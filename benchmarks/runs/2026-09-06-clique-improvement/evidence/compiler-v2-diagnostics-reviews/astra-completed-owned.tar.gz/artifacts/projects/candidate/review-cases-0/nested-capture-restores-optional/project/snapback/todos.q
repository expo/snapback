mutation probe(todoId: todos, done: bool ?):
  for done in ["yes"]:
    box = { value: done }
    broken = { saved: new, fail: missingInner }
    update todos[todoId] { done: box.value }
  insert todos { title: "x", done, ownerId: viewer }
  return missingAfter
