mutation probe(todoId: todos, done: bool ?):
  if done != null:
    match todos[todoId]:
      some done:
        bad = missingInner
        update todos[todoId] { done: done.title }
      none:
        insert todos { title: "x", done, ownerId: viewer }
    insert todos { title: "x", done, ownerId: viewer }
  insert todos { title: "x", done, ownerId: viewer }
  return true
