mutation probe(todoId: todos, value: text <=20 ?):
  lost = missingValue
  update todos[todoId] { title: .title, done: value }
  return true
