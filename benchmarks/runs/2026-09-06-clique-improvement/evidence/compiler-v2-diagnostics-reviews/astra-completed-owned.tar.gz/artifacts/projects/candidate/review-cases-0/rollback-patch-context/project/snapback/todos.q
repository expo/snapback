mutation probe(todoId: todos):
  update todos[todoId] { title: .title, done: missingInside }
  update todos[todoId] { done: "yes" }
  return missingAfter
