mutation probe(todoId: todos):
  item = missingOuter
  page = merge todos first 3 by byOwner:
    [item.title] for item in todos[(todos[missingDomain] ! else DOMAIN).ownerId] first 2 by byOwner
  update todos[todoId] { done: "yes" }
  return missingAfter
