mutation probe(todoId: todos):
  done = missingValue
  done = done ?? true
  alias = { done }
  update todos[todoId] { done: alias.done }
  update todos[todoId] { done: "yes" }
  return missingAfter
