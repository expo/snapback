mutation probe(done: bool ?):
  lost = missingValue
  box = { done }
  insert todos { title: "x", done: box.done, ownerId: viewer }
  return missingAfter
