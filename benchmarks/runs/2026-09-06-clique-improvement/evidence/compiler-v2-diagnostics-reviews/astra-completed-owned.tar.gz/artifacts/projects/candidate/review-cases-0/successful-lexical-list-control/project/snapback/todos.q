mutation probe(todoId: todos, values: [bool] <=3):
  box = { values }
  for done in box.values:
    update todos[todoId] { done }
  return true
