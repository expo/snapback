query range():
  return []
