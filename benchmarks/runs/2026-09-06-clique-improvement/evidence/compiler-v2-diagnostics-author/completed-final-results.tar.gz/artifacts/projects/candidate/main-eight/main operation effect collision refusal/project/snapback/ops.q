effect notify from delivery
query notify():
  return null
