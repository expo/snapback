effect range from delivery
query ping():
  return null
