mutation send(conversationId: id):
  for m in memberships[conversationId] first 50 by byConversationPrincipal { principal }:
    insert deliveries { principal: m.principal }
