mutation send(conversationId: id):
  for m in memberships[conversationId] first 50 by byConversationPrincipal:
    insert deliveries { principal: m.principal }
