effect orderedPair from delivery
query ping():
  return null
