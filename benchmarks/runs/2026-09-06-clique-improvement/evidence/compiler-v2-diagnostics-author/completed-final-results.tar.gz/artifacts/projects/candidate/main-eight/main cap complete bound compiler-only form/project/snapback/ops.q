mutation send(conversationId: id):
  page = memberships[conversationId] first 50 by byConversationPrincipal
  for m in page:
    insert deliveries { principal: m.principal }
