query reactions(messageId: messages):
  return reactions[messageId] first 20 by byMessage
