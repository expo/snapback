table messages:
  body: text <=100
  public
table reactions:
  messageId: messages
  emoji: text <=8
  by byMessage: messageId, id
  public
