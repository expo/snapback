fn isAdmin from access

query mine(c: cursor ?):
  page = memberships[viewer] after c first 50 by byPrincipalConversation
  return page { id, conversationId, role, unread: unreadCounts[.conversationId, viewer, .id, false], conversation: conversations[.conversationId], members: memberships[.conversationId] first 2 by byConversationPrincipal { principal, profile: profiles[.principal] { displayName, handle, avatar, principal } } }

query info(conversationId: conversations):
  row = conversations[conversationId] ! else MEMBERSHIP_REQUIRED
  return { conversation: row, members: memberships[conversationId] first 50 by byConversationPrincipal { *, profile: profiles[.principal] { displayName, handle, avatar, principal } } }

mutation dmCreate(other: principal):
  require other != viewer else SELF_DM
  require exists profiles[other] else PERSON_REQUIRED
  (lo, hi) = sorted(viewer, other)
  pair = dmPairs[lo, hi]
  if pair != null:
    return { id: pair.conversation }
  conversationId = new
  insert conversations { id: conversationId, title: 'Direct message', kind: 'dm', peer: other, creatorId: viewer }
  insert memberships { conversationId, principal: viewer, role: 'admin', joinedAt: now }
  insert memberships { conversationId, principal: other, role: 'member', joinedAt: now }
  insert dmPairs { lo, hi, conversation: conversationId }
  return { id: conversationId }

mutation groupCreate(title: text 1..50, description: text <=200, members: [principal] <=49, key: text <=100):
  require count(members) >= 1 else GROUP_REQUIRES_MEMBER
  old = conversations[viewer, key, null]
  if old != null:
    return { id: old.id }
  conversationId = new
  insert conversations { id: conversationId, title, description, kind: 'group', key, creatorId: viewer }
  insert memberships { conversationId, principal: viewer, role: 'admin', joinedAt: now }
  for principal in members:
    require principal != viewer else CREATOR_ALREADY_ADMIN
    require exists profiles[principal] else PERSON_REQUIRED
    insert memberships { conversationId, principal, role: 'member', joinedAt: now }
  return { id: conversationId }

mutation memberAdd(conversationId: conversations, principal: principal):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  if exists memberships[conversationId, principal]:
    return null
  require memberCounts[conversationId] < 50 else GROUP_FULL
  row = insert memberships { conversationId, principal, role: 'member', joinedAt: now } if absent
  return null

mutation memberPromote(conversationId: conversations, membershipId: memberships):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  membership = memberships[membershipId] ! else MEMBERSHIP_REQUIRED
  require membership.conversationId = conversationId else MEMBERSHIP_SCOPE_REQUIRED
  update memberships[membership] { role: 'admin' }
  return null

mutation memberRemove(conversationId: conversations, membershipId: memberships):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  membership = memberships[membershipId] ! else MEMBERSHIP_REQUIRED
  require membership.conversationId = conversationId else MEMBERSHIP_SCOPE_REQUIRED
  delete memberships[membership]
  return null

mutation memberLeave(conversationId: conversations, membershipId: memberships):
  membership = memberships[conversationId, viewer] ! else MEMBERSHIP_REQUIRED
  require membership.id = membershipId else MEMBERSHIP_SELF_REQUIRED
  delete memberships[membership]
  return null

mutation configure(conversationId: conversations, title: text 1..50, description: text <=200, color: text <=20 ?, background: image <=10000000 ?, disappearing: enum('off', '24h', '7d')):
  c = conversations[conversationId] ! else MEMBERSHIP_REQUIRED
  if c.kind = 'group':
    require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
    update conversations[c] { title, description, color, background, disappearing }
  else:
    require title = c.title else DM_NAME_FIXED
    update conversations[c] { color, background, disappearing }
  return null

query searchMemberships(c: cursor ?):
  return memberships[viewer] after c first 100 by byPrincipalConversation { id, conversationId }

query membershipTotal():
  return membershipsCounts[viewer]
