proc forgetUnread from digests
proc trackUnread from digests
proc messagePush from pushes
fn dayTTL from windows
fn weekTTL from windows
fn editWindowMs from windows
fn deleteWindowMs from windows
fn isMember from access
fn conversationMembers from access

shape messageCard = { *, myReceipt: messageReceipts[.id, viewer] { received, seen }, profile: profiles[.authorId] { displayName, handle, avatar, principal }, quoted: messages[.quote] { id, body: slice(.body ?? '', 0, 200), profile: profiles[.authorId] { displayName, handle, avatar, principal } } }

query inbox(c: cursor ?):
  page = deliveries[viewer] after c first 40 by byRecipient
  return page { *, message: messages[.row] messageCard }

query thread(conversationId: conversations, c: cursor ?):
  page = deliveries[viewer, conversationId, 'delivered'] after c last 40 by byRecipientGroup
  return page { *, message: messages[.row] messageCard }

query history(conversationId: conversations, c: cursor ?):
  require isMember(conversationId, viewer) else MEMBERSHIP_REQUIRED
  return messages[conversationId] after c last 50 by byConvTime messageCard

query receipts(messageId: messages):
  msg = messages[messageId] ! else NOT_FOUND
  return messageReceipts[messageId] first 50 by byMessage { recipient, received, seen, active: .membership != null and memberships[.conversation, .recipient].id = .membership }

query pendingReceipt():
  return messageReceipts[viewer, false] first 1 by byRecipientReceived

mutation mark(messageId: messages, seen: bool):
  if seen:
    forgetUnread(messageId, viewer)
  receipt = messageReceipts[messageId, viewer]
  if receipt != null:
    update messageReceipts[receipt] { received: true, seen: receipt.seen or seen }
  return null

mutation send(conversationId: conversations, body: text 1..2000, quote: messages ?, key: text <=100):
  require isMember(conversationId, viewer) else NOT_MEMBER
  existing = messages[viewer, key]
  if existing != null:
    return { id: existing.id }
  if quote != null:
    quoted = messages[quote] ! else QUOTE_REQUIRED
    require quoted.conversationId = conversationId else QUOTE_SCOPE
  rowId = new
  config = conversations[conversationId] ! else NOT_MEMBER
  if config.disappearing = '24h':
    insertText(rowId, conversationId, body, quote, key, now + dayTTL())
  else:
    if config.disappearing = '7d':
      insertText(rowId, conversationId, body, quote, key, now + weekTTL())
    else:
      insertText(rowId, conversationId, body, quote, key, null)
  for member in conversationMembers(conversationId):
    if member.principal != viewer:
      insert messageReceipts { conversation: conversationId, message: rowId, recipient: member.principal, membership: member.id, received: false, seen: false }
      trackUnread(rowId, conversationId, member.principal, member.id)
      messagePush(member.principal, conversationId, body)
  return { id: rowId }

proc insertText(rowId: messages, conversationId: conversations, body: text <=2000, quote: messages ?, key: text <=100, expiresAt: time ?):
  insert messages { id: rowId, conversationId, authorId: viewer, body, quote, key, expiresAt, at: now }

query byKey(author: principal, key: text <=100):
  return messages[author, key]

proc clearReceipts(conversationId: conversations, messageId: messages):
  for member in memberships[conversationId] first 50 by byConversationPrincipal:
    forgetUnread(messageId, member.principal)
    if exists messageReceipts[messageId, member.principal] by byMessageRecipient:
      delete messageReceipts[messageId, member.principal]

mutation expire(messageId: messages):
  msg = messages[messageId]
  if msg != null:
    clearReceipts(msg.conversationId, messageId)
    delete messages[msg]
  return null

schedule expireMessage on messages at .expiresAt: expire(.id)

mutation sendMedia(conversationId: conversations, caption: text <=500, photo: image <=10000000 ?, clip: video <=50000000 ?, once: bool, key: text <=100):
  require isMember(conversationId, viewer) else NOT_MEMBER
  require photo != null or clip != null else MEDIA_REQUIRED
  require photo = null or clip = null else MIXED_MEDIA
  require once = false or photo != null else PHOTO_ONLY
  if clip != null:
    require clip.duration <= 60000 else VIDEO_TOO_LONG
  old = messages[viewer, key]
  if old != null:
    return { id: old.id }
  rowId = new
  config = conversations[conversationId] ! else NOT_MEMBER
  if config.disappearing = '24h':
    insertMedia(rowId, conversationId, caption, photo, clip, once, key, now + dayTTL())
  else:
    if config.disappearing = '7d':
      insertMedia(rowId, conversationId, caption, photo, clip, once, key, now + weekTTL())
    else:
      insertMedia(rowId, conversationId, caption, photo, clip, once, key, null)
  for member in conversationMembers(conversationId):
    if member.principal != viewer:
      insert messageReceipts { conversation: conversationId, message: rowId, recipient: member.principal, membership: member.id, received: false, seen: false }
      trackUnread(rowId, conversationId, member.principal, member.id)
      if clip != null:
        messagePush(member.principal, conversationId, 'Video')
      else:
        messagePush(member.principal, conversationId, 'Photo')
  return { id: rowId }

proc insertMedia(rowId: messages, conversationId: conversations, caption: text <=500, photo: image <=10000000 ?, clip: video <=50000000 ?, once: bool, key: text <=100, expiresAt: time ?):
  if once:
    insert messages { id: rowId, conversationId, authorId: viewer, body: caption, oncePhoto: photo, key, expiresAt, at: now }
  else:
    insert messages { id: rowId, conversationId, authorId: viewer, body: caption, photo, clip, key, expiresAt, at: now }

mutation edit(messageId: messages, body: text <=2000):
  msg = messages[messageId] ! else NOT_FOUND
  require msg.authorId = viewer else NOT_AUTHOR
  require msg.deleted != true else DELETED
  require now - msg.at <= editWindowMs() else EDIT_WINDOW_EXPIRED
  if msg.photo != null or msg.clip != null or msg.oncePhoto != null:
    require body = slice(body, 0, 500) else CAPTION_TOO_LONG
  update messages[msg] { body, editedAt: now }
  return null

mutation unsend(messageId: messages):
  msg = messages[messageId] ! else NOT_FOUND
  require msg.authorId = viewer else NOT_AUTHOR
  require now - msg.at <= deleteWindowMs() else DELETE_WINDOW_EXPIRED
  clearReceipts(msg.conversationId, messageId)
  update messages[msg] { body: null, photo: null, clip: null, oncePhoto: null, deleted: true }
  return null

mutation react(messageId: messages, emoji: text <=64 ?, mutationId: text <=100):
  msg = messages[messageId] ! else NOT_FOUND
  require isMember(msg.conversationId, viewer) else MEMBERSHIP_REQUIRED
  require msg.deleted != true else DELETED
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, key: mutationId }
  old = reactions[messageId, viewer]
  if emoji = null:
    if old != null:
      delete reactions[old]
  else:
    if old != null:
      update reactions[old] { emoji }
    else:
      insert reactions { conversation: msg.conversationId, message: messageId, actor: viewer, emoji }
  return null

query reactions(messageId: messages):
  msg = messages[messageId] ! else NOT_FOUND
  return reactions[msg.conversationId, messageId] first 1000 by byConversationMessage { actor, emoji }

query search(term: text <=128, conversationId: conversations ?, c: cursor ?):
  if conversationId != null:
    require isMember(conversationId, viewer) else MEMBERSHIP_REQUIRED
    return messages[conversationId, term] after c last 20 by bySearch { id, body: slice(.body ?? '', 0, 200), conversationId, at, expiresAt, chat: conversations[.conversationId] { title, id } }
  else:
    page = merge messages after c last 20 by bySearch:
      [m.conversationId, term] for m in memberships[viewer] first 100 by byPrincipalConversation
    return page { id, body: slice(.body ?? '', 0, 200), conversationId, at, expiresAt, chat: conversations[.conversationId] { title, id } }


shape decoration = { id, receipts: messageReceipts[.id] first 50 by byMessage { recipient, received, seen, active: .membership != null and memberships[.conversation, .recipient].id = .membership }, reactions: reactions[.conversationId, .id] first 50 by byConversationMessage { actor, emoji } }
query decorations(m0: messages ?, m1: messages ?, m2: messages ?, m3: messages ?, m4: messages ?, m5: messages ?, m6: messages ?, m7: messages ?, m8: messages ?, m9: messages ?, m10: messages ?, m11: messages ?, m12: messages ?, m13: messages ?, m14: messages ?, m15: messages ?):
  return { m0: messages[m0] decoration, m1: messages[m1] decoration, m2: messages[m2] decoration, m3: messages[m3] decoration, m4: messages[m4] decoration, m5: messages[m5] decoration, m6: messages[m6] decoration, m7: messages[m7] decoration, m8: messages[m8] decoration, m9: messages[m9] decoration, m10: messages[m10] decoration, m11: messages[m11] decoration, m12: messages[m12] decoration, m13: messages[m13] decoration, m14: messages[m14] decoration, m15: messages[m15] decoration }

query clock():
  return now
