import {chromium} from '../choreography/node_modules/playwright/index.mjs';
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
const milestone=process.argv[process.argv.indexOf('--milestone')+1];
if(milestone==='m8'){await import('./acceptance-m8.mjs');process.exit(process.exitCode||0);}
if(milestone==='m6'){await import('./acceptance-m6.mjs');process.exit(process.exitCode||0);}
if(milestone==='m5'){await import('./acceptance-m5.mjs');process.exit(process.exitCode||0);}
if(milestone==='m4'){await import('./acceptance-m4.mjs');process.exit(process.exitCode||0);}
if(milestone==='m3'){await import('./acceptance-m3.mjs');process.exit(process.exitCode||0);}
if(milestone==='m2'){await import('./acceptance-m2.mjs');process.exit(process.exitCode||0);}
const coverage={m1:{'m1-a01':'signup','m1-a02':'signup','m1-a03':'duplicate-handle','m1-a04':'duplicate-email','m1-a08':'profile-edit','m1-a10':'avatar','m1-a11':'avatar'}};
const required=JSON.parse(readFileSync('instrument/schema/social-messenger/assertions.json')).milestones[milestone.toUpperCase()].assertions.filter(x=>x.executor==='suite-required');
for(const a of required)assert(coverage[milestone]?.[a.id],`Missing coverage ${a.id}`);
writeFileSync(`evidence/${milestone}-coverage.json`,JSON.stringify(coverage[milestone],null,2));
const browser=await chromium.launch({headless:true});const page=await browser.newPage();
page.setDefaultTimeout(15000);const id=s=>page.getByTestId(s);const checks=[];
try{
 const n=Date.now().toString().slice(-10),email=`test${n}@example.com`,password=`Test!${n}`,handle=`test${n}`;
 await page.goto('http://localhost:53101');await id('sm-auth-toggle').click();await id('sm-auth-email').fill(email);await id('sm-auth-password').fill(password);await id('sm-auth-submit').click();await id('sm-profile-field-displayname').fill('Acceptance Person');await id('sm-profile-field-handle').fill('alice');await id('sm-profile-save').click();await id('sm-profile-error').waitFor();assert.match(await id('sm-profile-error').innerText(),/HANDLE|unique/i);checks.push('duplicate-handle');
 await id('sm-profile-field-handle').fill(handle);await id('sm-profile-save').click();await id('sm-profile-heading').waitFor();assert.equal(await id('sm-profile-heading').innerText(),'Acceptance Person');checks.push('signup');
 await id('sm-profile-edit').click();await id('sm-profile-field-displayname').fill('Updated Person');await id('sm-profile-field-bio').fill('Acceptance bio');const chooser=page.waitForEvent('filechooser');await id('sm-profile-avatar').click();await(await chooser).setFiles('instrument/fixtures/media/avatar-alice.png');await id('sm-profile-save').click();await id('sm-profile-heading').waitFor();assert.equal(await id('sm-profile-heading').innerText(),'Updated Person');assert.match(await id('sm-profile').innerText(),/Acceptance bio/);checks.push('profile-edit');
 await page.waitForFunction(()=>[...document.querySelectorAll('[data-testid="sm-profile"] img')].some(i=>i.complete&&i.naturalWidth>0));checks.push('avatar');
 await page.goto('http://localhost:53101/settings');await id('sm-settings-logout').click();await id('sm-auth-toggle').click();await id('sm-auth-email').fill(email);await id('sm-auth-password').fill(password);await id('sm-auth-submit').click();await id('sm-auth-error').waitFor();checks.push('duplicate-email');
 execFileSync('npm',['run','seed','--','--segment','m1'],{stdio:'pipe'});execFileSync('npm',['run','seed','--','--segment','m1'],{stdio:'pipe'});
 const receipt={milestone,pass:true,checks,coverage:coverage[milestone],epoch:Date.now()/1000};writeFileSync(`evidence/${milestone}-suite.json`,JSON.stringify(receipt,null,2));writeFileSync('evidence/suite-status.json',JSON.stringify({... (existsSync('evidence/suite-status.json')?JSON.parse(readFileSync('evidence/suite-status.json')):{}),[milestone]:{pass:true,receipt:`${milestone}-suite.json`}}));console.log(receipt);
}catch(e){await page.screenshot({path:`evidence/${milestone}-failure.png`});console.error(e);writeFileSync('evidence/suite-status.json',JSON.stringify({... (existsSync('evidence/suite-status.json')?JSON.parse(readFileSync('evidence/suite-status.json')):{}),[milestone]:{pass:false,receipt:null,outcomeClass:'application'}}));process.exitCode=1;}finally{await browser.close()}
