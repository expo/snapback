query mine():
  return profiles[viewer]

query byHandle(handle: text <=20):
  return profiles[handle]

mutation createMyProfile(displayName: text <=50, handle: text <=20, avatar: image <=10000000 ?, bio: text <=200, location: text <=50, link: text <=2048 ?):
  require not exists profiles[handle] else HANDLE_TAKEN
  return insert profiles { principal: viewer, displayName, handle, avatar, bio, location, link }

mutation updateMyProfile(displayName: text <=50, handle: text <=20, avatar: image <=10000000 ?, bio: text <=200, location: text <=50, link: text <=2048 ?):
  existing = profiles[viewer] ! else PROFILE_REQUIRED
  update profiles[existing] { displayName, handle, avatar, bio, location, link }
  return profiles[existing.id] ! else PROFILE_REQUIRED

query counts(principal: principal):
  return { followers: followerCounts[principal], following: followingCounts[principal], followed: exists follows[viewer, principal] by byFollowerFollowed }

query people(c: cursor ?):
  return profiles[] after c first 50 by byHandle

query searchName(term: text <=128, c: cursor ?):
  return profiles[term] after c last 20 by bySearchName

query searchHandle(term: text <=128, c: cursor ?):
  return profiles[term] after c last 20 by bySearchHandle
