fn replayMode from runtime
effect deliver from push
proc messagePush(target: principal, conversation: conversations, preview: text <=2000):
  if replayMode() = false:
    if exists connected[target] = false:
      sender = profiles[viewer] ! else PROFILE_REQUIRED
      emit deliver { targetUserId: target, chatId: conversation, senderDisplayName: sender.displayName, preview: slice(preview, 0, 80) }
