fn replayMode from runtime
fn digestPeriodMs from digestconfig
fn digestAnchorMs from digestconfig
mutation createPost(body: text <=500, images: [image <=10000000] <=4 ?, clip: video <=50000000 ?, parent: posts ?, key: text <=100):
  require exists profiles[viewer] else PROFILE_REQUIRED
  require images = null or clip = null else MIXED_MEDIA
  if clip != null:
    require clip.duration <= 60000 else VIDEO_TOO_LONG
  existing = posts[viewer, key]
  if existing != null:
    return existing
  if parent != null:
    require exists posts[parent] else POST_REQUIRED
  (day, unusedDay) = divmod(now, 86400000)
  (unusedPeriod, rem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  row = insert posts { author: viewer, body, images, clip, parent, key, at: now, day, period: now - rem, eligible: replayMode() = false, replyAuthor: posts[parent].author }
  if parent = null:
    if replayMode() = false:
      counter = postPeriodCounts[viewer, now - rem]
      if counter = null:
        insert postPeriodCounts { author: viewer, period: now - rem, value: 1 }
      else:
        update postPeriodCounts[counter] { value: counter.value + 1 }
    insert feedEntries { actor: viewer, post: row.id, repost: false, at: now }
    insert rankings { post: row.id, author: viewer, likes: 0, at: now, expiresAt: now + 86400000 }
  return row

mutation setLike(post: posts, active: bool, mutationId: text <=100):
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, key: mutationId }
  original = posts[post] ! else POST_REQUIRED
  (day, unusedDay) = divmod(now, 86400000)
  if active:
    insert likes { actor: viewer, post, recipient: original.author, day, at: now } if absent
  else:
    row = likes[viewer, post]
    if row != null:
      delete likes[row]
  ranking = rankings[post]
  if ranking != null:
    update rankings[ranking] { likes: likeCounts[post] }
  return null

mutation setRepost(post: posts, active: bool, mutationId: text <=100):
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, key: mutationId }
  original = posts[post] ! else POST_REQUIRED
  require original.parent = null else REPLIES_NOT_REPOSTED
  if active:
    insert reposts { actor: viewer, post, recipient: original.author, at: now } if absent
    insert feedEntries { actor: viewer, post, repost: true, at: now } if absent
  else:
    row = reposts[viewer, post]
    if row != null:
      delete reposts[row]
      entry = feedEntries[viewer, post, true]
      if entry != null:
        if entry.repost:
          delete feedEntries[entry]
  return null

query byKey(author: principal, key: text <=100):
  return posts[author, key]
