proc refresh(conversationId: conversations):
  update conversations[conversationId] { visibleMessageCount: visibleCounts[conversationId, null] + visibleCounts[conversationId, false] }

job backfill():
  chunk c in conversations first 100 by byId:
    refresh(c.id)
