use identity password

table profiles:
  principal: principal
  displayName: text 1..50
  handle: text 3..20 format handle
  avatar: image <=10000000 ?
  by bySearchName: wordPrefixes(displayName), id
  by bySearchHandle: wordPrefixes(handle), id
  bio: text <=200
  location: text <=50
  link: text <=2048 format url ?
  unique byPrincipal: principal
  unique byHandle: handle
  immutable principal
  public 'profiles are public'
  insert <- .principal = viewer
  update <- .principal = viewer
  delete <- deny

table conversations:
  visibleMessageCount: int
  title: text 1..50
  description: text <=200 ?
  kind: enum('dm', 'group') ?
  peer: principal ?
  color: text <=20 ?
  background: image <=10000000 ?
  disappearing: enum('off', '24h', '7d') ?
  key: text <=100 ?
  creatorId: principal
  unique byCreatorKey: creatorId, key, peer
  by byCreator: creatorId
  unique byIdCreator: id, creatorId
  read <- exists memberships[.id, viewer]
  insert <- .creatorId = viewer
  update <- exists memberships[.id, viewer]
  delete <- deny
  after insert <- exists memberships[.id, .creatorId, 'admin']

table memberships:
  conversationId: conversations
  principal: principal
  role: enum('member', 'admin')
  joinedAt: time
  unique byConversationPrincipal: conversationId, principal
  by byConversationPrincipalRole: conversationId, principal, role
  by byPrincipalConversation: principal, conversationId, id
  cap 1000 by principal
  cap 50 by conversationId
  immutable conversationId, principal, joinedAt
  read <- exists memberships[.conversationId, viewer]
  insert <- (
    exists memberships[.conversationId, viewer, 'admin']
    or (
      .principal = viewer
      and .role = 'admin'
      and created conversations[.conversationId, viewer]
    )
  )
  update (old, next) <- (
    exists memberships[old.conversationId, viewer, 'admin']
    and old.role = 'member'
    and next.role = 'admin'
  )
  delete <- (
    .principal = viewer
    or exists memberships[.conversationId, viewer, 'admin']
  )

table messages:
  pollOptions: [text 1..50] <=4 ?
  conversationId: conversations
  authorId: principal
  body: text <=2000 ?
  photo: image <=10000000 ?
  clip: video <=50000000 ?
  oncePhoto: image <=10000000 once ?
  quote: messages ?
  key: text <=100 ?
  expiresAt: time ?
  deleted: bool ?
  editedAt: time ?
  at: time
  unique byIdAuthor: id, authorId
  unique byAuthorKey: authorId, key
  by byConvTime: conversationId, at, id
  by bySearch: conversationId, wordPrefixes(body), at, id
  immutable conversationId, authorId
  deliver to memberships[.conversationId] as deliveries with receipts
  retain delivered-history
  read <- exists memberships[.conversationId, viewer]
  insert <- (
    .authorId = viewer
    and exists memberships[.conversationId, viewer]
  )
  update <- .authorId = viewer
  delete <- .authorId = viewer


table posts:
  day: int ?
  period: time ?
  eligible: bool ?
  replyAuthor: principal ?
  author: principal
  body: text <=500
  images: [image <=10000000] <=4 ?
  clip: video <=50000000 ?
  parent: posts ?
  key: text <=100 ?
  at: time
  by byTime: parent, at, id
  by byAuthorTime: author, parent, at, id
  unique byKey: author, key
  immutable author, at
  public 'posts are globally readable product content'
  insert <- .author = viewer
  update <- .author = viewer
  delete <- .author = viewer
  after insert <- exists profiles[.author]

table follows:
  period: time ?
  eligible: bool ?
  cap 500 by follower
  follower: principal
  followed: principal
  at: time
  unique byFollowerFollowed: follower, followed
  by byFollower: follower, followed
  by byFollowed: followed, follower
  immutable follower, followed, at
  public 'follows are public product-selection relationships'
  insert <- .follower = viewer
  update <- deny
  delete <- .follower = viewer

table notifications:
  outboxId: id
  effect: text <=100
  providerId: text <=200
  unique byOutbox: outboxId
  read <- deny
  insert <- deny
  update <- deny
  delete <- deny

maintain messageCounts: count messages by conversationId
  read <- exists memberships[.conversationId, viewer]

channel typing(conversationId: conversations):
  value: { typing: bool }
  publish <- exists memberships[conversationId, viewer]
  subscribe <- exists memberships[conversationId, viewer]
  ttl 4s

maintain memberCounts: count memberships by conversationId
  read <- exists memberships[.conversationId, viewer]

table feedEntries:
  actor: principal
  post: posts
  repost: bool
  at: time
  unique byActorPostKind: actor, post, repost
  by byTime: at, id
  by byActorTime: actor, at, id
  public 'feed projections are public'
  insert <- .actor = viewer
  update <- deny
  delete <- .actor = viewer

table likes:
  recipient: principal ?
  day: int ?
  actor: principal
  post: posts
  at: time
  unique byActorPost: actor, post
  by byPost: post, actor
  public 'like states are public'
  insert <- .actor = viewer
  update <- deny
  delete <- .actor = viewer

table reposts:
  recipient: principal ?
  actor: principal
  post: posts
  at: time
  unique byActorPost: actor, post
  by byPost: post, actor
  public 'repost states are public'
  insert <- .actor = viewer
  update <- deny
  delete <- .actor = viewer

maintain likeCounts: count likes by post
  read <- allow
maintain repostCounts: count reposts by post
  read <- allow
maintain replyCounts: count posts by parent
  read <- allow
maintain followerCounts: count follows by followed
  read <- allow
maintain followingCounts: count follows by follower
  read <- allow

table intents:
  actor: principal
  key: text <=100
  unique byActorKey: actor, key
  read <- .actor = viewer
  insert <- .actor = viewer
  update <- deny
  delete <- deny

table dmPairs:
  lo: principal
  hi: principal
  conversation: conversations
  unique byPair: lo, hi
  read <- .lo = viewer or .hi = viewer
  insert <- .lo = viewer or .hi = viewer
  update <- deny
  delete <- deny

table messageReceipts:
  membership: memberships ?
  conversation: conversations
  message: messages
  cap 50 by message
  recipient: principal
  received: bool
  seen: bool
  unique byMessageRecipient: message, recipient
  by byMessage: message, recipient
  by byRecipientReceived: recipient, received, id
  read <- .recipient = viewer or exists memberships[.conversation, viewer]
  insert <- exists memberships[.conversation, viewer]
  update <- .recipient = viewer
  delete <- .recipient = viewer or exists messages[.message, viewer] by byIdAuthor

table reactions:
  conversation: conversations
  message: messages
  actor: principal
  emoji: text 1..64
  unique byMessageActor: message, actor
  by byConversationMessage: conversation, message, actor
  read <- exists memberships[.conversation, viewer]
  insert <- .actor = viewer and exists memberships[.conversation, viewer]
  update <- .actor = viewer and exists memberships[.conversation, viewer]
  delete <- .actor = viewer and exists memberships[.conversation, viewer]

table pushLogs:
  outboxId: id
  effect: text <=100
  payload: json <=2048
  at: time
  unique byOutbox: outboxId
  by byTime: at, id
  read <- deny
  insert <- deny
  update <- deny
  delete <- deny

maintain reactionCounts: count reactions by conversation, message, emoji
  read <- exists memberships[.conversation, viewer]

maintain postTotals: count posts by author, parent
  read <- allow
maintain likesReceived: count likes by recipient
  read <- allow
maintain repostsReceived: count reposts by recipient
  read <- allow
maintain repliesReceived: count posts by replyAuthor
  read <- allow
maintain postsByDay: count posts by author, parent, day
  read <- allow
maintain likesByDay: count likes by recipient, day
  read <- allow
maintain postsByPeriod: count posts by author, parent, period, eligible
  read <- deny
maintain followersByPeriod: count follows by followed, period, eligible
  read <- deny
maintain unreadCounts: count messageReceipts by conversation, recipient, membership, seen
  read <- .recipient = viewer

table rankings:
  post: posts
  author: principal
  likes: int
  at: time
  expiresAt: time ?
  unique byPost: post
  by byRank: likes, at, id
  public 'public trending projection'
  insert <- .author = viewer
  update <- allow
  delete <- deny

table digestUnread:
  recipient: principal
  author: principal
  conversation: conversations
  membership: memberships
  message: messages
  period: time
  expiresAt: time ?
  unique byMessageRecipient: message, recipient
  by byRecipientPeriod: recipient, period, id
  immutable recipient, author, conversation, membership, message, period
  read <- .recipient = viewer or (.author = viewer and exists memberships[.conversation, viewer])
  insert <- .author = viewer and exists memberships[.conversation, viewer]
  update <- deny
  delete <- .recipient = viewer or (.author = viewer and exists memberships[.conversation, viewer])
maintain digestUnreadCounts: count digestUnread by membership, period
  read <- exists memberships[.membership]

table digestScratch:
  target: principal
  period: time
  unique byTargetPeriod: target, period
  followers: int
  posts: int
  messages: int
  chats: int
  read <- deny
  insert <- deny
  update <- deny
  delete <- deny

table digestHistory:
  target: principal
  periodStart: time
  periodEnd: time
  newFollowers: int
  newPostsInFollowing: int
  unreadMessages: int
  unreadChats: int
  unique byTargetPeriod: target, periodStart
  by byTarget: target, periodStart, id
  read <- .target = viewer
  insert <- deny
  update <- deny
  delete <- deny

table postPeriodCounts:
  author: principal
  period: time
  value: int
  unique byAuthorPeriod: author, period
  read <- .author = viewer
  insert <- .author = viewer
  update <- .author = viewer
  delete <- deny

maintain membershipsCounts: count memberships by principal
  read <- .principal = viewer

table digestPeriodCounts:
  membership: memberships
  period: time
  recipient: principal
  value: int
  unique byMembershipPeriod: membership, period
  by byRecipientPeriod: recipient, period, id
  cap 1000 by recipient, period
  immutable membership, period, recipient
  read <- .recipient = viewer or exists memberships[.membership]
  insert <- exists memberships[.membership]
  update <- .recipient = viewer or exists memberships[.membership]
  delete <- deny
maintain digestPeriodCellCounts: count digestPeriodCounts by recipient, period
  read <- deny

maintain visibleCounts: count messages by conversationId, deleted
  read <- exists memberships[.conversationId, viewer]

table pollVotes:
  conversation: conversations
  message: messages
  actor: principal
  option: int
  unique byMessageActor: message, actor
  by byConversationMessage: conversation, message, actor
  read <- exists memberships[.conversation, viewer] and exists messages[.message]
  insert <- .actor = viewer and exists memberships[.conversation, viewer]
  update <- .actor = viewer and exists memberships[.conversation, viewer]
  delete <- .actor = viewer and exists memberships[.conversation, viewer]

maintain pollTallies: count pollVotes by conversation, message, option
  read <- exists memberships[.conversation, viewer] and exists messages[.message]
