-- Shortened fixture schedule; generated configuration surface.
fn digestPeriodMs(): 120000
fn digestAnchorMs(): 0
