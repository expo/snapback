import {effect} from 'snapback2';
import {recordPush} from './pushlog';
export const deliver = effect({grants:[],run:async(payload:{targetUserId:string;chatId?:string;senderDisplayName?:string;preview?:string;kind?:string;periodStart?:number;periodEnd?:number;newFollowers?:number;newPostsInFollowing?:number;unreadMessages?:number;unreadChats?:number},{meta})=>{console.log('clique-push',JSON.stringify(payload));return{...payload,providerId:meta.id};},then:recordPush});
