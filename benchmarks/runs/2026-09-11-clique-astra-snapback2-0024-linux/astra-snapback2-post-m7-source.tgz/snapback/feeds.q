shape card = { id, author, body, images, clip, parent, at, profile: profiles[.author], likes: likeCounts[.id], reposts: repostCounts[.id], replies: replyCounts[.id], liked: exists likes[viewer, .id], reposted: exists reposts[viewer, .id] }
query globalFeed(c: cursor ?):
  page = feedEntries[] after c last 20 by byTime
  return page { id, actor: profiles[.actor], repost, post: posts[.post] card }

query followingFeed(c: cursor ?):
  page = merge feedEntries after c last 20 by byActorTime:
    [viewer]
    [f.followed] for f in follows[viewer] first 500 by byFollower
  return page { id, actor: profiles[.actor], repost, post: posts[.post] card }

query byAuthor(author: principal, c: cursor ?):
  return posts[author, null] after c last 20 by byAuthorTime card

query thread(post: posts, c: cursor ?):
  root = posts[post] ! else POST_REQUIRED
  return { parent: root card, replies: posts[post] after c first 20 by byTime card }
