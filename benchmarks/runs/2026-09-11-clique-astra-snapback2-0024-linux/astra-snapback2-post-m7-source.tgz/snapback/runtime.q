-- Set true only in an isolated scale-replay deployment.
fn replayMode(): false
