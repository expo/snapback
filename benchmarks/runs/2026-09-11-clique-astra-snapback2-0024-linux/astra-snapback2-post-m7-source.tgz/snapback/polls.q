fn isMember from access
fn conversationMembers from access
fn dayTTL from windows
fn weekTTL from windows
proc trackUnread from digests
proc messagePush from pushes
proc refresh from counts

mutation create(conversationId: conversations, question: text 1..200, options: [text 1..50] <=4, mutationId: text 1..100):
  c = conversations[conversationId] ! else MEMBERSHIP_REQUIRED
  require c.kind = 'group' else GROUP_ONLY
  require count(options) >= 2 else POLL_OPTIONS_REQUIRED
  old = messages[viewer, mutationId]
  if old != null:
    return { id: old.id }
  rowId = new
  if c.disappearing = '24h':
    insertPoll(rowId, conversationId, question, options, mutationId, now + dayTTL())
  else:
    if c.disappearing = '7d':
      insertPoll(rowId, conversationId, question, options, mutationId, now + weekTTL())
    else:
      insertPoll(rowId, conversationId, question, options, mutationId, null)
  for member in conversationMembers(conversationId):
    if member.principal != viewer:
      insert messageReceipts { conversation: conversationId, message: rowId, recipient: member.principal, membership: member.id, received: false, seen: false }
      trackUnread(rowId, conversationId, member.principal, member.id)
      messagePush(member.principal, conversationId, question)
  refresh(conversationId)
  return { id: rowId }

proc insertPoll(rowId: messages, conversationId: conversations, question: text <=200, options: [text 1..50] <=4, key: text <=100, expiresAt: time ?):
  insert messages { id: rowId, conversationId, authorId: viewer, body: question, pollOptions: options, key, expiresAt, at: now }

mutation vote(messageId: messages, option: int, mutationId: text 1..100):
  msg = messages[messageId] ! else NOT_FOUND
  require isMember(msg.conversationId, viewer) else MEMBERSHIP_REQUIRED
  require msg.deleted != true else DELETED
  options = msg.pollOptions ! else NOT_POLL
  require option >= 0 and option < count(options) else INVALID_OPTION
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, key: mutationId }
  old = pollVotes[messageId, viewer]
  if old != null:
    update pollVotes[old] { option }
  else:
    insert pollVotes { conversation: msg.conversationId, message: messageId, actor: viewer, option }
  return null

query results(messageId: messages):
  msg = messages[messageId] ! else NOT_FOUND
  require msg.deleted != true else DELETED
  return { options: msg.pollOptions, mine: pollVotes[messageId, viewer].option, a: pollTallies[msg.conversationId, messageId, 0], b: pollTallies[msg.conversationId, messageId, 1], c: pollTallies[msg.conversationId, messageId, 2], d: pollTallies[msg.conversationId, messageId, 3] }
