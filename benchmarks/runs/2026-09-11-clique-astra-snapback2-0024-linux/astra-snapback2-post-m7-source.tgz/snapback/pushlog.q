mutation recordPush(outboxId: id, effect: text <=100, result: json <=2048):
  insert pushLogs { outboxId, effect, payload: result, at: now } if absent
  return true
