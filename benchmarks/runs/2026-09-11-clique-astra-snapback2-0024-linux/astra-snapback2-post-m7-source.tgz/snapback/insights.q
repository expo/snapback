shape card from feeds
query summary():
  (day, rem) = divmod(now, 86400000)
  return { posts: postTotals[viewer, null], likes: likesReceived[viewer], reposts: repostsReceived[viewer], replies: repliesReceived[viewer], followers: followerCounts[viewer], following: followingCounts[viewer], day, days: { d0: { day: day - 6, posts: postsByDay[viewer, null, day - 6], likes: likesByDay[viewer, day - 6] }, d1: { day: day - 5, posts: postsByDay[viewer, null, day - 5], likes: likesByDay[viewer, day - 5] }, d2: { day: day - 4, posts: postsByDay[viewer, null, day - 4], likes: likesByDay[viewer, day - 4] }, d3: { day: day - 3, posts: postsByDay[viewer, null, day - 3], likes: likesByDay[viewer, day - 3] }, d4: { day: day - 2, posts: postsByDay[viewer, null, day - 2], likes: likesByDay[viewer, day - 2] }, d5: { day: day - 1, posts: postsByDay[viewer, null, day - 1], likes: likesByDay[viewer, day - 1] }, d6: { day: day - 0, posts: postsByDay[viewer, null, day - 0], likes: likesByDay[viewer, day - 0] } } }
query trending():
  return rankings[] last 10 by byRank { id, likes, at, post: posts[.post] card }
schedule expireRanking on rankings at .expiresAt: delete .

job backfill():
  chunk p in posts first 1 by byId:
    (day, rem) = divmod(p.at, 86400000)
    update posts[p] { day, replyAuthor: posts[p.parent].author }
    if p.parent = null:
      if p.at > now - 86400000:
        insert rankings { post: p.id, author: p.author, likes: likeCounts[p.id], at: p.at, expiresAt: p.at + 86400000 } if absent
  chunk l in likes first 1 by byId:
    (day, rem) = divmod(l.at, 86400000)
    update likes[l] { recipient: posts[l.post].author, day }
  chunk r in reposts first 1 by byId:
    update reposts[r] { recipient: posts[r.post].author }
  chunk r in messageReceipts first 1 by byId:
    update messageReceipts[r] { membership: memberships[r.conversation, r.recipient].id }
