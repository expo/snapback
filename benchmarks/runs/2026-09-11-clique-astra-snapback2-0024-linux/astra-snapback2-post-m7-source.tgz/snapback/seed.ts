import { seed } from "snapback2";
export default seed({ personas: [], rows: {} });
