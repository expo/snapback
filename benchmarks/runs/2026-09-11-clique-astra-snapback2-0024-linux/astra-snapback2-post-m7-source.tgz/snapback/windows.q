-- Generated from config/windows.shortened.json; never from caller timestamps.
fn editWindowMs(): 60000
fn deleteWindowMs(): 120000
fn dayTTL(): 180000
fn weekTTL(): 300000
