fn replayMode from runtime
fn digestPeriodMs from digestconfig
fn digestAnchorMs from digestconfig
mutation setFollow(target: principal, following: bool, mutationId: text <=100 ?):
  if mutationId != null:
    if exists intents[viewer, mutationId]:
      return null
    insert intents { actor: viewer, key: mutationId }
  require target != viewer else SELF_FOLLOW
  if following:
    (unusedPeriod, rem) = divmod(now - digestAnchorMs(), digestPeriodMs())
    return insert follows { follower: viewer, followed: target, at: now, period: now - rem, eligible: replayMode() = false } if absent
  existing = follows[viewer, target]
  if existing != null:
    delete follows[existing]
  return null
