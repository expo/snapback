fn digestPeriodMs from digestconfig
fn digestAnchorMs from digestconfig
fn replayMode from runtime
effect deliver from push

proc trackUnread(messageId: messages, conversationId: conversations, recipient: principal, membershipId: memberships):
  if replayMode() = false:
    message = messages[messageId] ! else NOT_FOUND
    (period, rem) = divmod(now - digestAnchorMs(), digestPeriodMs())
    insert digestUnread { recipient, author: viewer, conversation: conversationId, membership: membershipId, message: messageId, period: now - rem, expiresAt: message.expiresAt }
    refreshCount(membershipId, recipient, now - rem)

proc refreshCount(membershipId: memberships, recipient: principal, period: time):
  cell = digestPeriodCounts[membershipId, period]
  amount = digestUnreadCounts[membershipId, period]
  if cell != null:
    update digestPeriodCounts[cell] { value: amount }
  else:
    insert digestPeriodCounts { membership: membershipId, recipient, period, value: amount }

proc forgetUnread(messageId: messages, recipient: principal):
  row = digestUnread[messageId, recipient]
  if row != null:
    delete digestUnread[row]
    refreshCount(row.membership, row.recipient, row.period)

mutation expireUnreadRow(rowId: digestUnread):
  row = digestUnread[rowId]
  if row != null:
    forgetUnread(row.message, row.recipient)
  return null

job backfillCounts():
  chunk row in digestUnread first 1 by byId:
    refreshCount(row.membership, row.recipient, row.period)

query mine(c: cursor ?):
  return digestHistory[viewer] after c last 20 by byTarget

job sweep(cutoff: time):
  chunk p in profiles first 1 by byId:
    if replayMode() = false:
      (period, rem) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
      periodEnd = cutoff - rem
      periodStart = periodEnd - digestPeriodMs()
      if exists digestHistory[p.principal, periodStart] = false and exists digestScratch[p.principal, periodStart] = false:
        scratch = insert digestScratch { target: p.principal, period: periodStart, followers: followersByPeriod[p.principal, periodStart, true], posts: postPeriodCounts[p.principal, periodStart].value ?? 0, messages: 0, chats: 0 }
        for f in follows[p.principal] first 500 by byFollower:
          update digestScratch[scratch] { posts: .posts + (postPeriodCounts[f.followed, periodStart].value ?? 0) }
  chunk p in profiles first 1 by byId:
    if replayMode() = false:
      (period, rem) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
      periodEnd = cutoff - rem
      periodStart = periodEnd - digestPeriodMs()
      if exists digestHistory[p.principal, periodStart] = false:
        scratch = digestScratch[p.principal, periodStart] ! else SCRATCH_REQUIRED
        for bucket in digestPeriodCounts[p.principal, periodStart] first 1000 by byRecipientPeriod:
          unread = bucket.value
          if unread > 0 and exists memberships[bucket.membership]:
            update digestScratch[scratch] { messages: .messages + unread, chats: .chats + 1 }
        total = digestScratch[scratch.id] ! else SCRATCH_REQUIRED
        if total.followers > 0 or total.posts > 0 or total.messages > 0 or total.chats > 0:
          insert digestHistory { target: p.principal, periodStart, periodEnd, newFollowers: total.followers, newPostsInFollowing: total.posts, unreadMessages: total.messages, unreadChats: total.chats }
          emit deliver { targetUserId: p.principal, kind: 'digest', periodStart, periodEnd, newFollowers: total.followers, newPostsInFollowing: total.posts, unreadMessages: total.messages, unreadChats: total.chats }
        delete digestScratch[total]
  chunk old in digestUnread first 1 by byId:
    (period, rem) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
    if old.period < cutoff - rem - digestPeriodMs():
      delete digestUnread[old]

  chunk oldCount in digestPeriodCounts first 1 by byId:
    (period, rem) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
    if oldCount.period < cutoff - rem - digestPeriodMs():
      delete digestPeriodCounts[oldCount]

schedule scheduledDigest every 1m: sweep(.periodEnd)
schedule expireUnread on digestUnread at .expiresAt: expireUnreadRow(.id)

query clock():
  return { now, periodMs: digestPeriodMs(), anchorMs: digestAnchorMs() }
