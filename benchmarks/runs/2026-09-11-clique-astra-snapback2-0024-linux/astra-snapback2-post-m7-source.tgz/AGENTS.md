<!-- snapback2:start -->
## Snapback 2

- `snapback2 check` compiles, certifies, and refreshes `.snapback/build/api.d.ts`.
- `snapback2 dev` starts or attaches to the one local owner and prints `SNAPBACK_URL`.
- Start React or Expo: `npm install && npx snapback2 dev && npm run dev`.
- The client config reads `.snapback/dev-url`; an explicit client URL environment variable overrides it.
- `snapback2 test` proves derived checks and authored journeys with a receipt.
- `snapback2 why <query> --as <persona>` explains rows, rules, and bounds.
- `snapback2 trace latest` follows commit → invalidation → delivery.
- Backends are `snapback/*.q`; `snapback2 guide quarry` is the language reference.
- Clients: `snapback2 guide live-query` for `data`, `status`, and non-throwing `run`; `snapback2 guide offline` for offline/recovery.
- Effect modules, `seed.ts`, and `tests/*.test.ts` are TypeScript.

Gotchas: authentication is always on; use `--as <persona>` only in development.
Every range names a `first`/`last` bound. Hook `status`, `receipt.state`, and `freshness` are separate.
Generated files stay under `.snapback/` and are never committed.
<!-- snapback2:end -->
