# Clique

Expo Router client and Quarry backend, pinned to `snapback2@0.0.24`.

```sh
npm ci
npx snapback2 check
npx snapback2 dev --port 53100
npm run dev
npm run seed -- --segment m1
npm run seed -- --segment m2
npm run seed -- --segment m3
npm run acceptance -- --milestone m5
node scripts/choreo.mjs m5
npm run export:ios -- --output-dir artifacts/manual-ios
```

The web client uses port 53101 and backend 53100. Starter segments use real
password signup and authenticated writes. Reinstalling a segment keeps its
stable intent keys; registrations and profiles are not duplicated. Fixture
passwords are read from the supplied instrument, not embedded in the client.

`node scripts/configure.mjs` selects production edit, delete, and expiration
windows. For grading use
`CLIQUE_WINDOWS_CONFIG=config/windows.shortened.json node scripts/configure.mjs`
then compile/apply the backend. Configuration changes are backend deployments,
not caller-controlled timestamp arguments. Existing messages retain their
original server expiration deadline.

The browser uses the package's IndexedDB store; native uses its SQLite/secure
store arm. Logout is an account boundary. Once-only images mount only while
explicitly viewing them. The server owns membership, deletion windows, expiry,
and asset access. Message history is paginated; delivery events carry changes
and removals into the cache. Online settings saves use the headless client so
an immediate browser navigation can preserve their keepalive requests.

Evidence is in `evidence/`; per-milestone Hermes exports are in `artifacts/`.
An iOS bundle export is not simulator proof. Apple simulator execution is
unavailable on this Ubuntu host. See `run-log.md` and `diary.md` for corrections
and limitations. Frozen UI, choreography, and metering are vendored separately
from authored source. Instrument files remain read-only inputs.

M8 adds `/insights`, the Trending feed tab, account-wide unread counts, and
scheduled digest emission through the logged push seam. Insights and Trending
load authoritative server snapshots and support refresh. Seven UTC-day buckets
include zeroes. Digest counts use server-maintained period data and current
membership incarnations; each user/period has a unique emission record.

For the shortened acceptance schedule, configure both files together:

```sh
CLIQUE_WINDOWS_CONFIG=config/windows.shortened.json \
CLIQUE_DIGEST_CONFIG=config/digest.shortened.json node scripts/configure.mjs
npx snapback2 check
```

The production digest period is anchored at 08:00 UTC. A server schedule checks
completed periods each minute. `node scripts/digest-proof.mjs` exercises the
shortened schedule with closed clients and a real backend restart. It must run
alone against the development owner because it deliberately stops that owner.

Run `npm run acceptance -- --milestone mN` and `node scripts/choreo.mjs mN` for
M1–M6 or M8. M4–M6 and M8 add no frozen starter segment. The choreography adapter
selects the real three-person Proof Trio fixture for the three-person receipt
check; see `evidence/instrument-gaps.md` for the frozen default fixture mismatch.
Install the copied harness with `npm ci --prefix choreography` before running it.

`API.md` documents the custom client and `scripts/custom-client-demo.mjs` is an
executable consumer. The replay adapter accepts `--url`, `--project`, `--out`,
`--logs` (comma-separated), and `--scale`; every accepted action writes a JSONL
receipt. Scale instances are fresh `snapback2 init` projects containing only
copies of authored backend files, with `runtime.q` setting replay mode true.
Replay state maps fixture logical IDs to backend opaque IDs. Never point the
scale adapter at the interactive development instance.

The frozen `instrument/ui` input is unchanged. Eight vendored UI components
carry only `aria-valuetext` mirrors of their existing `accessibilityValue.text`
for React Native Web compatibility. The exact patch is retained in
`evidence/ui-web-compatibility.patch`; visuals, data props, and native semantics
are preserved. App-owned wrappers additionally expose selected/read state from
real server data. The copied choreography is unmodified.

The completed-run results are in `final-report.md`, with the qualitative
comparison in `essay.md` and per-milestone notes in `diary.md`. `run-record.json`
is an ungraded builder record. Native token accounting was not supplied inside
this lane, so token/tool totals are null; no token-efficiency claim is made.
The final report distinguishes the required web green bar from strict scale
midpoint misses and unavailable native-simulator artifacts.

The web client forwards browser connectivity events to the durable SDK once per
transition. Conversation readiness waits for the authoritative inbox and local
write preparation. Cached messages also expire visually against a server-clock
anchor and server-issued deadline; backend deletion and asset authorization are
verified independently. Receipt/reaction display reads group sixteen message
IDs per subscription, rather than subscribing twice for every bubble.

M7 adds group polls and a backfilled visible-message count in chat settings.
Use **Create a poll** in any group conversation. Votes can change and queue
while offline; pending clears on settlement. Custom-client operations are in
`API.md`; the existing-data upgrade procedure and receipts are in
`m7/MIGRATION.md`.

Run `npm run acceptance -- --milestone m7` against the running app. It also runs
the unchanged previously green M1–M6 and M8 suites and retains fresh evidence
under `m7/evidence/acceptance-*/`. Then run `node scripts/choreo.mjs m7`; it
creates a new real group/poll fixture and invokes the unmodified choreography
with `m7` as its sole segment. M7 coverage is `m7/coverage-manifest.json`.
The per-persona migration snapshot is `m7/pre-snapshot/`.
