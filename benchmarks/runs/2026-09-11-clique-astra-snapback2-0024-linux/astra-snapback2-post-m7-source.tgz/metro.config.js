const { getDefaultConfig } = require('expo/metro-config');
const config=getDefaultConfig(__dirname);
config.maxWorkers=4;
config.resolver.blockList=[/\/\.snapback\//,/\/artifacts\//,/\/evidence\//,/\/choreography\//,/\/metering\//];
module.exports=config;
