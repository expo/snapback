import React from 'react';
import {useLocalSearchParams} from 'expo-router';
import {Profile} from '../../src/Clique';
export default function Screen(){const{handle}=useLocalSearchParams<{handle:string}>();return <Profile handle={handle}/>}
