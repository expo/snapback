export {OwnEdit as default} from '../../src/Clique';
