export {Feed as default} from '../src/Social';
