export {Settings as default} from '../src/Clique';
