import{ServerClock}from'../src/ServerClock';
import {Custody} from '../src/Custody';
import {ScrollSurface} from '../src/ScrollSurface';
import React from 'react';
import {Slot} from 'expo-router';
import {View,ScrollView} from 'react-native';
import Backend from '../src/Backend';
import {Gate} from '../src/Clique';
export default function Layout(){return <Backend><View style={{flex:1,backgroundColor:'#f8fafc'}}><ScrollSurface><ServerClock><Custody><Gate><Slot/></Gate></Custody></ServerClock></ScrollSurface></View></Backend>}
