import {useAssetFile} from 'snapback2/expo';
export const usePhoto=useAssetFile;
