import{api}from'snapback2/client';
import{useOnlineClient}from'./useOnlineClient';
// Membership changes require connectivity and must start their keepalive request
// before a settings navigation closes the page; they do not enter the message queue.
export function useGroupWrites(){const client=useOnlineClient();return{add:{run:(args:any)=>client.mutation(api.groups.memberAdd,args)},promote:{run:(args:any)=>client.mutation(api.groups.memberPromote,args)},remove:{run:(args:any)=>client.mutation(api.groups.memberRemove,args)},leave:{run:(args:any)=>client.mutation(api.groups.memberLeave,args)}}}
