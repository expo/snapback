import{useRef}from'react';
export function useSettingsSemantics(color:unknown,disappearing:unknown,background?:string){return useRef<any>(null)}
