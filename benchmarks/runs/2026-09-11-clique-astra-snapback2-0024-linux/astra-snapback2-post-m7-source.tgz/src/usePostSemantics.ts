import{useRef,useEffect}from'react';
export function usePostSemantics(liked:boolean,reposted:boolean){const ref=useRef<any>(null);useEffect(()=>{ref.current?.querySelector?.('[data-testid="sm-post-like"]')?.setAttribute('aria-pressed',String(!!liked));ref.current?.querySelector?.('[data-testid="sm-post-repost"]')?.setAttribute('aria-pressed',String(!!reposted))},[liked,reposted]);return ref}
