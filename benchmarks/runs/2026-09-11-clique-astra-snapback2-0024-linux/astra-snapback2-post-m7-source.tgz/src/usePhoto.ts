import {useEffect,useState} from 'react';
import {useSnapbackClient} from 'snapback2/react';
export function usePhoto(asset:any){const client=useSnapbackClient();const[uri,setUri]=useState<string>();useEffect(()=>{let alive=true;let blobUrl:string|undefined;setUri(undefined);if(asset)void(async()=>{try{const url=await client.assetUrl(asset);if(!url)return;const blob=await client.assetBlob(url);blobUrl=URL.createObjectURL(blob);if(alive)setUri(blobUrl);}catch{}})();return()=>{alive=false;if(blobUrl)URL.revokeObjectURL(blobUrl)}},[client,asset?.id]);return uri;}
