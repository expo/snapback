import {SyncStatus} from './SyncStatus';
import {InboxSync} from './Messaging';
import {AuthorPosts} from './Social';
import {usePhoto} from './usePhoto';
import React,{useState,useRef,useEffect} from 'react';
import {View,Text,Pressable,ScrollView,Linking} from 'react-native';
import {useAuth,useViewer,useQuery,useMutation,useAssetUrl} from 'snapback2/react';
import {api} from 'snapback2/client';
import {useRouter,usePathname,useLocalSearchParams} from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import {AuthForm,ProfileForm,FeedTabs,palette} from '../ui';
const blank={displayName:'',handle:'',bio:'',location:'',link:''};
export function Btn({children,onPress,testID}:{children:React.ReactNode,onPress:()=>void,testID?:string}){return <Pressable testID={testID} accessibilityRole="button" onPress={onPress} style={{padding:12}}><Text style={{color:palette.primary,fontSize:16}}>{children}</Text></Pressable>}
export function Gate({children}:{children:React.ReactNode}){
 const {session,actions}=useAuth();const viewer=useViewer();const [mode,setMode]=useState<'sign-in'|'sign-up'>('sign-in');const[email,setEmail]=useState('');const[password,setPassword]=useState('');const[error,setError]=useState('');const[busy,setBusy]=useState(false);
 if(session.state==='hydrating'&&!viewer)return <Text>Restoring session…</Text>;
 if(!viewer)return <AuthForm mode={mode} email={email} password={password} onChangeEmail={setEmail} onChangePassword={setPassword} onToggleMode={()=>{setMode(mode==='sign-in'?'sign-up':'sign-in');setError('')}} errorText={error} submitting={busy} onSubmit={async()=>{setBusy(true);setError('');try{await actions[mode==='sign-in'?'login':'signup']({email,password})}catch(e){setError(String(e))}finally{setBusy(false)}}}/>;
 return <Account key={viewer}>{children}</Account>;
}
function Account({children}:{children:React.ReactNode}){const me=useQuery(api.profiles.mine,{});const retained=useRef<typeof me.data>(undefined);if(me.data)retained.current=me.data;const profile=me.data||retained.current;const router=useRouter();const path=usePathname();const{tab}=useLocalSearchParams<{tab?:string}>();if(!profile&&me.status==='loading')return <Text>Loading profile…</Text>;if(!profile)return <EditProfile initial={null}/>;return <View style={{flex:1}}><InboxSync/><SyncStatus/><View style={{flexDirection:'row',borderBottomWidth:1,borderColor:palette.border,alignItems:'center'}}><Text style={{fontSize:24,fontWeight:'700',color:palette.primary,padding:12}}>Clique</Text><Btn onPress={()=>router.push('/')}>Feed</Btn><Btn onPress={()=>router.push(`/profile/${profile.handle}`)}>Profile</Btn><Btn onPress={()=>router.push('/chats')}>Chats</Btn><Btn onPress={()=>router.push('/search')}>Search</Btn><Btn onPress={()=>router.push('/settings')}>Settings</Btn></View><FeedTabs active={tab==='trending'?'trending':tab==='global'?'global':'following'} onChange={tab=>router.push('/?tab='+tab)}/>{children}</View>}
export function EditProfile({initial}:{initial:any}){
 const [values,setValues]=useState(initial?{displayName:initial.displayName,handle:initial.handle,bio:initial.bio,location:initial.location,link:initial.link||''}:blank);const[avatar,setAvatar]=useState<any>(initial?.avatar);const[preview,setPreview]=useState<string>();const[error,setError]=useState('');const router=useRouter();const create=useMutation(api.profiles.createMyProfile);const update=useMutation(api.profiles.updateMyProfile);const oldUri=usePhoto(initial?.avatar);
 return <ProfileForm mode="edit" values={values} avatarUri={preview||oldUri} onChange={p=>setValues(v=>({...v,...p}))} errorText={error} saving={create.inFlight||update.inFlight} onPressAvatar={async()=>{const r=await ImagePicker.launchImageLibraryAsync({mediaTypes:['images']});if(!r.canceled){const a=r.assets[0];setPreview(a.uri);setAvatar(a.file||{uri:a.uri,fileSize:a.fileSize,mimeType:a.mimeType})}}} onPressSave={async()=>{setError('');const r=await(initial?update:create).run({...values,link:values.link||null,avatar:avatar||null});if(r.state==='rejected')setError(r.code+": "+r.message);else if(r.state==='committed')router.replace(`/profile/${values.handle}`)}}/>;
}
export function Profile({handle}:{handle:string}){const q=useQuery(api.profiles.byHandle,{handle});if(!q.data)return <Text>Loading profile…</Text>;return <ProfileContent p={q.data}/>}
function ProfileContent({p}:{p:any}){const me=useViewer();const uri=usePhoto(p.avatar);const router=useRouter();const counts=useQuery(api.profiles.counts,{principal:p.principal});const follow=useMutation(api.follows.setFollow);return <View>{me===p.principal?<Btn testID="sm-profile-insights" onPress={()=>router.push('/insights')}>Insights</Btn>:null}<ProfileForm {...p} avatarUri={uri} link={p.link||undefined} followerCount={counts.data?.followers||0} followingCount={counts.data?.following||0} mode={me===p.principal?'view-own':'view-other'} onPressEdit={()=>router.push('/profile/edit')} following={counts.data?.followed||false} onPressFollow={()=>void follow.run({target:p.principal,following:!counts.data?.followed,mutationId:`follow-${Date.now()}-${Math.random()}`})} onPressFeed={()=>router.push('/')} onPressLink={Linking.openURL}/><AuthorPosts author={p.principal}/></View>}
export function OwnEdit(){const q=useQuery(api.profiles.mine,{});return q.data?<EditProfile initial={q.data}/>:<Text>Loading…</Text>}
export function Settings(){const{actions}=useAuth();return <Btn testID="sm-settings-logout" onPress={()=>void actions.logout()}>Log out</Btn>}
