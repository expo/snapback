import{useMemo,useEffect}from'react';import{useViewer}from'snapback2/react';import{createClient}from'snapback2/client';import{url,tokenStore,transport}from'./Backend';
export function useOnlineClient(){const viewer=useViewer();const client=useMemo(()=>createClient({url,tokenStore,fetch:transport}),[viewer]);useEffect(()=>()=>{void client.close()},[client]);return client}
