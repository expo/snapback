import{api,defineItems,mutationTarget,withHistory}from'snapback2/client';
const common={table:'messages',order:'reverse' as const,update:{target:mutationTarget(api.messages.edit,'messages')}};
const create={target:mutationTarget(api.messages.send,'messages'),belongs:(args:any,q:any)=>args.conversationId===q.conversationId,draft:(args:any)=>({key:args.key,body:args.body,conversationId:args.conversationId,quote:args.quote})};
const delivered=defineItems(api.messages.thread,{...common,select:e=>e.message,create});
export const messageItems=withHistory(defineItems(api.messages.history,{...common,create}),{items:delivered,args:({conversationId})=>({conversationId,c:null})});
