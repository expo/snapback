import {useRef} from 'react';
export function usePollSemantics(_selected:number|null|undefined,_pending:boolean,_ready:boolean){return useRef<any>(null);}
