import{useEffect}from'react';
import{useSnapbackClient}from'snapback2/react';
// Feed browser connectivity transitions to the durable carrier once per event.
// This avoids waiting for an SSE retry backoff before resuming queued writes.
export function NetworkBridge(){const client=useSnapbackClient();useEffect(()=>{if(typeof window==='undefined')return;const offline=()=>{void client.offline().catch(()=>{})};const online=()=>{void client.online().catch(()=>{})};window.addEventListener('offline',offline);window.addEventListener('online',online);if(!navigator.onLine)offline();return()=>{window.removeEventListener('offline',offline);window.removeEventListener('online',online)}},[client]);return null}
