import React from 'react';
import {AssetVideo,AssetImage} from 'snapback2/react';
const WebVideo=AssetVideo as any;
export function Media({asset,video=false,viewer=false}:{asset:any,video?:boolean,viewer?:boolean}){return video?<WebVideo asset={asset} controls style={{width:'100%',maxHeight:400}} data-testid="sm-media-viewer-video"/>:<AssetImage asset={asset} style={{width:'100%',maxHeight:500,objectFit:'contain'}} data-testid={viewer?"sm-media-viewer-image":undefined}/>}
