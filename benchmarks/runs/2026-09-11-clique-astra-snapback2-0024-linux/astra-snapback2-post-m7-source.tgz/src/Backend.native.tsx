import React from 'react';
import {SnapbackProvider} from 'snapback2/react';
import {expoSecureTokenStore} from 'snapback2/expo';
const offline={};
export const url=process.env.EXPO_PUBLIC_SNAPBACK_URL||'http://127.0.0.1:53100';
export const transport=fetch;
export const tokenStore=expoSecureTokenStore('clique-53100');
export default function Backend({children}:{children:React.ReactNode}){return <SnapbackProvider url={url} tokenStore={tokenStore} offline={offline}>{children}</SnapbackProvider>}
