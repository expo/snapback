import React from 'react';
import {AssetVideo,AssetImage} from 'snapback2/react';
export function Media({asset,video=false,viewer=false}:{asset:any,video?:boolean,viewer?:boolean}){return video?<AssetVideo asset={asset} style={{width:'100%',height:300}}/>:<AssetImage asset={asset} style={{width:'100%',height:400}}/>}
