import React, {createContext, useContext, useRef} from 'react';
import {ScrollView, View, Platform} from 'react-native';
const Context = createContext<{register:(id:string,node:any)=>void; jump:(id:string)=>void}>({register:()=>{},jump:()=>{}});
export const useScrollSurface = () => useContext(Context);
export function ScrollSurface({children}:{children:React.ReactNode}) {
  const scroll=useRef<ScrollView>(null), content=useRef<View>(null), nodes=useRef(new Map<string,any>());
  const register=(id:string,node:any)=>{if(node)nodes.current.set(id,node);else nodes.current.delete(id)};
  const jump=(id:string)=>{
    if(Platform.OS==='web'){document.getElementById(id)?.scrollIntoView({block:'center'});return;}
    const node=nodes.current.get(id);
    if(node&&content.current)node.measureLayout(content.current,(_x:number,y:number)=>scroll.current?.scrollTo({y,animated:true}),()=>{});
  };
  return <Context.Provider value={{register,jump}}>
    <ScrollView ref={scroll} contentContainerStyle={{width:'100%',maxWidth:760,alignSelf:'center',flexGrow:1,backgroundColor:'white'}}>
      <View ref={content} style={{flex:1}}>{children}</View>
    </ScrollView>
  </Context.Provider>;
}
