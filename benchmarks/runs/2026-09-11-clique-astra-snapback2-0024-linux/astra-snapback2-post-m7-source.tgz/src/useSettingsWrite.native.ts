import{useMutation}from'snapback2/react';import{api}from'snapback2/client';
export function useSettingsWrite(){return useMutation(api.groups.configure)}
