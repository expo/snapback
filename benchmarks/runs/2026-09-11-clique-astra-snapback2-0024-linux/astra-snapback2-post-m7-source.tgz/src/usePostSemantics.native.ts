import{useRef}from'react';export function usePostSemantics(liked:boolean,reposted:boolean){return useRef<any>(null)}
