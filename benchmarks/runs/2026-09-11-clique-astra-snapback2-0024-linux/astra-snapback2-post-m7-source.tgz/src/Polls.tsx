import {usePollSemantics} from './usePollSemantics';
import React,{useState} from 'react';
import {Text,View} from 'react-native';
import {useMutation,useOutbox,useQuery} from 'snapback2/react';
import {api} from 'snapback2/client';
import {PollCompose,PollDisplay} from '../ui';
import {Btn} from './Clique';
const fresh=()=>`poll-${Date.now()}-${Math.random()}`;
export function PollComposer({conversationId}:{conversationId:string}){
 const [open,setOpen]=useState(false),[question,setQuestion]=useState(''),[options,setOptions]=useState(['','']),[error,setError]=useState('');
 const create=useMutation(api.polls.create);
 return <View><Btn testID="sm-convo-poll-create" onPress={()=>setOpen(!open)}>{open?'Cancel poll':'Create a poll'}</Btn>{open?<PollCompose question={question} options={options} onChangeQuestion={setQuestion} onChangeOption={(i,t)=>setOptions(old=>old.map((v,n)=>i===n?t:v))} onAddOption={()=>setOptions(old=>[...old,''])} onRemoveOption={i=>setOptions(old=>old.filter((_,n)=>i!==n))} submitting={create.inFlight} onSubmit={async(question,options)=>{const r=await create.run({conversationId,question,options,mutationId:fresh()});if(r.state==='rejected')setError(r.code+': '+r.message);else{setOpen(false);setQuestion('');setOptions(['','']);setError('')}}}/>:null}{error?<Text testID="sm-poll-error">{error}</Text>:null}</View>
}
export function PollMessage({message,color}:{message:any,color?:string}){
 const q=useQuery(api.polls.results,{messageId:message.id});const vote=useMutation(api.polls.vote);const outbox=useOutbox();const[error,setError]=useState('');
 const pending=outbox.entries.filter(e=>(e.args as any).messageId===message.id&&(e.args as any).option!==undefined&&['queued','sending'].includes(e.state));
 const latest=pending[pending.length-1];const selected=latest?(latest.args as any).option:q.data?.mine;
 const counts=q.data?[q.data.a,q.data.b,q.data.c,q.data.d]:[0,0,0,0];
 const semanticRef=usePollSemantics(selected,!!latest,!!q.data?.options);
 if(!q.data?.options)return <Text>Loading poll…</Text>;
 return <View ref={semanticRef}><PollDisplay question={message.body||''} accentColor={color} options={q.data.options.map((label,i)=>({id:`${message.id}-option-${i}`,label,count:counts[i],mine:selected===i,pending:!!latest&&selected===i}))} onVote={async option=>{const r=await vote.run({messageId:message.id,option,mutationId:fresh()});setError(r.state==='rejected'?r.code+': '+r.message:'')}}/>{error?<Text testID="sm-poll-error">{error}</Text>:null}</View>
}
