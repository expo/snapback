import {useLayoutEffect,useRef} from 'react';
// React Native Web drops selected/busy from this kit's Pressable. Mirror the
// same render state as standard button accessibility attributes on web.
export function usePollSemantics(selected:number|null|undefined,pending:boolean,ready:boolean){
 const ref=useRef<any>(null);
 useLayoutEffect(()=>{const nodes=ref.current?.querySelectorAll?.('[data-testid="sm-poll-option"]')||[];nodes.forEach((node:HTMLElement,i:number)=>{node.setAttribute('aria-pressed',String(selected===i));node.setAttribute('aria-busy',String(pending&&selected===i));});},[selected,pending,ready]);
 return ref;
}
