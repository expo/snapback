import{NetworkBridge}from'./NetworkBridge';
import * as WebArm from 'snapback2/react';
import React from 'react';
import {SnapbackProvider} from 'snapback2/react';
import {browserTokenStore} from 'snapback2/client';
const offline={store:(WebArm as any).indexedDbRangeStore()};
export const url=process.env.EXPO_PUBLIC_SNAPBACK_URL||'http://127.0.0.1:53100';
export const tokenStore=typeof window==='undefined'?undefined:browserTokenStore(window.localStorage,'clique:'+url);
export const transport:typeof fetch=(input,init)=>fetch(input,{...init,...((typeof input==='string'?input:input instanceof URL?input.href:input.url).includes('/api/mutation')?{keepalive:true}:{})});
export default function Backend({children}:{children:React.ReactNode}){return <SnapbackProvider url={url} tokenStore={tokenStore} fetch={transport} offline={offline}><NetworkBridge/>{children}</SnapbackProvider>}
