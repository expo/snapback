export async function videoPreview(uri:string){return uri}
