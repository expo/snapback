import{useMemo,useEffect}from'react';
import{useViewer}from'snapback2/react';
import{createClient,api}from'snapback2/client';
import{url,tokenStore,transport}from'./Backend';
// Settings require connectivity. The direct arm starts the keepalive request
// without waiting behind the message outbox; message writes remain durable.
export function useSettingsWrite(){const viewer=useViewer();const client=useMemo(()=>createClient({url,tokenStore,fetch:transport}),[viewer]);useEffect(()=>()=>{void client.close()},[client]);return{run:(args:any)=>client.mutation(api.groups.configure,args)}}
