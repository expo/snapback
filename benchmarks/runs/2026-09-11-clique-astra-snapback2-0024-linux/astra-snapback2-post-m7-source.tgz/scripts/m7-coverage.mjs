import {readFileSync,writeFileSync} from 'node:fs';
import assert from 'node:assert/strict';
const root=JSON.parse(readFileSync('coverage-manifest.json'));
const m7=JSON.parse(readFileSync('m7/coverage-manifest.json'));
const required=JSON.parse(readFileSync('instrument/schema/social-messenger/assertions.json')).milestones.M7.assertions.filter(a=>a.executor==='suite-required');
for(const a of required)assert(m7.assertions[a.id],a.id);
root.scope=[...new Set([...root.scope,'M7'])];Object.assign(root.assertions,m7.assertions);root.note='Suite-required coverage. M7 is the fresh-session extension; its receipts and snapshots are under m7/. Choreography and native-artifact assertions retain separate receipts.';
writeFileSync('coverage-manifest.json',JSON.stringify(root,null,2));
