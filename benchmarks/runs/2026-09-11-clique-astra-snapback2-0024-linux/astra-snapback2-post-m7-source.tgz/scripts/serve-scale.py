from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
root = Path('artifacts/scale-web').resolve()
class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(root), **kwargs)
    def do_GET(self):
        if not Path(self.translate_path(self.path.split('?')[0])).is_file():
            self.path = '/index.html'
        super().do_GET()
ThreadingHTTPServer(('127.0.0.1', 53104), Handler).serve_forever()
