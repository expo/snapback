import {appendFileSync} from 'node:fs';
appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} ${process.argv.slice(2).join(' ')}\n`);
