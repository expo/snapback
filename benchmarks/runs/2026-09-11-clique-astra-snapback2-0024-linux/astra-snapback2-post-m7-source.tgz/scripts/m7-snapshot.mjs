import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createClient,api} from 'snapback2/client';
import assert from 'node:assert/strict';
const mode=process.argv[2]||'pre',dir=`m7/${mode}-snapshot`;
mkdirSync(dir,{recursive:true});
const manifest={mode,epoch:Date.now()/1000,api:'groups.mine + external.history, per-persona bearer token',files:[]};
async function pages(c,op,args={}){let next=null,out=[];do{const q=await c.query(op,{...args,c:next});assert(['complete','capped'].includes(q.state),JSON.stringify(q));out.push(...q.data);next=q.next;}while(next);return out;}
for(const line of readFileSync('instrument/fixtures/starter-m1.log','utf8').trim().split('\n')){
 const p=line.match(/"(?:[^"\\]|\\.)*"|\S+/g).map(t=>t.startsWith('"')?JSON.parse(t):t);if(p[2]!=='register')continue;
 const issuer=createClient({url:'http://127.0.0.1:53100'});await issuer.ready;const s=await issuer.auth.login({email:p[3],password:p[4]});await issuer.close();
 const c=createClient({url:'http://127.0.0.1:53100',token:s.token});await c.ready;
 const conversations=[];for(const g of await pages(c,api.groups.mine)){conversations.push({id:g.conversationId,conversation:g.conversation,messages:await pages(c,api.external.history,{conversationId:g.conversationId})});}
 conversations.sort((a,b)=>a.id.localeCompare(b.id));const data={persona:p[1],viewer:s.viewer,conversations};const bytes=JSON.stringify(data,null,2)+'\n';writeFileSync(`${dir}/${p[1]}.json`,bytes);manifest.files.push({persona:p[1],file:p[1]+'.json',sha256:createHash('sha256').update(bytes).digest('hex'),conversations:conversations.length,messages:conversations.reduce((n,g)=>n+g.messages.length,0)});await c.close();
}
writeFileSync(`${dir}/manifest.json`,JSON.stringify(manifest,null,2));
if(mode!=='pre'){
 const preManifest=JSON.parse(readFileSync('m7/pre-snapshot/manifest.json'));for(const f of preManifest.files)assert.equal(createHash('sha256').update(readFileSync('m7/pre-snapshot/'+f.file)).digest('hex'),f.sha256,'Pre-snapshot hash drift '+f.file);
 const results=[];for(const f of manifest.files){const before=JSON.parse(readFileSync(`m7/pre-snapshot/${f.file}`)),after=JSON.parse(readFileSync(`${dir}/${f.file}`));assert.equal(after.viewer,before.viewer);for(const g of before.conversations){const current=after.conversations.find(x=>x.id===g.id);assert(current,'Missing conversation '+g.id);for(const [key,value]of Object.entries(g.conversation))assert.deepEqual(current.conversation[key],value);for(const m of g.messages){const now=current.messages.find(x=>x.id===m.id);assert(now,'Missing message '+m.id);for(const [key,value] of Object.entries(m)){if(key==='type'){for(const [k,v]of Object.entries(value))assert.deepEqual(now.type[k],v);}else assert.deepEqual(now[key],value,`${f.persona}/${m.id}/${key}`);}}}results.push({persona:f.persona,pass:true});}
 writeFileSync(`m7/evidence/snapshot-comparison-${mode}.json`,JSON.stringify({pass:true,epoch:Date.now()/1000,results},null,2));
}
console.log(JSON.stringify(manifest));
