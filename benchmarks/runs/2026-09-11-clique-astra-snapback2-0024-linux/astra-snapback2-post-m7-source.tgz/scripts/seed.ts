import { readFileSync } from 'node:fs';
import { api, createClient } from 'snapback2/client';
const segment=process.argv[process.argv.indexOf('--segment')+1]||'m1';
if(!['m1','m2','m3'].includes(segment)) throw Error(`Segment ${segment} not implemented`);
const url=process.env.SNAPBACK_URL||'http://127.0.0.1:53100';
const clients=new Map(),principals=new Map(),posts=new Map();
const settled=async(c,ref,args)=>{const r=await c.mutation(ref,args);if(r.state!=='committed')throw Error(JSON.stringify(r));return r.data;};
const parse=line=>line.match(/"(?:[^"\\]|\\.)*"|\S+/g).map(t=>t.startsWith('"')?JSON.parse(t):t);
const file=(p)=>new File([readFileSync(`instrument/fixtures/${p}`)],p.split('/').pop(),{type:p.endsWith('.mp4')?'video/mp4':'image/png'});
for(const line of readFileSync('instrument/fixtures/starter-m1.log','utf8').trim().split('\n')){
 const [,actor,verb,...a]=parse(line);
 if(verb==='register'){
  const c=createClient({url});await c.ready;let session;
  try{session=await c.auth.login({email:a[0],password:a[1]});}catch(e){session=await c.auth.signup({email:a[0],password:a[1]});}
  clients.set(actor,c);principals.set(actor,session.viewer);
 }else if(segment==='m1'){
  const c=clients.get(actor);const q=await c.query(api.profiles.mine,{});if(q.data)continue;
  await settled(c,api.profiles.createMyProfile,{displayName:a[0],handle:a[1],bio:a[2],location:a[3],link:a[4],avatar:file(a[5])});
 }
}
if(segment==='m2')for(const line of readFileSync('instrument/fixtures/starter-m2.log','utf8').trim().split('\n')){
 const [,actor,verb,...a]=parse(line);const c=clients.get(actor);
 if(verb==='follow')await settled(c,api.follows.setFollow,{target:principals.get(a[0]),following:a[1]==='set',mutationId:a[2]});
 else if(verb==='post'){const old=await c.query(api.posts.byKey,{author:principals.get(actor),key:a[0]});posts.set(a[0],old.data||await settled(c,api.posts.createPost,{key:a[0],body:a[2],images:a[1]==='images'?a[3].split(',').map(file):null,clip:a[1]==='video'?file(a[3]):null,parent:null}));}
 else if(verb==='reply')posts.set(a[0],await settled(c,api.posts.createPost,{key:a[0],body:a[2],parent:posts.get(a[1]).id,images:null,clip:null}));
 else if(verb==='like')await settled(c,api.posts.setLike,{post:posts.get(a[0]).id,active:a[1]==='set',mutationId:a[2]});
 else if(verb==='repost')await settled(c,api.posts.setRepost,{post:posts.get(a[0]).id,active:a[1]==='set',mutationId:a[2]});
 else throw Error(`Unsupported ${verb}`);
}
if(segment==='m3'){
 const conversations=new Map(),messages=new Map();
 for(const line of readFileSync('instrument/fixtures/starter-m3.log','utf8').trim().split('\n')){
  const [,actor,verb,...a]=parse(line);const c=clients.get(actor);
  if(verb==='dm-create')conversations.set(a[0],(await settled(c,api.groups.dmCreate,{other:principals.get(a[1])})).id);
  else if(verb==='group-create')conversations.set(a[0],(await settled(c,api.groups.groupCreate,{key:a[0],title:a[2],description:a[3],members:[principals.get(a[1])]})).id);
  else if(verb==='member-add')await settled(c,api.groups.memberAdd,{conversationId:conversations.get(a[0]),principal:principals.get(a[1])});
  else if(verb==='send')messages.set(a[0],(await settled(c,api.messages.send,{key:a[0],conversationId:conversations.get(a[1]),body:a[2],quote:a[3]?messages.get(a[3].slice(6)):null})).id);
  else throw Error(`Unsupported ${verb}`);
 }
}
for(const c of clients.values())await c.close();
console.log(`Seed ${segment} installed idempotently`);
