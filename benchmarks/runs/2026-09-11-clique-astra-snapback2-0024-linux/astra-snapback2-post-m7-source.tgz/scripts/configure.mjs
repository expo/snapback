import{readFileSync,writeFileSync}from'node:fs';
const path=process.env.CLIQUE_WINDOWS_CONFIG||'config/windows.production.json';const w=JSON.parse(readFileSync(path));
writeFileSync('snapback/windows.q',`-- Generated from ${path}; never from caller timestamps.\nfn editWindowMs(): ${w.editWindowSeconds*1000}\nfn deleteWindowMs(): ${w.deleteForEveryoneWindowSeconds*1000}\nfn dayTTL(): ${w.disappearingOptions.find(x=>x.value==='24h').ttlSeconds*1000}\nfn weekTTL(): ${w.disappearingOptions.find(x=>x.value==='7d').ttlSeconds*1000}\n`);
console.log('Server windows:',w.profile);

const digestPath=process.env.CLIQUE_DIGEST_CONFIG||'config/digest.production.json';const d=JSON.parse(readFileSync(digestPath));const [h,m,sec]=d.periodAnchorUtc.split(':').map(Number);writeFileSync('snapback/digestconfig.q',`-- Generated from ${digestPath}\nfn digestPeriodMs(): ${d.periodSeconds*1000}\nfn digestAnchorMs(): ${(h*3600+m*60+sec)*1000}\n`);console.log('Server digest:',d.profile);
