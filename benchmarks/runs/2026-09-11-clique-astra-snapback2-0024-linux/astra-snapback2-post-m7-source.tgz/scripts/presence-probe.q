query presence(target: principal):
  return exists connected[target]
