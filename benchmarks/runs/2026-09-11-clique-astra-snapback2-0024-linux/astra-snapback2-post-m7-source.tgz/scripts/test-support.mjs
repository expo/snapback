import{readFileSync}from'node:fs';import{createClient,api}from'snapback2/client';export{api};
export const file=p=>new File([readFileSync('instrument/fixtures/'+p)],p,{type:p.endsWith('.mp4')?'video/mp4':'image/png'});
export const clients=[];
export async function login(actor){const line=readFileSync('instrument/fixtures/starter-m1.log','utf8').split('\n').find(l=>l.includes(` ${actor} register `));const password=JSON.parse(line.match(/".*"/)[0]);const c=createClient({url:'http://127.0.0.1:53100'});await c.ready;const session=await c.auth.login({email:`${actor}@example.com`,password});clients.push(c);return{c,viewer:session.viewer};}
export async function mutate(c,op,args){const r=await c.mutation(op,args);if(r.state!=='committed')throw Error(JSON.stringify(r));return r.data;}
export async function query(c,op,args){const q=await c.query(op,args);if(!['complete','capped'].includes(q.state))throw Error(JSON.stringify(q));return q;}
export async function pages(c,op,args={}){let cnext=null,items=[];do{const q=await query(c,op,{...args,c:cnext});items.push(...q.data);cnext=q.next;}while(cnext);return items;}
