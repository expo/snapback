import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {api,clients,login,mutate} from './test-support.mjs';
const A=await login('alice'),B=await login('bob'),C=await login('carol');const stamp=Date.now();
const group=await mutate(A.c,api.groups.groupCreate,{title:'M7 Poll '+stamp,description:'Retained two-client poll choreography',members:[B.viewer,C.viewer],key:'m7-choreo-'+stamp});
const poll=await mutate(A.c,api.polls.create,{conversationId:group.id,question:'Where should we meet?',options:['Cafe','Park'],mutationId:'m7-choreo-poll-'+stamp});
for(const c of clients)await c.close();
const adapter={schemaVersion:'social-messenger.choreography-adapter.v1',fixtures:{groupTitle:'M7 Poll '+stamp,pollOptionId:poll.id+'-option-0',pollAlternateOptionId:poll.id+'-option-1'}};
const adapterPath=`m7/evidence/choreo-adapter-${stamp}.json`;writeFileSync(adapterPath,JSON.stringify(adapter,null,2));
const env={...process.env,CHOREO_BASE_URL:'http://localhost:53101'};
for(const line of readFileSync('instrument/fixtures/starter-m1.log','utf8').trim().split('\n')){const p=line.match(/"(?:[^"\\]|\\.)*"|\S+/g).map(t=>t.startsWith('"')?JSON.parse(t):t);if(p[2]==='register')env[`CHOREO_${p[1].toUpperCase()}_PASSWORD`]=p[4];}
const suiteName=`choreo-suite-${stamp}.json`,statusPath=`m7/evidence/choreo-status-${stamp}.json`;writeFileSync('m7/evidence/'+suiteName,readFileSync('m7/evidence/m7-suite.json'));const suite=JSON.parse(readFileSync('m7/evidence/m7-suite.json'));writeFileSync(statusPath,JSON.stringify({m7:{pass:suite.pass,receipt:suiteName,...(!suite.pass?{outcomeClass:'application'}:{})}}));
const receipts=`m7/evidence/choreo-${stamp}.jsonl`;appendFileSync('m7/run-log.md',`${Date.now()/1000} M7 sole-segment choreography start with new real group/poll fixture; evidence ${receipts}; adapter ${adapterPath}\n`);
const code=await new Promise((resolve,reject)=>{const p=spawn(process.execPath,['choreography/choreography.mjs','m7','--adapter',adapterPath,'--suite-status',statusPath,'--setup-identity','setup-identity.json','--lane-run-id','astra-clique-snapback2','--receipts',receipts],{env,stdio:'inherit'});p.on('error',reject);p.on('close',resolve)});
writeFileSync('m7/evidence/choreo-result.json',JSON.stringify({pass:code===0,exitCode:code,receipts,adapter:adapterPath,epoch:Date.now()/1000},null,2));appendFileSync('m7/run-log.md',`${Date.now()/1000} M7 choreography finished exit=${code}; evidence ${receipts}\n`);process.exitCode=code;
