import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,appendFileSync,copyFileSync,existsSync} from 'node:fs';
import {spawn} from 'node:child_process';
import {chromium} from '../choreography/node_modules/playwright/index.mjs';
import {api,clients,login,mutate,query,pages,file} from './test-support.mjs';
const coverage={'m7-a01':'poll-shape-boundaries-group-authority-and-ui-create','m7-a03':'single-vote-replacement','m7-a04':'duplicate-and-stale-retry-preserve-state','m7-a06':'snapshot-baseline-backfill-and-tombstone-expiry-counts','m7-a07':'text-media-poll-forward-counts-and-settings-ui','m7-a09':'unchanged-previously-green-m1-m2-m3-m4-m5-m6-m8-suites'};
const stamp=Date.now(),dir=`m7/evidence/acceptance-${stamp}`;mkdirSync(dir,{recursive:true});
const log=text=>appendFileSync('m7/run-log.md',`${Date.now()/1000} ${text}\n`);
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function child(args,name){const out=await import('node:fs').then(fs=>fs.openSync(`${dir}/${name}.txt`,'w'));const start=Date.now()/1000;log(`suite ${name} start; evidence ${dir}/${name}.txt`);const code=await new Promise((resolve,reject)=>{const p=spawn(process.execPath,args,{stdio:['ignore',out,out]});p.on('error',reject);p.on('close',resolve)});const result={pass:code===0,exitCode:code,start,end:Date.now()/1000,evidence:`${dir}/${name}.txt`};log(`suite ${name} end pass=${result.pass}; ${result.pass?'event':'correction ambiguous: regression failure, preserved pending diagnosis'}; evidence ${result.evidence}`);return result;}
let browser;const checks=[],regressions={};
try{
 const A=await login('alice'),B=await login('bob'),C=await login('carol'),H=await login('henry');
 const info=async id=>(await query(A.c,api.groups.info,{conversationId:id})).data.conversation;
 const count=async id=>(await info(id)).visibleMessageCount;
 const baseline=JSON.parse(readFileSync('m7/pre-snapshot/alice.json'));
 for(const g of baseline.conversations){const history=await pages(A.c,api.external.history,{conversationId:g.id});assert.equal(await count(g.id),history.filter(m=>!m.tombstone).length);}
 assert(JSON.parse(readFileSync('m7/evidence/snapshot-comparison-migrated.json')).pass);checks.push('starter-backfill-migration-snapshot');
 const g=await mutate(A.c,api.groups.groupCreate,{title:'Poll acceptance '+stamp,description:'M7',members:[B.viewer,C.viewer],key:'m7-suite-'+stamp});assert.equal(await count(g.id),0);
 const dm=await mutate(A.c,api.groups.dmCreate,{other:B.viewer});
 const create=(extra={})=>({conversationId:g.id,question:'Lunch?',options:['Noodles','Soup'],mutationId:'m7-'+stamp+'-'+Math.random(),...extra});
 for(const extra of [{question:'q'.repeat(201)},{options:['Only']},{options:['1','2','3','4','5']},{options:['a'.repeat(51),'B']},{options:['','B']},{question:''},{conversationId:dm.id}])assert.equal((await A.c.mutation(api.polls.create,create(extra))).state,'rejected',JSON.stringify(extra));
 assert.equal((await H.c.mutation(api.polls.create,create())).state,'rejected');
 const p=await mutate(A.c,api.polls.create,create());assert.equal(await count(g.id),1);
 const maxArgs=create({question:'q'.repeat(200),options:['a'.repeat(50),'b','c','d']});const max=await mutate(A.c,api.polls.create,maxArgs);assert.deepEqual(await mutate(A.c,api.polls.create,maxArgs),max);assert.equal(await count(g.id),2);
 const results=async c=>(await query(c,api.polls.results,{messageId:p.id})).data;
 assert.equal((await H.c.query(api.polls.results,{messageId:p.id})).state,'denied');
 const vote=(option,key)=>({messageId:p.id,option,mutationId:'m7-vote-'+stamp+'-'+key});
 assert.equal((await B.c.mutation(api.polls.vote,vote(2,'bad'))).state,'rejected');
 await mutate(A.c,api.polls.vote,vote(0,'a'));await mutate(B.c,api.polls.vote,vote(0,'b'));
 assert.deepEqual([(await results(C.c)).a,(await results(C.c)).b],[2,0]);
 await mutate(A.c,api.polls.vote,vote(1,'switch'));assert.deepEqual([(await results(B.c)).a,(await results(B.c)).b],[1,1]);
 await mutate(A.c,api.polls.vote,vote(1,'switch'));await mutate(A.c,api.polls.vote,vote(0,'a'));assert.deepEqual([(await results(A.c)).a,(await results(A.c)).b,(await results(A.c)).mine],[1,1,1]);checks.push('poll-validation-votes-idempotency-authority');
 const text=await mutate(A.c,api.messages.send,{conversationId:g.id,body:'Counted text',key:'m7-text-'+stamp,quote:null});assert.equal(await count(g.id),3);
 const image=await mutate(A.c,api.messages.sendMedia,{conversationId:g.id,caption:'Counted image',photo:file('media/img-01.png'),clip:null,once:false,key:'m7-image-'+stamp});assert.equal(await count(g.id),4);
 await mutate(A.c,api.messages.unsend,{messageId:text.id});assert.equal(await count(g.id),3);await mutate(A.c,api.messages.unsend,{messageId:text.id});assert.equal(await count(g.id),3);
 await mutate(A.c,api.messages.unsend,{messageId:max.id});assert.equal(await count(g.id),2);assert.equal((await B.c.mutation(api.polls.vote,{messageId:max.id,option:0,mutationId:'deleted-'+stamp})).state,'rejected');assert.equal((await query(A.c,api.messages.byKey,{author:A.viewer,key:maxArgs.mutationId})).data.pollOptions,null);checks.push('text-media-poll-counts-tombstones');
 const exp=await mutate(A.c,api.groups.groupCreate,{title:'Expiry poll '+stamp,description:'M7 expiry',members:[B.viewer],key:'m7-expiry-'+stamp});
 await mutate(A.c,api.groups.configure,{conversationId:exp.id,title:'Expiry poll '+stamp,description:'M7 expiry',color:null,background:null,disappearing:'24h'});
 const expPoll=await mutate(A.c,api.polls.create,{conversationId:exp.id,question:'Expires',options:['A','B'],mutationId:'m7-exp-'+stamp});
 await mutate(A.c,api.messages.send,{conversationId:exp.id,body:'Expires too',quote:null,key:'m7-exp-text-'+stamp});assert.equal(await count(exp.id),2);
 await mutate(B.c,api.polls.vote,{messageId:expPoll.id,option:0,mutationId:'m7-exp-vote-'+stamp});
 const expiresAt=(await query(A.c,api.messages.byKey,{author:A.viewer,key:'m7-exp-'+stamp})).data.expiresAt;
 browser=await chromium.launch();const page=await browser.newPage();page.setDefaultTimeout(20000);await page.goto('http://localhost:53101');await page.getByTestId('sm-auth-email').fill('alice@example.com');await page.getByTestId('sm-auth-password').fill(JSON.parse(readFileSync('instrument/fixtures/starter-m1.log','utf8').split('\n')[0].match(/".*"/)[0]));await page.getByTestId('sm-auth-submit').click();await page.getByTestId('sm-feed-tab-following').waitFor();await page.goto('http://localhost:53101/chat/'+g.id);await page.getByTestId('sm-convo-poll-create').click();await page.getByTestId('sm-poll-compose-question').fill('UI poll '+stamp);await page.getByTestId('sm-poll-compose-option').nth(0).fill('Tea');await page.getByTestId('sm-poll-compose-option').nth(1).fill('Coffee');await page.getByTestId('sm-poll-compose-submit').click();await page.getByTestId('sm-convo-bubble').filter({hasText:'UI poll '+stamp}).waitFor();assert.equal(await count(g.id),3);const uiPoll=page.getByTestId('sm-convo-bubble').filter({hasText:'UI poll '+stamp});await uiPoll.getByTestId('sm-poll-option').nth(1).click();await page.waitForFunction(()=>[...document.querySelectorAll('[data-testid=sm-poll-option]')].some(e=>e.getAttribute('aria-pressed')==='true'));await page.getByTestId('sm-convo-settings').click();assert.equal(await page.getByTestId('sm-chatsettings-message-count').innerText(),'Messages: 3');await page.screenshot({path:`${dir}/settings-count.png`});await browser.close();browser=null;checks.push('poll-ui-create-settings-count');
 for(const c of clients)await c.close();
 for(const m of ['m1','m2','m3','m4','m5','m6','m8']){
  const attempts=[];let result;
  do{result=await child(['scripts/acceptance.mjs','--milestone',m],attempts.length?`${m}-attempt-${attempts.length+1}`:m);attempts.push(result);}while(!result.pass&&attempts.length<3&&/Timeout|timed out/i.test(readFileSync(result.evidence,'utf8')));
  regressions[m]={...result,attempts};if(result.pass&&existsSync(`evidence/${m}-suite.json`))copyFileSync(`evidence/${m}-suite.json`,`${dir}/${m}-suite.json`);
 }
 const fresh=await login('alice');const remaining=expiresAt-Date.now()+1000;if(remaining>0){log(`expiry observation awaits server deadline ${expiresAt}; evidence ${dir}`);await wait(remaining);}
 let expCount;for(let n=0;n<25;n++){expCount=(await query(fresh.c,api.groups.info,{conversationId:exp.id})).data.conversation.visibleMessageCount;if(expCount===0)break;await wait(200)}assert.equal(expCount,0,'Expired text and poll excluded');assert.equal((await query(fresh.c,api.messages.history,{conversationId:exp.id,c:null})).data.length,0);assert.equal((await fresh.c.mutation(api.polls.vote,{messageId:expPoll.id,option:0,mutationId:'expired-'+stamp})).state,'rejected');checks.push('real-server-timer-expiry-count');
 for(const a of JSON.parse(readFileSync('instrument/schema/social-messenger/assertions.json')).milestones.M7.assertions.filter(a=>a.executor==='suite-required'))assert(coverage[a.id],a.id);
 assert(Object.values(regressions).every(r=>r.pass),'Previously green suite regression; see '+dir);
 const receipt={pass:true,milestone:'m7',checks,coverage,regressions,epoch:Date.now()/1000,directory:dir,snapshotComparison:'m7/evidence/snapshot-comparison-migrated.json'};
 writeFileSync(`${dir}/suite.json`,JSON.stringify(receipt,null,2));writeFileSync('m7/evidence/m7-suite.json',JSON.stringify(receipt,null,2));writeFileSync('m7/evidence/suite-status.json',JSON.stringify({m7:{pass:true,receipt:'m7-suite.json'}}));writeFileSync('m7/coverage-manifest.json',JSON.stringify({scope:['M7'],validated:true,assertions:Object.fromEntries(Object.entries(coverage).map(([id,test])=>[id,{file:'scripts/acceptance-m7.mjs',test,receipt:'m7/evidence/m7-suite.json'}]))},null,2));log(`M7 suite passed; evidence ${dir}/suite.json`);console.log('M7 suite passed',receipt);
}catch(e){const receipt={pass:false,error:e.stack,checks,regressions,epoch:Date.now()/1000};writeFileSync(`${dir}/suite.json`,JSON.stringify(receipt,null,2));writeFileSync('m7/evidence/m7-suite.json',JSON.stringify(receipt,null,2));writeFileSync('m7/evidence/suite-status.json',JSON.stringify({m7:{pass:false,receipt:'m7-suite.json',outcomeClass:'application'}}));log(`M7 suite correction ambiguous: ${e.message}; evidence ${dir}/suite.json`);console.error(e);process.exitCode=1;}finally{if(browser)await browser.close();for(const c of clients)await c.close();}
