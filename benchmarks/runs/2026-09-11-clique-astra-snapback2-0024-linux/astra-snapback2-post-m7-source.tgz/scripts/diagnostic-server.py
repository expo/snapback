from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
class Handler(BaseHTTPRequestHandler):
 def do_POST(self):
  b=self.rfile.read(int(self.headers.get('Content-Length','0')))
  with open('evidence/client-telemetry.jsonl','ab') as f:f.write(b+b'\n')
  self.send_response(204);self.send_header('Access-Control-Allow-Origin','*');self.end_headers()
 def log_message(self,*args):pass
ThreadingHTTPServer(('127.0.0.1',53105),Handler).serve_forever()
