import{writeFileSync}from'node:fs';import{api,clients,login,mutate,query}from'./test-support.mjs';
const A=await login('alice'),B=await login('bob'),C=await login('carol');
const g=await mutate(A.c,api.groups.groupCreate,{title:'M7 Polls',description:'Group polls with one changeable vote per person.',members:[B.viewer,C.viewer],key:'m7-final-demo-group'});
const p=await mutate(A.c,api.polls.create,{conversationId:g.id,question:'Where should we meet?',options:['Cafe','Park','Library'],mutationId:'m7-final-demo-poll'});
const count=(await query(A.c,api.groups.info,{conversationId:g.id})).data.conversation.visibleMessageCount;
writeFileSync('m7/evidence/final-demo.json',JSON.stringify({conversationId:g.id,pollId:p.id,count,route:'/chat/'+g.id},null,2));
for(const c of clients)await c.close();
