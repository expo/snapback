import json,os,signal,time,pathlib,subprocess
root=pathlib.Path.cwd().resolve();events=[]
for project in ['.','replays/scale','replays/scale-m8']:
 owner=root/project/'.snapback/owner.json'
 if not owner.exists():continue
 data=json.load(open(owner));pid=data.get('pid')
 if not pid:continue
 try:cwd=pathlib.Path(f'/proc/{pid}/cwd').resolve(strict=True)
 except FileNotFoundError:continue
 if cwd!=root and root not in cwd.parents:raise RuntimeError(f'Unowned cwd for recorded {pid}')
 events.append({'pid':pid,'project':project,'epoch':time.time(),'action':'documented exact-project owner stop'})
 r=subprocess.run(['node_modules/snapback2-linux-x64/bin/snapback2','dev','--project',project,'--stop','--json'],capture_output=True,text=True,timeout=30)
 events[-1]['result']=r.stdout.strip();events[-1]['returncode']=r.returncode
for pid in [2692144,2691910,1482436,1938993]:
 try:cwd=pathlib.Path(f'/proc/{pid}/cwd').resolve(strict=True)
 except FileNotFoundError:continue
 if cwd!=root and root not in cwd.parents:raise RuntimeError(f'Unowned cwd for recorded {pid}')
 try:os.kill(pid,signal.SIGTERM);action='SIGTERM exact recorded Expo/static server PID'
 except ProcessLookupError:action='Already exited after parent/server shutdown'
 events.append({'pid':pid,'epoch':time.time(),'action':action})
pathlib.Path('evidence/shutdown.json').write_text(json.dumps(events,indent=2))
print(json.dumps(events,indent=2))
