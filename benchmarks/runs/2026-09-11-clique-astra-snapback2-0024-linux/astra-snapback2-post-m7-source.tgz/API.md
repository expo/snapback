# Clique custom-client API

Install `snapback2@0.0.24`. The public SDK is the supported native protocol client;
no operator secret or development persona is needed. Backend URL for this run:
`http://127.0.0.1:53100`. Production deployments should use HTTPS.

```js
import {createClient, api} from 'snapback2/client';
const client = createClient({url: 'http://127.0.0.1:53100', token: accessToken});
await client.ready;
const identity = await client.auth.me(); // {viewer, kind, authEpoch}
```

For password issuance, omit `token` and call
`client.auth.login({email,password})` or `signup({email,password})`.
The result includes an opaque bearer `token` and its bound `viewer`. A token
acts only as that user: membership rules apply to every conversation read and
write. Keep it secret. `client.auth.logout()` revokes that session, including
other clients using the same bearer. Separately issued sessions remain separate.
Sessions expire server-side; on `E_AUTH_SESSION`/`E_AUTH_REQUIRED`, authenticate
again. There is no application refresh-token endpoint. The published session
response does not expose an expiry timestamp or document an exact session TTL;
clients must handle refusal rather than infer a lifetime from the 30-day offline
ID grant. That documentation gap is recorded rather than inventing a TTL.

Query results are `{state,data,next,...}`. Accept `complete` or `capped`; pass
opaque `next` unchanged to continue. A refused query can have `state:'denied'` or `state:'refused'`, with refusal
details. Treat either as unavailable; poll membership denials return `denied`. Mutation results are `committed`, `rejected`, or (with an offline
store configured) `queued`. Only committed is authoritative success. This
headless example uses no offline store.

List conversations, including empty ones:

```js
const page = await client.query(api.groups.mine, {c:null});
// each row: {id,conversationId,role,conversation:{id,title,kind,...},members:[...]}
// Continue with {c:page.next} until next is null.
```

To fetch the latest message of a named conversation, page `groups.mine` until
`row.conversation.title === name`, retain its `conversationId`, then:

```js
const page = await client.query(api.external.history, {conversationId, c:null});
const latest = page.data[0] ?? null;
const older = page.next && await client.query(api.external.history,
  {conversationId, c:page.next});
```

History is newest first by server timestamp and stable ID. This enriched API
uses one message per page to stay inside the certified closure bound with a
50-member receipt/reaction projection. The app's simpler history has 50-row
pages. Equal names are allowed; use the opaque conversation ID thereafter.

Every enriched history message contains:

| Field | Meaning |
|---|---|
| `id`, `conversationId` | Opaque message and conversation IDs |
| `senderId`, `timestamp` | User principal and server Unix milliseconds |
| `type` | Flags `text`, `image`, `video`, `viewOnce`; media flags identify the variant |
| `text` | Text body or media caption; null after unsend |
| `media` | `{photo,clip,oncePhoto}` authenticated asset references or nulls |
| `edited`, `tombstone` | Boolean edit and unsend flags |
| `replyTo` | Quoted message ID or null |
| `reactions` | `{emoji,count,mine}` summary rows (up to 50 distinct emoji) |
| `receipt` | `{recipient,received,seen,active}` for original recipients |

For your own message, aggregate the authoritative receipt vector: consider
only active recipients; all seen means `read`, otherwise all received means
`delivered`, otherwise `sent`. An empty active audience is read. New members
never enter an old message's original audience. The vector also lets custom
clients show per-recipient details. Expired messages disappear; unsent messages
retain their tombstone. Once-only bytes require an explicit viewing action and
must never be persisted. Ordinary assets can be read through
`await client.assetBlob(await client.assetUrl(reference))`.

Send text with a fresh stable key per logical action (reuse exactly on retry):

```js
const result = await client.mutation(api.messages.send, {
  conversationId, body:'Hello', quote:null, key:crypto.randomUUID()
});
if (result.state !== 'committed') throw Error(result.code ?? result.state);
console.log(result.data.id);
```

New-message delivery for this custom API is **polling**: query the latest page
of `external.history` every second while online, compare message IDs, and page
back until your previous ID to catch bursts. Re-read visible pages for edits,
reactions and tombstones. Alternatively the SDK's `observe` on the same query
provides a live subscription; close its subscription when unused. Polling
history requires current membership and is not a delivery acknowledgement.
After accepting a message call `api.messages.mark` with
`{messageId,seen:false}`; when actually opened use `seen:true`.

Run the standalone demo against a seeded instance:

```sh
API_EMAIL=alice@example.com API_PASSWORD='your-password' node scripts/custom-client-demo.mjs
# or API_TOKEN=... API_CHAT_ID=... node scripts/custom-client-demo.mjs
```

Optional variables: `SNAPBACK_URL`, `API_CHAT_ID`, `API_CHAT_TITLE`. The demo
covers token/password authentication, conversation pagination, history
continuation, send, polling, field presence, and revocation of the session it
issued itself. It leaves a caller-supplied token valid. It uses no fixtures or
operator API and closes its client on completion.

M7 adds `conversation.visibleMessageCount` to `groups.mine` and `groups.info`.
It counts messages excluding tombstones; expiry removes a message and refreshes
its conversation count in the same server timer transaction. Polls count once.
`external.history` adds `type.poll` and `pollOptions` (ordered labels). Ordinary
text messages keep their existing flags. Poll options are cleared on unsend.

Create a group poll with `api.polls.create`:
`{conversationId, question, options, mutationId}`. The server requires a
non-empty question of at most 200 characters and 2–4 non-empty option labels
of at most 50 characters. DMs and non-members are refused. Reuse the same
`mutationId` when retrying creation.

Call `api.polls.vote` with `{messageId, option, mutationId}`. `option` is the
zero-based creation-order index. Each user has one vote; a later distinct intent
replaces it. A duplicate or older retried mutation ID is a no-op. Observe
`api.polls.results` with `{messageId}` for live `{options, mine, a, b, c, d}`;
`mine` is the caller's index or null and the four counters follow option order.
Stable UI option identity is `${messageId}-option-${index}`. The SDK durable
outbox queues vote intents offline and replays them in arrival order on reconnect.
