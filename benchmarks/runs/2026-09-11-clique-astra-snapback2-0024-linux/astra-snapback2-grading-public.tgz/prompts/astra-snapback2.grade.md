You are the **grader** for one social-messenger lane, a fresh session from a different model family than the lane's builder. Follow the frozen grader prompt at `/home/ccheever/clique-ri-20260911/instrument/grader/grader-prompt.md` exactly; this wrapper only supplies the lane's inputs and records this run's deviations from the frozen protocol. Work only inside `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2`; write everything you produce under `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2/grading/`.

## Inputs

- The frozen checklist as atomic assertions: `/home/ccheever/clique-ri-20260911/instrument/schema/social-messenger/assertions.json`; the dimension applicability manifest: `/home/ccheever/clique-ri-20260911/instrument/schema/social-messenger/applicability.json`; the report schema: `/home/ccheever/clique-ri-20260911/instrument/grader/grader-report.schema.json`; the brief: `/home/ccheever/clique-ri-20260911/instrument/social-messenger.md`; the fixture pack (personas, passwords, media, shortened-windows and digest configs, starter logs): `/home/ccheever/clique-ri-20260911/instrument/fixtures/`.
- The built app with source: `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2` (backend `snapback2-0.0.24`, built on the public npm package snapback2@0.0.24). Run instructions: the lane's `API.md` and `README.md` if present, `package.json` scripts, and the documented acceptance entrypoint (`npm run acceptance -- --milestone mN`). The lane's coverage manifest and harness receipts are under `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2` (`coverage*.json`, `receipts/`, `evidence/`, `artifacts/`); the choreography receipts and any simulator artifacts are the only basis for O4.
- The lane's run record, if it wrote one: `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2/run-record.json` (may be absent; then grade from receipts and say so).

## What you must not read

The builder's `diary.md`, `essay.md`, `final-report.md`, `FINAL.md`, `run-log.md`, and any other lane under `/home/ccheever/clique-ri-20260911/lanes/`. If any of them reaches you, stop and record a contaminated grading session.

## Environment

Run-specific host override: the frozen `instrument/ENVIRONMENT.md` still records the prior Mac host; only for host/tool/port facts, this wrapper supersedes that file. Ubuntu Linux x86_64 on AMD EPYC 9454; Node 24.13.1 first on PATH; Playwright 1.62.1 with Chromium 151 in the shared cache (if you need the harness, copy both `/home/ccheever/clique-ri-20260911/instrument/choreography` and its imported sibling `/home/ccheever/clique-ri-20260911/instrument/metering` under the lane while preserving their sibling layout; install only in the choreography copy and never write into `/home/ccheever/clique-ri-20260911/instrument/`; frozen fixtures are exposed at `/home/ccheever/clique-ri-20260911/fixtures/social-messenger` and the required schema helper at `/home/ccheever/clique-ri-20260911/lanes/lib/json-schema.mjs`). Start the lane's backend and web client yourself from its documented instructions, on ports **53100–53119** only; record every PID you start and kill only those PIDs at the end. Never pkill/killall. Native Apple simulator proof is unavailable on this host and must be graded `not-run`/unavailable; never accept web export as native proof. Ports outside the assigned range are reserved.

## Deviations you must record (this run is N=1 calibration, not a claim-eligible wave)

1. **No holdout probe set was committed for this wave.** Skip execution-order phase 4; in the report set `wave.probeSetSha256` to the string `none-uncommitted` and leave `probeResults` empty with a `note` explaining it. Do not invent probes.
2. **Your family has not passed the grader calibration gate** (`calibration.md`); set `grader.calibrationPassed` to `false`, `grader.sameFamilyGraded` to `false`, and grade anyway — the record labels the grade `uncalibrated-grader`.
3. Timing-sensitive checks are judged best-of-3 as the prompt says; record the machine load (`uptime`) beside each timing record because other sessions share this machine.

## Output (and nothing else)

1. `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2/grading/grader-report.json` conforming to the schema above: `reportVersion`, `lane` (`backend`, `runRecordPath`, `runScope` = `full`), `wave` (`id` = `astra`, `probeSetSha256`), `grader` (`family` = `claude`, `model` = `claude-opus-5`, `sameFamilyGraded`, `calibrationPassed`, `sessionOutcome`), `assertionResults` keyed by assertion id, `coverageSpotVerification` (`verdict`, `sampledAssertionIds`), `defects` (severity-bucketed with evidence pointers), `probeResults` (empty, with the note), `oDimensionScores` (`O1`…`O5`, each with the anchor text cited, `null` where `applicability.json` says not applicable).
2. `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2/grading/trace.md`: the sanitized evidence and action trace — what you ran, what you observed — with credentials and any personal or incidental data redacted. Raw transcripts are never published.

Validate the report against the schema before you finish (a small Node script with the AJV that the choreography copy installs is fine). Finish by writing `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2/grading/DONE` containing `end=<epoch>`.
