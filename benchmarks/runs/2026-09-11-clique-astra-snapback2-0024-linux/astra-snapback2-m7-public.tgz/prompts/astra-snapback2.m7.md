You are a senior product engineer picking up an existing production-shaped app you did not write, alone and timed. Work fully autonomously; there is no human to ask. Work only in the lane directory supplied as your current directory: /home/ccheever/clique-ri-20260911/lanes/astra-snapback2

This is the brief's **M7 — Day-2 evolution**: a fresh session with no builder context. Do not inspect other lanes under /home/ccheever/clique-ri-20260911/lanes/, any Snapback source checkout, or any prior Clique implementation, diary, essay, or benchmark run. You may and must read this lane's own code, `API.md`, `README.md` if present, its acceptance suites, and its `run-log.md`/`final-report.md` for facts about the artifact you inherit; you may not read `diary.md` or `essay.md`.

The authoritative instrument is `./instrument/` (also at /home/ccheever/clique-ri-20260911/instrument/): read `ENVIRONMENT.md`, then `social-messenger.md` §M7 and its global rulings, `CONTRACT.md`, `schema/social-messenger/assertions.json` (the M7 assertions), the fixtures README, and the choreography README (M7 runs only as the sole selected segment: `choreography.mjs m7`).

Run-specific host override: the frozen `instrument/ENVIRONMENT.md` still records the prior Mac host; only for host/tool/port facts, this wrapper supersedes that file. This session runs on Ubuntu Linux x86_64 on AMD EPYC 9454 with Node 24.13.1 and Playwright 1.62.1/Chromium 151 available.

The inherited app runs on **Snapback 2**, the public npm package `snapback2@0.0.24` (exact pin; use its README, the guide it serves via `npx snapback2 guide`, and its generated types; never a Snapback source checkout). Backend changes are Quarry (`snapback/*.q`) and go through `snapback2 check`; the migration is a schema successor applied by `snapback2 dev` — read the guide's successor/migration page before changing the schema. If the package cannot express something, record it as a platform gap with the exact diagnostic and continue.

Data environment: **the pre-replay starter state.** Start a fresh backend instance seeded with the three starter segments (`starter-m1.log`, `starter-m2.log`, `starter-m3.log`) through the app's own seed path; do not reuse the scale replay's database. Before changing anything, export the **pre-M7 snapshot** through the app's custom-client API over the M6 field manifest, using each persona's token, to `m7/pre-snapshot/` (one file per persona plus a manifest with hashes). The grader compares the post-M7 state against it.

Spec (both parts; the second forces a real migration):
1. **Group polls** — a new message type: question ≤200 chars, 2–4 options ≤50 chars each; one vote per user, changeable, expressed as an idempotent set-state intent carrying a client mutation id; live tallies visible to all members; votes queue offline like reactions.
2. **A backfilled field** — every conversation gains a message count shown in chat settings, backfilled over all existing conversations and maintained forward; it counts currently visible messages only (excludes tombstoned and expired), and polls count as messages. Existing data must survive the schema change intact. Record in `run-log.md` whether the pre-M7 schema already carried a count structure.

Acceptance (all five; ship `npm run acceptance -- --milestone m7`, a coverage manifest for its suite-required assertions, and run the `m7` choreography segment):
1. Create a poll in a group; members vote; tallies update live; changing a vote adjusts counts; a duplicate or retried vote intent does not flip state.
2. An offline vote queues and settles on reconnect.
3. Message counts are correct for pre-existing conversations (backfill) and increment with new messages.
4. Pre-existing messages, media, receipts, and reactions are intact after the migration, compared against `m7/pre-snapshot/`.
5. The acceptance suites of previously green milestones still pass; prior failures are preserved, not repaired under M7's budget.

Use only ports **53100–53119**; record every server PID; kill only those PIDs at the end; never pkill/killall/pattern kills. Safety limit: four hours of wall clock. Two consecutive capability failures end the session.

Create `m7/run-log.md` immediately (first lines: `lane id astra-clique-snapback2`, `model gpt-6-astra`, `effort=medium`, `backend=snapback2-0.0.24`, `phase=m7`, `start=<epoch>`), then append timestamped lines for every milestone event, error, retry, workaround, knowledge lookup with its source, and correction loop with attribution (snapback2-defect, agent-error, environment, or ambiguous) plus an evidence pointer. Write `m7/diary.md` at the end (what you built, what felt easy, what fought you, what a migration on this backend is like compared to the alternatives you know), then `m7/essay-paragraphs.md` (the closing-essay paragraphs for this phase, before tallying numbers), then `m7/final-report.md` with raw start/end epochs, wall, status (`green`, `capability-failure`, `aborted`), suite and choreography results, the snapshot comparison result, the previously green suites' results, correction loops with attribution, and a candid gap list. End with `end=<epoch>`.
