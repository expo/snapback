query probe():
  return conversations first 10 by byId { id, title, visibleMessageCount }
