M7 uses the public `snapback2@0.0.24` successor path. The inherited
`messageCounts` maintain already counted all physical message rows. It remains
unchanged. New `visibleCounts` groups by conversation and tombstone state;
`conversations.visibleMessageCount` is a required integer exposed in settings.

For an existing pre-M7 database, keep the owner running on port 53100 and:

1. Back up the stopped store and export per-persona history with
   `node scripts/m7-snapshot.mjs pre` before applying M7 source changes.
2. Temporarily declare `visibleMessageCount: int ?` in `snapback/schema.q`.
   Run `npx snapback2 check`, then inspect `npx snapback2 dev --status --json`.
   Require the successor to be ready before continuing.
3. Run `npx snapback2 run counts.backfill --as system --plan --json`, then
   `npx snapback2 run counts.backfill --as system --wait --json`.
4. Restore the required declaration `visibleMessageCount: int`, run
   `npx snapback2 check`, and verify the installed successor. The narrowing
   report must show zero null and affected rows.
5. Run `node scripts/m7-snapshot.mjs migrated`. Its comparison checks every
   original conversation field and every original M6 message field, allowing
   additive fields only.

The actual run receipts are under `m7/evidence/successor-*.json` and
`backfill-2.json`. The job visited both starter conversations. No table was
replaced, no destructive migration was accepted, and no SQL edits were used.
New conversations start at zero. Text, media, and poll sends, unsend, and the
existing message-expiry timer refresh the field in the same transaction.
The owner rebuilds both added maintains during successor installation.

Acceptance uses a working copy of the migrated starter store, saved while the
owner was stopped. This prevents prior-suite writes and automatic browser
receipt acknowledgements from changing the final starter snapshot subjects.
The tested copy is retained separately; the final `.snapback` is the migrated
starter instance, checked again through each persona's bearer-token API.
