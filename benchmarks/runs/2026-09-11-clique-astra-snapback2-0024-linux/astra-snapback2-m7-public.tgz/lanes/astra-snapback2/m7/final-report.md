M7 — Day-2 evolution: **green**

Lane `astra-clique-snapback2`; model `gpt-6-astra`; effort `medium`; backend `snapback2@0.0.24`.

Raw start epoch: `1789182173`. Raw end epoch: `1789183827`. Wall: **1654 seconds**. No capability-failure milestone or consecutive-failure stop occurred.

Shipped group poll composition, server validation, one changeable vote per user, mutation-ID deduplication, live tallies, durable offline votes, and a required visible-message count in chat settings. Text, media and polls increment it; unsend and expiry update it in the same transaction.

`npm run acceptance -- --milestone m7` **passed**. [Final suite](evidence/m7-suite.json), [command output](evidence/acceptance-bounded-retries.txt), [M7 coverage](coverage-manifest.json), [combined coverage](../coverage-manifest.json). The original M1–M6/M8 suite implementations were not repaired. The runner permits at most three unchanged invocations for timeout failures, under the brief's timing rule, and retains every attempt.

| Previously green suite | Result | Final-run attempts | Evidence |
|---|---|---:|---|
| M1 | pass | 1 | [m1 evidence](evidence/acceptance-1789183390032/m1.txt) |
| M2 | pass | 2 | [m2 evidence](evidence/acceptance-1789183390032/m2-attempt-2.txt) |
| M3 | pass | 1 | [m3 evidence](evidence/acceptance-1789183390032/m3.txt) |
| M4 | pass | 1 | [m4 evidence](evidence/acceptance-1789183390032/m4.txt) |
| M5 | pass | 1 | [m5 evidence](evidence/acceptance-1789183390032/m5.txt) |
| M6 | pass | 1 | [m6 evidence](evidence/acceptance-1789183390032/m6.txt) |
| M8 | pass | 1 | [m8 evidence](evidence/acceptance-1789183390032/m8.txt) |

`node scripts/choreo.mjs m7` invoked the unmodified `choreography.mjs m7` as the sole selected segment and **passed**. Live tallies, retained vote replacement, offline pending, and exactly-once reconnect settlement passed. [Final output](evidence/choreography-final.txt), [receipts](evidence/choreo-1789183577070.jsonl), [result](evidence/choreo-result.json). The final choreography has immutable, hash-linked suite inputs beside its receipt. Earlier misses and intermediate greens remain retained.

The pre-M7 schema **already carried** `maintain messageCounts: count messages by conversationId`; it included tombstones and was not exposed as a conversation field. M7 added `visibleCounts` and `conversations.visibleMessageCount`. The nullable successor was installed, the bounded job backfilled both starter conversations, and a required-column successor proved zero null/affected rows. [Migration procedure](MIGRATION.md), [additive successor](evidence/successor-additive-2.json), [job](evidence/backfill-2.json), [required successor](evidence/successor-required.json).

Snapshot comparison: **pass for all eight personas**, both immediately after migration and on the final restored instance. The original two conversations and fifteen distinct starter messages retain every pre-existing M6-manifest field, including receipts, reply references, tombstone/edit flags and null media/reaction state. All pre-snapshot SHA-256 values revalidated. [Pre-snapshot manifest](pre-snapshot/manifest.json), [immediate comparison](evidence/snapshot-comparison-migrated.json), [final comparison](evidence/snapshot-comparison-final.json), [final counts](evidence/final-counts.json).

Testing used a working copy of the migrated starter store. The final root `.snapback` restores the preserved migrated starter data, plus an API-created **M7 Polls** demo group with one poll; its counter is one. This avoids treating legitimate browser receipt acknowledgements or unrelated regression writes as migration damage. The entire exercised test store is retained at `m7/stores/tested/.snapback`; the untouched migrated checkpoint is at `m7/stores/migrated-pristine/.snapback`. Neither is a scale-replay database. [Demo fixture](evidence/final-demo.json).

TypeScript, Quarry certification, and the final iOS Hermes export passed. [Typecheck](evidence/typecheck-poll-semantics.txt), [restored certification](evidence/restored-check.txt), [Hermes hash](evidence/hermes-artifact-final.json). No simulator claim is made.

Correction loops, with attribution:

- **agent-error**: Broad message-card projection exceeded E_BOUND (1050662 > 1048576 bytes); premature backfill commands then returned E_OP_UNKNOWN. Split poll details from history and reran certification before the job. [Evidence](evidence/check-additive.txt).
- **agent-error**: Unauthorized-query test expected refused; the correct SDK state was denied. Fixed the assertion. [Evidence](evidence/acceptance-first.txt).
- **agent-error**: Background Expo launch died with its shell, causing ERR_CONNECTION_REFUSED. Restarted it in a persistent recorded session. [Evidence](evidence/acceptance-second.txt).
- **agent-error**: Source review found poll options retained by unsend. Cleared them in the existing transaction and checked tombstoned options. [Evidence](evidence/check-unsend-options.txt).
- **agent-error**: Evidence/test bookkeeping: do not copy stale prior success on a failed suite; complete expiry checks before reporting a regression failure; snapshot choreography suite inputs immutably. Earlier failed attempts remain retained. [Evidence](evidence/acceptance-1789182625144/suite.json).
- **environment**: React Native Web omitted frozen PollDisplay selected/busy attributes despite correct votes. App-owned web semantics mirror actual vote/outbox state; native kit behavior is retained. [Evidence](evidence/poll-diagnostic.json).
- **ambiguous**: Inherited M2 pagination timing: automatic loading removes the button while Playwright scrolls/clicks it. No feed or prior-suite changes. Bounded timeout retries preserve misses; final M2 passed on attempt two. [Evidence](evidence/acceptance-1789183390032/m2.txt).
- **agent-error**: Moved stopped-store archives under nested ignored .snapback directories to respect generated-file placement. [Evidence](../m7/run-log.md).
- **agent-error**: Two exploratory nonexistent-file lookups and an unnecessary final bare-range Quarry probe failed. Used correct paths and existing authenticated snapshot counts; probe performed no writes. [Evidence](evidence/optional-count-probe-refusal.json).

Candid gaps and limits:

- M2's inherited auto-pagination timing remains flaky; its failed attempts were preserved, and its code/suite were not repaired under M7.
- The frozen starter's message history has no non-null message media or reactions. The migration comparison validates their null/empty fields; it does not establish populated media-message or reaction migration coverage. Post media is outside the specified M6 history export. The unchanged M4 suite separately passed media/reaction behavior after migration.
- This proves starter-sized migration, not migration-at-scale. No scale replay was reused or run. Prior scale midpoint misses and native-simulator limitations remain untouched.
- Counts refresh atomically on the existing expiry timer. The public scheduler does not promise lateness under owner stalls/outages; the real-clock expiry check passed on this run.
- React Native Web needs the app-owned semantic wrapper for the frozen poll component. The iOS export is a build artifact, not simulator proof.
- No new unexpressible Snapback capability was identified. The response-size refusal was resolved within the public surface. No backend source checkout, other lane, inherited diary or essay was inspected.

All started server PIDs were recorded: `2743065`, `2771520` (short-lived failed background launch), `2771323`, `2784683`, `2889620`. Shutdown used exact owned PIDs only. [Test-server shutdown](evidence/test-server-shutdown.json), [final shutdown](evidence/final-server-shutdown.json), [empty assigned-port check](evidence/ports-after-shutdown.txt).

The [diary](diary.md) and [closing essay paragraphs](essay-paragraphs.md) were written before this numerical report. [Chronological run log](run-log.md), [machine-readable report](final-report.json).

end=1789183827
