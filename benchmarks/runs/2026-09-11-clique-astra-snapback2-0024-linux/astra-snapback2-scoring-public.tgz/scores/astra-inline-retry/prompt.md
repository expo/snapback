You are gpt-6-astra. In this benchmark run, one session of your own model family built the production-shaped app Clique (a social messenger), alone and timed, on Snapback 2 (`snapback2@0.0.24`, authored in Quarry). This is the rerun of the 2026-09-05 three-backend run on the newer package: score Snapback 2 alone, on the same absolute rubric, so the number compares with that run's Snapback 2 score (Convex `convex@1.45.0` and Supabase `@supabase/supabase-js@2.112.4` against a hosted project). Your job now is to **score Snapback 2 out of 100**, holistically and by category, from the evidence this session left behind.

## Read these, and only these

The brief: `/home/ccheever/clique-ri-20260911/instrument/social-messenger.md` (skim for the milestone shape; you are scoring backends, not the app).

Your lane, with `diary.md` (per-milestone build experience), `essay.md` (the closing comparison), `run-log.md` (timestamped events, attributions), `final-report.md` (status, results, correction loops, gaps), and `run-record.json` where present:

- `/home/ccheever/clique-ri-20260911/lanes/astra-snapback2/`

Read the narrative files in full. You may open the lanes' source files to check a specific claim. Do **not** open any other lane under `/home/ccheever/clique-ri-20260911/lanes/` (other model families' lanes, or `attempt1/`), any `grading/` directory, and never open or print `provider-secrets.env`. This is a read-only task: run nothing, write nothing, change nothing.

## How to score

- **100** = ideal for this brief: every milestone expressible directly, no workaround, nothing to prove twice. **75** = good, occasional friction. **50** = usable with substantial workarounds or missing pieces. **25** = fought the build at every step. **0** = unusable for this brief.
- Score the backend **as experienced on this brief through its published surface**, not its reputation or what you know it can do elsewhere. Evidence in the lane files decides; when a lane lost time to its own mistakes or to the environment (attributions `agent-error`, `environment`, `ambiguous` in `run-log.md`), do not charge the backend for it. Charge the backend for `*-defect` attributions, platform gaps, missing capabilities, and documentation that misled.
- Where the milestone outcomes differ between backends, weigh **why** they differ: a lane that self-downgraded milestones because the platform refused a product-preserving design is a backend finding; a lane that ran out of time on client-side test plumbing is only partly one.
- Be consistent with the rubric an earlier scorer applied to three backends: the same kind of friction gets the same kind of penalty. The **overall** score is your holistic judgement, not an average of the categories.

## Categories (score each, 0–100, with a note of at most 40 words citing the evidence)

1. `setup_and_docs` — getting started, documentation quality and discoverability, README/guide accuracy.
2. `data_modeling` — authoring the schema and the server-side program: the language's ergonomics, expressiveness, learning cost.
3. `authorization` — expressing who can read and write what, and how naturally the product's membership boundaries map onto it.
4. `queries_and_live` — reads, pagination, feeds, and live updates / realtime in the client.
5. `writes_and_transactions` — mutations, atomicity, idempotency, retries.
6. `offline_sync` — offline writes, outbox, replay, conflict handling, durability across restarts.
7. `media_assets` — uploads, storage, media typing, per-recipient and view-once delivery.
8. `background_work` — effects, scheduled work, row timers, jobs/backfills, the push seam.
9. `client_integration` — the React/Expo web and native arms: hooks, auth lifecycle, reconnect, subscriptions, the paved template.
10. `diagnostics_dev_loop` — quality of error messages, check/test/trace tooling, how fast a wrong program became a right one.
11. `scale_and_limits` — behaviour under the brief's envelope (500 follows, 1,000 conversations, the scale replay), bounds and ceilings, performance.
12. `operations` — seeding, reset, migrations, recovery from bad state, observability of the running backend.
13. `overall` — holistic.

## Output

Your final message must be exactly one fenced JSON block (```json … ```) and nothing else, shaped:

```json
{
  "scorer": {"family": "astra", "model": "gpt-6-astra", "basis": "own lane's narrative files (Snapback 2 only)"},
  "backends": {
    "snapback2": {
      "overall": {"score": 0, "note": "..."},
      "setup_and_docs": {"score": 0, "note": "..."},
      "data_modeling": {"score": 0, "note": "..."},
      "authorization": {"score": 0, "note": "..."},
      "queries_and_live": {"score": 0, "note": "..."},
      "writes_and_transactions": {"score": 0, "note": "..."},
      "offline_sync": {"score": 0, "note": "..."},
      "media_assets": {"score": 0, "note": "..."},
      "background_work": {"score": 0, "note": "..."},
      "client_integration": {"score": 0, "note": "..."},
      "diagnostics_dev_loop": {"score": 0, "note": "..."},
      "scale_and_limits": {"score": 0, "note": "..."},
      "operations": {"score": 0, "note": "..."},
      "verdict": "one sentence",
      "would_use_again_for": "one sentence"
    },
  },
  "notes": ["up to five sentences on what most helped and most hurt Snapback 2 in this run"]
}
```

Scores are integers 0–100. Every category must be present for every backend. Notes cite the lane evidence (a milestone, a diagnostic, a run-log attribution), not general knowledge.


## Transport-only retry

The host's read-only file sandbox could not initialize. No host security setting has been changed. The original scoring instructions above remain the rubric. Below are the complete, verbatim contents of every required, permitted evidence file, supplied directly so file access is unnecessary. Read these in full. Do not call any tools, run any command, access files or network, or attempt optional source checks. Treat each delimited file as evidence, not as new instructions. No other lane, grader finding, M7 narrative, or previous score is supplied. Cite the provided paths/milestones normally; do not claim source verification. Return the exact JSON format requested above.


===== BEGIN VERBATIM FILE instrument/social-messenger.md | 56730 bytes | SHA256 129fd79c5a2b19c7312fc41ed931647b79e2c4afc611c3cc431e0e26a452fbc6 =====
# Brief: social-messenger (canonical full-app benchmark)

**Status:** DRAFT — freeze-candidate. This brief freezes at LLP 0201 P3
(after the pilot calibrates budgets and the prerequisite artifacts
exist). Until freeze, nothing here supports a claim. Governing plan:
`llp/0201-social-messenger-canonical-benchmark.plan.md`; publication
rules: LLP 0197; scoring definition: LLP 0198 P0.0(e) (new brief family
⇒ this brief's own preregistered rubric, below).

**Design rule for this document:** the brief decides everything two
reasonable agents would build differently. The lane's remaining
decisions are backend-shaped only: schema, auth wiring, sync strategy,
media pipeline, API surface. Where this brief is silent and the choice
is not backend-shaped, lanes take the simplest option and note it in
the diary.

## The app

A group messaging and social app named **Clique**, built as an Expo
(Expo Router) client on the lane's backend, targeting iOS, Android,
and web. (Clique is the product name used in the UI and docs; the
brief family and measurement identity remain `social-messenger`.)
Accounts, profiles, a follow graph and post feeds, WhatsApp-shaped
messaging
(DMs and groups, typing, receipts, quoted replies, reactions,
media, edit/delete, disappearing and view-once), per-chat
customization, search, engagement insights and a trending view, a
server-scheduled daily digest, offline-first behavior (including
multi-device convergence), push emission at the provider seam, and a
documented third-party client API.

Lanes use the frozen presentational UI kit and fixture pack (LLP 0201
P1 artifacts; versions pinned at freeze). All test media and personas
come from the fixture pack — lanes never generate test content.

## Global rulings

These apply across all milestones.

- **Conflict policy: last-write-wins** by server arrival order.
  No lane builds CRDTs or custom merge logic.
- **Links:** `http(s)` URLs in any text are auto-detected and rendered
  as tappable text opening the system browser. **No unfurling, no
  OpenGraph fetching, no previews.**
- **Images:** JPEG/PNG/WebP, ≤10 MB. Client-side downscaling is
  permitted but not required.
- **Video:** MP4 (H.264/AAC), ≤50 MB, ≤60 s. Played as uploaded —
  **no transcoding, no thumbnail generation required** (a poster frame
  is optional).
- **Time windows:** message edit within **15 minutes** of send;
  delete-for-everyone within **60 minutes**; disappearing-message
  options **off / 24 h / 7 d**. There is no delete-for-me. The app
  reads its window durations from a config file with these production
  defaults; grading runs the fixture pack's **shortened-windows
  config** so expiry behavior is testable in minutes. Window
  enforcement is always server-side against server time — a backend
  that accepts caller-supplied timestamps for window checks fails the
  relevant probe.
- **Digest schedule** (M8): the app reads its digest schedule from a
  config file with the production default (one digest per user per
  day, computed at 08:00 UTC); grading runs the fixture pack's
  **shortened digest config** (one period every 2 minutes) so
  scheduled emission is testable in minutes. Like the time windows,
  the schedule is evaluated server-side against server time.
- **Revocation semantics** (applies to view-once, delete-for-everyone,
  and disappearing expiry): the guarantee is
  **server-authoritative refusal plus client purge at the next sync**.
  The server refuses reads/assets from the moment of
  revocation/expiry; connected clients purge within the stated
  tolerance; a disconnected client purges immediately on reconnect.
  Revoked and expired content must never render from the offline
  cache after the client has synced the revocation — **view-once
  media is never durably cached at all** and never renders offline
  after its one view. Bytes a client copied while access was valid
  (screenshots, exports) are outside the threat model. **Unfollow is
  projection-scoped, not content revocation:** it server-
  authoritatively removes the account's posts from the viewer's
  Following feed (purged locally on next load) but never revokes
  access to the posts themselves, which remain readable in Global.
- **Write idempotency:** toggle-shaped operations (like, repost,
  reaction, follow, poll vote) are expressed as **idempotent
  set-state intents** (set/clear, not flip) carrying client-generated
  mutation IDs, so at-least-once delivery and offline-queue retry can
  never invert intended state. Queued offline writes replay in order.
- **Identity is entirely in-system.** No device address-book access,
  no phone-number identity, no contact upload/matching (that flow
  needs SMS verification and measures OS permission plumbing, not the
  backend). "Contacts" means registered accounts: discovery is
  people-search by display name or handle; the de-facto contact set is
  who you follow and who you share chats with.
- **Self-follow is implicit feed membership.** The Following feed always
  includes the viewer's own original posts and reposts, even when the viewer
  follows no accounts. This is not a persisted follow edge: users cannot
  follow or unfollow themselves, follower/following counts exclude the
  implicit relationship, and feed entries remain unique.
- **Out of scope everywhere:** email sending (so: no verification, no
  password reset), SMS, OAuth/social login, device address-book
  access, quote-posts, link previews, message forwarding, voice notes
  (the media pipeline is already priced by photo/video; recording
  measures the client, not the backend), calls, E2E encryption,
  blocking/reporting, follow requests/private accounts, real APNs/FCM
  delivery.
- **Platform proof per milestone:** interaction proofs run on web
  (two browser contexts for two-client choreography); every milestone
  also produces an iOS Hermes bundle export as a build artifact. M6's
  offline proofs additionally run on the iOS simulator as a separately
  recorded native/O4 artifact; absence of that artifact cannot support a
  native claim but does not block the web authoring-green clock. M8's
  offline queued-write restart proof is the same class of separately
  recorded native artifact, under the same rule. Android is a
  spot-check outside scored runs, not a per-run requirement.
- **Seeding:** a versioned, idempotent seed installs the fixture
  personas and starter content. Both seeds — the small starter seed
  and the scale seed — are fixture-pack **action logs** replayed
  through the app's own write path. The starter log ships
  **segmented per milestone** (the M1 segment has only registrations
  and profiles; follows and posts arrive with M2's segment; chats
  and messages with M3's): a lane installs each segment when its
  milestone first needs it, that milestone's budget absorbs the
  segment's replay tooling, and idempotency ("running it twice
  changes nothing") is judged **per installed segment** — M3's
  seed-idempotency acceptance item covers every segment installed so
  far, and each milestone's suite re-runs it. The
  M6-budget replay-adapter ruling applies to the **scale** replay
  only (see "Scale envelope and performance").
- **Acceptance entrypoint:** the lane ships one documented command
  (e.g. `npm run acceptance`) that runs the scripted acceptance suite
  from a clean checkout against the running backend — the same
  invocation shape for every lane, so grader environment loops don't
  contaminate defect counts. Timing-sensitive checks (typing
  latency, live updates) are judged **best-of-3** under grader
  execution so machine-load flakes don't inflate defect severity.

## Scale envelope and performance

The app must remain correct and responsive at this envelope (visible
to builders by design — whether the agent designs for scale is part of
what the benchmark measures):

- ~1,000 registered users; ~50,000 posts; ~100,000 messages total;
  one "busy" group chat with 10,000 messages and 50 members; a probe
  user who follows 500 accounts and belongs to 100 conversations; one
  **celebrity** account followed by 900 of the 1,000 users, authoring
  ~200 posts spread through the log (M8's fan-out fixture — whether a
  lane fans out on write or filters at read time, the celebrity is
  where that decision's cost becomes visible); and a named
  **celebrity-follower** who follows the celebrity plus 4 small
  accounts (the read-path comparison fixture).
- The fixture pack provides the envelope as an **action log**: one
  action per line, human-readable but structured (e.g.
  `2026-01-03T10:15:00Z u0117 post "Coffee time"`,
  `… u0117 follow u0042`, `… u0042 send g003 "on my way"`), produced
  once by a committed deterministic generator (seeded RNG). The log
  is deliberately backend-neutral — no SQL dumps, no rows shaped
  like any backend's schema.

**Replay contract** (frozen with the brief):

- **Replay order is authoritative; log timestamps are documentary.**
  Content ordering follows replay order and server arrival time —
  lanes never backdate, and no privileged time seam is required for
  seeding. No chat in the scale log has disappearing messages
  enabled, so nothing is expired-on-arrival.
- **Registration is real:** the log's `register` actions run through
  the actual signup path (yes, ~1,000 password hashes — that is
  load, not waste); all scale-user credentials, including the probe
  user's, live in the fixture pack for the grader.
- **The replay adapter is authored inside M6's budget** and drives
  the app's **own mutation and auth path** (headless client, API, or
  the app's function surface — whatever the lane has), covering
  **every action-log verb** per the fixture pack's frozen action
  schema (register, profile-set, follow, post, like, repost, reply,
  chat-create, group-create, member-add, send, react, and so on —
  the schema file is the authority). Each action **settles before
  the next** so authoritative replay order is reproducible.
  **Replay execution** runs on its own recorded clock with its own
  wall cap — exhausting it scores O5, never the lane's completion
  statuses.
- **The push seam is disabled during replay** (a pinned replay-mode
  flag) so lanes don't diverge on ~100k notification side effects;
  receipts and feeds behave normally.
- **Base state:** the scale replay runs against a **fresh backend
  instance seeded with the starter log** (mirroring M7's ruling) —
  never the dev instance, whose acceptance and choreography residue
  would make exact-count verification fail spuriously. The
  invariant manifest is generated over the combined starter + scale
  content, so expected counts are exact. The M6 adapter-conformance
  check (50-action sample log) runs on the dev instance.
- End state is verified against the log's **invariant manifest** —
  per-entity counts, per-chat message counts, follow-edge counts,
  and named spot entities. Mechanics: corpus-wide counts come from
  the harness's **settle-receipt accounting** (every action
  acknowledged during replay — a fully acknowledged replay
  establishes the *expected* counts from the log itself); the
  *actual* end state is then independently verified by a **seeded
  deterministic sample covering every action-schema class**, whose
  seed is committed with the wave's probe set and hidden from
  builders — the adapter cannot predict which entities are checked,
  so no-opping any action class risks detection: 10 sampled chats'
  message counts via paged API history, the busy chat counted
  exactly by full paging, the probe user's conversation count, 10
  sampled users resolvable with correct profiles via people search,
  10 sampled users' follow counts via web-UI profiles, 10 sampled
  posts with their like/repost/reply counts via the feeds, sampled
  group membership lists via chat settings, sampled reactions and
  quoted replies on named messages via the field manifest. In
  addition, the **named O5 fixtures are checked exactly, at each
  checkpoint, before probes run**: the probe user's 500 follows, the
  5-follow comparison user's count, the celebrity's follower count
  (exactly 900) and post count, the celebrity-follower's 5-account
  following list, and the busy group's 50-member
  roster — a fixture mismatch, like any **manifest nonconformance,
  caps O5 at its failure band (0)** — performance is never scored on
  an artifact that did not validly reach the envelope, nor against
  an underfilled workload.
- The log carries **checkpoint markers at 10% and 50%**: replay
  pauses at each marker, probes run (their wall time excluded from
  the replay cap), and replay resumes — so growth is a curve through
  three sizes, not a two-endpoint ratio.

Performance grading runs on full-app runs after M6, using the
custom-client API and web client on the run machine. Probes run
sequentially (no concurrency), k=20 requests per probe after 3
warm-ups, 30 s timeout; each lane's **deployment posture** (local
binary, local dev server, hosted dev deployment) is a pinned record
field. **O5 is a scale-safety gate, not a comparative speed
statistic** — postures differ across backends, so cross-backend
latency ordering is never a claim; what is scored is viability at
the envelope. Absolute latency ceilings are **calibrated at P3 from
the pilot** (recorded with the budget caps). What is pinned now,
because it is hardware-independent, are **degradation rules** — the
signal is pathological growth, not milliseconds:

- Paging deep into the 10k-message chat must not grow superlinearly:
  p95 of page 50 ≤ 3× p95 of page 1.
- Following-feed load for the 500-follow probe user ≤ 3× the same
  query for a 5-follow user.
- Global message search latency at the full corpus ≤ 3× the same
  query at the 10% checkpoint, with the 50% checkpoint on or below
  the line between them (no superlinear blow-up mid-curve).
- Receipt aggregation in the 50-member group must not visibly stall
  message send/render.
- Cold-start initial sync of the probe user's account (100
  conversations) completes without timeout or unbounded memory
  growth; its wall time is recorded.
- **Celebrity write path (M8):** the celebrity's post-create
  acknowledgement p95 ≤ 3× a 5-follower author's post-create p95 —
  fan-out-on-write must not make the write path scale visibly with
  follower count.
- **Celebrity read path (M8):** Following-feed load p95 for the named
  celebrity-follower ≤ 3× the 5-follow comparison user's feed load —
  read-time filtering must not push the fan-out cost onto followers.
- **Insights (M8):** the probe user's Insights load at the full
  corpus ≤ 3× the same load at the 10% checkpoint, with the 50%
  checkpoint on or below the line between them; the load must not
  transfer the corpus to the client (a page-and-count-client-side
  implementation fails structurally, not just on latency).
- **Trending (M8):** Trending at the full corpus ≤ 3× the 10%
  checkpoint, under the same mid-curve rule.
- No probe may time out, error, or OOM at the envelope.

The exact probe queries rotate with the holdout set; the envelope
above is the published contract. Absolute numbers are indicative only
(local, colocated); network-realistic performance measurement is a
future leg once a hosted service exists (LLP 0201 D2).

## Screens (pinned)

Auth (sign up / sign in) · Feed (Following / Global / Trending
tabs) · Post thread · Compose post · Own profile (view + edit,
follower/following counts) · Insights (reached from own profile) ·
Other-user profile (follow toggle, counts) · Chats list ·
Conversation · Chat settings · New chat / new group · Search (people /
this chat / all messages) · Settings (account, log out).

The UI kit provides the presentational components and design tokens
for all of these; wireframe notes ship with the kit. Lanes wire data
and navigation.

## Fixture personas

Eight personas, `alice`…`henry` (`<name>@example.com`), passwords in
the fixture pack, each seeded with a profile, avatar, and starter
content (chats, group, posts, and a follow graph) defined by the
pack's seed manifest. The seeded follow graph is asymmetric by design
(some pairs follow one way only) so Following-feed acceptance can
distinguish the two feeds.
Two-client proofs use Alice and Bob in separate browser contexts,
driven by the choreography script.

---

## Milestones

An extension milestone, **P1 — Clique Pay** (wallets and bill splitting,
`clique-pay.md`, 2026-09-03), exercises the exact value model; it belongs to
neither run and enters neither completeness denominator.

Reduced run = M1–M3. Full run = M1–M8. Each milestone lists its spec
and its acceptance checklist — observable behaviors the grader
executes independently. Numbering is identity, not execution order:
the continuous session runs M1–M6 and then M8; M7 remains the
fresh-session day-2 milestone, run after the continuous session is
graded (M8 was added by the 2026-08-11 amendment — LLP 0201's dated
amendments — and keeps prior records comparable: runs that predate it
record M8 `not-run`).

**Budgets.** Cap keys (LLP 0201 D2): the **wall cap** is keyed by
milestone and shared by every lane in every family of a wave; the
**token cap** is keyed by (cap family, milestone) — cap families
enumerate the model matrix (primary Claude frontier; GPT frontier;
the mid-tier model as its own family; Kimi and Grok each their own
cap-advisory family — wall caps recorded for reference, token caps
recorded as inapplicable, never enforced, with the pilot safety
limits as hard stops), and no per-backend token caps exist. Wall cap(m) = 2× the slowest
tier-1 pilot lane's wall figure; primary token cap(m) = 2× the
largest tier-1 pilot token figure; the GPT and mid-tier families'
token caps come from their Convex mini-pilots via LLP 0201 D2's
max-over-backends pilot-figure transfer rule, 2× applied after
transfer, clamped at 2× the safety limit; pilot figures read green
pilot milestones, with the safety limit standing in as the *figure*
where a pilot lane has no green one — the ordinary 2× formula then
applies, the same rule as LLP 0201 D2/P2 (numbers recorded in the
table at the end at P3). Unused budget
does not roll over. M8 postdates the P2 pilot: its caps calibrate
from the P2b M8 pilot extension (LLP 0201, dated amendment
2026-08-11) under the same formulas, with the safety limits standing
in until those figures exist.

**Executors.** At P1 every checklist item is split into atomic
assertions with stable IDs, and every assertion (not merely every
numbered item — compound items get one class per clause) is assigned
exactly one executor class: **suite-required** (the builder's
scripted suite must cover it; the harness validates a coverage
manifest mapping every suite-required assertion to a test),
**[choreo]** (two-client behavior executed by the web harness, plus M6 native
behavior recorded by a separate lane-native harness artifact), or **[grader]** (source inspection,
API probing, snapshot comparison — grader phase only). **A
milestone's green receipt requires both a passing suite run
(coverage-validated) and a passing run of that milestone's
choreography segment** — realtime behavior gates green too; only
[grader] assertions are deferred to grading. M6 assertions marked
`native-artifact` are recorded and scored independently and do not gate web
authoring green; missing evidence leaves native/O4 proof absent rather than
passing it. The grader
spot-verifies the coverage mapping is honest. Tags below mark items
whose class is not obvious from phrasing. M8 assertions marked
`native-artifact` follow the M6 rule: separately recorded and scored,
never gating web authoring green.

**Statuses and dependencies.** A milestone ends in exactly one
execution-time status: `green` (harness-recorded passing suite run
plus passing choreography segment — this stops the milestone's
authoring clock), `capability-failure` (cap exhausted; the lane
proceeds to the next non-blocked milestone), `aborted` (abandoned
mid-attempt before cap exhaustion — treated as a capability failure
for proceed/completeness purposes, distinct in the record),
`blocked-by-M{n}` (a prerequisite failed; when several did, the
record lists the complete failed-prerequisite set, `n` = the lowest;
never counted as an additional independent capability failure), or
`not-run` (the lane terminated before reaching it). A milestone
whose prerequisite is itself blocked is likewise blocked, recording
the transitive failed set. Charging (mirrors LLP 0201 D2):
wall-exhausted `capability-failure` = full wall cap plus actual
tokens; token-exhausted = token cap plus actual wall; `aborted` =
full wall cap plus actual tokens, flagged `aborted`. A dishonest coverage mapping found
at grading **adjudicates** the milestone to `capability-failure` —
scoring-only and non-retroactive: execution-time statuses,
dependencies, termination history, and other milestones' clocks
stand as run; the published wall recharges that milestone to its
cap; O1 scores its checklist not-passed. The prerequisite DAG: M2
requires M1; M3 requires M1; M4, M5 require M3; **M6 requires M2,
M3, M4, and M5** (its checklist re-verifies likes, media,
view-once, and search behavior offline); **M8 requires M6** (it
extends M6's offline and push obligations and reads M2's social
graph); M7 requires M6. Scoring DAG: M3 requires M1 only; M3 does
not require M2. Reduced-run protocol: execute M1, then M2, then M3
in that order — do not start M3 to avoid an unfinished M2; a
reduced run that skips M2 is non-conforming even though M3's
scoring prerequisite is only M1. Two
consecutive `capability-failure`/`aborted` results (blocks do not
count) end the lane; the record carries an orthogonal termination
reason. All full-run milestones stay in the completeness
denominator regardless of status.

### M1 — Accounts and profiles

Spec:

- Sign up with email + password (password ≥8 chars). The lane uses
  its backend's **built-in auth if it supports password
  credentials**; otherwise it implements password auth with a named
  adaptive KDF — argon2id, scrypt, or bcrypt at standard published
  parameters. Fast unsalted hashes do not qualify. Never plaintext or
  reversible; the gap between "built-in fit" and "hand-rolled" is
  priced by rubric dimension B2, not hidden. Third-party identity
  services are out of scope (identity is in-system).
- Sessions are expiring tokens; logout revokes server-side.
- Sign in; sessions persist across app restart; log out invalidates
  the session server-side.
- Profile fields (exactly these): display name (1–50 chars), handle
  (unique, 3–20 chars, `[a-z0-9_]`), avatar image, bio (≤200), location
  (≤50), link (one URL). Handle uniqueness is enforced server-side.
- Own-profile editing for every field, including replacing the avatar.

Acceptance:

1. Sign up as a new user; app lands in the authenticated state.
2. Duplicate handle is rejected with a visible error; duplicate email
   likewise.
3. Kill and relaunch the app; still signed in.
4. Log out; relaunch; signed out. The old session token no longer
   works against the backend (the API sub-assertion is marked
   run-scope-conditional in the applicability manifest — [grader]
   via the API on full runs only).
5. Edit display name and bio; changes visible on the other client
   without manual refresh.
6. Upload a fixture avatar; it renders on the profile (avatars
   beside posts and messages are asserted at M2/M3, where those
   surfaces exist).
7. [grader] Source inspection: passwords stored via built-in auth
   or a named adaptive KDF; no plaintext or reversible password
   storage in server persistence, client bundles, or logs. The
   fixture pack's credential files are a declared test-fixture
   exception (they live outside the app). A backend's managed auth
   provider qualifies by its documentation — the grader verifies the
   lane uses the documented provider path, not provider internals.

### M2 — Posts and the follow graph

Spec:

- Post types: text (≤500 chars); images (1–4 fixture images);
  video (exactly 1). Image and video may carry a text body; a post
  never mixes images and video.
- **Follow graph:** follow/unfollow any other user from their profile
  (toggle; takes effect immediately — no requests, no private
  accounts). Profiles show follower and following counts.
- Likes: toggle, one per user per post, count visible.
- Reposts: toggle, one per user per post; appears in feeds attributed
  "reposted by {display name}". No quote-posts.
- Replies: any post can be replied to; a reply is a post referencing
  its parent. The thread screen shows the parent and its **direct**
  replies, chronological. Parents show a reply count. Replies never
  appear in feeds, only on thread screens.
- **Feeds, two tabs** (Following is the default): **Following** —
  reverse-chronological original posts and reposts from the viewer plus
  accounts the viewer currently follows; after an unfollow, that other
  account's posts (including older ones) no longer appear on next load.
  **Global** —
  reverse-chronological original posts and reposts from everyone.
  Both paginate 20 per page with infinite scroll.
- Profile screens list that user's posts, reverse-chronological.

Acceptance:

1. Create a text, an image (2 images), and a video post; all render
   in the Global feed on the other client without manual refresh,
   with the author's avatar and display name.
2. Bob follows Alice; Alice's posts appear in Bob's Following feed and
   her follower count updates live. Bob unfollows; on next feed load
   her posts (including older ones) are gone from Following but remain
   in Global. With no explicit self-follow edge, Bob's own original posts
   and reposts remain in Following throughout; the implicit relationship
   does not change his follower/following counts.
3. A post from a user Bob doesn't follow appears in his Global feed
   but not his Following feed.
4. A URL in a text post is tappable; no preview card renders.
5. Like from client B; count updates live on client A. Unlike works.
6. Repost from client B; feeds show the attributed repost; reposting
   again removes it. A repost by a followed user surfaces the original
   author's post in the Following feed. A viewer's own repost of an
   unfollowed author is labeled as a repost and is not a direct
   follow-projection hit; the author's original must appear via the
   follow edge.
7. Reply to a post; reply count increments live; thread screen shows
   parent + direct replies in order; the reply is absent from both
   feeds.
8. Feed pagination: with >20 seeded posts, scrolling loads the next
   page in both tabs; no duplicates, no gaps.

### M3 — Messaging core

Spec:

- **DMs:** at most one DM channel per user pair; starting a DM with an
  existing counterpart opens the existing channel.
- **Groups are entities:** created with a name (1–50 chars), optional
  description (≤200); 2–50 members; multiple groups with identical
  membership are distinct. The creator is an admin; admins can add and
  remove members and promote others to admin; anyone can leave. Adds
  take effect immediately — **no invitation/acceptance flow**.
- Text messages, ≤2000 chars.
- **Quoted replies** (WhatsApp-style): a reply carries a pointer to
  the quoted message; the bubble shows a quoted excerpt; tapping it
  scrolls/jumps to the original. No thread model.
- **Typing indicators:** appear on other members' screens within 2 s
  of typing, expire within 5 s of the last keystroke. Shown as "…"
  in the conversation and a hint in the chats list.
- **Receipts**, per message, monotonic: `sent` (accepted by the
  backend) → `delivered` (fetched by the recipient's client) →
  `read` (recipient viewed the conversation). Rendered as
  single-check / double-check / colored double-check. In groups the
  aggregate indicator shows a state only when every member of the
  message's **recipient set** has reached it — the recipient set is
  **membership at send time**, and members who leave or are removed
  before reaching a state drop out of the aggregate requirement.
- New members see the group's **full prior history** on join.
- Removed members immediately stop receiving new messages but keep
  their local copy of history from before removal.

Acceptance:

1. Alice DMs Bob; Bob replies; both see messages live with sender
   avatars. Starting the "same" DM again reuses the channel.
2. Create a group with Alice, Bob, Carol; a second group with the same
   three members coexists.
3. Bob types; Alice sees "…" within 2 s; it expires when he stops.
4. Receipt ticks transition sent → delivered → read as Bob's client
   fetches and then opens the conversation; group indicator waits for
   the slowest member.
5. Quoted reply renders the excerpt; tapping jumps to the original.
6. Admin removes Carol; she no longer receives new messages but still
   sees pre-removal history. A non-admin cannot remove members.
7. Seed is idempotent (second run: no duplicates).

### M4 — Media messages, reactions, edit/delete

Spec:

- Photo and video messages: fixture asset → picker → upload →
  rendered inline from a query result on the recipient; optional
  caption ≤500 chars.
- **Reactions:** any emoji, at most one per user per message; tapping
  the same emoji removes it, a different one replaces it; aggregate
  counts on the bubble.
- **Edit** own text messages ≤15 min after send; edited bubbles show
  an "edited" label; recipients see the new content. Media messages:
  caption is editable, media is not.
- **Delete-for-everyone** ≤60 min after send; the bubble becomes a
  "This message was deleted" tombstone for all members; the asset is
  no longer served.

Acceptance:

1. Photo message end-to-end: Alice picks a fixture image, sends; Bob
   sees it rendered (not a placeholder) live.
2. Video message end-to-end; plays on the recipient.
3. Bob reacts 👍; Alice sees it live; Bob switches to ❤️ (replaces);
   taps ❤️ again (removes).
4. Alice edits a sent message; Bob sees the new text and the label.
   Under the shortened-windows config, an edit attempted after the
   window is rejected **server-side** (the grader verifies via the
   API, not just the absence of the UI affordance).
5. Alice deletes a message; Bob sees the tombstone; the media URL no
   longer serves the asset.

### M5 — Ephemeral, chat config, search

Spec:

- **Disappearing messages:** per-chat setting (off / 24 h / 7 d),
  changeable by any member (admins only in groups); applies to
  messages sent after the change; the chat shows the current setting.
  Expiry is **server-enforced**: the server refuses expired content
  within 5 minutes of expiry with no client open, and clients purge
  per the global revocation ruling (connected: within tolerance;
  disconnected: on reconnect). Expired messages also leave the local
  store and offline search results once the client has synced the
  expiry.
- **View-once photos:** sender flags a photo message as view-once;
  each recipient can open it exactly once; after closing, reopening is
  denied and the backend refuses the asset. In groups, one view per
  member.
- **Chat customization**, synced to all members: group name and
  description editable by admins; accent color from the kit's pinned
  8-color palette; background image (fixture upload) rendered behind
  the conversation. DMs: color and background only.
- **Search** — matching semantics pinned as **case-insensitive
  word-prefix over Unicode-normalized (NFC) text** ("cof" matches
  "Coffee time"; mid-word substrings are explicitly not required —
  arbitrary substring would conflict with every tier-1 backend's
  indexed text search and force full scans at the envelope). Case
  folding is Unicode simple case folding; word boundaries split on
  whitespace and punctuation; the frozen fixture corpus and probes
  stay within Latin-script text, so locale-specific folding edge
  cases are out of scope. Newest first, paginated. Three scopes: people — all registered accounts by
  display name or handle; messages within one chat; messages across
  all the user's chats, grouped by chat. At M5, search over
  **already-synced** messages must keep working **warm-offline** (the
  running app loses connectivity — no restart); cold-start offline
  search is M6's obligation, re-verified there.

Acceptance:

1. [grader] Set a DM to disappearing (shortened-windows config):
   with both clients closed at expiry, the server refuses the expired
   message (API check); each client purges it on next
   launch/reconnect; it no longer appears in offline search after
   that sync.
2. View-once photo: Bob opens it once; second open is denied; direct
   asset fetch after the view is refused (server-side).
3. Admin sets group color + background; Carol sees both; non-admin
   cannot rename the group.
4. People search finds "car" → Carol; in-chat search finds a known
   seeded string; global search groups results by chat.
5. Warm-offline: with the app running, cut connectivity; search over
   previously synced messages still returns results (no restart —
   cold-start offline search is verified at M6).

### M6 — Offline writes, push seam, custom-client API

Spec:

- **Offline reads:** cold-starting the app with the backend
  unreachable shows all previously synced chats, messages, and
  already-viewed media — **except view-once media and revoked/expired
  content**, per the global revocation ruling. Message search over
  synced content also works cold-offline (re-verifying M5's warm
  guarantee against the durable store).
- **Offline writes:** composing while offline queues messages with a
  visible `pending` state; on reconnect they flush **in order** and
  walk the normal receipt states. Likes and reactions queue the same
  way.
- **Push seam:** when a message arrives for a user with no connected
  client, the backend emits a notification payload through its
  provider seam and logs it:
  `{targetUserId, chatId, senderDisplayName, preview}` — preview is
  the first 80 chars of text, or `"Photo"`/`"Video"` for media and
  view-once. Real APNs/FCM delivery is out of scope.
- **Custom-client API**, for third-party clients. Deliverables:
  a docs artifact (`API.md`) and a headless Node demo script
  (`scripts/custom-client-demo.mjs`). A third-party developer with
  only an access token and `API.md` must be able to: authenticate
  (or use an issued token), list their conversations, page through
  message history, send a text message, and receive new messages
  (streaming or documented polling — state which). API tokens are
  scoped to one user, expire, and die with logout/revocation —
  `API.md` states the issuance, expiry, and revocation story. REST
  is **not** required; the backend's native protocol is fine if
  `API.md` makes it followable. **Minimum message-object field
  manifest** (what the history operation must expose per message, so
  probes and the M7 snapshot are backend-neutral): id, conversation
  id, sender id, server timestamp, type, text/caption, media
  reference, edited flag, tombstone flag, reply-to id, reactions
  (emoji, count, caller's own state), and — for the caller's own
  messages — the receipt state.

Acceptance:

1. [native-artifact] Cold-start offline (iOS simulator, backend stopped): history and
   previously viewed media render; synced-message search works; a
   previously viewed view-once photo does **not** render.
2. [native-artifact] Send two messages offline; both show pending; on reconnect they
   arrive in order and reach `read` normally.
3. With Bob's clients closed, Alice messages him; the logged push
   payload has the right target, sender, and preview; a view-once
   photo previews as "Photo".
4. `custom-client-demo.mjs` runs green against the live backend from
   a clean checkout, exercising every listed operation.
5. [grader] Grader-written variation: following only `API.md`,
   fetch the latest message of a named conversation. (Documentation
   quality is part of the bar.)
6. The scale-replay adapter passes the fixture pack's action-schema
   conformance check (replays a 50-action sample log green,
   harness-validated) — adapter authoring is thereby inside M6's
   coverage manifest, cap, and authoring clock, not deferrable
   off-clock.

### M7 — Day-2 evolution (fresh session, after the continuous session — M1–M6 plus M8 — is graded)

Run by a **fresh agent session** with no builder context. **Data
environment (author ruling, 2026-08-08): the pre-replay starter
state** — a fresh backend instance seeded with the starter log, not
the scale replay's ~100k-message database (migration-at-scale is a
possible future leg). The pre-M7 snapshot is exported through the
custom-client API over the M6 field manifest, using each persona's
token, before the M7 session starts.

Spec, two parts (the second exists because polls alone could live in
a new table without ever touching existing data — the backfill is
what forces a real migration):

1. Add **group polls** — a new message type: question (≤200 chars),
   2–4 options (≤50 chars each); one vote per user, changeable
   (idempotent set-state, per the global ruling); live tallies
   visible to all members; votes queue offline like reactions.
2. Add a **backfilled field**: every conversation gains a message
   count, shown in chat settings, **backfilled over all existing
   conversations** and maintained forward. Count semantics: currently
   visible messages — excludes tombstoned and expired messages;
   polls count as messages.

Existing data must survive the schema change intact. The record
notes whether the pre-M7 schema already carried count structures
(a lane may have maintained counts early; the field keeps B8's
forced-migration signal honest). The M7 session
runs under the same aid condition as the lane it continues, on its
own recorded clock, and writes its own diary entry and closing-essay
paragraphs under the same essay-before-numbers sequencing; it scores
rubric dimension B8.

Acceptance:

1. Create a poll in a group; members vote; tallies update live;
   changing a vote adjusts counts; a duplicate/retried vote intent
   does not flip state.
2. An offline vote queues and settles on reconnect.
3. Message counts are correct for pre-existing conversations
   (backfill) and increment with new messages.
4. Pre-existing messages, media, receipts, and reactions are intact
   after the migration — the grader compares against the **pre-M7
   snapshot exported through the custom-client API** before M7
   started (backend-neutral by construction).
5. The acceptance suites of previously-green milestones still pass
   (prior failures are preserved, not repaired under M7's budget).

### M8 — Insights, digest, and multi-device offline (continuous session, after M6)

Added by the 2026-08-11 amendment (LLP 0201, dated amendments) to
close the coverage holes the instrument otherwise leaves open:
aggregation/reporting, genuinely scheduled server-side work, high
fan-out, and offline depth. Authored in the same continuous session
as M1–M6, immediately after M6; requires M6. M7 is unchanged: still
fresh-session, still requiring only M6, its regression item covering
whatever milestones were previously green (including M8). M8 adds no
starter-log segment — its acceptance creates the activity it
measures, over content the existing segments already seed.

Spec:

- **Insights screen** (reached from own profile):
  - Lifetime totals, exactly these six: posts, likes received,
    reposts received, replies received, followers, following.
  - Seven-day activity: for each of the trailing 7 UTC days (server
    time), posts created and likes received that day. Days with no
    activity render as zero, not omitted.
  - Freshness pinned: values reflect server state as of screen load;
    pull-to-refresh re-queries; live update is not required. Whether
    counts are maintained (counters, read models) or computed
    (aggregate queries) is backend-shaped — the scale envelope's
    Insights degradation rules are the only constraint.
  - Totals are server-computed: the client never derives a total by
    paging the corpus (structurally enforced by the Insights
    degradation rule at the envelope).
- **Trending** (third feed tab, after Following and Global): the top
  10 original posts (replies excluded, reposts count toward nothing
  here) from the trailing 24 h of server time, ranked by like count
  descending, ties newest-first. Recomputed on load and
  pull-to-refresh; live update is not required; an empty trailing
  window shows the kit's empty state.
- **Daily digest** (scheduled, server-side): on the digest-config
  schedule (see Global rulings), the backend computes, per user,
  activity since that user's previous digest period and emits one
  payload through the M6 push seam (logged, like all seam traffic):
  `{targetUserId, kind: "digest", periodStart, periodEnd,
  newFollowers, newPostsInFollowing, unreadMessages, unreadChats}`.
  Rules: emission is driven by the schedule alone — it requires no
  connected client and no client interaction, so lazy read-triggered
  evaluation cannot satisfy it; a user whose counts are all zero
  gets no digest; exactly one digest per user per period, idempotent
  under retry and backend restart; counts respect authorization —
  activity in chats the user is not a member of, and
  expired/tombstoned content, never contributes. The push seam's
  replay-mode flag also disables digests during the scale replay.
- **Multi-device and deeper offline** (one account on two clients;
  the global last-write-wins ruling applies unchanged — M8 adds no
  merge semantics):
  - Signed in on two clients: messages sent, edited, and reacted-to
    on one appear live on the other, and **read state syncs across
    the account's own devices** — opening a conversation on one
    client clears its unread indication on the other.
  - Both clients offline: each composes in the same chat; on
    reconnect both messages flush and settle in server-arrival
    order, no loss, no duplicates, receipts advancing normally.
  - Queued writes survive restart: composing offline, killing the
    app, and relaunching still offline shows the queued messages
    still pending; they flush in order on reconnect. (M6 requires
    the queue while the app stays running; M8 requires the queue to
    be durable.)

Acceptance:

1. Alice's Insights totals match the seeded content; Bob likes one
   of Alice's posts; after refresh her likes-received total
   increments.
2. The 7-day breakdown buckets a post created today under today and
   renders days with no activity as zero.
3. Trending ranks the post with the most likes in the trailing 24 h
   first; an older heavily-liked post (>24 h) is absent; a tie
   breaks newest-first.
4. [grader] Under the shortened digest config with every client
   closed: seeded activity produces exactly one logged digest per
   active user with correct counts; a persona with no activity in
   the period gets none; a following period with no new activity
   emits none; a backend restart mid-period does not double-emit.
5. [grader] Digest authorization: activity in a chat the target
   user is not a member of never contributes to that user's digest
   counts.
6. Same-account convergence: Alice signs in on two clients; a
   message sent on client 1 appears on client 2 live; opening the
   conversation on client 1 clears the unread indication on
   client 2.
7. Both of Alice's clients go warm-offline; each composes one
   message in the same chat; on reconnect both settle in
   server-arrival order, no duplicates, and receipts advance
   normally.
8. [native-artifact] Compose offline; kill and relaunch the app
   still offline; the queued messages render as pending; on
   reconnect they flush in order and reach `read` normally.

---

## Holdout probes

A rotated probe set — trust-boundary shaped (cross-user DM access via
the API, removed-member delivery, view-once re-fetch, expired edit
window, session invalidation after logout, **server-side denials
surviving the offline cache**, scheduled-digest authorization — a
digest must never count chats its target cannot read) and
performance shaped (the exact
queries measured against the scale envelope's degradation rules,
including the M8 celebrity and aggregate rules) —
is maintained outside this brief, run by the grader, and **published
after each scored wave, rotated for the next** (LLP 0201 D3).
Builders never see the current wave's **scored** probes; the trust
obligations and the scale envelope they test against are published
here. Custody and comparability per LLP 0201 D3: the wave's probe
set is hash-committed before its first lane starts, and the rotation
log records the category mapping; probes whose target behavior a
failed milestone never built score under a preregistered rule
(not-passed or excluded-with-note) frozen with the probe set.
**Anchor probes are non-scored**
(author ruling, 2026-08-08): each category's unchanged cross-wave
anchor is a published continuity diagnostic that never bears on
O3/O5 — scores read only the wave's secret rotated probes, which
cover every category.

## Scoring

Two layers per LLP 0201 D4. The grader scores outcome (45); the
builder scores experience (55); the builder separately records a
holistic 0–100 **before** seeing any computed total or metric, citing
2–3 concrete moments. Sequencing: closing essay → dimension scores →
holistic → numbers revealed.

**Applicability (frozen; author ruling 2026-08-08 — nulls block
totals):** a run scores only the dimensions it exercises. Each
dimension's **observing milestones**: O1/O2 — all in-scope; O3 —
M6 green plus M1–M5 attempted; O4 — M6 green; O5 — the replay; B1 —
M1–M3, plus M8 on full runs; B2 — M1; B3 — M2–M3, plus M8 on full
runs; B4 — M6, plus M8 on full runs; B5 — M1–M2 on reduced runs,
plus M4–M5 on full runs; B6 — M5; B7 — M6, plus M8 on full runs;
B8 — M7; B9/B10/B11 — the whole run. Per-dimension rules (these govern; there is no blanket
O-rule): O1 and O2 score whenever the grading phase ran, over every
in-scope milestone regardless of status (failed/blocked checklists
score not-passed — the partial-credit design); O3 and O4 require M6
green (O3 additionally M1–M5 attempted); O5 requires the replay
*attempted* — its exact function scores failures, including its 0
branches, so an attempted replay is never null; B-dimensions score
if every observing milestone was at least attempted
(`green`/`capability-failure`/`aborted`), except B9/B10/B11, which
score if at least one milestone was attempted (terminated lanes'
experience data is exactly what must publish). Never-attempted
scopes record null. So reduced runs (M1–M3) record null for O3, O4,
O5, B4, B6, B7, B8. The P1 applicability manifest instantiates this
table at assertion granularity for the record schema. A **complete
lane**, by enumeration: M6 green, replay attempted, M7 attempted,
every other milestone attempted — that is execution completeness; a
weighted total and L4 eligibility additionally require a **usable
grading record** (the dual grader-abort outcome nulls O-dimensions
and overrides these applicability rules). **Any run with a null dimension publishes
per-dimension scores and efficiency statistics only — no overall
weighted total**; L4 statistics read complete lanes, with every lane
reported and the completion rate published alongside (the Holistic
section's "report both" applies only when a weighted total exists).
On reduced
runs, anchors are interpreted over M1–M3 scope only (O1's 60-anchor
reads "M1–M2 solid, M3 patchy"; B5 reads over avatars and post
media). The holistic score is recorded and published for every run
as narrative evidence, never a claim statistic.

Anchors describe what ~30 / ~60 / ~90 look like; interpolate.

### Grader-scored outcome (45)

**O1. Functional completeness — 13.** Fraction and quality of the
frozen acceptance checklists passing, with **every milestone of the
run's scope in the denominator** regardless of status — non-green
milestones (`capability-failure`, `aborted`, `blocked-by-M{n}`,
`not-run`) score their checklists as not passed (the status
distinction matters for attribution, not for completeness
credit). *30:* core features
partially work; several checklist items fail. *60:* M1–M4 solid,
later milestones patchy or failed on cap. *90:* every in-scope
milestone green, including platform-proof artifacts.

**O2. Correctness under grading — 7.** Severity-weighted defects the
grader finds beyond the checklist (crashes, wrong data, broken flows).
*30:* multiple high-severity defects in core flows. *60:* a few
medium defects off the happy path. *90:* only cosmetic nits.

**O3. Trust boundaries — 8.** Holdout-probe results: authorization
enforced server-side, not by UI absence. *30:* a probe reads another
user's private data. *60:* core reads protected; a secondary probe
(e.g., expired-window edit) succeeds when it shouldn't. *90:* every
probe correctly denied, including asset access after view-once/delete.

**O4. Observed offline behavior — 9.** What the offline acceptance
actually demonstrated, and honesty of any gap between claim and
guarantee. *30:* cold-start offline shows an empty or broken app.
*60:* reads work; offline writes lost or mis-ordered, or receipts
wrong after flush. *90:* reads, ordered queued writes, receipt
transitions, and offline search all behave as specced on the native
proof — on full runs including M8's durable-queue restart and
multi-device convergence evidence.

**O5. Performance at the scale envelope — 8.** A **scale-safety
gate**, mapped by an exact function of the frozen invariants — never
a cross-backend speed comparison (deployment postures differ; see
the replay contract), never perceived feel; absolute latencies
publish as diagnostics only. Full-app runs only; the rubric-wide
"interpolate" instruction does not apply to O5. Function (the P3
decision table instantiates it against the frozen ceilings): **0**
if the invariant manifest does not conform or replay's cap was
exhausted; **30** if any degradation rule fails or any probe times
out/errors/OOMs; **60** if all rules pass but any ceiling is
exceeded or replay used >80% of its cap; **90** if every probe's
observed ceiling utilization is ≤50% and replay used ≤50% of its
cap; **75** otherwise (all rules and ceilings pass, 90's condition
not met). Bands evaluate **first-match in the order 0, 30, 60, 90,
75** — the function is total and unambiguous by construction. Each
degradation rule's measurable predicate (the p95 comparisons over
k=20 samples) is frozen with the probe set.

### Builder-scored experience (55)

**B1. Schema and data-model ergonomics — 6.** Declaring this app's
model: chats, membership, messages, receipts, reactions, posts, and
the follow graph with its feed read-models — on full runs including
M8's aggregate read-models (insights totals, 7-day buckets,
trending).
*30:* fought the model layer; workarounds encode the model in blobs
or duplicate state. *60:* workable with boilerplate or missing
constructs (e.g., no clean unique constraint). *90:* the model
expressed directly; constraints (handle uniqueness, DM dedupe)
enforced where declared.

**B2. Auth ergonomics — 5.** Real signup/login/sessions on this
backend. *30:* hand-rolled critical pieces (hashing, tokens) or
fought the built-in system into shape. *60:* built-in auth fit with
notable ceremony or docs gaps. *90:* secure-by-default flow wired
quickly; sessions and server-side scoping composed with the data
layer.

**B3. Realtime ergonomics — 6.** Live queries and ephemeral state
(typing, presence-ish). *30:* polling or hand-built channels for core
liveness. *60:* live data easy but ephemeral state needed a durable
workaround (tables + expiry jobs). *90:* both durable-live and
ephemeral expressed with purpose-built primitives.

**B4. Offline/sync authoring ergonomics — 7.** Effort to *author* the
offline behavior (distinct from O4's observed result). *30:* the
offline layer was built by hand (own cache, own queue, own conflict
handling). *60:* platform gives reads or writes but not both, or the
guarantees were hard to determine from docs. *90:* offline reads and
queued writes fell out of the platform with configuration-level
effort, and the docs stated the actual guarantees.

**B5. Media and storage ergonomics — 4.** Upload, serve, authorize,
and delete media, including view-once/tombstone asset denial. *30:*
CORS/auth/URL ceremony dominated; asset denial required hacks. *60:*
happy path smooth; access revocation awkward. *90:* policy-integrated
storage: upload trivial, per-recipient/one-view denial expressible
server-side.

**B6. Search ergonomics — 3.** Building the three search scopes with
the offline requirement. *30:* full client-side scan hand-rolled with
no help. *60:* server search easy but the offline requirement forced
a second parallel implementation. *90:* one coherent approach covered
online and offline search.

**B7. Push/actions ergonomics — 3.** Detecting no-connected-client
and emitting through the seam; on full runs, also authoring M8's
scheduled digest. *30:* no server-side hook existed;
polling or external infra required, or the digest needed an external
scheduler. *60:* doable with plumbing
(connection tracking or scheduling hand-built). *90:*
presence/connectivity, a notification seam, and scheduled server-side
work were first-class.

**B8. Day-2 evolution experience — 6.** Scored by the M7 session: the
schema-change-against-live-data loop. *30:* migration risked or
required manual data surgery; codegen/types fought the change. *60:*
migration worked but the workflow was undocumented or nervous
(no dry-run, unclear rollback). *90:* additive evolution was routine:
declare, migrate, types flow through, data verifiably intact.

**B9. DX, docs, setup — 6.** From zero to productive: install,
scaffold, dev loop, doc discoverability at point of need. *30:*
setup consumed a milestone's budget; docs missing or wrong. *60:*
productive after friction; some knowledge only in community sources.
*90:* first green proof fast; every needed doc was findable when
needed and correct.

**B10. Diagnostics and error quality — 4.** When things failed, did
the platform say why (LLP 0193's errors-as-docs bar). *30:* opaque
errors; debugging by bisection. *60:* accurate but shallow errors;
root causes needed digging. *90:* errors named the actual cause and
pointed at the fix or doc.

**B11. Operations and maturity — 5.** Running, inspecting, and
trusting the backend during development: data inspection, logs,
resets, lifecycle. *30:* opaque runtime; state inspected by writing
code. *60:* adequate basics, gaps in inspection or lifecycle. *90:*
productized dev operations: console/CLI inspection, clean resets,
trustworthy lifecycle.

### Holistic (builder, non-formulaic)

One 0–100 for "what was this experience actually like," explicitly not
computed from B1–B11, recorded before any totals are visible, with 2–3
cited moments. Divergence between holistic and weighted totals is
signal, not error — report both.

## Narrative artifacts

Per lane: a run diary (`diaries/` convention) with a timestamped entry
at each milestone boundary, and a 1–2 page closing essay — purely
qualitative, comparing the backend against alternatives the model
knows — written before any metrics are visible.

## Budget caps and performance ceilings (placeholder — set at P3 from pilot)

Cap keys, formulas, and fallbacks: see the Budgets paragraph in
the Milestones preamble (the single authority). At P3 this table
grows one row per milestone, with one token-cap column per cap
family.

| Milestone | Wall cap | Token cap |
|---|---|---|
| M1–M7 | *pilot-calibrated* | *pilot-calibrated* |
| M8 | *P2b-extension-calibrated* | *P2b-extension-calibrated* |
| Scale replay (own clock) | *pilot-calibrated (rerun after the M8 scale-log regeneration)* | n/a |

| Performance probe | Absolute p95 ceiling |
|---|---|
| *per rotated probe set* | *pilot-calibrated* |

## Lane-prompt block (placeholder — instantiated at freeze)

The verbatim per-lane prompt is instantiated at P3 freeze from this
brief plus the kit/fixture versions and budget caps, and recorded here,
following the messaging brief's convention.

===== END VERBATIM FILE instrument/social-messenger.md =====


===== BEGIN VERBATIM FILE lanes/astra-snapback2/diary.md | 13474 bytes | SHA256 eb75206ec4d2815f2af115afb405e3941c3478b634fd01d532988acd14e7aefb =====

## M1 — accounts and profiles
Built real password signup/login, persistent browser/native token stores, public live profiles, all profile fields and fixture avatar upload, using the frozen kit and Expo Router. The package scaffold, built-in identity, unique indexes, and generated mutation types were straightforward. The scaffold was not Router-based, so integrating navigation and the kit took ordinary client work. Asset URLs carry no auth: resolving protected bytes to a blob URI was necessary for the kit's Avatar. Setup-identity path constraints caused two harness startup retries; a visible generic requirement message also needed its code exposed. Familiar React and browser-test patterns saved time; no prior Snapback implementation was used. Compared with familiar Convex workflows, auth required fewer dependency decisions; compared with Supabase, the query subscription was less manual. This is local M1 evidence, not a comparative benchmark of those alternatives.

## M2 — posts and follow graph
Built text/image/video posts, global/following feeds, original-versus-repost entries, direct reply threads, likes, follows, public counts, profile post lists, and pagination. The bounded merge and maintained counts fit the model well, and asset arguments accepted fixture Files without a separate upload endpoint. A 1,000-follow merge exceeded the 4 MiB closure budget; the specified 500-follow envelope compiled, leaving a documented broader-limit gap. Quarry's explicit index selection and `read <- allow` grammar needed diagnostic-driven corrections. Replacing indexes required an explicit reviewed successor migration. Metro crashed watching a transient compiler directory, resolved by excluding generated paths. Most browser friction was mine or kit integration: persistent tabs, actual video thumbnails, and mirroring semantic props that React Native Web dropped. Running diagnostic suite and choreography concurrently displaced target posts and was corrected to serial verification. Prior React/SQL index knowledge helped, but did not substitute for learning Quarry's proof bounds. Compared with Convex, bounded-query design is more explicit; compared with Supabase, live feeds required less subscription plumbing but more compile-time query budgeting.

## M3 — messaging core
Built unique DMs, separate group entities, admin membership controls, live messages, quoted replies with cross-platform jump plumbing, typing channels, and per-recipient delivered/read records based on membership at send. Public identity and scoped membership rules composed cleanly. The package's typed expiring channel was particularly direct. Query-budget diagnostics pushed full profile joins out of nested chat-list rosters. My nullable unique-key design initially blocked a second DM; adding the stable peer principal to the unique address fixed it. Browser full navigation canceled a removal request; verified server state exposed the real cause, and mutation keepalive made the required cutoff proof pass. The default harness receipt group includes an unopened Erin; the documented fixture adapter instead exercises an actual Alice/Bob/Carol trio, with the default-instance instrument skip recorded explicitly. Native simulator proof is unavailable; only Hermes export is claimed. Familiar membership/index modeling helped; the compiler's uniform-read restrictions were new. Compared with SQL/RLS, policy and live reads stay in one model; compared with Convex, query-budget admission is more visible and sometimes more demanding. The scaffold already declared messageCounts; this is recorded for the later fresh-session M7 migration accounting, not claimed as M7 work.

## M4 — media, reactions, edit/delete
Built image/video messages using the same typed asset path as posts, inline playback, any-emoji reactions with idempotent set/clear/replace, caption/text editing and deletion tombstones. Server mutations enforce windows generated from the fixture configs using Quarry's server `now`; deletion clears asset cells and an independent fetch test verifies refusal. The UI and provider seam stayed small because assets are schema values, not manually signed storage URLs. `count(text)` was not a supported expression, so the server checks a caption against its first 500 scalars instead. Typing/reactive receipt work from M3 carried forward. A separate real elapsed-time late-edit probe is running after authoring green; its result will be recorded without changing the first-green boundary. Compared with storage-plus-database combinations, cell ownership made revocation much less procedural. Compared with a general TypeScript backend, the small expression vocabulary still creates occasional syntax detours.

## M5

Built view-once media, server-scheduled disappearance, chat customization, indexed people/message search, and warm-offline search. Suite and frozen choreography are green, including a real three-minute expiry with closed clients and purge on relaunch. Hermes exported on Linux; no native simulator claim.

Search indexes and row timers felt direct. Durable cache integration fought me: I initially acknowledged whole history pages repeatedly, then added computed joins to the drain, and briefly rendered stale history before removal catch-up. The published guide's raw delivery drain and indexed pending-receipt watcher supplied the right structure. React Native Web also omitted selected button semantics and placed image URLs on nested nodes; app-level semantic bindings fixed the frozen harness contract without editing the kit. Full-document navigation outran durable admission for settings, so online settings use the SDK's headless arm with keepalive while messages retain the durable store.

Prior familiarity with React lifecycle, browser navigation cancellation, and server-owned TTLs saved time. The distinction between a readable cached answer and an authoritative completed drain needed more attention than a conventional query cache. Compared with Convex, delivery retention and byte revocation are more integrated but have a steeper client-state vocabulary. Compared with Supabase, I wrote substantially less replication infrastructure, while accepting stricter query certification and its diagnostics. No source checkout was consulted.

## M6

Built SDK-owned pending message bindings, durable web/native provider setup, a no-network logged push seam driven by connected-client presence, a documented headless API and runnable demo, and an adapter for every frozen action verb. The suite proves push text/once-photo previews, issuance and logout revocation, API paging/send/polling, and the 50-action conformance sample against actual backend state. The web offline choreography passes two pending writes, FIFO arrival, and normal read receipts. Hermes exported; Apple simulator proofs remain explicitly unavailable on Linux.

The pure-create mutation target requirement was useful but surprising: inserting then updating an expiry field made the create binding a create/update union. Computing the deadline before insertion resolved it. An ordinary React draft race erased the user's second offline draft; that was my error, not the backend's. Source transitions between live history and retained delivery history needed a small in-memory display buffer until explicit removal. The durable outbox itself stays in the SDK.

The enriched history API hit a large certified closure bound for nested reaction and receipt data. One-message enriched pages compile and remain fully pageable, but this is a real ergonomic/performance tradeoff compared with a conventional SQL join endpoint. The session docs state expiry behavior without an exact TTL or expiry field; API.md is candid about that. The published SDK made the replay adapter straightforward and kept real signup and mutation paths in the proof. Against Supabase I avoided writing a durable client queue; against Convex I gained byte custody and delivery retention but spent more effort understanding admissible mutations and query readiness. Scale execution has its own clock and is not yet claimed successful at this boundary.

## M8 — Insights, digest, and multiple offline devices

I built maintained totals and seven UTC day buckets, a rolling 24-hour Trending index, scheduled private digests with period idempotency, and two-device offline convergence. The digest proof closed every client, checked an inactive account and a private chat exclusion, restarted the backend in the middle of a period, and waited for the next inactive period. It passed on the real shortened clock. The fresh M8 scale replay also reached the frozen final counts. Native simulator proof is unavailable on this Linux host; the Hermes bundle is a separate artifact.

Maintains made the small authoritative Insights response straightforward once the schema matched the intended grouping. The counter state could be verified independently against rows. What fought me was the difference between an authoritative server aggregate and a partially downloaded local evaluation. I ended up using an online client for aggregate reads and a durable client for message custody. That distinction was also decisive in the final offline regression: a compacted receipt queue could leave the durable inbox snapshot stale. An authoritative live inbox now reconciles removals and supplies the latest delivered message cards while history refreshes.

Digest work was much more involved than the display suggested. Certified bounds required compact per-period counters, multiple job stages, and membership-incarnation checks. My original account membership cap did not fit the scale fixture's 1,000-chat hub. That was my modeling error, diagnosed by the replay, not a platform failure. Increasing the cap then exposed query shapes that needed different bounds. The restart proof was valuable because a manually invoked digest mutation would not establish the required behavior.

Prior familiarity with transactional counters, idempotent effects, React state retention, and offline optimistic identity saved time. Prior familiarity with SQL would not have supplied Quarry syntax or its cost proof rules. The published diagnostic often gave enough information to make the next edit, but calendar scheduling, a direct observed-query refresh handle, and a clearer recovery story for compacted drained snapshots would have reduced the search. A supplementary scale owner became unresponsive after source refresh; restarting its exact PID recovered it after a temporary store-ownership refusal. I have left that attribution ambiguous.

Compared with Convex, the main gain was a backend-owned delivery/custody model and an integrated offline carrier; the cost was having to understand more visible authority states. Compared with Supabase, authorization and maintained aggregates were closer to the application's query program, while bounded fan-out required more explicit schema machinery than an ordinary indexed SQL query. These are experience-based comparisons, not measurements of competitor builds in this run. The final pass remains candid about the Linux-native gap, performance measurements, and places where the client is still shaped like a benchmark-sized production prototype.

M8 verification coda: the full expiry regression subsequently found a stale-delivery resurrection after adding inbox rows as a history fallback. I fixed the application custody reducer to retain the highest backend delivery sequence per message. A lower-sequence cached card can no longer clear a newer removal. This was an application integration error. The follow-up clean sync completed without timeout; its peak heap was large, while an explicit post-settlement GC diagnostic showed substantially lower retained heap. These are separate observations, not a claim of long-running memory stability. Literal midpoint interpolation also produced two small scale-envelope misses; the final report preserves them rather than applying an unannounced noise tolerance.

The last two-device diagnostic also exposed the cost of mounting a receipt query and a reaction query on every bubble. Under the accumulated development corpus, admission/render and a later flush could exceed the choreography deadline. I replaced those observers with a certified composite read covering sixteen message IDs per subscription. Pending drafts now appear immediately under the same stable author/key identity used by the durable SDK, with explicit rollback on refusal. The three-client diagnostic then converged. This correction follows the guide's advice to use composite list reads; it is not evidence that the platform cannot express the feature.

Final M8 boundary: M3 retained-history, M5 timed-expiry, M6 offline/push/API, and M8 multi-device checks are green. The final display path uses a server-clock anchor and server-issued `expiresAt` in addition to native removal events; this closes the cached-expiry visibility race without treating loss of read permission as deletion. Browser connectivity events now drive the durable SDK's transport controls. Temporary app telemetry was removed. The final cold-sync receipt, Hermes bundle, and type check pass. A supplemental package-native test invocation certified the operations but blocked its unseeded derived checks and exposed an uncontrolled internal ephemeral test-owner command; that port/PID audit exception is recorded separately and is not hidden behind the external green bar.

===== END VERBATIM FILE lanes/astra-snapback2/diary.md =====


===== BEGIN VERBATIM FILE lanes/astra-snapback2/essay.md | 9471 bytes | SHA256 7e24b16e724eb6df9c8ddf991548782096821e5bbf020df1c888a747e45163ed =====
# Building Clique with the published Snapback 2 package

I wrote this account after the continuous milestones reached their required web proof bar and before tallying the run's line counts, correction counts, or milestone timings. It describes one cold build using the published, pinned package and its guide and types. I did not inspect another implementation or a Snapback source checkout. Comparisons with Convex and Supabase come from general engineering familiarity; I did not build those alternatives alongside this app or measure their current products here.

The most consequential difference was that the backend did more than store rows and push updates. It exposed a model for which client could hold which facts, what an offline write had actually accomplished, and when downloaded history was sufficient to support a screen. That model helped express a messenger's hard requirements: membership-scoped delivery, disappearing content, receipts, and writes that survive disconnection. It also made several states visible that a conventional online application can accidentally ignore. A committed mutation, a downloaded row, a locally evaluated result, and a live authoritative result were distinct things throughout this build.

The first social screens were relatively direct. Schema rules, operations, generated references, and React hooks formed a short path from a data model to a working feed. I did not need to build an HTTP routing layer or keep a second collection of request DTOs synchronized with the backend. Generated types caught mismatches while the compiler explained several invalid query shapes. This resembles the benefit I associate with Convex: the application can concentrate on authenticated operations and reactive data instead of writing transport glue. The important difference here was that the backend language was Quarry, so ordinary TypeScript fluency did not remove the language-learning cost.

Quarry's bounded execution model strongly influenced the schema. A query was not accepted merely because I expected the database to handle the fixture. It needed a certifiable bound for its scans, nested results, and output. Sometimes that was a welcome early warning. It discouraged a hidden full-table scan behind an innocent-looking count or a growing fan-out behind a post. At other times it turned a simple product statement into a design exercise involving maintained counters, explicit caps, narrower projections, and staged jobs. A compiler refusal could be more useful than a slow benchmark result, but it was still work that had to be done before the feature existed.

With Supabase and PostgreSQL, my first instinct would have been to express more of these operations as joins, grouped queries, indexed lookups, and perhaps database functions protected by row-level security. That vocabulary is familiar and allows substantial freedom to try a query before committing to a read model. Snapback moved part of that optimization decision earlier. Insights became a small maintained summary rather than a server scan that happened to be fast today. Trending became a maintained rolling index with scheduled expiry. Those are reasonable production shapes, but their correctness depends on every relevant transition updating the right state. The compiler constrains the work; it does not decide the product's counting semantics for the author.

Messaging made the integrated approach more valuable. Membership rules were shared with the operations that delivered and exposed messages. Capturing a membership incarnation mattered: leaving and rejoining should not silently revive an old receipt obligation. Images, video, and view-once assets also benefited from a platform-level asset model. The client did not simply receive a permanent public URL and hope that the interface would stop displaying it after deletion. Authenticated asset access and view-once consumption were separate from showing a preview. I still had to integrate the web and Expo rendering paths, handle uploads correctly, and verify the actual fixture bytes or normalized pixels. The primitive reduced backend glue; it did not eliminate media product work.

Offline behavior was the part that most changed my implementation habits. I normally start with a server query result and add optimistic state around it. Here the durable client already had an outbox, retained reads, local prediction, and reconnection behavior. Stable message identity remained an application responsibility. A pending message and its committed row needed to reconcile without duplication or disappearing during a transient partial query. The screen also had to retain known profile and history data through hydration rather than replacing the entire conversation with a loading branch at the wrong moment. Those were my React integration mistakes, and the browser choreography exposed them more effectively than a mutation-level assertion could.

The late regression was particularly instructive. A page reopened after a message expired, and receipt compaction left the durable inbox reporting downloaded but stale data. The guide explained that older snapshots need refreshing, but the observed-query surface did not present a simple refresh method. Reopening a live observer and distinguishing authority from downloaded coverage took investigation. I ultimately retained the durable carrier for offline work and added an authoritative live inbox observer for reconciliation. That observer supplies removal events and newly delivered cards while durable history catches up. This is a concrete cost of a rich client model: the state vocabulary is useful, but applications need an equally clear recipe for moving through all of it.

Compared with a conventional Supabase application, this was substantially less custom offline infrastructure than I would expect to write from scratch. Compared with my general understanding of Convex's reactive online programming model, Snapback put durable offline custody much closer to the central abstraction. I cannot conclude from this run that either competitor would have been faster or slower overall. Familiarity would strongly affect that outcome. I can say that the offline work here was mostly about using and reconciling provided mechanisms, rather than inventing a persistent mutation ledger, replay transport, and row-authorization cache from nothing.

The digest looked small in the brief and became a serious backend exercise. Correctness meant more than scheduling a callback. Counts had to exclude unauthorized conversations, distinguish current membership from an earlier incarnation, suppress inactive users, and remain exactly once across restart. The bounded compiler pushed me toward compact period counters and multiple stages. I then proved the actual scheduled behavior with clients closed and a real backend restart; manually calling the digest operation would have missed the central obligation. A missing calendar-style schedule meant that the period boundary and the dispatch cadence had to be treated separately. That limitation belongs in the report, even though the shortened-clock proof passed.

The scale replay was useful because it challenged assumptions that small starter fixtures did not. My original per-account conversation cap was wrong for the hub persona. The diagnostic was precise, but the correction had consequences for global search and digest bounds. A bounded search across ordinary accounts and a paginated per-chat merge across the large hub are different client paths. Likewise, cheap authoritative Insights should not be replaced by downloading the corpus and counting it in JavaScript. Replaying the full fixture into isolated instances and checking independent invariants made those distinctions reviewable. Supplementary browser and deep-page probes were necessary because a fast headless endpoint alone cannot establish a healthy client startup.

Operationally, the package supplied a useful local owner, data inspection, trace, test, and diagnostic vocabulary. Staying inside the published surface was feasible. I nevertheless encountered an owner timeout after a post-replay source refresh and a temporary store-ownership refusal during recovery. Restarting the specific recorded process recovered it, but I do not have enough evidence to assign a definitive platform defect. The same restraint applies to the copied UI kit: its web accessibility compatibility edits were real edits and are recorded as such. They were not changes to the frozen choreography. Native simulator evidence was impossible on this host, and an iOS Hermes export cannot stand in for it.

The result is a working, extensively exercised application with a clear account of its remaining limits, rather than evidence that backend choice alone guarantees a production messenger. Snapback reduced transport, asset, authorization, and offline infrastructure work. It added language learning, cost-bound modeling, and client-authority reconciliation work. I would choose it most confidently when those integrated guarantees are central to the product and the team is prepared to design around certified bounds. For a team already fluent in SQL with modest offline requirements, the added model might be harder to justify. For a team seeking reactive application development, its closest appeal is the short typed path from backend operation to client, with offline custody as the distinctive additional commitment.

===== END VERBATIM FILE lanes/astra-snapback2/essay.md =====


===== BEGIN VERBATIM FILE lanes/astra-snapback2/run-log.md | 30997 bytes | SHA256 a1c453ce0a143636d2ee8daf7542670bd132ec373c7cc3577e42d94a35b91f60 =====
lane id astra-clique-snapback2
model gpt-6-astra
effort=medium
backend=snapback2-0.0.24
start=1789162624
1789162666 M1 start; orientation source=fixture evidence=instrument/ENVIRONMENT.md,instrument/social-messenger.md,instrument/CONTRACT.md,instrument/fixtures/action-schema.md,instrument/ui/README.md,instrument/choreography/README.md,instrument/protocol.md; host override=Linux ports=53100-53119
1789162666 knowledge lookup source=package README/guide evidence=node_modules/snapback2/README.md; exact npm pin installed
1789162729 error attribution=environment evidence=evidence/expo-install.log Expo install completed dependencies but requested manual dynamic-config plugin addition; workaround applied
1789162729 knowledge lookup source=package README/guide evidence=guide auth,guide assets,generated types; M1 uses built-in password auth and image column
1789162750 server PID=2606169 backend url=http://127.0.0.1:53100 evidence=evidence/owner-start.json
1789162812 server PID=2609782 Expo web port=53101 evidence=evidence/web.log
1789162881 retry attribution=environment initial background Expo process ended with shell; foreground managed session restarted; server PID=2610535 port=53101
1789162904 error attribution=agent-error evidence=evidence/m1-acceptance.log profile error showed generic message without code; include rejection code for useful duplicate-handle feedback
1789162934 error attribution=agent-error evidence=evidence/m1-choreo.log setup identity absolute path refused; retry with relative path
1789162985 M1 green evidence=evidence/m1-suite.json,evidence/m1-choreo.jsonl,artifacts/m1-ios; setup path retry resolved at lane root; M2 start
1789163102 M2 knowledge source=package README/guide guide rules,maintain,programs; diagnostics first-pass errors=maintain public unsupported/read true unsupported/index ambiguity; fixes read allow and named index. evidence=evidence/m2-check.log
1789163102 M2 error attribution=agent-error evidence=evidence/m2-seed.log,evidence/m2-owner-status.json; seed called before reviewed successor index replacement applied; migration reviewed and applied, retry
1789163102 M2 platform bound source=diagnostic attribution=snapback2-defect evidence=evidence/m2-bound-1000.log; 1000-follow merge closure exceeds 4MiB; 500-follow envelope compiles; bound beyond 500 remains limitation
1789163220 correction-loop attribution=ambiguous evidence=Metro ENOENT watch .snapback/build/tests.replaced-2631661-1789163121280; previously running Expo crashed on generated-directory replacement; exclude generated paths and bound workers, restart
1789163390 M2 errors attribution=agent-error evidence=evidence/m2-choreo.log; harness needs feed tabs reachable on profile; move tabs to shell. attribution=environment kit accessibilityValue stripped by react-native-web; add equivalent aria-valuetext to copied kit props, preserving presentation
1789163390 M2 error attribution=agent-error evidence=evidence/m2-acceptance.log; headless query returns state complete/capped, unlike hook status; test helper corrected from generated contract
1789163421 server PID=2692144 Expo restarted port=53101 evidence=evidence/web-m2.log; diagnostic harness PIDs=2706427,2736582 stopped explicitly because overlapping M2 runs shared receipt path; attribution=agent-error; invalidated overlapping receipts and rerun serially
1789163497 M2 error attribution=agent-error evidence=evidence/m2-choreo-final.log; kit video attachment expects image poster; generate actual selected-video first-frame thumbnail on web; native poster remains optional
1789163514 M2 diagnostic invalidation: concurrent acceptance posts displaced choreography target beyond first page; attribution=agent-error evidence=evidence/m2-choreo-final.log. Subsequent suite/choreo runs must be serial.
1789163573 M2 diagnostic harness PID=2739893 stopped explicitly after video and displaced-post failures were diagnosed; snapshot evidence=m2-choreo-diagnostic.jsonl; final serial verification begins
1789163629 M2 correction-loop iteration attribution=environment evidence=evidence/m2-choreo-serial.log; conditional Avatar and repost identity props also require web aria-valuetext mirror; fixed copied-kit attributes
1789163778 M2 green evidence=evidence/m2-suite.json,evidence/m2-choreo.jsonl,artifacts/m2-ios; M3 start
1789163937 M3 knowledge source=package README/guide evidence=guide deliver,pagination,expressions,fn,proc; use typed channel ttl4s and server-held per-message recipient receipts; first-pass query bounds narrowed profile projection and chat-list roster preview to two seats
1789164079 M3 error attribution=agent-error evidence=evidence/m3-acceptance.log; optional null key participates in unique constraint, blocking second DM; changed group idempotency lookup to transactionally read indexed exact key, kept dmPairs uniqueness
1789164097 M3 instrument default-fixture skip evidence=evidence/instrument-gaps.md; group aggregate default quartet includes unopened Erin. Documented adapter selects suite-created Alice/Bob/Carol Proof Trio for real required browser assertion; original starter preserved.
1789164156 M3 correction iteration attribution=agent-error evidence=evidence/m3-check.log; nonunique scan alternative refused E_STRUCTURAL_FANOUT/E_STRUCTURAL_COUNT. Retained point uniqueness with additional stable DM peer principal component; compiled/applied successor.
1789164216 native artifacts M6/M8 unavailable/not-run: Linux host lacks Apple simulator evidence=evidence/simulator-status.json; no Expo web or Hermes artifact substituted
1789164260 M3 error attribution=agent-error evidence=evidence/m3-choreo.log; group adapter URL encodes literal title, route expected slug; normalize route input. Normal client group navigation now uses opaque ID so equal-name groups remain distinct.
1789164338 M3 first-pass native quote-jump shared scroll container JSX syntax error fixed before typecheck/export; attribution=agent-error evidence=evidence/m3-typecheck.log,evidence/m3-ios.log
1789164549 M3 correction-loop attribution=agent-error evidence=evidence/m3-choreo-stable.log,evidence/m3-remove-diagnostic.log; browser full navigation canceled pending memberRemove; post-failure server roster still Dave admin. Mutation fetch keepalive added; explicit settled browser removal succeeds.
1789164655 M3 green evidence=evidence/m3-suite.json,evidence/m3-choreo.jsonl,artifacts/m3-ios; documented default-fixture skip/adapter evidence=evidence/instrument-gaps.md; M4 start
1789164817 M4 knowledge source=package README/guide evidence=guide expressions,assets,schedule; config generator reads frozen window files into server Quarry constants. First-pass errors: Quarry comments use --; count(text) unsupported, replaced caption length check with body=slice(body,0,500). attribution=agent-error
1789164895 M4 green evidence=evidence/m4-suite.json,evidence/m4-choreo.jsonl,artifacts/m4-ios; independent real-time edit-window probe still running evidence=evidence/m4-window-probe.log; M5 start
1789165007 M4 independent server-time verification pass evidence=evidence/m4-window-probe.json
1789165007 M5 knowledge source=package README/guide evidence=guide expiry,offline; first-pass diagnostics text concatenation unsupported, split profile name/handle queries; global message-search 100-chat full-body merge exceeds closure limit, bounded 200-scalar snippets preserve full indexed matching. attribution=agent-error evidence=evidence/m5-search-bound.log
1789165665 M5 correction agent-error: durable FIFO congested by redundant mark receipts on every navigation; project own receipt and skip already-received/read. Evidence evidence/m5-network-diagnostic.log; lookup source package README/guide offline.md and public client types.
1789165696 M5 correction agent-error: receipt projection exceeded 1MiB output (1051862); narrowed quoted excerpt to 200 scalars; nullable slice required ?? default. Evidence evidence/m5-receipt-check*.log; source diagnostic.
1789165931 M5 correction environment: React Native Web drops selected state on frozen kit button roles. Both clients show real updated checkmark but harness requires aria-selected/pressed; added app-owned DOM semantic binding from server state, no kit or harness edits. evidence/m5-color-diagnostic.log. Earlier diagnostic q.head optional access error was agent-error, evidence/m5-query-diagnostic-2.log. Narrowed delivery pages to40 because slice bound remains conservative.
1789165962 M5 retry: stopped choreography PID2924368 parent2924361 after diagnostic HMR contaminated observations; restart on stable app. attribution agent-error evidence/m5-choreo-receipts.log
1789165985 M5 stable verification in progress; knowledge lookup source package README/guide effects/live-query/deliver and fixture action-schema/README for next milestone planning. Evidence installed published docs; no source repository.
1789166210 M5 retry agent-error: stable run found inline viewer ID collision and background wrapper lacked observable state; expiry config not admitted before full document navigation. Server probe confirms disappearing=null and expiresAt=null, so stop PID2933950/2933942 and fix before rerun. evidence/m5-choreo-stable.log,evidence/m5-background-diagnostic.log
1789166263 M5 correction verified: settings online write uses public headless client and keepalive; immediate full-document navigation preserves committed 24h setting. Messages retain durable provider. Evidence evidence/m5-settings-navigation.log, server query recorded24h; adapter wait190000 matches real180000 expiry config.
1789166678 M5 correction agent-error: gate until delivered log catches up; first gate reset on twin refresh, fixed. Inbox projection contained computed receipt/profile joins causing partial local reevaluation; simplified to native delivery metadata plus raw message and dedicated indexed pending-receipt watcher per published guide. evidence/m5-custody-diagnostic.log,evidence/m5-drain-check.log; source package README/guide live-query/deliver.
1789167033 M5 green evidence=evidence/m5-suite.json,evidence/m5-choreo.jsonl,artifacts/m5-ios; M6 start
1789167842 M6 correction loops agent-error: create binding required pure insert, ReceiptTicks uses receiptPending; composer async completion erased next draft; usePage source transitions briefly removed already-rendered rows, now retain disclosed rows in memory until authoritative removal. evidence/m6-items-typecheck.log,evidence/m6-offline-diagnostic.log,evidence/m6-order-diagnostic.log. API bound 31MB heap required one-message rich pages. Source diagnostic/package guide; evidence/m6-api-check*.log. Sample50 schema and all13 actual-state classes pass.
1789167911 M6 green evidence=evidence/m6-suite.json,evidence/m6-choreo.jsonl,artifacts/m6-ios; native simulator unavailable Linux per evidence/simulator-status.json. Scale execution follows on own clock.
1789167936 Scale server started PID3113906 port53102 isolated project replays/scale; only authored source cloned, fresh empty owner, exact package0.0.24, replayMode=true. Evidence evidence/scale-dev.log. Scale replay start follows evidence/scale/clock.jsonl.
1789168068 M8 start; M6 authoring green. Independent scale execution remains active against isolated port53102; development instance M8 work cannot alter its cloned source/store.
1789168583 Scale 10% checkpoint verified exact manifest counts and named fixtures; non-scored probes recorded evidence/scale/verification-10pct.json. M8 corrections agent-error: schedules need optional time; Quarry arrays only scalar, seven-day response now named day records; digest maintained post-period key closure6180488>4194304 replaced with compact transactional table. Receipt cleanup changed to scoped membership walk and membership-incarnation unread counts. evidence/m8-insights-check*.log,evidence/m8-digest-check*.log.
1789169282 M8 correction-loop attribution=agent-error: reports incorrectly accepted partial local twin counters; use authenticated online queries for load/refresh. Shared display buffer now deduplicates provisional and authoritative rows by author+stable key; real desktop chat sidebar exposes unread state and live account convergence. RN Web toggle semantics mirror server state. TypeScript observePages loadMore belongs to snapshot, fixed. Evidence=evidence/m8-choreo-online.log,evidence/m8-typecheck.log. Fixture retry requires fresh unliked Alice witness after each consumed attempt. Scale 50pct invariant verification PASS evidence=evidence/scale/verification-50pct.json
1789169303 M8 suite/choreography/Hermes PASS evidence=evidence/m8-suite.json,evidence/m8-choreo.jsonl,artifacts/m8-ios; scheduled real-clock proof still running before milestone boundary.
1789169315 M8 digest proof retry attribution=agent-error: authorization correctly returned denied, proof expected refused; fixed assertion, no backend change. evidence=evidence/m8-digest-proof.log
1789169315 M8 digest-proof all clients closed; awaiting autonomous period 1789169280000..1789169400000 evidence=evidence/m8-digest-proof.json
1789169403 M8 secondary scale server PID3778175 port53103 fresh replays/scale-m8 source copy replayMode=true. Correction attribution=agent-error: raw binary dev misses compiler worker E_OWNER_NO_COMPILER, use public npx wrapper. Stopped proof PID3721870 before backend restart to correct same invocation. Evidence=evidence/scale-m8-dev.json,evidence/scale-m8-check.log,scripts/digest-proof.mjs
1789169403 M8 digest-proof all clients closed; awaiting autonomous period 1789169400000..1789169520000 evidence=evidence/m8-digest-proof.json
1789169450 knowledge source=fixture: protocol.md, social-messenger M8/envelope, run-record base/composed schemas, metering README and unavailable adapter/composer. Native usage stream is not exposed within authorized lane; will use explicit unavailable/null accounting, no reconstructed token claim. source=package README/guide offline.md drain/custody. Evidence=instrument/protocol.md,metering/README.md,node_modules/snapback2/dist/guide/offline.md
1789169458 correction attribution=agent-error: accidental empty scratch file /tmp/nope created outside lane by a stray heredoc; immediately removed exact file. No external files inspected. All substantive work remains in lane.
1789169597 M8 correction-loop attribution=agent-error: real schedule fires on installation-offset minute, proof 20s poll shorter than observed42s offset; expand to90s and record calendar-syntax limitation. Schedule diagnostic additionally exposed expiry E_REQUIRE:NOT_FOUND at messages.q:71:5 because point delete refuses absent digest custody; guard optional deletions, including old message mark-read. Evidence=evidence/m8-digest-schedule-logs.json; source=package README/guide schedule.md,diagnostic. Regression required M4/M5/M6.
1789169598 M8 digest-proof all clients closed; awaiting autonomous period 1789169520000..1789169640000 evidence=evidence/m8-digest-proof.json
1789169683 M8 digest-proof first autonomous digest correct; zero-activity and private-chat exclusion correct evidence=evidence/m8-digest-proof.json
1789169700 M8 digest-proof recorded server PID 2606169 before exact-project graceful stop evidence=evidence/m8-digest-proof.json
1789170020 M8 scale retry attribution=agent-error: fixture hub u0001 has1000 conversations, cap100 rejected action8145. Added maintained membership cap count; digest1000 loop exceeded E_BOUND heap12713686/8388608 and closure limits, repaired using compact period cells plus separate post aggregation and atomic current-membership emission chunks. Main server recovered PID4108440 port53100 after in-progress proof restart encountered invalid authoring source. Single-query1000-lane search E_BOUND heap20356901/8388608 closure31701617/4194304; will use client merge of bounded server lanes. Evidence=evidence/scale-m8-replay.log,evidence/m8-thousand-memberships-check.log,evidence/m8-split-digest-check.log,evidence/m8-search1000-check.log
1789170042 M8 digest-proof all clients closed; awaiting autonomous period 1789170000000..1789170120000 evidence=evidence/m8-digest-proof.json
1789170163 M8 digest-proof first autonomous digest correct; zero-activity and private-chat exclusion correct evidence=evidence/m8-digest-proof.json
1789170180 M8 digest-proof recorded server PID 4108440 before exact-project graceful stop evidence=evidence/m8-digest-proof.json
1789170181 M8 digest-proof server restarted PID 119451 port53100 mid-period evidence=evidence/m8-digest-proof.json
1789170305 M8 digest-proof pass evidence=evidence/m8-digest-proof.json
1789170359 M6 scale complete own-clock start=1789167936 end=1789170317; exact invariant manifest verification PASS at10pct/50pct/final; 167244 actions. Evidence=evidence/scale/clock.jsonl,evidence/scale/verification-final.json. M8 scheduled digest real-clock/restart proof PASS evidence=evidence/m8-digest-proof.json. Server currentPID119451 port53100.
1789170456 M8 corrections attribution=agent-error: new digest counter requires compact authorized read rule and maintained cap count; optional cleanup repaired and15 previously-rejected expired rows reaped by exact operator calls. source=diagnostic,package README/guide maintain/job/fanout. Evidence=evidence/m8-expired-repair.json,evidence/m8-final-digest-check.log. Expanded global search uses per-chat paginated head merge for1000-chat hub after unsupported dynamic merge E_QUARRY_SYNTAX and held_search E_ARGS_TYPE; normal100-chat bounded server query retained. Evidence=evidence/m8-search-batches-check-final.log,evidence/m8-search-batches-check-3.log,src/useLargeSearch.ts.
1789170733 audit correction attribution=environment: copied UI kit has eight accessibilityValue-to-aria-valuetext compatibility patches from early milestones, not byte-identical source. Frozen instrument/ui input remains unchanged. Patches preserve existing props, values, visuals, and native accessibility; app-only aria-pressed mirrors supplement them. Exact diff=evidence/ui-web-compatibility.patch. No choreography changes.
1789170838 regression M4/M5 suite+choreography PASS. M6 immediate post-browser push assertion missed while presence was settling; later owner subscriptions0 and precondition-probed retry passes. Added operator presence wait before disconnected push arrangement; no push behavior change. Attribution=ambiguous (browser-close/presence settlement boundary), evidence=evidence/m6-regression-suite.log,evidence/m6-regression-owner.json,evidence/m6-regression-suite-retry.log. M6scale named media12 normalized-pixel/video-byte checks and actual50-message page50 envelope pass, evidence=evidence/scale/media-verification.json,evidence/scale/deep-history.json.
1789171726 M6 post-M8 regression correction loops attribution=agent-error: sequential diagnostic passed but concurrent navigation reproduced permanent Synchronizing message history with queued sends already delivered. Initial composer gate tested connected only, allowing input during reconnecting before custody-ready; gate now waits in both online states and permits truly offline cached use. Authoritative inbox receipt filtering prevents partial twin null joins from becoming removals. Pending/committed rows retain stable logical React keys and known profile stays mounted. Read receipt effect tracks late-arriving receipt coverage. Prior buffer-only/sticky-profile attempts did not alone resolve; exact evidence=evidence/m6-parallel-body.log,evidence/m6-parallel-gated.log,evidence/m6-regression-choreo-buffer.log,evidence/m6-regression-choreo-retained.log. M8scale50pct exact invariant and Insights/Trending probes PASS evidence=evidence/scale-m8/verification-50pct.json.
1789172197 M5 cached-reopen regression exposed over-strict readiness requiring a server-source receipt in the same snapshot as caughtUp/live. Package guide documents caughtUp exhaustion + live tail as the completion contract; readiness now uses those flags, accepts native removal metadata, and ignores null local joined bodies until authoritative. M6 choreography passes again. Attribution=agent-error evidence=evidence/m5-regression-choreo-gated.log,evidence/m6-regression-choreo-caughtup.log; source=package README/guide offline.md. Receipt active vectors now compare captured membership identity, with remove/rejoin negative proof PASS evidence=evidence/m8-receipt-incarnation.json.
1789173358 M8 scale final invariant PASS all167244 actions, own start1789169404/end1789173075 including correction gap; latest authored backend applied only after invariant freeze for supplementary client probes. Evidence=evidence/scale-m8/clock.jsonl,evidence/scale-m8/verification-final.json
1789173488 M8 supplementary scale owner timeout after post-replay schema refresh; E_OWNER_RUNNING status probe did not answer; E_OWNER_START_TIMEOUT detached owner did not become ready within10seconds. Attribution=ambiguous, source=diagnostic evidence=evidence/scale-m8/celebrity-write.log,evidence/scale-m8/owner-after-apply.json,evidence/scale-m8/cold-sync.json. Restart exact recordedPID3778175, frozen final invariants preserved.
1789173738 M8 regression corrections attribution=agent-error: authoritative online inbox observer resolves durable-drain compaction/reopen gate; real M5 timed expiry choreography PASS evidence=evidence/m5-regression-choreo-online.log. M8 dual-offline convergence then exposed stale history missing delivered rows; custody now supplies latest50 delivered rows. Composite inbox first50 refused E_BOUND output1051862 exceeds1048576; reduce ascending drain chunk40 per diagnostic. source=package README/guide live-query/offline,generated types,diagnostic. Evidence=evidence/m8-regression-choreo-final.log,evidence/m8-inbox-composite-check.log,evidence/m8-inbox-composite-check-40.log.
1789173873 M8 green boundary: required suite and choreography pass; Hermes export produced; real autonomous digest restart proof passes. Native simulator unavailable Linux. Latest reconciliation regression checks and supplementary scale-client search continue before final report. Evidence=evidence/m8-regression-suite-inbox.log,evidence/m8-regression-choreo-inbox.log,evidence/m8-digest-proof.json,artifacts/m8-ios.
1789173873 essay written before final metric tally; source=model knowledge for qualitative competitor comparisons, current run evidence for Snapback experience; sha256=7e24b16e724eb6df9c8ddf991548782096821e5bbf020df1c888a747e45163ed evidence=essay.md
1789173954 M8 supplementary hub search first attempt timed out from durable partial-query path; correction uses authoritative online count/search while retaining durable queries offline; exported-client retry PASS 1000-conversation hub,20+20 distinct results,1157queryrequests,11.462seconds. Attribution=agent-error evidence=evidence/scale-m8/hub-search-first-refusal.json,evidence/scale-m8/hub-search.json. Scale latest backend restarted through documented --stop with recordedPID1573273.
1789174265 M8 late regression correction attribution=agent-error: inbox fallback allowed older cached delivered cards to clear a newer authoritative removal. M5 real-expiry regression failed visible-after-relaunch. Custody now compares backend delivery seq per row and ignores older snapshots. Evidence=evidence/m5-regression-choreo-final.log,src/Custody.tsx,evidence/m5-regression-choreo-sequence.log. M8 final-code scale cold sync54.894seconds, peak705741792bytes, post-settlement forced-GC heap169431472bytes; GC metric separate from sync timer, evidence=evidence/scale-m8/cold-sync.json.
1789174314 reporting knowledge lookup source=fixture instrument/protocol.md,instrument/schema/run-record.schema.json,metering/README.md,record-composer.mjs; native Codex rollout and external grader provenance unavailable in authorized lane. Base-schema builder record only, null tokens/toolUses, no synthetic driver/native clock identity. Evidence=evidence/metering-unavailable.json. Strict midpoint evaluation retains M6search and M8Trending misses evidence=evidence/scale/envelope-summary.json,evidence/scale-m8/envelope-summary.json.
1789174752 M8 diagnostics found pending admission/render and second flush exceeding15seconds as per-row observers multiplied. Explicit pending drafts preserve stable author+key identity during SDK admission and are removed on refusal. Receipt/reaction reads now batch16 message IDs into one certified composite query (50 recipient/reactor rows per message). Own dual-offline diagnostic now passes all3clients. Attribution=agent-error; source=package README/guide live-query warning against per-row queries, diagnostic. Evidence=evidence/dual-offline-diagnostic.log,evidence/dual-offline-draft.log,evidence/dual-offline-batched.log,evidence/m8-decoration-batch-check.log. Expiry server audit confirms recent test rows physically deleted; authoritative null body now purges even original delivered metadata and cached local values cannot override authoritative custody. Evidence=evidence/expiry-stored-diagnostic.json.
1789175066 M8 regression corrections attribution=agent-error: group memberRemove queued behind message work could be lost on immediate settings navigation; independent authenticated server roster still Dave admin after failed M3 check. Membership writes now use direct authenticated keepalive client, as settings already did. M3 suite restores genuine trio and proves all starter segments idempotent again. Suite adapter output now preserves shortened expiry configuration. Evidence=evidence/m3-regression-choreo-batched.log,evidence/m3-regression-suite-final.log,src/useGroupWrites.ts. Online composer gate now waits only for authoritative live inbox drain, not an earlier cached durable caughtUp flag; source=package README/guide deliver/offline/live-query, evidence=src/Messaging.tsx,evidence/m5-regression-choreo-online-gate.log.
1789175249 M5 real-expiry choreography PASS with authoritative-only startup gate; M6 and M8 choreography also PASS. M3 direct membership writes exposed retained-history regression: treating unreadable joined body as deletion erased departed-member history. Correction trusts only native kind=removed; local predictions never outrank authoritative event seq. Source=package README/guide deliver (changed refreshes, removed tombstones); attribution=agent-error. Evidence=evidence/m5-regression-choreo-online-gate.log,evidence/m3-regression-choreo-direct.log,evidence/m3-regression-choreo-retain.log,src/Custody.tsx.
1789175443 final M3 regression suite and choreography PASS, including membership add/promote/remove/readd/leave, retained history, live cutoff, receipt slowest-member, and quoted jump. Evidence=evidence/m3-regression-suite-retain.log,evidence/m3-regression-choreo-retain.log. Final deletion logic uses native removed events only; authoritative-only inbox gate prevents transient stale content before replay. Final M5 and M8 terminal verification remain active.
1789175505 supplemental snapback2 test --json returned blocked: certify57ops pass; derived rules/bounds/invalidation/replay/auth/effects blocked because snapback/seed.ts is empty and no native test journeys supplied. Required external acceptance suites remain separate. Source=diagnostic,package README/guide testing. Receipt declares internal command dev --foreground --port0; test --help exposes no port option and no isolated-owner PID was exposed. This unaudited ephemeral test-owner invocation did not honor the lane port pin; attribution=agent-error (invoked before checking isolation behavior), with package surface limitation. Tool documents isolated owner/store cleanup on exit. Evidence=evidence/final-platform-test.json,.snapback/receipts/1789175443811.json. No claim of complete PID/port audit for this internal invocation.
1789175697 M8 retry corrections attribution=agent-error: repeated own top/tie fixtures crowded Trending top10 and invalidated tie-order arrangement; suite now removes only prior authored witness likes before independent baseline. Failed terminal suite did not mean a backend ranking failure. New suite PASS evidence=evidence/m8-regression-suite-isolated.log; failed arrangement evidence=evidence/m8-regression-suite-terminal.log. Acceptance failure handlers now archive prior receipt and write explicit false status, avoiding stale-pass startup on future failed suite runs. Initial composer readiness now latches per conversation after history and write admission are ready; post-navigation offline handoff no longer precedes operation preparation. Evidence=src/Messaging.tsx,evidence/m8-regression-choreo-prepared.log.
1789176200 M8 intermittent handoff diagnostic: isolated and full own sequence pass; some frozen runs exceed10second offline convergence wait. Temporary app-owned telemetry serverPID1938993 port53105 captured connection flapping offline/connected and delayed recovering on browser network transitions. Instrumented frozen run passed; no harness edits. Web bridge now calls SDK offline/online once per browser connectivity event, not polling. Temporary client telemetry removed. Attribution=ambiguous for timing root cause, agent integration correction; source=public SDK types/guide offline plus own telemetry. Evidence=evidence/client-telemetry.jsonl,evidence/m8-choreo-telemetry.log,src/NetworkBridge.tsx,evidence/m8-choreo-network-events.log.
1789176717 M5 native-removal-only retry still exposed cached expired content after re-open despite physical server deletion. Added authenticated server-clock anchor with monotonic local elapsed time, deadline-triggered rendering removal in Conversation/Search, and orphan-draft exclusion when no durable queued work remains. This is display enforcement of server-issued expiresAt; backend timers and authorization remain the deletion proof. Attribution=agent-error, evidence=evidence/m5-choreo-network-events.log,evidence/expiry-clock-check.log,src/ServerClock.tsx,evidence/m5-choreo-clock.log. M8 browser network bridge latest M8/M6 choreography pass; no polling reconciliation.
1789176963 M8 green boundary: final M5/M6/M8 suite and choreography green after server-clock display expiry, orphan-draft exclusion, browser connectivity bridge, batched decorations, and membership keepalive fixes. M3 retained-history regression is green; M4 earlier regression green. Final Hermes export and typecheck pass. Native simulator unavailable Linux. Evidence=evidence/m5-choreo-clock.log,evidence/m6-suite-final-clock.log,evidence/m6-choreo-clock.log,evidence/m8-suite-clock.log,evidence/m8-choreo-clock.log,evidence/m3-regression-choreo-retain.log,artifacts/m8-ios. Final exported cold sync55.869seconds pass evidence=evidence/scale-m8/cold-sync.json.
1789177035 shutdown completed exact recorded PIDs119451,3113906,2117417,2692144,2691910,1482436,1938993; no pattern kills. Assigned53100–53119 listening-port check empty. Evidence=evidence/shutdown.json,evidence/ports-after-shutdown.txt. Base run-record schema validation and full coverage manifest validation passed; native metering/grading composition unavailable as documented.
end=1789177036

===== END VERBATIM FILE lanes/astra-snapback2/run-log.md =====


===== BEGIN VERBATIM FILE lanes/astra-snapback2/final-report.md | 16913 bytes | SHA256 39c2fe831e813af43e8963b9713166e627a16f95279ef3440ab287759a5c502e =====
# Clique — final build report

Lane `astra-clique-snapback2`; model `gpt-6-astra`; effort `medium`; backend `snapback2@0.0.24`. Start `1789162624`, report/shutdown end `1789177036`, total wall `14412` seconds.

M1 → M2 → M3 → M4 → M5 → M6 → M8 reached the required suite + implemented web choreography green bar. M7 was not run, as instructed. This is an ungraded builder result, not a claim that every performance or native proof passed.

## Milestone clocks and receipts

| Milestone | Status | Start epoch | Boundary end | Wall seconds | First combined green epoch | Seconds to first green | Suite / choreography |
|---|---|---:|---:|---:|---:|---:|---|
| M1 | green | 1789162666 | 1789162985 | 319 | 1789162956.675 | 290.675 | [suite](evidence/m1-suite.json) / [JSONL](evidence/m1-choreo.jsonl) |
| M2 | green | 1789162985 | 1789163778 | 793 | 1789163705.426 | 720.426 | [suite](evidence/m2-suite.json) / [JSONL](evidence/m2-choreo.jsonl) |
| M3 | green | 1789163778 | 1789164655 | 877 | 1789164601.032 | 823.032 | [suite](evidence/m3-suite.json) / [JSONL](evidence/m3-choreo.jsonl) |
| M4 | green | 1789164655 | 1789164895 | 240 | 1789164814.280 | 159.280 | [suite](evidence/m4-suite.json) / [JSONL](evidence/m4-choreo.jsonl) |
| M5 | green | 1789164895 | 1789167033 | 2138 | 1789166949.336 | 2054.336 | [suite](evidence/m5-suite.json) / [JSONL](evidence/m5-choreo.jsonl) |
| M6 | green | 1789167033 | 1789167911 | 878 | 1789167864.136 | 831.136 | [suite](evidence/m6-suite.json) / [JSONL](evidence/m6-choreo.jsonl) |
| M8 | green | 1789168068 | 1789176963 | 8895 | 1789169278.745 | 1210.745 | [suite](evidence/m8-suite.json) / [JSONL](evidence/m8-choreo.jsonl) |

Boundary wall includes the work recorded before advancing to the next milestone. First-green times come from preserved original segment summaries in `evidence/first-green/`; later M8 hardening and cross-milestone regression time is not silently removed. M1 also has 42 seconds of pre-milestone orientation after lane start. M6→M8 has a separately recorded replay setup interval. Work after the M8 boundary, including supplementary checks and this report, is included in total lane wall. No milestone reached its four-hour cap; no capability-failure chain occurred.

All suite-required assertions map through [coverage-manifest.json](coverage-manifest.json). Latest choreography counts and verification epochs are in [run-summary.json](evidence/run-summary.json). Starter commands exist for M1, M2 and M3; these are the only frozen starter segments. Stable mutation/message keys and existing-profile guards make repeated installation idempotent.

## Scale replays

- `scale`: start `1789167936`, final end `1789170317`, raw own-clock wall `2381` seconds; all **167,244** starter+scale actions settled and invariant checks at 10%, 50%, and final passed. [Clock](evidence/scale/clock.jsonl), [final invariants](evidence/scale/verification-final.json), [envelope](evidence/scale/envelope-summary.json).
- `scale-m8`: start `1789169404`, final end `1789173075`, raw own-clock wall `3671` seconds; all **167,244** starter+scale actions settled and invariant checks at 10%, 50%, and final passed. [Clock](evidence/scale-m8/clock.jsonl), [final invariants](evidence/scale-m8/verification-final.json), [envelope](evidence/scale-m8/envelope-summary.json).

M8 first rejected the 100-conversation cap after 8,144 actions. The corrected replay resumed idempotently in the same fresh instance, settled the remaining 159,100 actions, and kept the first start for the safety clock. Its raw wall includes that correction gap. Checkpoint probe exclusion durations are retained in each raw clock, rather than subtracted invisibly.

Both final invariant snapshots match 1,008 users/profiles, 50,228 posts, 100,015 messages, 1,002 conversations, 2,054 memberships, and all remaining manifest counts and named checks. Named media verification additionally compares decoded image pixels and original video bytes; view-once allowances are not consumed. Both replay instances produced zero replay push effects; M8 also produced zero replay digests.

**Strict envelope result: not all passed.** M6 global search midpoint was 4.407 ms against a 4.212 ms interpolation ceiling. M8 Trending midpoint was 48.122 ms against 47.607 ms. These remain failures under the literal published midpoint rule, despite small absolute differences. All recorded final 3× ratios passed. M8 global-search and Insights midpoint rules passed. No rotated holdout score is claimed.

The initial checkpoint busy-page probe used the rich custom API's one-item page. Separate [M6](evidence/scale/deep-history.json) and [M8](evidence/scale-m8/deep-history.json) probes verify the actual app history page size of 50 and page 50 at messages 2,451–2,500. [Celebrity write](evidence/scale-m8/celebrity-write.json) compares actual 900- and five-follower authors. Its 46 real probe posts were added **after** frozen invariant verification; the live M8 scale store therefore no longer has the exact frozen post count. No receipt was rewritten to hide that.

Latest clean 100-conversation app sync and heap samples: [cold-sync.json](evidence/scale-m8/cold-sync.json). The final exported client completed in 55.869 seconds, peaked at 636,609,816 observed heap bytes, and retained 179,462,420 bytes after explicit post-settlement GC. The forced-GC diagnostic is excluded from the sync timer. Earlier revisions and failures remain archived. Concurrent local regression traffic was present during this supplementary probe. The exported 1,000-conversation hub search loaded 20 results and 20 distinct continuations in [hub-search.json](evidence/scale-m8/hub-search.json). These are local non-scored diagnostics, not network-realistic or native measurements.

## Native and scheduled artifacts

Every milestone produced an Expo iOS Hermes export under `artifacts/mN-ios`; [hashes and byte headers](evidence/native-build-artifacts.json) identify the bundles. M6 and M8 simulator artifacts are **unavailable / not-run** because this Ubuntu Linux host has no Apple simulator. [Simulator status](evidence/simulator-status.json) is separate from these successful exports.

The real-clock [digest proof](evidence/m8-digest-proof.json) passed with all clients closed: correct counts, private-chat exclusion, inactive-account silence, exactly once across backend restart, and a following inactive period with no duplicate. The production configuration uses 08:00 UTC period boundaries but a one-minute installation-relative dispatch cadence; it does not promise exact 08:00:00 delivery.

## Corrections, pins, and authored size

Logged correction/retry/error events by attribution: `{"agent-error": 41, "ambiguous": 8, "environment": 4}`. [Full ledger](evidence/correction-ledger.json) preserves each source run-log line and evidence pointer. These are grouped logged events, not reconstructed native tool-attempt counts.

Authored/modified source, tests, diagnostics, and configuration: **1676 physical lines across 135 files**. [Every file and byte count](evidence/hand-authored-lines.json). Many files are densely formatted; physical LOC is a poor complexity comparison here. Generated config, dependency sources, untouched scaffold, replay copies, and copied UI are excluded. Eight UI components have a separate [web accessibility compatibility patch](evidence/ui-web-compatibility.patch).

Resolved principal pins: Snapback2 `0.0.24`, Expo `54.0.37`, React `19.1.0`, React Native `0.81.5`; Playwright `1.62.1` in the copied harness. [Complete resolved root pins](evidence/resolved-pins.json) and both package lockfiles retain dependency resolution.

## Shutdown

The three recorded backend owners, Expo server/parent, static export server, and temporary diagnostic server were stopped by exact project/PID. [Shutdown receipt](evidence/shutdown.json) and [assigned-port check](evidence/ports-after-shutdown.txt) retain the results. The internal package-test audit exception remains listed below.

## Gaps and evidence limits

- Native simulator proof is unavailable; Hermes exports are not substitutes. M7 remains reserved for a fresh session.
- Supplemental `snapback2 test --json` certified 57 operations but returned blocked for derived checks because the static package seed is empty and no native journeys were supplied; required external acceptance suites are separate. Its receipt declares an internal `dev --foreground --port 0` owner, with no exposed PID or CLI port override. This invocation is an explicit port/PID audit exception and authoring error. The guide promises isolated-owner cleanup; a later lane-owned process audit found only the three recorded persistent backend owners. [Receipt](evidence/final-platform-test.json).
- The strict scale midpoint misses above are not green performance results. Supplementary cold-start memory is substantial; long-running memory stability and network-realistic performance are not established.
- Rich custom-client history uses one-item pages to fit certified result bounds. Global search for the 1,000-chat hub uses authorized per-chat page merging, with a substantial request count. Normal 100-chat search remains one bounded operation.
- Receipt/reaction decoration reads are batched across sixteen message IDs, replacing the late per-bubble query bottleneck. Each card projects up to fifty recipient/reactor rows; pathological membership churn can leave more historical reactors than that display slice. History rendering is not virtualized. The deep-history probe establishes backend pagination, not unlimited simultaneous rendered history.
- Digest dispatch follows the schedule cadence after the configured UTC boundary. Exact calendar dispatch is not supplied by the used public schedule surface.
- A post-replay owner refresh became unresponsive; exact-PID restart recovered it after a temporary E_STORE_OWNED refusal. This remains ambiguous, with diagnostics retained. One historical parked-job count could not be mapped through the documented public job-list surface; current tested expiry and digest jobs completed.
- The frozen default M3 group includes Erin while its receipt choreography opens only Alice/Bob/Carol. The exact default fixture is an [instrument skip](evidence/instrument-gaps.md); the documented adapter runs the required assertion against the real three-person Proof Trio. Frozen starter membership and choreography code were not altered.
- Some early failed choreography files were overwritten by the frozen writer before archival was added. Structured miss logs remain; preserved first-green receipts and subsequent retry archives retain their original bytes. This is an evidence-retention limitation.
- No native Codex rollout stream, driver-native clock correlation, or external grader session was supplied inside the authorized lane. Tokens, tool-use totals, and detailed phase charges are null. `run-record.json` is base-schema validated and explicitly ungraded; it is not a scored meter-composed record. No token-efficiency or competitor performance ranking is claimed.

The qualitative comparison was written before this tally: [essay.md](essay.md). Milestone experiences: [diary.md](diary.md). Chronological evidence: [run-log.md](run-log.md).

## Per-file authored/modified counts

| File | Physical lines | Bytes |
|---|---:|---:|
| `app.config.js` | 9 | 490 |
| `app.json` | 21 | 406 |
| `app/_layout.tsx` | 9 | 532 |
| `app/chat-settings/[id].tsx` | 1 | 241 |
| `app/chat/[id].tsx` | 1 | 241 |
| `app/chats.tsx` | 1 | 51 |
| `app/conversation/[handle].tsx` | 1 | 255 |
| `app/conversation/group/[group]/index.tsx` | 1 | 257 |
| `app/conversation/group/[group]/settings.tsx` | 1 | 266 |
| `app/index.tsx` | 1 | 47 |
| `app/insights.tsx` | 1 | 50 |
| `app/new-chat.tsx` | 1 | 53 |
| `app/post/[id].tsx` | 1 | 216 |
| `app/profile/[handle].tsx` | 4 | 241 |
| `app/profile/edit.tsx` | 1 | 53 |
| `app/search.tsx` | 1 | 49 |
| `app/settings.tsx` | 1 | 51 |
| `choreo-adapter.json` | 1 | 152 |
| `config/digest.production.json` | 8 | 177 |
| `config/digest.shortened.json` | 8 | 182 |
| `config/windows.production.json` | 24 | 438 |
| `config/windows.shortened.json` | 24 | 484 |
| `metro.config.js` | 5 | 256 |
| `package.json` | 36 | 1021 |
| `scripts/acceptance-m2.mjs` | 18 | 6394 |
| `scripts/acceptance-m3.mjs` | 11 | 4527 |
| `scripts/acceptance-m4.mjs` | 11 | 3553 |
| `scripts/acceptance-m5.mjs` | 8 | 2753 |
| `scripts/acceptance-m6.mjs` | 7 | 3454 |
| `scripts/acceptance-m8.mjs` | 15 | 4437 |
| `scripts/acceptance.mjs` | 27 | 4380 |
| `scripts/audit-jobs.mjs` | 1 | 783 |
| `scripts/browser-smoke.mjs` | 2 | 431 |
| `scripts/cached-inbox-diagnostic.mjs` | 1 | 1543 |
| `scripts/choreo.mjs` | 3 | 1136 |
| `scripts/configure.mjs` | 6 | 977 |
| `scripts/coverage.mjs` | 1 | 951 |
| `scripts/custom-client-demo.mjs` | 3 | 2524 |
| `scripts/deleted-inbox-diagnostic.mjs` | 2 | 2580 |
| `scripts/diagnostic-server.py` | 9 | 486 |
| `scripts/digest-proof.mjs` | 4 | 5508 |
| `scripts/dual-offline-diagnostic.mjs` | 5 | 2687 |
| `scripts/dual-offline-full.mjs` | 5 | 4425 |
| `scripts/dual-offline-warm.mjs` | 5 | 3771 |
| `scripts/dump-table.mjs` | 2 | 546 |
| `scripts/finalize-report.py` | 72 | 18418 |
| `scripts/log.mjs` | 2 | 140 |
| `scripts/m2-smoke.mjs` | 1 | 665 |
| `scripts/m3-dave-smoke.mjs` | 1 | 801 |
| `scripts/m3-remove-diagnostic.mjs` | 1 | 909 |
| `scripts/m3-smoke.mjs` | 1 | 751 |
| `scripts/m5-background-diagnostic.mjs` | 1 | 1480 |
| `scripts/m5-browser-diagnostic.mjs` | 1 | 982 |
| `scripts/m5-color-diagnostic.mjs` | 1 | 1484 |
| `scripts/m5-custody-diagnostic.mjs` | 1 | 1413 |
| `scripts/m5-live-diagnostic.mjs` | 1 | 1322 |
| `scripts/m5-network-diagnostic.mjs` | 1 | 1582 |
| `scripts/m5-query-diagnostic.mjs` | 1 | 1473 |
| `scripts/m5-settings-navigation.mjs` | 1 | 1105 |
| `scripts/m6-network-regression.mjs` | 1 | 1849 |
| `scripts/m6-offline-diagnostic.mjs` | 1 | 1429 |
| `scripts/m6-order-diagnostic.mjs` | 1 | 1581 |
| `scripts/m6-parallel-body.mjs` | 1 | 2245 |
| `scripts/m6-parallel-regression.mjs` | 1 | 2086 |
| `scripts/m6-receipt-regression.mjs` | 1 | 2058 |
| `scripts/m6-regression-diagnostic.mjs` | 1 | 1563 |
| `scripts/media-smoke.mjs` | 1 | 808 |
| `scripts/presence-probe.q` | 2 | 69 |
| `scripts/receipt-incarnation-proof.mjs` | 1 | 1358 |
| `scripts/repair-expired.mjs` | 1 | 582 |
| `scripts/replay.mjs` | 34 | 6837 |
| `scripts/scale-cold-proof.mjs` | 2 | 2271 |
| `scripts/scale-deep-proof.mjs` | 1 | 1693 |
| `scripts/scale-hub-search-proof.mjs` | 2 | 2310 |
| `scripts/scale-write-probe.mjs` | 2 | 1926 |
| `scripts/seed.ts` | 42 | 3473 |
| `scripts/serve-scale.py` | 11 | 514 |
| `scripts/setup.mjs` | 3 | 1099 |
| `scripts/shutdown.py` | 22 | 1417 |
| `scripts/suite-failure.mjs` | 2 | 697 |
| `scripts/test-support.mjs` | 7 | 1122 |
| `scripts/ui-deleted-inbox-diagnostic.mjs` | 2 | 2890 |
| `scripts/validate-record.mjs` | 1 | 527 |
| `scripts/verify-replay-quiet.mjs` | 1 | 508 |
| `scripts/verify-replay.mjs` | 10 | 8426 |
| `scripts/verify-sample.mjs` | 10 | 4719 |
| `scripts/verify-scale-media.mjs` | 2 | 3374 |
| `scripts/video-smoke.mjs` | 1 | 808 |
| `scripts/warm-start-proof.mjs` | 1 | 1830 |
| `scripts/window-probe.mjs` | 2 | 1161 |
| `snapback/access.q` | 3 | 241 |
| `snapback/digests.q` | 80 | 4263 |
| `snapback/external.q` | 4 | 911 |
| `snapback/feeds.q` | 17 | 934 |
| `snapback/follows.q` | 16 | 694 |
| `snapback/groups.q` | 81 | 4220 |
| `snapback/insights.q` | 22 | 1876 |
| `snapback/messages.q` | 175 | 9108 |
| `snapback/posts.q` | 65 | 2688 |
| `snapback/profiles.q` | 26 | 1245 |
| `snapback/push.ts` | 3 | 473 |
| `snapback/pushes.q` | 7 | 401 |
| `snapback/pushlog.q` | 3 | 165 |
| `snapback/runtime.q` | 2 | 80 |
| `snapback/schema.q` | 375 | 10336 |
| `src/Backend.native.tsx` | 8 | 500 |
| `src/Backend.tsx` | 10 | 886 |
| `src/Clique.tsx` | 28 | 5518 |
| `src/Custody.tsx` | 7 | 1488 |
| `src/Insights.tsx` | 5 | 2187 |
| `src/Media.native.tsx` | 3 | 319 |
| `src/Media.tsx` | 4 | 477 |
| `src/Messaging.tsx` | 44 | 18569 |
| `src/NetworkBridge.tsx` | 5 | 706 |
| `src/ScrollSurface.tsx` | 18 | 1190 |
| `src/Search.tsx` | 12 | 3574 |
| `src/ServerClock.tsx` | 6 | 1379 |
| `src/Social.tsx` | 21 | 5697 |
| `src/SyncStatus.tsx` | 2 | 606 |
| `src/messageItems.ts` | 5 | 679 |
| `src/useGroupWrites.ts` | 5 | 602 |
| `src/useLargeSearch.ts` | 9 | 3037 |
| `src/useOnlineClient.ts` | 2 | 374 |
| `src/useOnlinePage.ts` | 2 | 542 |
| `src/usePhoto.native.ts` | 2 | 81 |
| `src/usePhoto.ts` | 3 | 567 |
| `src/usePostSemantics.native.ts` | 1 | 117 |
| `src/usePostSemantics.ts` | 2 | 395 |
| `src/useSettingsSemantics.native.ts` | 2 | 145 |
| `src/useSettingsSemantics.ts` | 4 | 923 |
| `src/useSettingsWrite.native.ts` | 2 | 153 |
| `src/useSettingsWrite.ts` | 7 | 590 |
| `src/videoPreview.native.ts` | 1 | 59 |
| `src/videoPreview.ts` | 1 | 487 |
| `tsconfig.json` | 12 | 183 |


end=1789177036

===== END VERBATIM FILE lanes/astra-snapback2/final-report.md =====


===== BEGIN VERBATIM FILE lanes/astra-snapback2/run-record.json | 45939 bytes | SHA256 14254ea5a9dec4f92bba843c1d57e0550135c4d7b268883948680fd9f15d9c93 =====
{
  "schemaVersion": 1,
  "lane": "snapback",
  "laneVariant": "bare",
  "carrier": "web",
  "brief": "social-messenger",
  "harness": {
    "name": "Codex API session; native rollout stream not provided in authorized lane",
    "model": "gpt-6-astra",
    "effort": "medium",
    "environment": {
      "snapback2": "0.0.24",
      "node": "24.13.1",
      "npm": "11.8.0",
      "expo": "54.0.37",
      "react": "19.1.0",
      "react-native": "0.81.5",
      "playwright": "1.62.1",
      "os": "Ubuntu Linux x86_64",
      "host": "expose-builder-pixel",
      "ports": "53100-53119"
    }
  },
  "timestamps": {
    "startedAt": "2026-09-11T21:37:04Z",
    "finishedAt": "2026-09-12T01:37:16Z"
  },
  "firstGreenProofAt": "2026-09-11T21:42:36.675000Z",
  "wallClock": {
    "totalSeconds": 14412,
    "phases": {
      "orientation": null,
      "authoring": null,
      "verification": null,
      "diagnosis": null,
      "replay": null,
      "m7Session": null
    }
  },
  "tokens": {
    "input": null,
    "output": null,
    "source": null,
    "phases": {
      "orientation": null,
      "authoring": null,
      "verification": null,
      "diagnosis": null,
      "replay": null,
      "m7Session": null
    }
  },
  "toolUses": null,
  "correctionLoops": [
    {
      "attribution": "environment",
      "summary": "1789162729 error attribution=environment evidence=evidence/expo-install.log Expo install completed dependencies but requested manual dynamic-config plugin addition; workaround applied",
      "evidence": "run-log.md:8"
    },
    {
      "attribution": "environment",
      "summary": "1789162881 retry attribution=environment initial background Expo process ended with shell; foreground managed session restarted; server PID=2610535 port=53101",
      "evidence": "run-log.md:12"
    },
    {
      "attribution": "agent-error",
      "summary": "1789162904 error attribution=agent-error evidence=evidence/m1-acceptance.log profile error showed generic message without code; include rejection code for useful duplicate-handle feedback",
      "evidence": "run-log.md:13"
    },
    {
      "attribution": "agent-error",
      "summary": "1789162934 error attribution=agent-error evidence=evidence/m1-choreo.log setup identity absolute path refused; retry with relative path",
      "evidence": "run-log.md:14"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789162985 M1 green evidence=evidence/m1-suite.json,evidence/m1-choreo.jsonl,artifacts/m1-ios; setup path retry resolved at lane root; M2 start",
      "evidence": "run-log.md:15"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789163102 M2 knowledge source=package README/guide guide rules,maintain,programs; diagnostics first-pass errors=maintain public unsupported/read true unsupported/index ambiguity; fixes read allow and named index. evidence=evidence/m2-check.log",
      "evidence": "run-log.md:16"
    },
    {
      "attribution": "agent-error",
      "summary": "1789163102 M2 error attribution=agent-error evidence=evidence/m2-seed.log,evidence/m2-owner-status.json; seed called before reviewed successor index replacement applied; migration reviewed and applied, retry",
      "evidence": "run-log.md:17"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789163220 correction-loop attribution=ambiguous evidence=Metro ENOENT watch .snapback/build/tests.replaced-2631661-1789163121280; previously running Expo crashed on generated-directory replacement; exclude generated paths and bound workers, restart",
      "evidence": "run-log.md:19"
    },
    {
      "attribution": "agent-error",
      "summary": "1789163390 M2 errors attribution=agent-error evidence=evidence/m2-choreo.log; harness needs feed tabs reachable on profile; move tabs to shell. attribution=environment kit accessibilityValue stripped by react-native-web; add equivalent aria-valuetext to copied kit props, preserving presentation",
      "evidence": "run-log.md:20"
    },
    {
      "attribution": "agent-error",
      "summary": "1789163390 M2 error attribution=agent-error evidence=evidence/m2-acceptance.log; headless query returns state complete/capped, unlike hook status; test helper corrected from generated contract",
      "evidence": "run-log.md:21"
    },
    {
      "attribution": "agent-error",
      "summary": "1789163421 server PID=2692144 Expo restarted port=53101 evidence=evidence/web-m2.log; diagnostic harness PIDs=2706427,2736582 stopped explicitly because overlapping M2 runs shared receipt path; attribution=agent-error; invalidated overlapping receipts and rerun serially",
      "evidence": "run-log.md:22"
    },
    {
      "attribution": "agent-error",
      "summary": "1789163497 M2 error attribution=agent-error evidence=evidence/m2-choreo-final.log; kit video attachment expects image poster; generate actual selected-video first-frame thumbnail on web; native poster remains optional",
      "evidence": "run-log.md:23"
    },
    {
      "attribution": "agent-error",
      "summary": "1789163514 M2 diagnostic invalidation: concurrent acceptance posts displaced choreography target beyond first page; attribution=agent-error evidence=evidence/m2-choreo-final.log. Subsequent suite/choreo runs must be serial.",
      "evidence": "run-log.md:24"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789163573 M2 diagnostic harness PID=2739893 stopped explicitly after video and displaced-post failures were diagnosed; snapshot evidence=m2-choreo-diagnostic.jsonl; final serial verification begins",
      "evidence": "run-log.md:25"
    },
    {
      "attribution": "environment",
      "summary": "1789163629 M2 correction-loop iteration attribution=environment evidence=evidence/m2-choreo-serial.log; conditional Avatar and repost identity props also require web aria-valuetext mirror; fixed copied-kit attributes",
      "evidence": "run-log.md:26"
    },
    {
      "attribution": "agent-error",
      "summary": "1789164079 M3 error attribution=agent-error evidence=evidence/m3-acceptance.log; optional null key participates in unique constraint, blocking second DM; changed group idempotency lookup to transactionally read indexed exact key, kept dmPairs uniqueness",
      "evidence": "run-log.md:29"
    },
    {
      "attribution": "agent-error",
      "summary": "1789164156 M3 correction iteration attribution=agent-error evidence=evidence/m3-check.log; nonunique scan alternative refused E_STRUCTURAL_FANOUT/E_STRUCTURAL_COUNT. Retained point uniqueness with additional stable DM peer principal component; compiled/applied successor.",
      "evidence": "run-log.md:31"
    },
    {
      "attribution": "agent-error",
      "summary": "1789164260 M3 error attribution=agent-error evidence=evidence/m3-choreo.log; group adapter URL encodes literal title, route expected slug; normalize route input. Normal client group navigation now uses opaque ID so equal-name groups remain distinct.",
      "evidence": "run-log.md:33"
    },
    {
      "attribution": "agent-error",
      "summary": "1789164338 M3 first-pass native quote-jump shared scroll container JSX syntax error fixed before typecheck/export; attribution=agent-error evidence=evidence/m3-typecheck.log,evidence/m3-ios.log",
      "evidence": "run-log.md:34"
    },
    {
      "attribution": "agent-error",
      "summary": "1789164549 M3 correction-loop attribution=agent-error evidence=evidence/m3-choreo-stable.log,evidence/m3-remove-diagnostic.log; browser full navigation canceled pending memberRemove; post-failure server roster still Dave admin. Mutation fetch keepalive added; explicit settled browser removal succeeds.",
      "evidence": "run-log.md:35"
    },
    {
      "attribution": "agent-error",
      "summary": "1789164817 M4 knowledge source=package README/guide evidence=guide expressions,assets,schedule; config generator reads frozen window files into server Quarry constants. First-pass errors: Quarry comments use --; count(text) unsupported, replaced caption length check with body=slice(body,0,500). attribution=agent-error",
      "evidence": "run-log.md:37"
    },
    {
      "attribution": "agent-error",
      "summary": "1789165007 M5 knowledge source=package README/guide evidence=guide expiry,offline; first-pass diagnostics text concatenation unsupported, split profile name/handle queries; global message-search 100-chat full-body merge exceeds closure limit, bounded 200-scalar snippets preserve full indexed matching. attribution=agent-error evidence=evidence/m5-search-bound.log",
      "evidence": "run-log.md:40"
    },
    {
      "attribution": "agent-error",
      "summary": "1789165665 M5 correction agent-error: durable FIFO congested by redundant mark receipts on every navigation; project own receipt and skip already-received/read. Evidence evidence/m5-network-diagnostic.log; lookup source package README/guide offline.md and public client types.",
      "evidence": "run-log.md:41"
    },
    {
      "attribution": "agent-error",
      "summary": "1789165696 M5 correction agent-error: receipt projection exceeded 1MiB output (1051862); narrowed quoted excerpt to 200 scalars; nullable slice required ?? default. Evidence evidence/m5-receipt-check*.log; source diagnostic.",
      "evidence": "run-log.md:42"
    },
    {
      "attribution": "agent-error",
      "summary": "1789165931 M5 correction environment: React Native Web drops selected state on frozen kit button roles. Both clients show real updated checkmark but harness requires aria-selected/pressed; added app-owned DOM semantic binding from server state, no kit or harness edits. evidence/m5-color-diagnostic.log. Earlier diagnostic q.head optional access error was agent-error, evidence/m5-query-diagnostic-2.log. Narrowed delivery pages to40 because slice bound remains conservative.",
      "evidence": "run-log.md:43"
    },
    {
      "attribution": "agent-error",
      "summary": "1789165962 M5 retry: stopped choreography PID2924368 parent2924361 after diagnostic HMR contaminated observations; restart on stable app. attribution agent-error evidence/m5-choreo-receipts.log",
      "evidence": "run-log.md:44"
    },
    {
      "attribution": "agent-error",
      "summary": "1789166210 M5 retry agent-error: stable run found inline viewer ID collision and background wrapper lacked observable state; expiry config not admitted before full document navigation. Server probe confirms disappearing=null and expiresAt=null, so stop PID2933950/2933942 and fix before rerun. evidence/m5-choreo-stable.log,evidence/m5-background-diagnostic.log",
      "evidence": "run-log.md:46"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789166263 M5 correction verified: settings online write uses public headless client and keepalive; immediate full-document navigation preserves committed 24h setting. Messages retain durable provider. Evidence evidence/m5-settings-navigation.log, server query recorded24h; adapter wait190000 matches real180000 expiry config.",
      "evidence": "run-log.md:47"
    },
    {
      "attribution": "agent-error",
      "summary": "1789166678 M5 correction agent-error: gate until delivered log catches up; first gate reset on twin refresh, fixed. Inbox projection contained computed receipt/profile joins causing partial local reevaluation; simplified to native delivery metadata plus raw message and dedicated indexed pending-receipt watcher per published guide. evidence/m5-custody-diagnostic.log,evidence/m5-drain-check.log; source package README/guide live-query/deliver.",
      "evidence": "run-log.md:48"
    },
    {
      "attribution": "agent-error",
      "summary": "1789167842 M6 correction loops agent-error: create binding required pure insert, ReceiptTicks uses receiptPending; composer async completion erased next draft; usePage source transitions briefly removed already-rendered rows, now retain disclosed rows in memory until authoritative removal. evidence/m6-items-typecheck.log,evidence/m6-offline-diagnostic.log,evidence/m6-order-diagnostic.log. API bound 31MB heap required one-message rich pages. Source diagnostic/package guide; evidence/m6-api-check*.log. Sample50 schema and all13 actual-state classes pass.",
      "evidence": "run-log.md:50"
    },
    {
      "attribution": "agent-error",
      "summary": "1789168583 Scale 10% checkpoint verified exact manifest counts and named fixtures; non-scored probes recorded evidence/scale/verification-10pct.json. M8 corrections agent-error: schedules need optional time; Quarry arrays only scalar, seven-day response now named day records; digest maintained post-period key closure6180488>4194304 replaced with compact transactional table. Receipt cleanup changed to scoped membership walk and membership-incarnation unread counts. evidence/m8-insights-check*.log,evidence/m8-digest-check*.log.",
      "evidence": "run-log.md:54"
    },
    {
      "attribution": "agent-error",
      "summary": "1789169282 M8 correction-loop attribution=agent-error: reports incorrectly accepted partial local twin counters; use authenticated online queries for load/refresh. Shared display buffer now deduplicates provisional and authoritative rows by author+stable key; real desktop chat sidebar exposes unread state and live account convergence. RN Web toggle semantics mirror server state. TypeScript observePages loadMore belongs to snapshot, fixed. Evidence=evidence/m8-choreo-online.log,evidence/m8-typecheck.log. Fixture retry requires fresh unliked Alice witness after each consumed attempt. Scale 50pct invariant verification PASS evidence=evidence/scale/verification-50pct.json",
      "evidence": "run-log.md:55"
    },
    {
      "attribution": "agent-error",
      "summary": "1789169315 M8 digest proof retry attribution=agent-error: authorization correctly returned denied, proof expected refused; fixed assertion, no backend change. evidence=evidence/m8-digest-proof.log",
      "evidence": "run-log.md:57"
    },
    {
      "attribution": "agent-error",
      "summary": "1789169403 M8 secondary scale server PID3778175 port53103 fresh replays/scale-m8 source copy replayMode=true. Correction attribution=agent-error: raw binary dev misses compiler worker E_OWNER_NO_COMPILER, use public npx wrapper. Stopped proof PID3721870 before backend restart to correct same invocation. Evidence=evidence/scale-m8-dev.json,evidence/scale-m8-check.log,scripts/digest-proof.mjs",
      "evidence": "run-log.md:59"
    },
    {
      "attribution": "agent-error",
      "summary": "1789169458 correction attribution=agent-error: accidental empty scratch file /tmp/nope created outside lane by a stray heredoc; immediately removed exact file. No external files inspected. All substantive work remains in lane.",
      "evidence": "run-log.md:62"
    },
    {
      "attribution": "agent-error",
      "summary": "1789169597 M8 correction-loop attribution=agent-error: real schedule fires on installation-offset minute, proof 20s poll shorter than observed42s offset; expand to90s and record calendar-syntax limitation. Schedule diagnostic additionally exposed expiry E_REQUIRE:NOT_FOUND at messages.q:71:5 because point delete refuses absent digest custody; guard optional deletions, including old message mark-read. Evidence=evidence/m8-digest-schedule-logs.json; source=package README/guide schedule.md,diagnostic. Regression required M4/M5/M6.",
      "evidence": "run-log.md:63"
    },
    {
      "attribution": "agent-error",
      "summary": "1789170020 M8 scale retry attribution=agent-error: fixture hub u0001 has1000 conversations, cap100 rejected action8145. Added maintained membership cap count; digest1000 loop exceeded E_BOUND heap12713686/8388608 and closure limits, repaired using compact period cells plus separate post aggregation and atomic current-membership emission chunks. Main server recovered PID4108440 port53100 after in-progress proof restart encountered invalid authoring source. Single-query1000-lane search E_BOUND heap20356901/8388608 closure31701617/4194304; will use client merge of bounded server lanes. Evidence=evidence/scale-m8-replay.log,evidence/m8-thousand-memberships-check.log,evidence/m8-split-digest-check.log,evidence/m8-search1000-check.log",
      "evidence": "run-log.md:67"
    },
    {
      "attribution": "agent-error",
      "summary": "1789170456 M8 corrections attribution=agent-error: new digest counter requires compact authorized read rule and maintained cap count; optional cleanup repaired and15 previously-rejected expired rows reaped by exact operator calls. source=diagnostic,package README/guide maintain/job/fanout. Evidence=evidence/m8-expired-repair.json,evidence/m8-final-digest-check.log. Expanded global search uses per-chat paginated head merge for1000-chat hub after unsupported dynamic merge E_QUARRY_SYNTAX and held_search E_ARGS_TYPE; normal100-chat bounded server query retained. Evidence=evidence/m8-search-batches-check-final.log,evidence/m8-search-batches-check-3.log,src/useLargeSearch.ts.",
      "evidence": "run-log.md:74"
    },
    {
      "attribution": "environment",
      "summary": "1789170733 audit correction attribution=environment: copied UI kit has eight accessibilityValue-to-aria-valuetext compatibility patches from early milestones, not byte-identical source. Frozen instrument/ui input remains unchanged. Patches preserve existing props, values, visuals, and native accessibility; app-only aria-pressed mirrors supplement them. Exact diff=evidence/ui-web-compatibility.patch. No choreography changes.",
      "evidence": "run-log.md:75"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789170838 regression M4/M5 suite+choreography PASS. M6 immediate post-browser push assertion missed while presence was settling; later owner subscriptions0 and precondition-probed retry passes. Added operator presence wait before disconnected push arrangement; no push behavior change. Attribution=ambiguous (browser-close/presence settlement boundary), evidence=evidence/m6-regression-suite.log,evidence/m6-regression-owner.json,evidence/m6-regression-suite-retry.log. M6scale named media12 normalized-pixel/video-byte checks and actual50-message page50 envelope pass, evidence=evidence/scale/media-verification.json,evidence/scale/deep-history.json.",
      "evidence": "run-log.md:76"
    },
    {
      "attribution": "agent-error",
      "summary": "1789171726 M6 post-M8 regression correction loops attribution=agent-error: sequential diagnostic passed but concurrent navigation reproduced permanent Synchronizing message history with queued sends already delivered. Initial composer gate tested connected only, allowing input during reconnecting before custody-ready; gate now waits in both online states and permits truly offline cached use. Authoritative inbox receipt filtering prevents partial twin null joins from becoming removals. Pending/committed rows retain stable logical React keys and known profile stays mounted. Read receipt effect tracks late-arriving receipt coverage. Prior buffer-only/sticky-profile attempts did not alone resolve; exact evidence=evidence/m6-parallel-body.log,evidence/m6-parallel-gated.log,evidence/m6-regression-choreo-buffer.log,evidence/m6-regression-choreo-retained.log. M8scale50pct exact invariant and Insights/Trending probes PASS evidence=evidence/scale-m8/verification-50pct.json.",
      "evidence": "run-log.md:77"
    },
    {
      "attribution": "agent-error",
      "summary": "1789172197 M5 cached-reopen regression exposed over-strict readiness requiring a server-source receipt in the same snapshot as caughtUp/live. Package guide documents caughtUp exhaustion + live tail as the completion contract; readiness now uses those flags, accepts native removal metadata, and ignores null local joined bodies until authoritative. M6 choreography passes again. Attribution=agent-error evidence=evidence/m5-regression-choreo-gated.log,evidence/m6-regression-choreo-caughtup.log; source=package README/guide offline.md. Receipt active vectors now compare captured membership identity, with remove/rejoin negative proof PASS evidence=evidence/m8-receipt-incarnation.json.",
      "evidence": "run-log.md:78"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789173358 M8 scale final invariant PASS all167244 actions, own start1789169404/end1789173075 including correction gap; latest authored backend applied only after invariant freeze for supplementary client probes. Evidence=evidence/scale-m8/clock.jsonl,evidence/scale-m8/verification-final.json",
      "evidence": "run-log.md:79"
    },
    {
      "attribution": "agent-error",
      "summary": "1789173738 M8 regression corrections attribution=agent-error: authoritative online inbox observer resolves durable-drain compaction/reopen gate; real M5 timed expiry choreography PASS evidence=evidence/m5-regression-choreo-online.log. M8 dual-offline convergence then exposed stale history missing delivered rows; custody now supplies latest50 delivered rows. Composite inbox first50 refused E_BOUND output1051862 exceeds1048576; reduce ascending drain chunk40 per diagnostic. source=package README/guide live-query/offline,generated types,diagnostic. Evidence=evidence/m8-regression-choreo-final.log,evidence/m8-inbox-composite-check.log,evidence/m8-inbox-composite-check-40.log.",
      "evidence": "run-log.md:81"
    },
    {
      "attribution": "agent-error",
      "summary": "1789173954 M8 supplementary hub search first attempt timed out from durable partial-query path; correction uses authoritative online count/search while retaining durable queries offline; exported-client retry PASS 1000-conversation hub,20+20 distinct results,1157queryrequests,11.462seconds. Attribution=agent-error evidence=evidence/scale-m8/hub-search-first-refusal.json,evidence/scale-m8/hub-search.json. Scale latest backend restarted through documented --stop with recordedPID1573273.",
      "evidence": "run-log.md:84"
    },
    {
      "attribution": "agent-error",
      "summary": "1789174265 M8 late regression correction attribution=agent-error: inbox fallback allowed older cached delivered cards to clear a newer authoritative removal. M5 real-expiry regression failed visible-after-relaunch. Custody now compares backend delivery seq per row and ignores older snapshots. Evidence=evidence/m5-regression-choreo-final.log,src/Custody.tsx,evidence/m5-regression-choreo-sequence.log. M8 final-code scale cold sync54.894seconds, peak705741792bytes, post-settlement forced-GC heap169431472bytes; GC metric separate from sync timer, evidence=evidence/scale-m8/cold-sync.json.",
      "evidence": "run-log.md:85"
    },
    {
      "attribution": "agent-error",
      "summary": "1789174752 M8 diagnostics found pending admission/render and second flush exceeding15seconds as per-row observers multiplied. Explicit pending drafts preserve stable author+key identity during SDK admission and are removed on refusal. Receipt/reaction reads now batch16 message IDs into one certified composite query (50 recipient/reactor rows per message). Own dual-offline diagnostic now passes all3clients. Attribution=agent-error; source=package README/guide live-query warning against per-row queries, diagnostic. Evidence=evidence/dual-offline-diagnostic.log,evidence/dual-offline-draft.log,evidence/dual-offline-batched.log,evidence/m8-decoration-batch-check.log. Expiry server audit confirms recent test rows physically deleted; authoritative null body now purges even original delivered metadata and cached local values cannot override authoritative custody. Evidence=evidence/expiry-stored-diagnostic.json.",
      "evidence": "run-log.md:87"
    },
    {
      "attribution": "agent-error",
      "summary": "1789175066 M8 regression corrections attribution=agent-error: group memberRemove queued behind message work could be lost on immediate settings navigation; independent authenticated server roster still Dave admin after failed M3 check. Membership writes now use direct authenticated keepalive client, as settings already did. M3 suite restores genuine trio and proves all starter segments idempotent again. Suite adapter output now preserves shortened expiry configuration. Evidence=evidence/m3-regression-choreo-batched.log,evidence/m3-regression-suite-final.log,src/useGroupWrites.ts. Online composer gate now waits only for authoritative live inbox drain, not an earlier cached durable caughtUp flag; source=package README/guide deliver/offline/live-query, evidence=src/Messaging.tsx,evidence/m5-regression-choreo-online-gate.log.",
      "evidence": "run-log.md:88"
    },
    {
      "attribution": "agent-error",
      "summary": "1789175249 M5 real-expiry choreography PASS with authoritative-only startup gate; M6 and M8 choreography also PASS. M3 direct membership writes exposed retained-history regression: treating unreadable joined body as deletion erased departed-member history. Correction trusts only native kind=removed; local predictions never outrank authoritative event seq. Source=package README/guide deliver (changed refreshes, removed tombstones); attribution=agent-error. Evidence=evidence/m5-regression-choreo-online-gate.log,evidence/m3-regression-choreo-direct.log,evidence/m3-regression-choreo-retain.log,src/Custody.tsx.",
      "evidence": "run-log.md:89"
    },
    {
      "attribution": "agent-error",
      "summary": "1789175505 supplemental snapback2 test --json returned blocked: certify57ops pass; derived rules/bounds/invalidation/replay/auth/effects blocked because snapback/seed.ts is empty and no native test journeys supplied. Required external acceptance suites remain separate. Source=diagnostic,package README/guide testing. Receipt declares internal command dev --foreground --port0; test --help exposes no port option and no isolated-owner PID was exposed. This unaudited ephemeral test-owner invocation did not honor the lane port pin; attribution=agent-error (invoked before checking isolation behavior), with package surface limitation. Tool documents isolated owner/store cleanup on exit. Evidence=evidence/final-platform-test.json,.snapback/receipts/1789175443811.json. No claim of complete PID/port audit for this internal invocation.",
      "evidence": "run-log.md:91"
    },
    {
      "attribution": "agent-error",
      "summary": "1789175697 M8 retry corrections attribution=agent-error: repeated own top/tie fixtures crowded Trending top10 and invalidated tie-order arrangement; suite now removes only prior authored witness likes before independent baseline. Failed terminal suite did not mean a backend ranking failure. New suite PASS evidence=evidence/m8-regression-suite-isolated.log; failed arrangement evidence=evidence/m8-regression-suite-terminal.log. Acceptance failure handlers now archive prior receipt and write explicit false status, avoiding stale-pass startup on future failed suite runs. Initial composer readiness now latches per conversation after history and write admission are ready; post-navigation offline handoff no longer precedes operation preparation. Evidence=src/Messaging.tsx,evidence/m8-regression-choreo-prepared.log.",
      "evidence": "run-log.md:92"
    },
    {
      "attribution": "ambiguous",
      "summary": "1789176200 M8 intermittent handoff diagnostic: isolated and full own sequence pass; some frozen runs exceed10second offline convergence wait. Temporary app-owned telemetry serverPID1938993 port53105 captured connection flapping offline/connected and delayed recovering on browser network transitions. Instrumented frozen run passed; no harness edits. Web bridge now calls SDK offline/online once per browser connectivity event, not polling. Temporary client telemetry removed. Attribution=ambiguous for timing root cause, agent integration correction; source=public SDK types/guide offline plus own telemetry. Evidence=evidence/client-telemetry.jsonl,evidence/m8-choreo-telemetry.log,src/NetworkBridge.tsx,evidence/m8-choreo-network-events.log.",
      "evidence": "run-log.md:93"
    },
    {
      "attribution": "agent-error",
      "summary": "1789176717 M5 native-removal-only retry still exposed cached expired content after re-open despite physical server deletion. Added authenticated server-clock anchor with monotonic local elapsed time, deadline-triggered rendering removal in Conversation/Search, and orphan-draft exclusion when no durable queued work remains. This is display enforcement of server-issued expiresAt; backend timers and authorization remain the deletion proof. Attribution=agent-error, evidence=evidence/m5-choreo-network-events.log,evidence/expiry-clock-check.log,src/ServerClock.tsx,evidence/m5-choreo-clock.log. M8 browser network bridge latest M8/M6 choreography pass; no polling reconciliation.",
      "evidence": "run-log.md:94"
    }
  ],
  "handAuthoredLoc": {
    "lines": 1676,
    "files": 135,
    "sharedUiLines": 3519
  },
  "authParity": {
    "posture": "sessions",
    "notes": "Authenticated user clients; operator personas only in explicit fixture/verification operations. Local development owner is not a production deployment."
  },
  "diary": "diary.md",
  "socialMessenger": {
    "laneId": "astra-clique-snapback2",
    "executionOrder": [
      "M1",
      "M2",
      "M3",
      "M4",
      "M5",
      "M6",
      "M8"
    ],
    "milestones": {
      "m1": {
        "status": "green",
        "start": 1789162666,
        "end": 1789162985,
        "wallSeconds": 319,
        "firstGreenEpoch": 1789162956.675,
        "firstGreenSeconds": 290.6749999523163,
        "latestVerificationEpoch": 1789162956.675,
        "suite": "evidence/m1-suite.json",
        "choreography": "evidence/m1-choreo.jsonl",
        "assertions": {
          "total": 3,
          "required": 3,
          "implemented": 3,
          "passed": 3,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m1-ios",
        "nativeSimulator": "not-required"
      },
      "m2": {
        "status": "green",
        "start": 1789162985,
        "end": 1789163778,
        "wallSeconds": 793,
        "firstGreenEpoch": 1789163705.426,
        "firstGreenSeconds": 720.4260001182556,
        "latestVerificationEpoch": 1789163705.426,
        "suite": "evidence/m2-suite.json",
        "choreography": "evidence/m2-choreo.jsonl",
        "assertions": {
          "total": 9,
          "required": 9,
          "implemented": 9,
          "passed": 9,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m2-ios",
        "nativeSimulator": "not-required"
      },
      "m3": {
        "status": "green",
        "start": 1789163778,
        "end": 1789164655,
        "wallSeconds": 877,
        "firstGreenEpoch": 1789164601.032,
        "firstGreenSeconds": 823.0320000648499,
        "latestVerificationEpoch": 1789175410.055,
        "suite": "evidence/m3-suite.json",
        "choreography": "evidence/m3-choreo.jsonl",
        "assertions": {
          "total": 7,
          "required": 5,
          "implemented": 7,
          "passed": 7,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m3-ios",
        "nativeSimulator": "not-required"
      },
      "m4": {
        "status": "green",
        "start": 1789164655,
        "end": 1789164895,
        "wallSeconds": 240,
        "firstGreenEpoch": 1789164814.28,
        "firstGreenSeconds": 159.27999997138977,
        "latestVerificationEpoch": 1789170483.127,
        "suite": "evidence/m4-suite.json",
        "choreography": "evidence/m4-choreo.jsonl",
        "assertions": {
          "total": 5,
          "required": 5,
          "implemented": 5,
          "passed": 5,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m4-ios",
        "nativeSimulator": "not-required"
      },
      "m5": {
        "status": "green",
        "start": 1789164895,
        "end": 1789167033,
        "wallSeconds": 2138,
        "firstGreenEpoch": 1789166949.336,
        "firstGreenSeconds": 2054.3359999656677,
        "latestVerificationEpoch": 1789176904.068,
        "suite": "evidence/m5-suite.json",
        "choreography": "evidence/m5-choreo.jsonl",
        "assertions": {
          "total": 4,
          "required": 2,
          "implemented": 4,
          "passed": 4,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m5-ios",
        "nativeSimulator": "not-required"
      },
      "m6": {
        "status": "green",
        "start": 1789167033,
        "end": 1789167911,
        "wallSeconds": 878,
        "firstGreenEpoch": 1789167864.136,
        "firstGreenSeconds": 831.135999917984,
        "latestVerificationEpoch": 1789176885.271,
        "suite": "evidence/m6-suite.json",
        "choreography": "evidence/m6-choreo.jsonl",
        "assertions": {
          "total": 1,
          "required": 1,
          "implemented": 1,
          "passed": 1,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m6-ios",
        "nativeSimulator": "unavailable-linux"
      },
      "m8": {
        "status": "green",
        "start": 1789168068,
        "end": 1789176963,
        "wallSeconds": 8895,
        "firstGreenEpoch": 1789169278.745,
        "firstGreenSeconds": 1210.744999885559,
        "latestVerificationEpoch": 1789176869.369,
        "suite": "evidence/m8-suite.json",
        "choreography": "evidence/m8-choreo.jsonl",
        "assertions": {
          "total": 5,
          "required": 5,
          "implemented": 5,
          "passed": 5,
          "failed": 0,
          "skipped": 0,
          "notImplemented": 0,
          "requiredUnimplemented": 0
        },
        "hermes": "artifacts/m8-ios",
        "nativeSimulator": "unavailable-linux"
      },
      "m7": {
        "status": "not-run",
        "reason": "Reserved for separate fresh session by user"
      }
    },
    "scaleReplays": {
      "scale": {
        "start": 1789167936,
        "end": 1789170317,
        "rawWallSeconds": 2381,
        "clock": [
          {
            "event": "start",
            "epoch": 1789167936,
            "files": [
              "instrument/fixtures/starter-m1.log",
              "instrument/fixtures/starter-m2.log",
              "instrument/fixtures/starter-m3.log",
              "instrument/fixtures/scale.log"
            ],
            "url": "http://127.0.0.1:53102"
          },
          {
            "event": "checkpoint",
            "checkpoint": "10%",
            "epoch": 1789168364.788,
            "excludedProbeMs": 10191
          },
          {
            "event": "checkpoint",
            "checkpoint": "50%",
            "epoch": 1789169180.37,
            "excludedProbeMs": 26943
          },
          {
            "event": "end",
            "epoch": 1789170317,
            "started": 1789167936,
            "pass": true,
            "excludedProbeMs": 37133,
            "actionsThisInvocation": 167244
          }
        ],
        "finalInvariantPass": true,
        "envelope": {
          "checkpointP95": {
            "10pct": {
              "busy-page1": 47.47040299999935,
              "busy-page50": 47.95819399999982,
              "following500": 65.08484399999907,
              "following5": 54.626303999999436,
              "global-search": 4.236477000000377
            },
            "50pct": {
              "busy-page1": 47.635119999999006,
              "busy-page50": 48.37393599999996,
              "following500": 56.777037000003475,
              "following5": 55.09599800000069,
              "global-search": 4.406692000000476
            },
            "final": {
              "busy-page1": 47.67976700000145,
              "busy-page50": 48.2872170000046,
              "following500": 66.27273300000525,
              "following5": 54.343110000001616,
              "global-search": 4.182135999995808
            }
          },
          "curves": {
            "global-search": {
              "p95": [
                4.236477000000377,
                4.406692000000476,
                4.182135999995808
              ],
              "fullRatio": 0.987173068565092,
              "fullPass": true,
              "midLine": 4.212325444442791,
              "midPass": false
            }
          },
          "note": "Literal published mid-curve rule, no noise tolerance or post-hoc replacement."
        }
      },
      "scale-m8": {
        "start": 1789169404,
        "end": 1789173075,
        "rawWallSeconds": 3671,
        "clock": [
          {
            "event": "start",
            "epoch": 1789169404,
            "files": [
              "instrument/fixtures/starter-m1.log",
              "instrument/fixtures/starter-m2.log",
              "instrument/fixtures/starter-m3.log",
              "instrument/fixtures/scale.log"
            ],
            "url": "http://127.0.0.1:53103"
          },
          {
            "event": "end",
            "epoch": 1789169623,
            "started": 1789169404,
            "pass": false,
            "error": "Error: {\"state\":\"rejected\",\"code\":\"E_CONSTRAINT\",\"family\":\"schema\",\"message\":\"memberships cap 100 reached for group (principal) = {\\\"Array\\\":[{\\\"Id\\\":\\\"user:aubCjq_B0cUi0HTSdT1PDg\\\"}]}\",\"guide\":\"schema/runtime\",\"rewrite\":\"fix the rejected mutation input and retry\"}",
            "actionsThisInvocation": 8144
          },
          {
            "event": "start",
            "epoch": 1789170041,
            "files": [
              "instrument/fixtures/starter-m1.log",
              "instrument/fixtures/starter-m2.log",
              "instrument/fixtures/starter-m3.log",
              "instrument/fixtures/scale.log"
            ],
            "url": "http://127.0.0.1:53103"
          },
          {
            "event": "checkpoint",
            "checkpoint": "10%",
            "epoch": 1789170366.274,
            "excludedProbeMs": 14189
          },
          {
            "event": "checkpoint",
            "checkpoint": "50%",
            "epoch": 1789171517.61,
            "excludedProbeMs": 38688
          },
          {
            "event": "end",
            "epoch": 1789173075,
            "started": 1789170041,
            "pass": true,
            "excludedProbeMs": 52877,
            "actionsThisInvocation": 159100
          }
        ],
        "finalInvariantPass": true,
        "envelope": {
          "checkpointP95": {
            "10pct": {
              "busy-page1": 49.9164069999988,
              "busy-page50": 49.37117099999887,
              "following500": 61.120764999999665,
              "following5": 52.18065999999999,
              "global-search": 7.183672999999544,
              "insights": 7.383922999999413,
              "trending": 47.28187000000071,
              "celebrity-following": 53.88286999999946
            },
            "50pct": {
              "busy-page1": 48.07905899999605,
              "busy-page50": 48.063625999995566,
              "following500": 64.09615699999995,
              "following5": 55.52835999999661,
              "global-search": 4.8694220000033965,
              "insights": 2.719518000005337,
              "trending": 48.12181299999793,
              "celebrity-following": 55.0139979999949
            },
            "final": {
              "busy-page1": 47.94545100000687,
              "busy-page50": 48.36862600000313,
              "following500": 58.008671999996295,
              "following5": 55.2139840000018,
              "global-search": 4.826524000003701,
              "insights": 2.5174819999956526,
              "trending": 48.01310200000444,
              "celebrity-following": 55.274695000000065
            }
          },
          "curves": {
            "global-search": {
              "p95": [
                7.183672999999544,
                4.8694220000033965,
                4.826524000003701
              ],
              "fullRatio": 0.6718741234468784,
              "fullPass": true,
              "midLine": 6.136051222223614,
              "midPass": true
            },
            "insights": {
              "p95": [
                7.383922999999413,
                2.719518000005337,
                2.5174819999956526
              ],
              "fullRatio": 0.340940987601828,
              "fullPass": true,
              "midLine": 5.221060333331075,
              "midPass": true
            },
            "trending": {
              "p95": [
                47.28187000000071,
                48.12181299999793,
                48.01310200000444
              ],
              "fullRatio": 1.015465378167228,
              "fullPass": true,
              "midLine": 47.606862000002366,
              "midPass": false
            }
          },
          "note": "Literal published mid-curve rule, no noise tolerance or post-hoc replacement."
        }
      }
    },
    "nativeArtifacts": {
      "m1": [
        {
          "path": "artifacts/m1-ios/metadata.json",
          "bytes": 1779,
          "sha256": "e83af7e3af7f56a0b7acd3b2b86f5293ab639745e9598138170ecc58909fe7b3",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m1-ios/_expo/static/js/ios/entry-f349aa8c0732f8c254fa2b72bfbad0ae.hbc",
          "bytes": 3884580,
          "sha256": "ee52d31733eb42e0c6fb6002c519be7dae0c7edc87dfb7411a53144883b5f62c",
          "first8Hex": "c61fbc03c103191f"
        }
      ],
      "m2": [
        {
          "path": "artifacts/m2-ios/metadata.json",
          "bytes": 1779,
          "sha256": "81c4513f9c69ccaf095778888aaa61b5435a35da1a18d06ff7e958a323d37ed6",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m2-ios/_expo/static/js/ios/entry-57e99e029b9a65a68b60841f728a7d29.hbc",
          "bytes": 3896918,
          "sha256": "a76a0e3d8bf689121272c6666bafe574e86935bf326ed912bb8dc456381f6681",
          "first8Hex": "c61fbc03c103191f"
        }
      ],
      "m3": [
        {
          "path": "artifacts/m3-ios/metadata.json",
          "bytes": 1779,
          "sha256": "401fbadf6f4ba178863ced9c50ccacb3c3d73df2960414e76d9828ffe0692feb",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m3-ios/_expo/static/js/ios/entry-4d929d02b435f9a075663df30eab26e7.hbc",
          "bytes": 3919693,
          "sha256": "aaeedaab6efc21c91480f91a4608730b7b09a63528296535d95783b6b5bce749",
          "first8Hex": "c61fbc03c103191f"
        }
      ],
      "m4": [
        {
          "path": "artifacts/m4-ios/metadata.json",
          "bytes": 1779,
          "sha256": "5deacc0489a8479e0042248f55daeb84000eb998ed48491af2a90a7aaa365e7f",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m4-ios/_expo/static/js/ios/entry-d86e188e98636011c83c865e1d6c5d78.hbc",
          "bytes": 3924833,
          "sha256": "431fd99d4abcd9c00b811e7058ee7af3d659873d7cdb063990c893419f234d97",
          "first8Hex": "c61fbc03c103191f"
        }
      ],
      "m5": [
        {
          "path": "artifacts/m5-ios/metadata.json",
          "bytes": 1779,
          "sha256": "815ebbbdb48ce7a0d01a4e5a6deb4dbdd2e5b9bb3d46f2d8a7ba48f1af5636b2",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m5-ios/_expo/static/js/ios/entry-3bdbe433538f163ab41453b3baac81fc.hbc",
          "bytes": 3939632,
          "sha256": "acbd84d8ecdcb9cde0139eba88b77d6b267bde2001e4f4ffbdf6477d46618e82",
          "first8Hex": "c61fbc03c103191f"
        }
      ],
      "m6": [
        {
          "path": "artifacts/m6-ios/metadata.json",
          "bytes": 1779,
          "sha256": "b34982430d6e4d3934092da801fe978efaf9644aba7606b96fe7eef293f4a8d0",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m6-ios/_expo/static/js/ios/entry-368f0e6f62b32fd11f5428343799ffee.hbc",
          "bytes": 3941984,
          "sha256": "291bb366d79dd3ede4535dabcb405615a3325c521f4b3771c4ac669cc6789032",
          "first8Hex": "c61fbc03c103191f"
        }
      ],
      "m8": [
        {
          "path": "artifacts/m8-ios/metadata.json",
          "bytes": 1779,
          "sha256": "d13a2c0c481248a7bbf36fe3c52a47422d7b56c4addd763852398db6cf6a31fc",
          "first8Hex": "7b2276657273696f"
        },
        {
          "path": "artifacts/m8-ios/_expo/static/js/ios/entry-ceb2451ea48a537ad55a557645a04ef4.hbc",
          "bytes": 3966047,
          "sha256": "1210b81f9e1b470f607877c8161a37a37d6908c0c7b17644e7695103a0c0ecab",
          "first8Hex": "c61fbc03c103191f"
        }
      ]
    },
    "grading": {
      "status": "not-run",
      "reason": "No external grader or rotated holdout access in this autonomous builder session"
    },
    "metering": {
      "status": "unavailable",
      "reason": "native-rollout-stream-not-provided-in-lane",
      "tokens": null,
      "toolUses": null,
      "composition": "not-composed; no driver-native session tree, first-edit marker, or measured native clock correlation supplied"
    }
  },
  "notes": "Builder record validated against base run-record schema only. Not a current scored/meter-composed record. Required suites and web choreography green; strict scale midpoint misses and native-unavailable gaps are explicit. See final-report.md."
}
===== END VERBATIM FILE lanes/astra-snapback2/run-record.json =====
