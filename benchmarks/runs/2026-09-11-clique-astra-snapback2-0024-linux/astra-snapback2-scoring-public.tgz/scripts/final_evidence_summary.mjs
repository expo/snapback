import fs from 'node:fs';
import assert from 'node:assert/strict';
const root = '/home/ccheever/clique-ri-20260911';
const read = path => fs.readFileSync(`${root}/${path}`, 'utf8');
const categories = ['overall','setup_and_docs','data_modeling','authorization','queries_and_live','writes_and_transactions','offline_sync','media_assets','background_work','client_integration','diagnostics_dev_loop','scale_and_limits','operations'];
const text = read('scores/astra-inline-retry/FINAL.md');
const match = text.match(/^\s*```json\s*\n([\s\S]*?)\n```\s*$/);
assert(match, 'exact JSON fence');
const score = JSON.parse(match[1]);
assert.equal(score.scorer.model, 'gpt-6-astra');
assert.deepEqual(Object.keys(score.backends), ['snapback2']);
const backend = score.backends.snapback2;
for (const key of categories) {
  assert(Number.isInteger(backend[key].score) && backend[key].score >= 0 && backend[key].score <= 100, key);
  assert.equal(typeof backend[key].note, 'string');
  assert(backend[key].note.trim().split(/\s+/).length <= 40, `${key} note too long`);
}
assert.equal(typeof backend.verdict, 'string');
assert.equal(typeof backend.would_use_again_for, 'string');
assert(Array.isArray(score.notes) && score.notes.length <= 5);
const phases = [
  ['m7', 'logs/astra-snapback2.m7.ndjson'],
  ['scorer-first-failed', 'scores/astra/raw.out'],
  ['scorer-inline-retry', 'scores/astra-inline-retry/raw.out'],
];
const streams = phases.map(([phase, path]) => {
  const records = read(path).split('\n').filter(Boolean).map(line => JSON.parse(line));
  const itemTypes = {};
  for (const record of records) if (record.type === 'item.completed') {
    const kind = record.item?.type || 'unknown';
    itemTypes[kind] = (itemTypes[kind] || 0) + 1;
  }
  const turns = records.filter(record => record.type === 'turn.completed').map(record => record.usage);
  const sumRawTurnUsage = {};
  for (const usage of turns) for (const [key,value] of Object.entries(usage || {})) {
    if (typeof value === 'number') sumRawTurnUsage[key] = (sumRawTurnUsage[key] || 0) + value;
  }
  return {phase, path, threadId: records.find(record => record.type === 'thread.started')?.thread_id,
    completedItemTypes: itemTypes, completedTurnCount: turns.length, sumRawTurnUsage};
});
assert.deepEqual(Object.keys(streams[2].completedItemTypes), ['agent_message'], 'retry called a tool');
const summary = {
  status: 'valid', categories: categories.length,
  scoringBasis: 'original continuous-builder narratives only; M7 and grading excluded',
  accounting: 'raw-retained-not-joined; no milestone cap or priced cost claim',
  streams,
};
fs.writeFileSync(`${root}/scores/astra-inline-retry/score.json`, JSON.stringify(score,null,2)+'\n', {flag:'wx'});
fs.writeFileSync(`${root}/scores/astra-inline-retry/validation-and-usage.json`, JSON.stringify(summary,null,2)+'\n', {flag:'wx'});
console.log(JSON.stringify(summary,null,2));
