You are a senior product engineer building a production-shaped app from scratch, alone and timed. Work fully autonomously; there is no human to ask. Work only in the lane directory supplied as your current directory: {LANE_DIR}

This is an independent cold build. Do not inspect:
- sibling lanes under {RUN_ROOT}/lanes/ (except this one)
- /home/ccheever/projects/snapback or any other Snapback/Exact checkout, or any Snapback source anywhere
- any prior Clique or Coterie implementation, diary, essay, or benchmark run on this machine

{PLATFORM_PARAGRAPH}

The authoritative instrument is `./instrument/` (also at {RUN_ROOT}/instrument/). Read `ENVIRONMENT.md` first — it wins over the brief on environment facts — then `social-messenger.md` in full, `CONTRACT.md`, `schema/social-messenger/assertions.json`, the fixtures README and `action-schema.md`, the UI kit, and the choreography README. Read `protocol.md` for how results are recorded.

This is the **full run**: build **M1 → M2 → M3 → M4 → M5 → M6 → M8** in that order in this one continuous session. Do not attempt M7 (it is a separate fresh session run later). Implement every milestone as the brief specifies, including media (images and video from `fixtures/media/`), reactions, edit/delete windows from the config files, disappearing and view-once, search, offline writes and the push seam, the custom-client API, the M6 replay adapter and the scale replay on its own clock against a fresh instance, insights, digest, and multi-device offline. Every milestone also produces an iOS Hermes bundle export as a build artifact. M6 and M8 simulator proofs are separately recorded native artifacts only on a host that supports them; on this Linux host record them unavailable and never fake or substitute them.

Green bar: `ENVIRONMENT.md`. Ship `npm run acceptance -- --milestone mN` with a coverage manifest, and `npm run seed -- --segment mN` for each starter segment (idempotent per installed segment). Copy both `instrument/choreography` and its imported sibling `instrument/metering` into this lane, preserving them as sibling directories; install inside the choreography copy, and run each milestone's choreography segment with `CHOREO_BASE_URL` pointing at your web client. The run root exposes the frozen fixture pack at `{RUN_ROOT}/fixtures/social-messenger`, matching the choreography's relative import contract, and `{RUN_ROOT}/lanes/lib/json-schema.mjs` is pre-staged for its schema-helper import. Keep the JSONL receipts in this lane. A milestone is green only when both the suite and all implemented required choreography checks pass. If the frozen harness itself makes a check structurally impossible, record the exact instrument skip rather than relabeling it.

Run-specific host override: the frozen `instrument/ENVIRONMENT.md` still records the prior Mac host; only for host/tool/port facts, this wrapper supersedes that file. This host is Ubuntu Linux x86_64 on an AMD EPYC 9454 (`expo-build-1000`; observed hostname `expose-builder-pixel`). Use only ports **{PORTS}**. Tell choreography `CHOREO_BASE_URL`. Playwright 1.62.1 and its Chromium 151 cache are available. Record every server PID and kill only those PIDs at the end; never pkill/killall/pattern kills. Other benchmark port assignments: {OTHER_PORTS}. Native Apple simulator proof is unavailable on this Linux host: record the M6/M8 native-simulator artifact as `unavailable`/`not-run` with the Linux-host reason. An Expo web run or iOS bundle export is not native-simulator proof.

Safety limit: four hours of wall clock per milestone. On exhaustion record `capability-failure` for that milestone and continue with the next milestone that is not blocked by it. Two consecutive capability failures end the lane: write the final report and stop.

Create `run-log.md` immediately. First lines must record:
lane id {LANE_ID}
model {MODEL}
effort={EFFORT}
backend={BACKEND}
start=<unix epoch seconds>

Append timestamped lines at every milestone start, green/failure, error, retry, workaround, knowledge lookup (source: model knowledge, published docs, package README/guide, package source, diagnostic, fixture, or web), and correction loop with attribution ({DEFECT_LABEL}, agent-error, environment, or ambiguous) plus an evidence pointer. Record the scale replay's own start/end epochs and its verification result against the invariant manifest.

At each milestone boundary append to `diary.md`: what you built, what felt easy, what fought you, what prior familiarity saved, what capability or docs were missing, and how this backend compared to the alternatives you know at that step.

After M8, before tallying numbers, write a 2–3 page `essay.md` comparing this experience to {OTHER_BACKENDS} and any other backend you know: where this backend reduced friction, added friction, or changed the shape of the work. Then write `final-report.md` with raw start/end epochs and wall by milestone, first-green times, each milestone's status (`green`, `capability-failure`, `aborted`, `blocked-by-M{n}`, `not-run`), correction loops and attribution, suite and choreography results per milestone, native artifacts produced, the scale replay clock and verification, resolved package pins, hand-authored line counts by file, and a candid gap list. End with `end=<epoch>`.
