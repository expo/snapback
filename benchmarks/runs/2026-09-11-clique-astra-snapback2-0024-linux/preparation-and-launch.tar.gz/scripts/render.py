#!/usr/bin/env python3
"""Render the single Astra/Snapback 2 lane prompt.

usage: render.py            (reads SNAPBACK2_VERSION beside this script's parent)
Writes prompts/<wave>-<backend>.md and creates lanes/<wave>-<backend>/ with an
instrument symlink. Wave: astra (Codex gpt-6-astra medium).
"""
import os
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEMPLATE = (ROOT / "prompts" / "template.md").read_text()
SB2_VERSION = (ROOT / "SNAPBACK2_VERSION").read_text().strip()
if not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?", SB2_VERSION):
    raise SystemExit("SNAPBACK2_VERSION is pending or invalid; root must confirm the published Linux version before rendering")

WAVES = {
    "astra": {"model": "gpt-6-astra", "effort": "medium", "base": 53100},
}
BACKENDS = ["snapback2"]
PREFIX = {"astra": "clqfa_", "grok": "clqfg_", "muse": "clqfm_"}


def platform(backend: str, wave: str) -> tuple[str, str, str, str]:
    if backend == "snapback2":
        return (
            f"Build Clique on **Snapback 2**. Install and use ONLY `snapback2@{SB2_VERSION}` from the public npm registry (exact pin; it installs its platform binary for this host), its README, the guide it serves (`npx snapback2 guide`, and the guide files inside the installed package), and its generated types. Discover everything else from that installed package: `snapback2 init`, `check`, `dev`, `run`, `test`, `why`, `trace`, `data`, `persona`. The backend is authored in Quarry (`snapback/*.q`); seeds, tests, and effect bodies are TypeScript. The client is an Expo Router app (web, plus the iOS Hermes bundle export) using the package's React and Expo client arms as its guide documents. Never read the Snapback source repository. If the package cannot express something the brief requires, record it as a platform gap with the exact diagnostic and continue.",
            f"snapback2-{SB2_VERSION}",
            "snapback2-defect",
            "Convex, Supabase",
        )
    if backend == "convex":
        return (
            "Build Clique as an Expo Router app (web, plus the iOS Hermes bundle export) on **Convex**, pinned exactly to `convex@1.45.0`. Discover Convex through the published package, CLI, and public documentation. Prefer anonymous/local development (`CONVEX_AGENT_MODE=anonymous`) and do not get stuck on account authentication; configure the local backend to listen only inside your port range. Do not use a shared hosted Convex project unless anonymous/local is impossible; if you do, record why.",
            "convex-1.45.0",
            "convex-defect",
            "Snapback 2, Supabase",
        )
    return (
        f"Build Clique as an Expo Router app (web, plus the iOS Hermes bundle export) on **Supabase**, using the published `@supabase/supabase-js` (pin `2.112.4`) and public documentation. There is no local Supabase stack on this host (no docker, no CLI). A lane-private `provider-secrets.env` file exists in this directory with hosted project credentials, including a Postgres URL that can run DDL. Namespace **every** database object, storage bucket, and Realtime channel you create with the prefix `{PREFIX[wave]}` — other lanes in other waves share this hosted project. Do not commit `provider-secrets.env`, print it, or copy it outside this lane directory. At the very end, after `final-report.md`, drop every object under your prefix and record the drop in `run-log.md`.",
        "supabase-2.112.4",
        "supabase-defect",
        "Snapback 2, Convex",
    )


def main() -> None:
    (ROOT / "prompts").mkdir(exist_ok=True)
    for wave, spec in WAVES.items():
        for i, backend in enumerate(BACKENDS):
            lane_id = f"{wave}-clique-{backend}"
            lane_dir = ROOT / "lanes" / f"{wave}-{backend}"
            lane_dir.mkdir(parents=True, exist_ok=True)
            link = lane_dir / "instrument"
            if not link.exists():
                link.symlink_to(ROOT / "instrument")
            lo = spec["base"] + 100 * i
            ports = f"{lo}–{lo + 19}"
            others = "none; all ports outside the assigned range remain reserved"
            para, backend_line, defect, other_backends = platform(backend, wave)
            text = TEMPLATE
            for key, value in {
                "{LANE_DIR}": str(lane_dir),
                "{RUN_ROOT}": str(ROOT),
                "{PLATFORM_PARAGRAPH}": para,
                "{PORTS}": ports,
                "{OTHER_PORTS}": others,
                "{LANE_ID}": lane_id,
                "{MODEL}": spec["model"],
                "{EFFORT}": spec["effort"],
                "{BACKEND}": backend_line,
                "{DEFECT_LABEL}": defect,
                "{OTHER_BACKENDS}": other_backends,
            }.items():
                text = text.replace(key, value)
            assert "{" not in text.replace("M{n}", ""), f"unfilled placeholder in {lane_id}"
            (ROOT / "prompts" / f"{wave}-{backend}.md").write_text(text)
            print(f"rendered {lane_id} → ports {ports}")


if __name__ == "__main__":
    main()
