#!/usr/bin/env python3
"""Launch one foreground grading session (fresh headless Claude) for a lane.

usage: grade.py <wave> <backend>
Renders prompts/grade.template.md for the lane and runs `claude -p` detached with
cwd = the lane; writes logs/<wave>-<backend>.grade.{ndjson,stderr.log,pid,start.json}.
Claude is the other scored family for every builder in this run (codex, grok, muse).
"""
import json, os, subprocess, sys, time
from pathlib import Path
from render import WAVES, BACKENDS, ROOT, SB2_VERSION
from run_support import run_env, wait_tracked_process

GRADER_MODEL = os.environ.get("CLIQUE_GRADER_MODEL", "claude-opus-5")
wave, backend = sys.argv[1], sys.argv[2]
spec = WAVES[wave]; i = BACKENDS.index(backend)
lane = ROOT / "lanes" / f"{wave}-{backend}"; logs = ROOT / "logs"; name = f"{wave}-{backend}"
lo = spec["base"] + 100 * i
platform_note = {"snapback2": f"the public npm package snapback2@{SB2_VERSION}",
                 "convex": "convex@1.45.0 (anonymous/local backend)",
                 "supabase": "@supabase/supabase-js@2.112.4 against a hosted project whose credentials are in the lane's provider-secrets.env (never print them)"}[backend]
text = (ROOT / "prompts" / "grade.template.md").read_text()
for key, value in {"{RUN_ROOT}": str(ROOT), "{LANE_DIR}": str(lane), "{BACKEND}": {"snapback2": f"snapback2-{SB2_VERSION}", "convex": "convex-1.45.0", "supabase": "supabase-2.112.4"}[backend],
                   "{PLATFORM_NOTE}": platform_note, "{PORTS}": os.environ.get("CLIQUE_GRADE_PORTS", f"{lo}–{lo + 19}"), "{WAVE}": wave, "{GRADER_MODEL}": GRADER_MODEL}.items():
    text = text.replace(key, value)
note = os.environ.get("CLIQUE_GRADE_NOTE", "")
if note: text += "\n\n## Harness note for this lane\n\n" + note + "\n"
assert "{" not in text.replace("{LANE_DIR}", ""), "unfilled placeholder"
prompt_path = ROOT / "prompts" / f"{name}.grade.md"; prompt_path.write_text(text)
(lane / "grading").mkdir(exist_ok=True)
env = run_env()
if not env.get("ANTHROPIC_API_KEY"):
    raise SystemExit("ANTHROPIC_API_KEY must be injected process-locally; do not store it in the run workspace")
# --add-dir is variadic, so the prompt goes in on stdin rather than as a trailing positional.
cmd = [os.path.expanduser("~/.local/bin/claude"), "-p", "--dangerously-skip-permissions", "--output-format", "stream-json", "--verbose",
       "--model", GRADER_MODEL, "--add-dir", str(ROOT / "instrument")]
out = open(logs / f"{name}.grade.ndjson", "w"); err = open(logs / f"{name}.grade.stderr.log", "w"); prompt = open(prompt_path)
started = int(time.time())
p = subprocess.Popen(cmd, stdin=prompt, stdout=out, stderr=err, cwd=lane, env=env)
(logs / f"{name}.grade.pid").write_text(str(p.pid))
(logs / f"{name}.grade.start.json").write_text(json.dumps({"lane": name, "phase": "grade", "pid": p.pid, "model": GRADER_MODEL, "startedEpoch": started, "command": cmd[:8] + ["<prompt>"]}, indent=2) + "\n")
print(f"{name} grade pid {p.pid}", flush=True)
wait_error = None
try:
    returncode, interrupted = wait_tracked_process(p)
except BaseException as error:
    wait_error = f"{type(error).__name__}: {error}"
    returncode, interrupted = p.poll() if p.poll() is not None else 125, "harness-wait-error"
finally:
    ended = int(time.time())
    out.close(); err.close(); prompt.close()
(logs / f"{name}.grade.end.json").write_text(json.dumps({
    "lane": name, "phase": "grade", "pid": p.pid, "startedEpoch": started,
    "endedEpoch": ended, "exit": returncode, "interrupted": interrupted,
    "waitError": wait_error,
}, indent=2) + "\n")
print(f"{name} grade exit {returncode} after {ended - started}s", flush=True)
sys.exit(returncode)
