#!/usr/bin/env python3
"""Fail-closed final preflight for the prepared Linux Clique run."""

import hashlib
import argparse
import json
import os
import platform
import re
import subprocess
from pathlib import Path

from run_support import run_env


ROOT = Path(__file__).resolve().parent.parent
PORTS = range(53100, 53120)

parser = argparse.ArgumentParser()
parser.add_argument("--phase", required=True, choices=["builder", "grade", "m7", "score"])
args = parser.parse_args()


def run(*args: str, env=None) -> str:
    return subprocess.run(args, check=True, text=True, capture_output=True, env=env).stdout.strip()


def npm_json(package: str, field: str):
    value = run("npm", "view", package, field, "--json", env=run_env())
    return json.loads(value)


version = (ROOT / "SNAPBACK2_VERSION").read_text().strip()
if not re.fullmatch(r"\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?", version):
    raise SystemExit("published version is still pending or invalid")
if version == "0.0.23":
    raise SystemExit("0.0.23 is Darwin-only and forbidden for this Linux run")
if platform.system() != "Linux" or platform.machine() != "x86_64":
    raise SystemExit(f"expected Linux x86_64, observed {platform.system()} {platform.machine()}")

umbrella = npm_json(f"snapback2@{version}", "version")
optional = npm_json(f"snapback2@{version}", "optionalDependencies")
linux_runtime = npm_json(f"snapback2-linux-x64@{version}", "version")
if umbrella != version or linux_runtime != version:
    raise SystemExit("published umbrella/Linux runtime version mismatch")
if optional.get("snapback2-linux-x64") != version:
    raise SystemExit("published umbrella does not pin the matching Linux runtime")

listeners = run("ss", "-ltnpH")
occupied = []
listener_evidence = []
for line in listeners.splitlines():
    columns = line.split()
    if len(columns) < 4:
        continue
    match = re.search(r":(\d+)$", columns[3])
    if match and int(match.group(1)) in PORTS:
        occupied.append(int(match.group(1)))
        listener_evidence.append(line)
if args.phase == "builder" and occupied:
    raise SystemExit(f"assigned ports occupied: {sorted(set(occupied))}")

expected_manifest = (ROOT / "preflight" / "instrument-files.sha256").read_text().splitlines()
actual_manifest = []
for path in sorted((ROOT / "instrument").glob("**/*")):
    if not path.is_file():
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    actual_manifest.append(f"{digest}  ./{path.relative_to(ROOT / 'instrument').as_posix()}")
if actual_manifest != expected_manifest:
    raise SystemExit("frozen instrument differs from the retained 170-file manifest")

codex_version = run("codex", "--version", env=run_env())
codex_auth_result = subprocess.run(
    ("codex", "login", "status"),
    check=True,
    text=True,
    capture_output=True,
    env=run_env(),
)
codex_auth_lines = [
    line.strip()
    for stream in (codex_auth_result.stdout, codex_auth_result.stderr)
    for line in stream.splitlines()
]
if "Logged in using ChatGPT" not in codex_auth_lines:
    raise SystemExit("Codex is not authenticated with ChatGPT")

browser_env = run_env()
browser_env["PLAYWRIGHT_BROWSERS_PATH"] = str(Path.home() / ".cache" / "ms-playwright")
browser_env["PW_MODULE"] = (ROOT / "preflight" / "playwright-1.62.1" / "node_modules" / "playwright" / "index.mjs").as_uri()
browser_result = run(
    "node", "--input-type=module", "-e",
    'const { chromium }=await import(process.env.PW_MODULE); const b=await chromium.launch({headless:true}); const p=await b.newPage(); await p.setContent("<main id=probe>HEADLESS_DOM_OK</main>"); console.log(JSON.stringify({version:b.version(),text:await p.locator("#probe").textContent()})); await b.close();',
    env=browser_env,
)
browser = json.loads(browser_result)
if browser.get("text") != "HEADLESS_DOM_OK":
    raise SystemExit("headless Chromium DOM probe failed")

meminfo = (Path("/proc/meminfo").read_text())
available_kib = int(re.search(r"^MemAvailable:\s+(\d+)", meminfo, re.M).group(1))
disk = os.statvfs(ROOT)
result = {
    "status": "ready",
    "phase": args.phase,
    "host": platform.node(),
    "platform": f"{platform.system()}-{platform.machine()}",
    "load": list(os.getloadavg()),
    "memoryAvailableGiB": round(available_kib / 1024 / 1024, 2),
    "diskFreeGiB": round(disk.f_bavail * disk.f_frsize / 1024**3, 2),
    "ports": "53100-53119-clear" if not occupied else "53100-53119-listeners-reported-not-refused",
    "portListeners": listener_evidence,
    "portPolicy": "must-be-clear" if args.phase == "builder" else "evidence-only-later-phase-never-kill-by-port-or-name",
    "snapback2": version,
    "linuxRuntime": f"snapback2-linux-x64@{linux_runtime}",
    "codex": codex_version,
    "codexAuth": "ChatGPT",
    "playwright": "1.62.1",
    "chromium": browser["version"],
    "nativeSimulatorProof": "unavailable-linux-host",
    "holdoutProbeClaims": "unavailable-none-committed",
    "capBoundaryAdjudication": "unavailable-old-lightweight-runner-no-authentic-boundary-controller",
}
print(json.dumps(result, indent=2))
