#!/usr/bin/env python3
"""Render the nine M7 (day-2 evolution) prompts from prompts/m7.template.md.

usage: render_m7.py   → prompts/<wave>-<backend>.m7.md
The M7 session runs in the SAME lane directory (the inherited artifact) with the
same model and effort as the continuous session, on the lane's own port range.
"""
from pathlib import Path
from render import WAVES, BACKENDS, PREFIX, SB2_VERSION, ROOT

TEMPLATE = (ROOT / "prompts" / "m7.template.md").read_text()


def platform(backend: str, wave: str) -> tuple[str, str, str]:
    if backend == "snapback2":
        return (
            f"The inherited app runs on **Snapback 2**, the public npm package `snapback2@{SB2_VERSION}` (exact pin; use its README, the guide it serves via `npx snapback2 guide`, and its generated types; never a Snapback source checkout). Backend changes are Quarry (`snapback/*.q`) and go through `snapback2 check`; the migration is a schema successor applied by `snapback2 dev` — read the guide's successor/migration page before changing the schema. If the package cannot express something, record it as a platform gap with the exact diagnostic and continue.",
            f"snapback2-{SB2_VERSION}", "snapback2-defect")
    if backend == "convex":
        return ("The inherited app runs on **Convex** (`convex@1.45.0`, anonymous/local, as the lane already uses it). Discover Convex through the published package, CLI, and public documentation; keep the local backend inside your port range.",
                "convex-1.45.0", "convex-defect")
    return (f"The inherited app runs on **Supabase** (`@supabase/supabase-js@2.112.4`) against the hosted project whose credentials are in this lane's `provider-secrets.env`; everything you create keeps the prefix `{PREFIX[wave]}`. Do not print, copy, or commit the credentials.",
            "supabase-2.112.4", "supabase-defect")


def main() -> None:
    for wave, spec in WAVES.items():
        for i, backend in enumerate(BACKENDS):
            lane_id = f"{wave}-clique-{backend}"
            lane_dir = ROOT / "lanes" / f"{wave}-{backend}"
            lo = spec["base"] + 100 * i
            para, backend_line, defect = platform(backend, wave)
            text = TEMPLATE
            for key, value in {
                "{LANE_DIR}": str(lane_dir), "{RUN_ROOT}": str(ROOT), "{PLATFORM_PARAGRAPH}": para,
                "{PORTS}": f"{lo}–{lo + 19}", "{LANE_ID}": lane_id, "{MODEL}": spec["model"],
                "{EFFORT}": spec["effort"], "{BACKEND}": backend_line, "{DEFECT_LABEL}": defect,
            }.items():
                text = text.replace(key, value)
            assert "{" not in text, f"unfilled placeholder in {lane_id}"
            (ROOT / "prompts" / f"{wave}-{backend}.m7.md").write_text(text)
            print(f"rendered m7 {lane_id}")


if __name__ == "__main__":
    main()
