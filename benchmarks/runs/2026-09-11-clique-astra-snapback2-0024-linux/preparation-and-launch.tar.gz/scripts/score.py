#!/usr/bin/env python3
"""Launch one read-only scoring session for a wave: score.py <wave>.
The wave's own model reads its three lanes' narrative files and scores each backend
out of 100 (overall + 12 categories). Writes scores/<wave>/{prompt.md,raw.*,FINAL.md}.
"""
import json, os, subprocess, sys, time
from pathlib import Path
from render import WAVES, ROOT, SB2_VERSION
from run_support import retain_codex_rollout_tree, rollout_snapshot, run_env, wait_tracked_process

wave = sys.argv[1]; spec = WAVES[wave]
out_dir = ROOT / "scores" / wave; out_dir.mkdir(parents=True, exist_ok=True)
text = (ROOT / "prompts" / "score.template.md").read_text()
for k, v in {"{MODEL}": spec["model"], "{WAVE}": wave, "{RUN_ROOT}": str(ROOT), "{SB2_VERSION}": SB2_VERSION}.items():
    text = text.replace(k, v)
assert "{RUN_ROOT}" not in text and "{MODEL}" not in text and "{WAVE}" not in text
prompt_path = out_dir / "prompt.md"; prompt_path.write_text(text)
env = run_env()
final = out_dir / "FINAL.md"; stdin = subprocess.DEVNULL
if wave == "astra":
    cmd = ["/home/ccheever/.local/bin/codex", "exec", "-s", "read-only", "--skip-git-repo-check", "--json", "--color", "never",
           "-m", "gpt-6-astra", "-c", "model_reasoning_effort=xhigh", "-C", str(ROOT), "-o", str(final), "-"]
    stdin = open(prompt_path)
elif wave == "grok":
    cmd = [os.path.expanduser("~/.local/bin/grok"), "--prompt-file", str(prompt_path), "--cwd", str(ROOT), "-m", "grok-4.6",
           "--reasoning-effort", "xhigh", "--output-format", "plain", "--disable-web-search", "--permission-mode", "auto", "--max-turns", "300"]
elif wave == "muse":
    cmd = [os.path.expanduser("~/.local/bin/muse"), "exec", "--prompt-file", str(prompt_path), "--model", "muse-spark-1.3", "--reasoning-effort", "xhigh",
           "--json", "--yolo", "--trust-workspace", "--user-input-auto-resolve", "--max-model-steps", "2000", "--workspace", str(ROOT)]
else:
    sys.exit("wave must be astra, grok, or muse")
out = open(out_dir / "raw.out", "w"); err = open(out_dir / "raw.err", "w")
start = int(time.time())
rollouts_before = rollout_snapshot() if wave == "astra" else set()
p = subprocess.Popen(cmd, stdin=stdin, stdout=out, stderr=err, cwd=ROOT, env=env)
(out_dir / "pid").write_text(str(p.pid) + "\n")
(out_dir / "start.json").write_text(json.dumps({
    "wave": wave, "pid": p.pid, "model": spec["model"], "effort": "xhigh",
    "startedEpoch": start, "command": cmd,
}, indent=2) + "\n")
wait_error = None
try:
    returncode, interrupted = wait_tracked_process(p)
except BaseException as error:
    wait_error = f"{type(error).__name__}: {error}"
    returncode, interrupted = p.poll() if p.poll() is not None else 125, "harness-wait-error"
finally:
    end = int(time.time())
    out.close(); err.close()
    if stdin is not subprocess.DEVNULL:
        stdin.close()
native_manifest = None
native_capture_error = None
if wave == "astra":
    try:
        native_manifest = str(retain_codex_rollout_tree(
            root=ROOT, lane=ROOT, phase=f"{wave}-score", stdout_path=out_dir / "raw.out",
            before=rollouts_before, started_epoch=start, ended_epoch=end,
        ))
    except Exception as error:
        native_capture_error = f"{type(error).__name__}: {error}"
(out_dir / "meta.json").write_text(json.dumps({
    "wave": wave, "pid": p.pid, "model": spec["model"], "effort": "xhigh",
    "start": start, "end": end, "exit": returncode, "interrupted": interrupted,
    "waitError": wait_error,
    "command": cmd, "nativeManifest": native_manifest,
    "nativeCaptureError": native_capture_error,
    "nativeTreeStatus": "retained" if native_manifest else "incomplete-unavailable",
}, indent=2) + "\n")
print(f"{wave} scorer exit {returncode} after {end - start}s")
sys.exit(returncode)
