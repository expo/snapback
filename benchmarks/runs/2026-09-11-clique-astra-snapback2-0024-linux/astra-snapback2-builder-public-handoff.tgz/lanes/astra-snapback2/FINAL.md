Built Clique on `snapback2@0.0.24`. M1–M6 and M8 passed required suites and choreography. Both scale replays verified; Hermes exports are saved. M7 was not run. Recorded servers are stopped.

Caveats: native simulator proof unavailable, two performance midpoint misses, and one internal test-port audit exception.

[Final report](final-report.md) · [Essay](essay.md) · [Run record](run-record.json)