# Clique — final build report

Lane `astra-clique-snapback2`; model `gpt-6-astra`; effort `medium`; backend `snapback2@0.0.24`. Start `1789162624`, report/shutdown end `1789177036`, total wall `14412` seconds.

M1 → M2 → M3 → M4 → M5 → M6 → M8 reached the required suite + implemented web choreography green bar. M7 was not run, as instructed. This is an ungraded builder result, not a claim that every performance or native proof passed.

## Milestone clocks and receipts

| Milestone | Status | Start epoch | Boundary end | Wall seconds | First combined green epoch | Seconds to first green | Suite / choreography |
|---|---|---:|---:|---:|---:|---:|---|
| M1 | green | 1789162666 | 1789162985 | 319 | 1789162956.675 | 290.675 | [suite](evidence/m1-suite.json) / [JSONL](evidence/m1-choreo.jsonl) |
| M2 | green | 1789162985 | 1789163778 | 793 | 1789163705.426 | 720.426 | [suite](evidence/m2-suite.json) / [JSONL](evidence/m2-choreo.jsonl) |
| M3 | green | 1789163778 | 1789164655 | 877 | 1789164601.032 | 823.032 | [suite](evidence/m3-suite.json) / [JSONL](evidence/m3-choreo.jsonl) |
| M4 | green | 1789164655 | 1789164895 | 240 | 1789164814.280 | 159.280 | [suite](evidence/m4-suite.json) / [JSONL](evidence/m4-choreo.jsonl) |
| M5 | green | 1789164895 | 1789167033 | 2138 | 1789166949.336 | 2054.336 | [suite](evidence/m5-suite.json) / [JSONL](evidence/m5-choreo.jsonl) |
| M6 | green | 1789167033 | 1789167911 | 878 | 1789167864.136 | 831.136 | [suite](evidence/m6-suite.json) / [JSONL](evidence/m6-choreo.jsonl) |
| M8 | green | 1789168068 | 1789176963 | 8895 | 1789169278.745 | 1210.745 | [suite](evidence/m8-suite.json) / [JSONL](evidence/m8-choreo.jsonl) |

Boundary wall includes the work recorded before advancing to the next milestone. First-green times come from preserved original segment summaries in `evidence/first-green/`; later M8 hardening and cross-milestone regression time is not silently removed. M1 also has 42 seconds of pre-milestone orientation after lane start. M6→M8 has a separately recorded replay setup interval. Work after the M8 boundary, including supplementary checks and this report, is included in total lane wall. No milestone reached its four-hour cap; no capability-failure chain occurred.

All suite-required assertions map through [coverage-manifest.json](coverage-manifest.json). Latest choreography counts and verification epochs are in [run-summary.json](evidence/run-summary.json). Starter commands exist for M1, M2 and M3; these are the only frozen starter segments. Stable mutation/message keys and existing-profile guards make repeated installation idempotent.

## Scale replays

- `scale`: start `1789167936`, final end `1789170317`, raw own-clock wall `2381` seconds; all **167,244** starter+scale actions settled and invariant checks at 10%, 50%, and final passed. [Clock](evidence/scale/clock.jsonl), [final invariants](evidence/scale/verification-final.json), [envelope](evidence/scale/envelope-summary.json).
- `scale-m8`: start `1789169404`, final end `1789173075`, raw own-clock wall `3671` seconds; all **167,244** starter+scale actions settled and invariant checks at 10%, 50%, and final passed. [Clock](evidence/scale-m8/clock.jsonl), [final invariants](evidence/scale-m8/verification-final.json), [envelope](evidence/scale-m8/envelope-summary.json).

M8 first rejected the 100-conversation cap after 8,144 actions. The corrected replay resumed idempotently in the same fresh instance, settled the remaining 159,100 actions, and kept the first start for the safety clock. Its raw wall includes that correction gap. Checkpoint probe exclusion durations are retained in each raw clock, rather than subtracted invisibly.

Both final invariant snapshots match 1,008 users/profiles, 50,228 posts, 100,015 messages, 1,002 conversations, 2,054 memberships, and all remaining manifest counts and named checks. Named media verification additionally compares decoded image pixels and original video bytes; view-once allowances are not consumed. Both replay instances produced zero replay push effects; M8 also produced zero replay digests.

**Strict envelope result: not all passed.** M6 global search midpoint was 4.407 ms against a 4.212 ms interpolation ceiling. M8 Trending midpoint was 48.122 ms against 47.607 ms. These remain failures under the literal published midpoint rule, despite small absolute differences. All recorded final 3× ratios passed. M8 global-search and Insights midpoint rules passed. No rotated holdout score is claimed.

The initial checkpoint busy-page probe used the rich custom API's one-item page. Separate [M6](evidence/scale/deep-history.json) and [M8](evidence/scale-m8/deep-history.json) probes verify the actual app history page size of 50 and page 50 at messages 2,451–2,500. [Celebrity write](evidence/scale-m8/celebrity-write.json) compares actual 900- and five-follower authors. Its 46 real probe posts were added **after** frozen invariant verification; the live M8 scale store therefore no longer has the exact frozen post count. No receipt was rewritten to hide that.

Latest clean 100-conversation app sync and heap samples: [cold-sync.json](evidence/scale-m8/cold-sync.json). The final exported client completed in 55.869 seconds, peaked at 636,609,816 observed heap bytes, and retained 179,462,420 bytes after explicit post-settlement GC. The forced-GC diagnostic is excluded from the sync timer. Earlier revisions and failures remain archived. Concurrent local regression traffic was present during this supplementary probe. The exported 1,000-conversation hub search loaded 20 results and 20 distinct continuations in [hub-search.json](evidence/scale-m8/hub-search.json). These are local non-scored diagnostics, not network-realistic or native measurements.

## Native and scheduled artifacts

Every milestone produced an Expo iOS Hermes export under `artifacts/mN-ios`; [hashes and byte headers](evidence/native-build-artifacts.json) identify the bundles. M6 and M8 simulator artifacts are **unavailable / not-run** because this Ubuntu Linux host has no Apple simulator. [Simulator status](evidence/simulator-status.json) is separate from these successful exports.

The real-clock [digest proof](evidence/m8-digest-proof.json) passed with all clients closed: correct counts, private-chat exclusion, inactive-account silence, exactly once across backend restart, and a following inactive period with no duplicate. The production configuration uses 08:00 UTC period boundaries but a one-minute installation-relative dispatch cadence; it does not promise exact 08:00:00 delivery.

## Corrections, pins, and authored size

Logged correction/retry/error events by attribution: `{"agent-error": 41, "ambiguous": 8, "environment": 4}`. [Full ledger](evidence/correction-ledger.json) preserves each source run-log line and evidence pointer. These are grouped logged events, not reconstructed native tool-attempt counts.

Authored/modified source, tests, diagnostics, and configuration: **1676 physical lines across 135 files**. [Every file and byte count](evidence/hand-authored-lines.json). Many files are densely formatted; physical LOC is a poor complexity comparison here. Generated config, dependency sources, untouched scaffold, replay copies, and copied UI are excluded. Eight UI components have a separate [web accessibility compatibility patch](evidence/ui-web-compatibility.patch).

Resolved principal pins: Snapback2 `0.0.24`, Expo `54.0.37`, React `19.1.0`, React Native `0.81.5`; Playwright `1.62.1` in the copied harness. [Complete resolved root pins](evidence/resolved-pins.json) and both package lockfiles retain dependency resolution.

## Shutdown

The three recorded backend owners, Expo server/parent, static export server, and temporary diagnostic server were stopped by exact project/PID. [Shutdown receipt](evidence/shutdown.json) and [assigned-port check](evidence/ports-after-shutdown.txt) retain the results. The internal package-test audit exception remains listed below.

## Gaps and evidence limits

- Native simulator proof is unavailable; Hermes exports are not substitutes. M7 remains reserved for a fresh session.
- Supplemental `snapback2 test --json` certified 57 operations but returned blocked for derived checks because the static package seed is empty and no native journeys were supplied; required external acceptance suites are separate. Its receipt declares an internal `dev --foreground --port 0` owner, with no exposed PID or CLI port override. This invocation is an explicit port/PID audit exception and authoring error. The guide promises isolated-owner cleanup; a later lane-owned process audit found only the three recorded persistent backend owners. [Receipt](evidence/final-platform-test.json).
- The strict scale midpoint misses above are not green performance results. Supplementary cold-start memory is substantial; long-running memory stability and network-realistic performance are not established.
- Rich custom-client history uses one-item pages to fit certified result bounds. Global search for the 1,000-chat hub uses authorized per-chat page merging, with a substantial request count. Normal 100-chat search remains one bounded operation.
- Receipt/reaction decoration reads are batched across sixteen message IDs, replacing the late per-bubble query bottleneck. Each card projects up to fifty recipient/reactor rows; pathological membership churn can leave more historical reactors than that display slice. History rendering is not virtualized. The deep-history probe establishes backend pagination, not unlimited simultaneous rendered history.
- Digest dispatch follows the schedule cadence after the configured UTC boundary. Exact calendar dispatch is not supplied by the used public schedule surface.
- A post-replay owner refresh became unresponsive; exact-PID restart recovered it after a temporary E_STORE_OWNED refusal. This remains ambiguous, with diagnostics retained. One historical parked-job count could not be mapped through the documented public job-list surface; current tested expiry and digest jobs completed.
- The frozen default M3 group includes Erin while its receipt choreography opens only Alice/Bob/Carol. The exact default fixture is an [instrument skip](evidence/instrument-gaps.md); the documented adapter runs the required assertion against the real three-person Proof Trio. Frozen starter membership and choreography code were not altered.
- Some early failed choreography files were overwritten by the frozen writer before archival was added. Structured miss logs remain; preserved first-green receipts and subsequent retry archives retain their original bytes. This is an evidence-retention limitation.
- No native Codex rollout stream, driver-native clock correlation, or external grader session was supplied inside the authorized lane. Tokens, tool-use totals, and detailed phase charges are null. `run-record.json` is base-schema validated and explicitly ungraded; it is not a scored meter-composed record. No token-efficiency or competitor performance ranking is claimed.

The qualitative comparison was written before this tally: [essay.md](essay.md). Milestone experiences: [diary.md](diary.md). Chronological evidence: [run-log.md](run-log.md).

## Per-file authored/modified counts

| File | Physical lines | Bytes |
|---|---:|---:|
| `app.config.js` | 9 | 490 |
| `app.json` | 21 | 406 |
| `app/_layout.tsx` | 9 | 532 |
| `app/chat-settings/[id].tsx` | 1 | 241 |
| `app/chat/[id].tsx` | 1 | 241 |
| `app/chats.tsx` | 1 | 51 |
| `app/conversation/[handle].tsx` | 1 | 255 |
| `app/conversation/group/[group]/index.tsx` | 1 | 257 |
| `app/conversation/group/[group]/settings.tsx` | 1 | 266 |
| `app/index.tsx` | 1 | 47 |
| `app/insights.tsx` | 1 | 50 |
| `app/new-chat.tsx` | 1 | 53 |
| `app/post/[id].tsx` | 1 | 216 |
| `app/profile/[handle].tsx` | 4 | 241 |
| `app/profile/edit.tsx` | 1 | 53 |
| `app/search.tsx` | 1 | 49 |
| `app/settings.tsx` | 1 | 51 |
| `choreo-adapter.json` | 1 | 152 |
| `config/digest.production.json` | 8 | 177 |
| `config/digest.shortened.json` | 8 | 182 |
| `config/windows.production.json` | 24 | 438 |
| `config/windows.shortened.json` | 24 | 484 |
| `metro.config.js` | 5 | 256 |
| `package.json` | 36 | 1021 |
| `scripts/acceptance-m2.mjs` | 18 | 6394 |
| `scripts/acceptance-m3.mjs` | 11 | 4527 |
| `scripts/acceptance-m4.mjs` | 11 | 3553 |
| `scripts/acceptance-m5.mjs` | 8 | 2753 |
| `scripts/acceptance-m6.mjs` | 7 | 3454 |
| `scripts/acceptance-m8.mjs` | 15 | 4437 |
| `scripts/acceptance.mjs` | 27 | 4380 |
| `scripts/audit-jobs.mjs` | 1 | 783 |
| `scripts/browser-smoke.mjs` | 2 | 431 |
| `scripts/cached-inbox-diagnostic.mjs` | 1 | 1543 |
| `scripts/choreo.mjs` | 3 | 1136 |
| `scripts/configure.mjs` | 6 | 977 |
| `scripts/coverage.mjs` | 1 | 951 |
| `scripts/custom-client-demo.mjs` | 3 | 2524 |
| `scripts/deleted-inbox-diagnostic.mjs` | 2 | 2580 |
| `scripts/diagnostic-server.py` | 9 | 486 |
| `scripts/digest-proof.mjs` | 4 | 5508 |
| `scripts/dual-offline-diagnostic.mjs` | 5 | 2687 |
| `scripts/dual-offline-full.mjs` | 5 | 4425 |
| `scripts/dual-offline-warm.mjs` | 5 | 3771 |
| `scripts/dump-table.mjs` | 2 | 546 |
| `scripts/finalize-report.py` | 72 | 18418 |
| `scripts/log.mjs` | 2 | 140 |
| `scripts/m2-smoke.mjs` | 1 | 665 |
| `scripts/m3-dave-smoke.mjs` | 1 | 801 |
| `scripts/m3-remove-diagnostic.mjs` | 1 | 909 |
| `scripts/m3-smoke.mjs` | 1 | 751 |
| `scripts/m5-background-diagnostic.mjs` | 1 | 1480 |
| `scripts/m5-browser-diagnostic.mjs` | 1 | 982 |
| `scripts/m5-color-diagnostic.mjs` | 1 | 1484 |
| `scripts/m5-custody-diagnostic.mjs` | 1 | 1413 |
| `scripts/m5-live-diagnostic.mjs` | 1 | 1322 |
| `scripts/m5-network-diagnostic.mjs` | 1 | 1582 |
| `scripts/m5-query-diagnostic.mjs` | 1 | 1473 |
| `scripts/m5-settings-navigation.mjs` | 1 | 1105 |
| `scripts/m6-network-regression.mjs` | 1 | 1849 |
| `scripts/m6-offline-diagnostic.mjs` | 1 | 1429 |
| `scripts/m6-order-diagnostic.mjs` | 1 | 1581 |
| `scripts/m6-parallel-body.mjs` | 1 | 2245 |
| `scripts/m6-parallel-regression.mjs` | 1 | 2086 |
| `scripts/m6-receipt-regression.mjs` | 1 | 2058 |
| `scripts/m6-regression-diagnostic.mjs` | 1 | 1563 |
| `scripts/media-smoke.mjs` | 1 | 808 |
| `scripts/presence-probe.q` | 2 | 69 |
| `scripts/receipt-incarnation-proof.mjs` | 1 | 1358 |
| `scripts/repair-expired.mjs` | 1 | 582 |
| `scripts/replay.mjs` | 34 | 6837 |
| `scripts/scale-cold-proof.mjs` | 2 | 2271 |
| `scripts/scale-deep-proof.mjs` | 1 | 1693 |
| `scripts/scale-hub-search-proof.mjs` | 2 | 2310 |
| `scripts/scale-write-probe.mjs` | 2 | 1926 |
| `scripts/seed.ts` | 42 | 3473 |
| `scripts/serve-scale.py` | 11 | 514 |
| `scripts/setup.mjs` | 3 | 1099 |
| `scripts/shutdown.py` | 22 | 1417 |
| `scripts/suite-failure.mjs` | 2 | 697 |
| `scripts/test-support.mjs` | 7 | 1122 |
| `scripts/ui-deleted-inbox-diagnostic.mjs` | 2 | 2890 |
| `scripts/validate-record.mjs` | 1 | 527 |
| `scripts/verify-replay-quiet.mjs` | 1 | 508 |
| `scripts/verify-replay.mjs` | 10 | 8426 |
| `scripts/verify-sample.mjs` | 10 | 4719 |
| `scripts/verify-scale-media.mjs` | 2 | 3374 |
| `scripts/video-smoke.mjs` | 1 | 808 |
| `scripts/warm-start-proof.mjs` | 1 | 1830 |
| `scripts/window-probe.mjs` | 2 | 1161 |
| `snapback/access.q` | 3 | 241 |
| `snapback/digests.q` | 80 | 4263 |
| `snapback/external.q` | 4 | 911 |
| `snapback/feeds.q` | 17 | 934 |
| `snapback/follows.q` | 16 | 694 |
| `snapback/groups.q` | 81 | 4220 |
| `snapback/insights.q` | 22 | 1876 |
| `snapback/messages.q` | 175 | 9108 |
| `snapback/posts.q` | 65 | 2688 |
| `snapback/profiles.q` | 26 | 1245 |
| `snapback/push.ts` | 3 | 473 |
| `snapback/pushes.q` | 7 | 401 |
| `snapback/pushlog.q` | 3 | 165 |
| `snapback/runtime.q` | 2 | 80 |
| `snapback/schema.q` | 375 | 10336 |
| `src/Backend.native.tsx` | 8 | 500 |
| `src/Backend.tsx` | 10 | 886 |
| `src/Clique.tsx` | 28 | 5518 |
| `src/Custody.tsx` | 7 | 1488 |
| `src/Insights.tsx` | 5 | 2187 |
| `src/Media.native.tsx` | 3 | 319 |
| `src/Media.tsx` | 4 | 477 |
| `src/Messaging.tsx` | 44 | 18569 |
| `src/NetworkBridge.tsx` | 5 | 706 |
| `src/ScrollSurface.tsx` | 18 | 1190 |
| `src/Search.tsx` | 12 | 3574 |
| `src/ServerClock.tsx` | 6 | 1379 |
| `src/Social.tsx` | 21 | 5697 |
| `src/SyncStatus.tsx` | 2 | 606 |
| `src/messageItems.ts` | 5 | 679 |
| `src/useGroupWrites.ts` | 5 | 602 |
| `src/useLargeSearch.ts` | 9 | 3037 |
| `src/useOnlineClient.ts` | 2 | 374 |
| `src/useOnlinePage.ts` | 2 | 542 |
| `src/usePhoto.native.ts` | 2 | 81 |
| `src/usePhoto.ts` | 3 | 567 |
| `src/usePostSemantics.native.ts` | 1 | 117 |
| `src/usePostSemantics.ts` | 2 | 395 |
| `src/useSettingsSemantics.native.ts` | 2 | 145 |
| `src/useSettingsSemantics.ts` | 4 | 923 |
| `src/useSettingsWrite.native.ts` | 2 | 153 |
| `src/useSettingsWrite.ts` | 7 | 590 |
| `src/videoPreview.native.ts` | 1 | 59 |
| `src/videoPreview.ts` | 1 | 487 |
| `tsconfig.json` | 12 | 183 |


end=1789177036
