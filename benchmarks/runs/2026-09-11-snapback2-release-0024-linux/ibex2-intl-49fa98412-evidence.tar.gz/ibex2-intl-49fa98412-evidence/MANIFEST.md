# Ibex2 TimeClip correction evidence

- Candidate: `49fa9841212cf1fc119a3f8dcd246b1f9ab71ea8`
- Tree: `1fbf56cb0c2ec3f15555b2d173d5f36f78db9419`
- Parent: `12dfbf3fd20fe0986768a3a5443972d38e69566c`
- Published reversible ref: `origin/codex/ibex2-linux-runtime`
- Qualification host: `expose-builder-pixel` (EPYC Ubuntu 24.04.4, glibc 2.39)
- Source lane: `/home/ccheever/projects/ibex-capsec-next-5b64b3ad`
- Cargo target: `/home/ccheever/projects/ibex-capsec-next-5b64b3ad/target`

This child corrects one observed defect only: after finite/range validation, DateTimeFormat milliseconds are truncated toward zero before ICU formatting, including preservation of negative zero. It adds one native unit witness and one real-runtime format/parts witness for `-0.1`, `0`, and `0.9`.

## Commands and results

Both commands used the existing qualified vanilla Hermes/ICU environment and `CARGO_BUILD_JOBS=32`:

```sh
timeout 900s cargo test -p ibex2 --features hermes --no-fail-fast time_clip -- --test-threads=1
timeout 900s cargo test --no-fail-fast -p ibex2 --features hermes -- --test-threads=1
```

- Focused: PID 2421391; 2026-09-11 20:36:09–20:36:12 UTC; rc 0. Both `time_clip_range_is_exact` and `fractional_milliseconds_are_time_clipped_before_format_and_parts` passed.
- Full: PID 2424964; 2026-09-11 20:36:37–20:36:49 UTC; rc 0; 30 test summaries, 481 passed, 0 failed, 13 ignored.
- Local `cargo fmt --all -- --check` and `git diff --check`: rc 0.
- The ignored count retains the previously documented expected-correct primitive-newTarget and WPT report fixtures; this addendum does not claim those behaviors pass.

## Identity

- `git archive --format=tar 49fa9841212cf1fc119a3f8dcd246b1f9ab71ea8`: SHA-256 `81a5f92152139ca040482c143611b487ad1adbd6f12502f208c2959cc2ed9ae9`.
- Binary diff `12dfbf3..49fa984`: SHA-256 `d7869ec07f979e840556684afb430dc6616080c81d293dd4dc3752da0c420c14`.
- `crates/ibex2/src/stdlib/intl_datetime.rs`: SHA-256 `3b2d24b07d0807feed55a9955fe547f8408e66a73e34d42df139758a61defe58`.
- `crates/ibex2/tests/intl_datetime.rs`: SHA-256 `0be637cc6792c1d417cd05aa749e2c34d8800a015479f6ffdcf56eccfc6b1fa5`.
- Both changed file hashes matched between the committed local candidate and the EPYC qualification lane.

## Archive member checksums

```text
63bdf73a8cad7adfaad4b67a00e290d7b6e9a1017cf4a2035b166f43a5afd61c  focused.log
9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa  focused.status
f36b639baf8731d23e202ebbd4d854e1c5d066434d17818b408518bb71681c92  full.log
9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa  full.status
```

The complete parent candidate evidence, including source/HBC hashes, clippy, ref-check, the pre-fix reproduction, and unchanged ELF closure, is in `ibex2-intl-12dfbf3-evidence.tar.gz` in the same release run directory.
