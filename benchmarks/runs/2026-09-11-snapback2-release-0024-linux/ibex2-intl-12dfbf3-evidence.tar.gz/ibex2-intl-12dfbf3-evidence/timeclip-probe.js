const formatter = new Intl.DateTimeFormat("en-US", {
  timeZone: "UTC",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hour12: false,
});

for (const input of [-0.1, 0]) {
  console.log(JSON.stringify({
    input,
    formatted: formatter.format(input),
    parts: formatter.formatToParts(input),
  }));
}
