# Ibex2 Linux native Intl correction evidence

- Candidate: `12dfbf3fd20fe0986768a3a5443972d38e69566c`
- Tree: `11a3eb8c01c01acdcdc490198293eb775a7fed74`
- Parent: `02cf5b12dc2f3ebe2b64327fd57457eb0ae68485`
- Published reversible ref: `origin/codex/ibex2-linux-runtime`
- Upstream base: `0019691e87f120a33cfec9b7dd22b6d98f49d420`
- Qualification host: `expose-builder-pixel` (EPYC Ubuntu 24.04.4, glibc 2.39)
- Qualification source lane: `/home/ccheever/projects/ibex-capsec-next-5b64b3ad`
- Cargo target: `/home/ccheever/projects/ibex-capsec-next-5b64b3ad/target`

## Result summary

- Focused Intl: rc 0; DateTimeFormat 10 passed, 0 failed, 1 ignored; NumberFormat 12 passed, 0 failed, 1 ignored. PID 2296953; 2026-09-11 20:18:25–20:18:32 UTC.
- Full Ibex2 Hermes suite: rc 0; 30 test binaries, 480 passed, 0 failed, 13 ignored. PID 2299376; 2026-09-11 20:19:22–20:19:35 UTC.
- Clippy all targets: rc 0; only inherited `ring` warnings. PID 2304622; 2026-09-11 20:19:52–20:20:00 UTC.
- Ref check: rc 0; 75 LLP docs, 2743 refs in 9720 files, 0 errors, 0 unchecked.
- Local static checks: `cargo fmt --all -- --check`, both changed JS files with `node --check`, changed ICU C++ with Clang syntax-only, `git diff --check`, and the <1500-line file caps all passed.

The read-only `timeclip-probe.js` run records a real, still-open bounded limitation: the existing debug CLI formats `-0.1` as the preceding UTC second/day while `0` formats the epoch. ES TimeClip should truncate `-0.1` to negative zero. This diagnostic is retained to prevent the candidate from being described as fully TimeClip-correct; it did not trigger a source change while R3 review and reversible packaging were active.

The two ignored tests are the deliberately retained expected-correct reproductions for the selected vanilla Hermes primitive `newTarget.prototype` fallback limitation. They are not claimed as passing behavior.

## Exact commands

Environment for all EPYC Cargo commands:

```text
PATH=/home/ccheever/.cargo/bin:/home/ccheever/.bun/bin:/home/ccheever/.local/bin:$PATH
CARGO_BUILD_JOBS=32
IBEX2_VANILLA_HERMES_DIR=/home/ccheever/projects/ibex-capsec-next-5b64b3ad/linux/Frameworks-vanilla
IBEX2_HERMESC=/home/ccheever/projects/ibex-capsec-next-5b64b3ad/tools/hermes-vanilla/hermesc-linux-x64
```

```sh
timeout 900s cargo test -p ibex2 --features hermes --no-fail-fast --test intl_number_format --test intl_datetime -- --test-threads=1
timeout 900s cargo test --no-fail-fast -p ibex2 --features hermes -- --test-threads=1
timeout 900s cargo clippy -p ibex2 --features hermes --all-targets -- -D warnings
./ref-check --verbose
```

The status files contain the actual wrapper return code followed by a newline.

## Source and generated-input identity

- `git archive --format=tar 12dfbf3fd20fe0986768a3a5443972d38e69566c`: SHA-256 `c49bbba902bf8f1778967bf74a86bf88badd90626a995f1c79565d0e0d5c9110`; 185,538,560 bytes.
- Binary diff `02cf5b12..12dfbf3`: SHA-256 `ff69429f9d633c14385c617f3218159e55ce407eb9060dce98c20dbb8e0cf179`.
- Binary diff `0019691e..12dfbf3`: SHA-256 `c4020b08ca0665b2fc029e7b819ec1298b292d3e09507e90afce411f83ff402e`.
- Generated `intl_case.hbc`: SHA-256 `b8ed1a0669391721894f3570a94a6cfbf7e1f47b6ffd527687d6cfcdd35ff97c`.
- Generated `intl_datetime.hbc`: SHA-256 `9e7e70edebe805bc28c897dd81c680048f8097357e992e85150e338c10880b38`.
- Generated `intl_number_format.hbc`: SHA-256 `9d5c5eb7b82722f236e8c7b673fd967b0e0400915ad2701fb2a4114ebf9757e0`.
- Both active debug build OUT_DIRs contained identical HBC hashes.

The EPYC lane intentionally remained based at `3182a9d7` with the candidate files synchronized as a working-tree overlay. Every compiled source/test file hash matched the final `12dfbf3` commit except `crates/ibex2/src/stdlib/intl.rs`: the tested lane had SHA-256 `3eb503ce26ee42c335d185e058a5b162a163c77f09911b303323b40754343cf6`, while the commit has `245032ad56d044fb5058c6c97e57df9eb62ee5729eb6f1b197859ca8b94e9ca4`. The sole difference is a non-executable comment changing “canonicalizes” to the narrower “case-normalizes”; Rust/HBC semantics are identical. This manifest does not describe the lane as an exact Git checkout.

### Final candidate file SHA-256s since `0019691e`

```text
c70ef4130756b111373420b4e7b39fb0895a7a75f1f127896559777aa19e73fe  crates/ibex2/build.rs
23a41c0d3296bd9c3900ee08581a87d8de266d1356c5f5e5a3b36a1de9cc5f1a  crates/ibex2/include/ibex2_jsi.h
b0f8d9a5b622a257b9a65f3126146876c33ccb862ef166210c2c1a7abdff31a1  crates/ibex2/src/bindings/intl_case.js
8b2ecf585ab692e2571111774130cbcc2d2f708d1bb0d2d12730945cbdbcb9c5  crates/ibex2/src/bindings/intl_datetime.js
1eef9db44fa31171578fc5a9ce6b04594435e9fdde0b5f4e6d13275af135bfa9  crates/ibex2/src/bindings/intl_number_format.js
28b712457ac5a5c9623d304747f2f50fdf2d06dd87867755bfb4895f0a56097e  crates/ibex2/src/boundary_abi.rs
1e8bdd70805c762b27df69880fd3a6f8d30a0c509609eb8bdb075bf89b9c0bea  crates/ibex2/src/engine/hermes.rs
081ad3c20316e58d5ccba365a6310536ff9aa1221c5a25d885ce192172228045  crates/ibex2/src/engine/hermes_shim.cc
d879e573de21bf9c0ce6b9fc7540c274c6830c218f9969594f0deaafb88574a2  crates/ibex2/src/engine/ibex2_jsi.cc
ecfda8e91b957970515afebaac58b4755f19b4a4d84c5f8d5518ce4b2f6eeac3  crates/ibex2/src/engine/intl_case_icu.cc
8ce637f7c9e47977b5ba8bea0a99a4f749db6d60e01a1c9693dd63746a10a5f9  crates/ibex2/src/engine/intl_datetime_icu.cc
4310f1015e17ce36f56de40e74f65d63068ce5c6cdeedd98dc401519359cb3be  crates/ibex2/src/engine/intl_icu.cc
71df53ba93fa0652465fc4669fa1944fdbb7ca8214be2e7521f9db4a377b0d35  crates/ibex2/src/engine/intl_number_format.cc
245032ad56d044fb5058c6c97e57df9eb62ee5729eb6f1b197859ca8b94e9ca4  crates/ibex2/src/stdlib/intl.rs
64965be35200c2f79bde1d35217da82a2c2dfb312509c1affeadb9f4175df746  crates/ibex2/src/stdlib/intl_case.rs
79b0f6374b470ef3554bc2d309b4efa6b90cfdd28de3eff5ec5600f457d24ca1  crates/ibex2/src/stdlib/intl_datetime.rs
afe1ed36c5a9afb083c54b6b560346a8fde5f416a679b8bed92f296ef5d1c4b2  crates/ibex2/src/stdlib/mod.rs
97975919addcb6bd3ee5dcf5a4e2664e15c4ca6a082f140ee8ddf8b2e252285a  crates/ibex2/src/task.rs
35eb4e76baaf0045038f035ed07b024badd4795cec09ef2ee84cd1d4b9df7dc5  crates/ibex2/tests/intl_case.rs
62a7ec7e1695739399db56755cc1fe6b1a8b0c1bcd5d54a7cb24c89a7996aa1e  crates/ibex2/tests/intl_datetime.rs
e2f4f1d14ca9c0e36b1cb7998d1f4c10bd5e2c492db63995c4fc0498734c7a63  crates/ibex2/tests/intl_number_format.rs
66202edabf638f233322d6dd8dd9175d5117efc490d399bc877b0821da95395b  crates/ibex2/tests/sqlite.rs
476b95d8340dca154ef9a37013a6be11bc191639c9291b8e54b95fbac0b4244f  issues/20260911-linux-hermes-intl-numberformat-stub.md
1ca9c53c5ab6ce1ed8346b6198aff1b09f35513166f9e4f2021709dbd5d0f93e  llp/0057-ibex-2-rust-standard-library.rfc.md
26b55246d44b3563b48e14db05cbd50684b60a6fe55b964519018c6d8ed4cae8  llp/0067-capabilities-in-ibex-2.spec.md
4061d723d04458f89bfe17cca0a42a13140645513f1c9d901a56fe769f49b9c0  llp/0068-the-standard-library-for-a-rust-consumer.spec.md
7bf132f86decaf39a6ac06a0759e679e5dbc457f44db3a41a7e33ee6c480817f  llp/reviews/0067-native-intl-20260911.r2.grok.md
7e76d67979127af012684a53f6323841457a9d548d9e15d19c98eefb7eb639c4  llp/reviews/0067-native-intl-20260911.r2.sol.md
```

## Archive member checksums

```text
880bbe9678316796b63ce216f488484283a08414bf22fbadf784a3dea0ba2287  focused.log
9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa  focused.status
1255e0e128b624295c07cad85cdc42cf497ff1d3682c9a348c5e3f5ac9f15f18  full.log
9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa  full.status
97a3256ffefb2a1446eea632e81da42d392b8effac2b20809ef87bebc27ec2a5  clippy.log
9a271f2a916b0b6ee6cecb2426f0b3206ef074578be55d9bc94f6f3fe3ab86aa  clippy.status
d965e3db20c34fb3b4a797b52fcc85aad8841b93a5345ea14a42a4c4a473ce67  ref-check.log
38eba6b25e8cb511481215c364cac9d882de157175af6952ba5a473f2eb7f0d6  timeclip-probe.js
9e7d678667e85139a62b0cb4f147e4fe893b96221dc22a1c0c903b4cb0a8a9df  timeclip-probe-output.txt
```

## Existing unchanged closure evidence

The unchanged release `boot_floor` binary and its ELF closure inspection remain in `ibex2-intl-02cf5b12-evidence.tar.gz` in the same release run directory: binary SHA-256 `7b23269c102863786ba39d084a48f9112f8d3de48d3970ae958ff71e86d15162`, NEEDED only ordinary system C/C++ libraries, maximum `GLIBC_2.39`, `GLIBCXX_3.4.30`, `CXXABI_1.3.9`, and no shared Hermes/JSI/Boost/ICU/curl/TLS dependencies.
