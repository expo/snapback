const result = {};
function capture(name, run) {
  try { result[name] = { ok: true, value: run() }; }
  catch (error) { result[name] = { ok: false, error: String(error && error.name) + ": " + String(error && error.message) }; }
}

const DTF = Intl.DateTimeFormat;
const proto = DTF.prototype;
const formatGetter = Object.getOwnPropertyDescriptor(proto, "format").get;
const resolvedIntrinsic = proto.resolvedOptions;
const partsIntrinsic = proto.formatToParts;
const instant = new Date("2020-06-07T18:09:10.000Z");

capture("datePrototypeNames", () => Object.getOwnPropertyNames(proto).sort());
capture("dateFormatDescriptor", () => {
  const d = Object.getOwnPropertyDescriptor(proto, "format");
  return { hasGet: typeof d.get, hasValue: typeof d.value, enumerable: d.enumerable, configurable: d.configurable };
});
capture("datePartsDescriptor", () => {
  const d = Object.getOwnPropertyDescriptor(proto, "formatToParts");
  return { hasGet: typeof d.get, hasValue: typeof d.value, writable: d.writable, enumerable: d.enumerable, configurable: d.configurable };
});
capture("dateResolvedDefault", () => new DTF("en-US").resolvedOptions());
capture("dateResolvedFields", () => new DTF("en-US", {
  timeZone: "UTC", weekday: "long", era: "short", year: "2-digit", month: "short", day: "2-digit",
  hour: "2-digit", minute: "2-digit", second: "2-digit", timeZoneName: "short", hour12: false,
}).resolvedOptions());
capture("dateResolvedStyles", () => new DTF("en-US", {
  timeZone: "UTC", dateStyle: "full", timeStyle: "long", hourCycle: "h23",
}).resolvedOptions());
capture("dateResolvedUnicodeExtensions", () => new DTF("en-US-u-ca-buddhist-nu-thai-hc-h23", {
  timeZone: "UTC", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit",
}).resolvedOptions());
capture("dateResolvedExplicitCalendar", () => new DTF("en-US", {
  timeZone: "UTC", calendar: "buddhist", numberingSystem: "thai", hourCycle: "h23",
  year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", dayPeriod: "long",
}).resolvedOptions());

function formatAndParts(locales, options) {
  const dtf = new DTF(locales, options);
  const format = formatGetter.call(dtf);
  const formatted = format(instant);
  const parts = partsIntrinsic.call(dtf, instant);
  return { formatted, parts, joined: parts.map((part) => part.value).join(""), equal: formatted === parts.map((part) => part.value).join("") };
}
capture("datePartsNumeric", () => formatAndParts("en-US", { timeZone: "UTC", year: "numeric", month: "2-digit", day: "2-digit" }));
capture("datePartsNamed", () => formatAndParts("de-DE", { timeZone: "UTC", weekday: "long", year: "numeric", month: "long", day: "numeric" }));
capture("datePartsTime", () => formatAndParts("en-US", { timeZone: "America/New_York", hour: "2-digit", minute: "2-digit", second: "2-digit", timeZoneName: "short", hour12: false }));
capture("datePartsStyles", () => formatAndParts("en-US", { timeZone: "UTC", dateStyle: "full", timeStyle: "long" }));
capture("datePartsCalendar", () => formatAndParts("en-US-u-ca-buddhist-nu-thai", { timeZone: "UTC", year: "numeric", month: "long", day: "numeric" }));

capture("dateFormatFakeReceiver", () => formatGetter.call({}));
capture("dateResolvedFakeReceiver", () => resolvedIntrinsic.call({}));
capture("datePartsFakeReceiver", () => partsIntrinsic.call({}, instant));

capture("localeCaseEdge", () => ({
  emptyLower: "".toLocaleLowerCase("tr"),
  emptyUpper: "".toLocaleUpperCase("tr"),
  surrogateLower: "😀I".toLocaleLowerCase("tr"),
  surrogateUpper: "😀i".toLocaleUpperCase("tr"),
  greekFinal: "ΟΣ".toLocaleLowerCase("el"),
  germanUpper: "straße".toLocaleUpperCase("de"),
}));
capture("localeCaseInvalidLower", () => "I".toLocaleLowerCase("not_a_locale"));
capture("localeCaseInvalidUpper", () => "i".toLocaleUpperCase("not_a_locale"));
capture("localeCaseArray", () => ({
  lower: "I".toLocaleLowerCase(["tr", "en-US"]),
  upper: "i".toLocaleUpperCase(["tr", "en-US"]),
}));

console.log("SNAPBACK2_INTL_DETAILS|" + JSON.stringify(result));
