const result = {};

function capture(name, run) {
  try {
    result[name] = { ok: true, value: run() };
  } catch (error) {
    result[name] = {
      ok: false,
      error: String(error && error.name) + ": " + String(error && error.message),
    };
  }
}

capture("intlOwnNames", () => Object.getOwnPropertyNames(Intl).sort());
capture("constructors", () => {
  const names = ["Collator", "DateTimeFormat", "DisplayNames", "Locale", "NumberFormat", "PluralRules", "RelativeTimeFormat"];
  const values = {};
  for (const name of names) values[name] = typeof Intl[name];
  values.getCanonicalLocales = typeof Intl.getCanonicalLocales;
  return values;
});

capture("canonicalLocales", () => Intl.getCanonicalLocales(["EN-us", "de-de", "en-US"]));
capture("canonicalLocalesInvalid", () => Intl.getCanonicalLocales("not_a_locale"));

capture("numberDecimalEn", () => new Intl.NumberFormat("en-US").format(1234567.89));
capture("numberDecimalDe", () => new Intl.NumberFormat("de-DE").format(1234567.89));
capture("numberCurrencyEn", () => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(1234.5));
capture("numberCurrencyDe", () => new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR" }).format(1234.5));
capture("numberPercent", () => new Intl.NumberFormat("en-US", { style: "percent" }).format(0.25));
capture("numberRounding", () => new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(1.239));
capture("numberMinimumDigits", () => new Intl.NumberFormat("en-US", { minimumIntegerDigits: 3, minimumFractionDigits: 2 }).format(7));
capture("numberSign", () => new Intl.NumberFormat("en-US", { signDisplay: "always" }).format(7));
capture("numberUnit", () => new Intl.NumberFormat("en-US", { style: "unit", unit: "kilometer-per-hour", unitDisplay: "long" }).format(5));
capture("numberCompact", () => new Intl.NumberFormat("en-US", { notation: "compact", compactDisplay: "short" }).format(1200));
capture("numberParts", () => new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).formatToParts(1234.5));
capture("numberResolved", () => new Intl.NumberFormat("de-DE", { style: "currency", currency: "EUR", maximumFractionDigits: 1 }).resolvedOptions());
capture("numberSupportedLocales", () => Intl.NumberFormat.supportedLocalesOf(["de-DE", "tr", "zz-ZZ"]));
capture("numberInvalidCurrency", () => new Intl.NumberFormat("en-US", { style: "currency", currency: "x" }).format(1));
capture("numberToLocaleString", () => (1234567.89).toLocaleString("de-DE", { maximumFractionDigits: 1 }));
capture("bigIntToLocaleString", () => BigInt("12345678901234567890").toLocaleString("en-US"));

const instant = new Date("2020-01-02T03:04:05.000Z");
capture("dateUtcEn", () => new Intl.DateTimeFormat("en-US", {
  timeZone: "UTC", year: "numeric", month: "2-digit", day: "2-digit",
  hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
}).format(instant));
capture("dateUtcDe", () => new Intl.DateTimeFormat("de-DE", {
  timeZone: "UTC", year: "numeric", month: "long", day: "numeric",
}).format(instant));
capture("dateNewYork", () => new Intl.DateTimeFormat("en-US", {
  timeZone: "America/New_York", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", hour12: false,
}).format(instant));
capture("dateStyle", () => new Intl.DateTimeFormat("en-US", { timeZone: "UTC", dateStyle: "full", timeStyle: "long" }).format(instant));
capture("dateParts", () => new Intl.DateTimeFormat("en-US", {
  timeZone: "UTC", year: "numeric", month: "2-digit", day: "2-digit",
}).formatToParts(instant));
capture("dateResolved", () => new Intl.DateTimeFormat("de-DE", { timeZone: "UTC", dateStyle: "short" }).resolvedOptions());
capture("dateSupportedLocales", () => Intl.DateTimeFormat.supportedLocalesOf(["de-DE", "tr", "zz-ZZ"]));
capture("dateToLocaleString", () => instant.toLocaleString("en-US", { timeZone: "UTC", year: "numeric", month: "2-digit", day: "2-digit" }));
capture("dateToLocaleDateString", () => instant.toLocaleDateString("de-DE", { timeZone: "UTC", year: "numeric", month: "long", day: "numeric" }));
capture("dateToLocaleTimeString", () => instant.toLocaleTimeString("en-US", { timeZone: "UTC", hour: "2-digit", minute: "2-digit", hour12: false }));

capture("collatorNumeric", () => ({
  lexical: new Intl.Collator("en-US").compare("2", "10"),
  numeric: new Intl.Collator("en-US", { numeric: true }).compare("2", "10"),
}));
capture("collatorLocale", () => ({
  de: new Intl.Collator("de-DE", { sensitivity: "base" }).compare("ä", "a"),
  sv: new Intl.Collator("sv-SE").compare("ä", "z"),
}));
capture("collatorPunctuation", () => new Intl.Collator("en-US", { ignorePunctuation: true }).compare("a-b", "ab"));
capture("collatorResolved", () => new Intl.Collator("de-DE", { numeric: true, sensitivity: "base" }).resolvedOptions());
capture("collatorSupportedLocales", () => Intl.Collator.supportedLocalesOf(["de-DE", "tr", "zz-ZZ"]));
capture("stringLocaleCompare", () => ({
  lexical: "2".localeCompare("10", "en-US"),
  numeric: "2".localeCompare("10", "en-US", { numeric: true }),
}));

capture("stringLocaleCase", () => ({
  lowerDefault: "I".toLocaleLowerCase("en-US"),
  lowerTurkish: "I".toLocaleLowerCase("tr"),
  upperDefault: "i".toLocaleUpperCase("en-US"),
  upperTurkish: "i".toLocaleUpperCase("tr"),
}));

capture("pluralEnglish", () => ({
  one: new Intl.PluralRules("en-US").select(1),
  other: new Intl.PluralRules("en-US").select(2),
  ordinal1: new Intl.PluralRules("en-US", { type: "ordinal" }).select(1),
  ordinal2: new Intl.PluralRules("en-US", { type: "ordinal" }).select(2),
  ordinal3: new Intl.PluralRules("en-US", { type: "ordinal" }).select(3),
  ordinal4: new Intl.PluralRules("en-US", { type: "ordinal" }).select(4),
}));
capture("pluralArabic", () => {
  const rules = new Intl.PluralRules("ar");
  return [0, 1, 2, 3, 11, 100].map((value) => [value, rules.select(value)]);
});
capture("pluralResolved", () => new Intl.PluralRules("ar", { type: "cardinal" }).resolvedOptions());
capture("pluralSupportedLocales", () => Intl.PluralRules.supportedLocalesOf(["ar", "de-DE", "zz-ZZ"]));

capture("relativeEnglish", () => ({
  yesterday: new Intl.RelativeTimeFormat("en-US", { numeric: "auto" }).format(-1, "day"),
  future: new Intl.RelativeTimeFormat("en-US").format(2, "day"),
}));
capture("relativeFrench", () => new Intl.RelativeTimeFormat("fr", { numeric: "auto" }).format(-1, "day"));
capture("relativeParts", () => new Intl.RelativeTimeFormat("en-US").formatToParts(2, "day"));
capture("relativeResolved", () => new Intl.RelativeTimeFormat("fr", { numeric: "auto", style: "long" }).resolvedOptions());
capture("relativeSupportedLocales", () => Intl.RelativeTimeFormat.supportedLocalesOf(["fr", "de-DE", "zz-ZZ"]));

capture("localeObject", () => {
  const locale = new Intl.Locale("en-us");
  const maximized = locale.maximize();
  return {
    text: locale.toString(), baseName: locale.baseName, language: locale.language,
    region: locale.region, script: locale.script, maximized: maximized.toString(),
    minimized: maximized.minimize().toString(),
  };
});

capture("displayNames", () => new Intl.DisplayNames("en-US", { type: "region" }).of("DE"));
capture("displayNamesResolved", () => new Intl.DisplayNames("en-US", { type: "region" }).resolvedOptions());

console.log("SNAPBACK2_INTL_AUDIT|" + JSON.stringify(result));
