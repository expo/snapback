# Snapback2 selected-ES2020 Intl audit — 2026-09-11

Scope: the `collectEffectLib("es2020")` TypeScript declaration closure and the
adjacent runtime APIs named in the release investigation. This is not a full
ECMA-402 conformance audit.

## Governing context

- LLP 1000 decision 3: Ibex/Hermes is effects-only and the published binary
  carries it.
- LLP 1003 §1: effect bodies receive TypeScript's ES5–ES2020 library closure;
  every admitted name is promised a compile-and-execute Hermes witness.
- LLP 1003 §3 and §5: the relevant runtime is `Hermes::new(Closed)` followed by
  `install_stdlib`, bindings and hardening; the engine suite is the proof.
- `rules/RULES.md`: only implemented behavior binds; add no new apparatus.

## Exact declaration provenance

`snapback2/packages/snapback2/build.mjs` recursively collects TypeScript 5.9.2
from `lib.es2020.d.ts`. The selected files declare:

- String locale case: `lib.es5.d.ts` and `lib.es2020.string.d.ts`.
- `Intl.DateTimeFormat#formatToParts`: `lib.es2017.intl.d.ts`.
- `Intl.PluralRules` and `Intl.NumberFormat#formatToParts`:
  `lib.es2018.intl.d.ts`.
- `Intl.RelativeTimeFormat`, `Intl.Locale`, `Intl.DisplayNames`, and ES2020
  Number/DateTime options: `lib.es2020.intl.d.ts`.
- BigInt locale formatting: `lib.es2020.bigint.d.ts`.

`DisplayNames` is therefore in the exact compiler-selected closure; it was not
inferred from the installed TypeScript library as a whole.

## Bounded result table

| Declared surface | Existing Linux runtime | Existing Mac runtime | Classification |
|---|---|---|---|
| `Intl.getCanonicalLocales` | Canonicalizes/deduplicates and rejects an invalid tag | Same | Good in focused cases |
| `Intl.Collator`; `String#localeCompare` | Locale, numeric, sensitivity, punctuation and supported-locale cases match the same-host Node/ICU reference | Same | Good in focused cases |
| `Intl.DateTimeFormat#format`; Date locale methods | Locale, timezone, field, `dateStyle`/`timeStyle`, calendar cases format meaningfully | Same in the sparse cross-host cases | Good in focused cases |
| `DateTimeFormat#formatToParts` | Silent stub: one `integer` part whose value is the epoch milliseconds; joined parts never equal `format` | Produces real typed parts in the sparse probe | Linux-specific blocker |
| `DateTimeFormat#resolvedOptions` | Retains requested fields/styles/timezone/locale, but omits required `calendar`/`numberingSystem` in ordinary/style cases and omits `numberingSystem` even when explicitly requested | Sparse probe is real; detailed retained older binary probe aborted before output | Incomplete state; resolved options alone cannot faithfully reconstruct parts |
| `Intl.NumberFormat` core | Comprehensive silent stub: fixed six-decimal output; ignores locale, grouping, currency, percent, rounding, minimum digits, sign, unit and compact notation; accepts invalid currency | Locale/currency/percent/rounding/minimum digits work | Linux-specific core blocker |
| `NumberFormat#formatToParts` / `resolvedOptions` / `supportedLocalesOf` | One fake integer part; minimal/bogus options; wrong locale result (`de-DE,tr,zz-ZZ` request returned `en-CA,de-DE`) | `formatToParts` absent; resolved/supported are meaningful | Linux blocker plus inherited selected-surface gap |
| ES2020 NumberFormat additions | Ignored with the rest | `signDisplay` and compact ignored; unit silently converts `5 km/h` to `3.107 miles/h`; parts absent | Shared broader conformance gap, not needed to explain the new Linux regression |
| `Number#toLocaleString` | Inherits the six-decimal NumberFormat stub | Meaningful locale formatting | Linux-specific blocker |
| `BigInt#toLocaleString` | Raw ungrouped digits | Raw ungrouped digits | Inherited cross-platform selected-surface gap |
| `String#toLocaleLowerCase/UpperCase` | True stub: returns literal `lowered` / `uppered`, including empty strings, surrogate-containing strings and invalid locale tags | Turkish/default case probes are correct | Linux-specific blocker; invalid-locale validation is also absent |
| `Intl.PluralRules` | Absent | Absent | Inherited selected ES2018 closure gap |
| `Intl.RelativeTimeFormat`, `Intl.Locale`, `Intl.DisplayNames` | Absent | Absent | Inherited selected ES2020 closure gaps |

Not audited and not part of the selected ES2020 closure: newer Node-visible
`DurationFormat`, `ListFormat`, `Segmenter`, and `supportedValuesOf` surfaces.

## Date-parts implementation constraint found by the probe

Linux `resolvedOptions()` is not complete enough by itself: default and style
formatters omit calendar/numbering system, style formatters omit hour-cycle
state, and explicit `numberingSystem: "thai"` is omitted. A correct seam must
capture construction inputs in private state in addition to the captured real
`format` getter / `resolvedOptions` intrinsic. Its acceptance must require that
the values of returned parts rejoin byte-for-byte to that captured formatter's
output across numeric, named, timezone, style, and non-Gregorian cases, and
native receiver-brand failures must remain failures.

## Evidence

- Linux run root: `/home/ccheever/release-inputs/snapback2-intl-audit-20260911`
  - `probe.js`, `run-ibex.{log,pid,started,ended,exit}`
  - `probe-details.js`, `run-details-ibex.{log,pid,started,ended,exit}`
  - same-host reference: `run-node.*`, `run-details-node.*`
  - existing binary SHA-256:
    `c14809eac4259c0c99d8b4f42ece1fd702549356a06affaac6b85ef843bcb061`
- Mac run root: `/Users/ccheever/release-inputs/snapback2-intl-audit-20260911`
  - sparse successful comparison: `run-ibex-mac.*`
  - the two detailed runs aborted in the retained older debug CLI (exit 139)
    and are preserved, not used for positive claims.

All launched probe PIDs exited. No Cargo/build, repository edit, stage,
publication, registry mutation, or benchmark actor was run.
