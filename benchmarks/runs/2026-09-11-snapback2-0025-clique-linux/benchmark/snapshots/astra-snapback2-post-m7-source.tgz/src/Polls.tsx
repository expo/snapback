import React,{useState} from 'react';
import {View,Button,Text} from 'react-native';
import {useQuery,useMutation,useViewer} from 'snapback2/react';
import {api} from 'snapback2/client';
import {PollCompose,PollDisplay} from '../ui';
export function PollComposer({conversationId}:{conversationId:string}){
 const create=useMutation(api.polls.create);
 const [open,setOpen]=useState(false),[question,setQuestion]=useState(''),[options,setOptions]=useState(['','']),[error,setError]=useState('');
 return <View><Button title={open?'Cancel poll':'Create poll'} testID="sm-poll-open" onPress={()=>setOpen(!open)}/>{open?<PollCompose question={question} options={options} onChangeQuestion={setQuestion} onChangeOption={(i,v)=>setOptions(o=>o.map((x,j)=>i===j?v:x))} onAddOption={()=>setOptions(o=>[...o,''])} onRemoveOption={i=>setOptions(o=>o.filter((_,j)=>i!==j))} submitting={create.inFlight} onSubmit={async(q,o)=>{const r=await create.run({messageId:crypto.randomUUID(),conversationId,question:q,options:o});if(r.state==='rejected')setError(r.message);else{setOpen(false);setQuestion('');setOptions(['',''])}}}/>:null}{error?<Text testID="sm-poll-error">{error}</Text>:null}</View>
}
export function Poll({message}:{message:any}){
 const viewer=useViewer(),q=useQuery(api.polls.view,{messageId:message.id}),vote=useMutation(api.polls.vote);
 const [selected,setSelected]=useState<number|null>(null),[error,setError]=useState('');
 const votes=q.data?.votes??[];
 const pending=vote.inFlight||vote.work?.entry.state==='queued';
 const mine=pending&&selected!==null?selected:votes.find(v=>v.actor===viewer)?.option;
 return <View><PollDisplay question={message.body??''} options={(message.pollOptions??[]).map((label:string,i:number)=>({id:message.id+'-option-'+i,label,count:votes.filter(v=>v.option===i).length,mine:mine===i,pending:pending&&selected===i}))} onVote={async option=>{setSelected(option);setError('');const r=await vote.run({messageId:message.id,option,mutationId:crypto.randomUUID()});if(r.state==='rejected')setError(r.message)}}/>{error?<Text testID="sm-poll-error">{error}</Text>:null}</View>
}
