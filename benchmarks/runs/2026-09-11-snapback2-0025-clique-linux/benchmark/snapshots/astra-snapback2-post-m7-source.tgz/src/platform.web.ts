import {browserTokenStore} from 'snapback2/client';
import * as Browser from 'snapback2/react';
export const store=(url:string)=>browserTokenStore(globalThis.localStorage,'clique:'+url);
// TypeScript's native condition is global; Metro selects the browser arm here.
export const offline={store:(Browser as any).indexedDbRangeStore()};
