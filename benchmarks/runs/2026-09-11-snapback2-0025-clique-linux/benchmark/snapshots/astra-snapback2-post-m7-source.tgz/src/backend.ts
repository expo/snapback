import Constants from 'expo-constants';
// Expo's public variable is compiled per client build; the app config supplies a fallback.
export const backendUrl = process.env.EXPO_PUBLIC_SNAPBACK_URL ?? Constants.expoConfig?.extra?.snapbackUrl;
