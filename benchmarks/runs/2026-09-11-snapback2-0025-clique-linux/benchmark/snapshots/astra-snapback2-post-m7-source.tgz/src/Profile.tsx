import React,{useState} from 'react';
import {View,Text,ScrollView,Button,Platform,Linking} from 'react-native';
import {useQuery,useMutation,AssetImage} from 'snapback2/react';
import {api} from 'snapback2/client';
import {useRouter} from 'expo-router';
import * as Picker from 'expo-image-picker';
import {ProfileForm} from '../ui';
import {AuthorPosts,NavTabs} from './Social';
export function ProfileEditor({creating=false}:any){
 const router=useRouter(),q=useQuery(api.profiles.mine,{});const save=useMutation(creating?api.profiles.createMyProfile:api.profiles.updateMyProfile), avatar=useMutation(api.profiles.setAvatar);
 const [values,setValues]=useState<any>(null),[error,setError]=useState(''),[file,setFile]=useState<any>(null);
 const v=values??{displayName:q.data?.displayName??'',handle:q.data?.handle??'',bio:q.data?.bio??'',location:q.data?.location??'',link:q.data?.link??''};
 async function submit(){setError('');const result=await save.run({...v,link:v.link||null,avatarUrl:null});if(result.state==='rejected'){setError(result.message??JSON.stringify(result));return}if(file){const r=await avatar.run({avatar:file});if(r.state==='rejected'){setError(r.message??JSON.stringify(r));return}}if(!creating)router.replace('/profile/'+v.handle)}
 return <ScrollView><Text>{creating?'Create your profile':''}</Text><ProfileForm mode="edit" values={v} onChange={p=>setValues({...v,...p})} onPressSave={submit} saving={save.inFlight} errorText={error} onPressAvatar={async()=>{if(Platform.OS==='web'){(document.getElementById('avatar-file') as any)?.click()}else{const r=await Picker.launchImageLibraryAsync({mediaTypes:['images']});if(!r.canceled)setFile(r.assets[0])}}}/>{Platform.OS==='web'?React.createElement('input',{id:'avatar-file',type:'file',accept:'image/*','data-testid':'sm-avatar-file',onChange:(e:any)=>setFile(e.target.files[0])}):null}{file?<Text>Photo selected</Text>:null}</ScrollView>
}
export function Profile({handle}:any){const q=useQuery(api.profiles.byHandle,{handle}),mine=useQuery(api.profiles.mine,{}),router=useRouter();const social=useQuery(api.profiles.social,{handle}),follow=useMutation(api.follows.setFollow);const p=q.data;if(!p)return <Text>Loading profile…</Text>;const own=p.principal===mine.data?.principal;return <ScrollView><NavTabs/>{p.avatar?<View testID="sm-profile-image"><AssetImage asset={p.avatar} style={{width:72,height:72}}/></View>:null}<ProfileForm mode={own?'view-own':'view-other'} {...p} link={p.link??undefined} followerCount={social.data?.followers??0} followingCount={social.data?.following??0} following={social.data?.mine??false} onPressFollow={()=>follow.run({target:p.principal,following:!social.data?.mine,mutationId:crypto.randomUUID()})} onPressEdit={()=>router.push('/profile/edit')} onPressFeed={()=>router.push('/')} onPressLink={Linking.openURL}/>{own?<Button title="Insights" testID="sm-profile-insights" onPress={()=>router.push('/insights')}/>:null}<AuthorPosts author={p.principal}/></ScrollView>}
