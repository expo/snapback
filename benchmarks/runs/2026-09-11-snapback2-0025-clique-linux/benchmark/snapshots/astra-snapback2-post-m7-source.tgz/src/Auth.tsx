import React,{useState,useRef} from 'react';
import { View, Text } from 'react-native';
import { useAuth, useQuery } from 'snapback2/react';
import { api } from 'snapback2/client';
import { AuthForm } from '../ui';
import { ProfileEditor } from './Profile';
export function Auth({children}:any){
 const {session,actions}=useAuth(); const [mode,setMode]=useState<'sign-in'|'sign-up'>('sign-in'); const [email,setEmail]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 if(session.viewer??session.restoringViewer) return <Onboard key={session.viewer??session.restoringViewer}>{children}</Onboard>;
 if(session.state==='hydrating') return <Text>Restoring session…</Text>;
 return <View style={{flex:1,justifyContent:'center',maxWidth:650,width:'100%',alignSelf:'center'}}><AuthForm mode={mode} email={email} password={password} onChangeEmail={setEmail} onChangePassword={setPassword} onToggleMode={()=>setMode(mode==='sign-in'?'sign-up':'sign-in')} errorText={error} submitting={busy} onSubmit={async()=>{setBusy(true);setError('');try {await actions[mode==='sign-in'?'login':'signup']({email,password});setPassword('')}catch(e:any){setError(e.message)}finally{setBusy(false)}}}/></View>
}
function Onboard({children}:any){const q=useQuery(api.profiles.mine,{}),confirmed=useRef(false);if(q.data)confirmed.current=true;if(confirmed.current)return <><InboxSync/>{children}</>;if(q.status==='loading'||q.data===undefined)return <Text>Loading profile…</Text>;return <ProfileEditor creating/>}

function InboxSync(){useQuery(api.messages.inbox,{c:null},{drain:true});return null}
