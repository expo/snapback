import {createClient} from 'snapback2/client';import {backendUrl} from './backend';import {store} from './platform';
export function onlineClient(){const url=backendUrl;return createClient({url,tokenStore:store(url),fetch:(input,init)=>fetch(input,{...init,keepalive:true})})}
