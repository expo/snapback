import React from 'react';import {AssetImage,AssetVideo,useAssetFile} from 'snapback2/react-native';
export function Media({asset,video=false}:any){return video?<AssetVideo asset={asset} style={{width:300,height:240}}/>:<AssetImage asset={asset} style={{width:300,height:240}}/>}
export function useImageUri(asset:any){return useAssetFile(asset)}
