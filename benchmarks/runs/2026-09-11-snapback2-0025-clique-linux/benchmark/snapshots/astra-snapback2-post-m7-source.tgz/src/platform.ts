import { expoSecureTokenStore } from 'snapback2/expo';
export const store = (url:string) => expoSecureTokenStore(Array.from(url, c => c.codePointAt(0)!.toString(16)).join('-'));
export const offline={};
