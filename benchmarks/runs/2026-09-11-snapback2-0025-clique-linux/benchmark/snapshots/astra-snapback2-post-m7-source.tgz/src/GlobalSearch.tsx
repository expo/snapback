import React,{useEffect,useRef,useState} from 'react';
import {Button,Text} from 'react-native';
import {useConnection,useSnapbackClient} from 'snapback2/react';
import {api} from 'snapback2/client';
import {useRouter} from 'expo-router';
import {SearchBar} from '../ui';
import {onlineClient} from './online';
// Each chat uses the same certified, authorized bounded query. Discovery is paged,
// so a prolific DM account does not silently lose its later conversations.
export function GlobalSearch({term,setTerm}:any){
 const twin=useSnapbackClient(),connection=useConnection(),router=useRouter();
 const [limit,setLimit]=useState(20);const [rows,setRows]=useState<any[]>([]),[busy,setBusy]=useState(false),[error,setError]=useState(''),[more,setMore]=useState(false);
 const generation=useRef(0),tail=useRef<any[]>([]),clientRef=useRef<any>(null);
 async function batch(client:any,seats:any[],replace:boolean,token:number){
  const found:any[]=[],next:any[]=[];let i=0;
  await Promise.all(Array.from({length:Math.min(8,seats.length)},async()=>{while(i<seats.length){const seat=seats[i++];const q=await client.query(api.messages.searchChat,{conversationId:seat.id,term,c:seat.c??null});if(token!==generation.current)return;for(const m of q.data??[])found.push({...m,title:seat.title});if(q.next)next.push({...seat,c:q.next});}}));
  if(token!==generation.current)return;
  tail.current=next;setMore(next.length>0);setRows(old=>[...new Map([...(replace?[]:old),...found].map(m=>[m.id,m])).values()].sort((a,b)=>b.at-a.at||b.id.localeCompare(a.id)));
 }
 useEffect(()=>{const token=++generation.current;let client:any;setRows([]);setLimit(20);setMore(false);setError('');if(!term.trim())return;const timer=setTimeout(async()=>{setBusy(true);try{client=connection==='connected'?onlineClient():twin;clientRef.current=client;await client.ready;let c:any=null;const seats:any[]=[];do{const q=await client.query(api.groups.mine,{c});if(token!==generation.current)return;for(const seat of q.data??[])seats.push({id:seat.conversationId,title:seat.conversation?.title??seat.conversationId});c=q.next;}while(c);await batch(client,seats,true,token);}catch(e){if(token===generation.current)setError(String(e))}finally{if(token===generation.current)setBusy(false)}},250);return()=>{clearTimeout(timer);if(client&&client!==twin)void client.close()}},[term,connection,twin]);
 return <><SearchBar value={term} onChangeText={setTerm} results={rows.slice(0,limit).map(m=>({id:m.id,title:m.body??'Media message',subtitle:new Date(m.at).toLocaleString(),groupLabel:m.title}))} onPressResult={id=>{const m=rows.find(m=>m.id===id);if(m)router.push('/chat/'+m.conversationId)}}/>{busy?<Text>Searching conversations…</Text>:null}{error?<Text>{error}</Text>:null}{(more||rows.length>limit)?<Button title="More results" disabled={busy} onPress={async()=>{if(rows.length>limit){setLimit(n=>n+20);return}setBusy(true);try{await batch(clientRef.current,tail.current,false,generation.current);setLimit(n=>n+20)}finally{setBusy(false)}}}/>:null}</>;
}
