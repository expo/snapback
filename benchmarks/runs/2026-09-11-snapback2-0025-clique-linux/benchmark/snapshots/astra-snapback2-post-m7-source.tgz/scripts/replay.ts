import {readFileSync,writeFileSync,appendFileSync,mkdirSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
import {createClient,api} from 'snapback2/client';
const arg=(key,fallback)=>{const i=process.argv.indexOf(key);return i<0?fallback:process.argv[i+1]};
const path=arg('--log','instrument/fixtures/sample-50.log'),project=arg('--project','.'),url=arg('--url','http://127.0.0.1:53200'),out=arg('--out','evidence/sample-replay'),isScale=path.endsWith('/scale.log');
mkdirSync(out,{recursive:true});
const start=Number(process.env.REPLAY_CLOCK_START)||Math.floor(Date.now()/1000);appendFileSync('run-log.md',`${start} ${isScale?'scale replay':'adapter conformance'} start log=${path} project=${project} evidence=${out}\n`);
execFileSync('node',['instrument/fixtures/validate.mjs',path],{stdio:'pipe'});
const source=readFileSync(path,'utf8'),lines=source.trimEnd().split('\n'),hash=createHash('sha256').update(source).digest('hex');
const cli=(args)=>execFileSync(resolve('node_modules/.bin/snapback2'),[...args,'--project',project,'--json'],{encoding:'utf8',maxBuffer:32*1024*1024});
cli(['run','runtime.setReplayMode','{"enabled":true}','--as','system']);
const clients=new Map(),principals=new Map(),credentials=new Map(),conversationIds=new Map();
const personas=JSON.parse(readFileSync('instrument/fixtures/personas.json','utf8'));for(const p of personas.starter)credentials.set(p.id,p);
const mapFile=resolve(project,'replay-principals.json');try{for(const [k,v] of Object.entries(JSON.parse(readFileSync(mapFile,'utf8'))))principals.set(k,v)}catch{}
async function client(actor){if(clients.has(actor))return clients.get(actor);const p=credentials.get(actor);if(!p)throw Error('Unknown actor '+actor);const c=createClient({url});await c.ready;const s=await c.auth.login({email:p.email,password:p.password});principals.set(actor,s.viewer);clients.set(actor,c);return c}
async function principal(actor){if(!principals.has(actor))await client(actor);return principals.get(actor)}
async function call(c,op,args){const r=await c.mutation(op,args);if(r.state!=='committed')throw Error(JSON.stringify({op:op.op,result:r}));return r}
const file=(p)=>new File([readFileSync(resolve('instrument/fixtures',p))],p,{type:p.endsWith('.mp4')?'video/mp4':'image/png'});
const conv=id=>conversationIds.get(id)??id;
const receiptFile=out+'/settlements.jsonl';writeFileSync(receiptFile,'');let count=0,excludedMs=0;
try{
for(let index=0;index<lines.length;index++){
 if(Date.now()-start*1000-excludedMs>4*60*60*1000)throw Error('Scale replay wall cap exhausted');
 const line=lines[index];if(line.startsWith('# checkpoint ')){writeFileSync(mapFile,JSON.stringify(Object.fromEntries(principals)));const checkpoint=line.slice(13);const began=Date.now();appendFileSync('run-log.md',`${Math.floor(began/1000)} scale checkpoint ${checkpoint} verification start evidence=${out}\n`);execFileSync(process.execPath,['scripts/verify-replay.mjs','--project',project,'--checkpoint',checkpoint,'--out',out],{stdio:'inherit'});excludedMs+=Date.now()-began;continue}
 const tokens=line.match(/"(?:[^"\\]|\\.)*"|\S+/g).map(x=>x.startsWith('"')?JSON.parse(x):x);const [,actor,verb,...a]=tokens;let r;
 if(verb==='register'){credentials.set(actor,{id:actor,email:a[0],password:a[1]});let c=createClient({url});await c.ready;let session;try{session=await c.auth.signup({email:a[0],password:a[1]})}catch{session=await c.auth.login({email:a[0],password:a[1]})}clients.set(actor,c);principals.set(actor,session.viewer);r={state:'committed',data:{viewer:session.viewer}}}
 else{const c=await client(actor);
 if(verb==='profile-set'){const [displayName,handle,bio,location,link,path]=a;const current=await c.query(api.profiles.mine,{});r=await call(c,current.data?api.profiles.updateMyProfile:api.profiles.createMyProfile,{displayName,handle,bio,location,link,avatarUrl:null});r=await call(c,api.profiles.setAvatar,{avatar:file(path)})}
 else if(verb==='follow')r=await call(c,api.follows.setFollow,{target:await principal(a[0]),following:a[1]==='set',mutationId:a[2]});
 else if(verb==='post'){const existing=await c.query(api.feeds.thread,{postId:a[0],c:null});r=existing.data?.parent?{state:'committed',data:{id:a[0],alreadyPresent:true}}:await call(c,api.posts.createPost,{postId:a[0],body:a[2],parent:null,images:a[1]==='images'?a[3].split(',').map(file):null,clip:a[1]==='video'?file(a[3]):null})}
 else if(verb==='like'||verb==='repost')r=await call(c,verb==='like'?api.posts.setLike:api.posts.setRepost,{postId:a[0],active:a[1]==='set',mutationId:a[2]});
 else if(verb==='reply')r=await call(c,api.posts.createPost,{postId:a[0],parent:a[1],body:a[2],images:null,clip:null});
 else if(verb==='dm-create'){r=await call(c,api.groups.dmCreate,{conversationId:a[0],other:await principal(a[1])});conversationIds.set(a[0],r.data.id)}
 else if(verb==='group-create')r=await call(c,api.groups.groupCreate,{conversationId:a[0],members:[await principal(a[1])],title:a[2],description:a[3]});
 else if(verb==='member-add')r=await call(c,api.groups.memberAdd,{conversationId:conv(a[0]),principal:await principal(a[1])});
 else if(verb==='send')r=await call(c,api.messages.send,{messageId:a[0],conversationId:conv(a[1]),body:a[2],quoteId:a[3]?.slice(6)??null});
 else if(verb==='send-media'){const current=await c.query(api.messages.history,{conversationId:conv(a[1]),c:null});if(current.data?.some(m=>m.id===a[0]))r={state:'committed',data:{id:a[0],alreadyPresent:true}};else r=await call(c,a[2]==='video'?api.messages.sendClip:a[5]==='view-once'?api.messages.sendOncePhoto:api.messages.sendPhoto,{messageId:a[0],conversationId:conv(a[1]),caption:a[4],...(a[2]==='video'?{clip:file(a[3])}:{photo:file(a[3])})})}
 else if(verb==='react')r=await call(c,api.messages.react,{messageId:a[0],emoji:a[1],mutationId:a[2]});
 else throw Error('Unsupported verb '+verb);
 }
 count++;appendFileSync(receiptFile,JSON.stringify({line:index+1,action:count,actor,verb,state:r.state,intent:r.intent??null,entityId:r.data?.id??null,sourceSha256:createHash('sha256').update(line).digest('hex'),settledAt:Date.now()})+'\n');if(count%1000===0)console.log(JSON.stringify({actions:count,at:Date.now()}));
}
writeFileSync(mapFile,JSON.stringify(Object.fromEntries(principals)));if(isScale)execFileSync(process.execPath,['scripts/verify-replay.mjs','--project',project,'--checkpoint','100%','--out',out],{stdio:'inherit'});
writeFileSync(out+'/result.json',JSON.stringify({pass:true,start,end:Math.floor(Date.now()/1000),actions:count,sourceSha256:hash,excludedProbeMs:excludedMs},null,2));
appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} ${isScale?'scale replay':'adapter conformance'} end pass=true actions=${count} excludedProbeMs=${excludedMs} verification=${isScale?'manifest verified':'sample pending semantic suite'} evidence=${out}\n`);
}catch(e){writeFileSync(out+'/result.json',JSON.stringify({pass:false,start,end:Math.floor(Date.now()/1000),actions:count,error:String(e),excludedProbeMs:excludedMs},null,2));appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} replay error attribution=ambiguous actions=${count} ${String(e)} evidence=${out}\n`);throw e}
finally{for(const c of clients.values())await c.close();if(!isScale)cli(['run','runtime.setReplayMode','{"enabled":false}','--as','system'])}
process.exit();
