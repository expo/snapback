import {pollsSuite} from './polls-suite.mjs';
import {insightsSuite} from './insights-suite.mjs';
import {offlineSuite} from './offline-suite.mjs';
import {ephemeralSuite} from './ephemeral-suite.mjs';
import {chromium} from '../choreography/node_modules/playwright/index.mjs';
import {mediaSuite} from './media-suite.mjs';
import {messagingSuite} from './messaging-suite.mjs';
import {socialSuite} from './social-suite.mjs';
import assert from 'node:assert/strict';import {readFileSync,writeFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';
const m=process.argv[process.argv.indexOf('--milestone')+1]||'m1';const base=process.env.CHOREO_BASE_URL||'http://127.0.0.1:53201';
const records=[];let browser;
async function test(ids,name,fn){await fn();records.push({ids,name,pass:true});console.log('PASS',ids.join(','),name)}
try{
for(const segment of ['m1','m2','m3'].slice(0,Math.min(3,Number(m.slice(1)))))execFileSync('npm',['run','seed','--','--segment',segment],{stdio:'pipe'});
browser=await chromium.launch({headless:true});const page=await browser.newPage();page.setDefaultTimeout(20000);
if(m==='m1'){
await test(['m1-a01','m1-a02'],'signup and profile onboarding reaches authenticated feed',async()=>{await page.goto(base);await page.getByTestId('sm-auth-toggle').click();const id='a'+Date.now();await page.getByTestId('sm-auth-email').fill(id+'@example.com');await page.getByTestId('sm-auth-password').fill('Acceptance!2026');await page.getByTestId('sm-auth-submit').click();await page.getByTestId('sm-profile-field-displayname').fill('Acceptance');await page.getByTestId('sm-profile-field-handle').fill(id);await page.getByTestId('sm-profile-save').click();await page.getByTestId('sm-feed-tab-following').waitFor();});
await test(['m1-a03'],'duplicate handle visibly rejected',async()=>{await page.goto(base+'/profile/edit');await page.getByTestId('sm-profile-field-handle').fill('alice');await page.getByTestId('sm-profile-save').click();await page.getByTestId('sm-profile-error').waitFor();assert.ok((await page.getByTestId('sm-profile-error').innerText()).length>0);});
await test(['m1-a08'],'profile edits persist',async()=>{await page.getByTestId('sm-profile-field-handle').fill('a'+Date.now());await page.getByTestId('sm-profile-field-displayname').fill('Suite Profile');await page.getByTestId('sm-profile-field-bio').fill('Suite bio');await page.getByTestId('sm-profile-save').click();await page.getByTestId('sm-profile-heading').waitFor();assert.equal(await page.getByTestId('sm-profile-heading').innerText(),'Suite Profile');assert.ok((await page.getByTestId('sm-profile').innerText()).includes('Suite bio'));});
await test(['m1-a10','m1-a11'],'fixture avatar upload and decoded image render',async()=>{await page.getByTestId('sm-profile-edit').click();await page.getByTestId('sm-avatar-file').setInputFiles('instrument/fixtures/media/avatar-alice.png');await page.getByTestId('sm-profile-save').click();await page.getByTestId('sm-profile-image').waitFor();await page.waitForFunction(()=>{const i=document.querySelector('[data-testid="sm-profile-image"] img');return i?.complete&&i.naturalWidth>0});});
await test(['m1-a04'],'duplicate email visibly rejected',async()=>{await page.goto(base+'/settings');await page.getByTestId('sm-settings-logout').click();await page.getByTestId('sm-auth-toggle').click();await page.getByTestId('sm-auth-email').fill('alice@example.com');await page.getByTestId('sm-auth-password').fill('Acceptance!2026');await page.getByTestId('sm-auth-submit').click();await page.getByTestId('sm-auth-error').waitFor();});
}else if(m==='m2'){execFileSync('npm',['run','seed','--','--segment','m2'],{stdio:'pipe'});await socialSuite({test,page,base})}else if(m==='m3'){execFileSync('npm',['run','seed','--','--segment','m3'],{stdio:'pipe'});await messagingSuite({test,page,base})}else if(m==='m4'){await mediaSuite({test,page,base})}else if(m==='m5'){await ephemeralSuite({test,page,base})}else if(m==='m6'){await offlineSuite({test,page,base})}else if(m==='m7'){await pollsSuite({test,page,base})}else if(m==='m8'){await insightsSuite({test,page,base})}else throw Error('Milestone suite not implemented: '+m);
const manifest=JSON.parse(readFileSync('instrument/schema/social-messenger/assertions.json'));const required=manifest.milestones[m.toUpperCase()].assertions.filter(a=>a.executor==='suite-required').map(a=>a.id);const covered=new Set(records.flatMap(r=>r.ids));assert.deepEqual([...covered].sort(),required.sort());
writeFileSync(`evidence/suite-${m}.json`,JSON.stringify({pass:true,records,at:Date.now()},null,2));writeFileSync(`evidence/coverage-${m}.json`,JSON.stringify({format:'clique-coverage-manifest.v1',instrument:'social-messenger@0.3.6-m8',milestones:{[m]:manifest.milestones[m.toUpperCase()].assertions.filter(a=>a.executor==='suite-required').map(a=>a.id)},tests:records},null,2));
let status={};try{status=JSON.parse(readFileSync('evidence/suite-status.json'))}catch{}status[m]={pass:true,receipt:`suite-${m}.json`};writeFileSync('evidence/suite-status.json',JSON.stringify(status,null,2));
}catch(e){console.error(e);writeFileSync(`evidence/suite-${m}.json`,JSON.stringify({pass:false,records,error:String(e)},null,2));let status={};try{status=JSON.parse(readFileSync('evidence/suite-status.json'))}catch{}status[m]={pass:false,receipt:`suite-${m}.json`,outcomeClass:'application'};writeFileSync('evidence/suite-status.json',JSON.stringify(status,null,2));process.exitCode=1}finally{await browser?.close()}

process.exit(process.exitCode??0);
