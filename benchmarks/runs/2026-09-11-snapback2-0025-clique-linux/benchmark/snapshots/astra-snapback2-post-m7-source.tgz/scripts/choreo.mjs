import {spawnSync} from 'node:child_process';import {readFileSync} from 'node:fs';
const personas=JSON.parse(readFileSync('instrument/fixtures/personas.json'));console.log(Object.keys(personas));
const m=process.argv[2]||'m1';
const env={...process.env,CHOREO_BASE_URL:'http://127.0.0.1:53201',CHOREO_LANE_RUN_ID:'astra-clique-snapback2',CHOREO_ALICE_PASSWORD:'Alice!Clique2026',CHOREO_BOB_PASSWORD:'Bob!Clique2026',CHOREO_CAROL_PASSWORD:'Carol!Clique2026',CHOREO_DAVE_PASSWORD:'Dave!Clique2026'};
const r=spawnSync(process.execPath,['choreography/choreography.mjs',m,'--suite-status','evidence/suite-status.json','--setup-identity','setup-identity.json','--receipts',`evidence/choreography-${m}.jsonl`,'--simulator-status','native-status.json',...(Number(m.slice(1))>=3?['--adapter','choreography-adapter.json']:[])],{env,stdio:'inherit'});process.exit(r.status??1);
