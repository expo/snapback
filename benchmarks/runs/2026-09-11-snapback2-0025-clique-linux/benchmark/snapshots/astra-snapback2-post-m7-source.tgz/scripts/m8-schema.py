p='snapback/schema.q';s=open(p).read();s=s.replace('table posts:\n','table posts:\n  day: int ?\n  period: time ?\n  digestEligible: bool ?\n  recipient: principal ?\n');s=s.replace('table likes:\n','table likes:\n  recipient: principal ?\n  day: int ?\n');s=s.replace('table feedEntries:\n','table feedEntries:\n  recipient: principal ?\n');s=s.replace('table follows:\n','table follows:\n  period: time ?\n  digestEligible: bool ?\n');s=s.replace('table messages:\n','table messages:\n  period: time ?\n  digestEligible: bool ?\n');s+='''

maintain authoredCounts: count posts by author, parent
  read <- public
maintain likesReceived: count likes by recipient
  read <- public
maintain repostsReceived: count feedEntries by recipient
  read <- public
maintain repliesReceived: count posts by recipient
  read <- public
maintain dayPosts: count posts by author, parent, day
  read <- public
maintain dayLikes: count likes by recipient, day
  read <- public
maintain periodPosts: count posts by author, parent, period, digestEligible
  read <- public
maintain periodFollowers: count follows by followed, period, digestEligible
  read <- public

table trending:
  postId: posts
  author: principal
  likes: int
  at: time
  expiresAt: time ?
  unique byPost: postId
  by byRank: likes, at, id
  public 'public original post ranking'
  insert <- .author = viewer
  update <- allow
  delete <- allow
''';open(p,'w').write(s)
