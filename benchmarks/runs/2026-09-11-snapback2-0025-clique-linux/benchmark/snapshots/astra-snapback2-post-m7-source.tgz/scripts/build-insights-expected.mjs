import {readFileSync,writeFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';
const project='scale-instance-retry',out='evidence/scale-replay-retry';
function all(table){let rows=[],c;do{const q=JSON.parse(execFileSync('node_modules/.bin/snapback2',['data',table,'--as','system','--project',project,'--limit','500','--json',...(c?['--after',c]:[])],{maxBuffer:32*1024*1024}));rows.push(...q.data);c=q.next}while(c);return rows}
const [posts,likes,feedEntries,follows]=['posts','likes','feedEntries','follows'].map(t=>{let rows=all(t);console.log(t,rows.length);return rows});const reposts=feedEntries.filter(e=>e.kind==='repost'),profiles=Object.values(JSON.parse(readFileSync(project+'/replay-principals.json'))).map(principal=>({principal}));const countBy=(rows,key)=>rows.reduce((a,r)=>(a[key(r)]=(a[key(r)]??0)+1,a),{});
 const day=Math.floor(Date.now()/86400000), byPost=new Map(posts.map(p=>[p.id,p]));
 const stats=Object.fromEntries(profiles.map(p=>[p.principal,{posts:0,likes:0,reposts:0,replies:0,followers:0,following:0,days:Object.fromEntries(Array.from({length:7},(_,i)=>['d'+i,{day:day-6+i,posts:0,likes:0}]))}]));
 for(const p of posts){if(!p.parent){stats[p.author].posts++;const d=Object.values(stats[p.author].days).find(d=>d.day===Math.floor(p.at/86400000));if(d)d.posts++}else stats[byPost.get(p.parent).author].replies++}
 for(const l of likes){const st=stats[byPost.get(l.postId).author];st.likes++;const d=Object.values(st.days).find(d=>d.day===Math.floor(l.at/86400000));if(d)d.likes++}
 for(const e of reposts)stats[byPost.get(e.postId).author].reposts++;
 for(const f of follows){stats[f.follower].following++;stats[f.followed].followers++}
 const likeMap=countBy(likes,l=>l.postId);const ranked=posts.filter(p=>!p.parent&&Date.now()-p.at<86400000).map(p=>({postId:p.id,likes:likeMap[p.id]??0,at:p.at})).sort((a,b)=>b.likes-a.likes||b.at-a.at||b.postId.localeCompare(a.postId)).slice(0,10);
 writeFileSync(out+'/insights-expected.json',JSON.stringify({stats,trending:ranked,at:Date.now()}));

