import {createClient,api} from 'snapback2/client';
import {readFileSync,writeFileSync,appendFileSync} from 'node:fs';import {execFileSync} from 'node:child_process';import {resolve} from 'node:path';import assert from 'node:assert/strict';import {performance} from 'node:perf_hooks';
const arg=(k,d)=>process.argv.includes(k)?process.argv[process.argv.indexOf(k)+1]:d;
const project=arg('--project','scale-instance'),checkpoint=arg('--checkpoint','100%'),out=arg('--out','evidence/scale-replay');
const manifest=JSON.parse(readFileSync('instrument/fixtures/invariant-manifest-combined.json'));const expected=checkpoint==='100%'?manifest.expectedState:manifest.checkpoints[checkpoint].expectedState;
const principalMap=JSON.parse(readFileSync(resolve(project,'replay-principals.json'))),actorOf=Object.fromEntries(Object.entries(principalMap).map(([a,p])=>[p,a]));
const cli=(args)=>JSON.parse(execFileSync(resolve('node_modules/.bin/snapback2'),[...args,'--project',project,'--json'],{encoding:'utf8',maxBuffer:32*1024*1024}));
function all(table){const rows=[];let next=null;do{const r=cli(['data',table,'--as','system','--limit','500',...(next?['--after',next]:[])]);rows.push(...r.data);next=r.next}while(next);return rows}
const tables={};const started=Date.now();
try{
for(const t of ['profiles','posts','follows','likes','feedEntries','conversations','memberships','messages','reactions']){tables[t]=all(t);console.log('VERIFY',checkpoint,t,tables[t].length)}
const {profiles,posts,follows,likes,feedEntries,conversations,memberships,messages,reactions}=tables;const reposts=feedEntries.filter(e=>e.kind==='repost');
const counts={users:profiles.length,profiles:profiles.length,followEdges:follows.length,posts:posts.length,topLevelPosts:posts.filter(p=>!p.parent).length,replies:posts.filter(p=>p.parent).length,activeLikes:likes.length,activeReposts:reposts.length,conversations:conversations.length,dms:conversations.filter(c=>c.kind==='dm').length,groups:conversations.filter(c=>c.kind==='group').length,memberships:memberships.length,messages:messages.length,textMessages:messages.filter(m=>!m.photo&&!m.clip&&!m.oncePhoto).length,mediaMessages:messages.filter(m=>m.photo||m.clip||m.oncePhoto).length,quotedReplies:messages.filter(m=>m.quoteId).length,activeReactions:reactions.length,disappearingSettingsEnabled:conversations.filter(c=>c.disappearing&&c.disappearing!=='off').length};assert.deepEqual(counts,expected.perEntityCounts);
const countBy=(rows,key)=>rows.reduce((a,r)=>(a[key(r)]=(a[key(r)]??0)+1,a),{});
for(const [actor,count] of Object.entries(expected.perUserFollowingCounts))assert.equal(follows.filter(f=>f.follower===principalMap[actor]).length,count,'following '+actor);
for(const [actor,count] of Object.entries(expected.perUserConversationCounts))assert.equal(memberships.filter(m=>m.principal===principalMap[actor]).length,count,'conversations '+actor);
const chatCounts=countBy(messages,m=>m.conversationId);for(const [id,count] of Object.entries(expected.perChatMessageCounts))assert.equal(chatCounts[id]??0,count,'messages '+id);
for(const [id,count] of Object.entries(expected.perGroupMemberCounts))assert.equal(memberships.filter(m=>m.conversationId===id).length,count,'roster '+id);
for(const [id,fixture] of Object.entries(expected.namedO5Fixtures)){
 if(fixture.followingCount!=null)assert.equal(follows.filter(f=>f.follower===principalMap[id]).length,fixture.followingCount,id);
 if(fixture.followerCount!=null)assert.equal(follows.filter(f=>f.followed===principalMap[id]).length,fixture.followerCount,id);
 if(fixture.postCount!=null)assert.equal(posts.filter(p=>p.author===principalMap[id]).length,fixture.postCount,id);
 if(fixture.following)assert.deepEqual(follows.filter(f=>f.follower===principalMap[id]).map(f=>actorOf[f.followed]).sort(),[...fixture.following].sort());
 if(fixture.members)assert.deepEqual(memberships.filter(m=>m.conversationId===id).map(m=>actorOf[m.principal]).sort(),[...fixture.members].sort());
}
if(checkpoint==='100%'){
 const day=Math.floor(Date.now()/86400000), byPost=new Map(posts.map(p=>[p.id,p]));
 const stats=Object.fromEntries(profiles.map(p=>[p.principal,{posts:0,likes:0,reposts:0,replies:0,followers:0,following:0,days:Object.fromEntries(Array.from({length:7},(_,i)=>['d'+i,{day:day-6+i,posts:0,likes:0}]))}]));
 for(const p of posts){if(!p.parent){stats[p.author].posts++;const d=Object.values(stats[p.author].days).find(d=>d.day===Math.floor(p.at/86400000));if(d)d.posts++}else stats[byPost.get(p.parent).author].replies++}
 for(const l of likes){const st=stats[byPost.get(l.postId).author];st.likes++;const d=Object.values(st.days).find(d=>d.day===Math.floor(l.at/86400000));if(d)d.likes++}
 for(const e of reposts)stats[byPost.get(e.postId).author].reposts++;
 for(const f of follows){stats[f.follower].following++;stats[f.followed].followers++}
 const likeMap=countBy(likes,l=>l.postId);const ranked=posts.filter(p=>!p.parent&&Date.now()-p.at<86400000).map(p=>({postId:p.id,likes:likeMap[p.id]??0,at:p.at})).sort((a,b)=>b.likes-a.likes||b.at-a.at||b.postId.localeCompare(a.postId)).slice(0,10);
 writeFileSync(out+'/insights-expected.json',JSON.stringify({stats,trending:ranked,at:Date.now()}));

 for(const [id,e] of Object.entries(manifest.namedSpotEntities.profiles)){const p=profiles.find(p=>p.principal===principalMap[id]);assert.ok(p,id);for(const key of ['displayName','handle','bio','location','link'])assert.equal(p[key],e[key],id+'.'+key);assert.ok(p.avatar)}
 for(const [id,e] of Object.entries(manifest.namedSpotEntities.posts)){const p=posts.find(p=>p.id===id);assert.ok(p,id);assert.equal(p.body,e.text);assert.equal(p.author,principalMap[e.authorId]);assert.equal(p.parent,e.parentPostId);assert.equal(likes.filter(l=>l.postId===id).length,e.activeLikeCount);assert.equal(reposts.filter(r=>r.postId===id).length,e.activeRepostCount);assert.equal(posts.filter(r=>r.parent===id).length,e.directReplyCount)}
 for(const [id,e] of Object.entries(manifest.namedSpotEntities.messages)){const m=messages.find(m=>m.id===id);assert.ok(m,id);assert.equal(m.authorId,principalMap[e.senderId]);assert.equal(m.conversationId,e.conversationId);assert.equal(m.body,e.text??e.caption);assert.equal(m.quoteId,e.quoteId);assert.equal(!!m.oncePhoto,e.viewOnce);assert.deepEqual(reactions.filter(r=>r.messageId===id).map(r=>({userId:actorOf[r.actor],emoji:r.emoji})).sort((a,b)=>a.userId.localeCompare(b.userId)),[...e.reactions].sort((a,b)=>a.userId.localeCompare(b.userId)))}
}
const probes={};const url=readFileSync(resolve(project,'.snapback/dev-url'),'utf8').trim();
for(const [name,op,args,actor] of [['following-500',api.feeds.followingFeed,{c:null},'u0500'],['following-5',api.feeds.followingFeed,{c:null},'u0005'],['celebrity-follower',api.feeds.followingFeed,{c:null},'u0901'],['busy-history',api.messages.history,{conversationId:'g0001',c:null},'u0500']]){const c=createClient({url});await c.ready;await c.auth.login({email:actor+'@example.com',password:JSON.parse(readFileSync('instrument/fixtures/personas.json')).scale.password});try{const times=[];for(let i=0;i<5;i++){const t=performance.now();const result=await c.query(op,args);assert.ok(result.data?.length,'nonempty '+name);times.push(performance.now()-t)}probes[name]={ms:times,note:'Authenticated SDK API latency; independent browser grading remains separate',actor}}finally{await c.close()}}
const receipt={pass:true,checkpoint,started,ended:Date.now(),counts,namedO5:true,allPerUserAndPerChatCounts:true,namedSpots:checkpoint==='100%',probes};writeFileSync(out+'/verification-'+checkpoint.replace('%','')+'.json',JSON.stringify(receipt,null,2));appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} scale verification ${checkpoint} pass=true all entity/user/chat/roster counts and named O5 fixtures checked evidence=${out}\n`);
}catch(e){writeFileSync(out+'/verification-'+checkpoint.replace('%','')+'.json',JSON.stringify({pass:false,checkpoint,error:String(e),started,ended:Date.now()},null,2));throw e}
