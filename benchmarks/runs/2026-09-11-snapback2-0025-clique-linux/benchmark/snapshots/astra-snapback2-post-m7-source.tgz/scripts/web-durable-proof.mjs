import {chromium} from '../choreography/node_modules/playwright/index.mjs';
import {createClient,api} from 'snapback2/client';import assert from 'node:assert/strict';import {writeFileSync,appendFileSync} from 'node:fs';
const base='http://127.0.0.1:53201',backend='http://127.0.0.1:53200',tag='durable-'+Date.now(),texts=[tag+'-one',tag+'-two'];
let context;const dataDir='evidence/web-durable-profile';
try{
context=await chromium.launchPersistentContext(dataDir,{headless:true});let page=context.pages()[0];page.setDefaultTimeout(25000);await page.goto(base);
await page.getByTestId('sm-auth-email').or(page.getByTestId('sm-feed-tab-following')).first().waitFor();
if(await page.getByTestId('sm-auth-email').count()){await page.getByTestId('sm-auth-email').fill('alice@example.com');await page.getByTestId('sm-auth-password').fill('Alice!Clique2026');await page.getByTestId('sm-auth-submit').click()}
await page.getByTestId('sm-feed-tab-following').waitFor();await page.goto(base+'/conversation/bob');await page.getByTestId('sm-convo-input').waitFor();await page.waitForTimeout(1500);
await context.setOffline(true);
for(const text of texts){await page.getByTestId('sm-convo-input').fill(text);await page.getByTestId('sm-convo-send').click();await page.getByTestId('sm-convo-bubble').filter({hasText:text}).waitFor()}
await page.waitForTimeout(1000);await context.close();context=null;
// The web shell must be fetched after browser restart; only the backend is partitioned.
// This is explicitly an additional web proof, never an iOS/native substitute.
context=await chromium.launchPersistentContext(dataDir,{headless:true});await context.route(backend+'/**',r=>r.abort());await context.addInitScript(()=>Object.defineProperty(navigator,'onLine',{get:()=>false,configurable:true}));page=context.pages()[0];page.setDefaultTimeout(25000);await page.goto(base+'/conversation/bob');
for(const text of texts){const bubble=page.getByTestId('sm-convo-bubble').filter({hasText:text});await bubble.waitFor();assert.match(await bubble.innerText(),new RegExp(text))}
await page.screenshot({path:'evidence/web-durable-restored.png'});
await context.unroute(backend+'/**');await page.evaluate(()=>{Object.defineProperty(navigator,'onLine',{get:()=>true,configurable:true});window.dispatchEvent(new Event('online'))});
const c=createClient({url:backend});await c.ready;await c.auth.login({email:'alice@example.com',password:'Alice!Clique2026'});let matches=[];for(let i=0;i<100;i++){const q=await c.query(api.messages.history,{conversationId:'d-alice-bob',c:null});matches=q.data.filter(m=>texts.includes(m.body));if(matches.length===2)break;await new Promise(r=>setTimeout(r,200))}assert.equal(matches.length,2);matches.sort((a,b)=>a.at-b.at);assert.deepEqual(matches.map(m=>m.body),texts);await c.close();writeFileSync('evidence/web-durable-proof.json',JSON.stringify({pass:true,kind:'web-browser-restart-with-backend-partition',nativeSimulator:false,texts,matches:matches.map(m=>({id:m.id,at:m.at})),at:Date.now()},null,2));appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} additional web durable queue restart proof green; web shell available, backend partitioned; not native simulator evidence=evidence/web-durable-proof.json\n`);
}catch(e){writeFileSync('evidence/web-durable-proof.json',JSON.stringify({pass:false,error:String(e),at:Date.now()},null,2));throw e}finally{await context?.close()}
process.exit();
