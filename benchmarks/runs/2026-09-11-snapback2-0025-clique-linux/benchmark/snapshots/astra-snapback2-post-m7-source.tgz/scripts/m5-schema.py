p='snapback/schema.q';s=open(p).read();s=s.replace('  creatorId: principal\n','  creatorId: principal\n  accent: text <=7 ?\n  background: image <=10000000 ?\n  disappearing: enum(\'off\', \'24h\', \'7d\') ?\n  ttlMs: int ?\n');s=s.replace('  update <- deny\n  delete <- deny\n  after insert',"  update <- exists memberships[.id, viewer]\n  delete <- deny\n  after insert",1);s+='''

table profileSearch:
  owner: principal
  field: enum('name', 'handle')
  term: text <=50
  at: time
  unique byOwnerField: owner, field
  by byTerm: wordPrefixes(term), at, id
  public 'registered people directory'
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
''';open(p,'w').write(s)
p='snapback/profiles.q';s=open(p).read().replace('  return insert profiles { principal: viewer, displayName, handle, avatarUrl, bio, location, link }',"  row = insert profiles { principal: viewer, displayName, handle, avatarUrl, bio, location, link }\n  upsert profileSearch[viewer, 'name'] { owner: viewer, field: 'name', term: displayName, at: now }\n  upsert profileSearch[viewer, 'handle'] { owner: viewer, field: 'handle', term: handle, at: now }\n  return row");s=s.replace('  return profiles[existing.id] ! else PROFILE_REQUIRED',"  n = profileSearch[viewer, 'name']\n  h = profileSearch[viewer, 'handle']\n  upsert profileSearch[viewer, 'name'] { owner: viewer, field: 'name', term: displayName, at: n.at ?? now }\n  upsert profileSearch[viewer, 'handle'] { owner: viewer, field: 'handle', term: handle, at: h.at ?? now }\n  return profiles[existing.id] ! else PROFILE_REQUIRED");s+='''
query search(term: text <=128, c: cursor ?):
  page = profileSearch[term] after c last 20 by byTerm
  return page { *, profile: profiles[.owner] }

job fillDirectory():
  chunk p in profiles first 100 by byId:
    if not exists profileSearch[p.principal, 'name']:
      insert profileSearch { owner: p.principal, field: 'name', term: p.displayName, at: now }
      insert profileSearch { owner: p.principal, field: 'handle', term: p.handle, at: now }
''';open(p,'w').write(s)
p='snapback/messages.q';s=open(p).read().replace('first 50 by byPrincipalConversation','first 100 by byPrincipalConversation');s=s.replace('  return { id: row.id }',"  chat = conversations[conversationId] ! else NOT_MEMBER\n  if chat.ttlMs != null:\n    update messages[row] { expiresAt: now + chat.ttlMs }\n  return { id: row.id }");s+='''
query searchChat(conversationId: conversations, term: text <=128, c: cursor ?):
  require isMember(conversationId, viewer) else NOT_MEMBER
  return messages[conversationId, term] after c last 20 by bySearch
''';open(p,'w').write(s)
