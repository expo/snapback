import {readFileSync,writeFileSync} from 'node:fs';
const path=process.env.CLIQUE_WINDOWS_CONFIG||'config/windows.json',w=JSON.parse(readFileSync(path));
writeFileSync('snapback/config.q',`-- Generated from ${path}; server time is always authoritative.\nfn editMs(): ${w.editWindowSeconds*1000}\nfn deleteMs(): ${w.deleteForEveryoneWindowSeconds*1000}\nfn disappear24Ms(): ${w.disappearingOptions.find(x=>x.value==='24h').ttlSeconds*1000}\nfn disappear7Ms(): ${w.disappearingOptions.find(x=>x.value==='7d').ttlSeconds*1000}\n`);console.log('Configured',path);
