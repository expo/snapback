p='snapback/schema.q';s=open(p).read().replace('  creatorId: principal\n','  creatorId: principal\n  latestMessage: messages ?\n');s+='''

table postDigestContribution:
  follower: principal
  followed: principal
  followId: follows
  period: time
  value: int
  unique byFollowPeriod: followId, period
  by byFollow: followId, id
  cap 3 by followId
  read <- .follower = viewer
  insert <- .follower = viewer
  update <- .follower = viewer
  delete <- .follower = viewer
maintain newPostsFollowing: sum postDigestContribution of value by follower, period
  read <- .follower = viewer
''';open(p,'w').write(s)
p='snapback/messages.q';s=open(p).read().replace('  latest = messages[conversationId] last 1 by byConvTime\n  require latest[0].id = messageId else READ_MOVED',"  chat = conversations[conversationId] ! else NOT_MEMBER\n  require chat.latestMessage = null or chat.latestMessage = messageId else READ_MOVED");s=s.replace('    admitUnread(conversationId, period)','    update conversations[chat] { latestMessage: row.id }\n    admitUnread(conversationId, period)');s=s.replace('mutation expire(messageId: messages):\n  releaseUnread(messageId)',"mutation expire(messageId: messages):\n  message = messages[messageId] ! else MESSAGE_REQUIRED\n  chat = conversations[message.conversationId] ! else CHAT_REQUIRED\n  if chat.latestMessage = messageId:\n    update conversations[chat] { latestMessage: null }\n  releaseUnread(messageId)");open(p,'w').write(s)
p='snapback/digest.q';s=open(p).read();a=s.index('job sweep(');b=s.index('  chunk p in profiles',a);s=s[:b]+'''  chunk old in postDigestContribution first 100 by byId:
    (number, remainder) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
    periodStart = cutoff - remainder - digestPeriodMs()
    if old.period < periodStart:
      delete postDigestContribution[old]
  chunk follow in follows first 25 by byId:
    if not replayMode():
      (number, remainder) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
      periodStart = cutoff - remainder - digestPeriodMs()
      upsert postDigestContribution[follow.id, periodStart] { follower: follow.follower, followed: follow.followed, followId: follow.id, period: periodStart, value: postPeriodTotals[follow.followed, periodStart].value ?? 0 }
'''+s[b:];a=s.index('        scratch = insert digestScratch');b=s.index('        newFollowers =',a);s=s[:a]+'        newPosts = newPostsFollowing[p.principal, periodStart]\n'+s[b:];s=s.replace('total.posts','newPosts').replace('        delete digestScratch[scratch]\n','');a=s.index('job backfillUnread():');s=s[:a]+'''job backfillUnread():
  chunk old in chatUnread first 100 by byId:
    delete chatUnread[old]
  chunk message in messages first 10 by byId:
    chat = conversations[message.conversationId] ! else CHAT_REQUIRED
    latest = messages[chat.latestMessage]
    if latest = null or message.at > (latest.at ! else TIME_REQUIRED):
      update conversations[chat] { latestMessage: message.id }
    if message.deleted != true:
      for seat in memberships[message.conversationId] first 50 by byConversationPrincipal:
        mark = readMarks[message.conversationId, seat.principal]
        if message.authorId != seat.principal and message.at >= seat.joinedAt and (mark.readAt = null or message.at > (mark.readAt ! else READ_REQUIRED)):
          old = chatUnread[seat.principal, message.conversationId, seat.id]
          upsert chatUnread[seat.principal, message.conversationId, seat.id] { recipient: seat.principal, conversationId: message.conversationId, membershipId: seat.id, unread: (old.unread ?? 0) + 1 }

proc clearFollow(followId: follows):
  for row in postDigestContribution[followId] first 3 by byFollow:
    delete postDigestContribution[row]

proc admitFollow(followId: follows, follower: principal, followed: principal, period: time):
  upsert postDigestContribution[followId, period - digestPeriodMs()] { follower, followed, followId, period: period - digestPeriodMs(), value: postPeriodTotals[followed, period - digestPeriodMs()].value ?? 0 }
''';open(p,'w').write(s)
p='snapback/follows.q';s=open(p).read();s='proc clearFollow from digest\nproc admitFollow from digest\n'+s;s=s.replace('    return insert follows { period, digestEligible: not replayMode(), follower: viewer, followed: target, at: now } if absent',"    row = insert follows { period, digestEligible: not replayMode(), follower: viewer, followed: target, at: now } if absent\n    present = follows[viewer, target] ! else FOLLOW_REQUIRED\n    admitFollow(present.id, viewer, target, period)\n    return null");s=s.replace('    delete follows[existing]', '    clearFollow(existing.id)\n    delete follows[existing]');open(p,'w').write(s)
