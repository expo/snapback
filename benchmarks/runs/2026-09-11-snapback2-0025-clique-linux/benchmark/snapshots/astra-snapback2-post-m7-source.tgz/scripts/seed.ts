import {existsSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {readFile,writeFile} from 'node:fs/promises';
import {createClient,api} from 'snapback2/client';
const segment=process.argv[process.argv.indexOf('--segment')+1]||'m1';
const url=process.env.CLIQUE_BACKEND_URL||'http://127.0.0.1:53200';
const clients=new Map();const principals=new Map();
const personas=JSON.parse(await readFile('instrument/fixtures/personas.json','utf8')).starter;
async function client(actor){let c=clients.get(actor);if(c)return c;c=createClient({url});await c.ready;clients.set(actor,c);const p=personas.find(x=>x.id===actor);const s=await c.auth.login({email:p.email,password:p.password});principals.set(actor,s.viewer);return c}
async function principal(actor){await client(actor);return principals.get(actor)}
async function call(c,op,args){const r=await c.mutation(op,args);if(r.state!=='committed')throw Error(JSON.stringify(r));return r.data}
async function file(path){return new File([await readFile('instrument/fixtures/'+path)],path,{type:path.endsWith('.mp4')?'video/mp4':'image/png'})}
const log=(await readFile(`instrument/fixtures/starter-${segment}.log`,'utf8')).trim().split('\n');
for(const line of log){const t=line.match(/"(?:[^"\\]|\\.)*"|\S+/g).map(x=>x.startsWith('"')?JSON.parse(x):x);const [,actor,verb,...a]=t;
 if(verb==='register'){const c=createClient({url});await c.ready;clients.set(actor,c);let s;try{s=await c.auth.signup({email:a[0],password:a[1]})}catch{s=await c.auth.login({email:a[0],password:a[1]})}principals.set(actor,s.viewer);continue}
 const c=await client(actor);
 if(verb==='profile-set'){const exists=await c.query(api.profiles.mine,{});if(exists.data)continue;const [displayName,handle,bio,location,link,path]=a;await call(c,api.profiles.createMyProfile,{displayName,handle,bio,location,link,avatarUrl:null});await call(c,api.profiles.setAvatar,{avatar:await file(path)})}
 else if(verb==='follow')await call(c,api.follows.setFollow,{target:await principal(a[0]),following:a[1]==='set',mutationId:a[2]});
 else if(verb==='post'){const existing=await c.query(api.feeds.thread,{postId:a[0],c:null});if(existing.data?.parent)continue;await call(c,api.posts.createPost,{postId:a[0],body:a[2],parent:null,images:a[1]==='images'?await Promise.all(a[3].split(',').map(file)):null,clip:a[1]==='video'?await file(a[3]):null})}
 else if(verb==='like'||verb==='repost')await call(c,verb==='like'?api.posts.setLike:api.posts.setRepost,{postId:a[0],active:a[1]==='set',mutationId:a[2]});
 else if(verb==='reply')await call(c,api.posts.createPost,{postId:a[0],parent:a[1],body:a[2],images:null,clip:null});
 else if(verb==='dm-create')await call(c,api.groups.dmCreate,{conversationId:a[0],other:await principal(a[1])});
 else if(verb==='group-create')await call(c,api.groups.groupCreate,{conversationId:a[0],members:[await principal(a[1])],title:a[2],description:a[3]});
 else if(verb==='member-add')await call(c,api.groups.memberAdd,{conversationId:a[0],principal:await principal(a[1])});
 else if(verb==='send')await call(c,api.messages.send,{messageId:a[0],conversationId:a[1],body:a[2],quoteId:a[3]?.slice(6)??null});
 else throw Error('Unimplemented seed verb: '+verb);
}
const mapFile=(process.env.CLIQUE_PROJECT||'.')+'/replay-principals.json';let previous={};try{previous=JSON.parse(await readFile(mapFile,'utf8'))}catch{}await writeFile(mapFile,JSON.stringify({...previous,...Object.fromEntries(principals)}));
for(const c of clients.values())await c.close();
if(existsSync((process.env.CLIQUE_PROJECT||'.')+'/snapback/digest.q'))execFileSync('node_modules/.bin/snapback2',['run','digest.installSchedule','{}','--as','system','--project',process.env.CLIQUE_PROJECT||'.'],{stdio:'pipe'});
console.log(JSON.stringify({segment,pass:true,actions:log.length}));
