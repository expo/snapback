import assert from 'node:assert/strict';
import {createClient,api} from 'snapback2/client';
import {readFileSync,writeFileSync,copyFileSync} from 'node:fs';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
const execAsync=promisify(execFile);
import {createHash} from 'node:crypto';
export async function pollsSuite({test,page,base}){
 const clients=[];async function client(actor){const c=createClient({url:'http://127.0.0.1:53200'});await c.ready;await c.auth.login({email:actor+'@example.com',password:actor[0].toUpperCase()+actor.slice(1)+'!Clique2026'});clients.push(c);return c}
 const a=await client('alice'),b=await client('bob'),outsider=await client('henry');const q=async(c,op,args)=>(await c.query(op,args)).data;const mut=async(c,op,args)=>{const r=await c.mutation(op,args);assert.equal(r.state,'committed',JSON.stringify(r));return r.data};const id='poll-suite-'+Date.now(),bob=(await b.auth.me()).viewer;
 try{
 await test(['m7-a06'],'backfilled starter counts and current visible corpus match, migration snapshot hashes intact',async()=>{
 const manifest=JSON.parse(readFileSync('m7/pre-snapshot/manifest.json'));for(const p of manifest.personas){const bytes=readFileSync('m7/pre-snapshot/'+p.file);assert.equal(createHash('sha256').update(bytes).digest('hex'),p.sha256);assert.deepEqual(JSON.parse(readFileSync('m7/post-snapshot/'+p.file)),JSON.parse(bytes))}
 let c=null;do{const page=await a.query(api.groups.mine,{c});for(const chat of page.data){let cursor=null,visible=0;do{const h=await a.query(api.messages.history,{conversationId:chat.conversationId,c:cursor});visible+=h.data.filter(m=>!m.deleted).length;cursor=h.next??null}while(cursor);const settings=await q(a,api.groups.settings,{conversationId:chat.conversationId});assert.equal(settings.conversation.messageCount,visible,chat.conversationId)}c=page.next??null}while(c);
 });
 await mut(a,api.groups.groupCreate,{conversationId:id,title:id,description:'Poll acceptance',members:[bob]});
 await page.goto(base);await page.getByTestId('sm-auth-email').fill('alice@example.com');await page.getByTestId('sm-auth-password').fill('Alice!Clique2026');await page.getByTestId('sm-auth-submit').click();await page.getByTestId('sm-feed-tab-following').waitFor();await page.goto(base+'/chat/'+id);
 let pollId;
 await test(['m7-a01'],'group poll UI creation plus server shape, group and membership validation',async()=>{
 await page.getByTestId('sm-poll-open').click();await page.getByTestId('sm-poll-compose-question').fill('Lunch choice?');await page.getByTestId('sm-poll-compose-option').nth(0).fill('Soup');await page.getByTestId('sm-poll-compose-option').nth(1).fill('Salad');await page.getByTestId('sm-poll-compose-submit').click();await page.getByTestId('sm-poll').waitFor();const rows=await q(a,api.messages.history,{conversationId:id,c:null});assert.equal(rows.length,1);pollId=rows[0].id;assert.deepEqual(rows[0].pollOptions,['Soup','Salad']);
 for(const args of [{question:'x'.repeat(201),options:['a','b']},{question:'q',options:['a']},{question:'q',options:['a','b','c','d','e']},{question:'q',options:['a','x'.repeat(51)]}])assert.equal((await a.mutation(api.polls.create,{messageId:crypto.randomUUID(),conversationId:id,...args})).state,'rejected');
 assert.equal((await a.mutation(api.polls.create,{messageId:crypto.randomUUID(),conversationId:'d-alice-bob',question:'q',options:['a','b']})).state,'rejected');assert.equal((await outsider.mutation(api.polls.vote,{messageId:pollId,option:0,mutationId:crypto.randomUUID()})).state,'rejected');
 });
 await test(['m7-a03','m7-a04'],'one vote per user, changeable set-state, duplicate and stale retry cannot revert',async()=>{
 const first={messageId:pollId,option:0,mutationId:crypto.randomUUID()};await mut(a,api.polls.vote,first);await mut(a,api.polls.vote,first);await mut(b,api.polls.vote,{messageId:pollId,option:0,mutationId:crypto.randomUUID()});let view=await q(a,api.polls.view,{messageId:pollId});assert.equal(view.votes.length,2);assert.equal(view.votes.filter(v=>v.option===0).length,2);
 const change={messageId:pollId,option:1,mutationId:crypto.randomUUID()};await mut(a,api.polls.vote,change);await mut(a,api.polls.vote,change);await mut(a,api.polls.vote,first);view=await q(b,api.polls.view,{messageId:pollId});assert.equal(view.votes.length,2);assert.equal(view.votes.filter(v=>v.option===0).length,1);assert.equal(view.votes.filter(v=>v.option===1).length,1);assert.equal((await a.mutation(api.polls.vote,{messageId:pollId,option:2,mutationId:crypto.randomUUID()})).state,'rejected');
 });
 await test(['m7-a07'],'settings count maintains text, polls and repeated tombstones',async()=>{
 const count=async()=>(await q(a,api.groups.settings,{conversationId:id})).conversation.messageCount;assert.equal(await count(),1);const messageId=crypto.randomUUID();await mut(a,api.messages.send,{messageId,conversationId:id,body:'Count this',quoteId:null});assert.equal(await count(),2);await mut(a,api.messages.send,{messageId,conversationId:id,body:'Count this',quoteId:null});assert.equal(await count(),2);await mut(a,api.messages.unsend,{messageId});await mut(a,api.messages.unsend,{messageId});assert.equal(await count(),1);await page.goto(base+'/chatsettings/'+id);await page.getByTestId('sm-chatsettings-message-count').waitFor();await page.waitForFunction(()=>document.querySelector('[data-testid="sm-chatsettings-message-count"]')?.getAttribute('aria-valuetext')==='1');await mut(a,api.messages.unsend,{messageId:pollId});assert.equal(await count(),0);
 });
 for(const c of clients)await c.close();
 await page.close();
 await test(['m7-a09'],'all previously green milestone suites remain green',async()=>{
 const results=[];
 for(const m of ['m1','m2','m3','m4','m5','m6','m8']){
  if(m==='m6'){
   const samples=[];
   for(let i=0;i<30;i++){
    const {stdout}=await execAsync('node_modules/.bin/snapback2',['run','--file','m7/connections.q',JSON.stringify({p:bob}),'--as','system']);
    const value=JSON.parse(stdout).data.connections;samples.push({at:Date.now(),connections:value});writeFileSync('m7/regression/m6-precondition.json',JSON.stringify(samples,null,2));
    if(value===0)break;
    await new Promise(r=>setTimeout(r,1000));
   }
   assert.equal(samples.at(-1).connections,0,'M6 requires disconnected Bob');
  }
  const attempts=[];
  for(let attempt=1;attempt<=3;attempt++){
   const start=Date.now();let timingFailure=false;
   try{
    const {stdout:output}=await execAsync('npm',['run','acceptance','--','--milestone',m],{encoding:'utf8',timeout:600000,maxBuffer:8*1024*1024});
    writeFileSync(`m7/regression/${m}-attempt-${attempt}.log`,output);
    const receipt=JSON.parse(readFileSync(`evidence/suite-${m}.json`));assert.equal(receipt.pass,true);
    copyFileSync(`evidence/suite-${m}.json`,`m7/regression/suite-${m}.json`);
    attempts.push({pass:true,start,end:Date.now()});
   }catch(e){
    const output=String(e.stdout??'')+String(e.stderr??'')+String(e);writeFileSync(`m7/regression/${m}-attempt-${attempt}.log`,output);
    timingFailure=/Timeout|detached from the DOM/.test(output);attempts.push({pass:false,start,end:Date.now(),timingFailure});
   }
   if(attempts.at(-1).pass||!timingFailure)break;
  }
  results.push({milestone:m,pass:attempts.some(a=>a.pass),attempts});writeFileSync('m7/regression/results.json',JSON.stringify(results,null,2));
 }
 assert.ok(results.every(x=>x.pass),JSON.stringify(results));
 });
 }finally{for(const c of clients)await c.close()}
}
