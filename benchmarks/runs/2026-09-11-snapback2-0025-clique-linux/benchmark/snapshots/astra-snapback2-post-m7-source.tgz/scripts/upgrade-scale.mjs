import {readFileSync,writeFileSync,appendFileSync,cpSync,existsSync} from 'node:fs';import {execFileSync} from 'node:child_process';
const result='evidence/scale-replay-retry/result.json',project='scale-instance-retry';
while(!existsSync(result))await new Promise(r=>setTimeout(r,5000));
if(!JSON.parse(readFileSync(result)).pass)throw Error('Scale replay failed; refusing to alter its evidence instance');
appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} M8 full-corpus successor/backfill start after final M6 invariant verification evidence=evidence/scale-upgrade.log\n`);
cpSync('snapback',project+'/snapback',{recursive:true});
function run(args,file){const output=execFileSync('node_modules/.bin/snapback2',[...args,'--project',project],{encoding:'utf8',maxBuffer:100*1024*1024});writeFileSync(file,output);return output}
run(['check'],'evidence/scale-check-m8.log');await new Promise(r=>setTimeout(r,3000));for(let attempt=0;;attempt++){try{run(['dev','--status','--json'],'evidence/scale-status-m8.json');break}catch(e){if(attempt>=119)throw e;console.log('Owner installing successor; status retry',attempt);await new Promise(r=>setTimeout(r,5000))}}
for(const job of ['insights.backfillAnalytics','digest.backfillUnread']){console.log('BEGIN',job,Date.now());run(['run',job,'{}','--as','system','--wait'],'evidence/scale-'+job+'.log');console.log('END',job,Date.now())}
appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} M8 full-corpus successor/backfills complete evidence=evidence/scale-upgrade.log\n`);
writeFileSync('evidence/scale-m8-ready.json',JSON.stringify({pass:true,at:Date.now()}));
