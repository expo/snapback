import {createClient,api} from 'snapback2/client';
import assert from 'node:assert/strict';import {writeFileSync,appendFileSync} from 'node:fs';
const root='http://127.0.0.1:53200',prefix='dg'+Date.now(),users=[];
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function connect(u){const c=createClient({url:root});await c.ready;await c.auth.login({email:u.email,password:u.password});return c}
for(let i=0;i<4;i++){const u={email:prefix+i+'@example.com',password:'Digest!2026proof',handle:prefix+i};const c=createClient({url:root});await c.ready;await c.auth.signup({email:u.email,password:u.password});u.id=(await c.auth.me()).viewer;await c.mutation(api.profiles.createMyProfile,{handle:u.handle,displayName:'Digest '+i,avatarUrl:null,bio:'',location:'',link:null});users.push(u);await c.close()}
let c=await connect(users[0]);let clock=(await c.query(api.digest.clock,{})).data;await c.close();if(clock.periodEnd-clock.now<90000){console.log('WAIT period boundary',clock);await sleep(clock.periodEnd-clock.now+500)}
const clients=await Promise.all(users.map(connect));clock=(await clients[0].query(api.digest.clock,{})).data;
async function mut(i,ref,args){const r=await clients[i].mutation(ref,args);assert.equal(r.state,'committed',JSON.stringify(r));return r.data}
await mut(1,api.follows.setFollow,{target:users[0].id,following:true,mutationId:crypto.randomUUID()});
await mut(2,api.follows.setFollow,{target:users[1].id,following:true,mutationId:crypto.randomUUID()});
for(let i=0;i<2;i++)await mut(0,api.posts.createPost,{postId:prefix+'post'+i,body:'digest period post',parent:null,images:null,clip:null});
await mut(0,api.groups.groupCreate,{conversationId:prefix+'ab',title:'Digest AB',description:'',members:[users[1].id]});
await mut(0,api.groups.groupCreate,{conversationId:prefix+'ac',title:'Digest AC private',description:'',members:[users[2].id]});
for(const pair of ['ab','ac'])await mut(0,api.messages.send,{messageId:prefix+pair+'message',conversationId:prefix+pair,body:'digest unread',quoteId:null});
for(const client of clients)await client.close();
writeFileSync('evidence/digest-proof-waiting.json',JSON.stringify({prefix,users,clock,closedAt:Date.now()},null,2));console.log('READY_FOR_RESTART',JSON.stringify(clock));
await sleep(Math.max(0,clock.periodEnd-Date.now()+18000));
async function inspect(){const rows=[];for(const u of users){const client=await connect(u);rows.push((await client.query(api.digest.mine,{c:null})).data);await client.close()}return rows}
const rows=await inspect();const active=rows.map(r=>r.filter(x=>x.periodStart===clock.periodStart));assert.deepEqual(active.map(r=>r.length),[1,1,1,0]);const b=active[1][0];for(const [k,v] of Object.entries({newFollowers:1,newPostsInFollowing:2,unreadMessages:1,unreadChats:1}))assert.equal(b[k],v,k);assert.equal(active[0][0].newFollowers,1);assert.equal(active[2][0].unreadMessages,1);assert.equal(active[2][0].newPostsInFollowing,0);
console.log('FIRST_PERIOD_PASS',JSON.stringify(active));await sleep(Math.max(0,clock.periodEnd+120000-Date.now()+18000));const next=await inspect();assert.deepEqual(next.map(r=>r.length),rows.map(r=>r.length));const result={pass:true,clock,first:active,next,ended:Date.now(),reason:'real scheduled periods, clients closed, main owner restarted mid-period; private chat excluded; zero next period'};writeFileSync('evidence/digest-proof.json',JSON.stringify(result,null,2));appendFileSync('run-log.md',`${Math.floor(Date.now()/1000)} M8 digest real-clock proof green evidence=evidence/digest-proof.json\n`);console.log('DIGEST_PASS');process.exit(0);
