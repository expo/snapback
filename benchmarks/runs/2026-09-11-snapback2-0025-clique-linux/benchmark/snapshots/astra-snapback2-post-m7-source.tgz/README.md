# Clique

Cold build on public `snapback2@0.0.25`, with Quarry, Expo Router and the supplied UI kit. The lane's evidence, milestone coverage manifests, Hermes exports and run diary are retained locally.

Install with `npm ci`. Start the owner with `npx snapback2 dev --port 53200 --foreground`, then start Expo with `EXPO_PUBLIC_SNAPBACK_URL=http://127.0.0.1:53200 npx expo start --web --port 53201`. This lane reserves only 53200–53219. The app defaults to 53200 and rejects backend URLs outside the assigned loopback port range.

Run `npm run seed -- --segment m1`, then m2 and m3. These are the three supplied starter segments and are idempotent per installed segment. Seeding also installs the persisted digest clock when the M8 schema is present. Fixture sign-ins are in the supplied personas file. Run `npm run acceptance -- --milestone mN` for a suite and its exact coverage manifest, then `node scripts/choreo.mjs mN` for the copied frozen choreography. Choreography receives `CHOREO_BASE_URL` explicitly and writes JSONL receipts under `evidence/`.

The checked-in generated Quarry config currently uses the instrument's shortened edit/delete/disappearing and digest windows for reproducible checks. Production values remain in `config/windows.json` and `config/digest.json`. Run `node scripts/configure.mjs` and `node scripts/configure-digest.mjs` to generate production constants, then `npx snapback2 check`. To switch an already initialized digest clock, review and reset its private clock row through the operator before calling `digest.installSchedule`; this avoids silently changing an in-flight period. A fresh database's seed installs the correct next UTC anchor automatically.

For an existing pre-M8 instance, install the successor and run `insights.backfillAnalytics`, `digest.backfillUnread`, and `messages.labelOnce` as system jobs with `--wait`, while application writes are quiescent. These rebuild derived analytics, unread custody, and durable view-once labels. `digest.installSchedule` is an operator-only write to a private table; normal clients cannot change the clock. The scheduler emits digests without client reads and advances the persisted UTC-anchored deadline.

`API.md` describes the custom-client contract and `scripts/custom-client-demo.mjs` demonstrates it without generated local files. `scripts/replay.ts` validates and replays every supplied action verb through authenticated APIs; its separate scale clock and all settlement/invariant receipts are retained. `scale-instance-retry/` is the fresh verified replay target, distinct from the main development content. Do not replay over the main application when evaluating exact invariant counts.

Global message search pages all visible conversation memberships and issues bounded indexed searches with eight concurrent requests. More results follows each conversation's opaque continuation. Offline it asks the SDK twin for the same authorized queries over synced data. The low-level single-merge `messages.search` remains bounded to 100 conversation lanes; custom clients needing the complete scope should use the paged discovery pattern in `src/GlobalSearch.tsx`.

Each milestone has an iOS Hermes bundle under `artifacts/mN-ios`. Linux cannot produce Apple simulator execution proofs. `native-status.json` records M6/M8 as unavailable; the additional web restart proof is explicitly not a simulator substitute.

M7: `npm run acceptance -- --milestone m7` covers poll creation, set-state
votes, message counts and every previously green suite. Its coverage is written
to `evidence/coverage-m7.json`. M7 migration evidence and eight-persona API
snapshots are under `m7/`. Prepare a fresh poll with `node m7/prepare-choreo.mjs`, then run
`node m7/choreo.mjs`. This selects only M7 and supplies its adapter, suite
status and setup identity.

To upgrade an inherited pre-M7 database: first add `conversations.messageCount`
as optional (`int ?`) alongside the M7 message/poll changes, run
`npx snapback2 check`, and let `snapback2 dev` install that successor. While
application writes are quiescent, run
`npx snapback2 run polls.backfillCounts '{}' --as system --wait`.
Then change the column to required `int`, check, and install the final
successor. Never apply the final required-column schema directly to populated
pre-M7 rows. This lane records both successful successor reports. The existing
`liveMessageCounts` aggregate supplies the backfill; a job cannot write a
maintained aggregate, so the new field lives on each conversation.
