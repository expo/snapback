module.exports = ({ config }) => {
  const url = process.env.EXPO_PUBLIC_SNAPBACK_URL || 'http://127.0.0.1:53200';
  const parsed = new URL(url);
  if (parsed.hostname !== '127.0.0.1' || Number(parsed.port) < 53200 || Number(parsed.port) > 53219) throw new Error('This lane permits backend ports 53200–53219 on 127.0.0.1 only');
  return { ...config, name: 'Clique', slug: 'clique', plugins: [...(config.plugins || []), 'expo-router'], web: { bundler: 'metro' }, extra: { snapbackUrl: url } };
};
