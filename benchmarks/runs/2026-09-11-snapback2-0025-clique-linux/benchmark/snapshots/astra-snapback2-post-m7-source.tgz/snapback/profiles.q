query mine():
  return profiles[viewer]

query byHandle(handle: text <=20):
  return profiles[handle]

mutation createMyProfile(displayName: text <=50, handle: text <=20, avatarUrl: text <=2048 ?, bio: text <=200, location: text <=50, link: text <=2048 ?):
  require not exists profiles[handle] else HANDLE_TAKEN
  row = insert profiles { principal: viewer, displayName, handle, avatarUrl, bio, location, link }
  upsert profileSearch[viewer, 'name'] { owner: viewer, field: 'name', term: displayName, at: now }
  upsert profileSearch[viewer, 'handle'] { owner: viewer, field: 'handle', term: handle, at: now }
  return row

mutation updateMyProfile(displayName: text <=50, handle: text <=20, avatarUrl: text <=2048 ?, bio: text <=200, location: text <=50, link: text <=2048 ?):
  existing = profiles[viewer] ! else PROFILE_REQUIRED
  update profiles[existing] { displayName, handle, avatarUrl, bio, location, link }
  n = profileSearch[viewer, 'name']
  h = profileSearch[viewer, 'handle']
  upsert profileSearch[viewer, 'name'] { owner: viewer, field: 'name', term: displayName, at: n.at ?? now }
  upsert profileSearch[viewer, 'handle'] { owner: viewer, field: 'handle', term: handle, at: h.at ?? now }
  return profiles[existing.id] ! else PROFILE_REQUIRED

mutation setAvatar(avatar: image <=10000000):
  existing = profiles[viewer] ! else PROFILE_REQUIRED
  update profiles[existing] { avatar }
  return profiles[existing.id]

query social(handle: text <=20):
  p = profiles[handle] ! else PROFILE_REQUIRED
  return { followers: followerCounts[p.principal], following: followingCounts[p.principal], mine: exists follows[viewer, p.principal] by byFollowerFollowed }
query list(c: cursor ?):
  return profiles[] after c first 50 by byHandle

query search(term: text <=128, c: cursor ?):
  page = profileSearch[term] after c last 20 by byTerm
  return page { *, profile: profiles[.owner] }

job fillDirectory():
  chunk p in profiles first 25 by byId:
    if not exists profileSearch[p.principal, 'name']:
      insert profileSearch { owner: p.principal, field: 'name', term: p.displayName, at: now }
      insert profileSearch { owner: p.principal, field: 'handle', term: p.handle, at: now }
