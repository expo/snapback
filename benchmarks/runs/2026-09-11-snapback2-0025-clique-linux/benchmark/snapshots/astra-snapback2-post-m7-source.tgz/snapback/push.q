fn replayMode from runtime
effect notify from delivery
proc messagePush(conversationId: conversations, messageId: messages, preview: text <=80):
  if not replayMode():
    sender = profiles[viewer] ! else PROFILE_REQUIRED
    for member in memberships[conversationId] first 50 by byConversationPrincipal:
      if member.principal != viewer and not exists connected[member.principal]:
        insert pushLog { targetUserId: member.principal, senderId: viewer, chatId: conversationId, messageId, senderDisplayName: sender.displayName, preview, at: now }
        emit notify { targetUserId: member.principal, chatId: conversationId, senderDisplayName: sender.displayName, preview }

query forMessage(messageId: messages):
  return pushLog[messageId] first 50 by byMessage
