fn digestPeriodMs from digestConfig
fn digestAnchorMs from digestConfig
fn replayMode from runtime
mutation createPost(postId: id, body: text <=500, parent: posts ?, images: [image <=10000000] <=4 ?, clip: video <=50000000 ?):
  require exists profiles[viewer] else PROFILE_REQUIRED
  existing = posts[postId]
  if existing != null:
    return existing
  require images = null or clip = null else MIXED_MEDIA
  if clip != null:
    require clip.duration <= 60000 else VIDEO_TOO_LONG
  if images != null:
    require count(images) >= 1 else IMAGES_REQUIRED
  if parent != null:
    require exists posts[parent] else PARENT_REQUIRED
  (day, rem) = divmod(now, 86400000)
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  row = insert posts { day, period, digestEligible: not replayMode(), recipient: posts[parent].author, id: postId, author: viewer, body, parent, images, clip, at: now }
  if parent = null:
    if not replayMode():
      tally = postPeriodTotals[viewer, period]
      upsert postPeriodTotals[viewer, period] { owner: viewer, period, value: (tally.value ?? 0) + 1 }
    insert trending { postId: row.id, author: viewer, likes: 0, at: now, expiresAt: now + 86400000 }
    insert feedEntries { actor: viewer, postId: row.id, kind: 'original', at: now }
  return row

mutation setLike(postId: posts, active: bool, mutationId: id):
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, mutationId }
  post = posts[postId] ! else POST_REQUIRED
  (day, rem) = divmod(now, 86400000)
  if active:
    insert likes { actor: viewer, postId, recipient: post.author, day, at: now } if absent
  else:
    old = likes[viewer, postId]
    if old != null:
      delete likes[old]
  rank = trending[postId]
  if rank != null:
    update trending[rank] { likes: likeCounts[postId] }
  return null

mutation setRepost(postId: posts, active: bool, mutationId: id):
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, mutationId }
  require exists posts[postId] else POST_REQUIRED
  if active:
    return insert feedEntries { actor: viewer, postId, recipient: posts[postId].author, kind: 'repost', at: now } if absent
  old = feedEntries[viewer, postId, 'repost']
  if old != null:
    delete feedEntries[old]
  return null
