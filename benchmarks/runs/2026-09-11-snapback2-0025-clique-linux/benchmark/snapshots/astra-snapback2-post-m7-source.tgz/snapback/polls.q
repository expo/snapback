fn isMember from access
proc admitUnread from digest
proc messagePush from push
fn digestPeriodMs from digestConfig
fn digestAnchorMs from digestConfig
fn replayMode from runtime

mutation create(messageId: id, conversationId: conversations, question: text 1..200, options: [text 1..50] <=4):
  require isMember(conversationId, viewer) else NOT_MEMBER
  chat = conversations[conversationId] ! else CHAT_REQUIRED
  require chat.kind = 'group' else GROUP_REQUIRED
  require count(options) >= 2 else TWO_OPTIONS_REQUIRED
  old = messages[messageId]
  if old != null:
    return { id: old.id }
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  if chat.ttlMs != null:
    row = insert messages { id: messageId, conversationId, authorId: viewer, body: question, pollOptions: options, at: now, period, digestEligible: not replayMode(), expiresAt: now + chat.ttlMs }
    update conversations[chat] { latestMessage: row.id, messageCount: (chat.messageCount ?? 0) + 1 }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, slice(question, 0, 80))
    return { id: row.id }
  else:
    row = insert messages { id: messageId, conversationId, authorId: viewer, body: question, pollOptions: options, at: now, period, digestEligible: not replayMode() }
    update conversations[chat] { latestMessage: row.id, messageCount: (chat.messageCount ?? 0) + 1 }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, slice(question, 0, 80))
    return { id: row.id }

query view(messageId: messages):
  m = messages[messageId] ! else MESSAGE_REQUIRED
  require m.deleted != true else DELETED
  require m.pollOptions != null else POLL_REQUIRED
  return { message: m, votes: pollVotes[messageId] first 50 by byMessage }

mutation vote(messageId: messages, option: int, mutationId: id):
  if exists intents[viewer, mutationId]:
    return null
  m = messages[messageId] ! else MESSAGE_REQUIRED
  require isMember(m.conversationId, viewer) else NOT_MEMBER
  require m.deleted != true else DELETED
  options = m.pollOptions ! else POLL_REQUIRED
  require option >= 0 and option < count(options) else OPTION_REQUIRED
  insert intents { actor: viewer, mutationId }
  upsert pollVotes[messageId, viewer] { option }
  return null

job backfillCounts():
  chunk c in conversations first 25 by byId:
    update conversations[c] { messageCount: (liveMessageCounts[c.id, null] ?? 0) + (liveMessageCounts[c.id, false] ?? 0) }
