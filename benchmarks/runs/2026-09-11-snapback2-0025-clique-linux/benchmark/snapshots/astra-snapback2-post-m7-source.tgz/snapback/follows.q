proc clearFollow from digest
proc admitFollow from digest
fn digestPeriodMs from digestConfig
fn digestAnchorMs from digestConfig
fn replayMode from runtime
mutation setFollow(target: principal, following: bool, mutationId: id):
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, mutationId }
  require target != viewer else SELF_FOLLOW
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  if following:
    row = insert follows { period, digestEligible: not replayMode(), follower: viewer, followed: target, at: now } if absent
    present = follows[viewer, target] ! else FOLLOW_REQUIRED
    admitFollow(present.id, viewer, target, period)
    return null
  existing = follows[viewer, target]
  if existing != null:
    clearFollow(existing.id)
    delete follows[existing]
  return null
