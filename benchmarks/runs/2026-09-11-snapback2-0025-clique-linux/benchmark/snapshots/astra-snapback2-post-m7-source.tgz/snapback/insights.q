shape postCard from feeds
fn daySummary(person: principal, day: int): { day, posts: dayPosts[person, null, day], likes: dayLikes[person, day] }
query mine():
  (day, rem) = divmod(now, 86400000)
  return { posts: authoredCounts[viewer, null], likes: likesReceived[viewer], reposts: repostsReceived[viewer], replies: repliesReceived[viewer], followers: followerCounts[viewer], following: followingCounts[viewer], days: { d0: daySummary(viewer, day - 6), d1: daySummary(viewer, day - 5), d2: daySummary(viewer, day - 4), d3: daySummary(viewer, day - 3), d4: daySummary(viewer, day - 2), d5: daySummary(viewer, day - 1), d6: daySummary(viewer, day - 0) } }
query trending():
  return trending[] last 10 by byRank { *, post: posts[.postId], profile: profiles[.author], content: posts[.postId] postCard }
schedule expireTrending on trending at .expiresAt: delete .

job backfillAnalytics():
  chunk p in posts first 25 by byId:
    (day, rem) = divmod(p.at, 86400000)
    update posts[p] { day, recipient: posts[p.parent].author, digestEligible: p.digestEligible ?? false }
    if p.parent = null and now - p.at < 86400000 and not exists trending[p.id]:
      insert trending { postId: p.id, author: p.author, likes: likeCounts[p.id], at: p.at, expiresAt: p.at + 86400000 }
  chunk l in likes first 25 by byId:
    (day, rem) = divmod(l.at, 86400000)
    update likes[l] { recipient: posts[l.postId].author, day }
  chunk e in feedEntries first 50 by byId:
    if e.kind = 'repost':
      update feedEntries[e] { recipient: posts[e.postId].author }
