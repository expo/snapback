fn digestPeriodMs from digestConfig
fn digestAnchorMs from digestConfig
fn replayMode from runtime
effect notify from delivery

proc admitUnread(conversationId: conversations, period: time):
  for seat in memberships[conversationId] first 50 by byConversationPrincipal:
    if seat.principal != viewer:
      oldTotal = chatUnread[seat.principal, conversationId, seat.id]
      upsert chatUnread[seat.principal, conversationId, seat.id] { recipient: seat.principal, conversationId, membershipId: seat.id, unread: (oldTotal.unread ?? 0) + 1 }
  if not replayMode():
    for member in memberships[conversationId] first 50 by byConversationPrincipal:
      if member.principal != viewer:
        old = periodUnread[member.principal, conversationId, member.id, period]
        upsert periodUnread[member.principal, conversationId, member.id, period] { recipient: member.principal, conversationId, membershipId: member.id, period, unread: (old.unread ?? 0) + 1, active: 1 }

proc clearSeat(person: principal, conversationId: conversations, membershipId: memberships):
  total = chatUnread[person, conversationId, membershipId]
  if total != null:
    delete chatUnread[total]
  (number, remainder) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - remainder
  a = periodUnread[person, conversationId, membershipId, period]
  b = periodUnread[person, conversationId, membershipId, period - digestPeriodMs()]
  if a != null:
    delete periodUnread[a]
  if b != null:
    delete periodUnread[b]

proc releaseUnread(messageId: messages):
  m = messages[messageId] ! else MESSAGE_REQUIRED
  if m.deleted != true:
    for seat in memberships[m.conversationId] first 50 by byConversationPrincipal:
      if seat.principal != m.authorId and seat.joinedAt <= m.at:
        mark = readMarks[m.conversationId, seat.principal]
        if mark.readAt = null or (mark.readAt ! else READ_REQUIRED) < m.at:
          total = chatUnread[seat.principal, m.conversationId, seat.id]
          if total != null:
            update chatUnread[total] { unread: max(0, total.unread - 1) }
  if m.digestEligible = true and m.deleted != true and m.period != null:
    for member in memberships[m.conversationId] first 50 by byConversationPrincipal:
      if member.principal != m.authorId and member.joinedAt <= m.at:
        mark = readMarks[m.conversationId, member.principal]
        if mark.readAt = null or (mark.readAt ! else READ_REQUIRED) < m.at:
          counter = periodUnread[member.principal, m.conversationId, member.id, m.period]
          if counter != null:
            value = max(0, counter.unread - 1)
            if value = 0:
              delete periodUnread[counter]
            else:
              update periodUnread[counter] { unread: value }

query mine(c: cursor ?):
  return digestLog[viewer] after c last 50 by byPeriod

job sweep(cutoff: time):
  chunk old in postDigestContribution first 100 by byId:
    (number, remainder) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
    periodStart = cutoff - remainder - digestPeriodMs()
    if old.period < periodStart:
      delete postDigestContribution[old]
  chunk follow in follows first 25 by byId:
    if not replayMode():
      (number, remainder) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
      periodStart = cutoff - remainder - digestPeriodMs()
      upsert postDigestContribution[follow.id, periodStart] { follower: follow.follower, followed: follow.followed, followId: follow.id, period: periodStart, value: postPeriodTotals[follow.followed, periodStart].value ?? 0 }
  chunk p in profiles first 1 by byId:
    if not replayMode():
      (number, remainder) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
      periodEnd = cutoff - remainder
      periodStart = periodEnd - digestPeriodMs()
      if not exists digestRuns[p.principal, periodStart]:
        insert digestRuns { owner: p.principal, periodStart, periodEnd }
        newPosts = newPostsFollowing[p.principal, periodStart]
        newFollowers = periodFollowers[p.principal, periodStart, true]
        unreadMessages = digestUnreadMessages[p.principal, periodStart]
        unreadChats = digestUnreadChats[p.principal, periodStart]
        if newFollowers > 0 or newPosts > 0 or unreadMessages > 0 or unreadChats > 0:
          insert digestLog { targetUserId: p.principal, kind: 'digest', periodStart, periodEnd, newFollowers, newPostsInFollowing: newPosts, unreadMessages, unreadChats }
          emit notify { targetUserId: p.principal, kind: 'digest', periodStart, periodEnd, newFollowers, newPostsInFollowing: newPosts, unreadMessages, unreadChats }
  chunk row in periodUnread first 100 by byId:
    (number, remainder) = divmod(cutoff - digestAnchorMs(), digestPeriodMs())
    oldest = cutoff - remainder - digestPeriodMs()
    if row.period < oldest:
      delete periodUnread[row]

  chunk clock in digestClock first 1 by byId:
    (number, remainder) = divmod(now - digestAnchorMs(), digestPeriodMs())
    update digestClock[clock] { nextAt: max(cutoff + digestPeriodMs(), now - remainder + digestPeriodMs()), cutoff: max(cutoff + digestPeriodMs(), now - remainder + digestPeriodMs()) }

schedule digestAtAnchor on digestClock at .nextAt: sweep(.cutoff)

mutation installSchedule():
  if not exists digestClock['main'] by byName:
    (number, remainder) = divmod(now - digestAnchorMs(), digestPeriodMs())
    insert digestClock { name: 'main', nextAt: now - remainder + digestPeriodMs(), cutoff: now - remainder + digestPeriodMs() }
  return null

job backfillUnread():
  chunk old in chatUnread first 100 by byId:
    delete chatUnread[old]
  chunk message in messages first 10 by byId:
    if message.oncePhoto != null:
      update messages[message] { hasOnce: true }
    chat = conversations[message.conversationId] ! else CHAT_REQUIRED
    latest = messages[chat.latestMessage]
    if latest = null or message.at > (latest.at ! else TIME_REQUIRED):
      update conversations[chat] { latestMessage: message.id }
    if message.deleted != true:
      for seat in memberships[message.conversationId] first 50 by byConversationPrincipal:
        mark = readMarks[message.conversationId, seat.principal]
        if message.authorId != seat.principal and message.at >= seat.joinedAt and (mark.readAt = null or message.at > (mark.readAt ! else READ_REQUIRED)):
          old = chatUnread[seat.principal, message.conversationId, seat.id]
          upsert chatUnread[seat.principal, message.conversationId, seat.id] { recipient: seat.principal, conversationId: message.conversationId, membershipId: seat.id, unread: (old.unread ?? 0) + 1 }

proc clearFollow(followId: follows):
  for row in postDigestContribution[viewer, followId] first 3 by byFollow:
    delete postDigestContribution[row]

proc admitFollow(followId: follows, follower: principal, followed: principal, period: time):
  upsert postDigestContribution[followId, period - digestPeriodMs()] { follower, followed, followId, period: period - digestPeriodMs(), value: postPeriodTotals[followed, period - digestPeriodMs()].value ?? 0 }

query clock():
  (number, remainder) = divmod(now - digestAnchorMs(), digestPeriodMs())
  return { now, periodStart: now - remainder, periodEnd: now - remainder + digestPeriodMs() }
