import { seed } from "snapback2";
export default seed({ personas: ["alice", "bob", "carol"], rows: {} });
