fn replayMode(): runtimeConfig['main'].replayMode ?? false
mutation setReplayMode(enabled: bool):
  upsert runtimeConfig['main'] { name: 'main', replayMode: enabled }
  return null
