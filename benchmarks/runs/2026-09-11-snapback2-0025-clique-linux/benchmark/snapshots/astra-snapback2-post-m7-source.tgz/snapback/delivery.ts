import { effect } from 'snapback2';
import { recordNotified } from './notifications';
export const notify = effect({
  grants: [],
  run: async (payload: {targetUserId:string;chatId?:string;senderDisplayName?:string;preview?:string;kind?:string;periodStart?:number;periodEnd?:number;newFollowers?:number;newPostsInFollowing?:number;unreadMessages?:number;unreadChats?:number}, {meta}) => {
    console.log('Clique push seam', JSON.stringify({id:meta.id,...payload}));
    return {providerId:meta.id};
  },
  then: recordNotified,
});
