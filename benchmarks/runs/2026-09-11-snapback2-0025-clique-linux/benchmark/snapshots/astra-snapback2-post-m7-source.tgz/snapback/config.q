-- Generated from instrument/fixtures/config/windows.shortened.json; server time is always authoritative.
fn editMs(): 60000
fn deleteMs(): 120000
fn disappear24Ms(): 180000
fn disappear7Ms(): 300000
