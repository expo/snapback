shape postCard = { post: ., author: profiles[.author], likes: likeCounts[.id], replies: replyCounts[.id], reposts: repostCounts[.id, 'repost'], liked: exists likes[viewer, .id], reposted: exists feedEntries[viewer, .id, 'repost'] }
shape entryCard = { entry: ., content: posts[.postId] postCard, actor: profiles[.actor] }
query globalFeed(c: cursor ?):
  page = feedEntries[] after c last 20 by byTime
  return page entryCard
query followingFeed(c: cursor ?):
  page = merge feedEntries after c last 20 by byActorTime:
    [viewer]
    [f.followed] for f in follows[viewer] first 500 by byFollower
  return page entryCard
query thread(postId: posts, c: cursor ?):
  page = posts[postId] after c first 20 by byParent
  return { parent: posts[postId] postCard, items: page postCard }
query byAuthor(author: principal, c: cursor ?):
  page = posts[author, null] after c last 20 by byAuthorTime
  return page postCard
