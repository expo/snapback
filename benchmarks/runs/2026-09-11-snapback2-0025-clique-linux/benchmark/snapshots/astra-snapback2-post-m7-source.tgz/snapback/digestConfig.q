-- Generated from instrument/fixtures/config/digest.shortened.json
fn digestPeriodMs(): 120000
fn digestAnchorMs(): 0
