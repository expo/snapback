import React from 'react';import {ProfileEditor} from '../../src/Profile';export default function Edit(){return <ProfileEditor/>}
