export {Insights as default} from '../src/Insights';
