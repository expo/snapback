import React from 'react';
import { Slot } from 'expo-router';
import { SnapbackProvider } from 'snapback2/react';
import { backendUrl } from '../src/backend';
import { store, offline } from '../src/platform';
import {Connectivity} from '../src/Connectivity';
import { Auth } from '../src/Auth';
const url = backendUrl;
const tokenStore = store(url);
export default function Layout(){return <SnapbackProvider url={url} tokenStore={tokenStore} offline={offline}><Connectivity/><Auth><Slot /></Auth></SnapbackProvider>}
