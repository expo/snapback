# Clique custom-client API

Install exactly `npm install snapback2@0.0.25`. Node 24 runs the supplied plain-JavaScript demo. The public SDK's `api` proxy discovers the running server's operations; a custom JavaScript client needs no generated project files. Use `CLIQUE_BACKEND_URL=http://127.0.0.1:53200` for this instance.

Authentication uses the real password API:

```js
import {createClient, api} from 'snapback2/client';
const client = createClient({url:'http://127.0.0.1:53200'});
await client.ready;
const session = await client.auth.login({email, password});
// session.token is a bearer credential scoped to session.viewer.
// For an already-issued token: createClient({url, token}).
const identity = await client.auth.me();
```

`auth.signup({email,password})` issues an authenticated session too; new accounts then call `profiles.createMyProfile`. Do not publish or put a bearer token in a URL. Tokens belong to one user/session. The server enforces expiry and revocation; `auth.logout()` revokes the current session, including other clients using that same token. Independent logins on other devices remain separate sessions. The package does not document a numeric session TTL or expose an expiry instant in `AuthSession`; clients must handle `E_AUTH_SESSION` by signing in again. Local cached identity is not authority. This is a documentation limitation, not a promise of permanent tokens.

List conversations using `client.query(api.groups.mine,{c:null})`. Successful results contain `data` and an opaque `next` cursor. Each row has `conversationId` and `conversation` (`title`, `kind`, etc.). Repeat with `{c:result.next}` until `next` is null; do not synthesize cursors. For a named conversation, page this list until its title matches, then retain its ID. Membership controls access.

History is newest-first, ten rich rows per page:

```js
const page = await client.query(api.messages.conversationView, {
  conversationId, c: null
});
const latest = page.data.messages.find(row => row.message)?.message;
const older = page.next && await client.query(api.messages.conversationView, {
  conversationId, c: page.next
});
```

The page contains `messages`, `reads`, `count`, and `preview`. A message entry contains `message`, `author`, `quote`, `reactions`, and `receipts`. Nullable message joins must be handled. `groups.settings({conversationId})` supplies the current roster and each membership's `joinedAt`.

| Neutral message field | Native response / normalization |
| --- | --- |
| id | `message.id` |
| conversation id | `message.conversationId` |
| sender id | `message.authorId` |
| server timestamp | `message.at`, Unix milliseconds |
| type | tombstone if `deleted`; otherwise poll when `pollOptions` is present, or view-once/image/video/text from `hasOnce` or `oncePhoto`, then `photo`/`clip` |
| text or caption | `message.body` (nullable for tombstones/media) |
| media reference | first present `oncePhoto`, `photo`, `clip`; object with id/dimensions, video duration |
| edited flag | `Boolean(message.editedAt)` |
| tombstone flag | `Boolean(message.deleted)` |
| reply-to id | `message.quoteId`; `quote` contains a readable excerpt source |
| reactions | group entry `reactions` by `emoji`, count rows, set caller `mine` when `actor === identity.viewer` |
| own receipt | `sent`; `delivered` when all relevant entry `receipts.received`; `read` when all relevant recipients' page `reads.readAt >= message.at` |

Relevant receipt recipients exclude the sender and departed members, and require their current membership to have existed when the message was sent (`joinedAt <= at`). Other people's messages expose no caller-own receipt. The demo includes executable normalization into exactly these neutral fields. Regular `messages.history({conversationId,c})` is a lighter 50-row raw-message page, useful for polling and corpus checks.

Send a text message with a stable caller-generated ID:

```js
const messageId = crypto.randomUUID();
const result = await client.mutation(api.messages.send, {
  messageId, conversationId, body:'Hello', quoteId:null
});
if (result.state !== 'committed') throw Error(JSON.stringify(result));
```

Reuse the same message ID only for retries of that send. Server arrival time is authoritative. Edits use `messages.edit({messageId,body})`; media captions use `editCaption`; delete-for-everyone uses `unsend`. Windows come from the server config. `messages.markRead({conversationId,messageId})` advances the caller's watermark to an actually readable message.

The demo **receives by documented polling**: query `messages.history` with `c:null` every 250 ms while waiting for a new message, then deduplicate by message ID. Production clients can reduce polling frequency or use SDK live observations. Polling the head is sufficient for live low-volume updates; page back to the last known ID if more than 50 messages arrived. Re-read changed rows to observe edits and tombstones. Expired content disappears; do not keep it indefinitely after an authoritative resync.

Use `client.assetUrl(reference)` followed by the SDK asset consumer or `assetBlob` (web/Node) / `assetBytes` (native), never an unauthenticated permanent media URL. View-once is consumed by the first byte fetch per recipient: pass a stable `{viewing:{}}` instance, retain bytes only for that view, then destroy it. A subsequent viewing instance is refused. Do not durably cache once media.

Run the standalone demo with `CLIQUE_EMAIL`, `CLIQUE_PASSWORD` (or `CLIQUE_TOKEN`), optional `CLIQUE_CONVERSATION`, and `CLIQUE_BACKEND_URL`:

```sh
node scripts/custom-client-demo.mjs
```

It authenticates, pages conversations and two history pages where available, sends a text, and receives it by polling. A green JSON receipt lists each exercised operation. `client.close()` releases connections without revoking the session; logout is explicit.

M8 adds `insights.mine()` (six server totals and seven UTC day records), `insights.trending()` (ten ranked original post cards), and `messages.unread({conversationId})`. Insights uses an authenticated online read on load/refresh; do not present a partial local count as a complete total. `messages.markRead` accepts the latest committed message in the conversation; retry with a fresh head after `READ_MOVED`.

A view-once message keeps `hasOnce` in durable metadata even when the asset reference is omitted from a local snapshot. Fetch `messages.onceReference({messageId})` on open when needed, and use the SDK viewing API with a stable per-view token. Never persist the view-once bytes.

For complete global search, page `groups.mine`, then call `messages.searchChat` for each visible conversation and follow each opaque continuation. The app limits concurrency to eight and groups results by chat. The convenience `messages.search` merge has a documented 100-lane envelope; it is not the complete discovery API for larger accounts.

M7 adds group polls as ordinary messages with `pollOptions` (ordered strings).
Create one using `polls.create({messageId,conversationId,question,options})`:
question is 1–200 characters and there are 2–4 options of 1–50 characters.
`polls.view({messageId})` returns the message and up to 50 member vote rows.
Observe this query for live tallies; group the rows by zero-based `option`.
`polls.vote({messageId,option,mutationId})` sets the caller's single vote.
Generate a fresh mutation ID for each new intent and reuse it for retries.
Replaying an earlier mutation ID after a later vote does not revert the vote.
The SDK durable offline queue carries this operation like message reactions.
Poll questions/options are immutable after creation; delete-for-everyone and
expiry apply as for other messages. A tombstone takes precedence over poll type.

`groups.settings({conversationId}).data.conversation.messageCount` is the
persisted number of currently visible messages, including polls and excluding
tombstones and expired rows. The same field is present on conversation-list
rows. It is initialized on conversation creation and updated transactionally
by message creation, unsend, and scheduled expiry.
