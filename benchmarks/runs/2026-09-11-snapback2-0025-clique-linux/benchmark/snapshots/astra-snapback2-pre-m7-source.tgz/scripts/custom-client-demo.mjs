import {createClient,api} from 'snapback2/client';
import assert from 'node:assert/strict';
const url=process.env.CLIQUE_BACKEND_URL??'http://127.0.0.1:53200';
const client=createClient({url,...(process.env.CLIQUE_TOKEN?{token:process.env.CLIQUE_TOKEN}:{})});
await client.ready;
try{
 if(!process.env.CLIQUE_TOKEN)await client.auth.login({email:process.env.CLIQUE_EMAIL,password:process.env.CLIQUE_PASSWORD});
 const me=await client.auth.me();assert.ok(me.viewer);
 const conversations=[];let cursor=null;
 do{const q=await client.query(api.groups.mine,{c:cursor});assert.ok(q.data);conversations.push(...q.data);cursor=q.next??null}while(cursor);
 const id=process.env.CLIQUE_CONVERSATION??conversations[0]?.conversationId;assert.ok(id,'Account needs a conversation');
 const settings=(await client.query(api.groups.settings,{conversationId:id})).data;
 const history=[];cursor=null;let pages=0;
 do{const q=await client.query(api.messages.conversationView,{conversationId:id,c:cursor});assert.ok(q.data);pages++;for(const row of q.data.messages){if(row.message)history.push(normalize(row,q.data.reads,settings.members,me.viewer))}cursor=q.next??null}while(cursor&&pages<2);
 const messageId=crypto.randomUUID(),body='Custom client '+messageId;
 const sent=await client.mutation(api.messages.send,{messageId,conversationId:id,body,quoteId:null});assert.equal(sent.state,'committed');
 let received=false;for(let i=0;i<20;i++){const q=await client.query(api.messages.history,{conversationId:id,c:null});if(q.data?.some(m=>m.id===messageId&&m.body===body)){received=true;break}await new Promise(r=>setTimeout(r,250))}assert.ok(received);
 console.log(JSON.stringify({pass:true,operations:['authenticate','list-conversations','page-history','send-text','receive-by-polling'],conversations:conversations.length,historyPages:pages,historyMessages:history.length,fieldManifest:history[0]?Object.keys(history[0]):[],sentId:messageId}));
}finally{await client.close()}
process.exit();
function normalize(row,reads,members,viewer){const m=row.message,reactions=new Map();for(const r of row.reactions){const a=reactions.get(r.emoji)??{emoji:r.emoji,count:0,mine:false};a.count++;a.mine||=r.actor===viewer;reactions.set(r.emoji,a)}const recipients=row.receipts.filter(r=>r.recipient!==m.authorId&&members.some(x=>x.principal===r.recipient&&x.joinedAt<=m.at));let receipt=null;if(m.authorId===viewer){receipt='sent';if(recipients.every(r=>r.received))receipt='delivered';if(recipients.every(r=>(reads.find(x=>x.actor===r.recipient)?.readAt??0)>=m.at))receipt='read'}return {id:m.id,conversationId:m.conversationId,senderId:m.authorId,serverTimestamp:m.at,type:m.deleted?'tombstone':m.oncePhoto?'view-once':m.photo?'image':m.clip?'video':'text',text:m.body,media:m.oncePhoto??m.photo??m.clip??null,edited:!!m.editedAt,tombstone:!!m.deleted,replyToId:m.quoteId,reactions:[...reactions.values()],receipt}}
