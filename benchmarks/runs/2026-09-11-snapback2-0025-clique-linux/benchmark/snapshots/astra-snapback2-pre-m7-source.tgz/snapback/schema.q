use identity password

table profiles:
  principal: principal
  displayName: text 1..50
  handle: text 3..20 format handle
  avatarUrl: text <=2048 format url ?
  avatar: image <=10000000 ?
  bio: text <=200
  location: text <=50
  link: text <=2048 format url ?
  unique byPrincipal: principal
  unique byHandle: handle
  immutable principal
  public 'profiles are public'
  insert <- .principal = viewer
  update <- .principal = viewer
  delete <- deny

table conversations:
  title: text <=120
  description: text <=200 ?
  kind: enum('dm', 'group') ?
  pairLo: principal ?
  pairHi: principal ?
  creatorId: principal
  latestMessage: messages ?
  accent: text <=7 ?
  background: image <=10000000 ?
  disappearing: enum('off', '24h', '7d') ?
  ttlMs: int ?
  by byCreator: creatorId
  unique byIdCreator: id, creatorId
  by byPair: pairLo, pairHi, id
  read <- exists memberships[.id, viewer]
  insert <- .creatorId = viewer
  update <- exists memberships[.id, viewer]
  delete <- deny
  after insert <- exists memberships[.id, .creatorId, 'admin']

table memberships:
  conversationId: conversations
  principal: principal
  role: enum('member', 'admin')
  joinedAt: time
  unique byConversationPrincipal: conversationId, principal
  by byConversationPrincipalRole: conversationId, principal, role
  by byPrincipalConversation: principal, conversationId, id
  cap 50 by conversationId
  immutable conversationId, principal, joinedAt
  read <- exists memberships[.conversationId, viewer]
  insert <- (
    exists memberships[.conversationId, viewer, 'admin']
    or (
      .principal = viewer
      and .role = 'admin'
      and created conversations[.conversationId, viewer]
    )
  )
  update (old, next) <- (
    exists memberships[old.conversationId, viewer, 'admin']
    and old.role = 'member'
    and next.role = 'admin'
  )
  delete <- (
    .principal = viewer
    or exists memberships[.conversationId, viewer, 'admin']
  )

table messages:
  period: time ?
  digestEligible: bool ?
  conversationId: conversations
  authorId: principal
  body: text <=2000 ?
  quoteId: messages ?
  photo: image <=10000000 ?
  clip: video <=50000000 ?
  hasOnce: bool ?
  oncePhoto: image <=10000000 once ?
  expiresAt: time ?
  editedAt: time ?
  deleted: bool ?
  at: time
  by byConvTime: conversationId, at, id
  by bySearch: conversationId, wordPrefixes(body), at, id
  immutable conversationId, authorId
  deliver to memberships[.conversationId] as deliveries with receipts
  retain delivered-history
  read <- exists memberships[.conversationId, viewer]
  insert <- (
    .authorId = viewer
    and exists memberships[.conversationId, viewer]
  )
  update <- .authorId = viewer
  delete <- .authorId = viewer


table posts:
  day: int ?
  period: time ?
  digestEligible: bool ?
  recipient: principal ?
  author: principal
  body: text <=500
  parent: posts ?
  images: [image <=10000000] <=4 ?
  clip: video <=50000000 ?
  at: time
  by byTime: parent, at, id
  by byAuthorTime: author, parent, at, id
  by byParent: parent, at, id
  immutable author, at
  public 'posts are globally readable product content'
  insert <- .author = viewer
  update <- .author = viewer
  delete <- .author = viewer
  after insert <- exists profiles[.author]

table follows:
  period: time ?
  digestEligible: bool ?
  follower: principal
  followed: principal
  at: time
  unique byFollowerFollowed: follower, followed
  by byFollower: follower, followed
  by byFollowed: followed, follower
  immutable follower, followed, at
  public 'follows are public product-selection relationships'
  insert <- .follower = viewer
  update <- deny
  delete <- .follower = viewer

table notifications:
  outboxId: id
  effect: text <=100
  providerId: text <=200
  unique byOutbox: outboxId
  read <- deny
  insert <- deny
  update <- deny
  delete <- deny

maintain messageCounts: count messages by conversationId
  read <- exists memberships[.conversationId, viewer]

channel typing(conversationId: conversations):
  value: { typing: bool }
  publish <- exists memberships[conversationId, viewer]
  subscribe <- exists memberships[conversationId, viewer]
  ttl 2s

maintain memberCounts: count memberships by conversationId
  read <- exists memberships[.conversationId, viewer]

table feedEntries:
  recipient: principal ?
  actor: principal
  postId: posts
  kind: enum('original', 'repost')
  at: time
  unique byActorPostKind: actor, postId, kind
  by byTime: at, id
  by byActorTime: actor, at, id
  public 'feed projections'
  insert <- .actor = viewer
  update <- deny
  delete <- .actor = viewer

table likes:
  recipient: principal ?
  day: int ?
  actor: principal
  postId: posts
  at: time
  unique byActorPost: actor, postId
  by byPost: postId, actor
  public 'public engagement'
  insert <- .actor = viewer
  update <- deny
  delete <- .actor = viewer

maintain likeCounts: count likes by postId
  read <- public
maintain replyCounts: count posts by parent
  read <- public
maintain repostCounts: count feedEntries by postId, kind
  read <- public
maintain followerCounts: count follows by followed
  read <- public
maintain followingCounts: count follows by follower
  read <- public

table intents:
  actor: principal
  mutationId: id
  unique byActorMutation: actor, mutationId
  read <- .actor = viewer
  insert <- .actor = viewer
  update <- deny
  delete <- deny

table readMarks:
  conversationId: conversations
  actor: principal
  readAt: time
  unique byConversationActor: conversationId, actor
  read <- exists memberships[.conversationId, viewer]
  insert <- .actor = viewer and exists memberships[.conversationId, viewer]
  update <- .actor = viewer and exists memberships[.conversationId, viewer]
  delete <- deny

table dmPairs:
  lo: principal
  hi: principal
  conversationId: conversations
  unique byPair: lo, hi
  read <- .lo = viewer or .hi = viewer
  insert <- .lo = viewer or .hi = viewer
  update <- deny
  delete <- deny

table reactions:
  messageId: messages
  actor: principal
  emoji: text <=40
  unique byMessageActor: messageId, actor
  by byMessage: messageId, id
  cap 50 by messageId
  read <- exists messages[.messageId]
  insert <- .actor = viewer and exists messages[.messageId]
  update <- .actor = viewer and exists messages[.messageId]
  delete <- .actor = viewer and exists messages[.messageId]


table profileSearch:
  owner: principal
  field: enum('name', 'handle')
  term: text <=50
  at: time
  unique byOwnerField: owner, field
  by byTerm: wordPrefixes(term), at, id
  public 'registered people directory'
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer

table runtimeConfig:
  name: text <=20
  replayMode: bool
  unique byName: name
  public 'non-secret runtime mode'
  insert <- deny
  update <- deny
  delete <- deny

table pushLog:
  targetUserId: principal
  senderId: principal
  chatId: conversations
  messageId: messages
  senderDisplayName: text <=50
  preview: text <=80
  at: time
  by byMessage: messageId, id
  by byTarget: targetUserId, at, id
  read <- .targetUserId = viewer or .senderId = viewer
  insert <- .senderId = viewer
  update <- deny
  delete <- deny


maintain authoredCounts: count posts by author, parent
  read <- public
maintain likesReceived: count likes by recipient
  read <- public
maintain repostsReceived: count feedEntries by recipient
  read <- public
maintain repliesReceived: count posts by recipient
  read <- public
maintain dayPosts: count posts by author, parent, day
  read <- public
maintain dayLikes: count likes by recipient, day
  read <- public
maintain periodFollowers: count follows by followed, period, digestEligible
  read <- public

table trending:
  postId: posts
  author: principal
  likes: int
  at: time
  expiresAt: time ?
  unique byPost: postId
  by byRank: likes, at, id
  public 'public original post ranking'
  insert <- .author = viewer
  update <- allow
  delete <- allow

table periodUnread:
  recipient: principal
  conversationId: conversations
  membershipId: memberships
  period: time
  unread: int
  active: int
  unique bySeatPeriod: recipient, conversationId, membershipId, period
  read <- .recipient = viewer or exists memberships[.conversationId, viewer]
  insert <- exists memberships[.conversationId, viewer]
  update <- exists memberships[.conversationId, viewer]
  delete <- .recipient = viewer or exists memberships[.conversationId, viewer, 'admin']
maintain digestUnreadMessages: sum periodUnread of unread by recipient, period
  read <- .recipient = viewer
  readable <- allow
maintain digestUnreadChats: sum periodUnread of active by recipient, period
  read <- .recipient = viewer
  readable <- allow

table digestScratch:
  owner: principal
  posts: int
  unique byOwner: owner
  read <- deny
  insert <- deny
  update <- deny
  delete <- deny

table digestRuns:
  owner: principal
  periodStart: time
  periodEnd: time
  unique byPeriod: owner, periodStart
  read <- .owner = viewer
  insert <- deny
  update <- deny
  delete <- deny

table digestLog:
  targetUserId: principal
  kind: enum('digest')
  periodStart: time
  periodEnd: time
  newFollowers: int
  newPostsInFollowing: int
  unreadMessages: int
  unreadChats: int
  unique byPeriod: targetUserId, periodStart
  read <- .targetUserId = viewer
  insert <- deny
  update <- deny
  delete <- deny


table postPeriodTotals:
  owner: principal
  period: time
  value: int
  unique byOwnerPeriod: owner, period
  public 'original-post digest counts'
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- deny

table chatUnread:
  recipient: principal
  conversationId: conversations
  membershipId: memberships
  unread: int
  unique bySeat: recipient, conversationId, membershipId
  read <- .recipient = viewer or exists memberships[.conversationId, viewer]
  insert <- exists memberships[.conversationId, viewer]
  update <- exists memberships[.conversationId, viewer]
  delete <- .recipient = viewer or exists memberships[.conversationId, viewer, 'admin']
maintain liveMessageCounts: count messages by conversationId, deleted
  read <- exists memberships[.conversationId, viewer]
maintain authorMessageCounts: count messages by conversationId, authorId, deleted
  read <- exists memberships[.conversationId, viewer]


table postDigestContribution:
  follower: principal
  followed: principal
  followId: follows
  period: time
  value: int
  unique byFollowPeriod: followId, period
  by byFollow: follower, followId, id
  cap 3 by follower, followId
  read <- .follower = viewer
  insert <- .follower = viewer
  update <- .follower = viewer
  delete <- .follower = viewer
maintain newPostsFollowing: sum postDigestContribution of value by follower, period
  read <- .follower = viewer

table digestClock:
  name: text <=20
  nextAt: time ?
  cutoff: time
  unique byName: name
  read <- deny
  insert <- deny
  update <- deny
  delete <- deny
