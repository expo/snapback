proc clearSeat from digest
fn isAdmin from access

query mine(c: cursor ?):
  page = memberships[viewer] after c first 50 by byPrincipalConversation
  return page { conversationId, conversation: conversations[.conversationId] }

mutation groupCreate(conversationId: id, title: text 1..50, description: text <=200, members: [principal] <=49):
  require count(members) >= 1 else GROUP_REQUIRES_MEMBER
  existing = conversations[conversationId]
  if existing != null:
    return { id: existing.id, creatorMembershipId: (memberships[conversationId, viewer] ! else MEMBERSHIP_REQUIRED).id }
  creatorMembershipId = new
  joinedAt = now
  insert conversations { id: conversationId, title, description, kind: 'group', creatorId: viewer }
  insert memberships { id: creatorMembershipId, conversationId, principal: viewer, role: 'admin', joinedAt }
  for principal in members:
    require principal != viewer else CREATOR_ALREADY_ADMIN
    insert memberships { conversationId, principal, role: 'member', joinedAt }
  return { id: conversationId, creatorMembershipId }

mutation memberAdd(conversationId: conversations, principal: principal):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  existing = memberships[conversationId, principal]
  if existing != null:
    return { id: existing.id }
  require principal != viewer else ADMIN_SELF_RESEAT
  require memberCounts[conversationId] < 50 else GROUP_FULL
  row = insert memberships { conversationId, principal, role: 'member', joinedAt: now }
  return { id: row.id }

mutation memberPromote(conversationId: conversations, membershipId: memberships):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  membership = memberships[membershipId] ! else MEMBERSHIP_REQUIRED
  require membership.conversationId = conversationId else MEMBERSHIP_SCOPE_REQUIRED
  require membership.role = 'member' else MEMBER_REQUIRED
  update memberships[membership] { role: 'admin' }
  return null

mutation memberRemove(conversationId: conversations, membershipId: memberships):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  membership = memberships[membershipId] ! else MEMBERSHIP_REQUIRED
  require membership.conversationId = conversationId else MEMBERSHIP_SCOPE_REQUIRED
  require membership.principal != viewer else ADMIN_SELF_REMOVE
  clearSeat(membership.principal, conversationId, membership.id)
  delete memberships[membership]
  return null

mutation memberLeave(conversationId: conversations, membershipId: memberships):
  membership = memberships[conversationId, viewer] ! else MEMBERSHIP_REQUIRED
  require membership.id = membershipId else MEMBERSHIP_SELF_REQUIRED
  clearSeat(membership.principal, conversationId, membership.id)
  delete memberships[membership]
  return null

query settings(conversationId: conversations):
  c = conversations[conversationId] ! else MEMBERSHIP_REQUIRED
  return { conversation: c, me: memberships[conversationId, viewer], members: memberships[conversationId] first 50 by byConversationPrincipal { *, profile: profiles[.principal] } }

mutation dmCreate(conversationId: id, other: principal):
  require other != viewer else SELF_DM
  require exists profiles[other] else USER_REQUIRED
  (lo, hi) = sorted(viewer, other)
  prior = dmPairs[lo, hi]
  if prior != null:
    return { id: prior.conversationId }
  insert dmPairs { lo, hi, conversationId }
  insert conversations { id: conversationId, title: 'Direct message', kind: 'dm', pairLo: lo, pairHi: hi, creatorId: viewer }
  insert memberships { conversationId, principal: viewer, role: 'admin', joinedAt: now }
  insert memberships { conversationId, principal: other, role: 'member', joinedAt: now }
  return { id: conversationId }

mutation rename(conversationId: conversations, title: text 1..50, description: text <=200):
  require isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  chat = conversations[conversationId] ! else NOT_MEMBER
  require chat.kind = 'group' else GROUP_REQUIRED
  update conversations[chat] { title, description }
  return null

mutation color(conversationId: conversations, accent: text <=7):
  chat = conversations[conversationId] ! else NOT_MEMBER
  require accent = '#4F46E5' or accent = '#0D9488' or accent = '#EF6351' or accent = '#D97706' or accent = '#7C3AED' or accent = '#059669' or accent = '#E11D48' or accent = '#475569' else INVALID_COLOR
  update conversations[chat] { accent }
  return null

mutation background(conversationId: conversations, background: image <=10000000):
  chat = conversations[conversationId] ! else NOT_MEMBER
  update conversations[chat] { background }
  return null

fn disappear24Ms from config
fn disappear7Ms from config
mutation disappearing(conversationId: conversations, setting: enum('off', '24h', '7d')):
  chat = conversations[conversationId] ! else NOT_MEMBER
  require chat.kind = 'dm' or isAdmin(conversationId, viewer) else ADMIN_REQUIRED
  if setting = 'off':
    update conversations[chat] { disappearing: setting, ttlMs: null }
  else:
    if setting = '24h':
      update conversations[chat] { disappearing: setting, ttlMs: disappear24Ms() }
    else:
      update conversations[chat] { disappearing: setting, ttlMs: disappear7Ms() }
  return null
