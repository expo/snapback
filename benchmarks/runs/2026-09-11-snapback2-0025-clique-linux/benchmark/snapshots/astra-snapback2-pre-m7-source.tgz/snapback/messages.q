proc admitUnread from digest
proc clearSeat from digest
proc releaseUnread from digest
fn digestPeriodMs from digestConfig
fn digestAnchorMs from digestConfig
fn replayMode from runtime
proc messagePush from push
fn editMs from config
fn deleteMs from config
fn isMember from access
fn conversationMembers from access

query inbox(c: cursor ?):
  page = deliveries[viewer] after c first 50 by byRecipient
  return page { *, message: messages[.row] }

query thread(conversationId: conversations, c: cursor ?):
  require isMember(conversationId, viewer) else MEMBERSHIP_REQUIRED
  page = deliveries[viewer, conversationId, 'delivered'] after c last 50 by byRecipientGroup
  return page { *, message: messages[.row] }

query history(conversationId: conversations, c: cursor ?):
  require isMember(conversationId, viewer) else MEMBERSHIP_REQUIRED
  return messages[conversationId] after c last 50 by byConvTime

query receipts(messageId: messages):
  msg = messages[messageId] ! else NOT_FOUND
  require isMember(msg.conversationId, viewer) else MEMBERSHIP_REQUIRED
  return deliveriesReceipts[messageId] first 50 by byRow { recipient, received }

query conversationView(conversationId: conversations, c: cursor ?):
  require isMember(conversationId, viewer) else MEMBERSHIP_REQUIRED
  page = messages[conversationId] after c last 10 by byConvTime
  latest = messages[conversationId] last 1 by byConvTime
  return {
    messages: page { message: messages[.id], author: profiles[.authorId], quote: messages[.quoteId], reactions: reactions[.id] first 50 by byMessage, receipts: deliveriesReceipts[.id] first 50 by byRow { recipient, received } },
    reads: readMarks[conversationId] first 50 by byConversationActor,
    count: messageCounts[conversationId],
    preview: latest { message: messages[.id] },
  }

query search(term: text <=128, c: cursor ?):
  page = merge messages after c last 20 by bySearch:
    [m.conversationId, term] for m in memberships[viewer] first 100 by byPrincipalConversation
  return page

mutation send(messageId: id, conversationId: conversations, body: text <=2000, quoteId: messages ?):
  require isMember(conversationId, viewer) else NOT_MEMBER
  old = messages[messageId]
  if old != null:
    return { id: old.id }
  if quoteId != null:
    quoted = messages[quoteId] ! else QUOTE_REQUIRED
    require quoted.conversationId = conversationId else QUOTE_SCOPE
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  chat = conversations[conversationId] ! else NOT_MEMBER
  if chat.ttlMs != null:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body, quoteId, at: now, expiresAt: now + chat.ttlMs }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, slice(body, 0, 80))
    return { id: row.id }
  else:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body, quoteId, at: now }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, slice(body, 0, 80))
    return { id: row.id }

mutation sendPhoto(messageId: id, conversationId: conversations, photo: image <=10000000, caption: text <=500):
  require isMember(conversationId, viewer) else NOT_MEMBER
  old = messages[messageId]
  if old != null:
    return { id: old.id }
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  chat = conversations[conversationId] ! else NOT_MEMBER
  if chat.ttlMs != null:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body: caption, photo, at: now, expiresAt: now + chat.ttlMs }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, 'Photo')
    return { id: row.id }
  else:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body: caption, photo, at: now }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, 'Photo')
    return { id: row.id }

mutation sendClip(messageId: id, conversationId: conversations, clip: video <=50000000, caption: text <=500):
  require isMember(conversationId, viewer) else NOT_MEMBER
  require clip.duration <= 60000 else VIDEO_TOO_LONG
  old = messages[messageId]
  if old != null:
    return { id: old.id }
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  chat = conversations[conversationId] ! else NOT_MEMBER
  if chat.ttlMs != null:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body: caption, clip, at: now, expiresAt: now + chat.ttlMs }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, 'Video')
    return { id: row.id }
  else:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body: caption, clip, at: now }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, 'Video')
    return { id: row.id }

mutation sendOncePhoto(messageId: id, conversationId: conversations, photo: image <=10000000, caption: text <=500):
  require isMember(conversationId, viewer) else NOT_MEMBER
  old = messages[messageId]
  if old != null:
    return { id: old.id }
  (periodNumber, periodRem) = divmod(now - digestAnchorMs(), digestPeriodMs())
  period = now - periodRem
  chat = conversations[conversationId] ! else NOT_MEMBER
  if chat.ttlMs != null:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body: caption, hasOnce: true, oncePhoto: photo, at: now, expiresAt: now + chat.ttlMs }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, 'Photo')
    return { id: row.id }
  else:
    row = insert messages { period, digestEligible: not replayMode(), id: messageId, conversationId, authorId: viewer, body: caption, hasOnce: true, oncePhoto: photo, at: now }
    update conversations[chat] { latestMessage: row.id }
    admitUnread(conversationId, period)
    messagePush(conversationId, row.id, 'Photo')
    return { id: row.id }

mutation unsend(messageId: messages):
  msg = messages[messageId] ! else NOT_FOUND
  require msg.authorId = viewer else NOT_AUTHOR
  require now - msg.at <= deleteMs() else DELETE_WINDOW_EXPIRED
  releaseUnread(messageId)
  update messages[msg] { body: null, photo: null, clip: null, oncePhoto: null, deleted: true }
  return null

mutation edit(messageId: messages, body: text <=2000):
  msg = messages[messageId] ! else NOT_FOUND
  require msg.authorId = viewer else NOT_AUTHOR
  require msg.deleted != true else DELETED
  require now - msg.at <= editMs() else EDIT_WINDOW_EXPIRED
  require msg.photo = null and msg.clip = null and msg.oncePhoto = null else USE_CAPTION_EDIT
  update messages[msg] { body, editedAt: now }
  return null

mutation editCaption(messageId: messages, body: text <=500):
  msg = messages[messageId] ! else NOT_FOUND
  require msg.authorId = viewer else NOT_AUTHOR
  require msg.deleted != true else DELETED
  require now - msg.at <= editMs() else EDIT_WINDOW_EXPIRED
  update messages[msg] { body, editedAt: now }
  return null

mutation react(messageId: messages, emoji: text <=40, mutationId: id):
  if exists intents[viewer, mutationId]:
    return null
  insert intents { actor: viewer, mutationId }
  msg = messages[messageId] ! else MESSAGE_REQUIRED
  require msg.deleted != true else DELETED
  old = reactions[messageId, viewer]
  if emoji = 'none':
    if old != null:
      delete reactions[old]
  else:
    upsert reactions[messageId, viewer] { emoji }
  return null

schedule expireMessage on messages at .expiresAt: expire(.id)

query details(messageId: messages):
  m = messages[messageId] ! else MESSAGE_REQUIRED
  return { reactions: reactions[messageId] first 50 by byMessage, author: profiles[m.authorId], quote: messages[m.quoteId], receipts: deliveriesReceipts[messageId] first 50 by byRow { recipient, received, membership: memberships[m.conversationId, .recipient], read: readMarks[m.conversationId, .recipient] } }

mutation markRead(conversationId: conversations, messageId: messages):
  require isMember(conversationId, viewer) else MEMBERSHIP_REQUIRED
  message = messages[messageId] ! else MESSAGE_REQUIRED
  require message.conversationId = conversationId else MESSAGE_SCOPE
  chat = conversations[conversationId] ! else NOT_MEMBER
  require chat.latestMessage = null or chat.latestMessage = messageId else READ_MOVED
  seat = memberships[conversationId, viewer] ! else NOT_MEMBER
  clearSeat(viewer, conversationId, seat.id)
  previous = readMarks[conversationId, viewer]
  if previous != null:
    if previous.readAt >= message.at:
      return null
  upsert readMarks[conversationId, viewer] { readAt: message.at }
  return null

query searchChat(conversationId: conversations, term: text <=128, c: cursor ?):
  require isMember(conversationId, viewer) else NOT_MEMBER
  return messages[conversationId, term] after c last 20 by bySearch

mutation expire(messageId: messages):
  message = messages[messageId] ! else MESSAGE_REQUIRED
  chat = conversations[message.conversationId] ! else CHAT_REQUIRED
  if chat.latestMessage = messageId:
    update conversations[chat] { latestMessage: null }
  releaseUnread(messageId)
  delete messages[messageId]
  return null

query unread(conversationId: conversations):
  seat = memberships[conversationId, viewer] ! else NOT_MEMBER
  return { unread: chatUnread[viewer, conversationId, seat.id].unread ?? 0 }

query onceReference(messageId: messages):
  m = messages[messageId] ! else MESSAGE_REQUIRED
  require isMember(m.conversationId, viewer) else NOT_MEMBER
  return { oncePhoto: m.oncePhoto }

job labelOnce():
  chunk m in messages first 10 by byId:
    if m.oncePhoto != null:
      update messages[m] { hasOnce: true }
