table items:
  owner: principal
  bucket: int
  score: int
  label: text <=64
  tag: tags
  helper: principal ?
  read <- .owner = viewer or .helper = viewer
  insert <- .owner = viewer or .helper = viewer
  update <- .owner = viewer or .helper = viewer
  delete <- .owner = viewer or .helper = viewer
  online only

table tags:
  rank: int
  read <- allow
  insert <- allow
  update <- allow
  delete <- allow
  sync public

table kids:
  item: items on delete keep
  owner: principal
  read <- .owner = viewer
  insert <- allow
  update <- allow
  delete <- allow
  online only

table notes:
  kid: kids
  read <- allow
  insert <- allow
  delete <- allow
  online only

query run(key: id, bucket: int, c: cursor ?, n: int ?, a: int, b: int):
  return items where (.owner = viewer or .helper = viewer) and .bucket = bucket and .tag.rank = 1 last 1 by .label, .score after c
