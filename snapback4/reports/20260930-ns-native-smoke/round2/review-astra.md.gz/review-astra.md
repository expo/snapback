**NOT READY.** The round-0 fixes pass their regression controls, but I found a new port leak and incomplete protection of ownership records.

1. **P2 — Interrupted startup can leave the port occupied by an orphaned checker.**  
   [`serve.rs:269`](/home/ccheever/sb4-intent/review-ns-r1-astra/snapback4/crates/snapback4/src/serve.rs:269) starts the server-handler checker before [`witness_socket.rs:33`](/home/ccheever/sb4-intent/review-ns-r1-astra/snapback4/crates/snapback4/src/witness_socket.rs:33) restores `FD_CLOEXEC`. I reproduced this with a real Node process standing in for a stalled checker: interrupting the witness returned exit 1 / `E_WITNESS_INTERRUPTED`, but Node survived holding the inherited listener; port **54719 remained occupied after the witness exited**. A startup-timeout reproduction also leaked the port. Restore close-on-exec before any child can spawn.

2. **P2 — Ownership records are trusted without checking their filesystem ownership or permissions.**  
   [`simulator.rs:55`](/home/ccheever/sb4-intent/review-ns-r1-astra/snapback4/crates/snapback4/src/verbs/witness/simulator.rs:55) follows symlinks and accepts matching JSON without checking UID or writable permissions. I supplied symlinked and mode-`0666` records for a foreign device: both produced `selection: reused`, skipped creation, and targeted that device. Shared or externally writable state can therefore authorize an unrelated simulator. Require records and their containing directory to belong to the current user and exclude writes by other users.  
   The permission/symlink reproductions ran here; an actual second-UID execution was unavailable. Acceptance of a foreign-owned readable record follows from the unchecked read.

| Claim | Concrete result |
|---|---|
| **1. Recorded ownership required** | **Confirmed for missing records; qualified by finding 2.** Missing, truncated, mismatched and deleted-device records caused new creation without targeting the foreign device. Removing the record predicate made `prefix_without_creation_record_is_ignored` fail. |
| **2. Continuous port handoff** | **Confirmed during normal startup; failure cleanup is incomplete.** Both custody tests passed. Releasing the preparation reservation and disabling inherited-listener adoption independently made their tests fail. |
| **3. Identity recorded before boot** | **Confirmed.** Boot and bootstatus failures retained identity. An ownership-file persistence failure did too. Moving `remember` after boot made the regression fail with missing simulator identity. |
| **4. READMEs cite new timings** | **They cite round 0, not the stated round-1 cohort:** **221.7 / 83.5 / 186.2 s**, in [snapback4 README](/home/ccheever/sb4-intent/review-ns-r1-astra/snapback4/packages/snapback4/README.md:87) and [Expo README](/home/ccheever/sb4-intent/review-ns-r1-astra/snapback4/packages/snapback4-expo/README.md:90). The report explicitly explains this choice. Both README checks pass and fail against the previous README bytes. |
| **5. Numeric runtime and deliberate phone selection** | **Confirmed.** Tests selected iOS 26.5 over 18.0/9.3 and iPhone 17 over last-listed iPhone 11. Reverting each ordering rule made its control fail. |
| **6. Leased, wrapped `check`** | **Confirmed.** A held project lease prevented generation; missing schema returned one message, exit 1 and a receipt. Reversing lease order produced generated files; restoring the direct check produced exit 2. Both controls failed. |

Additional checks:

- Two concurrent runs selecting one simulator yielded one success and one lease refusal.
- A third-party listener appearing during the offline interval caused failure and remained untouched.
- Ordinary compilation/preparation failures released their reserved ports.
- All **320 retained files** matched their hashes. Receipts support **239.025 s cold, 86.251 s warm median, 202.091 s social**, with every smoke segment passing.

Validation: **40 driver/protocol checks passed; eight individual Rust reversions each failed their control.** The checked-in driver tests remain macOS-gated; Linux execution used scratch-only platform and plist adaptations. Native macOS execution was assessed from retained evidence.

Checkout unchanged at `2f2154e7ba`; nothing pushed.