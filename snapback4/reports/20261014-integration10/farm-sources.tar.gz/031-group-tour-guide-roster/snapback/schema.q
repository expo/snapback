-- Development cast: alice operates; bob and carol are freelance guides.
use personas alice, bob, carol

table operators:
  principal: principal
  name: text 1..80
  unique principal
  read <- .principal = viewer
  online only

table guides:
  principal: principal
  name: text 1..80
  unique principal
  read <- .principal = viewer or exists operators[viewer]
  online only

-- Skills are verified administrative data, never self-awarded by a guide.
table guideSkills:
  principal: principal
  language: enum('en', 'de', 'fr')
  certificate: enum('city', 'museum', 'adventure')
  unique principal, language, certificate
  read <- .principal = viewer or exists operators[viewer]
  online only

table tours:
  operator: principal
  title: text 3..120
  language: enum('en', 'de', 'fr')
  certificate: enum('city', 'museum', 'adventure')
  startsAt: time
  guests: int 1..40
  status: enum('open', 'assigned') default 'open'
  assignedGuide: principal ?
  immutable operator, language, certificate, startsAt
  read <- .operator = viewer or exists guideSkills[viewer, .language, .certificate]
  insert <- .operator = viewer and exists operators[viewer]
  update <- .operator = viewer and exists operators[viewer]
  online only

table bids:
  tour: tours
  guide: principal
  fee: int 20..2000
  note: text 0..300
  at: time default now
  unique tour, guide else ALREADY_BID
  immutable tour, guide, at
  read <- .guide = viewer or .tour.operator = viewer
  insert <- .guide = viewer and .tour.status = 'open' and exists guideSkills[viewer, .tour.language, .tour.certificate]
  online only

table reminders:
  tour: tours
  guide: principal
  at: time default now
  unique tour, guide
  read <- .guide = viewer or .tour.operator = viewer
  online only

query myProfile():
  return { operator: operators[viewer], guide: guides[viewer] }
query mySkills(c: cursor ?):
  return guideSkills where .principal = viewer first 50 by .id after c
query tourBoard(language: enum('en', 'de', 'fr'), certificate: enum('city', 'museum', 'adventure'), c: cursor ?):
  if exists operators[viewer]:
    return tours where .operator = viewer and .language = language and .certificate = certificate first 50 by .startsAt after c
  return tours where .language = language and .certificate = certificate first 50 by .startsAt after c
query tourBids(tour: tours, c: cursor ?):
  t = tours[tour] ! else NOT_FOUND
  return bids where .tour = tour first 50 by .at after c { id, tour, guide, fee, note, name: guides[.guide].name }
query myBids(c: cursor ?):
  return bids where .guide = viewer first 50 by .at after c
query myReminders(c: cursor ?):
  return reminders where .guide = viewer first 50 by .at after c { id, tour, at, title: tours[.tour].title, startsAt: tours[.tour].startsAt }

mutation publishTour(title: text 3..120, language: enum('en', 'de', 'fr'), certificate: enum('city', 'museum', 'adventure'), startsAt: time, guests: int 1..40):
  require exists operators[viewer] else OPERATOR_ONLY 'Only operators can publish tours.'
  require startsAt > now else START_IN_PAST 'Choose a future start time.'
  return insert tours { operator: viewer, title, language, certificate, startsAt, guests, assignedGuide: null }
mutation placeBid(tour: tours, fee: int 20..2000, note: text 0..300):
  t = tours[tour] ! else NOT_FOUND
  require exists guideSkills[viewer, t.language, t.certificate] else SKILL_REQUIRED
  require t.status = 'open' else TOUR_ASSIGNED
  require t.startsAt > now else TOUR_STARTED
  return insert bids { tour, guide: viewer, fee, note }
mutation assignGuide(bid: bids):
  b = bids[bid] ! else NOT_FOUND
  t = tours[b.tour] ! else NOT_FOUND
  require t.operator = viewer else OPERATOR_ONLY
  require t.status = 'open' else TOUR_ASSIGNED
  require t.startsAt > now else TOUR_STARTED
  require exists guideSkills[b.guide, t.language, t.certificate] else SKILL_REQUIRED
  update tours[t.id] { status: 'assigned', assignedGuide: b.guide }
  return tours[t.id]

-- Hourly sweep includes short-notice assignments; unique key makes reruns safe.
job remindGuides(periodStart: time, periodEnd: time):
  for t in tours where .startsAt >= periodEnd and .startsAt < periodEnd + 1d by .startsAt:
    if t.status = 'assigned' and t.assignedGuide != null:
      if exists guideSkills[t.assignedGuide, t.language, t.certificate]:
        if not exists reminders[t.id, t.assignedGuide]:
          insert reminders { tour: t.id, guide: t.assignedGuide }
schedule hourlyReminders every 1h: remindGuides
