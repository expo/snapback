-- Print Shop Proof Approvals.
-- Personas: alice = designer, bob = client, carol = production staff.
use personas alice, bob, carol

-- Roster for the privileged production role.
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- .principal = viewer
  cap 20
  online only

table jobs:
  designer: principal
  client: principal
  title: text 3..80
  createdAt: time default now
  immutable designer, client, title, createdAt
  cap 200 by designer
  cap 200 by client
  -- Designer and client see their own jobs; production staff see only approved ones.
  read <- .designer = viewer or .client = viewer or (exists staff[viewer] and exists approvals[.id])
  insert <- .designer = viewer
  online only

-- One row per approved job, written by the client's approveProof.
table approvals:
  job: jobs
  designer: principal
  approvedBy: principal
  at: time default now
  unique job
  immutable job, designer, approvedBy, at
  read <- .designer = viewer or .approvedBy = viewer or exists staff[viewer]
  insert <- .approvedBy = viewer and .job.client = viewer and not exists approvals[.job]
  online only

table proofs:
  job: jobs
  version: int 1..
  file: text 1..300
  status: enum('pending', 'approved', 'changes_requested', 'expired') default 'pending'
  uploadedBy: principal
  uploadedAt: time default now
  expiresAt: time
  immutable job, version, file, uploadedBy, uploadedAt, expiresAt
  unique job, version
  cap 200 by job
  read through .job
  insert <- .uploadedBy = viewer and .job.designer = viewer
  -- Only the client moves pending -> approved / changes_requested. Approved rows lock.
  update (old, next) <- old.status = 'pending' and next.status != 'pending' and next.status != 'expired' and old.job.client = viewer
  online only

table comments:
  proof: proofs
  author: principal
  body: text 1..500
  x: int 0..1000
  y: int 0..1000
  at: time default now
  immutable proof, author, x, y, at
  cap 1000 by proof
  read through .proof
  insert <- .author = viewer and (.proof.job.designer = viewer or .proof.job.client = viewer) and .proof.status != 'approved'
  delete <- .author = viewer
  online only

query myDesignJobs():
  return jobs where .designer = viewer

query myClientJobs():
  return jobs where .client = viewer

query approvedJobs(c: cursor ?):
  if exists staff[viewer]:
    return approvals first 50 by .id after c { id, title: .job.title, job }
  return approvals where .approvedBy = viewer or .designer = viewer first 50 by .id after c { id, title: .job.title, job }

query jobCard(job: jobs):
  return jobs[job]

query proofsFor(job: jobs):
  return proofs where .job = job

query commentsOn(proof: proofs):
  return comments where .proof = proof

mutation createJob(client: principal, title: text 3..80):
  require viewer != client else SELF_JOB 'Designer and client must differ.'
  return insert jobs { designer: viewer, client, title }

mutation uploadProof(job: jobs, file: text 1..300, version: int 1..):
  j = jobs[job] ! else NOT_FOUND
  require j.designer = viewer else NOT_DESIGNER 'Only the job designer uploads proofs.'
  require not exists approvals[job] else JOB_APPROVED 'Job is already approved.'
  return insert proofs { job, version, file, uploadedBy: viewer, uploadedAt: now, expiresAt: now + 14d, status: 'pending' }

mutation approveProof(proof: proofs):
  p = proofs[proof] ! else NOT_FOUND
  require p.job.client = viewer else NOT_CLIENT 'Only the client approves proofs.'
  require p.status = 'pending' else BAD_STATE 'Only a pending proof can be approved.'
  update proofs[proof] { status: 'approved' }
  d = p.job.designer
  require d != null else NOT_FOUND
  return insert approvals { job: p.job, designer: d, approvedBy: viewer, at: now }

mutation requestChanges(proof: proofs, body: text 1..500, x: int 0..1000, y: int 0..1000):
  p = proofs[proof] ! else NOT_FOUND
  require p.job.client = viewer else NOT_CLIENT 'Only the client requests changes.'
  require p.status = 'pending' else BAD_STATE 'Only a pending proof can be sent back.'
  update proofs[proof] { status: 'changes_requested' }
  return insert comments { proof, author: viewer, body, x, y, at: now }

mutation addComment(proof: proofs, body: text 1..500, x: int 0..1000, y: int 0..1000):
  p = proofs[proof] ! else NOT_FOUND
  require p.job.designer = viewer or p.job.client = viewer else NOT_PARTY 'Only the designer or client comments.'
  require p.status != 'approved' else PROOF_LOCKED 'Approved proofs are locked.'
  return insert comments { proof, author: viewer, body, x, y, at: now }

mutation deleteComment(id: comments):
  delete comments[id]

job expireProofs():
  for p in proofs:
    if p.status = 'pending' or p.status = 'changes_requested':
      if p.expiresAt < now:
        update proofs[p.id] { status: 'expired' }

schedule expireHourly every 1h: expireProofs
