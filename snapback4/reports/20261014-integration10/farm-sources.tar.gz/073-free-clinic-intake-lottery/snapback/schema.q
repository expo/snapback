-- Free Clinic Appointment Lottery.
-- Clinics open limited weekly appointment slots through a lottery.
-- Applicants enter under an anonymous codeName, so no personal details leak
-- to other applicants; staff run the draw, and winners confirm within a
-- window or forfeit to the waitlist.
use identity
use personas alice, bob, carol

-- Privileged role: carol is seeded as staff (fixtures/staff.jsonl).
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

-- One lottery round per clinic per week. The schedule itself is public.
table drawings:
  clinic: text 1..80
  weekLabel: text 1..20
  slots: int 1..50
  status: enum('open', 'drawn', 'closed') default 'open'
  confirmBy: time
  creator: principal
  unique clinic, weekLabel else ALREADY_OPEN 'This clinic already has a drawing for that week.'
  immutable creator
  public 'the lottery schedule is public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  online only

-- One entry per applicant per drawing. Only the applicant and staff can read
-- a row, so contact details never leak to other applicants; the codeName is
-- the anonymous handle winners are announced under.
table entries:
  drawing: drawings
  applicant: principal
  codeName: text 1..30
  contact: text 1..80
  status: enum('entered', 'winner', 'waitlist', 'confirmed', 'forfeited') default 'entered'
  unique drawing, applicant else ALREADY_ENTERED 'You already entered this drawing.'
  cap 200 by drawing
  immutable drawing, applicant
  read <- .applicant = viewer or exists staff[viewer]
  insert <- .applicant = viewer
  update <- .applicant = viewer or exists staff[viewer]
  delete <- .applicant = viewer
  online only

-- Public demand per drawing over private entries (booking-recipe pattern).
view entryCount: count entries by .drawing
  read <- allow

query board(c: cursor ?):
  return drawings first 50 by .id after c

query openDrawings(c: cursor ?):
  return drawings where .status = 'open' first 50 by .id after c

query myEntries(c: cursor ?):
  return entries where .applicant = viewer first 50 by .id after c

query drawingEntries(drawing: drawings, c: cursor ?):
  require exists staff[viewer] else NOT_STAFF
  return entries where .drawing = drawing first 100 by .id after c

query demand(drawing: drawings):
  return entryCount[drawing]

mutation openDrawing(clinic: text 1..80, weekLabel: text 1..20, slots: int 1..50, confirmBy: time):
  require exists staff[viewer] else NOT_STAFF
  require confirmBy > now else BAD_WINDOW 'The confirmation deadline must be in the future.'
  return insert drawings { clinic, weekLabel, slots, confirmBy, creator: viewer }

mutation enterLottery(drawing: drawings, codeName: text 1..30, contact: text 1..80):
  d = drawings[drawing] ! else NOT_FOUND
  require d.status = 'open' else DRAW_CLOSED 'This drawing is no longer open.'
  require not exists entries[drawing, viewer] else ALREADY_ENTERED 'You already entered this drawing.'
  return insert entries { drawing, applicant: viewer, codeName, contact }

mutation withdraw(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.applicant = viewer else NOT_YOURS 'You can only withdraw your own entry.'
  d = drawings[e.drawing] ! else NOT_FOUND
  require d.status = 'open' else DRAW_CLOSED 'This drawing is no longer open.'
  delete entries[entry]
  return null

-- Staff run the draw in two steps: flip the drawing open -> drawn, then record
-- each entry's result. (A single bulk sweep would need the complete-group
-- proof for loop writes; per-entry recording fits a small clinic and keeps
-- every decision auditable.)
mutation runDraw(drawing: drawings):
  d = drawings[drawing] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  require d.status = 'open' else ALREADY_DRAWN 'This drawing was already run.'
  update drawings[drawing] { status: 'drawn' }
  return null

mutation setResult(entry: entries, outcome: enum('winner', 'waitlist')):
  e = entries[entry] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  d = drawings[e.drawing] ! else NOT_FOUND
  require d.status = 'drawn' else NEED_DRAWN 'Run the draw before recording results.'
  require e.status = 'entered' else ALREADY_SET 'This entry already has a result.'
  update entries[entry] { status: outcome }
  return null

mutation confirmWin(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.applicant = viewer else NOT_YOURS 'You can only confirm your own win.'
  require e.status = 'winner' else NOT_WINNER 'This entry is not a winner.'
  d = drawings[e.drawing] ! else NOT_FOUND
  require d.status = 'drawn' else DRAW_CLOSED 'This drawing is closed.'
  require now <= d.confirmBy else CONFIRM_CLOSED 'The confirmation window passed; the slot goes to the waitlist.'
  update entries[entry] { status: 'confirmed' }
  return null

mutation forfeit(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  require e.status = 'winner' else NOT_WINNER 'Only a winner can forfeit.'
  update entries[entry] { status: 'forfeited' }
  return null

mutation promote(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  d = drawings[e.drawing] ! else NOT_FOUND
  require d.status = 'drawn' else NEED_DRAWN 'Run the draw before promoting the waitlist.'
  require e.status = 'waitlist' else NOT_WAITLIST 'Only a waitlisted entry can be promoted.'
  update entries[entry] { status: 'winner' }
  return null

mutation closeDrawing(drawing: drawings):
  d = drawings[drawing] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  require d.status = 'drawn' else NEED_DRAWN 'Only a drawn lottery can be closed.'
  update drawings[drawing] { status: 'closed' }
  return null
