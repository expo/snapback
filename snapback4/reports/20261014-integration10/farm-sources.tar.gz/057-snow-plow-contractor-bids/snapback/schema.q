-- Snow Plow Contractor Bids.
-- Personas: alice = property manager; bob, carol = contractors.
use personas alice, bob, carol

table managers:
  principal: principal
  unique principal
  read <- allow
  insert <- deny
  online only

table contracts:
  manager: principal
  title: text 3..80
  details: text <=500
  site: text 1..120
  season: text 1..40
  deadline: time
  status: enum('open', 'awarded', 'closed') default 'open'
  winner: principal ?
  immutable manager
  read <- allow
  insert <- .manager = viewer and exists managers[viewer]
  update <- .manager = viewer and exists managers[viewer]
  cap 100 by manager
  online only

table bids:
  contract: contracts on delete cascade
  contractor: principal
  amount: money USD
  daysToComplete: int 1..120
  note: text <=280 ?
  at: time default now
  unique contract, contractor
  immutable contract, contractor
  read <- .contractor = viewer or .contract.manager = viewer
  insert <- .contractor = viewer
  update <- .contractor = viewer
  cap 50 by contract
  online only

table proofs:
  contract: contracts on delete cascade
  contractor: principal
  stormAt: time
  notes: text <=280
  photo: image <=10000000 ?
  at: time default now
  immutable contract, contractor, stormAt
  read <- .contractor = viewer or .contract.manager = viewer
  insert <- .contractor = viewer
  cap 200 by contract
  online only

table invoices:
  contract: contracts on delete cascade
  contractor: principal
  amount: money USD
  status: enum('submitted', 'approved', 'rejected') default 'submitted'
  at: time default now
  immutable contract, contractor
  read <- .contractor = viewer or .contract.manager = viewer
  insert <- .contractor = viewer
  update <- .contract.manager = viewer
  cap 50 by contract
  online only

query openContracts(c: cursor ?):
  return contracts last 50 by .id after c

query contractDetail(contract: contracts):
  return contracts[contract]

query myBids(c: cursor ?):
  return bids where .contractor = viewer last 50 by .id after c

query bidsFor(contract: contracts, c: cursor ?):
  c0 = contracts[contract] ! else NOT_FOUND
  if now >= c0.deadline:
    return bids where .contract = contract first 50 by .id after c
  return bids where .contract = contract and .contractor = viewer first 50 by .id after c

query proofsFor(contract: contracts, c: cursor ?):
  return proofs where .contract = contract last 50 by .id after c

query invoicesFor(contract: contracts, c: cursor ?):
  return invoices where .contract = contract last 50 by .id after c

mutation postContract(title: text 3..80, details: text <=500, site: text 1..120, season: text 1..40, deadline: time):
  require exists managers[viewer] else NOT_MANAGER 'Only a property manager can post contracts.'
  require deadline > now else BAD_DEADLINE 'The deadline must be in the future.'
  return insert contracts { manager: viewer, title, details, site, season, deadline }

mutation submitBid(contract: contracts, amount: money USD, daysToComplete: int 1..120, note: text <=280 ?):
  c = contracts[contract] ! else NOT_FOUND
  require now < c.deadline else BIDDING_CLOSED 'Bidding has closed for this contract.'
  require c.status = 'open' else NOT_OPEN 'This contract is no longer open.'
  return insert bids { contract, contractor: viewer, amount, daysToComplete, note }

mutation reviseBid(bid: bids, amount: money USD, daysToComplete: int 1..120, note: text <=280 ?):
  b = bids[bid] ! else NOT_FOUND
  c = contracts[b.contract] ! else NOT_FOUND
  require now < c.deadline else BIDDING_CLOSED 'Bidding has closed for this contract.'
  update bids[bid] { amount, daysToComplete, note: note ?? b.note }
  return null

mutation awardBid(bid: bids):
  b = bids[bid] ! else NOT_FOUND
  c = contracts[b.contract] ! else NOT_FOUND
  require c.manager = viewer else NOT_MANAGER 'Only the contract manager can award.'
  require now >= c.deadline else TOO_EARLY 'Bids stay sealed until the deadline.'
  require c.status = 'open' else NOT_OPEN 'This contract is no longer open.'
  update contracts[b.contract] { status: 'awarded', winner: b.contractor }
  return null

mutation logProof(contract: contracts, stormAt: time, notes: text <=280, photo: image <=10000000 ?):
  c = contracts[contract] ! else NOT_FOUND
  require c.status = 'awarded' else NOT_AWARDED 'This contract has not been awarded yet.'
  require c.winner = viewer else NOT_WINNER 'Only the winning contractor logs service.'
  require stormAt <= now else BAD_STORM 'The storm date cannot be in the future.'
  return insert proofs { contract, contractor: viewer, stormAt, notes, photo }

mutation submitInvoice(contract: contracts, amount: money USD):
  c = contracts[contract] ! else NOT_FOUND
  require c.status = 'awarded' else NOT_AWARDED 'This contract has not been awarded yet.'
  require c.winner = viewer else NOT_WINNER 'Only the winning contractor can invoice.'
  return insert invoices { contract, contractor: viewer, amount }

mutation decideInvoice(invoice: invoices, approve: bool):
  v = invoices[invoice] ! else NOT_FOUND
  c = contracts[v.contract] ! else NOT_FOUND
  require c.manager = viewer else NOT_MANAGER 'Only the contract manager decides invoices.'
  update invoices[invoice] { status: 'approved' if approve else 'rejected' }
  return null

mutation closeContract(contract: contracts):
  c = contracts[contract] ! else NOT_FOUND
  require c.manager = viewer else NOT_MANAGER 'Only the contract manager can close.'
  update contracts[contract] { status: 'closed' }
  return null
