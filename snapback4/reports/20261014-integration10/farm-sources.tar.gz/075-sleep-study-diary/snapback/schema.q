use personas alice, bob, researcher, coordinator

table staff:
  principal: principal
  role: enum('researcher', 'coordinator')
  unique principal
  read <- .principal = viewer
  online only

table enrolments:
  principal: principal
  subject: subjects
  unique principal
  unique subject, principal
  immutable principal, subject
  read <- .principal = viewer or exists staff[viewer, role = 'coordinator']
  online only

table subjects:
  code: text 5..20
  startDay: int
  approved: bool default false
  completed: count diaries by subject
  unique code
  cap 20
  immutable code, startDay
  read <- exists enrolments[.id, viewer] or exists staff[viewer]
  update <- exists staff[viewer, role = 'coordinator']
  online only

table diaries:
  subject: subjects
  studyDay: int 1..4
  sleepMinutes: int 0..960
  awakenings: int 0..30
  quality: int 1..5
  at: time
  unique subject, studyDay
  immutable subject, studyDay
  read <- exists enrolments[.subject, viewer] or exists staff[viewer]
  insert <- exists enrolments[.subject, viewer]
  update <- exists enrolments[.subject, viewer]
  cap 4 by subject
  cap 80
  online only

table exports:
  subject: subjects
  wearable: file <=2000000 ('text/csv', 'application/json')
  at: time
  immutable subject, at
  read <- exists enrolments[.subject, viewer] or exists staff[viewer]
  insert <- exists enrolments[.subject, viewer]
  cap 20 by subject
  online only

table reminders:
  subject: subjects
  principal: principal
  studyDay: int 1..4
  message: text 1..160
  at: time
  unique subject, studyDay
  cap 4 by subject
  immutable subject, principal, studyDay, at
  read <- .principal = viewer
  online only

query myEnrollment():
  return enrolments[principal = viewer]
query myStatus():
  e = enrolments[principal = viewer] ! else NOT_PARTICIPANT
  s = subjects[e.subject] ! else NOT_FOUND
  return { code: s.code, approved: s.approved, completed: s.completed, target: 4, threshold: 3 }
query myDiaries():
  e = enrolments[principal = viewer] ! else NOT_PARTICIPANT
  return diaries where .subject = e.subject first 4 by .studyDay
query myExports():
  e = enrolments[principal = viewer] ! else NOT_PARTICIPANT
  return exports where .subject = e.subject last 20 by .at
query myReminders():
  return reminders where .principal = viewer last 4 by .at
query researchDiaries():
  require exists staff[viewer] else NOT_STAFF
  return diaries first 80 by .id { id, subject, studyDay, sleepMinutes, awakenings, quality }
query researchExports(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF
  return exports last 100 by .at after c
query paymentQueue():
  require exists staff[viewer, role = 'coordinator'] else NOT_COORDINATOR
  return subjects first 20 by .id { id, code, approved, completed }

mutation saveDiary(studyDay: int 1..4, sleepMinutes: int 0..960, awakenings: int 0..30, quality: int 1..5):
  e = enrolments[principal = viewer] ! else NOT_PARTICIPANT
  return upsert diaries[e.subject, studyDay] { subject: e.subject, studyDay, sleepMinutes, awakenings, quality, at: now }
mutation attachExport(wearable: file <=2000000 ('text/csv', 'application/json')):
  e = enrolments[principal = viewer] ! else NOT_PARTICIPANT
  return insert exports { subject: e.subject, wearable, at: now }
mutation approvePayment(subject: subjects):
  require exists staff[viewer, role = 'coordinator'] else NOT_COORDINATOR
  s = subjects[subject] ! else NOT_FOUND
  require s.completed >= 3 else INCOMPLETE 'Complete at least three diary days before payment approval.'
  update subjects[s.id] { approved: true }
  return { ok: true }

job nudgeMissing(periodStart: time, periodEnd: time):
  for e in enrolments:
    s = subjects[e.subject]
    if s != null:
      d = day(periodEnd) - s.startDay + 1
      if d >= 1 and d <= 4:
        if not exists diaries[e.subject, d] and not exists reminders[e.subject, d]:
          insert reminders { subject: e.subject, principal: e.principal, studyDay: d, message: 'Your daily sleep diary is missing. Please submit it in the portal.', at: now }
schedule dailyNudge every 1d at 09:00: nudgeMissing
