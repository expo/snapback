use personas alice, bob, ranger

table rangers:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table zones:
  name: text 2..60
  guidance: text 1..300
  unique name
  public 'Forest zones and gathering guidance are public.'
  insert <- exists rangers[viewer]
  online only

table weeks:
  zone: zones
  weekStart: time
  bookingOpen: time
  bookingClose: time
  capacity: int 1..50
  photoQuota: int 1..5
  publisher: principal
  unique zone, weekStart else WEEK_EXISTS
  public 'Weekly availability is public; holder identities are private.'
  insert <- exists rangers[viewer] and .publisher = viewer
  online only

table permits:
  week: weeks
  holder: principal
  claimedAt: time default now
  unique week, holder else ALREADY_CLAIMED
  cap 50 by week
  immutable week, holder
  read <- .holder = viewer or exists rangers[viewer]
  insert <- .holder = viewer
  online only

table photos:
  permit: permits
  owner: principal
  photo: image <=5000000
  note: text 1..200
  at: time default now
  immutable permit, owner
  read <- .owner = viewer or exists rangers[viewer]
  insert <- .owner = viewer and .permit.holder = viewer
  cap 5 by permit
  online only

view occupancy: count permits by .week
  read <- allow

view photoCount: count photos by .permit
  read <- exists permits[.permit, holder = viewer] or exists rangers[viewer]

query isRanger():
  return exists rangers[viewer]

query forestZones(c: cursor ?):
  return zones first 50 by .name after c

query availability(c: cursor ?):
  return weeks last 20 by .weekStart after c { id, zone: zones[.zone], weekStart, bookingOpen, bookingClose, capacity, photoQuota, taken: occupancy[.id] }

query holders(c: cursor ?):
  if exists rangers[viewer]:
    return permits last 20 by .claimedAt after c { id, holder, claimedAt, week: weeks[.week], zone: zones[.week.zone], uploaded: photoCount[.id] }
  return permits where .holder = viewer last 20 by .claimedAt after c { id, holder, claimedAt, week: weeks[.week], zone: zones[.week.zone], uploaded: photoCount[.id] }

query harvest(permit: permits):
  p = permits[permit] ! else NOT_FOUND
  return photos where .permit = permit last 5 by .at

mutation createZone(name: text 2..60, guidance: text 1..300):
  require exists rangers[viewer] else NOT_RANGER 'Only rangers can publish forest zones.'
  return insert zones { name, guidance }

mutation publishWeek(zone: zones, weekStart: time, bookingOpen: time, bookingClose: time, capacity: int 1..50, photoQuota: int 1..5):
  require exists rangers[viewer] else NOT_RANGER 'Only rangers can publish weekly permits.'
  z = zones[zone] ! else NOT_FOUND
  require bookingOpen < bookingClose and bookingClose <= weekStart else BAD_WINDOW 'Booking must open before it closes, and close by the foraging week.'
  require weekStart % 7d = 4d else BAD_WEEK 'Choose a Monday at midnight UTC.'
  return insert weeks { zone, weekStart, bookingOpen, bookingClose, capacity, photoQuota, publisher: viewer }

mutation claim(week: weeks):
  w = weeks[week] ! else NOT_FOUND
  require now >= w.bookingOpen else NOT_OPEN 'Booking has not opened yet.'
  require now < w.bookingClose else WINDOW_CLOSED 'Booking has closed.'
  require not exists permits[week, viewer] else ALREADY_CLAIMED 'You already hold this weekly permit.'
  require occupancy[week] < w.capacity else FULL 'All permits for this zone and week have been claimed.'
  return insert permits { week, holder: viewer }

mutation recordPhoto(permit: permits, photo: image <=5000000, note: text 1..200):
  p = permits[permit] ! else NOT_FOUND
  require p.holder = viewer else NOT_HOLDER 'Only the holder can attach harvest photos.'
  w = weeks[p.week] ! else NOT_FOUND
  require (photoCount[permit] ?? 0) < w.photoQuota else PHOTO_QUOTA 'This permit has reached its harvest photo quota.'
  return insert photos { permit, owner: viewer, photo, note }
