use personas alice, bob, visitor

table scientists:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table windows:
  pool: text 1..80
  assigned: principal
  startsAt: time
  endsAt: time
  immutable pool, assigned, startsAt, endsAt
  read <- .assigned = viewer or exists scientists[viewer]
  insert <- exists scientists[viewer]
  online only

table observations:
  window: windows
  owner: principal
  species: enum('limpet', 'anemone', 'shore_crab')
  count: int 0..1000
  photo: image <=5000000 ?
  notes: text <=500
  at: time default now
  immutable window, owner, species, count, photo, notes, at
  read <- .owner = viewer or exists scientists[viewer]
  insert <- .owner = viewer and .window.assigned = viewer
  online only

view monthlyIndividuals: sum observations of .count by month(.at), .species
  public 'Only monthly species totals are released publicly.'
view monthlySamples: count observations by month(.at), .species
  public 'Only monthly sample totals are released publicly.'

query assignedWindows():
  if exists scientists[viewer]:
    return windows last 100 by .startsAt
  return windows where .assigned = viewer last 100 by .startsAt
query myObservations():
  return observations where .owner = viewer last 100 by .at
query rawObservations():
  require exists scientists[viewer] else SCIENTIST_ONLY 'Raw survey data is restricted to scientists.'
  return observations last 100 by .at
query monthlySummary(monthNumber: int 0..2400):
  return { monthNumber, limpets: monthlyIndividuals[monthNumber, 'limpet'], anemones: monthlyIndividuals[monthNumber, 'anemone'], shoreCrabs: monthlyIndividuals[monthNumber, 'shore_crab'], limpetSamples: monthlySamples[monthNumber, 'limpet'], anemoneSamples: monthlySamples[monthNumber, 'anemone'], shoreCrabSamples: monthlySamples[monthNumber, 'shore_crab'] }

mutation scheduleWindow(pool: text 1..80, assigned: principal, startsAt: time, endsAt: time):
  require exists scientists[viewer] else SCIENTIST_ONLY 'Only scientists assign survey windows.'
  require endsAt > startsAt and endsAt <= startsAt + 6h else BAD_WINDOW 'A low-tide window must last between 1 ms and 6 hours.'
  require assigned = 'dev:alice' else UNKNOWN_VOLUNTEER 'Choose a registered volunteer.'
  return insert windows { pool, assigned, startsAt, endsAt }
mutation recordCount(window: windows, species: enum('limpet', 'anemone', 'shore_crab'), count: int 0..1000, photo: image <=5000000 ?, notes: text <=500):
  w = windows[window] ! else NOT_FOUND
  require w.assigned = viewer else NOT_ASSIGNED 'This tide pool is assigned to another volunteer.'
  require now >= w.startsAt and now < w.endsAt else OUTSIDE_WINDOW 'Counts are accepted only during the assigned low-tide window.'
  return insert observations { window, owner: viewer, species, count, photo, notes }
