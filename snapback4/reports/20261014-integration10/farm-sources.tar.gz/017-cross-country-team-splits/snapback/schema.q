use personas alice, bob, pat, sam

table coaches:
  principal: principal
  unique principal
  read <- .principal = viewer
  cap 10
  online only

table meets:
  title: text 1..80
  published: bool default false
  public 'Meet title and release status are visible to families.'
  update <- exists coaches[viewer]
  cap 10
  online only

table runners:
  meet: meets
  name: text 1..60
  bib: int 1..9999
  parent: principal
  unique meet, bib else BIB_TAKEN
  immutable meet, parent, bib
  read <- exists coaches[viewer] or .parent = viewer
  insert <- exists coaches[viewer]
  cap 200 by meet
  online only

table splits:
  meet: meets
  runner: runners
  parent: principal
  checkpoint: int 1..3
  elapsed: int 1..14400
  recorder: principal
  at: time default now
  unique runner, checkpoint
  immutable meet, runner, parent, checkpoint
  read <- exists coaches[viewer] or (.parent = viewer and exists meets[.meet, published = true])
  insert <- exists coaches[viewer] and .recorder = viewer and .runner.meet = .meet and .runner.parent = .parent
  update <- exists coaches[viewer] and .recorder = viewer
  cap 3 by runner
  online only

query meetStatus(meet: meets):
  m = meets[meet] ! else NOT_FOUND
  return { meet: m, isCoach: exists coaches[viewer] }

query roster(meet: meets, c: cursor ?):
  if exists coaches[viewer]:
    return runners where .meet = meet first 200 by .bib after c
  return runners where .meet = meet and .parent = viewer first 200 by .bib after c

query leaderboard(meet: meets, checkpoint: int 1..3, c: cursor ?):
  require exists coaches[viewer] else COACH_ONLY 'Only coaches can view the team leaderboard.'
  return splits where .meet = meet and .checkpoint = checkpoint first 200 by .elapsed after c { id, runner, elapsed, recorder, name: runners[.runner].name, bib: runners[.runner].bib }

query childSplits(runner: runners, c: cursor ?):
  r = runners[runner] ! else NOT_FOUND
  if exists coaches[viewer]:
    return splits where .runner = runner first 3 by .checkpoint after c
  require exists meets[r.meet, published = true] else RESULTS_EMBARGOED 'Results will be available when the coach releases them.'
  return splits where .runner = runner and .parent = viewer and .meet = r.meet first 3 by .checkpoint after c

mutation addRunner(meet: meets, name: text 1..60, bib: int 1..9999, parent: principal):
  require exists coaches[viewer] else COACH_ONLY
  m = meets[meet] ! else NOT_FOUND
  require not m.published else RESULTS_RELEASED 'Embargo results before changing the roster.'
  return insert runners { meet, name, bib, parent }

mutation recordSplit(runner: runners, checkpoint: int 1..3, elapsed: int 1..14400):
  require exists coaches[viewer] else COACH_ONLY
  r = runners[runner] ! else NOT_FOUND
  m = meets[r.meet] ! else NOT_FOUND
  require not m.published else RESULTS_RELEASED 'Embargo results before correcting splits.'
  if checkpoint > 1:
    prev = splits[runner, checkpoint - 1]
    require prev != null else PREVIOUS_SPLIT_REQUIRED 'Record the previous checkpoint first.'
    require elapsed > prev.elapsed else SPLIT_ORDER 'Elapsed time must increase at each checkpoint.'
  if checkpoint < 3:
    nextSplit = splits[runner, checkpoint + 1]
    require nextSplit = null or elapsed < nextSplit.elapsed else SPLIT_ORDER
  return upsert splits[runner, checkpoint] { meet: r.meet, runner, parent: r.parent, checkpoint, elapsed, recorder: viewer, at: now }

mutation setPublication(meet: meets, published: bool):
  require exists coaches[viewer] else COACH_ONLY
  if published:
    n = count(runners where .meet = meet)
    finishers = count(splits where .meet = meet and .checkpoint = 3)
    require n > 0 and finishers = n else FINISHERS_MISSING 'Every registered runner must have a finish split before release.'
  update meets[meet] { published }
  return null
