-- Mooring Field Waitlist.
-- Boaters (alice, bob) join one ranked waitlist; the harbormaster (harry)
-- offers mooring slots with a response deadline. A job lapses expired
-- offers and returns the entry to waiting. Boat details are readable only
-- by the entry's owner and the harbormaster; queue order is public.

use personas alice, bob, harry

-- Roster: one row per harbormaster. Rows are seeded as the system
-- (fixtures, POST /seed); no one may insert through the API.
table harbormasters:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table entries:
  boater: principal
  joinedAt: time default now
  status: enum('waiting', 'offered', 'accepted', 'declined', 'lapsed', 'withdrawn') default 'waiting'
  unique boater
  immutable boater, joinedAt
  by byJoined: joinedAt, id
  public 'queue order is public'
  insert <- .boater = viewer
  update <- .boater = viewer or exists harbormasters[viewer]
  delete <- .boater = viewer or exists harbormasters[viewer]
  sync

-- Boat details: visible only to the owner and the harbormaster.
table boats:
  entry: entries on delete cascade
  owner: principal
  boatName: text 1..40
  lengthFt: int 10..120
  details: text <=200 ?
  unique entry
  immutable entry, owner
  read <- .owner = viewer or exists harbormasters[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer or exists harbormasters[viewer]
  online only

table offers:
  entry: entries on delete keep
  boater: principal
  offeredAt: time default now
  deadline: time
  state: enum('pending', 'accepted', 'declined', 'lapsed') default 'pending'
  immutable entry, boater, offeredAt, deadline
  by byDeadline: deadline, id
  read <- .boater = viewer or exists harbormasters[viewer]
  insert <- exists harbormasters[viewer]
  update <- .boater = viewer or exists harbormasters[viewer]
  delete <- deny
  online only

-- Ranked waitlist, oldest first. Public.
query waitlist(c: cursor ?):
  return entries first 50 by .joinedAt after c

query myEntry():
  return entries where .boater = viewer

-- The viewer's roster rows: non-empty exactly for the harbormaster.
query myRole():
  return harbormasters where .principal = viewer

query myOffers(c: cursor ?):
  return offers where .boater = viewer last 20 by .offeredAt after c

-- Harbormaster sees every pending offer; a boater sees only their own.
query pendingOffers(c: cursor ?):
  if exists harbormasters[viewer]:
    return offers where .state = 'pending' first 20 by .deadline after c
  return offers where .boater = viewer and .state = 'pending' first 20 by .deadline after c

-- Boat details gate: owner or harbormaster. Another boater is refused.
query boatDetail(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.boater = viewer or exists harbormasters[viewer] else NOT_ALLOWED 'Only the harbormaster and the owner may view boat details.'
  return boats where .entry = entry first 1 by .id

-- Join the waitlist with boat details. One entry per boater.
mutation join(boatName: text 1..40, lengthFt: int 10..120, details: text <=200 ?):
  require not exists entries[viewer] else ALREADY_ON_LIST 'You are already on the waitlist.'
  e = insert entries { boater: viewer, status: 'waiting' }
  insert boats { entry: e.id, owner: viewer, boatName, lengthFt, details }
  return { entry: e.id }

-- Leave the waitlist while still waiting. Boat row goes with the entry.
mutation withdraw():
  e = entries[viewer] ! else NOT_ON_LIST 'You are not on the waitlist.'
  require e.status = 'waiting' else NOT_WAITING 'Only a waiting entry may be withdrawn.'
  delete boats[e.id]
  delete entries[viewer]
  return null

-- Harbormaster offers a slot to a waiting entry with a response deadline.
-- The entry's waiting status is the no-double-offer guard: offering flips
-- it to offered, and only waiting entries may be offered.
mutation offer(entry: entries, hours: int 1..72):
  require exists harbormasters[viewer] else NOT_HARBORMASTER 'Only the harbormaster may offer slots.'
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'waiting' else NOT_WAITING 'This entry is not waiting.'
  o = insert offers { entry, boater: e.boater, deadline: now + hours * 1h }
  update entries[entry] { status: 'offered' }
  return { offer: o.id, deadline: o.deadline }

-- The offered boater accepts in time.
mutation accept(offer: offers):
  o = offers[offer] ! else NOT_FOUND
  require o.boater = viewer else NOT_YOURS 'This offer is not yours.'
  require o.state = 'pending' else NOT_PENDING 'This offer is no longer pending.'
  require o.deadline >= now else EXPIRED 'This offer has expired.'
  update offers[offer] { state: 'accepted' }
  update entries[o.entry] { status: 'accepted' }
  return null

-- The offered boater declines; the entry returns to waiting.
mutation decline(offer: offers):
  o = offers[offer] ! else NOT_FOUND
  require o.boater = viewer else NOT_YOURS 'This offer is not yours.'
  require o.state = 'pending' else NOT_PENDING 'This offer is no longer pending.'
  update offers[offer] { state: 'declined' }
  update entries[o.entry] { status: 'waiting' }
  return null

-- Lapse expired offers and return their entries to waiting. Sweeps back
-- 30d from the period end so one run catches up missed periods.
job lapseOffers(periodStart: time, periodEnd: time):
  for o in offers where .deadline >= periodEnd - 30d and .deadline < periodEnd by .deadline:
    if o.state = 'pending':
      update offers[o.id] { state: 'lapsed' }
      e = entries[o.entry]
      if e != null:
        if e.status = 'offered':
          update entries[o.entry] { status: 'waiting' }

schedule lapseSweep every 1m: lapseOffers
