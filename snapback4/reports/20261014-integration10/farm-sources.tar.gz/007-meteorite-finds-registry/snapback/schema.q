-- Meteorite Finds Registry.
--
-- Hunters submit candidate finds (title, mass, photo URL, precise location).
-- Precise coordinates live in findCoords, readable only by the finder and the
-- assigned curator. Curators triage via queue, claim finds, and review them.
-- A daily job publishes coarsened (0.1 degree) coordinates onto confirmed finds
-- so the public confirmedFinds list never exposes a precise location.
-- Coordinates are scaled ints (degrees * 10000) so the job can coarsen them
-- with integer division.

use personas alice, bob, carol

table curators:
  principal: principal
  unique principal
  read <- allow
  insert <- deny
  update <- deny
  delete <- deny
  online only

table finds:
  finder: principal
  title: text 1..80
  massG: int 1..100000000
  photoUrl: text <=500 ?
  status: enum('submitted', 'under_review', 'confirmed', 'rejected') default 'submitted'
  assignedCurator: principal ?
  pubLatE4: int -900000..900000 ?
  pubLngE4: int -1800000..1800000 ?
  createdAt: time default now
  immutable finder, createdAt
  read <- .finder = viewer or .assignedCurator = viewer or exists curators[principal = viewer] or .status = 'confirmed'
  insert <- .finder = viewer
  update <- exists curators[principal = viewer]
  delete <- .finder = viewer
  cap 500 by finder
  online only

table findCoords:
  find: finds on delete cascade
  latE4: int -900000..900000
  lngE4: int -1800000..1800000
  unique find
  immutable find
  read <- .find.finder = viewer or .find.assignedCurator = viewer
  insert <- .find.finder = viewer
  update <- .find.finder = viewer
  delete <- .find.finder = viewer
  online only

query myFinds():
  return finds where .finder = viewer last 50 by .id

query coordsFor(find: finds):
  f = finds[find] ! else NOT_FOUND
  require f.finder = viewer or f.assignedCurator = viewer else COORDS_PRIVATE
  return findCoords where .find = find

query queue(status: enum('submitted', 'under_review')):
  require exists curators[principal = viewer] else NOT_CURATOR
  return finds where .status = status last 50 by .id

query confirmedFinds():
  return finds where .status = 'confirmed' last 50 by .id

mutation submitFind(title: text 1..80, massG: int 1..100000000, latE4: int -900000..900000, lngE4: int -1800000..1800000, photoUrl: text <=500 ?):
  f = insert finds { finder: viewer, title, massG, photoUrl }
  insert findCoords { find: f.id, latE4, lngE4 }
  return f

mutation claimFind(find: finds):
  f = finds[find] ! else NOT_FOUND
  require exists curators[principal = viewer] else NOT_CURATOR
  require f.status = 'submitted' else BAD_STATUS
  update finds[find] { assignedCurator: viewer, status: 'under_review' }
  return finds[find]

mutation reviewFind(find: finds, decision: enum('confirmed', 'rejected')):
  f = finds[find] ! else NOT_FOUND
  require exists curators[principal = viewer] else NOT_CURATOR
  require f.assignedCurator = viewer else NOT_ASSIGNED
  require f.status = 'under_review' else BAD_STATUS
  update finds[find] { status: decision }
  return finds[find]

mutation retractFind(find: finds):
  f = finds[find] ! else NOT_FOUND
  require f.finder = viewer else NOT_FINDER
  require f.status != 'confirmed' else ALREADY_PUBLISHED
  delete finds[find]

job publishConfirmed():
  for f in finds by .id:
    if f.status = 'confirmed' and f.pubLatE4 = null:
      c = findCoords[find = f.id]
      if c != null:
        update finds[f.id] { pubLatE4: (c.latE4 / 1000) * 1000, pubLngE4: (c.lngE4 / 1000) * 1000 }

schedule publishDaily every 1d at 03:00: publishConfirmed
