use personas alice, bob, carol

table coordinators:
  principal: principal
  unique principal
  cap 100
  read <- exists coordinators[viewer]
  insert <- exists coordinators[viewer]
  update <- deny
  delete <- exists coordinators[viewer]
  online only

table orchards:
  owner: principal
  fruit: text 1..40
  surplusKg: int 1..10000
  windowStart: time
  windowEnd: time
  location: text 1..120
  active: bool default true
  immutable owner
  public 'orchard postings are discoverable so gleaners can claim crews'
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
  cap 50 by owner
  online only

table crews:
  orchard: orchards
  gleaner: principal
  capKg: int 1..2000
  status: enum('claimed', 'harvested', 'cancelled') default 'claimed'
  visitDate: time
  immutable orchard, gleaner
  read <- .gleaner = viewer or exists orchards[.orchard, owner = viewer] or exists coordinators[viewer]
  insert <- .gleaner = viewer
  update <- .gleaner = viewer or exists orchards[.orchard, owner = viewer] or exists coordinators[viewer]
  delete <- .gleaner = viewer or exists coordinators[viewer]
  cap 20 by orchard
  online only

table harvestLogs:
  crew: crews
  gleaner: principal
  weightKg: int 1..2000
  loggedAt: time default now
  month: int
  immutable crew, gleaner
  read <- .gleaner = viewer or exists coordinators[viewer]
  insert <- .gleaner = viewer
  update <- deny
  delete <- deny
  cap 10000
  sync

view crewWeight: sum harvestLogs of .weightKg by .crew
  read <- allow

query listOrchards(c: cursor ?):
  return orchards last 50 by .id after c

query myOrchards(c: cursor ?):
  return orchards where .owner = viewer last 50 by .id after c

query crewsForOrchard(orchard: orchards, c: cursor ?):
  o = orchards[orchard] ! else NOT_FOUND
  if o.owner = viewer or exists coordinators[viewer]:
    return crews where .orchard = orchard last 50 by .id after c
  return crews where .orchard = orchard and .gleaner = viewer last 50 by .id after c

query myCrews(c: cursor ?):
  return crews where .gleaner = viewer last 50 by .id after c

query logsForCrew(crew: crews, c: cursor ?):
  return harvestLogs where .crew = crew and (.gleaner = viewer or exists coordinators[viewer]) last 50 by .id after c

query myLogs(c: cursor ?):
  return harvestLogs where .gleaner = viewer last 50 by .id after c

query monthlyReport(month: int):
  if exists coordinators[viewer]:
    return sum(harvestLogs where .month = month, .weightKg)
  return sum(harvestLogs where .month = month and .gleaner = viewer, .weightKg)

mutation postOrchard(fruit: text 1..40, surplusKg: int 1..10000, windowStart: time, windowEnd: time, location: text 1..120):
  require windowEnd > windowStart else BAD_WINDOW 'The access window must end after it starts.'
  return insert orchards { owner: viewer, fruit, surplusKg, windowStart, windowEnd, location }

mutation editOrchard(orchard: orchards, fruit: text 1..40, surplusKg: int 1..10000, location: text 1..120):
  o = orchards[orchard] ! else NOT_FOUND
  require o.owner = viewer else NOT_OWNER 'Only the orchard owner can edit it.'
  update orchards[orchard] { fruit, surplusKg, location }
  return null

mutation closeOrchard(orchard: orchards):
  o = orchards[orchard] ! else NOT_FOUND
  require o.owner = viewer else NOT_OWNER 'Only the orchard owner can close it.'
  update orchards[orchard] { active: false }
  return null

mutation removeOrchard(orchard: orchards):
  o = orchards[orchard] ! else NOT_FOUND
  require o.owner = viewer else NOT_OWNER 'Only the orchard owner can remove it.'
  delete orchards[orchard]

mutation claimCrew(orchard: orchards, capKg: int 1..2000, visitDate: time):
  o = orchards[orchard] ! else NOT_FOUND
  require o.active else ORCHARD_CLOSED 'This orchard is closed to gleaning.'
  require visitDate >= o.windowStart and visitDate <= o.windowEnd else OUTSIDE_WINDOW 'The visit must fall inside the orchard access window.'
  require capKg <= o.surplusKg else OVER_CAP 'The per-visit cap cannot exceed the posted surplus.'
  return insert crews { orchard, gleaner: viewer, capKg, visitDate }

mutation setCrewStatus(crew: crews, status: enum('claimed', 'harvested', 'cancelled')):
  c = crews[crew] ! else NOT_FOUND
  require c.gleaner = viewer or exists coordinators[viewer] else NOT_YOURS 'Only the claiming gleaner or a coordinator can change the crew status.'
  update crews[crew] { status }
  return null

mutation cancelCrew(crew: crews):
  c = crews[crew] ! else NOT_FOUND
  require c.gleaner = viewer or exists coordinators[viewer] else NOT_YOURS 'Only the claiming gleaner or a coordinator can cancel the crew.'
  delete crews[crew]

mutation logHarvest(crew: crews, weightKg: int 1..2000, loggedAt: time ?):
  c = crews[crew] ! else NOT_FOUND
  require c.gleaner = viewer else NOT_YOURS 'Only the claiming gleaner can log harvest weight.'
  require c.status != 'cancelled' else CREW_CANCELLED 'This crew was cancelled.'
  at = loggedAt ?? now
  total = crewWeight[crew] ?? 0
  require total + weightKg <= c.capKg else OVER_CAP 'This visit would exceed its harvest weight cap.'
  return insert harvestLogs { crew, gleaner: viewer, weightKg, loggedAt: at, month: month(at) }
