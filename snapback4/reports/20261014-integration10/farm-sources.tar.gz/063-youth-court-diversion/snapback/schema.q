use personas alice, bob, morgan

table staff:
  principal: principal
  name: text 1..80
  role: enum('staff', 'supervisor')
  unique principal
  public 'Internal staff directory for assignment; no participant information.'
  online only

table participants:
  name: text 1..80
  caseCode: text 1..30
  assignedStaff: principal
  supervisor: principal
  requiredHours: int 1..300
  deadline: time
  status: enum('active', 'completed', 'overdue') default 'active'
  checkedAt: time ?
  verifiedSnapshot: int 0.. default 0
  immutable assignedStaff, supervisor, requiredHours, deadline, caseCode
  read <- .assignedStaff = viewer or .supervisor = viewer
  insert <- .assignedStaff = viewer and exists staff[viewer, role = 'staff'] and exists staff[principal = .supervisor, role = 'supervisor'] and .status = 'active' and .verifiedSnapshot = 0 and .checkedAt = null
  online only

table tasks:
  participant: participants
  title: text 1..120
  organization: text 1..100
  targetHours: int 1..200
  dueAt: time
  immutable participant, title, organization, targetHours, dueAt
  read through .participant
  insert <- .participant.assignedStaff = viewer
  online only

table hours:
  participant: participants
  task: tasks
  amount: int 1..12
  serviceDate: time
  note: text 1..400
  submittedBy: principal
  submittedAt: time default now
  decision: enum('pending', 'approved', 'rejected') default 'pending'
  reviewedBy: principal ?
  reviewedAt: time ?
  reviewNote: text <=400 default ''
  immutable participant, task, amount, serviceDate, note, submittedBy, submittedAt
  read through .participant
  insert <- .participant.assignedStaff = viewer and .submittedBy = viewer and .task.participant = .participant and .decision = 'pending' and .reviewedBy = null and .reviewedAt = null and .reviewNote = ''
  update (old, next) <- old.participant.supervisor = viewer and old.decision = 'pending' and next.decision != 'pending' and next.reviewedBy = viewer
  online only

view verifiedHours: sum hours of .amount where .decision = 'approved' by .participant

query directory():
  return staff first 50 by .id
query myParticipants():
  if exists staff[viewer, role = 'supervisor']:
    return participants where .supervisor = viewer first 100 by .id
  return participants where .assignedStaff = viewer first 100 by .id
query participantDetails(participant: participants):
  return participants[participant] ! else NOT_FOUND
query tasksFor(participant: participants):
  p = participants[participant] ! else NOT_FOUND
  return tasks where .participant = p.id first 200 by .id
query hoursFor(participant: participants):
  p = participants[participant] ! else NOT_FOUND
  return hours where .participant = p.id last 200 by .submittedAt
query progress(participant: participants):
  p = participants[participant] ! else NOT_FOUND
  return { verified: verifiedHours[p.id], required: p.requiredHours }

mutation createParticipant(name: text 1..80, caseCode: text 1..30, supervisor: principal, requiredHours: int 1..300, deadline: time):
  require exists staff[viewer, role = 'staff'] else STAFF_ONLY
  require deadline > now else DEADLINE_PAST
  return insert participants { name, caseCode, assignedStaff: viewer, supervisor, requiredHours, deadline }
mutation assignTask(participant: participants, title: text 1..120, organization: text 1..100, targetHours: int 1..200, dueAt: time):
  p = participants[participant] ! else NOT_FOUND
  require p.assignedStaff = viewer else STAFF_ONLY
  require dueAt > now and dueAt <= p.deadline else INVALID_DEADLINE
  return insert tasks { participant, title, organization, targetHours, dueAt }
mutation submitHours(task: tasks, amount: int 1..12, serviceDate: time, note: text 1..400):
  t = tasks[task] ! else NOT_FOUND
  p = participants[t.participant] ! else NOT_FOUND
  require p.assignedStaff = viewer else STAFF_ONLY
  require serviceDate <= now else FUTURE_SERVICE
  return insert hours { participant: p.id, task, amount, serviceDate, note, submittedBy: viewer }
mutation reviewHours(entry: hours, decision: enum('approved', 'rejected'), reviewNote: text 1..400):
  h = hours[entry] ! else NOT_FOUND
  p = participants[h.participant] ! else NOT_FOUND
  require p.supervisor = viewer else SUPERVISOR_ONLY
  require h.decision = 'pending' else ALREADY_REVIEWED
  return update hours[entry] { decision, reviewNote, reviewedBy: viewer, reviewedAt: now }

job checkDeadlines(periodStart: time, periodEnd: time):
  for p in participants:
    total = verifiedHours[p.id] ?? 0
    state = 'completed' if total >= p.requiredHours else 'overdue' if p.deadline < periodEnd else 'active'
    update participants[p.id] { status: state, verifiedSnapshot: total, checkedAt: periodEnd }
schedule nightlyCheck every 1d at 02:00: checkDeadlines
