-- College Application Tracker schema.
-- Personas: alice + bob (students), carol (counselor), dave (recommender).
use personas alice, bob, carol, dave

-- Roster: one row per counselor. Probes in rules see every row.
table counselors:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table applications:
  student: principal
  college: text 1..80
  deadline: time
  status: enum('planned', 'applied', 'accepted', 'declined') default 'planned'
  immutable student
  read <- .student = viewer or exists counselors[viewer]
  insert <- .student = viewer
  update <- .student = viewer
  delete <- .student = viewer
  cap 50 by student
  sync

-- Tasks carry the application's student inline (read-through is refused over a union audience).
table tasks:
  application: applications
  student: principal
  title: text 1..100
  due: time
  done: bool default false
  immutable application, student
  read <- .student = viewer or exists counselors[viewer]
  insert <- .student = .application.student and .student = viewer
  update <- .student = viewer
  delete <- .student = viewer
  cap 100 by application
  sync

-- Letters: the student cannot read them, even for their own application.
-- The author (recommender) and counselors can.
table letters:
  application: applications
  author: principal
  body: text 1..2000
  at: time default now
  immutable application, author
  read <- .author = viewer or exists counselors[viewer]
  insert <- .author = viewer
  update <- deny
  delete <- .author = viewer or exists counselors[viewer]
  cap 20 by application
  online only

-- Written only by the escalation job (runs as system, bypasses rules).
table escalations:
  application: applications
  student: principal
  task: tasks
  reason: text 1..200
  at: time default now
  unique task
  immutable application, student, task
  read <- .student = viewer or exists counselors[viewer]
  insert <- deny
  update <- deny
  delete <- deny
  online only

query myApplications():
  return applications where .student = viewer last 50 by .deadline

query counselorApplications():
  require exists counselors[viewer] else NOT_COUNSELOR 'Only counselors can list every application.'
  return applications last 50 by .deadline

query tasksFor(application: applications):
  return tasks where .application = application first 100 by .due

query lettersFor(application: applications):
  return letters where .application = application first 20 by .at

query escalationsFor(application: applications):
  return escalations where .application = application first 50 by .at

query myEscalations():
  return escalations where .student = viewer first 50 by .at

mutation addApplication(college: text 1..80, deadline: time):
  return insert applications { student: viewer, college, deadline }

mutation setStatus(application: applications, status: enum('planned', 'applied', 'accepted', 'declined')):
  app = applications[application] ! else NOT_FOUND
  require app.student = viewer else NOT_YOURS 'Only the student can change the status.'
  update applications[application] { status }
  return null

mutation addTask(application: applications, title: text 1..100, due: time):
  app = applications[application] ! else NOT_FOUND
  require app.student = viewer else NOT_YOURS 'Only the student can add tasks.'
  return insert tasks { application, student: app.student, title, due }

mutation setTaskDone(task: tasks, done: bool):
  t = tasks[task] ! else NOT_FOUND
  require t.application.student = viewer else NOT_YOURS 'Only the student can update tasks.'
  update tasks[task] { done }
  return null

mutation removeTask(task: tasks):
  t = tasks[task] ! else NOT_FOUND
  require t.application.student = viewer else NOT_YOURS 'Only the student can remove tasks.'
  delete tasks[task]
  return null

-- The recommender cannot read the application row (only its student and
-- counselors can), so a hidden row reads as absent here: readers get the
-- SELF_LETTER check, non-readers (recommenders) go straight to the insert.
mutation addLetter(application: applications, body: text 1..2000):
  app = applications[application]
  if app != null:
    require app.student != viewer else SELF_LETTER 'Students cannot write their own recommendation letters.'
  return insert letters { application, author: viewer, body }

-- Deadline job: escalate each overdue open task once (unique task backstop).
job escalateOverdue(periodStart: time, periodEnd: time):
  for t in tasks:
    if not t.done and t.due < periodEnd:
      if not exists escalations[task = t.id]:
        insert escalations { application: t.application, student: t.student, task: t.id, reason: 'Task is overdue.' }

schedule nightlyEscalation every 1d at 07:00: escalateOverdue
