-- Volunteer Visit Scheduling.
-- Personas: alice = coordinator (privileged), bob = volunteer, carol = family contact.
-- Care team = coordinators (they read visit notes); family sees only confirmations.
use personas alice, bob, carol

table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer or exists coordinators[viewer] or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or exists coordinators[viewer]
  update <- deny
  delete <- exists coordinators[viewer]
  online only

table volunteers:
  principal: principal
  displayName: text 1..60
  unique principal
  read <- .principal = viewer or exists coordinators[viewer] or exists volunteers[viewer]
  insert <- viewer = 'service:ops' or exists coordinators[viewer]
  update <- exists coordinators[viewer]
  delete <- exists coordinators[viewer]
  online only

table slots:
  patient: text 1..80
  startsAt: time
  location: text 1..120
  status: enum('open', 'assigned', 'completed', 'cancelled') default 'open'
  assignedVolunteer: principal ?
  familyContact: principal ?
  reminded: bool default false
  confirmed: bool default false
  createdBy: principal
  immutable patient, startsAt, createdBy
  read <- exists coordinators[viewer] or .assignedVolunteer = viewer or .familyContact = viewer or (exists volunteers[viewer] and .status = 'open')
  insert <- viewer = 'service:ops' or exists coordinators[viewer]
  update <- viewer = 'service:ops' or exists coordinators[viewer] or .assignedVolunteer = viewer
  delete <- exists coordinators[viewer]
  online only

table visits:
  slot: slots on delete cascade
  volunteer: principal
  note: text 1..1000
  at: time default now
  unique slot
  immutable slot, volunteer
  read <- exists coordinators[viewer] or .volunteer = viewer
  insert <- exists coordinators[viewer] or .volunteer = viewer
  update <- exists coordinators[viewer] or .volunteer = viewer
  online only

query openSlots(c: cursor ?):
  require exists volunteers[viewer] or exists coordinators[viewer] else NOT_VOLUNTEER
  return slots where .status = 'open' first 50 by .startsAt after c

query myAssignments(c: cursor ?):
  return slots where .assignedVolunteer = viewer first 50 by .startsAt after c

query allSlots(c: cursor ?):
  require exists coordinators[viewer] or viewer = 'service:ops' else NOT_COORDINATOR
  return slots first 50 by .startsAt after c

query familyConfirmations(c: cursor ?):
  return slots where .familyContact = viewer first 50 by .startsAt after c { id, startsAt, location, status, assignedVolunteer, confirmed }

query visitNote(slot: slots):
  require exists coordinators[viewer] or exists volunteers[viewer] else NOT_ALLOWED
  return visits where .slot = slot

mutation addCoordinator(who: principal):
  require exists coordinators[viewer] or viewer = 'service:ops' else NOT_COORDINATOR
  return insert coordinators { principal: who }

mutation registerVolunteer(who: principal, displayName: text 1..60):
  require exists coordinators[viewer] or viewer = 'service:ops' else NOT_COORDINATOR
  return upsert volunteers[who] { principal: who, displayName }

mutation createSlot(patient: text 1..80, startsAt: time, location: text 1..120, familyContact: principal ?):
  require exists coordinators[viewer] or viewer = 'service:ops' else NOT_COORDINATOR
  return insert slots { patient, startsAt, location, familyContact, createdBy: viewer, status: 'open' }

mutation assignVolunteer(slot: slots, volunteer: principal):
  require exists coordinators[viewer] or viewer = 'service:ops' else NOT_COORDINATOR
  s = slots[slot] ! else NOT_FOUND
  require s.status = 'open' else ALREADY_ASSIGNED
  require exists volunteers[volunteer] else NOT_VOLUNTEER
  update slots[slot] { assignedVolunteer: volunteer, status: 'assigned' }

mutation logVisit(slot: slots, note: text 1..1000):
  s = slots[slot] ! else NOT_FOUND
  require s.status = 'assigned' else NOT_ASSIGNED
  require s.assignedVolunteer = viewer or exists coordinators[viewer] else NOT_YOURS
  upsert visits[s.id] { slot: s.id, volunteer: s.assignedVolunteer ?? viewer, note }
  update slots[slot] { status: 'completed' }

mutation confirmVisit(slot: slots):
  s = slots[slot] ! else NOT_FOUND
  require exists coordinators[viewer] or s.assignedVolunteer = viewer else NOT_ALLOWED
  update slots[slot] { confirmed: true }

mutation cancelSlot(slot: slots):
  require exists coordinators[viewer] or viewer = 'service:ops' else NOT_COORDINATOR
  s = slots[slot] ! else NOT_FOUND
  require s.status = 'open' or s.status = 'assigned' else ALREADY_DONE
  update slots[slot] { status: 'cancelled' }

-- At 08:00 UTC, remind volunteers for visits happening in the next 24h
-- ("a day ahead"): the schedule's period is the day just started, so the
-- ahead-window begins at periodEnd.
job remindVolunteers(periodStart: time, periodEnd: time):
  for s in slots where .startsAt >= periodEnd and .startsAt < periodEnd + 24h by .startsAt:
    if s.status = 'assigned' and not s.reminded:
      update slots[s.id] { reminded: true }

schedule reminderDaily every 1d at 08:00: remindVolunteers
