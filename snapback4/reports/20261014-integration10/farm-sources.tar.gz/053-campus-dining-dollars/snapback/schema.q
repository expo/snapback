use personas alice, bob, pat, mira, noah

table plans:
  name: text 1..60
  weeklySwipes: int 1..30
  carryCap: int 0..10
  public 'Students and parents can compare meal plan rules.'
  online only

table cafes:
  name: text 1..60
  manager: principal
  public 'Campus cafes are a public directory.'
  online only

table wallets:
  student: principal
  parent: principal
  name: text 1..60
  plan: plans
  cents: int 0..1000000
  swipes: int 0..40
  rolledWeek: int
  unique student
  immutable student, parent, name, plan
  read <- .student = viewer or .parent = viewer
  update <- .student = viewer or .parent = viewer
  online only

table purchases:
  wallet: wallets
  student: principal
  cafe: cafes
  item: text 1..100
  cents: int 0..10000
  method: enum('dollars', 'swipe')
  at: time default now
  immutable wallet, student, cafe, item, cents, method, at
  read <- .student = viewer
  insert <- .student = viewer and .wallet.student = viewer
  online only

table topups:
  wallet: wallets
  payer: principal
  cents: int 100..50000
  at: time default now
  immutable wallet, payer, cents, at
  read <- .wallet.student = viewer or .wallet.parent = viewer
  insert <- .payer = viewer and .wallet.parent = viewer
  online only

view salesCents: sum purchases of .cents by .cafe, day(.at)
  read <- exists cafes[.cafe, manager = viewer]
view salesCount: count purchases by .cafe, day(.at)
  read <- exists cafes[.cafe, manager = viewer]
view swipeCount: count purchases where .method = 'swipe' by .cafe, day(.at)
  read <- exists cafes[.cafe, manager = viewer]

query walletFor(student: principal):
  w = wallets[student = student] ! else WALLET_PRIVATE 'This wallet is private.'
  return w
query myPurchases():
  return purchases where .student = viewer last 50 by .at
query topupHistory(student: principal):
  w = wallets[student = student] ! else WALLET_PRIVATE
  return topups where .wallet = w.id last 50 by .at
query cafeDirectory():
  return cafes first 20 by .name
query mealPlans():
  return plans first 20 by .name
query dailySales(cafe: cafes, date: int):
  c = cafes[cafe] ! else CAFE_NOT_FOUND
  require c.manager = viewer else MANAGER_ONLY 'Only this cafe manager can see daily sales.'
  return { cents: salesCents[cafe, date], purchases: salesCount[cafe, date], swipes: swipeCount[cafe, date] }

mutation spend(cafe: cafes, item: text 1..100, cents: int 1..10000):
  w = wallets[student = viewer] ! else STUDENT_ONLY
  require exists cafes[cafe] else CAFE_NOT_FOUND
  require w.cents >= cents else INSUFFICIENT_DOLLARS 'Not enough dining dollars.'
  update wallets[w.id] { cents: w.cents - cents }
  return insert purchases { wallet: w.id, student: viewer, cafe, item, cents, method: 'dollars' }
mutation useSwipe(cafe: cafes, item: text 1..100):
  w = wallets[student = viewer] ! else STUDENT_ONLY
  require exists cafes[cafe] else CAFE_NOT_FOUND
  require w.swipes > 0 else NO_SWIPES 'No meal swipes remaining.'
  update wallets[w.id] { swipes: w.swipes - 1 }
  return insert purchases { wallet: w.id, student: viewer, cafe, item, cents: 0, method: 'swipe' }
mutation topUp(student: principal, cents: int 100..50000):
  w = wallets[student = student] ! else WALLET_PRIVATE
  require w.parent = viewer else PARENT_ONLY 'Only the linked parent can top up.'
  require w.cents + cents <= 1000000 else BALANCE_LIMIT
  update wallets[w.id] { cents: w.cents + cents }
  return insert topups { wallet: w.id, payer: viewer, cents }

-- Daily scheduling makes the week boundary explicitly Monday 00:00 UTC.
-- Outages replenish only the current week; missed grants do not accumulate.
job rollWeeklySwipes(periodStart: time, periodEnd: time):
  week = (day(periodEnd) + 3) / 7
  for w in wallets where .rolledWeek < week by .id:
    p = plans[w.plan] ! else PLAN_NOT_FOUND
    update wallets[w.id] { swipes: p.weeklySwipes + min(w.swipes, p.carryCap), rolledWeek: week }
schedule weeklyCheck every 1d at 00:00: rollWeeklySwipes
