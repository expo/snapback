-- Emergency Volunteer Credentials.
-- Volunteers (alice, bob) upload certifications and request skill badges.
-- Carol is the privileged operator: coordinator (approves badges) and
-- incident commander (opens activations, queries approved holders).
use personas alice, bob, carol

table roles:
  principal: principal
  role: enum('coordinator', 'commander')
  unique principal
  read <- .principal = viewer or exists roles[viewer]
  insert <- deny
  update <- deny
  delete <- deny
  online only

table certifications:
  owner: principal
  title: text 3..80
  issuer: text 3..80
  expiresAt: time
  immutable owner
  read <- .owner = viewer or exists roles[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
  cap 50 by owner
  online only

table badges:
  volunteer: principal
  skill: enum('medical', 'rescue', 'comms', 'logistics')
  cert: certifications
  status: enum('pending', 'approved', 'expired') default 'pending'
  approvedAt: time ?
  immutable volunteer, skill, cert
  read <- .volunteer = viewer or exists roles[viewer]
  insert <- .volunteer = viewer
  update <- exists roles[viewer]
  delete <- deny
  cap 50 by volunteer
  online only

table activations:
  title: text 3..80
  active: bool default true
  startedAt: time default now
  immutable startedAt
  public 'activations are public so volunteers can see callouts'
  insert <- exists roles[viewer, role = 'commander']
  update <- exists roles[viewer, role = 'commander']
  -- NOTE: commander implies staff (exists roles[viewer]); coordinator-only
  -- checks use the bare probe, commander checks name the role.
  delete <- deny
  online only

query myCerts():
  return certifications where .owner = viewer

query myBadges():
  return badges where .volunteer = viewer

query reviewQueue(c: cursor ?):
  require exists roles[viewer] else NOT_COORDINATOR
  return badges where .status = 'pending' first 50 by .id after c

query availableVolunteers(activation: activations, skill: enum('medical', 'rescue', 'comms', 'logistics'), c: cursor ?):
  require exists roles[viewer, role = 'commander'] else NOT_COMMANDER
  a = activations[activation] ! else NOT_FOUND
  require a.active else NOT_ACTIVE
  return badges where .volunteer != viewer and .skill = skill and .status = 'approved' first 50 by .id after c

query listActivations():
  return activations last 20 by .startedAt

mutation uploadCert(title: text 3..80, issuer: text 3..80, expiresAt: time):
  require expiresAt > now else BAD_DATE 'Certification expiry must be in the future.'
  return insert certifications { owner: viewer, title, issuer, expiresAt }

mutation updateCert(cert: certifications, expiresAt: time):
  c = certifications[cert] ! else NOT_FOUND
  require c.owner = viewer else NOT_OWNER
  require expiresAt > now else BAD_DATE 'Certification expiry must be in the future.'
  update certifications[cert] { expiresAt }
  return null

mutation requestBadge(cert: certifications, skill: enum('medical', 'rescue', 'comms', 'logistics')):
  c = certifications[cert] ! else NOT_FOUND
  require c.owner = viewer else NOT_OWNER
  require c.expiresAt > now else CERT_LAPSED 'Certification has lapsed.'
  return insert badges { volunteer: viewer, skill, cert }

mutation approveBadge(badge: badges):
  require exists roles[viewer] else NOT_COORDINATOR
  b = badges[badge] ! else NOT_FOUND
  require b.status = 'pending' else BAD_STATUS 'Only pending badges can be approved.'
  c = certifications[b.cert] ! else NOT_FOUND
  require c.expiresAt > now else CERT_LAPSED 'Certification has lapsed.'
  update badges[badge] { status: 'approved', approvedAt: now }
  return null

mutation denyBadge(badge: badges):
  require exists roles[viewer] else NOT_COORDINATOR
  b = badges[badge] ! else NOT_FOUND
  require b.status = 'pending' else BAD_STATUS 'Only pending badges can be denied.'
  update badges[badge] { status: 'expired' }
  return null

mutation openActivation(title: text 3..80):
  require exists roles[viewer, role = 'commander'] else NOT_COMMANDER
  return insert activations { title }

mutation closeActivation(activation: activations):
  require exists roles[viewer, role = 'commander'] else NOT_COMMANDER
  a = activations[activation] ! else NOT_FOUND
  update activations[activation] { active: false }
  return null

job expireBadges():
  for b in badges by .id:
    if b.status = 'approved':
      c = certifications[b.cert]
      if c = null or c.expiresAt <= now:
        update badges[b.id] { status: 'expired' }

schedule expireHourly every 1h: expireBadges
