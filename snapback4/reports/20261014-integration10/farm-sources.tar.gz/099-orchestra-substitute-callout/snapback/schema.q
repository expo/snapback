use personas manager, alice, bob

-- Personnel managers: the privileged roster. Seeded as the system;
-- no mutation manages it, so the cast is fixed in fixtures/seed.
table managers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- Chairs (seats) in the orchestra. Public to browse, manager to manage.
table chairs:
  name: text 1..60
  section: text 1..40
  public 'any player may browse chairs'
  insert <- exists managers[viewer]
  update <- exists managers[viewer]
  delete <- exists managers[viewer]
  sync public last 200 by .id

-- A substitute callout for one chair and one concert. Public to browse;
-- pay lives in rates so it never leaks through this table.
table callouts:
  chair: chairs
  concert: text 1..120
  concertAt: time
  status: enum('open', 'cancelled') default 'open'
  owner: principal
  immutable chair, owner
  public 'any player may browse callouts'
  insert <- .owner = viewer and exists managers[viewer]
  update <- exists managers[viewer]
  delete <- exists managers[viewer]
  sync public last 200 by .id

-- Pay per callout. Manager-only: players cannot read these rows at all,
-- so a pay rate stays hidden from every player, including the offeree.
-- (The offeree learns the rate off-band from the manager.)
table rates:
  callout: callouts
  payCents: int 0..
  unique callout
  immutable callout
  read <- exists managers[viewer]
  insert <- exists managers[viewer]
  update <- exists managers[viewer]
  delete <- exists managers[viewer]
  online only

-- Ranked offers per callout. A player reads only their own offers;
-- the manager reads all. Rank 1 is top of the list.
table offers:
  callout: callouts
  player: principal
  rank: int 1..100
  status: enum('pending', 'accepted', 'declined', 'expired') default 'pending'
  expiresAt: time
  respondedAt: time ?
  unique callout, rank else RANK_TAKEN 'That rank is already offered for this callout.'
  unique callout, player else ALREADY_OFFERED 'That player already has an offer for this callout.'
  immutable callout, player, rank
  read <- .player = viewer or exists managers[viewer]
  insert <- exists managers[viewer]
  update <- .player = viewer or exists managers[viewer]
  delete <- exists managers[viewer]
  sync

query allChairs():
  return chairs first 200 by .id

query openCallouts():
  return callouts where .status = 'open' first 100 by .concertAt

query offersFor(callout: callouts):
  return offers where .callout = callout first 50 by .rank

query myOffers():
  return offers where .player = viewer first 50 by .expiresAt

-- Lowest-ranked live offer: lapsed (past expiresAt) offers are skipped,
-- so the job escalates down the list as offers lapse. The manager records
-- each lapse with escalate.
query currentOffer(callout: callouts):
  return offers where .callout = callout and .status = 'pending' and .expiresAt > now first 1 by .rank

query acceptedOffer(c: callouts):
  return offers where .callout = c and .status = 'accepted' first 1 by .rank

query calloutPay(c: callouts):
  require exists managers[viewer] else NOT_MANAGER 'Only the personnel manager may read pay rates.'
  return rates[callout = c]

mutation addChair(name: text 1..60, section: text 1..40):
  require exists managers[viewer] else NOT_MANAGER 'Only the personnel manager may add chairs.'
  return insert chairs { name, section }

mutation createCallout(chair: chairs, concert: text 1..120, concertAt: time, payCents: int 0..):
  require exists managers[viewer] else NOT_MANAGER 'Only the personnel manager may create callouts.'
  require concertAt > now else IN_THE_PAST 'The concert must be in the future.'
  ch = chairs[chair] ! else NOT_FOUND
  c = insert callouts { chair: ch.id, concert, concertAt, owner: viewer }
  insert rates { callout: c.id, payCents }
  return c

mutation offerPlayer(callout: callouts, player: principal, rank: int 1..100, minutes: int 1..43200):
  require exists managers[viewer] else NOT_MANAGER 'Only the personnel manager may send offers.'
  c = callouts[callout] ! else NOT_FOUND
  require c.status = 'open' else NOT_OPEN 'This callout is not open.'
  return insert offers { callout, player, rank, expiresAt: now + minutes * 1m }

mutation respond(offer: offers, accept: bool):
  o = offers[offer] ! else NOT_FOUND
  require o.player = viewer else NOT_YOURS 'This offer is for another player.'
  require o.status = 'pending' else ALREADY 'This offer was already answered.'
  require o.expiresAt > now else EXPIRED 'This offer has lapsed.'
  update offers[offer] { status: 'accepted' if accept else 'declined', respondedAt: now }
  return null

mutation escalate(offer: offers):
  require exists managers[viewer] else NOT_MANAGER 'Only the personnel manager may escalate.'
  o = offers[offer] ! else NOT_FOUND
  require o.status = 'pending' else ALREADY 'This offer was already answered.'
  require o.expiresAt <= now else NOT_YET 'This offer has not lapsed yet.'
  update offers[offer] { status: 'expired' }
  return null

mutation cancelCallout(callout: callouts):
  require exists managers[viewer] else NOT_MANAGER 'Only the personnel manager may cancel callouts.'
  c = callouts[callout] ! else NOT_FOUND
  update callouts[callout] { status: 'cancelled' }
  return null
