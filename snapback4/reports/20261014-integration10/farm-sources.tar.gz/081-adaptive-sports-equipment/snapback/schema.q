use personas alice, bob, coordinator

-- Coordinator membership is provisioned by the operator, never by app users.
table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table equipment:
  owner: principal
  title: text 3..100
  sport: enum('cycling', 'basketball', 'skiing', 'running', 'other')
  description: text 1..600
  maintenance: enum('ready', 'on-loan', 'inspection', 'repair') default 'ready'
  maintenanceNote: text <=300 default ''
  createdAt: time default now
  immutable owner, createdAt
  public 'Athletes browse equipment and maintenance availability.'
  insert <- .owner = viewer
  update <- exists coordinators[viewer]
  online only

table loans:
  equipment: equipment
  athlete: principal
  loaner: principal
  days: int 1..30
  status: enum('requested', 'approved', 'active', 'return-due', 'returned') default 'requested'
  requestedAt: time default now
  dueAt: time ?
  returnedAt: time ?
  immutable equipment, athlete, loaner, days, requestedAt
  read <- .athlete = viewer or .loaner = viewer or exists coordinators[viewer]
  insert <- .athlete = viewer and .loaner = .equipment.owner
  update <- exists coordinators[viewer]
  online only

-- A separate read boundary keeps fitting information out of loaner results.
table fittingNotes:
  loan: loans
  author: principal
  notes: text 1..1000
  unique loan
  immutable loan, author, notes
  read <- exists coordinators[viewer]
  insert <- .author = viewer and .loan.athlete = viewer and created loans[.loan]
  online only

query catalog(c: cursor ?):
  return equipment last 50 by .createdAt after c

query loanBoard(c: cursor ?):
  if exists coordinators[viewer]:
    return loans last 50 by .requestedAt after c
  return loans where .athlete = viewer or .loaner = viewer last 50 by .requestedAt after c

query coordinatorNotes(loan: loans):
  require exists coordinators[viewer] else COORDINATOR_ONLY 'Fitting notes are private to the loan coordinator.'
  return fittingNotes[loan = loan]

mutation listEquipment(title: text 3..100, sport: enum('cycling', 'basketball', 'skiing', 'running', 'other'), description: text 1..600):
  return insert equipment { owner: viewer, title, sport, description }

mutation requestLoan(equipment: equipment, days: int 1..30, notes: text 1..1000):
  item = equipment[equipment] ! else NOT_FOUND
  require item.owner != viewer else OWN_EQUIPMENT 'Request equipment from another loaner.'
  require item.maintenance = 'ready' else UNAVAILABLE 'This equipment is unavailable.'
  loan = insert loans { equipment, athlete: viewer, loaner: item.owner, days }
  insert fittingNotes { loan: loan.id, author: viewer, notes }
  return loan

mutation approveLoan(loan: loans):
  require exists coordinators[viewer] else COORDINATOR_ONLY
  request = loans[loan] ! else NOT_FOUND
  require request.status = 'requested' else BAD_STATUS
  item = equipment[request.equipment] ! else NOT_FOUND
  require item.maintenance = 'ready' else UNAVAILABLE
  update equipment[item.id] { maintenance: 'on-loan', maintenanceNote: '' }
  update loans[loan] { status: 'approved' }

mutation recordReturn(loan: loans):
  require exists coordinators[viewer] else COORDINATOR_ONLY
  request = loans[loan] ! else NOT_FOUND
  require request.status = 'active' or request.status = 'return-due' else BAD_STATUS
  update loans[loan] { status: 'returned', returnedAt: now }
  update equipment[request.equipment] { maintenance: 'inspection', maintenanceNote: 'Inspect after return before lending again.' }

mutation setMaintenance(equipment: equipment, status: enum('ready', 'inspection', 'repair'), note: text <=300):
  require exists coordinators[viewer] else COORDINATOR_ONLY
  item = equipment[equipment] ! else NOT_FOUND
  require item.maintenance != 'on-loan' else ON_LOAN 'Record the return before updating maintenance.'
  update equipment[equipment] { maintenance: status, maintenanceNote: note }

-- Each approved loan receives a return deadline. Catch overdue loans even
-- when several schedule periods were missed. Returned loans remain history.
job scheduleReturns(periodStart: time, periodEnd: time):
  for loan in loans:
    if loan.status = 'approved':
      update loans[loan.id] { status: 'active', dueAt: now + loan.days * 1d }
    if loan.status = 'active' and loan.dueAt != null:
      if loan.dueAt <= periodEnd:
        update loans[loan.id] { status: 'return-due' }

schedule returns every 1m: scheduleReturns
