-- Solar Array Cleaning Routes: operators schedule cleanings from logged
-- output drops; owners see only their own arrays; photo records hold
-- before/after evidence; scheduleCleaning estimates recovered energy.
-- Personas: alice = operator (roster), bob + cara = site owners.

use personas alice, bob, cara

-- Privileged roster. Rule probes see every row, so operator checks work
-- inside rules; program-level `exists operators[viewer]` sees the caller's
-- own row.
table operators:
  principal: principal
  unique principal
  cap 100
  read <- exists operators[viewer]
  insert <- exists operators[viewer]
  delete <- .principal = viewer
  sync

-- A solar array (site). Only operators register sites.
table sites:
  owner: principal
  name: text 1..80
  location: text 1..120
  capacityKw: int 1..100000
  read <- .owner = viewer or exists operators[viewer]
  insert <- exists operators[viewer]
  update <- exists operators[viewer]
  delete <- exists operators[viewer]
  cap 1000
  sync

-- A logged output sample for a site. Operators log (monitoring), owners may
-- log their own arrays. `owner` is copied so the read rule stays a syncable
-- owner-or-staff union.
table readings:
  site: sites on delete cascade
  owner: principal
  outputKw: int 0..1000000
  dropPct: int 0..100
  at: time default now
  immutable site, owner, at
  read <- .owner = viewer or exists operators[viewer]
  insert <- exists operators[viewer] or (.owner = viewer and exists sites[.site, owner = viewer])
  cap 5000 by site
  sync

-- A cleaning job. Only operators schedule; the mutation estimates recovered
-- energy from the latest logged drop.
table cleanings:
  site: sites on delete cascade
  owner: principal
  scheduledAt: time
  status: enum('scheduled', 'in_progress', 'done', 'cancelled') default 'scheduled'
  estimatedRecoveryKwh: int 0..100000000
  note: text <=200 ?
  immutable site, owner
  read <- .owner = viewer or exists operators[viewer]
  insert <- exists operators[viewer]
  update <- exists operators[viewer]
  delete <- exists operators[viewer]
  cap 2000 by site
  sync

-- Before/after photo evidence for a cleaning. `owner` is copied from the
-- cleaning's site so reads stay a union; the mutation checks the cleaning is
-- visible before stamping the owner.
table photos:
  cleaning: cleanings on delete cascade
  owner: principal
  kind: enum('before', 'after')
  image: image <=5000000 ?
  at: time default now
  immutable cleaning, owner, at
  read <- .owner = viewer or exists operators[viewer]
  insert <- exists operators[viewer] or (.owner = viewer and exists cleanings[.cleaning, owner = viewer])
  cap 50 by cleaning
  sync

-- Operators see every array; owners see only their own.
query mySites():
  if exists operators[viewer]:
    return sites last 50 by .id
  return sites where .owner = viewer last 50 by .id

query siteReadings(site: sites):
  s = sites[site] ! else NOT_FOUND
  return readings where .site = site last 50 by .at

query siteCleanings(site: sites):
  s = sites[site] ! else NOT_FOUND
  return cleanings where .site = site last 50 by .scheduledAt

query cleaningPhotos(cleaning: cleanings):
  c = cleanings[cleaning] ! else NOT_FOUND
  return photos where .cleaning = cleaning last 20 by .at

-- Operator work queue: every scheduled cleaning, soonest first.
query cleaningQueue():
  require exists operators[viewer] else NOT_OPERATOR
  return cleanings last 50 by .scheduledAt

mutation registerSite(owner: principal, name: text 1..80, location: text 1..120, capacityKw: int 1..100000):
  require exists operators[viewer] else NOT_OPERATOR
  return insert sites { owner, name, location, capacityKw }

mutation logReading(site: sites, outputKw: int 0..1000000, dropPct: int 0..100):
  s = sites[site] ! else NOT_FOUND
  require exists operators[viewer] or s.owner = viewer else NOT_READER
  return insert readings { site, owner: s.owner, outputKw, dropPct, at: now }

-- Schedule a cleaning; estimate = capacity x latest drop % x 6 sun-hours.
mutation scheduleCleaning(site: sites, scheduledAt: time, note: text <=200 ?):
  s = sites[site] ! else NOT_FOUND
  require exists operators[viewer] else NOT_OPERATOR
  page = readings where .site = site last 1 by .at
  drop = max(page, .dropPct) ?? 0
  estimate = s.capacityKw * drop * 6 / 100
  return insert cleanings { site, owner: s.owner, scheduledAt, estimatedRecoveryKwh: estimate, note }

mutation setCleaningStatus(cleaning: cleanings, status: enum('scheduled', 'in_progress', 'done', 'cancelled')):
  c = cleanings[cleaning] ! else NOT_FOUND
  require exists operators[viewer] else NOT_OPERATOR
  update c { status }
  return null

-- Crew upload path: the operator, or the owner of the cleaned array.
mutation uploadPhoto(cleaning: cleanings, kind: enum('before', 'after'), image: image <=5000000 ?):
  c = cleanings[cleaning] ! else NOT_FOUND
  s = sites[c.site] ! else NOT_FOUND
  require exists operators[viewer] or s.owner = viewer else NOT_CREW
  return insert photos { cleaning, owner: s.owner, kind, image }
