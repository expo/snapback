-- Gear Return Inspection Disputes.
-- Renters check out gear (checkout photo). Staff file inspections
-- (return photo + proposed fee). Renters contest with their own photo.
-- Managers arbitrate. A daily job releases deposits when no claim is
-- filed inside the window.
use personas alice, bob, carol

-- Outfitter catalog. World-readable; only managers edit it.
table gear:
  name: text 1..80
  description: text <=500 ?
  depositCents: int 0..10000000
  read <- allow
  insert <- exists managers[principal = viewer]
  update <- exists managers[principal = viewer]
  delete <- exists managers[principal = viewer]
  cap 500
  online only

-- Staff roster (one row per staff member; carol is staff).
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- Manager roster (carol is also a manager, so she can arbitrate).
table managers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- A rental: renter checks out one gear item, photographed at checkout.
table rentals:
  item: gear
  renter: principal
  checkoutPhoto: text 1..500
  dueAt: time
  returnedAt: time ?
  status: enum('active', 'returned', 'closed') default 'active'
  claimed: bool default false
  released: bool default false
  immutable item, renter
  read <- .renter = viewer or exists staff[principal = viewer] or exists managers[principal = viewer]
  insert <- .renter = viewer
  update <- .renter = viewer or exists staff[principal = viewer] or exists managers[principal = viewer]
  cap 200 by renter
  online only

-- Staff inspection of a returned rental: return photo + proposed fee.
table inspections:
  rental: rentals
  inspector: principal
  returnPhoto: text 1..500
  condition: enum('ok', 'scuffed', 'damaged', 'lost')
  proposedFeeCents: int 0..500000
  note: text <=500 ?
  createdAt: time default now
  unique rental else ALREADY_INSPECTED 'This rental already has an inspection.'
  immutable rental, inspector
  read <- exists rentals[.rental, renter = viewer] or exists staff[principal = viewer] or exists managers[principal = viewer]
  insert <- exists staff[principal = viewer] or exists managers[principal = viewer]
  update <- exists staff[principal = viewer] or exists managers[principal = viewer]
  cap 500
  online only

-- Renter contest of an inspection, with the renter's own photo.
table disputes:
  inspection: inspections
  renter: principal
  reason: text 1..500
  renterPhoto: text 1..500 ?
  status: enum('open', 'resolved') default 'open'
  createdAt: time default now
  unique inspection else ALREADY_CONTESTED 'This inspection is already contested.'
  immutable inspection, renter
  read <- .renter = viewer or exists staff[principal = viewer] or exists managers[principal = viewer]
  insert <- .renter = viewer
  update <- .renter = viewer or exists managers[principal = viewer]
  cap 200 by renter
  online only

-- Manager arbitration of a dispute: exactly one ruling per dispute.
table rulings:
  dispute: disputes
  manager: principal
  decision: enum('fee-stands', 'fee-reduced', 'fee-waived')
  finalFeeCents: int 0..500000
  note: text <=500 ?
  decidedAt: time default now
  unique dispute else ALREADY_RULED 'This dispute already has a ruling.'
  immutable dispute, manager
  read <- exists disputes[.dispute, renter = viewer] or exists staff[principal = viewer] or exists managers[principal = viewer]
  insert <- exists managers[principal = viewer]
  cap 500
  online only

query gearCatalog(c: cursor ?):
  return gear first 50 by .id after c

query myRentals():
  return rentals where .renter = viewer

query rentalInspections(rental: rentals, c: cursor ?):
  return inspections where .rental = rental first 50 by .id after c

query inspectionDisputes(inspection: inspections):
  return disputes where .inspection = inspection

query disputeRuling(dispute: disputes):
  return rulings where .dispute = dispute

query openDisputes(c: cursor ?):
  require exists managers[principal = viewer] else NOT_MANAGER 'Managers only.'
  return disputes where .status = 'open' first 50 by .id after c

query returnsToInspect(c: cursor ?):
  require exists staff[principal = viewer] or exists managers[principal = viewer] else NOT_STAFF 'Staff only.'
  return rentals where .status = 'returned' first 50 by .id after c

mutation addGear(name: text 1..80, description: text <=500 ?, depositCents: int 0..10000000):
  require exists managers[principal = viewer] else NOT_MANAGER 'Managers only.'
  return insert gear { name, description, depositCents }

mutation checkout(item: gear, dueAt: time, checkoutPhoto: text 1..500):
  g = gear[item] ! else NOT_FOUND
  require dueAt > now else BAD_WINDOW 'The due date must be in the future.'
  return insert rentals { item, renter: viewer, dueAt, checkoutPhoto }

mutation markReturned(rental: rentals):
  r = rentals[rental] ! else NOT_FOUND
  require r.renter = viewer or exists staff[principal = viewer] or exists managers[principal = viewer] else NOT_YOURS 'Not your rental.'
  require r.status = 'active' else ALREADY_RETURNED 'This rental is already returned.'
  update rentals[rental] { status: 'returned', returnedAt: now }
  return rentals[rental]

mutation fileInspection(rental: rentals, returnPhoto: text 1..500, condition: enum('ok', 'scuffed', 'damaged', 'lost'), proposedFeeCents: int 0..500000, note: text <=500 ?):
  require exists staff[principal = viewer] or exists managers[principal = viewer] else NOT_STAFF 'Staff only.'
  r = rentals[rental] ! else NOT_FOUND
  require r.status = 'returned' else NOT_RETURNED 'The rental is not returned yet.'
  update rentals[rental] { claimed: true }
  return insert inspections { rental, inspector: viewer, returnPhoto, condition, proposedFeeCents, note }

mutation contestInspection(inspection: inspections, reason: text 1..500, renterPhoto: text 1..500 ?):
  i = inspections[inspection] ! else NOT_FOUND
  r = rentals[i.rental] ! else NOT_FOUND
  require r.renter = viewer else NOT_YOURS 'Not your rental.'
  return insert disputes { inspection, renter: viewer, reason, renterPhoto }

mutation arbitrate(dispute: disputes, decision: enum('fee-stands', 'fee-reduced', 'fee-waived'), finalFeeCents: int 0..500000, note: text <=500 ?):
  require exists managers[principal = viewer] else NOT_MANAGER 'Managers only.'
  d = disputes[dispute] ! else NOT_FOUND
  require d.status = 'open' else ALREADY_RULED 'This dispute is already resolved.'
  update disputes[dispute] { status: 'resolved' }
  return insert rulings { dispute, manager: viewer, decision, finalFeeCents, note }

-- Daily sweep: release deposits on returned rentals that nobody claimed
-- inside the 2-day window and that have no inspection.
job releaseDeposits(periodStart: time, periodEnd: time):
  for r in rentals by .id:
    if r.status = 'returned' and not r.claimed and not r.released and (r.returnedAt ?? now) + 2d < now:
      update rentals[r] { released: true, status: 'closed' }
schedule releaseDaily every 1d at 08:00: releaseDeposits
