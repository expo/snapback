use personas alice, bob, organizer

table scouts:
  principal: principal
  team: int 1..99999
  name: text 1..60
  unique principal
  unique team, principal
  immutable principal, team
  read <- .principal = viewer
  sync to .principal

table organizers:
  principal: principal
  unique principal
  read <- .principal = viewer
  sync to .principal

table events:
  name: text 1..100
  venue: text 1..100
  draftDeadline: time
  public 'Event details and alliance draft deadlines are public.'
  update <- exists organizers[viewer]
  sync last 20 by .id

table rankings:
  event: events
  team: int 1..99999
  name: text 1..80
  rank: int 1..100
  points: int 0..1000
  unique event, team
  immutable event, team
  public 'Official event rankings are public.'
  update <- exists organizers[viewer]
  cap 100 by event
  sync

table observations:
  event: events
  scoutTeam: int 1..99999
  author: principal
  robotTeam: int 1..99999
  matchNumber: int 1..300
  autoPoints: int 0..100
  teleopPoints: int 0..200
  defense: int 1..5
  reliability: enum('reliable', 'issues', 'disabled')
  notes: text <=500
  recordedAt: time default now
  immutable event, scoutTeam, author, recordedAt
  read <- exists scouts[.scoutTeam, viewer]
  insert <- .author = viewer and exists scouts[.scoutTeam, viewer]
  delete <- .author = viewer and exists scouts[.scoutTeam, viewer]
  sync to scouts[.scoutTeam] last 500 by .recordedAt, .id

table picks:
  event: events
  scoutTeam: int 1..99999
  robotTeam: int 1..99999
  priority: int 1..3
  unique event, scoutTeam, priority
  immutable event, scoutTeam, priority
  read <- exists scouts[.scoutTeam, viewer]
  insert <- exists scouts[.scoutTeam, viewer]
  update <- exists scouts[.scoutTeam, viewer]
  delete <- exists scouts[.scoutTeam, viewer]
  online only

query myScout():
  return scouts[principal = viewer]
query isOrganizer():
  return exists organizers[viewer]
query eventList():
  return events last 20 by .id
query publicRankings(event: events):
  return rankings where .event = event first 100 by .rank
query teamObservations():
  s = scouts[principal = viewer]
  if s = null:
    return observations where .scoutTeam = 0 last 500 by .recordedAt, .id
  return observations where .scoutTeam = s.team last 500 by .recordedAt, .id
query alliancePicks(event: events):
  s = scouts[principal = viewer]
  if s = null:
    return picks where .scoutTeam = 0 first 3 by .priority
  return picks where .scoutTeam = s.team and .event = event first 3 by .priority

mutation recordObservation(event: events, robotTeam: int 1..99999, matchNumber: int 1..300, autoPoints: int 0..100, teleopPoints: int 0..200, defense: int 1..5, reliability: enum('reliable', 'issues', 'disabled'), notes: text <=500):
  s = scouts[principal = viewer] ! else NOT_SCOUT 'Only a team scout can record observations.'
  require exists events[event] else EVENT_NOT_FOUND
  return insert observations { event, scoutTeam: s.team, author: viewer, robotTeam, matchNumber, autoPoints, teleopPoints, defense, reliability, notes }
mutation removeObservation(observation: observations):
  delete observations[observation]
mutation setPick(event: events, priority: int 1..3, robotTeam: int 1..99999):
  s = scouts[principal = viewer] ! else NOT_SCOUT
  e = events[event] ! else EVENT_NOT_FOUND
  require now < e.draftDeadline else DRAFT_LOCKED 'Alliance picks are locked. The draft deadline has passed.'
  require robotTeam != s.team else OWN_TEAM 'Choose another team for your alliance.'
  require exists rankings[event, robotTeam] else TEAM_NOT_AT_EVENT
  return upsert picks[event, s.team, priority] { event, scoutTeam: s.team, priority, robotTeam }
mutation removePick(pick: picks):
  p = picks[pick] ! else NOT_FOUND
  e = events[p.event] ! else EVENT_NOT_FOUND
  require now < e.draftDeadline else DRAFT_LOCKED 'Alliance picks are locked. The draft deadline has passed.'
  delete picks[pick]
mutation setDraftDeadline(event: events, deadline: time):
  require exists organizers[viewer] else NOT_ORGANIZER 'Only event organizers can set the draft deadline.'
  update events[event] { draftDeadline: deadline }
mutation publishRanking(event: events, team: int 1..99999, rank: int 1..100, points: int 0..1000):
  require exists organizers[viewer] else NOT_ORGANIZER
  update rankings[event, team] { rank, points }
