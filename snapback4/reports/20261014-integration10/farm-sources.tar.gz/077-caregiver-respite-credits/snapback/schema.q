use personas alice, bob, carol

-- Coordinators: roster seeded via fixtures (system load) or POST /seed on dev.
table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- A care visit logged by a volunteer, reviewed by a coordinator.
table visits:
  volunteer: principal
  family: text 1..80
  hours: int 1..24
  at: time default now
  status: enum('pending', 'verified', 'rejected')
  note: text <=200 ?
  immutable volunteer
  by byVolunteer: volunteer, id
  read <- .volunteer = viewer or exists coordinators[viewer]
  insert <- .volunteer = viewer
  update <- exists coordinators[viewer]
  delete <- deny
  cap 200 by volunteer
  sync

-- Earned hours, minted only when a coordinator approves a visit.
table credits:
  volunteer: principal
  hours: int 1..24
  visit: visits
  earnedAt: time default now
  expiresAt: time
  expired: bool default false
  immutable volunteer, visit, earnedAt, expiresAt
  by byVolunteer: volunteer, id
  read <- .volunteer = viewer or exists coordinators[viewer]
  insert <- exists coordinators[viewer]
  update <- exists coordinators[viewer]
  delete <- deny
  cap 500 by volunteer
  sync

-- Monthly earned-hours totals used to enforce the cap.
view monthlyHours: sum credits of .hours by .volunteer, month(.earnedAt)
  read <- .volunteer = viewer or exists coordinators[viewer]

-- Spent hours.
table redemptions:
  volunteer: principal
  hours: int 1..12
  at: time default now
  reason: text 1..200
  immutable volunteer, hours, at
  by byVolunteer: volunteer, id
  read <- .volunteer = viewer or exists coordinators[viewer]
  insert <- .volunteer = viewer
  update <- deny
  delete <- deny
  cap 200 by volunteer
  sync

query myVisits():
  return visits where .volunteer = viewer last 50 by .id

query visitQueue():
  require exists coordinators[viewer] else NOT_COORDINATOR
  return visits where .status = 'pending' last 50 by .id

query myCredits():
  return credits where .volunteer = viewer and not .expired last 100 by .id

query myRedemptions():
  return redemptions where .volunteer = viewer last 50 by .id

query myBalance():
  earned = sum(credits where .volunteer = viewer and not .expired, .hours)
  spent = sum(redemptions where .volunteer = viewer, .hours)
  return { earned, spent, balance: earned - spent }

mutation logVisit(family: text 1..80, hours: int 1..24, note: text <=200 ?):
  return insert visits { volunteer: viewer, family, hours, status: 'pending', note }

mutation approveVisit(visit: visits):
  require exists coordinators[viewer] else NOT_COORDINATOR
  v = visits[visit] ! else NOT_FOUND
  require v.status = 'pending' else ALREADY_REVIEWED 'This visit was already reviewed.'
  require monthlyHours[v.volunteer, month(now)] + v.hours <= 40 else MONTHLY_CAP 'This volunteer reached the 40-hour monthly cap.'
  insert credits { volunteer: v.volunteer, hours: v.hours, visit, earnedAt: now, expiresAt: now + 90d }
  update visits[visit] { status: 'verified' }
  return null

mutation rejectVisit(visit: visits):
  require exists coordinators[viewer] else NOT_COORDINATOR
  v = visits[visit] ! else NOT_FOUND
  require v.status = 'pending' else ALREADY_REVIEWED 'This visit was already reviewed.'
  update visits[visit] { status: 'rejected' }
  return null

mutation redeemHours(hours: int 1..12, reason: text 1..200):
  earned = sum(credits where .volunteer = viewer and not .expired, .hours)
  spent = sum(redemptions where .volunteer = viewer, .hours)
  require earned - spent >= hours else INSUFFICIENT 'Not enough credit balance.'
  return insert redemptions { volunteer: viewer, hours, reason }

job expireCredits(periodStart: time, periodEnd: time):
  for c in credits by .id:
    if not c.expired and c.expiresAt < periodEnd:
      update credits[c.id] { expired: true }
schedule expireNightly every 1d at 03:00: expireCredits
