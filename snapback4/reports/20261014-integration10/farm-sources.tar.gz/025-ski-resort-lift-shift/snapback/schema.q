-- Lift Operator Shift Board
-- Personas: alice, bob = operators; carol = supervisor.
use personas alice, bob, carol

table staff:
  principal: principal
  role: enum('supervisor', 'operator')
  unique principal
  read <- .principal = viewer or exists staff[viewer]
  insert <- exists staff[viewer, role = 'supervisor'] or viewer = 'service:ops'
  update <- exists staff[viewer, role = 'supervisor']
  delete <- exists staff[viewer, role = 'supervisor']
  online only

table certs:
  operator: principal
  cert: enum('chair', 'gondola', 'tbar')
  unique operator, cert
  immutable operator, cert
  read <- exists staff[viewer]
  insert <- exists staff[viewer, role = 'supervisor']
  delete <- exists staff[viewer, role = 'supervisor']
  online only

table shifts:
  lift: text 1..60
  certRequired: enum('chair', 'gondola', 'tbar')
  startsAt: time
  endsAt: time
  claimedBy: principal ?
  immutable lift, startsAt, endsAt, certRequired
  read <- exists staff[viewer]
  insert <- exists staff[viewer, role = 'supervisor']
  update (old, next) <- exists staff[viewer, role = 'supervisor'] or old.claimedBy = viewer or next.claimedBy = viewer
  delete <- exists staff[viewer, role = 'supervisor']
  cap 500
  online only

table swaps:
  shift: shifts on delete cascade
  fromOp: principal
  toOp: principal
  status: enum('pending', 'approved', 'denied') default 'pending'
  at: time default now
  immutable shift, fromOp, toOp
  read <- .fromOp = viewer or .toOp = viewer or exists staff[viewer, role = 'supervisor']
  insert <- .fromOp = viewer
  update <- exists staff[viewer, role = 'supervisor']
  cap 200 by shift
  online only

table violations:
  shift: shifts on delete cascade
  operator: principal
  reason: text 1..200
  at: time default now
  immutable shift, operator
  unique shift, operator
  cap 50 by shift
  read <- .operator = viewer or exists staff[viewer, role = 'supervisor']
  insert <- deny
  delete <- exists staff[viewer, role = 'supervisor']
  online only

query board(c: cursor ?):
  return shifts last 50 by .startsAt after c

query openShifts(c: cursor ?):
  return shifts where .claimedBy = null last 50 by .startsAt after c

query myShifts(c: cursor ?):
  return shifts where .claimedBy = viewer last 50 by .startsAt after c

query swapQueue(c: cursor ?):
  if exists staff[viewer, role = 'supervisor']:
    return swaps where .status = 'pending' last 50 by .id after c
  return swaps where .fromOp = viewer and .status = 'pending' last 50 by .id after c

query restReport(c: cursor ?):
  require exists staff[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  return violations last 50 by .id after c

query myFlags(c: cursor ?):
  return violations where .operator = viewer last 50 by .id after c

mutation postShift(lift: text 1..60, certRequired: enum('chair', 'gondola', 'tbar'), startsAt: time, endsAt: time):
  require exists staff[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  require endsAt > startsAt else BAD_WINDOW
  return insert shifts { lift, certRequired, startsAt, endsAt }

mutation claimShift(shift: shifts):
  s = shifts[shift] ! else NOT_FOUND
  require s.claimedBy = null else TAKEN
  require exists staff[viewer, role = 'operator'] else NOT_OPERATOR
  require exists certs[viewer, s.certRequired] else NOT_CERTIFIED
  update shifts[shift] { claimedBy: viewer }

mutation releaseShift(shift: shifts):
  s = shifts[shift] ! else NOT_FOUND
  require s.claimedBy = viewer else NOT_HOLDER
  update shifts[shift] { claimedBy: null }

mutation requestSwap(shift: shifts, toOp: principal):
  s = shifts[shift] ! else NOT_FOUND
  require s.claimedBy = viewer else NOT_HOLDER
  require toOp != viewer else SELF_SWAP
  require exists staff[toOp, role = 'operator'] else TO_NOT_OPERATOR
  require exists certs[toOp, s.certRequired] else TO_NOT_CERTIFIED
  return insert swaps { shift, fromOp: viewer, toOp }

mutation approveSwap(swap: swaps):
  require exists staff[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  w = swaps[swap] ! else NOT_FOUND
  require w.status = 'pending' else ALREADY_DECIDED
  s = shifts[w.shift] ! else NOT_FOUND
  require s.claimedBy = w.fromOp else STALE
  update shifts[w.shift] { claimedBy: w.toOp }
  update swaps[swap] { status: 'approved' }

mutation denySwap(swap: swaps):
  require exists staff[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  w = swaps[swap] ! else NOT_FOUND
  require w.status = 'pending' else ALREADY_DECIDED
  update swaps[swap] { status: 'denied' }

mutation grantRole(who: principal, role: enum('supervisor', 'operator')):
  require exists staff[viewer, role = 'supervisor'] or viewer = 'service:ops' else NOT_SUPERVISOR
  return upsert staff[who] { principal: who, role }

mutation grantCert(who: principal, cert: enum('chair', 'gondola', 'tbar')):
  require exists staff[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  require exists staff[who, role = 'operator'] else TO_NOT_OPERATOR
  return insert certs { operator: who, cert } if absent

mutation clearFlag(violation: violations):
  require exists staff[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  delete violations[violation]

job restCheck():
  for s in shifts by .startsAt:
    if s.claimedBy != null:
      if s.endsAt - s.startsAt > 10h or s.startsAt - day(s.startsAt) * 1d < 5h:
        if not exists violations[s.id, s.claimedBy]:
          insert violations { shift: s.id, operator: s.claimedBy, reason: 'Shift exceeds 10 hours.' if s.endsAt - s.startsAt > 10h else 'Shift starts inside nightly rest window.' }

schedule restNightly every 1d at 03:00: restCheck
