use personas alice, bob, cara

-- Teachers roster: one row per teacher. Students have no roster row;
-- enrollment in `students` is their membership.
table teachers:
  principal: principal
  school: text 1..80
  unique principal
  read <- .principal = viewer
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table classrooms:
  name: text 1..80
  school: text 1..80
  teacher: principal
  immutable teacher
  read <- allow
  insert <- exists teachers[principal = viewer]
  update <- .teacher = viewer
  delete <- .teacher = viewer
  cap 50
  online only

-- A class pairs with at most one partner: each side unique, so both
-- `pairings[classA = x]` and `pairings[classB = x]` are point lookups.
table pairings:
  classA: classrooms
  classB: classrooms
  createdBy: principal
  createdAt: time default now
  immutable classA, classB
  unique classA
  unique classB
  read <- allow
  insert <- .createdBy = viewer and exists teachers[principal = viewer]
  delete <- .createdBy = viewer
  cap 100
  online only

-- Enrollment. Partner classes learn first names only through the
-- `partnerRoster` projection; full rows are gated by `classRoster`.
table students:
  classroom: classrooms
  owner: principal
  firstName: text 1..30
  immutable classroom, owner
  unique classroom, owner
  read <- allow
  insert <- exists classrooms[.classroom, teacher = viewer]
  delete <- exists classrooms[.classroom, teacher = viewer]
  cap 200 by classroom
  cap 50 by owner
  online only

-- Letter lifecycle: draft -> pending -> approved -> delivered (job),
-- or pending -> rejected (teacher). Bodies stay hidden from the partner
-- class until approved.
table letters:
  author: principal
  authorName: text 1..30
  fromClass: classrooms
  toClass: classrooms
  subject: text 1..100
  body: text 1..2000
  status: enum('draft', 'pending', 'approved', 'delivered', 'rejected') default 'draft'
  createdAt: time default now
  immutable author, authorName, fromClass, toClass, createdAt
  read <- .author = viewer or .fromClass.teacher = viewer or (.toClass.teacher = viewer and (.status = 'approved' or .status = 'delivered'))
  insert <- .author = viewer
  update <- .author = viewer or .fromClass.teacher = viewer
  delete <- .author = viewer
  cap 500 by fromClass
  cap 200 by author
  cap 500 by toClass
  online only

query myClassrooms():
  return classrooms where .teacher = viewer

query allClassrooms():
  return classrooms

query myEnrollments():
  return students where .owner = viewer

query classRoster(classroom: classrooms):
  c = classrooms[classroom] ! else NOT_FOUND
  require c.teacher = viewer or exists students[classroom = classroom, owner = viewer] else NOT_MEMBER 'Only members of this class may see its roster.'
  return students where .classroom = classroom

-- First-name-only view for the partner class.
query partnerRoster(mine: classrooms):
  require exists pairings[classA = mine] or exists pairings[classB = mine] else NOT_PAIRED 'These classes are not paired.'
  if exists pairings[classA = mine]:
    p = pairings[classA = mine]
    return students where .classroom = p.classB { firstName }
  p2 = pairings[classB = mine] ! else NOT_PAIRED
  return students where .classroom = p2.classA { firstName }

query myLetters():
  return letters where .author = viewer

query pendingApprovals(classroom: classrooms):
  c = classrooms[classroom] ! else NOT_FOUND
  require c.teacher = viewer else NOT_TEACHER 'Only the class teacher may review approvals.'
  return letters where .fromClass = classroom and .status = 'pending'

query classInbox(classroom: classrooms):
  c = classrooms[classroom] ! else NOT_FOUND
  require c.teacher = viewer or exists students[classroom = classroom, owner = viewer] else NOT_MEMBER 'Only members of this class may read its inbox.'
  return letters where .toClass = classroom

query pairingsFor(classroom: classrooms):
  return pairings where .classA = classroom or .classB = classroom

mutation registerTeacher(school: text 1..80):
  upsert teachers[principal = viewer] { principal: viewer, school }

mutation createClassroom(name: text 1..80, school: text 1..80):
  require exists teachers[principal = viewer] else NOT_TEACHER 'Register as a teacher first.'
  return insert classrooms { name, school, teacher: viewer }

mutation pairClasses(classA: classrooms, classB: classrooms):
  a = classrooms[classA] ! else NOT_FOUND
  b = classrooms[classB] ! else NOT_FOUND
  require classA != classB else SAME_CLASS 'A class cannot pair with itself.'
  require exists teachers[principal = viewer] else NOT_TEACHER 'Only teachers can pair classes.'
  require a.teacher = viewer or b.teacher = viewer else NOT_INVOLVED 'Only a teacher of one of the classes may pair them.'
  return insert pairings { classA, classB, createdBy: viewer }

mutation unpair(classA: classrooms):
  p = pairings[classA = classA] ! else NOT_FOUND
  require p.createdBy = viewer else NOT_OWNER 'Only the teacher who paired them may unpair.'
  delete pairings[p.id]

mutation enrollStudent(classroom: classrooms, owner: principal, firstName: text 1..30):
  c = classrooms[classroom] ! else NOT_FOUND
  require c.teacher = viewer else NOT_TEACHER 'Only the class teacher may enroll students.'
  return insert students { classroom, owner, firstName }

mutation writeLetter(fromClass: classrooms, toClass: classrooms, subject: text 1..100, body: text 1..2000):
  s = students[classroom = fromClass, owner = viewer] ! else NOT_ENROLLED 'Only enrolled students may write letters.'
  f = classrooms[fromClass] ! else NOT_FOUND
  t = classrooms[toClass] ! else NOT_FOUND
  require exists pairings[classA = fromClass, classB = toClass] or exists pairings[classA = toClass, classB = fromClass] else NOT_PAIRED 'These classes are not paired.'
  return insert letters { author: viewer, authorName: s.firstName, fromClass, toClass, subject, body }

mutation submitLetter(letter: letters):
  l = letters[letter] ! else NOT_FOUND
  require l.author = viewer else NOT_AUTHOR 'Only the author may submit this letter.'
  require l.status = 'draft' else BAD_STATUS 'Only drafts can be submitted.'
  update letters[letter] { status: 'pending' }
  return null

mutation approveLetter(letter: letters):
  l = letters[letter] ! else NOT_FOUND
  c = classrooms[l.fromClass] ! else NOT_FOUND
  require c.teacher = viewer else NOT_TEACHER 'Only the sending class teacher may approve.'
  require l.status = 'pending' else BAD_STATUS 'Only pending letters can be approved.'
  update letters[letter] { status: 'approved' }
  return null

mutation rejectLetter(letter: letters):
  l = letters[letter] ! else NOT_FOUND
  c = classrooms[l.fromClass] ! else NOT_FOUND
  require c.teacher = viewer else NOT_TEACHER 'Only the sending class teacher may reject.'
  require l.status = 'pending' else BAD_STATUS 'Only pending letters can be rejected.'
  update letters[letter] { status: 'rejected' }
  return null

mutation retractLetter(letter: letters):
  l = letters[letter] ! else NOT_FOUND
  require l.author = viewer else NOT_AUTHOR 'Only the author may retract this letter.'
  require l.status = 'draft' or l.status = 'pending' else BAD_STATUS 'Only drafts or pending letters can be retracted.'
  delete letters[letter]

job deliverBatch():
  for l in letters by .id:
    if l.status = 'approved':
      update letters[l.id] { status: 'delivered' }

schedule deliveryHourly every 1h: deliverBatch
