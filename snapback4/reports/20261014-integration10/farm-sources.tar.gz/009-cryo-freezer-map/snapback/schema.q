-- Cryo Freezer Box Map: lab members claim rack positions in shared freezers.
-- Owners control who may see sample labels via the shared flag on their
-- positions; a half-yearly job reminds owners to audit and frees discards.
use personas alice, bob, curator

table stewards:
  principal: principal
  unique principal
  read <- .principal = viewer or exists stewards[viewer]
  insert <- exists stewards[viewer]
  update <- exists stewards[viewer]
  delete <- exists stewards[viewer]
  online only

table freezers:
  name: text 1..80
  location: text 1..120
  unique name
  public 'the freezer catalog is public'
  insert <- exists stewards[viewer]
  update <- exists stewards[viewer]
  delete <- exists stewards[viewer]
  sync public last 100 by .id

table positions:
  freezer: freezers
  slot: text 1..20
  owner: principal
  shared: bool default false
  status: enum('active', 'discarded') default 'active'
  claimedAt: time default now
  auditedAt: time default now
  unique freezer, slot else SLOT_TAKEN 'This rack position is already claimed.'
  immutable freezer, slot, owner
  public 'the box map is shared so members can see what is claimed'
  insert <- .owner = viewer
  update <- .owner = viewer or exists stewards[viewer]
  delete <- .owner = viewer or exists stewards[viewer]
  sync public last 500 by .id

table samples:
  position: positions on delete cascade
  label: text 1..120
  unique position
  immutable position
  read <- .position.owner = viewer or .position.shared = true or exists stewards[viewer]
  insert <- .position.owner = viewer
  update <- .position.owner = viewer
  delete <- .position.owner = viewer
  online only

table reminders:
  position: positions on delete cascade
  owner: principal
  periodEnd: time
  message: text 1..200
  unique position, periodEnd
  cap 20 by position
  immutable position, owner, periodEnd
  read <- .owner = viewer
  insert <- deny
  update <- deny
  delete <- deny
  sync to .owner last 100 by .periodEnd

query freezers():
  return freezers first 100 by .id

query freezerMap(freezer: freezers):
  return positions where .freezer = freezer first 200 by .slot

query myPositions():
  return positions where .owner = viewer first 200 by .id

query boxLabels(position: positions):
  return samples where .position = position

query myReminders():
  return reminders where .owner = viewer first 100 by .periodEnd

query stewardQueue():
  require exists stewards[viewer] else NOT_STEWARD
  return positions where .status = 'discarded' first 100 by .id

mutation addFreezer(name: text 1..80, location: text 1..120):
  require exists stewards[viewer] else NOT_STEWARD
  return insert freezers { name, location }

mutation claim(freezer: freezers, slot: text 1..20, label: text 1..120 ?):
  f = freezers[freezer] ! else NOT_FOUND
  row = insert positions { freezer, slot, owner: viewer, shared: false, status: 'active' }
  if label != null:
    insert samples { position: row.id, label: label }
  return row

mutation setLabel(position: positions, label: text 1..120):
  p = positions[position] ! else NOT_FOUND
  require p.owner = viewer else NOT_OWNER
  return upsert samples[position] { position, label }

mutation setShared(position: positions, shared: bool):
  p = positions[position] ! else NOT_FOUND
  require p.owner = viewer else NOT_OWNER
  update positions[position] { shared }
  return null

mutation auditBox(position: positions):
  p = positions[position] ! else NOT_FOUND
  require p.owner = viewer else NOT_OWNER
  update positions[position] { auditedAt: now }
  return null

mutation markDiscarded(position: positions):
  p = positions[position] ! else NOT_FOUND
  require p.owner = viewer or exists stewards[viewer] else NOT_OWNER
  update positions[position] { status: 'discarded' }
  return null

mutation release(position: positions):
  p = positions[position] ! else NOT_FOUND
  require p.owner = viewer or exists stewards[viewer] else NOT_OWNER
  delete positions[position]
  return null

mutation grantSteward(who: principal):
  require exists stewards[viewer] else NOT_STEWARD
  return upsert stewards[who] { principal: who }

job auditBoxes(periodStart: time, periodEnd: time):
  for p in positions:
    if p.status = 'discarded':
      delete positions[p.id]
    else:
      if p.auditedAt < periodStart:
        if not exists reminders[p.id, periodEnd]:
          insert reminders { position: p.id, owner: p.owner, periodEnd, message: 'Time to audit your box.' }

schedule auditHalfYearly every 180d at 09:00: auditBoxes
