-- Sample Shipping Manifests.
-- Labs (senders) prepare shipments to partner sites with a manifest of items;
-- the receiving site confirms each item on arrival. Temperature logger files
-- upload against each shipment; a job flags manifests unreceived past their
-- expected window.
use personas alice, bob, carol

table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table shipments:
  sender: principal
  receiver: principal
  destSite: text 1..80
  expectedBy: time
  createdAt: time default now
  received: bool default false
  receivedAt: time ?
  overdue: bool default false
  immutable sender, receiver, createdAt
  read <- .sender = viewer or .receiver = viewer or exists coordinators[viewer]
  insert <- .sender = viewer
  update <- .sender = viewer or .receiver = viewer or exists coordinators[viewer]
  delete <- deny
  cap 500
  online only

table items:
  shipment: shipments on delete cascade
  name: text 1..120
  qty: int 1..10000
  confirmed: bool default false
  confirmedAt: time ?
  immutable shipment
  read through .shipment
  insert <- .shipment.sender = viewer
  update <- .shipment.sender = viewer or .shipment.receiver = viewer
  delete <- .shipment.sender = viewer
  cap 200 by shipment

table loggerFiles:
  shipment: shipments on delete cascade
  uploader: principal
  data: file <=5000000 ('text/csv', 'text/plain')
  at: time default now
  immutable shipment, uploader, at
  read through .shipment
  insert <- .shipment.sender = viewer or .shipment.receiver = viewer
  update <- deny
  delete <- .shipment.sender = viewer or .shipment.receiver = viewer
  cap 20 by shipment

query mySent(c: cursor ?):
  return shipments where .sender = viewer last 50 by .createdAt after c

query incoming(c: cursor ?):
  return shipments where .receiver = viewer last 50 by .createdAt after c

query allShipments(c: cursor ?):
  require exists coordinators[viewer] else NOT_COORDINATOR
  return shipments last 50 by .createdAt after c

query overdueShipments(c: cursor ?):
  if exists coordinators[viewer]:
    return shipments where .overdue = true last 50 by .createdAt after c
  return shipments where .overdue = true and (.sender = viewer or .receiver = viewer) last 50 by .createdAt after c

query shipmentItems(shipment: shipments, c: cursor ?):
  return items where .shipment = shipment first 100 by .id after c

query shipmentLoggers(shipment: shipments, c: cursor ?):
  return loggerFiles where .shipment = shipment last 20 by .at after c

query getShipment(shipment: shipments):
  return shipments[shipment]

mutation createShipment(receiver: principal, destSite: text 1..80, expectedBy: time):
  require receiver != viewer else SELF_SHIPMENT 'Sender and receiver must differ.'
  require expectedBy > now else BAD_WINDOW 'Expected arrival must be in the future.'
  return insert shipments { sender: viewer, receiver, destSite, expectedBy }

mutation addItem(shipment: shipments, name: text 1..120, qty: int 1..10000):
  s = shipments[shipment] ! else NOT_FOUND
  require s.sender = viewer else NOT_SENDER 'Only the sender adds manifest items.'
  require not s.received else ALREADY_RECEIVED 'Shipment already received.'
  return insert items { shipment, name, qty }

mutation removeItem(item: items):
  i = items[item] ! else NOT_FOUND
  s = shipments[i.shipment] ! else NOT_FOUND
  require s.sender = viewer else NOT_SENDER 'Only the sender removes manifest items.'
  require not s.received else ALREADY_RECEIVED 'Shipment already received.'
  delete items[item]

mutation confirmItem(item: items):
  i = items[item] ! else NOT_FOUND
  s = shipments[i.shipment] ! else NOT_FOUND
  require s.receiver = viewer else NOT_RECEIVER 'Only the receiver confirms items.'
  require not i.confirmed else ALREADY_CONFIRMED 'Item already confirmed.'
  update items[item] { confirmed: true, confirmedAt: now }
  return null

mutation uploadLogger(shipment: shipments, data: file <=5000000 ('text/csv', 'text/plain')):
  s = shipments[shipment] ! else NOT_FOUND
  require s.sender = viewer or s.receiver = viewer else NOT_PARTY 'Only the shipment parties attach logger files.'
  return insert loggerFiles { shipment, uploader: viewer, data }

mutation markReceived(shipment: shipments):
  s = shipments[shipment] ! else NOT_FOUND
  require s.receiver = viewer else NOT_RECEIVER 'Only the receiver marks arrival.'
  require not s.received else ALREADY_RECEIVED 'Shipment already received.'
  update shipments[shipment] { received: true, receivedAt: now }
  return null

job flagOverdue():
  for s in shipments:
    if not s.received and s.expectedBy < now and not s.overdue:
      update shipments[s.id] { overdue: true }

schedule overdueSweep every 1h: flagOverdue
