use personas alice, bob, ranger

-- The roster is provisioned administratively; clients cannot grant roles.
table rangers:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table permits:
  owner: principal
  partyName: text 2..80
  partySize: int 1..12
  itinerary: text 10..2000 ?
  exitAt: time
  issuedAt: time default now
  status: enum('active', 'overdue', 'returned') default 'active'
  escalatedAt: time ?
  returnedAt: time ?
  immutable owner, partyName, partySize, exitAt, issuedAt
  read <- .owner = viewer or (.status = 'overdue' and exists rangers[viewer])
  insert <- .owner = viewer and .status = 'active'
  update (old, next) <- old.owner = viewer and next.status = 'returned'
  online only

query myRole():
  return { principal: viewer, isRanger: exists rangers[viewer] }

query myPermits(c: cursor ?):
  return permits where .owner = viewer last 50 by .issuedAt after c

query overdueParties(c: cursor ?):
  require exists rangers[viewer] else NOT_RANGER 'Only rangers can open the overdue board.'
  return permits where .status = 'overdue' first 100 by .exitAt after c

query permitDetails(permit: permits):
  return permits[permit]

mutation issuePermit(partyName: text 2..80, partySize: int 1..12, itinerary: text 10..2000, exitAt: time):
  require not exists rangers[viewer] else RANGER_ACCOUNT 'Select a hiker to issue a permit.'
  require exitAt > now and exitAt <= now + 30d else INVALID_EXIT 'Exit must be in the next 30 days.'
  return insert permits { owner: viewer, partyName, partySize, itinerary, exitAt }

mutation checkOut(permit: permits):
  p = permits[permit] ! else NOT_FOUND
  require p.owner = viewer else NOT_OWNER 'Only the permit holder can check out.'
  require p.status != 'returned' else ALREADY_RETURNED 'This party has already checked out.'
  return update permits[permit] { status: 'returned', returnedAt: now }

-- Sweep by immutable exit time; mutable status is tested inside the loop.
-- Catch up all overdue records, including boundaries missed during downtime.
job safetySweep():
  for p in permits:
    if p.status = 'active' and p.exitAt <= now:
      update permits[p.id] { status: 'overdue', escalatedAt: now }
    if p.status = 'returned' and p.itinerary != null:
      update permits[p.id] { itinerary: null }

schedule safetyCheck every 1m: safetySweep
