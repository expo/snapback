use personas intake, alice, bob

table staff:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer
  online only

table attorneys:
  principal: principal
  name: text 1..80
  area: enum('housing', 'family')
  unique principal
  immutable principal, area
  read <- .principal = viewer or exists staff[viewer]
  online only

table cases:
  summary: text 10..1000
  area: enum('housing', 'family')
  status: enum('open', 'claimed', 'active') default 'open'
  assignee: principal ?
  postedAt: time default now
  touchedAt: time default now
  reassignments: int 0.. default 0
  immutable summary, area, postedAt
  read <- exists staff[viewer] or exists attorneys[viewer]
  insert <- exists staff[viewer] and .status = 'open' and .assignee = null
  update (old, next) <- exists staff[viewer] or (old.status = 'open' and next.status = 'claimed' and next.assignee = viewer and exists attorneys[principal = viewer, area = old.area]) or (old.assignee = viewer and next.assignee = viewer and old.status = next.status) or (old.assignee = viewer and next.assignee = null and next.status = 'open')
  online only

table identities:
  caseId: cases
  clientName: text 1..100
  contact: text 3..200
  unique caseId
  immutable caseId
  read <- exists staff[viewer] or exists cases[.caseId, assignee = viewer, status = 'active']
  insert <- exists staff[viewer] and created cases[.caseId]
  online only

query profile():
  return { intake: exists staff[viewer], attorney: attorneys[principal = viewer] }

query board(c: cursor ?):
  require exists staff[viewer] or exists attorneys[viewer] else NOT_REGISTERED
  return cases last 50 by .postedAt after c

query clientIdentity(caseId: cases):
  return identities[caseId = caseId]

mutation postCase(summary: text 10..1000, area: enum('housing', 'family'), clientName: text 1..100, contact: text 3..200):
  require exists staff[viewer] else INTAKE_ONLY
  item = insert cases { summary, area }
  insert identities { caseId: item.id, clientName, contact }
  return { id: item.id }

mutation claim(caseId: cases):
  attorney = attorneys[principal = viewer] ! else ATTORNEY_ONLY
  item = cases[caseId] ! else NOT_FOUND
  require item.area = attorney.area else PRACTICE_MISMATCH
  require item.status = 'open' and item.assignee = null else ALREADY_CLAIMED
  update cases[caseId] { status: 'claimed', assignee: viewer, touchedAt: now }
  return null

mutation checkConflict(caseId: cases, passes: bool):
  require exists staff[viewer] else INTAKE_ONLY
  item = cases[caseId] ! else NOT_FOUND
  require item.status = 'claimed' else NOT_AWAITING_CHECK
  if passes:
    update cases[caseId] { status: 'active', touchedAt: now }
  else:
    update cases[caseId] { status: 'open', assignee: null, touchedAt: now }
  return null

mutation touch(caseId: cases):
  item = cases[caseId] ! else NOT_FOUND
  require item.assignee = viewer and item.status != 'open' else NOT_ASSIGNED
  update cases[caseId] { touchedAt: now }
  return null

mutation release(caseId: cases):
  item = cases[caseId] ! else NOT_FOUND
  require item.assignee = viewer and item.status != 'open' else NOT_ASSIGNED
  update cases[caseId] { status: 'open', assignee: null, touchedAt: now }
  return null

job reassignStalled():
  for item in cases:
    if item.status != 'open' and item.touchedAt <= now - 48h:
      update cases[item.id] { status: 'open', assignee: null, touchedAt: now, reassignments: item.reassignments + 1 }
schedule hourly every 1h: reassignStalled
