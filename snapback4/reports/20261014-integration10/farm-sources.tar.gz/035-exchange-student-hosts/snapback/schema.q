-- Exchange student host matching.
-- Personas: alice = coordinator (privileged), bob + carol = host families.
-- Redaction: table rows are readable by coordinators and registered hosts,
-- but queries project. browseStudents returns only safe fields; fullStudent
-- returns the whole row and refuses unless coordinator or accepted match.

use personas alice, bob, carol

table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table students:
  owner: principal
  name: text 1..80
  age: int 10..19
  country: text 1..60
  interests: text 1..500
  medical: text 1..500 ?
  contact: text 1..120 ?
  immutable owner
  read <- exists coordinators[viewer] or exists hosts[viewer]
  insert <- exists coordinators[viewer]
  update <- exists coordinators[viewer]
  delete <- exists coordinators[viewer]
  cap 500
  online only

table hosts:
  owner: principal
  familyName: text 1..80
  city: text 1..60
  capacity: int 1..10
  preferences: text 1..500 ?
  unique owner
  immutable owner
  read <- exists coordinators[viewer] or .owner = viewer
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
  cap 200
  online only

table matches:
  student: students on delete cascade
  host: principal
  status: enum('proposed', 'accepted', 'declined') default 'proposed'
  reminded: bool default false
  createdAt: time default now
  unique student, host else ALREADY_MATCHED 'This student is already matched to this host.'
  cap 500 by student
  immutable student, host, createdAt
  read <- exists coordinators[viewer] or .host = viewer
  insert <- exists coordinators[viewer]
  update (old, next) <- exists coordinators[viewer] or (old.host = viewer and next.host = viewer and old.status = 'proposed' and (next.status = 'accepted' or next.status = 'declined'))
  delete <- exists coordinators[viewer]
  cap 1000
  online only

table documents:
  owner: principal
  title: text 1..80
  body: text 1..4000
  createdAt: time default now
  immutable owner, createdAt
  read <- .owner = viewer or exists coordinators[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
  cap 200 by owner
  online only

query browseStudents(c: cursor ?):
  require exists coordinators[viewer] or exists hosts[viewer] else NOT_HOST 'Only coordinators and host families may browse students.'
  return students last 50 by .id after c { id, country, interests, age }

query fullStudent(student: students):
  if exists coordinators[viewer]:
    return students[student]
  m = matches[student, viewer]
  require m != null and m.status = 'accepted' else NOT_ACCEPTED 'The full profile is shared after the match is accepted.'
  return students[student]

query myHosts(c: cursor ?):
  if exists coordinators[viewer]:
    return hosts last 50 by .id after c
  return hosts where .owner = viewer last 50 by .id after c

query myMatches(c: cursor ?):
  if exists coordinators[viewer]:
    return matches last 50 by .id after c
  return matches where .host = viewer last 50 by .id after c

query myDocuments(c: cursor ?):
  if exists coordinators[viewer]:
    return documents last 50 by .id after c
  return documents where .owner = viewer last 50 by .id after c

mutation addStudent(name: text 1..80, age: int 10..19, country: text 1..60, interests: text 1..500, medical: text 1..500 ?, contact: text 1..120 ?):
  require exists coordinators[viewer] else NOT_COORDINATOR 'Only coordinators add students.'
  return insert students { owner: viewer, name, age, country, interests, medical, contact }

mutation registerHost(familyName: text 1..80, city: text 1..60, capacity: int 1..10, preferences: text 1..500 ?):
  return upsert hosts[viewer] { owner: viewer, familyName, city, capacity, preferences }

mutation proposeMatch(student: students, host: principal):
  require exists coordinators[viewer] else NOT_COORDINATOR 'Only coordinators propose matches.'
  s = students[student] ! else NOT_FOUND 'No such student.'
  require exists hosts[host] else NOT_HOST 'No such host family.'
  return insert matches { student, host, status: 'proposed', reminded: false }

mutation respondMatch(match: matches, accept: bool):
  m = matches[match] ! else NOT_FOUND 'No such match.'
  require exists coordinators[viewer] or m.host = viewer else NOT_YOURS 'Only the matched host family may respond.'
  update matches[match] { status: 'accepted' if accept else 'declined' }
  return null

mutation uploadDocument(title: text 1..80, body: text 1..4000):
  return insert documents { owner: viewer, title, body }

job paperworkReminders(periodStart: time, periodEnd: time):
  for m in matches where .createdAt >= periodStart and .createdAt < periodEnd by .createdAt:
    if m.status = 'proposed' and not m.reminded:
      update matches[m.id] { reminded: true }

schedule paperworkDaily every 1d at 08:00: paperworkReminders
