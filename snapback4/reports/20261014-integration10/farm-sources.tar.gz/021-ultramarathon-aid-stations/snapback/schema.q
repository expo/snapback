use personas alice, bob, control

table staff:
  principal: principal
  station: int 1..3
  unique principal
  immutable principal, station
  read <- .principal = viewer
  sync to .principal

table controllers:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer
  sync to .principal

table stations:
  number: int 1..3
  name: text 1..60
  distance: int 0..100
  unique number
  read <- exists staff[viewer]
  cap 3
  sync

table runners:
  bib: int 1..9999
  name: text 1..80
  lastStation: int 0..3 default 0
  lastAt: time default now
  dueAt: time
  status: enum('running', 'dropped', 'finished') default 'running'
  unique bib
  immutable bib, name
  read <- exists staff[viewer]
  update <- exists staff[viewer]
  cap 500
  sync

table checkins:
  runner: runners
  station: int 1..3
  captain: principal
  at: time
  unique runner, station else ALREADY_CHECKED_IN
  immutable runner, station, captain, at
  read <- exists staff[viewer]
  insert <- .captain = viewer and exists staff[viewer]
  cap 3 by runner
  cap 1500
  sync

table crew:
  runner: runners
  principal: principal
  unique runner, principal
  immutable runner, principal
  read <- .principal = viewer or exists controllers[viewer]
  insert <- exists controllers[viewer] and exists crew[.runner, viewer]
  delete <- exists controllers[viewer]
  cap 10 by runner
  sync

table bags:
  runner: runners
  contents: text 1..500
  unique runner
  immutable runner
  read <- exists crew[.runner, viewer]
  sync

table alerts:
  runner: runners
  checkpoint: int 1..3
  dueAt: time
  createdAt: time default now
  acknowledged: bool default false
  unique runner, checkpoint
  immutable runner, checkpoint, dueAt, createdAt
  read <- exists controllers[viewer]
  update <- exists controllers[viewer]
  cap 3 by runner
  cap 1500
  sync

query mySeat():
  return { captain: staff[viewer], control: exists controllers[viewer] }
query stationsList():
  return stations first 3 by .number
query positionBoard():
  return runners first 500 by .bib
query history(runner: runners):
  return checkins where .runner = runner last 3 by .station
query dropBag(runner: runners):
  require exists crew[runner, viewer] else CREW_ONLY 'Only authorized crew may view this drop bag.'
  return bags[runner = runner]
query crewList(runner: runners):
  require exists controllers[viewer] else CONTROL_ONLY
  return crew where .runner = runner first 10 by .id
query alertBoard():
  require exists controllers[viewer] else CONTROL_ONLY
  return alerts first 1500 by .id

mutation checkIn(bib: int 1..9999, station: int 1..3, at: time):
  seat = staff[viewer] ! else STAFF_ONLY
  require seat.station = station else WRONG_STATION 'Check in only at your assigned station.'
  r = runners[bib = bib] ! else BIB_NOT_FOUND
  require r.status = 'running' else RUNNER_INACTIVE
  require station > r.lastStation else STALE_CHECKPOINT
  require at >= r.lastAt and at <= now + 5m else BAD_TIME
  insert checkins { runner: r.id, station, captain: viewer, at }
  update runners[r.id] { lastStation: station, lastAt: at, dueAt: at + 2h, status: 'finished' if station = 3 else 'running' }
  return r.id
mutation dropRunner(runner: runners):
  require exists controllers[viewer] else CONTROL_ONLY
  update runners[runner] { status: 'dropped' }
mutation grantCrew(runner: runners, principal: principal):
  require exists controllers[viewer] else CONTROL_ONLY
  require exists runners[runner] else BIB_NOT_FOUND
  return insert crew { runner, principal }
mutation revokeCrew(runner: runners, principal: principal):
  require exists controllers[viewer] else CONTROL_ONLY
  require principal != viewer else KEEP_CONTROL_ACCESS
  c = crew[runner, principal] ! else NOT_FOUND
  delete crew[c.id]
mutation acknowledge(alert: alerts):
  require exists controllers[viewer] else CONTROL_ONLY
  update alerts[alert] { acknowledged: true }

job missedCheckpoints(periodStart: time, periodEnd: time):
  for r in runners:
    if r.status = 'running' and r.dueAt < periodEnd and r.lastStation < 3:
      if not exists alerts[r.id, r.lastStation + 1]:
        insert alerts { runner: r.id, checkpoint: r.lastStation + 1, dueAt: r.dueAt }
schedule checkpointWatch every 1m: missedCheckpoints
