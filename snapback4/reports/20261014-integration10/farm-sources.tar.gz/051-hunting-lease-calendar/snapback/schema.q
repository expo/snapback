-- Hunting Lease Calendar.
-- Members (alice, bob) reserve stands for date blocks (cap 4 per member,
-- no overlapping blocks per stand, locked stands refuse). The manager (carol)
-- curates stands, approves/denies guest passes, and reads every harvest
-- report. Harvests are private to their member + manager. A daily job locks
-- stands whose season window does not cover the current day.
-- All tables are online only: no device sync needed, web client stays wasm-free.

use personas alice, bob, carol

table managers:
  principal: principal
  unique principal
  read <- .principal = viewer or exists managers[viewer]
  insert <- exists managers[viewer] or viewer = 'service:ops'
  update <- exists managers[viewer]
  delete <- exists managers[viewer]
  online only

table stands:
  name: text 1..60
  location: text 1..120
  locked: bool default false
  seasonStart: time
  seasonEnd: time
  unique name else STAND_TAKEN 'A stand with that name already exists.'
  immutable seasonStart, seasonEnd
  public 'the stand list and its locks are visible to every member'
  insert <- exists managers[viewer]
  update <- exists managers[viewer]
  delete <- exists managers[viewer]
  online only

table reservations:
  stand: stands
  member: principal
  startsAt: time
  endsAt: time
  unique stand, startsAt, endsAt else OVERLAPS 'That stand is already reserved for those dates.'
  cap 4 by member
  immutable stand, member, startsAt, endsAt
  public 'the lease calendar is visible to every member'
  insert <- .member = viewer
  delete <- .member = viewer or exists managers[viewer]
  online only

view reservationCounts: count reservations by .member
  read <- .member = viewer
  online only

table guestPasses:
  stand: stands
  member: principal
  guestName: text 1..60
  date: time
  status: enum('pending', 'approved', 'denied') default 'pending'
  immutable stand, member, guestName, date
  read <- .member = viewer or exists managers[viewer]
  insert <- .member = viewer
  update <- exists managers[viewer]
  online only

table harvests:
  member: principal
  stand: stands
  at: time default now
  species: text 1..60
  notes: text <=500 ?
  immutable member, stand, at
  read <- .member = viewer or exists managers[viewer]
  insert <- .member = viewer
  online only

query standsList(c: cursor ?):
  return stands first 50 by .id after c

query myReservations(c: cursor ?):
  return reservations where .member = viewer first 50 by .startsAt after c

query standReservations(stand: stands, c: cursor ?):
  return reservations where .stand = stand first 50 by .startsAt after c

query allReservations(c: cursor ?):
  require exists managers[viewer] else NOT_MANAGER
  return reservations first 50 by .startsAt after c

query myGuestPasses(c: cursor ?):
  return guestPasses where .member = viewer first 50 by .date after c

query guestQueue(c: cursor ?):
  require exists managers[viewer] else NOT_MANAGER
  return guestPasses where .status = 'pending' first 50 by .date after c

query myHarvests(c: cursor ?):
  return harvests where .member = viewer first 50 by .at after c

query harvestLog(c: cursor ?):
  require exists managers[viewer] else NOT_MANAGER
  return harvests first 50 by .at after c

query myReservationCount():
  return reservationCounts[viewer]

query whoAmI():
  return viewer

mutation bootstrapManager(who: principal):
  require viewer = 'service:ops' else NOT_ADMIN 'Only the ops service seat bootstraps the first manager.'
  return insert managers { principal: who }

mutation addStand(name: text 1..60, location: text 1..120, seasonStart: time, seasonEnd: time):
  require exists managers[viewer] else NOT_MANAGER
  require seasonStart < seasonEnd else BAD_SEASON 'The season must start before it ends.'
  return insert stands { name, location, seasonStart, seasonEnd, locked: false }

mutation setStandLocked(stand: stands, locked: bool):
  require exists managers[viewer] else NOT_MANAGER
  s = stands[stand] ! else NOT_FOUND
  update stands[stand] { locked }
  return null

mutation reserve(stand: stands, startsAt: time, endsAt: time):
  s = stands[stand] ! else NOT_FOUND
  require not s.locked else STAND_LOCKED 'That stand is locked outside season.'
  require startsAt < endsAt else BAD_DATES 'The block must start before it ends.'
  require startsAt >= now - 1d else IN_THE_PAST 'Reservations start today or later.'
  require endsAt - startsAt <= 14d else TOO_LONG 'A reservation is at most 14 days.'
  require reservationCounts[viewer] < 4 else TOO_MANY 'You may hold at most 4 reservations.'
  require not exists reservations where .stand = stand and .startsAt < endsAt and .endsAt > startsAt else OVERLAPS 'That stand is already reserved for those dates.'
  return insert reservations { stand, member: viewer, startsAt, endsAt }

mutation cancelReservation(reservation: reservations):
  r = reservations[reservation] ! else NOT_FOUND
  require r.member = viewer or exists managers[viewer] else NOT_YOURS
  delete reservations[reservation]
  return null

mutation requestGuestPass(stand: stands, guestName: text 1..60, date: time):
  s = stands[stand] ! else NOT_FOUND
  require date >= now - 1d else IN_THE_PAST 'Guest passes are for today or later.'
  return insert guestPasses { stand, member: viewer, guestName, date }

mutation decideGuestPass(pass: guestPasses, approve: bool):
  require exists managers[viewer] else NOT_MANAGER
  p = guestPasses[pass] ! else NOT_FOUND
  require p.status = 'pending' else ALREADY_DECIDED 'That pass was already decided.'
  update guestPasses[pass] { status: 'approved' if approve else 'denied' }
  return null

mutation reportHarvest(stand: stands, species: text 1..60, notes: text <=500 ?):
  s = stands[stand] ! else NOT_FOUND
  return insert harvests { member: viewer, stand, species, notes }

job lockStands(periodStart: time, periodEnd: time):
  for s in stands by .id:
    if s.seasonStart > periodEnd or s.seasonEnd < periodEnd:
      if not s.locked:
        update stands[s.id] { locked: true }
    else:
      if s.locked:
        update stands[s.id] { locked: false }

schedule lockNightly every 1d at 03:00: lockStands
