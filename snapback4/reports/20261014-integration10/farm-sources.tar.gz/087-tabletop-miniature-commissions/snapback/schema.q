use personas alice, bob, mira

table painters:
  principal: principal
  name: text 1..60
  monthlyLimit: int 1..20
  slotsUsed: int 0..20 default 0
  slotMonth: int
  releasedPayments: int 0.. default 0
  unique principal
  immutable principal, name, monthlyLimit
  public 'Clients can discover painters and their available commission slots.'
  insert <- deny
  update <- allow
  delete <- deny
  online only

table commissions:
  client: principal
  painter: painters
  painterPrincipal: principal
  title: text 3..100
  notes: text <=1000
  miniatureCount: int 1..50
  finalCents: int 100..100000
  bookedMonth: int
  createdAt: time default now
  status: enum('requested', 'painting', 'approved', 'paid') default 'requested'
  photo: image <=5000000 ?
  caption: text <=300 default ''
  immutable client, painter, painterPrincipal, title, notes, miniatureCount, finalCents, bookedMonth, createdAt
  read <- .client = viewer or .painterPrincipal = viewer
  insert <- .client = viewer and .painterPrincipal = .painter.principal
  update <- .client = viewer or .painterPrincipal = viewer
  delete <- deny
  online only

query availablePainters(c: cursor ?):
  return painters first 20 by .name after c

query myCommissions(c: cursor ?):
  if exists painters[principal = viewer]:
    return commissions where .painterPrincipal = viewer last 50 by .createdAt after c
  return commissions where .client = viewer last 50 by .createdAt after c

query commissionDetail(commission: commissions):
  return commissions[commission] ! else NOT_FOUND

mutation reserve(painter: painters, title: text 3..100, notes: text <=1000, miniatureCount: int 1..50, finalCents: int 100..100000):
  p = painters[painter] ! else NOT_FOUND
  require p.principal != viewer else CLIENT_ONLY 'Choose a client persona to reserve a slot.'
  require p.slotMonth = month(now) else MONTH_PENDING 'The monthly slot reset has not run yet.'
  require p.slotsUsed < p.monthlyLimit else MONTH_FULL 'This painter has no commission slots left this month.'
  update painters[p] { slotsUsed: p.slotsUsed + 1 }
  return insert commissions { client: viewer, painter, painterPrincipal: p.principal, title, notes, miniatureCount, finalCents, bookedMonth: month(now) }

mutation postProgress(commission: commissions, photo: image <=5000000, caption: text <=300):
  r = commissions[commission] ! else NOT_FOUND
  require r.painterPrincipal = viewer else PAINTER_ONLY 'Only the commissioned painter can post progress.'
  require r.status != 'paid' else ALREADY_PAID 'A completed commission cannot be changed.'
  update commissions[r] { photo, caption, status: 'painting' }
  return null

mutation approveProgress(commission: commissions):
  r = commissions[commission] ! else NOT_FOUND
  require r.client = viewer else CLIENT_ONLY 'Only the client can approve progress.'
  require r.status = 'painting' and r.photo != null else NO_PROGRESS 'A new progress photo is required before approval.'
  update commissions[r] { status: 'approved' }
  return null

mutation releasePayment(commission: commissions):
  r = commissions[commission] ! else NOT_FOUND
  require r.painterPrincipal = viewer else PAINTER_ONLY 'Only the commissioned painter can release payment.'
  require r.status = 'approved' else APPROVAL_REQUIRED 'The client must approve the current photo before payment release.'
  p = painters[r.painter] ! else NOT_FOUND
  update commissions[r] { status: 'paid' }
  update painters[p] { releasedPayments: p.releasedPayments + 1 }
  return null

job resetMonthlySlots(periodStart: time, periodEnd: time):
  for p in painters:
    if p.slotMonth < month(periodEnd):
      update painters[p.id] { slotsUsed: 0, slotMonth: month(periodEnd) }

schedule monthlySlots every 1 month at day 1 00:00: resetMonthlySlots
