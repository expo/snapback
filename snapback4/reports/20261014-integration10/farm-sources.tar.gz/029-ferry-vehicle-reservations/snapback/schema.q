use personas alice, bob, carol

table residents:
  principal: principal
  name: text 1..60
  unique principal
  immutable principal
  read <- .principal = viewer
  insert <- deny
  sync to .principal

table crew:
  principal: principal
  name: text 1..60
  unique principal
  read <- exists crew[viewer]
  insert <- deny
  sync

table sailings:
  route: text 1..80
  departsAt: time
  quotaOpensAt: time
  capacity: int 1..100
  residentQuota: int 0..100
  immutable departsAt, quotaOpensAt, capacity, residentQuota
  public 'Published ferry timetable and vehicle capacity'
  insert <- exists crew[viewer]
  cap 100
  sync public

table reservations:
  sailing: sailings
  owner: principal
  plate: text 2..12
  resident: bool
  status: enum('standby', 'confirmed', 'cancelled') default 'standby'
  arrived: bool default false
  at: time default now
  unique sailing, owner else ALREADY_RESERVED
  immutable sailing, owner, plate, resident, at
  read <- .owner = viewer or exists crew[viewer]
  insert <- .owner = viewer and ((.resident and exists residents[viewer]) or (not .resident and not exists residents[viewer]))
  update <- .owner = viewer or exists crew[viewer]
  cap 1000
  cap 100 by owner
  sync

view occupied: count reservations where .status = 'confirmed' by .sailing
  read <- allow
view visitors: count reservations where .status = 'confirmed' and not .resident by .sailing
  read <- allow
view waiting: count reservations where .status = 'standby' by .sailing
  read <- allow

query profile():
  return { resident: exists residents[viewer], crew: exists crew[viewer] }
query departures():
  return sailings first 100 by .departsAt
query timetable():
  return sailings first 100 by .departsAt { id, route, departsAt, quotaOpensAt, capacity, residentQuota, occupied: occupied[.id], waiting: waiting[.id] }
query mine():
  return reservations where .owner = viewer last 100 by .at
query manifest(sailing: sailings):
  require exists crew[viewer] else NOT_CREW 'Only crew may access the manifest.'
  return reservations where .sailing = sailing first 1000 by .at

mutation addSailing(route: text 1..80, departsAt: time, quotaOpensAt: time, capacity: int 1..100, residentQuota: int 0..100):
  require exists crew[viewer] else NOT_CREW
  require departsAt > now and quotaOpensAt < departsAt else BAD_TIMES
  require residentQuota <= capacity else BAD_QUOTA
  return insert sailings { route, departsAt, quotaOpensAt, capacity, residentQuota }

mutation reserve(sailing: sailings, plate: text 2..12): server
  s = sailings[sailing] ! else NOT_FOUND
  require s.departsAt > now else DEPARTED
  require not exists reservations[sailing, viewer] else ALREADY_RESERVED
  resident = exists residents[viewer]
  eligible = occupied[sailing] < s.capacity and (resident or now >= s.quotaOpensAt or visitors[sailing] < s.capacity - s.residentQuota)
  return insert reservations { sailing, owner: viewer, plate, resident, status: 'confirmed' if eligible and waiting[sailing] = 0 else 'standby' }

mutation cancel(reservation: reservations):
  r = reservations[reservation] ! else NOT_FOUND
  require r.owner = viewer else NOT_OWNER
  require not r.arrived else ALREADY_ARRIVED
  require r.status != 'cancelled' else ALREADY_CANCELLED
  update reservations[r.id] { status: 'cancelled' }
  return null

mutation scanArrival(reservation: reservations):
  require exists crew[viewer] else NOT_CREW 'Only crew may scan arrivals.'
  r = reservations[reservation] ! else NOT_FOUND
  require r.status = 'confirmed' else NOT_CONFIRMED
  update reservations[r.id] { arrived: true }
  return null

job promoteStandby():
  for r in reservations by .at, .id:
    if r.status != 'standby':
      continue
    s = sailings[r.sailing] ! else NOT_FOUND
    if s.departsAt > now and occupied[r.sailing] < s.capacity:
      if r.resident or now >= s.quotaOpensAt or visitors[r.sailing] < s.capacity - s.residentQuota:
        update reservations[r.id] { status: 'confirmed' }
schedule promoteEveryMinute every 1m: promoteStandby
