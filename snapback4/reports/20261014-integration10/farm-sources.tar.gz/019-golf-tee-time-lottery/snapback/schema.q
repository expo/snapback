use personas alice, bob, pro

-- Pro shop roster: one row per staff member.
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

-- One weekly draw. Status: open -> drawn -> published.
table lotteries:
  weekLabel: text 1..40
  season: int 2000..2100
  annualCap: int 1..20 default 3
  status: enum('open', 'drawn', 'published') default 'open'
  drawAt: time
  immutable season
  public 'the lottery schedule is public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  sync public last 100 by .id

-- Premium tee times up for grabs in a lottery.
table teetimes:
  lottery: lotteries on delete cascade
  label: text 1..60
  startsAt: time
  immutable lottery
  cap 50 by lottery
  public 'the tee sheet is public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  sync public last 200 by .id

-- A member's entry for one tee time. season is copied from the lottery
-- (immutable) so the annual cap can group by it.
table entries:
  lottery: lotteries on delete cascade
  teetime: teetimes on delete cascade
  member: principal
  season: int 2000..2100
  status: enum('entered', 'won', 'waitlisted', 'cancelled') default 'entered'
  createdAt: time default now
  unique lottery, teetime, member else ALREADY_ENTERED 'You already entered for this tee time.'
  cap 500 by lottery
  cap 500 by teetime
  immutable lottery, teetime, member, season
  read <- .member = viewer or exists staff[viewer]
  insert <- .member = viewer
  update <- .member = viewer or exists staff[viewer]
  delete <- .member = viewer or exists staff[viewer]
  online only

-- Public occupancy over private entries: wins per member per season.
view seasonWins: count entries where .status = 'won' by .member, .season
  read <- allow

query lotteriesList(c: cursor ?):
  return lotteries last 50 by .id after c

query teeTimesFor(lottery: lotteries, c: cursor ?):
  return teetimes where .lottery = lottery first 50 by .startsAt after c

query myEntries(c: cursor ?):
  return entries where .member = viewer last 50 by .id after c

-- Staff see every entry for the draw; members see their own rows, complete too.
query entriesFor(lottery: lotteries, c: cursor ?):
  if exists staff[viewer]:
    return entries where .lottery = lottery last 100 by .id after c
  return entries where .lottery = lottery and .member = viewer last 100 by .id after c

-- Anyone may read published results; before that, staff only.
query resultsFor(lottery: lotteries):
  l = lotteries[lottery] ! else NOT_FOUND
  if l.status = 'published':
    return entries where .lottery = lottery and (.status = 'won' or .status = 'waitlisted') first 100 by .id
  require exists staff[viewer] else NOT_PUBLISHED 'Results are not published yet.'
  return entries where .lottery = lottery and (.status = 'won' or .status = 'waitlisted') first 100 by .id

mutation createLottery(weekLabel: text 1..40, season: int 2000..2100, drawAt: time, annualCap: int 1..20):
  require exists staff[viewer] else NOT_STAFF
  return insert lotteries { weekLabel, season, drawAt, annualCap }

mutation addTeeTime(lottery: lotteries, label: text 1..60, startsAt: time):
  l = lotteries[lottery] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  require l.status = 'open' else LOCKED 'This lottery is closed to changes.'
  return insert teetimes { lottery, label, startsAt }

mutation enterLottery(lottery: lotteries, teetime: teetimes):
  l = lotteries[lottery] ! else NOT_FOUND
  t = teetimes[teetime] ! else NOT_FOUND
  require t.lottery = lottery else WRONG_SHEET 'That tee time is not in this lottery.'
  require l.status = 'open' else NOT_OPEN 'This lottery is no longer open.'
  require t.startsAt > now else TEED_OFF 'That tee time already passed.'
  return insert entries { lottery, teetime, member: viewer, season: l.season }

-- Leave the draw before it happens. Winners use cancelWin so the waitlist moves up.
mutation withdraw(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.member = viewer else NOT_YOURS
  require e.status = 'entered' or e.status = 'waitlisted' else USE_CANCEL 'Winners cancel so the waitlist can move up.'
  delete entries[entry]

-- Deterministic draw: earliest entry per tee time wins unless already at the
-- annual cap; everyone else is waitlisted in entry order.
mutation runDraw(lottery: lotteries):
  l = lotteries[lottery] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  require l.status = 'open' else ALREADY_DRAWN 'This lottery was already drawn.'
  update lotteries[lottery] { status: 'drawn' }
  for t in teetimes where .lottery = lottery by .startsAt:
    picked = false
    for e in entries where .lottery = lottery and .teetime = t.id and .status = 'entered' by .id:
      if not picked and seasonWins[e.member, e.season] < l.annualCap:
        update entries[e.id] { status: 'won' }
        picked = true
      else:
        update entries[e.id] { status: 'waitlisted' }

mutation publishResults(lottery: lotteries):
  l = lotteries[lottery] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  require l.status = 'drawn' else NOT_DRAWN 'Draw this lottery before publishing.'
  update lotteries[lottery] { status: 'published' }

-- A winner cancels. The pro shop then calls promoteWaitlist: winners cannot walk
-- the waitlist themselves because other members' waitlisted rows are hidden.
mutation cancelWin(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'won' else NOT_WINNER 'Only a winning entry can be cancelled this way.'
  require e.member = viewer or exists staff[viewer] else NOT_YOURS
  update entries[entry] { status: 'cancelled' }

-- The earliest waitlisted entry still under the cap moves up.
mutation promoteWaitlist(teetime: teetimes):
  require exists staff[viewer] else NOT_STAFF
  t = teetimes[teetime] ! else NOT_FOUND
  l = lotteries[t.lottery] ! else NOT_FOUND
  promoted = false
  for w in entries where .lottery = t.lottery and .teetime = teetime and .status = 'waitlisted' by .id:
    if not promoted and seasonWins[w.member, w.season] < l.annualCap:
      update entries[w.id] { status: 'won' }
      promoted = true
