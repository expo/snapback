use personas dispatcher, alice, bob, eve

table dispatchers:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table technicians:
  principal: principal
  name: text 2..80
  badge: text 3..30
  unique principal
  public 'Customers can identify a technician before agreeing to work.'
  online only

table jobs:
  customer: principal
  technician: principal
  address: text 5..160
  quoteCents: int 1000..100000
  assignedAt: time default now
  verifyBy: time
  approved: bool default false
  verified: bool default false
  status: enum('assigned', 'working') default 'assigned'
  flagged: bool default false
  immutable customer, technician, address, quoteCents, assignedAt, verifyBy
  read <- .customer = viewer or .technician = viewer or exists dispatchers[viewer]
  insert <- exists dispatchers[viewer]
  update <- .customer = viewer or .technician = viewer or exists dispatchers[viewer]
  online only

table ownershipCodes:
  job: jobs
  code: text 6..6
  unique job
  immutable job, code
  read <- .job.customer = viewer or .job.technician = viewer or exists dispatchers[viewer]
  insert <- exists dispatchers[viewer]
  online only

query technicianDirectory():
  return technicians first 20 by .id

query myJobs():
  return jobs last 50 by .assignedAt { id, customer, technician, address, quoteCents, approved, verified, status, flagged, verifyBy, technicianName: technicians[principal = .technician].name, badge: technicians[principal = .technician].badge }

query customerCode(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  require j.customer = viewer else CUSTOMER_ONLY
  require j.approved else REVIEW_QUOTE_FIRST 'Review technician identity and quote first.'
  return ownershipCodes[job = job] { code }

mutation assignJob(customer: principal, technician: principal, address: text 5..160, quoteCents: int 1000..100000, code: text 6..6):
  require exists dispatchers[viewer] else DISPATCHER_ONLY
  require customer != technician else DISTINCT_PARTIES
  require exists technicians[principal = technician] else UNKNOWN_TECHNICIAN
  j = insert jobs { customer, technician, address, quoteCents, verifyBy: now + 15m }
  insert ownershipCodes { job: j.id, code }
  return { id: j.id }

mutation approveQuote(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  require j.customer = viewer else CUSTOMER_ONLY
  require j.status = 'assigned' else ALREADY_STARTED
  update jobs[job] { approved: true }
  return { id: j.id }

mutation verifyOwnership(job: jobs, code: text 6..6):
  j = jobs[job] ! else NOT_FOUND
  require j.technician = viewer else TECHNICIAN_ONLY
  require j.approved else REVIEW_QUOTE_FIRST
  require j.status = 'assigned' else ALREADY_STARTED
  secret = ownershipCodes[job = job] ! else CODE_MISSING
  require secret.code = code else WRONG_CODE 'Ownership code did not match.'
  update jobs[job] { verified: true, flagged: false }
  return { id: j.id }

mutation startWork(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  require j.technician = viewer else TECHNICIAN_ONLY
  require j.verified else VERIFICATION_REQUIRED 'Verify ownership before beginning work.'
  require j.status = 'assigned' else ALREADY_STARTED
  update jobs[job] { status: 'working' }
  return { id: j.id }

job flagUnverified(periodStart: time, periodEnd: time):
  for j in jobs where .verifyBy < periodEnd by .verifyBy:
    if not j.verified and not j.flagged:
      update jobs[j.id] { flagged: true }
schedule verificationWatch every 1m: flagUnverified
