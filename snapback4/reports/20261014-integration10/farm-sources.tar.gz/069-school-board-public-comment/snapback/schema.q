use personas alice, bob, clerk

table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table agenda:
  title: text 1..120
  cutoff: time
  active: speakers ?
  public 'Meeting agenda and the active speaker are public.'
  update <- exists staff[viewer]
  cap 50
  online only

table speakers:
  agenda: agenda
  owner: principal
  name: text 1..80
  ordinal: sequence by agenda
  status: enum('waiting', 'speaking', 'done', 'withdrawn') default 'waiting'
  registeredAt: time default now
  startedAt: time ?
  endsAt: time ?
  unique agenda, owner else ALREADY_REGISTERED
  cap 200 by agenda
  cap 50 by owner
  immutable agenda, owner, name, registeredAt
  public 'Speaker names and queue positions are public; contacts are separate.'
  insert <- .owner = viewer and .status = 'waiting'
  update <- .owner = viewer or exists staff[viewer]
  online only

table contacts:
  agenda: agenda
  speaker: speakers on delete cascade
  owner: principal
  email: text 3..160
  unique speaker
  cap 200 by agenda
  immutable agenda, speaker, owner, email
  read <- exists staff[viewer]
  insert <- .owner = viewer and created speakers[.speaker]
  online only

query listAgenda():
  return agenda first 50 by .id { id, title, cutoff, active, registrationOpen: .cutoff > now }
query queue(agenda: agenda):
  return speakers where .agenda = agenda first 200 by .ordinal { id, agenda, owner, name, ordinal, status, registeredAt, startedAt, endsAt, serverNow: now }
query myRegistrations():
  return speakers where .owner = viewer first 50 by .registeredAt
query staffContacts(agenda: agenda):
  require exists staff[viewer] else STAFF_ONLY 'Only the clerk can read speaker contacts.'
  return contacts where .agenda = agenda first 200 by .id

mutation register(agenda: agenda, name: text 1..80, email: text 3..160):
  a = agenda[agenda] ! else NOT_FOUND
  require now < a.cutoff else REGISTRATION_CLOSED 'The registration cutoff has passed.'
  s = insert speakers { agenda, owner: viewer, name }
  insert contacts { agenda, speaker: s.id, owner: viewer, email }
  return { id: s.id }
mutation withdraw(speaker: speakers):
  s = speakers[speaker] ! else NOT_FOUND
  require s.owner = viewer else NOT_YOURS
  require s.status = 'waiting' else NOT_WAITING
  update speakers[speaker] { status: 'withdrawn' }
  return null
mutation startSpeaker(speaker: speakers):
  require exists staff[viewer] else STAFF_ONLY
  s = speakers[speaker] ! else NOT_FOUND
  a = agenda[s.agenda] ! else NOT_FOUND
  require a.active = null else SPEAKER_ACTIVE
  require s.status = 'waiting' else NOT_WAITING
  update speakers[speaker] { status: 'speaking', startedAt: now, endsAt: now + 3m }
  update agenda[s.agenda] { active: speaker }
  return null
mutation finishSpeaker(speaker: speakers):
  require exists staff[viewer] else STAFF_ONLY
  s = speakers[speaker] ! else NOT_FOUND
  require s.status = 'speaking' else NOT_SPEAKING
  update speakers[speaker] { status: 'done' }
  update agenda[s.agenda] { active: null }
  return null
mutation closeRegistration(agenda: agenda):
  require exists staff[viewer] else STAFF_ONLY
  update agenda[agenda] { cutoff: now }
  return null
