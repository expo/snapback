-- Live Action Event Casting.
-- Organizers post characters (public name/blurb, secret backstory), players rank
-- preferences, casting closes by job at the deadline, each player sees only
-- their own sheet.
use personas morgan, alice, bob

-- Roster: one row per organizer. Rule probes see every roster row, so a
-- restrictive read rule is fine here.
table organizers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  cap 20
  online only

table events:
  title: text 1..80
  deadline: time
  castDone: bool default false
  organizer: principal
  immutable organizer, deadline
  public 'event listings are public so players can browse'
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  cap 100
  online only

-- Public face of a character. The secret backstory lives in `secrets`.
table characters:
  event: events
  name: text 1..80
  blurb: text <=500
  immutable event
  public 'character names and blurbs are public so players can rank them'
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  cap 200 by event
  online only

-- Secret backstory: organizers plus the assigned player only.
table secrets:
  character: characters
  body: text 1..2000
  unique character
  read <- exists organizers[viewer] or exists sheets[.character, player = viewer]
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  immutable character
  online only

-- Casting result: one row per character, holding a copy of the secret for the
-- assigned player. Each player reads only their own sheet.
table sheets:
  event: events
  character: characters
  player: principal
  secret: text 1..2000
  unique character
  read <- .player = viewer or exists organizers[viewer]
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  immutable event, character
  cap 200 by event
  cap 200 by player
  online only

table preferences:
  event: events
  player: principal
  character: characters
  rank: int 1..10
  unique event, player, character
  unique event, player, rank else DUP_RANK
  read <- .player = viewer or exists organizers[viewer]
  insert <- .player = viewer
  update <- .player = viewer
  delete <- .player = viewer
  immutable event, player, character
  cap 20 by event, player
  online only

query events(c: cursor ?):
  return events first 50 by .id after c

query charactersOf(event: events, c: cursor ?):
  return characters where .event = event first 50 by .id after c

query myPreferences(event: events):
  return preferences where .event = event and .player = viewer

query preferencesOf(event: events, c: cursor ?):
  require exists organizers[viewer] else NOT_ORGANIZER
  return preferences where .event = event first 100 by .id after c

query mySheets():
  return sheets where .player = viewer

query sheetsOf(event: events, c: cursor ?):
  require exists organizers[viewer] else NOT_ORGANIZER
  return sheets where .event = event first 100 by .id after c

query secretOf(character: characters):
  return secrets[character]

mutation createEvent(title: text 1..80, deadline: time):
  require exists organizers[viewer] else NOT_ORGANIZER
  return insert events { title, deadline, organizer: viewer }

mutation postCharacter(event: events, name: text 1..80, blurb: text <=500, secret: text 1..2000):
  require exists organizers[viewer] else NOT_ORGANIZER
  e = events[event] ! else NOT_FOUND
  c = insert characters { event: e.id, name, blurb }
  insert secrets { character: c.id, body: secret }
  return c

mutation rankCharacter(event: events, character: characters, rank: int 1..10):
  e = events[event] ! else NOT_FOUND
  require not e.castDone else CASTING_CLOSED 'Casting is closed for this event.'
  require e.deadline > now else CASTING_CLOSED 'The deadline has passed.'
  c = characters[character] ! else NOT_FOUND
  require c.event = event else WRONG_EVENT 'That character is not in this event.'
  upsert preferences[event, viewer, character] { event, player: viewer, character, rank }
  return null

mutation retractPreference(event: events, character: characters):
  e = events[event] ! else NOT_FOUND
  require not e.castDone else CASTING_CLOSED 'Casting is closed for this event.'
  delete preferences[event, viewer, character]
  return null

mutation assignSheet(character: characters, player: principal):
  require exists organizers[viewer] else NOT_ORGANIZER
  c = characters[character] ! else NOT_FOUND
  s = secrets[c.id] ! else NOT_FOUND
  upsert sheets[character = c.id] { event: c.event, character: c.id, player, secret: s.body }
  return null

-- Casting closes at the deadline: the sweep marks due events cast, which locks
-- preference writes. Assignment rows are written by the organizer's assignSheet.
job closeCasting(periodStart: time, periodEnd: time):
  for e in events where .deadline >= periodStart and .deadline < periodEnd by .deadline:
    if not e.castDone:
      update events[e.id] { castDone: true }

schedule closeEveryMinute every 1m: closeCasting
