use personas alice, bob, flora

table florists:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table orders:
  planner: principal
  title: text 1..100
  venue: text 1..160
  brief: text 1..1000
  eventAt: time
  budgetCents: int 1000..10000000
  status: enum('requested', 'proposed', 'approved') default 'requested'
  createdAt: time default now
  immutable planner, eventAt, budgetCents, createdAt
  read <- .planner = viewer or exists florists[viewer]
  insert <- .planner = viewer and not exists florists[viewer]
  update <- .planner = viewer or exists florists[viewer]
  delete <- deny
  online only

table proposals:
  order: orders
  planner: principal
  description: text 1..2000
  flower: text 1..100
  stems: int 1..10000
  quoteCents: int 1000..10000000
  unique order
  immutable order, planner
  read <- .planner = viewer or exists florists[viewer]
  insert <- exists florists[viewer]
  update <- exists florists[viewer]
  delete <- deny
  online only

table wholesale:
  proposal: proposals
  unitCostCents: int 1..100000
  supplier: text 1..160
  unique proposal
  immutable proposal
  read <- exists florists[viewer]
  insert <- exists florists[viewer]
  update <- exists florists[viewer]
  delete <- deny
  online only

table purchases:
  order: orders
  flower: text 1..100
  stems: int 1..10000
  supplier: text 1..160
  totalCostCents: int 1..1000000000
  generatedAt: time default now
  unique order
  immutable order, flower, stems, supplier, totalCostCents, generatedAt
  read <- exists florists[viewer]
  insert <- deny
  update <- deny
  delete <- deny
  online only

query myRole():
  return { florist: exists florists[viewer], principal: viewer }
query board():
  if exists florists[viewer]:
    return orders last 100 by .createdAt
  return orders where .planner = viewer last 100 by .createdAt
query proposalFor(order: orders):
  o = orders[order] ! else NOT_FOUND 'This order is unavailable.'
  return proposals[order = o.id]
query costsFor(proposal: proposals):
  require exists florists[viewer] else FLORIST_ONLY 'Wholesale costs are private to the florist.'
  return wholesale[proposal = proposal]
query purchaseList():
  require exists florists[viewer] else FLORIST_ONLY 'Purchase lists are private to the florist.'
  return purchases last 100 by .generatedAt

mutation requestOrder(title: text 1..100, venue: text 1..160, brief: text 1..1000, eventAt: time, budgetCents: int 1000..10000000):
  require not exists florists[viewer] else PLANNER_ONLY 'Pick a planner to request flowers.'
  require eventAt > now + 7d else EVENT_TOO_SOON 'Request flowers more than a week before the event.'
  return insert orders { planner: viewer, title, venue, brief, eventAt, budgetCents }

mutation draftProposal(order: orders, description: text 1..2000, flower: text 1..100, stems: int 1..10000, quoteCents: int 1000..10000000, unitCostCents: int 1..100000, supplier: text 1..160):
  require exists florists[viewer] else FLORIST_ONLY 'Only the florist can draft proposals.'
  o = orders[order] ! else NOT_FOUND
  require o.status != 'approved' else ORDER_LOCKED 'Approved orders are locked.'
  require quoteCents <= o.budgetCents else OVER_BUDGET 'The quote must fit the planner budget.'
  upsert proposals[order = order] { order, planner: o.planner, description, flower, stems, quoteCents }
  p = proposals[order = order] ! else NO_PROPOSAL
  upsert wholesale[proposal = p.id] { proposal: p.id, unitCostCents, supplier }
  update orders[order] { status: 'proposed' }
  return p

mutation approveProposal(order: orders):
  o = orders[order] ! else NOT_FOUND 'This order is unavailable.'
  require o.planner = viewer else PLANNER_ONLY 'Only this order planner can approve.'
  require o.status = 'proposed' else NO_PROPOSAL 'Only a proposed order can be approved.'
  p = proposals[order = order] ! else NO_PROPOSAL
  require p.quoteCents <= o.budgetCents else OVER_BUDGET
  update orders[order] { status: 'approved' }
  return null

job generatePurchases(periodStart: time, periodEnd: time):
  for o in orders where .eventAt <= periodEnd + 7d by .eventAt:
    if o.status = 'approved' and not exists purchases[order = o.id]:
      p = proposals[order = o.id] ! else NO_PROPOSAL
      w = wholesale[proposal = p.id] ! else NO_WHOLESALE
      insert purchases { order: o.id, flower: p.flower, stems: p.stems, supplier: w.supplier, totalCostCents: p.stems * w.unitCostCents }
schedule purchasing every 1h: generatePurchases
