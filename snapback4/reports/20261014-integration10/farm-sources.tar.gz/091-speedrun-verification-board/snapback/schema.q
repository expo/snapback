use personas alice, bob, carol, dave

table games:
  title: text 1..80
  public 'Games are discoverable by all runners.'
  online only

table verifiers:
  game: games
  principal: principal
  unique game, principal
  read <- .principal = viewer
  online only

table moderators:
  game: games
  principal: principal
  unique game, principal
  read <- .principal = viewer
  online only

table runs:
  game: games
  runner: principal
  category: enum('Any%', '100%')
  timeMs: int 1..86400000
  video: text 10..500 format url
  submittedAt: time default now
  status: enum('pending', 'approved', 'rejected', 'disputed') default 'pending'
  reviewer: principal ?
  decisionNote: text <=1000 ?
  disputeNote: text <=1000 ?
  immutable game, runner, category, timeMs, video, submittedAt
  read <- .status = 'approved' or .runner = viewer or exists verifiers[.game, viewer] or (.status = 'disputed' and exists moderators[.game, viewer])
  insert <- .runner = viewer and .status = 'pending'
  update <- .runner = viewer or exists verifiers[.game, viewer] or exists moderators[.game, viewer]
  online only

table records:
  game: games
  runner: principal
  category: enum('Any%', '100%')
  timeMs: int 1..86400000
  run: runs
  unique game, runner, category
  immutable game, runner, category
  public 'Approved personal bests make up the leaderboard.'
  insert <- exists verifiers[.game, viewer] or exists moderators[.game, viewer]
  update <- exists verifiers[.game, viewer] or exists moderators[.game, viewer]
  online only

query gameList(c: cursor ?):
  return games first 50 by .title after c

query myRoles(game: games):
  return { verifier: exists verifiers[game, viewer], moderator: exists moderators[game, viewer] }

query myRuns(game: games, c: cursor ?):
  return runs where .game = game and .runner = viewer last 50 by .submittedAt after c

query reviewQueue(game: games, c: cursor ?):
  require exists verifiers[game, viewer] else NOT_VERIFIER 'Only game verifiers can review pending runs.'
  return runs where .game = game and .status = 'pending' first 50 by .submittedAt after c

query disputes(game: games, c: cursor ?):
  require exists moderators[game, viewer] else NOT_MODERATOR 'Only game moderators can resolve disputes.'
  return runs where .game = game and .status = 'disputed' first 50 by .submittedAt after c

query leaderboard(game: games, category: enum('Any%', '100%'), c: cursor ?):
  return records where .game = game and .category = category first 50 by .timeMs after c

query runDetail(run: runs):
  return runs[run]

mutation submitRun(game: games, category: enum('Any%', '100%'), timeMs: int 1..86400000, video: text 10..500 format url):
  g = games[game] ! else NOT_FOUND
  return insert runs { game: g.id, runner: viewer, category, timeMs, video }

mutation approveRun(run: runs, note: text 1..1000):
  r = runs[run] ! else NOT_FOUND
  require exists verifiers[r.game, viewer] else NOT_VERIFIER
  require r.runner != viewer else SELF_REVIEW 'You cannot verify your own run.'
  require r.status = 'pending' else NOT_PENDING
  update runs[run] { status: 'approved', reviewer: viewer, decisionNote: note }
  best = records[r.game, r.runner, r.category]
  if best = null or r.timeMs < best.timeMs:
    upsert records[r.game, r.runner, r.category] { game: r.game, runner: r.runner, category: r.category, timeMs: r.timeMs, run: r.id }
  return null

mutation rejectRun(run: runs, note: text 1..1000):
  r = runs[run] ! else NOT_FOUND
  require exists verifiers[r.game, viewer] else NOT_VERIFIER
  require r.runner != viewer else SELF_REVIEW
  require r.status = 'pending' else NOT_PENDING
  update runs[run] { status: 'rejected', reviewer: viewer, decisionNote: note }
  return null

mutation disputeRun(run: runs, note: text 1..1000):
  r = runs[run] ! else NOT_FOUND
  require r.runner = viewer else NOT_RUNNER
  require r.status = 'rejected' else NOT_REJECTED
  update runs[run] { status: 'disputed', disputeNote: note }
  return null

mutation resolveDispute(run: runs, approve: bool, note: text 1..1000):
  r = runs[run] ! else NOT_FOUND
  require exists moderators[r.game, viewer] else NOT_MODERATOR
  require r.runner != viewer else SELF_REVIEW
  require r.status = 'disputed' else NOT_DISPUTED
  update runs[run] { status: 'approved' if approve else 'rejected', reviewer: viewer, decisionNote: note }
  if approve:
    best = records[r.game, r.runner, r.category]
    if best = null or r.timeMs < best.timeMs:
      upsert records[r.game, r.runner, r.category] { game: r.game, runner: r.runner, category: r.category, timeMs: r.timeMs, run: r.id }
  return null
