-- Trading Card Escrow: collectors propose trades; a neutral escrow officer
-- confirms receipt of each side, appraises privately, and releases the swap.
-- A scheduled job flags trades stalled in `proposed` for over 7 days.
use personas alice, bob, carol

table escrowAgents:
  principal: principal
  unique principal
  read <- .principal = viewer or exists escrowAgents[viewer]
  insert <- exists escrowAgents[viewer] or viewer = 'service:ops'
  update <- exists escrowAgents[viewer]
  delete <- exists escrowAgents[viewer]
  online only

table cards:
  owner: principal
  name: text 1..80
  setName: text 1..80
  condition: enum('mint', 'near-mint', 'good', 'poor')
  public 'collectors browse each others listings to propose trades'
  insert <- .owner = viewer
  update (old, next) <- old.owner = viewer or exists escrowAgents[viewer]
  delete <- .owner = viewer
  cap 500 by owner
  online only

table trades:
  proposer: principal
  counterparty: principal
  offerCard: cards
  requestCard: cards
  status: enum('proposed', 'accepted', 'escrow', 'released', 'cancelled', 'stalled') default 'proposed'
  createdAt: time default now
  immutable proposer, counterparty, offerCard, requestCard, createdAt
  read <- .proposer = viewer or .counterparty = viewer or exists escrowAgents[viewer]
  insert <- .proposer = viewer
  update <- .proposer = viewer or .counterparty = viewer or exists escrowAgents[viewer]
  delete <- .proposer = viewer
  cap 1000
  online only

table receipts:
  trade: trades
  side: enum('offer', 'request')
  received: bool default false
  unique trade, side
  immutable trade, side
  read <- exists trades[.trade, proposer = viewer] or exists trades[.trade, counterparty = viewer] or exists escrowAgents[viewer]
  insert <- exists escrowAgents[viewer]
  update <- exists escrowAgents[viewer]
  online only

table appraisals:
  trade: trades
  appraiser: principal
  valueCents: int 0..100000000
  unique trade
  immutable trade, appraiser
  read <- exists escrowAgents[viewer]
  insert <- .appraiser = viewer and exists escrowAgents[viewer]
  update <- .appraiser = viewer and exists escrowAgents[viewer]
  online only

query myCards():
  return cards where .owner = viewer

query allCards(c: cursor ?):
  return cards first 50 by .id after c

query myTrades(c: cursor ?):
  return trades where .proposer = viewer or .counterparty = viewer first 50 by .id after c

query tradeDetail(trade: trades):
  return trades[trade]

query receiptsFor(trade: trades):
  return receipts where .trade = trade

query appraisalFor(trade: trades):
  return appraisals where .trade = trade

query escrowQueue(c: cursor ?):
  require exists escrowAgents[viewer] else NOT_AGENT
  return trades where .status = 'accepted' or .status = 'escrow' first 50 by .id after c

query stalledTrades(c: cursor ?):
  if exists escrowAgents[viewer]:
    return trades where .status = 'stalled' first 50 by .id after c
  return trades where .status = 'stalled' and (.proposer = viewer or .counterparty = viewer) first 50 by .id after c

mutation grantAgent(who: principal):
  require exists escrowAgents[viewer] or viewer = 'service:ops' else NOT_AGENT 'Only an escrow officer may name another.'
  return upsert escrowAgents[who] { principal: who }

mutation addCard(name: text 1..80, setName: text 1..80, condition: enum('mint', 'near-mint', 'good', 'poor')):
  return insert cards { owner: viewer, name, setName, condition }

mutation proposeTrade(counterparty: principal, offerCard: cards, requestCard: cards):
  require counterparty != viewer else SELF_TRADE 'You cannot trade with yourself.'
  o = cards[offerCard] ! else NOT_FOUND
  require o.owner = viewer else NOT_YOUR_CARD 'The offered card is not yours.'
  r = cards[requestCard] ! else NOT_FOUND
  require r.owner = counterparty else NOT_THEIRS 'The requested card belongs to someone else.'
  return insert trades { proposer: viewer, counterparty, offerCard, requestCard }

mutation acceptTrade(trade: trades, accept: bool):
  t = trades[trade] ! else NOT_FOUND
  require t.counterparty = viewer else NOT_COUNTERPARTY 'Only the counterparty can answer.'
  require t.status = 'proposed' else BAD_STATE 'This trade is no longer proposed.'
  update trades[trade] { status: 'accepted' if accept else 'cancelled' }
  return null

mutation confirmReceipt(trade: trades, side: enum('offer', 'request')):
  require exists escrowAgents[viewer] else NOT_AGENT 'Only an escrow officer confirms receipt.'
  t = trades[trade] ! else NOT_FOUND
  require t.status = 'accepted' or t.status = 'escrow' else BAD_STATE 'Receipts are confirmed while the trade is in escrow.'
  upsert receipts[trade, side] { trade, side, received: true }
  if exists receipts[trade = trade, side = 'offer', received = true] and exists receipts[trade = trade, side = 'request', received = true]:
    update trades[trade] { status: 'escrow' }
  return null

mutation releaseTrade(trade: trades):
  require exists escrowAgents[viewer] else NOT_AGENT 'Only an escrow officer releases trades.'
  t = trades[trade] ! else NOT_FOUND
  require t.status = 'escrow' else BAD_STATE 'Both sides must be received before release.'
  require exists receipts[trade = trade, side = 'offer', received = true] else NOT_RECEIVED 'Offer side not received.'
  require exists receipts[trade = trade, side = 'request', received = true] else NOT_RECEIVED 'Request side not received.'
  update cards[t.offerCard] { owner: t.counterparty }
  update cards[t.requestCard] { owner: t.proposer }
  update trades[trade] { status: 'released' }
  return null

mutation cancelTrade(trade: trades):
  t = trades[trade] ! else NOT_FOUND
  require t.proposer = viewer or exists escrowAgents[viewer] else NOT_PARTY 'Only the proposer or escrow may cancel.'
  require t.status = 'proposed' or t.status = 'accepted' else BAD_STATE 'This trade can no longer be cancelled.'
  update trades[trade] { status: 'cancelled' }
  return null

mutation appraise(trade: trades, valueCents: int 0..100000000):
  require exists escrowAgents[viewer] else NOT_AGENT 'Only an escrow officer appraises.'
  t = trades[trade] ! else NOT_FOUND
  upsert appraisals[trade] { trade, appraiser: viewer, valueCents }
  return null

job flagStalled():
  for t in trades by .id:
    if t.status = 'proposed' and t.createdAt < now - 7d:
      update trades[t.id] { status: 'stalled' }

schedule flagStalledDaily every 1d at 08:00: flagStalled
