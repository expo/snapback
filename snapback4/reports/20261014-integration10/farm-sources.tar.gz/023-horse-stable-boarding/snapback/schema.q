-- Stable Boarding Manager: development personas, server-authoritative care and billing.
use personas alice, bob, manager, groom

table staff:
  principal: principal
  role: enum('manager', 'groom')
  unique principal
  immutable principal, role
  read <- .principal = viewer
  online only

table horses:
  name: text 1..60
  owner: principal
  stall: text 1..20
  feedPlan: text 1..1000
  monthlyFeeCents: int 100..1000000
  immutable owner
  read <- .owner = viewer or exists staff[viewer]
  insert <- exists staff[viewer, role = 'manager']
  update <- exists staff[viewer, role = 'manager']
  online only

table farrierVisits:
  horse: horses
  visitedAt: time
  nextDueAt: time
  notes: text 1..500
  immutable horse, visitedAt, nextDueAt, notes
  read through .horse
  insert <- exists staff[viewer, role = 'manager']
  online only

table tasks:
  horse: horses
  dayNumber: int 0..100000
  label: text 1..120
  done: bool default false
  completedBy: principal ?
  completedAt: time ?
  immutable horse, dayNumber, label
  read through .horse
  insert <- exists staff[viewer, role = 'manager']
  update <- exists staff[viewer]
  online only

table invoices:
  horse: horses
  year: int 2020..2100
  month: int 1..12
  amountCents: int 100..1000000
  paid: bool default false
  unique horse, year, month else INVOICE_EXISTS
  immutable horse, year, month, amountCents
  read <- .horse.owner = viewer or exists staff[viewer, role = 'manager']
  insert <- exists staff[viewer, role = 'manager']
  update <- exists staff[viewer, role = 'manager']
  online only

query myRole():
  return staff[viewer]
query listHorses(c: cursor ?):
  if exists staff[viewer]:
    return horses first 100 by .id after c
  return horses where .owner = viewer first 100 by .id after c
query farrierFor(horse: horses, c: cursor ?):
  return farrierVisits where .horse = horse last 50 by .visitedAt after c
query tasksFor(horse: horses, dayNumber: int 0..100000, c: cursor ?):
  return tasks where .horse = horse and .dayNumber = dayNumber first 100 by .id after c
query invoicesFor(horse: horses, c: cursor ?):
  return invoices where .horse = horse last 36 by .year, .month after c

mutation addHorse(name: text 1..60, owner: principal, stall: text 1..20, feedPlan: text 1..1000, monthlyFeeCents: int 100..1000000):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only a manager can add horses.'
  return insert horses { name, owner, stall, feedPlan, monthlyFeeCents }
mutation setFeedPlan(horse: horses, feedPlan: text 1..1000):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only a manager can change feed plans.'
  update horses[horse] { feedPlan }
mutation recordFarrier(horse: horses, visitedAt: time, nextDueAt: time, notes: text 1..500):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only a manager can record farrier visits.'
  require nextDueAt > visitedAt else INVALID_DUE_DATE 'Next visit must follow this visit.'
  return insert farrierVisits { horse, visitedAt, nextDueAt, notes }
mutation createTask(horse: horses, dayNumber: int 0..100000, label: text 1..120):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only a manager can assign care tasks.'
  return insert tasks { horse, dayNumber, label, completedBy: null, completedAt: null }
mutation completeTask(task: tasks):
  require exists staff[viewer] else STAFF_ONLY 'Only stable staff can complete care tasks.'
  t = tasks[task] ! else NOT_FOUND
  require not t.done else ALREADY_DONE 'This task is already complete.'
  update tasks[task] { done: true, completedBy: viewer, completedAt: now }
mutation issueInvoice(horse: horses, year: int 2020..2100, month: int 1..12):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only a manager can issue invoices.'
  h = horses[horse] ! else NOT_FOUND
  return insert invoices { horse, year, month, amountCents: h.monthlyFeeCents }
mutation markPaid(invoice: invoices):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only a manager can record payments.'
  update invoices[invoice] { paid: true }
