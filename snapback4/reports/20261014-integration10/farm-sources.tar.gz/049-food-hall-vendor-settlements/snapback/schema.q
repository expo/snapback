use personas alice, bob, manager

table managers:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table vendors:
  owner: principal
  name: text 1..80
  weeklyRentCents: int 0..1000000
  feeBps: int 0..10000
  unique owner
  immutable owner
  cap 50
  read <- .owner = viewer or exists managers[viewer]
  online only

table sales:
  vendor: vendors
  grossCents: int 1..10000000
  tipsCents: int 0..1000000
  at: time
  note: text 1..120
  immutable vendor, grossCents, tipsCents, at, note
  read <- exists managers[viewer]
  insert <- exists managers[viewer]
  online only

table statements:
  vendor: vendors
  owner: principal
  periodStart: time
  periodEnd: time
  grossCents: int 0..
  rentCents: int 0..
  feesCents: int 0..
  tipsCents: int 0..
  adjustmentCents: int default 0
  status: enum('draft', 'final') default 'draft'
  unique vendor, periodStart
  immutable vendor, owner, periodStart, periodEnd, grossCents, rentCents, feesCents, tipsCents
  read <- .owner = viewer or exists managers[viewer]
  insert <- deny
  update <- exists managers[viewer]
  online only

table disputes:
  statement: statements
  owner: principal
  line: enum('sales', 'rent', 'fees', 'tips')
  reason: text 5..500
  status: enum('open', 'resolved') default 'open'
  response: text <=500 ?
  adjustmentCents: int default 0
  at: time default now
  unique statement, line
  immutable statement, owner, line, reason, at
  read <- .owner = viewer or exists managers[viewer]
  insert <- .owner = viewer and exists statements[id = .statement, owner = viewer, status = 'draft']
  update <- exists managers[viewer]
  online only

query vendorDirectory():
  if exists managers[viewer]:
    return vendors first 50 by .id
  return vendors where .owner = viewer first 1 by .id

query settlementList(c: cursor ?):
  if exists managers[viewer]:
    return statements last 20 by .periodStart, .id after c
  return statements where .owner = viewer last 20 by .periodStart, .id after c

query statementDetail(statement: statements):
  s = statements[statement] ! else STATEMENT_PRIVATE 'This statement is unavailable to you.'
  return { statement: s, netCents: s.grossCents + s.tipsCents - s.rentCents - s.feesCents + s.adjustmentCents }

query statementDisputes(statement: statements):
  s = statements[statement] ! else STATEMENT_PRIVATE
  if exists managers[viewer]:
    return disputes where .statement = s.id first 4 by .id
  return disputes where .owner = viewer and .statement = s.id first 4 by .id

query registerSales(c: cursor ?):
  require exists managers[viewer] else MANAGER_ONLY
  return sales last 20 by .at, .id after c

mutation recordSale(vendor: vendors, grossCents: int 1..10000000, tipsCents: int 0..1000000, at: time, note: text 1..120):
  require exists managers[viewer] else MANAGER_ONLY
  v = vendors[vendor] ! else VENDOR_NOT_FOUND
  require not exists statements where .vendor = v.id and .periodStart <= at and .periodEnd > at else WEEK_CLOSED 'This week has already been tallied.'
  return insert sales { vendor: v.id, grossCents, tipsCents, at, note }

mutation disputeLine(statement: statements, line: enum('sales', 'rent', 'fees', 'tips'), reason: text 5..500):
  s = statements[statement] ! else STATEMENT_PRIVATE
  require s.owner = viewer else VENDOR_ONLY
  require s.status = 'draft' else FINALIZED 'Final statements cannot be disputed.'
  return insert disputes { statement: s.id, owner: viewer, line, reason }

mutation resolveDispute(dispute: disputes, response: text 5..500, adjustmentCents: int -1000000..1000000):
  require exists managers[viewer] else MANAGER_ONLY
  d = disputes[dispute] ! else NOT_FOUND
  s = statements[d.statement] ! else NOT_FOUND
  require s.status = 'draft' else FINALIZED
  require d.status = 'open' else ALREADY_RESOLVED
  update disputes[d.id] { status: 'resolved', response, adjustmentCents }
  update statements[s.id] { adjustmentCents: s.adjustmentCents + adjustmentCents }
  return null

mutation finalizeStatement(statement: statements):
  require exists managers[viewer] else MANAGER_ONLY
  s = statements[statement] ! else NOT_FOUND
  require s.status = 'draft' else FINALIZED
  require count(disputes where .statement = s.id and .status = 'open') = 0 else OPEN_DISPUTES 'Resolve all disputes before finalizing.'
  update statements[s.id] { status: 'final' }
  return null

job weeklySettlements(periodStart: time, periodEnd: time):
  require periodEnd - periodStart = 7d else BAD_WEEK
  for v in vendors:
    if not exists statements[v.id, periodStart]:
      gross = sum(sales where .vendor = v.id and .at >= periodStart and .at < periodEnd, .grossCents)
      tips = sum(sales where .vendor = v.id and .at >= periodStart and .at < periodEnd, .tipsCents)
      insert statements { vendor: v.id, owner: v.owner, periodStart, periodEnd, grossCents: gross, tipsCents: tips, rentCents: v.weeklyRentCents, feesCents: gross * v.feeBps / 10000 }
schedule weekly every 7d at 03:00: weeklySettlements
