-- Pickup Authorization Desk.
-- Guardians register children and authorize pickup adults (photo + ID notes).
-- A second guardian (or office staff) must approve before an adult is valid.
-- The front office reads the approved list only on the child's dismissal day.
-- Every change appends to an append-only audit log.
use personas alice, bob, carol

-- Front-office roster. Bootstrapped via fixtures/seed (written as the system).
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- exists staff[viewer] or viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

table children:
  name: text 1..80
  dismissalDate: time default now
  read <- exists guardians[child = .id, guardian = viewer] or exists staff[viewer]
  insert <- allow
  update <- deny
  delete <- deny
  cap 500
  online only

-- Which guardians speak for a child. First row is written by registerChild
-- (admitted via `created children[.child]`); later rows by fellow guardians.
table guardians:
  child: children on delete cascade
  guardian: principal
  unique child, guardian
  immutable child, guardian
  read <- .guardian = viewer or exists guardians[child = .child, guardian = viewer] or exists staff[viewer]
  insert <- created children[.child] or exists guardians[child = .child, guardian = viewer]
  update <- deny
  delete <- deny
  cap 10 by child
  online only

-- An authorized pickup adult. Starts pending; a *different* guardian (or
-- office staff) approves. Edits reset to pending so changes re-require approval.
table authorizedAdults:
  child: children on delete cascade
  name: text 1..80
  photo: image <=5000000 ?
  idNotes: text <=500 ?
  status: enum('pending', 'approved', 'revoked') default 'pending'
  addedBy: principal
  approvedBy: principal ?
  immutable child, addedBy
  read <- exists guardians[child = .child, guardian = viewer] or exists staff[viewer]
  insert <- exists guardians[child = .child, guardian = viewer]
  update <- exists guardians[child = .child, guardian = viewer] or exists staff[viewer]
  delete <- deny
  cap 50 by child
  online only

-- Append-only audit trail: no updates, no deletes.
table auditLog:
  child: children on delete cascade
  actor: principal
  action: enum('child_registered', 'guardian_added', 'adult_added', 'adult_approved', 'adult_edited', 'adult_revoked', 'staff_granted')
  detail: text <=500 ?
  at: time default now
  immutable child, actor, action, detail, at
  read <- exists guardians[child = .child, guardian = viewer] or exists staff[viewer]
  insert <- created children[.child] or exists guardians[child = .child, guardian = viewer] or exists staff[viewer]
  update <- deny
  delete <- deny
  cap 1000 by child
  online only

-- Every child the caller guards (staff: every child).
query myChildren(c: cursor ?):
  if exists staff[viewer]:
    return children last 50 by .id after c
  return children where exists guardians[child = .id, guardian = viewer] last 50 by .id after c

query approvedFor(child: children, c: cursor ?):
  c0 = children[child] ! else NOT_FOUND
  require exists guardians[child = child, guardian = viewer] or exists staff[viewer] else NOT_GUARDIAN
  return authorizedAdults where .child = child and .status = 'approved' first 50 by .id after c

query pendingFor(child: children, c: cursor ?):
  c0 = children[child] ! else NOT_FOUND
  require exists guardians[child = child, guardian = viewer] or exists staff[viewer] else NOT_GUARDIAN
  return authorizedAdults where .child = child and .status = 'pending' first 50 by .id after c

-- Front-office dismissal-day list: approved adults, visible to staff only,
-- and only on the child's dismissal day.
query dismissalList(child: children, c: cursor ?):
  c0 = children[child] ! else NOT_FOUND
  require day(now) = day(c0.dismissalDate) else NOT_DISMISSAL_DAY
  require exists staff[viewer] else NOT_STAFF
  return authorizedAdults where .child = child and .status = 'approved' first 50 by .id after c

query auditTrail(child: children, c: cursor ?):
  c0 = children[child] ! else NOT_FOUND
  require exists guardians[child = child, guardian = viewer] or exists staff[viewer] else NOT_GUARDIAN
  return auditLog where .child = child last 50 by .at after c

mutation registerChild(name: text 1..80, dismissalDate: time ?):
  c = insert children { name, dismissalDate: dismissalDate ?? now }
  insert guardians { child: c.id, guardian: viewer }
  insert auditLog { child: c.id, actor: viewer, action: 'child_registered', detail: name }
  return c.id

mutation addGuardian(child: children, who: principal):
  c0 = children[child] ! else NOT_FOUND
  require exists guardians[child = child, guardian = viewer] else NOT_GUARDIAN
  insert guardians { child, guardian: who }
  insert auditLog { child, actor: viewer, action: 'guardian_added' }
  return null

mutation addAdult(child: children, name: text 1..80, photo: image <=5000000 ?, idNotes: text <=500 ?):
  c0 = children[child] ! else NOT_FOUND
  require exists guardians[child = child, guardian = viewer] else NOT_GUARDIAN
  a = insert authorizedAdults { child, name, photo, idNotes, addedBy: viewer }
  insert auditLog { child, actor: viewer, action: 'adult_added', detail: name }
  return a.id

mutation approveAdult(adult: authorizedAdults):
  a = authorizedAdults[adult] ! else NOT_FOUND
  require exists guardians[child = a.child, guardian = viewer] or exists staff[viewer] else NOT_GUARDIAN
  require viewer != a.addedBy or exists staff[viewer] else NEED_SECOND_GUARDIAN
  require a.status = 'pending' else ALREADY_DECIDED
  update authorizedAdults[adult] { status: 'approved', approvedBy: viewer }
  insert auditLog { child: a.child, actor: viewer, action: 'adult_approved', detail: a.name }
  return null

mutation editAdult(adult: authorizedAdults, name: text 1..80 ?, photo: image <=5000000 ?, idNotes: text <=500 ?):
  a = authorizedAdults[adult] ! else NOT_FOUND
  require exists guardians[child = a.child, guardian = viewer] else NOT_GUARDIAN
  update authorizedAdults[adult] { name: name ?? a.name, photo: photo ?? a.photo, idNotes: idNotes ?? a.idNotes, status: 'pending', approvedBy: null }
  insert auditLog { child: a.child, actor: viewer, action: 'adult_edited', detail: a.name }
  return null

mutation revokeAdult(adult: authorizedAdults):
  a = authorizedAdults[adult] ! else NOT_FOUND
  require exists guardians[child = a.child, guardian = viewer] or exists staff[viewer] else NOT_GUARDIAN
  require viewer != a.addedBy or exists staff[viewer] else NEED_SECOND_GUARDIAN
  require a.status != 'revoked' else ALREADY_DECIDED
  update authorizedAdults[adult] { status: 'revoked' }
  insert auditLog { child: a.child, actor: viewer, action: 'adult_revoked', detail: a.name }
  return null

mutation addStaff(who: principal):
  require exists staff[viewer] or viewer = 'service:ops' else NOT_STAFF
  insert staff { principal: who }
  return null
