use personas alice, bob, clara

-- Roster is provisioned by the fund administrator, not by clients.
table members:
  principal: principal
  role: enum('applicant', 'reviewer', 'manager')
  unique principal
  read <- .principal = viewer
  online only

table pools:
  quarter: int 1..
  label: text 1..80
  balance: int 0..100000000
  closesAt: time
  phase: enum('accepting', 'review', 'closed') default 'accepting'
  unique quarter
  immutable quarter
  read <- allow
  insert <- exists members[viewer, role = 'manager']
  update <- exists members[viewer, role = 'manager']
  online only

-- This table deliberately contains no owner or branch identifier.
table briefs:
  pool: pools
  title: text 3..120
  purpose: text 20..2000
  requested: int 100..500000
  at: time default now
  immutable pool, title, purpose, requested, at
  read <- allow
  insert <- exists members[viewer, role = 'applicant']
  online only

table applications:
  brief: briefs
  owner: principal
  branch: text 3..100
  status: enum('submitted', 'awarded') default 'submitted'
  unique brief
  immutable brief, owner, branch
  read <- .owner = viewer or exists members[viewer, role = 'manager']
  insert <- .owner = viewer and exists members[viewer, role = 'applicant']
  update <- exists members[viewer, role = 'manager']
  online only

table scores:
  brief: briefs
  reviewer: principal
  value: int 1..5
  note: text 1..500
  unique brief, reviewer
  immutable brief, reviewer
  read <- .reviewer = viewer or exists members[viewer, role = 'manager']
  insert <- .reviewer = viewer and exists members[viewer, role = 'reviewer']
  update <- .reviewer = viewer and exists members[viewer, role = 'reviewer']
  online only

table awards:
  application: applications
  owner: principal
  pool: pools
  amount: int 100..500000
  at: time default now
  unique application
  immutable application, owner, pool, amount, at
  read <- .owner = viewer or exists members[viewer, role = 'manager']
  insert <- exists members[viewer, role = 'manager']
  online only

query myRole():
  return members[principal = viewer]
query poolList(c: cursor ?):
  return pools last 20 by .quarter after c
query myApplications(c: cursor ?):
  return applications where .owner = viewer last 100 by .id after c
query briefDetail(brief: briefs):
  return briefs[brief]
query panelBriefs(pool: pools, c: cursor ?):
  require exists members[viewer, role = 'reviewer'] or exists members[viewer, role = 'manager'] else PANEL_ONLY
  return briefs where .pool = pool first 100 by .id after c
query myScores(c: cursor ?):
  return scores where .reviewer = viewer first 100 by .id after c
query managerApplications(c: cursor ?):
  require exists members[viewer, role = 'manager'] else MANAGER_ONLY
  return applications last 100 by .id after c
query reviewScores(brief: briefs, c: cursor ?):
  require exists members[viewer, role = 'manager'] else MANAGER_ONLY
  return scores where .brief = brief first 100 by .id after c
query myAwards(c: cursor ?):
  return awards where .owner = viewer last 100 by .id after c

mutation createPool(quarter: int 1.., label: text 1..80, balance: int 0..100000000, closesAt: time):
  require exists members[viewer, role = 'manager'] else MANAGER_ONLY
  require closesAt > now else FUTURE_DEADLINE
  return insert pools { quarter, label, balance, closesAt }
mutation submitApplication(pool: pools, branch: text 3..100, title: text 3..120, purpose: text 20..2000, requested: int 100..500000):
  require exists members[viewer, role = 'applicant'] else APPLICANT_ONLY
  p = pools[pool] ! else NOT_FOUND
  require p.phase = 'accepting' and p.closesAt > now else ROUND_CLOSED
  b = insert briefs { pool, title, purpose, requested }
  return insert applications { brief: b.id, owner: viewer, branch }
mutation beginReview(pool: pools):
  require exists members[viewer, role = 'manager'] else MANAGER_ONLY
  p = pools[pool] ! else NOT_FOUND
  require p.phase = 'accepting' and p.closesAt > now else ROUND_CLOSED
  return update pools[pool] { phase: 'review' }
mutation scoreBrief(brief: briefs, value: int 1..5, note: text 1..500):
  require exists members[viewer, role = 'reviewer'] else REVIEWER_ONLY
  b = briefs[brief] ! else NOT_FOUND
  p = pools[b.pool] ! else NOT_FOUND
  require p.phase = 'review' and p.closesAt > now else ROUND_CLOSED
  return upsert scores[brief, viewer] { brief, reviewer: viewer, value, note }
mutation awardGrant(application: applications, amount: int 100..500000):
  require exists members[viewer, role = 'manager'] else MANAGER_ONLY
  a = applications[application] ! else NOT_FOUND
  b = briefs[a.brief] ! else NOT_FOUND
  p = pools[b.pool] ! else NOT_FOUND
  require p.phase = 'review' and p.closesAt > now else ROUND_CLOSED
  require a.status = 'submitted' else ALREADY_AWARDED
  require count(scores where .brief = b.id) > 0 else SCORE_REQUIRED
  require amount <= b.requested else ABOVE_REQUEST
  require amount <= p.balance else INSUFFICIENT_FUNDS
  update pools[p.id] { balance: p.balance - amount }
  update applications[a.id] { status: 'awarded' }
  return insert awards { application, owner: a.owner, pool: p.id, amount }

-- System job transfers once: a closed source no longer participates.
job rollover():
  for p in pools where .phase != 'closed' and .closesAt <= now:
    nextQuarter = p.quarter + 1
    target = pools[quarter = nextQuarter]
    if target = null:
      insert pools { quarter: nextQuarter, label: 'Next quarterly pool', balance: p.balance, closesAt: now + 90d }
    else:
      update pools[target.id] { balance: target.balance + p.balance }
    update pools[p.id] { balance: 0, phase: 'closed' }
schedule quarterlySweep every 1d at 00:00: rollover
