use personas alice, bob, cara

-- Training roster is provisioned administratively, never by a contributor.
table reviewers:
  principal: principal
  name: text 1..60
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table recordings:
  owner: principal
  title: text 1..100
  notes: text <=500
  audio: file <=10000000 ('audio/wav', 'audio/mpeg', 'audio/flac')
  latitudeCell: int -89950000..89950000
  longitudeCell: int -179950000..179950000
  uploadedAt: time default now
  uploadDay: int
  acceptedSpecies: enum('Blackbird', 'Robin', 'Great tit', 'Chaffinch') ?
  immutable owner, title, notes, audio, latitudeCell, longitudeCell, uploadedAt, uploadDay
  read <- .owner = viewer or exists reviewers[viewer] or .acceptedSpecies != null
  insert <- .owner = viewer and .acceptedSpecies = null
  update <- exists reviewers[viewer]
  delete <- deny
  cap 5 by owner, uploadDay
  online only

table locations:
  recording: recordings
  owner: principal
  latitude: int -89999999..89999999
  longitude: int -179999999..179999999
  unique recording
  immutable recording, owner, latitude, longitude
  read <- .owner = viewer
  insert <- .owner = viewer and .recording.owner = viewer
  update <- deny
  delete <- deny
  online only

table votes:
  recording: recordings
  reviewer: principal
  species: enum('Blackbird', 'Robin', 'Great tit', 'Chaffinch')
  votedAt: time default now
  unique recording, reviewer else ALREADY_VOTED 'You already reviewed this recording.'
  immutable recording, reviewer, species, votedAt
  read <- exists reviewers[viewer] or .recording.owner = viewer
  insert <- .reviewer = viewer and exists reviewers[viewer] and .recording.owner != viewer
  update <- deny
  delete <- deny
  online only

view dailyUploads: count recordings by .owner, .uploadDay
  read <- .owner = viewer
  online only
view agreement: count votes by .recording, .species
  read <- exists reviewers[viewer]
  online only

query myRecordings():
  return recordings where .owner = viewer last 50 by .uploadedAt
query publicArchive():
  return recordings where .acceptedSpecies != null last 50 by .uploadedAt { id, title, notes, audio, latitudeCell, longitudeCell, acceptedSpecies, uploadedAt }
query reviewQueue():
  require exists reviewers[viewer] else NOT_REVIEWER 'Only trained reviewers can open the queue.'
  return recordings where .acceptedSpecies = null last 50 by .uploadedAt
query recordingDetail(recording: recordings):
  return recordings[recording]
query myLocation(recording: recordings):
  return locations[recording = recording]
query recordingVotes(recording: recordings):
  return votes where .recording = recording first 20 by .votedAt
query dashboard():
  return { principal: viewer, trainedReviewer: exists reviewers[viewer], uploadsToday: (dailyUploads[viewer, day(now)] ?? 0), dailyLimit: 5 }

mutation uploadRecording(title: text 1..100, notes: text <=500, audio: file <=10000000 ('audio/wav', 'audio/mpeg', 'audio/flac'), latitude: int -89999999..89999999, longitude: int -179999999..179999999):
  require (dailyUploads[viewer, day(now)] ?? 0) < 5 else DAILY_QUOTA 'Daily limit reached. You can upload five recordings per UTC day.'
  r = insert recordings { owner: viewer, title, notes, audio, latitudeCell: latitude / 100000 * 100000 + 50000, longitudeCell: longitude / 100000 * 100000 + 50000, uploadDay: day(now) }
  insert locations { recording: r.id, owner: viewer, latitude, longitude }
  return r

mutation voteSpecies(recording: recordings, species: enum('Blackbird', 'Robin', 'Great tit', 'Chaffinch')):
  require exists reviewers[viewer] else NOT_REVIEWER 'Only trained reviewers can vote.'
  r = recordings[recording] ! else NOT_FOUND
  require r.owner != viewer else SELF_REVIEW 'You cannot review your own recording.'
  require r.acceptedSpecies = null else LABEL_ACCEPTED 'This recording already has an accepted label.'
  insert votes { recording, reviewer: viewer, species }
  if (agreement[recording, species] ?? 0) >= 2:
    update recordings[recording] { acceptedSpecies: species }
  return recordings[recording]
