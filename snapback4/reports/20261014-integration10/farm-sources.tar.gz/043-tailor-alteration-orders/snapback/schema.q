-- Tailor Alteration Orders.
-- alice: counter staff. bob: tailor (sees only assigned pieces). carol: manager.
use personas alice, bob, carol

table roles:
  principal: principal
  role: enum('staff', 'manager')
  unique principal
  read <- .principal = viewer or exists roles[viewer]
  insert <- exists roles[viewer, role = 'manager'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'manager']
  delete <- exists roles[viewer, role = 'manager']
  online only

table orders:
  customer: text 1..80
  phone: text 3..24 ?
  garment: text 1..120
  status: enum('intake', 'in_work', 'fitting', 'ready', 'picked_up', 'cancelled') default 'intake'
  createdBy: principal
  createdAt: time default now
  fittingStart: time ?
  fittingEnd: time ?
  fittingClaimed: bool default false
  immutable createdBy, createdAt
  read <- exists roles[viewer]
  insert <- exists roles[viewer]
  update <- exists roles[viewer]
  delete <- exists roles[viewer, role = 'manager']
  cap 500
  online only

table pieces:
  order: orders on delete cascade
  customer: text 1..80
  garment: text 1..120
  description: text 1..200
  measurements: text 1..500 ?
  photo: image <=5000000 ?
  tailor: principal ?
  done: bool default false
  immutable order, customer, garment
  read <- exists roles[viewer] or .tailor = viewer
  insert <- exists roles[viewer]
  update <- exists roles[viewer] or .tailor = viewer
  cap 50 by order
  online only

query board(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return orders last 50 by .id after c

query orderPieces(order: orders, c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return pieces where .order = order first 50 by .id after c

query myPieces(c: cursor ?):
  return pieces where .tailor = viewer first 50 by .id after c

query fittings(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return orders where .status = 'fitting' first 50 by .id after c

mutation placeOrder(customer: text 1..80, garment: text 1..120, phone: text 3..24 ?):
  require exists roles[viewer] else NOT_STAFF
  return insert orders { customer, garment, phone, createdBy: viewer }

mutation addPiece(order: orders, description: text 1..200, measurements: text 1..500 ?):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status != 'cancelled' and o.status != 'picked_up' else ORDER_CLOSED
  return insert pieces { order, customer: o.customer, garment: o.garment, description, measurements }

mutation assignPiece(piece: pieces, tailor: principal):
  require exists roles[viewer] else NOT_STAFF
  update pieces[piece] { tailor }

mutation setMeasurements(piece: pieces, measurements: text 1..500 ?):
  require exists roles[viewer] else NOT_STAFF
  update pieces[piece] { measurements }

mutation placePhoto(piece: pieces, photo: image <=5000000):
  require exists roles[viewer] else NOT_STAFF
  update pieces[piece] { photo }

mutation markDone(piece: pieces, done: bool):
  p = pieces[piece] ! else NOT_FOUND
  require exists roles[viewer] or p.tailor = viewer else NOT_ASSIGNED
  update pieces[piece] { done }

mutation startWork(order: orders):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status = 'intake' else BAD_STATUS
  update orders[order] { status: 'in_work' }

mutation scheduleFitting(order: orders, fittingStart: time, fittingEnd: time):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status = 'in_work' or o.status = 'ready' else BAD_STATUS
  require fittingEnd > fittingStart else BAD_WINDOW
  require fittingStart >= now - 5m else WINDOW_PAST
  update orders[order] { status: 'fitting', fittingStart, fittingEnd, fittingClaimed: false }

mutation claimFitting(order: orders):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status = 'fitting' else BAD_STATUS
  update orders[order] { fittingClaimed: true }

mutation markReady(order: orders):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status = 'fitting' else BAD_STATUS
  require o.fittingClaimed else NOT_CLAIMED
  update orders[order] { status: 'ready', fittingStart: null, fittingEnd: null }

mutation pickup(order: orders):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status = 'ready' else BAD_STATUS
  update orders[order] { status: 'picked_up' }

mutation cancelOrder(order: orders):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  o = orders[order] ! else NOT_FOUND
  require o.status != 'picked_up' else BAD_STATUS
  update orders[order] { status: 'cancelled' }

mutation removeOrder(order: orders):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  delete orders[order]

job releaseUnclaimed(periodStart: time, periodEnd: time):
  for o in orders by .id:
    if o.status = 'fitting' and not o.fittingClaimed and (o.fittingEnd ?? periodEnd) < periodEnd:
      update orders[o.id] { status: 'ready', fittingStart: null, fittingEnd: null }

schedule releaser every 5m: releaseUnclaimed
