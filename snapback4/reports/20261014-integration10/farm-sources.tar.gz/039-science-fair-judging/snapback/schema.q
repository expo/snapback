-- Science Fair Judging Desk backend.
-- Judges (alice, bob) are assigned projects blind (no school visible),
-- score against rubrics offline, and sync. Organizer (carol) manages the
-- fair, sees averages, and publishes results at awards time.
--
-- Audience design (one synced audience per table): organizers hold the
-- canonical projects/schools under the roster; judges hold their own
-- assignment cards (project fields copied at assign time, so the blind
-- core never fans out on edit -- projects are immutable) plus rubrics
-- and their own scores.
use personas alice, bob, carol

-- Roster: one row per organizer. The first row comes from fixtures/seed.
table organizers:
  principal: principal
  unique principal
  cap 50
  read <- .principal = viewer
  insert <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  online only

-- Canonical projects, organizers only (judges read their assignment cards).
table projects:
  title: text 1..100
  category: text 1..40
  student: text 1..60
  immutable title, category, student
  cap 500
  read <- exists organizers[viewer]
  insert <- exists organizers[viewer]
  sync

-- Hidden side of a project: organizers only, held on their devices.
table projectSchools:
  project: projects
  school: text 1..80
  unique project
  immutable project
  cap 500
  read <- exists organizers[viewer]
  insert <- exists organizers[viewer]
  sync

-- A judge's offline project card: assignment + blind project copy.
-- Copies are written once by assignJudge and never edited.
table assignments:
  project: projects
  judge: principal
  title: text 1..100
  category: text 1..40
  student: text 1..60
  unique project, judge
  immutable project, judge, title, category, student
  cap 200 by project
  cap 100 by judge
  read <- .judge = viewer or exists organizers[viewer]
  insert <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  sync

-- Scoring rubric, shared with every device.
table rubrics:
  criterion: text 1..60
  maxScore: int 1..100
  unique criterion
  cap 100
  public 'rubrics are shared with judges and organizers'
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  sync public

-- One score per (project, judge, criterion). Judges write only their own,
-- only where assigned; organizers read everything.
table scores:
  project: projects
  judge: principal
  criterion: rubrics
  value: int 0..100
  note: text <=280 ?
  unique project, judge, criterion
  immutable project, judge, criterion
  cap 500 by project
  cap 100 by judge, project
  read <- .judge = viewer or exists organizers[viewer]
  insert <- .judge = viewer and exists assignments[project = .project, judge = viewer]
  update <- .judge = viewer
  delete <- .judge = viewer or exists organizers[viewer]
  sync

-- Awards-time gate. Unpublished rows are invisible to judges, so a judge's
-- probe fails and gated queries refuse with RESULTS_HIDDEN.
table releaseFlags:
  name: text 1..40
  published: bool default false
  unique name
  read <- .published = true or exists organizers[viewer]
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  online only

-- Maintained totals back the averages. Served by the server.
view projectScoreTotal: sum scores of .value by .project
  read <- exists organizers[viewer] or exists assignments[.project, viewer]
  online only
view projectScoreCount: count scores by .project
  read <- exists organizers[viewer] or exists assignments[.project, viewer]
  online only

-- Judge reads --------------------------------------------------------------
query myAssignments():
  return assignments where .judge = viewer

query assignmentDetail(assignment: assignments):
  a = assignments[assignment] ! else NOT_FOUND
  return a

query rubricList():
  return rubrics

query myScores(project: projects):
  require exists organizers[viewer] or exists assignments[project, viewer] else NOT_ASSIGNED
  return scores where .project = project and .judge = viewer

-- Organizer reads -----------------------------------------------------------
query allProjects():
  require exists organizers[viewer] else NOT_ORGANIZER
  return projects

query projectSchool(project: projects):
  require exists organizers[viewer] else NOT_ORGANIZER
  return projectSchools[project = project]

query assignmentsFor(project: projects):
  require exists organizers[viewer] else NOT_ORGANIZER
  return assignments where .project = project

query scoresFor(project: projects):
  require exists organizers[viewer] else NOT_ORGANIZER
  return scores where .project = project

-- Results (averages): organizers anytime, judges only after publishing -----
query resultTotal(project: projects):
  require exists organizers[viewer] or exists releaseFlags[name = 'fair', published = true] else RESULTS_HIDDEN
  require exists organizers[viewer] or exists assignments[project, viewer] else NOT_ASSIGNED
  return projectScoreTotal[project]

query resultCount(project: projects):
  require exists organizers[viewer] or exists releaseFlags[name = 'fair', published = true] else RESULTS_HIDDEN
  require exists organizers[viewer] or exists assignments[project, viewer] else NOT_ASSIGNED
  return projectScoreCount[project]

query resultsFor(project: projects):
  require exists organizers[viewer] or exists releaseFlags[name = 'fair', published = true] else RESULTS_HIDDEN
  require exists organizers[viewer] or exists assignments[project, viewer] else NOT_ASSIGNED
  return scores where .project = project

-- Writes --------------------------------------------------------------------
mutation createProject(title: text 1..100, category: text 1..40, student: text 1..60, school: text 1..80):
  require exists organizers[viewer] else NOT_ORGANIZER
  p = insert projects { title, category, student }
  insert projectSchools { project: p.id, school }
  return p

mutation assignJudge(project: projects, judge: principal):
  require exists organizers[viewer] else NOT_ORGANIZER
  p = projects[project] ! else NOT_FOUND
  return insert assignments { project, judge, title: p.title, category: p.category, student: p.student }

mutation unassignJudge(assignment: assignments):
  require exists organizers[viewer] else NOT_ORGANIZER
  a = assignments[assignment] ! else NOT_FOUND
  delete assignments[assignment]
  return null

mutation createRubric(criterion: text 1..60, maxScore: int 1..100):
  require exists organizers[viewer] else NOT_ORGANIZER
  return insert rubrics { criterion, maxScore }

mutation updateRubric(criterion: rubrics, maxScore: int 1..100):
  require exists organizers[viewer] else NOT_ORGANIZER
  c = rubrics[criterion] ! else NOT_FOUND
  update rubrics[criterion] { maxScore }
  return null

mutation submitScore(project: projects, criterion: rubrics, value: int 0..100, note: text <=280 ?):
  require exists assignments[project, viewer] else NOT_ASSIGNED
  c = rubrics[criterion] ! else NOT_FOUND
  require value <= c.maxScore else OVER_MAX 'Score exceeds the rubric maximum.'
  return upsert scores[project, viewer, criterion] { project, judge: viewer, criterion, value, note }

mutation clearScore(score: scores):
  s = scores[score] ! else NOT_FOUND
  delete scores[score]
  return null

mutation publishResults(published: bool):
  require exists organizers[viewer] else NOT_ORGANIZER
  return upsert releaseFlags[name = 'fair'] { name: 'fair', published }
