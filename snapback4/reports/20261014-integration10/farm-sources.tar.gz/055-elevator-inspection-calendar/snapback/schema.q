use personas alice, bob, carol, dave

-- A small staff directory for assignment; no contact or account secrets.
table people:
  principal: principal
  name: text 1..80
  role: enum('manager', 'inspector', 'owner')
  unique principal
  cap 50
  public 'Staff names and roles are visible for visit assignment.'
  online only

table elevators:
  manager: principal
  owner: principal
  name: text 1..80
  address: text 1..160
  certificateDue: time
  immutable manager, owner
  read <- .manager = viewer or .owner = viewer
  insert <- .manager = viewer and exists people[viewer, role = 'manager']
  update <- .manager = viewer
  online only

table visits:
  elevator: elevators
  elevatorName: text 1..80
  manager: principal
  owner: principal
  inspector: principal
  visitAt: time
  signedAt: time ?
  immutable elevator, elevatorName, manager, owner, inspector, visitAt
  read <- .manager = viewer or .owner = viewer or .inspector = viewer
  insert <- .manager = viewer and .elevator.manager = viewer and .owner = .elevator.owner and .signedAt = null and exists people[.inspector, role = 'inspector']
  update (old, next) <- old.manager = viewer and old.signedAt = null and next.signedAt != null
  online only

table reports:
  visit: visits
  author: principal
  manager: principal
  owner: principal
  summary: text 10..2000
  document: file <=5000000 ('application/pdf', 'text/plain')
  uploadedAt: time
  locked: bool default false
  unique visit
  immutable visit, author, manager, owner
  read <- .manager = viewer or .owner = viewer or .author = viewer
  insert <- .author = viewer and .visit.inspector = viewer and .visit.signedAt = null and .manager = .visit.manager and .owner = .visit.owner and .locked = false
  update (old, next) <- old.author = viewer and next.author = viewer and old.visit.signedAt = null and old.locked = false and next.locked = false
  online only

table alerts:
  elevator: elevators
  owner: principal
  manager: principal
  dueAt: time
  raisedAt: time
  unique elevator, dueAt
  immutable elevator, owner, manager, dueAt, raisedAt
  read <- .owner = viewer or .manager = viewer
  online only

query directory():
  return people first 50 by .name
query calendar(c: cursor ?):
  if exists people[viewer, role = 'manager']:
    return elevators where .manager = viewer first 50 by .certificateDue after c
  return elevators where .owner = viewer first 50 by .certificateDue after c
query assignedVisits(c: cursor ?):
  if exists people[viewer, role = 'manager']:
    return visits where .manager = viewer first 50 by .visitAt after c
  if exists people[viewer, role = 'owner']:
    return visits where .owner = viewer first 50 by .visitAt after c
  return visits where .inspector = viewer first 50 by .visitAt after c
query visitReports(c: cursor ?):
  if exists people[viewer, role = 'manager']:
    return reports where .manager = viewer first 50 by .uploadedAt after c
  if exists people[viewer, role = 'owner']:
    return reports where .owner = viewer first 50 by .uploadedAt after c
  return reports where .author = viewer first 50 by .uploadedAt after c
query ownerAlerts(c: cursor ?):
  if exists people[viewer, role = 'manager']:
    return alerts where .manager = viewer first 50 by .raisedAt after c
  return alerts where .owner = viewer first 50 by .raisedAt after c

mutation addElevator(name: text 1..80, address: text 1..160, owner: principal, certificateDue: time):
  require exists people[viewer, role = 'manager'] else MANAGER_ONLY 'Only building managers can add elevators.'
  require exists people[owner, role = 'owner'] else OWNER_REQUIRED
  return insert elevators { manager: viewer, owner, name, address, certificateDue }

mutation scheduleVisit(elevator: elevators, inspector: principal, visitAt: time):
  e = elevators[elevator] ! else NOT_FOUND
  require e.manager = viewer else MANAGER_ONLY
  require exists people[inspector, role = 'inspector'] else INSPECTOR_REQUIRED
  require visitAt > now else FUTURE_VISIT 'Choose a future visit time.'
  return insert visits { elevator, elevatorName: e.name, manager: e.manager, owner: e.owner, inspector, visitAt }

mutation uploadReport(visit: visits, summary: text 10..2000, document: file <=5000000 ('application/pdf', 'text/plain')):
  v = visits[visit] ! else NOT_FOUND
  require v.inspector = viewer else INSPECTOR_ONLY 'Only the assigned inspector may upload a report.'
  require v.signedAt = null else REPORT_LOCKED 'Signed reports cannot be edited.'
  upsert reports[visit = visit] { visit, author: viewer, manager: v.manager, owner: v.owner, summary, document, uploadedAt: now, locked: false }
  return null

mutation signOff(visit: visits, certificateDue: time):
  v = visits[visit] ! else NOT_FOUND
  require v.manager = viewer else MANAGER_ONLY
  require v.signedAt = null else ALREADY_SIGNED
  require exists reports[visit = visit] else REPORT_REQUIRED
  require certificateDue > now else FUTURE_CERTIFICATE
  update visits[visit] { signedAt: now }
  update elevators[v.elevator] { certificateDue }
  return null

job certificateSweep():
  for e in elevators:
    if e.certificateDue < now and not exists alerts[e.id, e.certificateDue]:
      insert alerts { elevator: e.id, owner: e.owner, manager: e.manager, dueAt: e.certificateDue, raisedAt: now }
  for r in reports:
    if r.visit.signedAt != null and not r.locked:
      update reports[r.id] { locked: true }
schedule certificateCheck every 1h: certificateSweep
