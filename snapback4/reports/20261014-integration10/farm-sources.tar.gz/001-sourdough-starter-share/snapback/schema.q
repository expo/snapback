-- Sourdough Starter Share.
-- Home bakers list a starter they can divide; neighbors request portions.
-- Pickup address and phone stay hidden until the baker approves the request.
-- A weekly job expires unclaimed offers; a baker holds at most 3 active offers.
use personas alice, bob, carol

table offers:
  baker: principal
  name: text 3..60
  description: text <=500 ?
  portions: int 1..20
  pickupArea: text 3..80
  status: enum('active', 'expired') default 'active'
  hasApproved: bool default false
  createdAt: time default now
  immutable baker, createdAt
  public 'offers are browsable by every neighbor'
  insert <- .baker = viewer
  update <- .baker = viewer
  delete <- .baker = viewer
  online only

table contacts:
  offer: offers on delete cascade
  address: text 3..200
  phone: text 3..30
  unique offer
  immutable offer
  read <- exists offers[.offer, baker = viewer] or exists requests[offer = .offer, requester = viewer, status = 'approved']
  insert <- created offers[.offer] or exists offers[.offer, baker = viewer]
  update <- exists offers[.offer, baker = viewer]
  delete <- exists offers[.offer, baker = viewer]
  online only

table requests:
  offer: offers
  baker: principal
  requester: principal
  status: enum('pending', 'approved', 'declined') default 'pending'
  note: text <=200 ?
  createdAt: time default now
  unique offer, requester
  immutable offer, baker, requester, createdAt
  read <- .requester = viewer or exists offers[.offer, baker = viewer]
  insert <- .requester = viewer
  update <- exists offers[.offer, baker = viewer]
  delete <- .requester = viewer
  online only

view activeOfferCount: count offers where .status = 'active' by .baker
  read <- .baker = viewer
  online only

query browse(c: cursor ?):
  return offers where .status = 'active' last 50 by .createdAt after c

query myOffers(c: cursor ?):
  return offers where .baker = viewer last 50 by .createdAt after c

query offerDetail(offer: offers):
  return offers[offer]

query offerContact(offer: offers):
  o = offers[offer] ! else NOT_FOUND
  require o.baker = viewer or exists requests[offer, viewer, status = 'approved'] else CONTACT_HIDDEN
  return contacts[offer]

query incomingRequests(c: cursor ?):
  return requests where .baker = viewer last 50 by .createdAt after c

query myRequests(c: cursor ?):
  return requests where .requester = viewer last 50 by .createdAt after c

mutation createOffer(name: text 3..60, description: text <=500 ?, portions: int 1..20, pickupArea: text 3..80, address: text 3..200, phone: text 3..30):
  require activeOfferCount[viewer] < 3 else TOO_MANY_OFFERS
  o = insert offers { baker: viewer, name, description, portions, pickupArea }
  insert contacts { offer: o.id, address, phone }
  return o

mutation updateOffer(offer: offers, name: text 3..60 ?, description: text <=500 ?, portions: int 1..20 ?, pickupArea: text 3..80 ?):
  o = offers[offer] ! else NOT_FOUND
  require o.baker = viewer else NOT_YOURS
  update offers[offer] { name: name ?? o.name, description: description ?? o.description, portions: portions ?? o.portions, pickupArea: pickupArea ?? o.pickupArea }
  return offers[offer]

mutation retireOffer(offer: offers):
  o = offers[offer] ! else NOT_FOUND
  require o.baker = viewer else NOT_YOURS
  update offers[offer] { status: 'expired' }
  return offers[offer]

mutation requestPortion(offer: offers, note: text <=200 ?):
  o = offers[offer] ! else NOT_FOUND
  require o.status = 'active' else OFFER_UNAVAILABLE
  require o.baker != viewer else CANNOT_REQUEST_OWN
  return insert requests { offer, baker: o.baker, requester: viewer, note }

mutation approveRequest(request: requests):
  r = requests[request] ! else NOT_FOUND
  o = offers[r.offer] ! else NOT_FOUND
  require o.baker = viewer else NOT_YOURS
  require r.status = 'pending' else ALREADY_DECIDED
  update requests[request] { status: 'approved' }
  update offers[r.offer] { hasApproved: true }
  return requests[request]

mutation declineRequest(request: requests):
  r = requests[request] ! else NOT_FOUND
  o = offers[r.offer] ! else NOT_FOUND
  require o.baker = viewer else NOT_YOURS
  require r.status = 'pending' else ALREADY_DECIDED
  update requests[request] { status: 'declined' }
  return requests[request]

mutation withdrawRequest(request: requests):
  r = requests[request] ! else NOT_FOUND
  require r.requester = viewer else NOT_YOURS
  delete requests[request]
  return null

job expireOffers():
  for o in offers:
    if o.status = 'active' and o.createdAt < now - 7d and not o.hasApproved:
      update offers[o.id] { status: 'expired' }

schedule expireWeekly every 7d at 03:00: expireOffers
