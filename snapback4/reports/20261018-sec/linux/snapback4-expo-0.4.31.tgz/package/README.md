# snapback4-expo

Start with `npx snapback4 init --expo`, then `npm install` and `npx snapback4 check`. Adapter-first installs constrain React Native 0.86.3 and compatible React 19 (the same React peer range RN declares); init plus `npm install` pins React/React DOM 19.2.3 and supplies the app/scripts. Expo >=57.0.22 <58 with expo-modules-core >=57.0.23 <58 is supported. Upgrade with `npx snapback4@latest upgrade`; regenerate iOS and rebuild.

Snapback 4's device in Rust, as an Expo module: the partition in its own
SQLite, the stream applied, the outbox kept, queries and predictions
answered — the same interpreter the server runs, and the same module the
web runs as wasm — behind one JSON call. `snapback4/local` is the client
over it:

```ts
import { createLocalClient } from "snapback4/local";
import { createClient } from "snapback4/client";
import { nativeAvailable, nativeDevice } from "snapback4-expo";

const client = nativeAvailable()
  ? await createLocalClient({ url, guest: true, sessionStore, device: nativeDevice })
  : createClient({ url, session });   // Expo Go: the online tier, with a session the app keeps
```

`createNativeClient` probes the module first and rejects with
`E_NATIVE_VERSION` when the native binary predates the JavaScript client:
reloading JavaScript does not update the module; rebuild the development
build.

Expo Go loads no custom native code, so the module is present only in a
development or production build: add `expo-dev-client`, then
`npx expo run:ios` (the module autolinks; nothing to configure). The
Rust library ships in the package as `ios/Snapback4Device.xcframework`
(about 13.2 MB in 0.2.1, a 6.6 MB archive per slice, built by
`scripts/build-xcframework.sh` from `crates/snapback4-device`). It includes
SQLite and the native-query Wasm host. The earlier module measured 1.7 MB
linked and about a millisecond per call; those measurements predate the
native-query host.

The pinned Expo 57.0.30 apps list `snapback4-expo/plugin` in app.json's
`plugins`. Keep that entry when generating iOS: it supplies the scene lifecycle
required by Xcode 27, shared by the reference chat app and both starters.
It also adds the selected Xcode build to ExpoModulesJSI's slice-cache key:
27.0 and 27.1 can share a Swift compiler version but require different SDK
modules ([upstream issue](https://github.com/expo/expo/issues/50365)).
The patch is idempotent, applies during iOS prebuild, and refuses an unknown
upstream script instead of silently leaving an incompatible cache. Regenerate
iOS after installing/upgrading dependencies or changing Xcode; direct native
builds then invalidate the patched cache when the selected Xcode changes.
After adding it, run `npx expo prebuild --platform ios`, rebuild Release and
reinstall. Preserve custom native changes when regenerating; the plugin handles
the standard Swift starter and refuses custom delegates/manifests.

Earlier iOS simulator evidence from the repository's witness in a development
build (before the published driver, recorded in
`metrics/witness.jsonl` as `dev-client-native`): a cold sync of 303 rows
in 31 ms, a reopen in 6 ms, a cold start with no network answering the
thread from the store in 2 ms, and writes composed offline surviving a
restart and landing in order. `EXPO_PUBLIC_SNAPBACK_TRACE=1` logs every
call's op, time and answer size. Android follows.

Ordinary media can be retained with `createLocalClient({ ..., device: nativeDevice,
assets: { keep: "viewed", maxBytes: 67108864 } })`. The opener supplies private
file storage beside each device store in Documents. Offline `client.asset` and
`useAsset` return a file URI; online calls revalidate. The client purges bytes
on home-row revocation, deletion, clearing or expiry and on sign-out; `once`
bytes never enter file storage. Rebuild the native app to include this storage
capability. `keep: "none"` (default) retains no bytes.

## Simulator witness

Import `witness` from `snapback4-expo/witness` in an installed iOS Release
app. `witness()` is null on ordinary launches; under `snapback4 witness ios`
it returns `{ segment, step(name, fn), receipt(object), waitFor(label) }`.
The `Witness` type is exported from the same subpath. Rebuild the native app
to include the launch-environment and Documents-file bridge. The full chat
runner, commands and artifact contract are in `snapback4 guide witness`
(aliases: `simulator`, `offline proof`) and the client package README's
“Proving it on an iOS simulator”. No Expo Go or Metro process supplies a
Release witness.

At every milestone, `npm run export:ios` publishes Hermes to `dist/` and returns.
Native proof runs in the background at background QoS while you keep building.
The next export and `npx snapback4 doctor` print the result; for your final report
run `npx snapback4 witness status --wait`. A newer export supersedes pending proof.
Failures stay visible with log paths without failing a successful export;
unavailable hosts report a skip. Background preparation allows 900 seconds without output activity and at most 60 minutes total. Activity alone does not establish build progress; repeated output can keep a stalled build occupied until that cap.
`npm run native:smoke` explicitly waits for the full build and smoke.
The smoke prepares and installs your Release app, chooses its own simulator and free
port, and keeps receipts in `artifacts/native-smoke/<timestamp>`. It proves local
store acquisition, cold offline reopen and reconnect. Pending write replay, media
and application assertions need the deeper scenario in `snapback4 guide witness`.
An empty starter proves lifecycle only; a skipped smoke proves no native execution.

Own-build preparation (`witness ios --build . --smoke`) uses the witness helper
in matching current `snapback4` and `snapback4-expo` packages. Its synchronous native observation hashes
the executable and the file selected by React Native SourceCode.scriptURL.
Selection must resolve to the verified installed main.jsbundle; unknown, remote
or alternate URLs fail, as do runtime __DEV__ true/unknown and launcher/updates
manifest presence. The validator
checks Release/Hermes, the selected path and hashes against the external proof. Rebuild the native module
when adopting it. Ordinary launches remain inactive. Linked expo-updates is
outside this preparation adapter because an embedded hash cannot attest a cached
update selected at runtime. The JS smoke helper consumes compiler query facts
from the driver, bound to the generation actually served. It checks every
runs/held fact against the kept backend before querying. Stale facts fail;
device-answerable loading fails, while server-only offline
E_OFFLINE is recorded as expected unavailability. Server-only reads
must answer online in prime and restart. Conditional native-module queries
require an application witness; generic smoke refuses that unsupported shape. Client semantics are unchanged.

After JS edits, repeat `npm run export:ios`; simulator selection and fresh
artifact directories are automatic. Matching native inputs reuse the Release
app and install the exact exported bundle/assets. Native changes rebuild;
`npm run native:smoke` always runs Xcode. Both routes retain the same loaded-file
hash and prime/offline/restart proof. Automatic smoke creates and removes its own
recorded simulator, with project and device leases held through cleanup.

For durable offline media, use the local client's `uploadAndPlace` or `useUpload`
(re-exported here). `saveAsset(client, id, name?)` presents the iOS save/share sheet
from authorized or retained bytes. See [the shared upload contract](../snapback4/OFFLINE-UPLOADS.md).

### Persist account sessions

Install with `npx expo install expo-secure-store`, import `* as SecureStore` from
`expo-secure-store`, then import `secureStoreSessionStore` from `snapback4-expo`.
Pass `sessionStore: secureStoreSessionStore(SecureStore)` to `createApp`.
The adapter encodes complete UTF-16 keys injectively; distinct backend and
read/full session keys stay distinct. Storage failures propagate. This adds no
Swift code. Rebuild the app after installing SecureStore; see
[Expo SecureStore](https://docs.expo.dev/versions/latest/sdk/securestore/).
