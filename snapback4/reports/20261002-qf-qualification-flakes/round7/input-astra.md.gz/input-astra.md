**Verdict: NOT READY — three P1 findings remain.** All three reproduced on Linux and the Apartment mini.

1. **P1 — Exit fields do not prove the keeper is unreaped.**  
   [`signalGroup()`](/home/ccheever/sb4-intent/review-qf-r6-astra/snapback4/scripts/test-processes.mjs:91) trusts `exitCode === null && signalCode === null`. Libuv can reap several children before delivering their individual exit callbacks. During the first child’s callback, the keeper was already absent from the process table, but both fields remained null. Aborting `runFile()` then attempted `SIGKILL` against its former PGID.

   I intercepted the signal call; no unrelated process was signalled. This leaves authorization valid after kernel custody has ended, permitting an unrelated group to be targeted after reuse. Actual PID/PGID reuse was not forced. Have the live keeper perform its own group signal, or otherwise retain actual unreaped custody; JavaScript exit fields are insufficient.

2. **P1 — `test.only()` silently removes failing tests.**  
   The reporter’s [`isolation: 'none'`](/home/ccheever/sb4-intent/review-qf-r6-astra/snapback4/scripts/test-progress-reporter.mjs:13) changes ordinary `node --test` semantics:

   ```js
   import test from 'node:test';
   test.only('selected', () => {});
   test('must fail', () => { throw Error('failure'); });
   ```

   Native Node runs both tests and exits **1**. This runner executes only the selected test and returns **`passed: true`, `tests: 1`, `fail: 0`**. This follows Node’s isolation-dependent filtering behavior. [Node implementation](https://raw.githubusercontent.com/nodejs/node/v24.13.1/lib/internal/test_runner/harness.js)

3. **P1 — Exit-code overrides still conceal teardown and asynchronous failures.**  
   The [summary-only failure count](/home/ccheever/sb4-intent/review-qf-r6-astra/snapback4/scripts/test-progress-reporter.mjs:18) does not include every failure:

   ```js
   import test from 'node:test';
   test('passes', () => {});
   test.after(() => { throw Error('teardown failure'); });
   process.on('beforeExit', () => { process.exitCode = 0; });
   ```

   Native Node exits **1**. This runner prints the hook’s `not ok`, yet returns **`passed: true`, `fail: 0`**. Late uncaught exceptions and unhandled rejections also falsely pass with the override. Preserve TODO-aware failure events independently, and retain the summary’s unsuccessful-run state. Neither counters nor `summary.success` alone covers all these cases.

The qualification claims check out as recorded evidence:

| Claim | Concrete verification |
|---|---|
| Focused checks: 32/32 on each host | Fresh **32/32 Linux and mini**, zero skips/refusals. |
| Both targets: 200/200 | Independently recounted compressed JSONL; correct assertion counts and 23 active background slots at every completion. |
| Background: 1,429 passes, zero refusals | Recounted all 1,429 results across 300 files; status 0, populated counts, no failures/cancellations/refusals. |
| Full suite: only four UB failures | Verified log SHA-256, four failure names and assertion signatures against the retained clean-main baseline. Footer: **1 failure category in 1452 seconds**. All 303 JavaScript file results passed; no `not ok` or late-asynchronous-error diagnostics. |
| Evidence matches reviewed source | All **2,433 source hashes** and ten mini source hashes match. |

The previous stale-ancestry reproduction now leaves the unrelated sibling untouched, including a stale-group-row variant. The original assertion/`beforeExit` reproduction is correctly rejected; expected TODO failures and skips behave correctly. Cancellation overrides are also rejected.

The native fork/exit escape still survives while its file passes. That now matches the explicit exclusion: **`setsid`, `setpgid`, and detached spawns are neither tracked, cleaned up, nor counted as leaks, regardless of ancestry or environment**. My escaped helpers exited cooperatively afterward.

Observed in-group leaks fail and are killed. Stalled execution, console chatter, failed listings, vanished members, and progressing synchronous/nested tests passed their regressions. Replacement cleanup passed all three focused cases; the worker admission barrier and original worker regression passed fresh Linux checks. I found no removed mechanism required by those original incidents.

Open checks: I did not rerun the complete suite or 1,829-execution stress batch, and did not force kernel PID/PGID reuse. Mini replacement checks used published 0.4.10, so they establish fixture portability rather than current-release qualification.

Both scratch directories were deleted. The checkout is unchanged; nothing was pushed. **NOT READY.**