# Independent SECP calibrated-hole question retention

Status: **complete**. Generated 2026-10-27T02:19:35.426762+00:00.

All **54** calibrated findings were reviewed: wave26 19, wave28 18, wave30 17, across 37 source applications. **31** had an exact semantically relevant baseline question. Current result: **31 retained, 0 lost_question, 23 uncovered_before, 0 pending_final**.

This measures questions only. It does not measure witnesses, exploits, runtime safety or production gates. **Integration27 wave30 exact M-hole gate coverage remains 1/14, solely 033F1.** The seven selected SECP codes are non-gates; matching may use any advisory or recorded question.

A retained finding means at least one question names the same actual missing condition. Generic guarded-stage advice does not cover missing transition edges; standing-guard advice does not cover duplicate-resource credit-hold bypass. Broad assignment-audience questions that do not name the assigned coordinator/project lead are listed separately. Upload-versus-text questions retain that aspect only, not automatically required-presence or nonempty-list checks.

| Wave | Findings | Exact baseline question | Retained | Lost | Uncovered before | Pending |
|---|---:|---:|---:|---:|---:|---:|
| 26 | 19 | 17 | 17 | 0 | 2 | 0 |
| 28 | 18 | 9 | 9 | 0 | 9 | 0 |
| 30 | 17 | 5 | 5 | 0 | 12 | 0 |

No actual lost calibrated question was found in the available qualified files.

Selected-code question disappearance with an exact alternative still present: w26-033F1. The per-finding evidence names the alternative; a different code/site alone is never sufficient.

Final-only exact questions, still classified uncovered_before: w28-036F2. They do not increase the retention denominator. In total 32 findings have a relevant question after.

## Provenance and scope

Worktree `/home/ccheever/projects/sb4-b31-secp`; observed HEAD `473e7433a9c7e8a1f0dd71007a347db807ef2251`. Only audit artifacts under `/tmp/secp-evidence` were written. No source application, product command, credential or other worktree was used as an executable or modified; no agents were spawned.

Inputs (SHA-256):
- `/tmp/secp-evidence/before-default/results.json` — `177a6d28d9c7f60b694a7b43397f63ead00b063eae0c41a5bac9977de8a862aa`
- `/tmp/secp-evidence/accepted-final/results.json` — `9c3ac88434952f5d89c246c5f7938cb1f190f813bc33d21385cac6b77f76c969`
- `/home/ccheever/sb4-loop/wave26/analysis/calibration.json` — `8dbc518869498111be30a418bbf0da27e51f4bf88822127603f7ab0f450778d5`
- `/home/ccheever/sb4-loop/wave28/analysis/calibration.json` — `2a253362bd3d8bc07145675f9b09f89a527f0dcbf8084a562ab30f2131c4fe8a`
- `/home/ccheever/sb4-loop/wave30/analysis/calibration.json` — `12009da8c8ba4ada449cfc4b64c9d62a9fc410f790cb98cad5bdae49ec7942db`
- Baseline manifest `/tmp/secp-evidence/before-default/measurement.json` — `8ed72b0e22e033fa708eb672df8fe6206e1559a347b6af9183681aa40f8e12fc`; measured binary SHA-256 `3e5b86eb9fdf84842c2fbf40ccb7019a64ec3ad02aef7e180801a1d4203fbffb`.
- Qualified final manifest `/tmp/secp-evidence/accepted-final/measurement.json` — `1031a8a457803dcae43ec90e152e4d23263d78bcd8247df070d504776ed22efb`; measured binary SHA-256 `566371fccda0622d4bb920856e2a040ccab1540f943198aa0c1f170d5dd52bc8`.
- Audit generator `/home/ccheever/projects/sb4-b31-secp/snapback4/reports/secp/tools/calibration-retention.py` — `2431b13bad50c80bf6cb8843fc304487bcb25c063d0077eed567defbecb9590f`.

Every source bundle equals the baseline and available final record’s `sha256`. Bundle recipe: SHA-256 of UTF-8 Python `json.dumps(sorted [(q.name, q.read_text()) for top-level *.q])`, default serialization. Individual source-file hashes, result-file hashes, unchanged-source verification, complete diagnostic inventories and all exact messages are in the JSON. Both individual/aggregate records were compared when both existed.

Governing read-only context: `skills/llp-orient/SKILL.md`; Snapback4 fence/LLP 3000; LLP 3000.036.004.001 §6 and LLP 3000.036.004. No document changes or runtime claims follow from this audit.

## All findings

### w26-002F1 — retained (M)

Application: `002-snapback-compression-garment-fittings`. Pattern: `time-rule-misencoded`.

Condition: Six-month prescription age uses month buckets rather than an exact elapsed/anniversary window.

Calibration note (verbatim): orderGarment compares calendar month numbers (`month(now) - month(f.prescriptionDate) <= 6`, schema.q:94): an April prescription orders in late October. Real; no note; 0.4.40 test with clock intent 0 witnesses

Retained-question scope: Six-month prescription age uses month buckets rather than an exact elapsed/anniversary window.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/002-snapback-compression-garment-fittings/snapback/schema.q:89` through line 96
```text
89: -- Staff order the garment; refused once the prescription is older than six months.
90: mutation orderGarment(fitting: fittings):
91:   require exists roles[principal = viewer, role = 'frontdesk'] or exists roles[principal = viewer, role = 'fitter'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
92:   f = fittings[fitting] ! else NOT_FOUND
93:   require f.status = 'measured' else BAD_STATUS 'Only a measured fitting can be ordered.'
94:   require month(now) - month(f.prescriptionDate) <= 6 else PRESCRIPTION_STALE 'The prescription is older than six months.'
95:   update fittings[fitting] { status: 'ordered' }
96:   return null
```
Source bundle SHA-256: `2181c58cb9e0249df90078f415157c18a23b697ead42fa86c51101df65837c25`.

**BEFORE exact relevant matches**
- `N_CALENDAR_DURATION` at `schema.q:95:3` (advisory; `notes[17]`): orderGarment: month() arithmetic retains the year but drops day-of-month precision; is this a month bucket or an exact anniversary window?

**AFTER exact relevant matches**
- `N_CALENDAR_DURATION` at `schema.q:95:3` (advisory; `notes[13]`): orderGarment: month() arithmetic retains the year but drops day-of-month precision; is this a month bucket or an exact anniversary window?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The calendar question names orderGarment and the loss of day-of-month precision in month() arithmetic. It asks about the same prescription-window encoding. This does not validate the calibration note's older description of month() as month numbers alone.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-008F1 — retained (M)

Application: `008-snapback-stucco-repair-jobs`. Pattern: `child-transition-ignores-parent-state`.

Condition: advanceWall does not require its parent job to have an accepted estimate or be in progress.

Calibration note (verbatim): advanceWall (schema.q:146-151) never checks jobs.status; crew plaster walls on an unaccepted estimate. Real; 0.4.40 test with one line: 10 witnesses

Retained-question scope: advanceWall does not require its parent job to have an accepted estimate or be in progress.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/008-snapback-stucco-repair-jobs/snapback/schema.q:133` through line 157
```text
133: mutation acceptQuote(job: jobs):
134:   j = jobs[job] ! else NOT_FOUND
135:   require j.homeowner = viewer else NOT_HOMEOWNER
136:   require j.status = 'estimate' else BAD_STATUS
137:   require now <= j.estimateCreatedAt + 30d else ESTIMATE_LAPSED
138:   update jobs[job] { status: 'accepted', acceptedAt: now }
139: 
140: mutation startWork(job: jobs):
141:   j = jobs[job] ! else NOT_FOUND
142:   require exists roles[viewer, role = 'crew'] else NOT_CREW
143:   require j.status = 'accepted' else BAD_STATUS
144:   update jobs[job] { status: 'in_progress' }
145: 
146: -- Walls move forward one stage at a time: removal -> lath -> scratch -> finish.
147: mutation advanceWall(wall: walls):
148:   w = walls[wall] ! else NOT_FOUND
149:   require exists roles[viewer, role = 'crew'] else NOT_CREW
150:   require w.stage = 'removal' or w.stage = 'lath' or w.stage = 'scratch' else ALREADY_FINISHED
151:   update walls[wall] { stage: 'lath' if w.stage = 'removal' else 'scratch' if w.stage = 'lath' else 'finish' }
152: 
153: mutation finishJob(job: jobs):
154:   j = jobs[job] ! else NOT_FOUND
155:   require exists roles[viewer, role = 'crew'] else NOT_CREW
156:   require j.status = 'in_progress' else BAD_STATUS
157:   update jobs[job] { status: 'finished', finishedAt: now }
```
Source bundle SHA-256: `62ef92d4fbaa3ad991a1e073166b6c5873743ed2b189452a4bd784854249ef0b`.

**BEFORE exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/parent-state/754d5fbc4057b66fb816dde3600c92927483cfcbe41740db8ffe0a0139e7c437/schema.q:151:3` (advisory; `notes[30]`): walls.stage update: derived candidate update only (.job.status = 'accepted' or .job.status = 'in_progress'); a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/parent-state/754d5fbc4057b66fb816dde3600c92927483cfcbe41740db8ffe0a0139e7c437/schema.q:151:3` (advisory; `notes[25]`): walls.stage update: derived candidate update only (.job.status = 'accepted' or .job.status = 'in_progress'); a replayed violation needs a specification decision

**Broad/nearby questions excluded from coverage**
- baseline: `N_ROLE_WIDE_READ` at `schema.q:40:3`: jobs.read: roles.role='crew' (`exists roles[viewer, role = 'crew']`), roles.role='owner' (`exists roles[viewer, role = 'owner']`) branches read every value of [status] across a private/media boundary; should the spec restrict these roles to particular resource relationships or states?
- final: `N_ROLE_WIDE_READ` at `schema.q:40:3`: jobs.read: roles.role='crew' (`exists roles[viewer, role = 'crew']`), roles.role='owner' (`exists roles[viewer, role = 'owner']`) branches read every value of [status] across a private/media boundary; should the spec restrict these roles to particular resource relationships or states?

Rationale: The derived walls.stage question explicitly requires .job.status accepted/in_progress. The broad read-audience question has no such write prerequisite.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-008F2 — retained (M)

Application: `008-snapback-stucco-repair-jobs`. Pattern: `parent-completion-ignores-children`.

Condition: finishJob does not require every child wall to have its finish coat.

Calibration note (verbatim): finishJob (schema.q:153-157) ignores wall stages, opening the 60-day free-repair window before any final coat. Convex 008 F4 is the same rule. Real; 0.4.40 test with one line: 1 witness

Retained-question scope: finishJob does not require every child wall to have its finish coat.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/008-snapback-stucco-repair-jobs/snapback/schema.q:146` through line 157
```text
146: -- Walls move forward one stage at a time: removal -> lath -> scratch -> finish.
147: mutation advanceWall(wall: walls):
148:   w = walls[wall] ! else NOT_FOUND
149:   require exists roles[viewer, role = 'crew'] else NOT_CREW
150:   require w.stage = 'removal' or w.stage = 'lath' or w.stage = 'scratch' else ALREADY_FINISHED
151:   update walls[wall] { stage: 'lath' if w.stage = 'removal' else 'scratch' if w.stage = 'lath' else 'finish' }
152: 
153: mutation finishJob(job: jobs):
154:   j = jobs[job] ! else NOT_FOUND
155:   require exists roles[viewer, role = 'crew'] else NOT_CREW
156:   require j.status = 'in_progress' else BAD_STATUS
157:   update jobs[job] { status: 'finished', finishedAt: now }
```
Source bundle SHA-256: `62ef92d4fbaa3ad991a1e073166b6c5873743ed2b189452a4bd784854249ef0b`.

**BEFORE exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/child-stage/16c68cbdeab94206ae0a04b64feb30dbbbda706306a645e1dfd325e1d3ab28fd/schema.q:157:3` (advisory; `notes[31]`): jobs.status update: inferred effect prerequisite (.status != 'finished' or count(walls[job = .id] where .stage != 'finish') = 0); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/child-stage/16c68cbdeab94206ae0a04b64feb30dbbbda706306a645e1dfd325e1d3ab28fd/schema.q:157:3` (advisory; `notes[26]`): jobs.status update: inferred effect prerequisite (.status != 'finished' or count(walls[job = .id] where .stage != 'finish') = 0); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision

**Broad/nearby questions excluded from coverage**
- baseline: `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:138:3`: jobs: transitions acceptQuote, finishJob, startWork do not require attached photos[job = parent].photo; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:157:3`: finishJob: jobs.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- final: `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:138:3`: jobs: transitions acceptQuote, finishJob, startWork do not require attached photos[job = parent].photo; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

Rationale: The inferred effect prerequisite names finished jobs and unfinished walls for that job. The edit question concerns generic editability; the child-evidence question concerns photos rather than finished walls.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-018F1 — retained (M)

Application: `018-snapback-livestock-ultrasound-scans`. Pattern: `approval-sibling-path-bypass`.

Condition: addRescan omits the restricted-herd approval checked by addScan.

Calibration note (verbatim): addScan requires approvals[visit] on a restricted herd (schema.q:180-181), addRescan (:184-191) does not; an ordinary scanner records a rescan without lead approval. Staff bypass -> M. 0.4.40: no note, test 0 in 7,230 (history reach)

Retained-question scope: addRescan omits the restricted-herd approval checked by addScan.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/018-snapback-livestock-ultrasound-scans/snapback/schema.q:172` through line 199
```text
172: mutation addScan(visit: visits, tag: text 1..20, result: enum('pregnant', 'empty')):
173:   v = visits[visit] ! else NOT_FOUND 'Visit not found.'
174:   me = roles[viewer]
175:   require me != null and (me.role = 'scanner' or me.role = 'lead') else NOT_SCANNER 'Only a scanner may record scans.'
176:   require v.confirmed else NOT_CONFIRMED 'Confirm the visit before scanning.'
177:   require v.status = 'penned' or v.status = 'scanned' else BAD_STATUS 'Pen the visit before scanning.'
178:   h = herds[v.herd]
179:   if h != null and h.restricted:
180:     require exists approvals[visit] else NO_APPROVAL 'Disease restriction: lead approval with vet permit required.'
181:   require not exists scans[visit, tag] else DUPLICATE_TAG 'This animal is already scanned for this visit.'
182:   return insert scans { visit, tag, result, at: now }
183: 
184: mutation addRescan(scan: scans, result: enum('pregnant', 'empty')):
185:   s = scans[scan] ! else NOT_FOUND 'Scan not found.'
186:   me = roles[viewer]
187:   require me != null and (me.role = 'scanner' or me.role = 'lead') else NOT_SCANNER 'Only a scanner may rescan.'
188:   require s.result = 'empty' else NOT_EMPTY 'Only animals scanned empty may be rescanned.'
189:   v = visits[s.visit] ! else NOT_FOUND 'Visit not found.'
190:   require v.visitDate >= now - 30d else WINDOW_CLOSED 'Rescans are allowed within 30 days of the visit.'
191:   return insert rescans { scan, result, at: now }
192: 
193: mutation approveRestricted(visit: visits, permit: text 1..120, extraFeeCents: int 0..1000000):
194:   me = roles[viewer]
195:   require me != null and me.role = 'lead' else NOT_LEAD 'Only the lead scanner may approve a restricted herd.'
196:   v = visits[visit] ! else NOT_FOUND 'Visit not found.'
197:   h = herds[v.herd] ! else NOT_FOUND 'Herd not found.'
198:   require h.restricted else NOT_RESTRICTED 'This herd is not under disease restrictions.'
199:   return upsert approvals[visit] { visit, permit, extraFeeCents, approver: viewer, at: now }
```
Source bundle SHA-256: `2c2291b716f699e4b0e367b4fae916cb727a2947d0ee261682e6773bf9fa4938`.

**BEFORE exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/8659fc62e316e43a5802e0df26bd7606683cd128ac2f54a99b259f8a84afb039/schema.q:182:10` (advisory; `notes[23]`): rescans.insert: derived candidate insert only (not (.scan.visit.herd != null and .scan.visit.herd.restricted) or (exists approvals[visit = .scan.visit.id])); a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/8659fc62e316e43a5802e0df26bd7606683cd128ac2f54a99b259f8a84afb039/schema.q:182:10` (advisory; `notes[9]`): rescans.insert: derived candidate insert only (not (.scan.visit.herd != null and .scan.visit.herd.restricted) or (exists approvals[visit = .scan.visit.id])); a replayed violation needs a specification decision

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:191:10`: addRescan: checks roles.role but leaves it unchanged while changing rescans state; could repeating this transition reuse that guard?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:191:10`: addRescan: checks scans.result but leaves it unchanged while changing rescans state; could repeating this transition reuse that guard?

Rationale: The derived rescans.insert prerequisite follows scan.visit.herd.restricted to approvals[visit = .scan.visit.id], naming the missing approval on the rescan path. Its emitted site is the sibling addScan write at 182; the target and expression, rather than the shared site, establish relevance. Role/result reuse advice at addRescan does not name the missing approval.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-018F2 — uncovered_before (L)

Application: `018-snapback-livestock-ultrasound-scans`. Pattern: `window-one-sided`.

Condition: addRescan lacks a lower bound on server time relative to the original visit, allowing a rescan before a future visit.

Calibration note (verbatim): addRescan bounds only visitDate >= now-30d (schema.q:189); a rescan can predate a future visit. Not Convex 018 F5 (late rescan accepted, the real rule); low harm -> L

Retained-question scope: addRescan lacks a lower bound on server time relative to the original visit, allowing a rescan before a future visit.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/018-snapback-livestock-ultrasound-scans/snapback/schema.q:184` through line 191
```text
184: mutation addRescan(scan: scans, result: enum('pregnant', 'empty')):
185:   s = scans[scan] ! else NOT_FOUND 'Scan not found.'
186:   me = roles[viewer]
187:   require me != null and (me.role = 'scanner' or me.role = 'lead') else NOT_SCANNER 'Only a scanner may rescan.'
188:   require s.result = 'empty' else NOT_EMPTY 'Only animals scanned empty may be rescanned.'
189:   v = visits[s.visit] ! else NOT_FOUND 'Visit not found.'
190:   require v.visitDate >= now - 30d else WINDOW_CLOSED 'Rescans are allowed within 30 days of the visit.'
191:   return insert rescans { scan, result, at: now }
```
Source bundle SHA-256: `2c2291b716f699e4b0e367b4fae916cb727a2947d0ee261682e6773bf9fa4938`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:191:10`: addRescan: checks roles.role but leaves it unchanged while changing rescans state; could repeating this transition reuse that guard?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:191:10`: addRescan: checks scans.result but leaves it unchanged while changing rescans state; could repeating this transition reuse that guard?

Rationale: The only time requirement is visitDate >= now - 30d. Neither role/result reuse nor filtered lookup advice asks whether now precedes visitDate; there is no exact baseline question.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w26-020F1 — retained (M)

Application: `020-snapback-llama-trekking-trips`. Pattern: `approval-not-enforced`.

Condition: advanceStatus does not read routeApproved for a private-land trek.

Calibration note (verbatim): advanceStatus (schema.q:104-109) ignores routeApproved for crossesPrivateLand; approveRoute only sets the flag. Handler bypass -> M. 0.4.40 N_APPROVAL_NOT_ENFORCED fires at :108 (advice); one line + test: 127 witnesses

Retained-question scope: advanceStatus does not read routeApproved for a private-land trek.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/020-snapback-llama-trekking-trips/snapback/schema.q:104` through line 126
```text
104: mutation advanceStatus(trek: treks):
105:   require exists roles[principal = viewer, role = 'handler'] or exists roles[principal = viewer, role = 'owner'] else NOT_STAFF
106:   t = treks[trek] ! else NOT_FOUND
107:   require t.status = 'booked' or t.status = 'saddled' or t.status = 'on_trail' else NOT_ADVANCEABLE
108:   update treks[trek] { status: 'saddled' if t.status = 'booked' else 'on_trail' if t.status = 'saddled' else 'back_at_barn' }
109:   return null
110: 
111: mutation cancelTrek(trek: treks):
112:   require exists roles[principal = viewer, role = 'handler'] or exists roles[principal = viewer, role = 'owner'] else NOT_STAFF
113:   t = treks[trek] ! else NOT_FOUND
114:   require t.status != 'cancelled' else ALREADY_CANCELLED
115:   require t.status != 'back_at_barn' else TREK_COMPLETED
116:   update treks[trek] { status: 'cancelled' }
117:   if now < t.trekDate - 10d:
118:     for h in trekHikers where .trek = trek by .id:
119:       insert receipts { trek, hiker: h.hiker, amount: t.price, kind: 'refund' }
120:   return null
121: 
122: mutation approveRoute(trek: treks, landownerPermission: text 1..500):
123:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
124:   t = treks[trek] ! else NOT_FOUND
125:   require t.crossesPrivateLand else NO_PRIVATE_LAND
126:   update treks[trek] { routeApproved: true, landownerPermission }
```
Source bundle SHA-256: `b858f88a3cf9a1dfe97301ef67d3bb58eb2ee28f046ef48f06cbda5a747cdd85`.

**BEFORE exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:108:3` (advisory; `notes[13]`): treks.routeApproved: a modeled advanceStatus effect can proceed without reading this recorded approval

**AFTER exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:108:3` (advisory; `notes[12]`): treks.routeApproved: a modeled advanceStatus effect can proceed without reading this recorded approval

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:108:3`: advanceStatus: treks.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The approval diagnostic names treks.routeApproved and the actual advanceStatus effect. The generic status-edit question is not the basis of coverage.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-024F1 — retained (M)

Application: `024-snapback-billiard-table-relocations`. Pattern: `required-evidence-optional-text`.

Condition: The three required move photos are optional text references rather than verified uploads.

Calibration note (verbatim): photoTable/photoSlate/photoStair are `text <=500 ?` (schema.q:38-40), optional in createMove (:90-93); no upload at all. Like wave-24 008 F1. No note fires on text columns on 0.4.39 or 0.4.40; one `always` line + test: 153 witnesses, no gate (not media)

Retained-question scope: Verified uploaded photos versus text references; optionality itself is not named by these messages.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/024-snapback-billiard-table-relocations/snapback/schema.q:38` through line 40
```text
38:   photoTable: text <=500 ?
39:   photoSlate: text <=500 ?
40:   photoStair: text <=500 ?
```
`/home/ccheever/sb4-loop/wave26/apps/024-snapback-billiard-table-relocations/snapback/schema.q:90` through line 93
```text
90: mutation createMove(client: principal, pickup: text 1..200, dropoff: text 1..200, accessNotes: text <=2000, slateLengthMm: int 200..3000, slateWidthMm: int 200..2000, slateThickMm: int 10..100, photoTable: text <=500 ?, photoSlate: text <=500 ?, photoStair: text <=500 ?, phone: text 4..30, insuredCents: int 0..100000000, priceCents: int 0..100000000):
91:   require exists roles[principal = viewer, role = 'surveyor'] or exists roles[principal = viewer, role = 'manager'] else NOT_SURVEYOR 'Only a surveyor or the operations manager can open a move.'
92:   require exists roles[principal = client, role = 'client'] else NOT_CLIENT 'The move client must hold the client role.'
93:   return insert moves { client, surveyor: viewer, pickup, dropoff, accessNotes, slateLengthMm, slateWidthMm, slateThickMm, photoTable, photoSlate, photoStair, phone, insuredCents, priceCents }
```
Source bundle SHA-256: `925f8faf758c6ca13eb8f77230d36446b8e0fa867cf50a99b25f0258ae755810`.

**BEFORE exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:39:3` (advisory; `notes[15]`): moves.photoSlate: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?
- `N_TEXT_EVIDENCE` at `schema.q:40:3` (advisory; `notes[16]`): moves.photoStair: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?
- `N_TEXT_EVIDENCE` at `schema.q:38:3` (advisory; `notes[17]`): moves.photoTable: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**AFTER exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:39:3` (advisory; `notes[11]`): moves.photoSlate: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?
- `N_TEXT_EVIDENCE` at `schema.q:40:3` (advisory; `notes[12]`): moves.photoStair: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?
- `N_TEXT_EVIDENCE` at `schema.q:38:3` (advisory; `notes[13]`): moves.photoTable: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: Each named photo column receives the explicit verified-upload-versus-text question. This retains the upload representation aspect of the calibrated finding; these messages do not independently ask whether the photos may be omitted.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-024F2 — retained (L)

Application: `024-snapback-billiard-table-relocations`. Pattern: `window-one-sided`.

Condition: recordVisit allows visitedAt earlier than movedAt because it checks only the upper 60-day bound.

Calibration note (verbatim): recordVisit (schema.q:114) bounds visitedAt only above movedAt+60d; a visit 61 days before the move is stored. overdueMoves keys on status, so no obligation is cleared -> L. One line + test: 22 witnesses

Retained-question scope: recordVisit allows visitedAt earlier than movedAt because it checks only the upper 60-day bound.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/024-snapback-billiard-table-relocations/snapback/schema.q:110` through line 115
```text
110: mutation recordVisit(move: moves, kind: enum('relevel', 'service'), visitedAt: time, notes: text <=1000 ?):
111:   require exists roles[principal = viewer, role = 'surveyor'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF 'Only a surveyor or the operations manager can record a visit.'
112:   m = moves[move] ! else NOT_FOUND
113:   require m.status != 'surveyed' else NOT_MOVED_YET 'The table must be moved before a visit is recorded.'
114:   require visitedAt <= (m.movedAt ?? 0) + 60d else VISIT_WINDOW_CLOSED 'Service visits are due within 60 days of the move.'
115:   return insert visits { move, client: m.client, kind, visitedAt, notes, recordedBy: viewer }
```
Source bundle SHA-256: `925f8faf758c6ca13eb8f77230d36446b8e0fa867cf50a99b25f0258ae755810`.

**BEFORE exact relevant matches**
- `N_CALLER_TIME` at `schema.q:115:10` (advisory; `notes[10]`): recordVisit: caller time visitedAt is bounded on only one side of a stored anchor; does the window also forbid dates before/after that anchor?

**AFTER exact relevant matches**
- `N_CALLER_TIME` at `schema.q:115:10` (advisory; `notes[10]`): recordVisit: caller time visitedAt is bounded on only one side of a stored anchor; does the window also forbid dates before/after that anchor?

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:115:10`: recordVisit: checks moves.status but leaves it unchanged while changing visits state; could repeating this transition reuse that guard?

Rationale: The caller-time question explicitly identifies the one-sided visitedAt bound and asks about the missing side of the stored anchor. Status reuse concerns a different property.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-025F1 — retained (M)

Application: `025-snapback-lifeguard-certification-exams`. Pattern: `guard-not-consumed-insert`.

Condition: retest can reuse a failed prior exam to create multiple attempt-2 rows without consuming the prior exam.

Calibration note (verbatim): retest (schema.q:166-174) never consumes the failed prior exam, so retesting attempt 1 twice yields a second attempt-2 without manager approval. Same hole as F2 (attempts not counted per candidate). Registrar bypass -> M. N_GUARD_NOT_CONSUMED skips insert transitions (lifecycle.rs:78)

Retained-question scope: retest can reuse a failed prior exam to create multiple attempt-2 rows without consuming the prior exam.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/025-snapback-lifeguard-certification-exams/snapback/schema.q:166` through line 183
```text
166: mutation retest(priorExam: exams, feeCents: int 0..20000, photo: image <=5000000):
167:   require exists roles[principal = viewer, role = 'registrar'] else NOT_REGISTRAR
168:   p = exams[priorExam] ! else NOT_FOUND
169:   require p.status = 'failed' else NOT_FAILED 'Only a failed exam can be retested.'
170:   require p.failedAt != null and now <= p.failedAt + 30d else WINDOW_CLOSED 'Retests close 30 days after failure.'
171:   require feeCents = 4000 else BAD_FEE 'A retest costs half the full fee (4000 cents).'
172:   if p.attemptNo >= 2:
173:     require exists approvals[priorExam = p.id] else NEEDS_APPROVAL 'Beyond the second attempt the manager must approve first.'
174:   return insert exams { candidate: p.candidate, status: 'booked', feeCents, attemptNo: p.attemptNo + 1, priorExam: p.id, createdAt: now, photo }
175: 
176: -- Aquatics manager approves a retest beyond the second attempt, recording the
177: -- reason and the instructor's recommendation.
178: mutation approveRetest(priorExam: exams, reason: text 10..500, recommendation: text 10..500):
179:   require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
180:   p = exams[priorExam] ! else NOT_FOUND
181:   require p.status = 'failed' else NOT_FAILED 'Only a failed exam can be approved for retest.'
182:   require p.attemptNo >= 2 else TOO_EARLY 'The second attempt needs no approval.'
183:   return insert approvals { priorExam: p.id, reason, recommendation, approvedBy: viewer, at: now }
```
Source bundle SHA-256: `b316a75e226990ad7dca291b9d34a1461ae69a0a56317eaa1704408ff711055c`.

**BEFORE exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/repeat-create/b7309e662794afc3369c6d457f05bfb258569f304777e30b79b861b211a29325/schema.q:174:10` (advisory; `notes[24]`): exams.insert: derived candidate insert only (.priorExam = null or count(exams[priorExam = .priorExam]) <= 1); a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/repeat-create/b7309e662794afc3369c6d457f05bfb258569f304777e30b79b861b211a29325/schema.q:174:10` (advisory; `notes[16]`): exams.insert: derived candidate insert only (.priorExam = null or count(exams[priorExam = .priorExam]) <= 1); a replayed violation needs a specification decision
- `N_GUARD_NOT_CONSUMED` at `schema.q:174:10` (advisory; `notes[13]`): retest: saw `((exams[priorExam]) ! else NOT_FOUND.failedAt != null and now <= (exams[priorExam]) ! else NOT_FOUND.failedAt + 2592000000); ((exams[priorExam]) ! else NOT_FOUND.status = 'failed'); (feeCents = 4000); (not ((exams[priorExam]) ! else NOT_FOUND.attemptNo >= 2) or (exists approvals[priorExam = (exams[priorExam]) ! else NOT_FOUND.id])); exists roles[principal = viewer, role = 'registrar']`; not proved: unchanged exams.status cannot authorize a repeated exams transition at schema.q:174:10

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:174:10`: retest: exams.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:183:10`: approveRetest: checks exams.status but leaves it unchanged while changing approvals state; could repeating this transition reuse that guard?

Rationale: The repeat-create derived candidate limits child exams sharing .priorExam to one. That is the duplicate-retest condition, even though baseline N_GUARD_NOT_CONSUMED does not ask it at the insert. Advice about approveRetest retaining a failed status addresses the approval record, not reuse by retest.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-025F2 — retained (M)

Application: `025-snapback-lifeguard-certification-exams`. Pattern: `approval-sibling-path-bypass`.

Condition: logExam can start another attempt-1 despite failed candidate history that requires manager approval.

Calibration note (verbatim): logExam (schema.q:129-132) opens a new attempt-1 exam for a candidate with two failures; only retest checks approvals. Same hole as F1, second path -> M (count the hole once)

Retained-question scope: logExam can start another attempt-1 despite failed candidate history that requires manager approval.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/025-snapback-lifeguard-certification-exams/snapback/schema.q:129` through line 132
```text
129: mutation logExam(candidate: principal, feeCents: int 0..20000, photo: image <=5000000):
130:   require exists roles[principal = viewer, role = 'registrar'] else NOT_REGISTRAR
131:   require feeCents = 8000 else BAD_FEE 'The full exam fee is 8000 cents.'
132:   return insert exams { candidate, status: 'booked', feeCents, attemptNo: 1, createdAt: now, photo }
```
`/home/ccheever/sb4-loop/wave26/apps/025-snapback-lifeguard-certification-exams/snapback/schema.q:166` through line 174
```text
166: mutation retest(priorExam: exams, feeCents: int 0..20000, photo: image <=5000000):
167:   require exists roles[principal = viewer, role = 'registrar'] else NOT_REGISTRAR
168:   p = exams[priorExam] ! else NOT_FOUND
169:   require p.status = 'failed' else NOT_FAILED 'Only a failed exam can be retested.'
170:   require p.failedAt != null and now <= p.failedAt + 30d else WINDOW_CLOSED 'Retests close 30 days after failure.'
171:   require feeCents = 4000 else BAD_FEE 'A retest costs half the full fee (4000 cents).'
172:   if p.attemptNo >= 2:
173:     require exists approvals[priorExam = p.id] else NEEDS_APPROVAL 'Beyond the second attempt the manager must approve first.'
174:   return insert exams { candidate: p.candidate, status: 'booked', feeCents, attemptNo: p.attemptNo + 1, priorExam: p.id, createdAt: now, photo }
```
Source bundle SHA-256: `b316a75e226990ad7dca291b9d34a1461ae69a0a56317eaa1704408ff711055c`.

**BEFORE exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/approval-history/45c341e20643b838f9d857be4564d87583029455f58518c4f61fd8cd95c51cdf/schema.q:174:10` (advisory; `notes[25]`): exams.insert: derived candidate insert only (count(exams[candidate = .candidate] where .status = 'failed' and (.failedAt != null and now <= .failedAt + 2592000000) and not (not (.attemptNo >= 2) or (exists approvals[priorExam = .id]))) = 0); a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/approval-history/45c341e20643b838f9d857be4564d87583029455f58518c4f61fd8cd95c51cdf/schema.q:174:10` (advisory; `notes[17]`): exams.insert: derived candidate insert only (count(exams[candidate = .candidate] where .status = 'failed' and (.failedAt != null and now <= .failedAt + 2592000000) and not (not (.attemptNo >= 2) or (exists approvals[priorExam = .id]))) = 0); a replayed violation needs a specification decision

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:132:10`: logExam: exams.attemptNo can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The approval-history derived insert candidate ranges over this candidate's failed exams and missing approvals, including an unrestricted fresh logExam insert. It is not limited to the retest operation despite the seed site at 174. Generic attemptNo editability is not history/count coverage.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-031F1 — retained (M)

Application: `031-snapback-ice-machine-cleanings`. Pattern: `window-base`.

Condition: scheduleCleaning bounds scheduledAt against now instead of the linked restaurant dueAt.

Calibration note (verbatim): scheduleCleaning bounds scheduledAt by now+180d (schema.q:78), not restaurants.dueAt; planner schedules past the due date without an extension. Same as wave-24 031 F1. Codex lane. 0.4.40 N_DEPENDENT_WINDOW fires at :79 (advice); one line + test: 1 witness

Retained-question scope: scheduleCleaning bounds scheduledAt against now instead of the linked restaurant dueAt.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/031-snapback-ice-machine-cleanings/snapback/schema.q:25` through line 37
```text
25: table restaurants:
26:   name: text 2..100
27:   address: text 5..200
28:   owner: principal
29:   contact: principal
30:   lastCleanedAt: time ?
31:   dueAt: time
32:   activeStop: cleanings ?
33:   createdAt: time default now
34:   immutable name, address, owner, contact, createdAt
35:   read <- .owner = viewer or exists roles[principal = viewer, role = 'planner'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'manager']
36:   insert <- exists roles[principal = viewer, role = 'planner']
37:   update <- exists roles[principal = viewer, role = 'planner'] or exists roles[principal = viewer, role = 'manager']
```
`/home/ccheever/sb4-loop/wave26/apps/031-snapback-ice-machine-cleanings/snapback/schema.q:73` through line 80
```text
73: mutation scheduleCleaning(restaurant: restaurants, technician: principal, scheduledAt: time):
74:   require exists roles[principal = viewer, role = 'planner'] else PLANNER_ONLY
75:   r = restaurants[restaurant] ! else NOT_FOUND
76:   require r.activeStop = null else STOP_ALREADY_OPEN
77:   require exists roles[principal = technician, role = 'technician'] else TECHNICIAN_ACCOUNT_REQUIRED
78:   require scheduledAt >= now - 5m and scheduledAt <= now + 180d else INVALID_SCHEDULE 'Schedule between now and 180 days ahead.'
79:   stop = insert cleanings { restaurant, owner: r.owner, restaurantName: r.name, address: r.address, technician, scheduledAt, stage: 'scheduled', descaledAt: null, sanitizedAt: null, closedAt: null, photo: null, loggedBy: null, createdBy: viewer }
80:   update restaurants[restaurant] { activeStop: stop.id }
```
Source bundle SHA-256: `7effae86bc723b4dc62968a1b551adf218ee00edddc9373fff3c655400bf5f27`.

**BEFORE exact relevant matches**
- `N_DEPENDENT_WINDOW` at `schema.q:79:10` (advisory; `notes[29]`): scheduleCleaning: bounds cleanings.scheduledAt against now but does not compare dependent restaurants.dueAt; which deadline is the specification's window base? (name-based question)

**AFTER exact relevant matches**
- `N_DEPENDENT_WINDOW` at `schema.q:79:10` (advisory; `notes[16]`): scheduleCleaning: saw `((restaurants[restaurant]) ! else NOT_FOUND.activeStop = null); (scheduledAt >= now - 300000 and scheduledAt <= now + 15552000000); exists roles[principal = technician, role = 'technician']; exists roles[principal = viewer, role = 'planner']` bounding cleanings.scheduledAt; not proved: window uses linked restaurants[restaurant].dueAt at schema.q:79:10

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:79:10`: scheduleCleaning: cleanings.scheduledAt can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The dependent-window question names cleanings.scheduledAt and linked restaurants.dueAt, exactly the wrong-base/missing-deadline question. A generic edit question at the same insert is not a substitute.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-033F1 — retained (M)

Application: `033-snapback-asphalt-sealcoating-jobs`. Pattern: `approval-not-invalidated`.

Condition: signFailing can withdraw customerConsent after approveSeal without clearing ownerApproved.

Calibration note (verbatim): approveSeal inspects customerConsent (schema.q:158-163) but signFailing (:151-155) can withdraw consent afterwards and ownerApproved stays true; crew then seals. 0.4.40 derived approve/edit contracts skip Bool inputs (derived.rs:75). N_APPROVAL_NOT_ENFORCED at :148 is misdirected. One line + test: 8 witnesses

Retained-question scope: signFailing can withdraw customerConsent after approveSeal without clearing ownerApproved.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/033-snapback-asphalt-sealcoating-jobs/snapback/schema.q:151` through line 175
```text
151: mutation signFailing(job: jobs, consent: bool):
152:   j = jobs[job] ! else NOT_FOUND
153:   require j.customer = viewer else NOT_YOUR_JOB
154:   require j.status != 'lapsed' and j.status != 'striped' else BAD_STATE
155:   update jobs[job] { customerSignedFailing: true, customerConsent: consent }
156:   return null
157: 
158: mutation approveSeal(job: jobs):
159:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
160:   j = jobs[job] ! else NOT_FOUND
161:   require j.customerSignedFailing else NO_SIGNOFF
162:   require j.customerConsent else NO_CONSENT
163:   update jobs[job] { ownerApproved: true }
164:   return null
165: 
166: mutation advanceStatus(job: jobs, to: enum('booked', 'crack_filling', 'sealing', 'striped')):
167:   require exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'estimator'] or exists roles[principal = viewer, role = 'owner'] else NOT_STAFF
168:   j = jobs[job] ! else NOT_FOUND
169:   require (j.status = 'booked' and to = 'crack_filling') or (j.status = 'crack_filling' and to = 'sealing') or (j.status = 'sealing' and to = 'striped') else BAD_TRANSITION 'Jobs move booked to crack filling to sealing to striped.'
170:   if to = 'sealing' and (j.surfaceFailing or j.customerSignedFailing):
171:     require j.ownerApproved else NEEDS_OWNER_APPROVAL 'Only the owner may approve sealing over a failing surface.'
172:   if to = 'striped':
173:     update jobs[job] { status: to, sealedAt: now }
174:   else:
175:     update jobs[job] { status: to }
```
Source bundle SHA-256: `7831c89e12a191e46587e6be1d20b332c692171aaa163f00b5539d23581963d6`.

**BEFORE exact relevant matches**
- `N_EDIT_AFTER_APPROVAL` at `schema.q:155:3` (advisory; `notes[19]`): signFailing: jobs.customerConsent can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/schema.q/jobs/customerConsent/update/04b2ecb27d3684a813d41b3f372641835e68a8052b867ce412764f8d78088489:163:3` (advisory; `notes[31]`): jobs.customerConsent update: derived candidate update only old.ownerApproved != true or next.ownerApproved != true; a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/schema.q/jobs/customerConsent/update/04b2ecb27d3684a813d41b3f372641835e68a8052b867ce412764f8d78088489:163:3` (advisory; `notes[14]`): jobs.customerConsent update: derived candidate update only old.ownerApproved != true or next.ownerApproved != true; a replayed violation needs a specification decision

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:173:5`: advanceStatus: checks jobs.ownerApproved but leaves it unchanged while changing state; could repeating this transition reuse the same authorization?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:175:5`: advanceStatus: checks jobs.ownerApproved but leaves it unchanged while changing state; could repeating this transition reuse the same authorization?

Rationale: The baseline consent edit question and derived consent update candidate address changing approved input while ownerApproved stays true. The derived expression requires old.ownerApproved != true or next.ownerApproved != true. Approval reuse on advanceStatus is a different question. Loss of a particular selected diagnostic is recorded without calling the hole lost if the exact derived question remains.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-033F2 — retained (M)

Application: `033-snapback-asphalt-sealcoating-jobs`. Pattern: `child-evidence-not-required`.

Condition: acceptQuote and advanceStatus can proceed with no photos child row.

Calibration note (verbatim): openJob takes no photos; acceptQuote/advanceStatus never require photos[job] (schema.q:134-148, :166-175). Same as wave-24 033 F1. 0.4.40 N_CHILD_EVIDENCE_PRESENCE fires at :148 (advice); one line + test: 36 witnesses

Retained-question scope: acceptQuote and advanceStatus can proceed with no photos child row.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/033-snapback-asphalt-sealcoating-jobs/snapback/schema.q:134` through line 148
```text
134: mutation openJob(customer: principal, address: text 1..200, notes: text <=1000 ?, quotedCents: int 0..100000000, surfaceFailing: bool):
135:   require exists roles[principal = viewer, role = 'estimator'] or exists roles[principal = viewer, role = 'owner'] else NOT_ESTIMATOR
136:   return insert jobs { customer, address, notes, quotedCents, quotedAt: now, status: 'quoted', surfaceFailing }
137: 
138: mutation addPhoto(job: jobs, caption: text 1..120, photo: image <=10000000):
139:   require exists roles[principal = viewer, role = 'estimator'] or exists roles[principal = viewer, role = 'owner'] else NOT_ESTIMATOR
140:   j = jobs[job] ! else NOT_FOUND
141:   return insert photos { job: j.id, caption, photo }
142: 
143: mutation acceptQuote(job: jobs):
144:   j = jobs[job] ! else NOT_FOUND
145:   require j.customer = viewer else NOT_YOUR_JOB
146:   require j.status = 'quoted' else NOT_QUOTED
147:   require j.quotedAt + 14d >= now else QUOTE_LAPSED 'The 14-day quote window has passed.'
148:   update jobs[job] { status: 'booked' }
```
`/home/ccheever/sb4-loop/wave26/apps/033-snapback-asphalt-sealcoating-jobs/snapback/schema.q:166` through line 175
```text
166: mutation advanceStatus(job: jobs, to: enum('booked', 'crack_filling', 'sealing', 'striped')):
167:   require exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'estimator'] or exists roles[principal = viewer, role = 'owner'] else NOT_STAFF
168:   j = jobs[job] ! else NOT_FOUND
169:   require (j.status = 'booked' and to = 'crack_filling') or (j.status = 'crack_filling' and to = 'sealing') or (j.status = 'sealing' and to = 'striped') else BAD_TRANSITION 'Jobs move booked to crack filling to sealing to striped.'
170:   if to = 'sealing' and (j.surfaceFailing or j.customerSignedFailing):
171:     require j.ownerApproved else NEEDS_OWNER_APPROVAL 'Only the owner may approve sealing over a failing surface.'
172:   if to = 'striped':
173:     update jobs[job] { status: to, sealedAt: now }
174:   else:
175:     update jobs[job] { status: to }
```
Source bundle SHA-256: `7831c89e12a191e46587e6be1d20b332c692171aaa163f00b5539d23581963d6`.

**BEFORE exact relevant matches**
- `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:148:3` (advisory; `notes[12]`): jobs: transitions acceptQuote, advanceStatus do not require attached photos[job = parent].photo; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

**AFTER exact relevant matches**
- `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:148:3` (advisory; `notes[11]`): jobs: transitions acceptQuote, advanceStatus do not require attached photos[job = parent].photo; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The child-evidence question names the missing photos[job = parent].photo existence requirement and both affected transitions. The separate reports.photo question is not used.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-033F3 — uncovered_before (L)

Application: `033-snapback-asphalt-sealcoating-jobs`. Pattern: `approval-checked-at-entry-only`.

Condition: A new failing sign-off during sealing is not re-gated before the striped transition.

Calibration note (verbatim): a failing sign-off arriving during sealing is not re-gated before striped (schema.q:171-172); approval governs entering sealing, spec silent on mid-seal sign-offs -> L

Retained-question scope: A new failing sign-off during sealing is not re-gated before the striped transition.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/033-snapback-asphalt-sealcoating-jobs/snapback/schema.q:151` through line 175
```text
151: mutation signFailing(job: jobs, consent: bool):
152:   j = jobs[job] ! else NOT_FOUND
153:   require j.customer = viewer else NOT_YOUR_JOB
154:   require j.status != 'lapsed' and j.status != 'striped' else BAD_STATE
155:   update jobs[job] { customerSignedFailing: true, customerConsent: consent }
156:   return null
157: 
158: mutation approveSeal(job: jobs):
159:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
160:   j = jobs[job] ! else NOT_FOUND
161:   require j.customerSignedFailing else NO_SIGNOFF
162:   require j.customerConsent else NO_CONSENT
163:   update jobs[job] { ownerApproved: true }
164:   return null
165: 
166: mutation advanceStatus(job: jobs, to: enum('booked', 'crack_filling', 'sealing', 'striped')):
167:   require exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'estimator'] or exists roles[principal = viewer, role = 'owner'] else NOT_STAFF
168:   j = jobs[job] ! else NOT_FOUND
169:   require (j.status = 'booked' and to = 'crack_filling') or (j.status = 'crack_filling' and to = 'sealing') or (j.status = 'sealing' and to = 'striped') else BAD_TRANSITION 'Jobs move booked to crack filling to sealing to striped.'
170:   if to = 'sealing' and (j.surfaceFailing or j.customerSignedFailing):
171:     require j.ownerApproved else NEEDS_OWNER_APPROVAL 'Only the owner may approve sealing over a failing surface.'
172:   if to = 'striped':
173:     update jobs[job] { status: to, sealedAt: now }
174:   else:
175:     update jobs[job] { status: to }
```
Source bundle SHA-256: `7831c89e12a191e46587e6be1d20b332c692171aaa163f00b5539d23581963d6`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:173:5`: advanceStatus: jobs.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:173:5`: advanceStatus: checks jobs.ownerApproved but leaves it unchanged while changing state; could repeating this transition reuse the same authorization?
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:175:5`: advanceStatus: jobs.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:175:5`: advanceStatus: checks jobs.ownerApproved but leaves it unchanged while changing state; could repeating this transition reuse the same authorization?

Rationale: Generic reuse/editability questions do not name rechecking approval after a new mid-sealing sign-off on the striped path. The derived customerConsent invalidation candidate covers F1, not the newly required sign-off/approval checkpoint in F3.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w26-034F1 — retained (L)

Application: `034-snapback-luxury-watch-servicing`. Pattern: `existence-oracle-unique`.

Condition: Global serial uniqueness over private watches can reveal another owner's registered serial.

Calibration note (verbatim): global `unique serial` (schema.q:25) over owner-only rows lets owner B test whether a serial is registered (E_RULE vs sent). Class c; N_UNIQUE_HIDDEN does not fire here (write_affordances.rs:104). Same scale as wave-24 Convex 015 F1/F2 (L)

Retained-question scope: Global serial uniqueness over private watches can reveal another owner's registered serial.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/034-snapback-luxury-watch-servicing/snapback/schema.q:18` through line 29
```text
18: table watches:
19:   owner: principal
20:   brand: text 1..40
21:   model: text 1..40
22:   serial: text 1..30
23:   createdAt: time default now
24:   immutable owner
25:   unique serial
26:   read <- .owner = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'watchmaker'] or exists roles[principal = viewer, role = 'workshop_owner']
27:   insert <- .owner = viewer
28:   update <- .owner = viewer
29:   delete <- .owner = viewer
```
Source bundle SHA-256: `6757181e00411e97a24fb4afc753b2d4af320bb388b2a08732f7aa9f7d77bb64`.

**BEFORE exact relevant matches**
- `N_UNIQUE_HIDDEN` at `schema.q:18:1` (advisory; `notes[8]`): watches: global unique serial omits owner scope owner; could a private-row conflict expose that another owner already holds this value?

**AFTER exact relevant matches**
- `N_UNIQUE_HIDDEN` at `schema.q:18:1` (advisory; `notes[8]`): watches: global unique serial omits owner scope owner; could a private-row conflict expose that another owner already holds this value?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The unique-hidden question explicitly names global serial uniqueness, omitted owner scope, and disclosure of another owner holding the value.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-036F1 — retained (M)

Application: `036-snapback-bronze-statue-casting`. Pattern: `approval-not-enforced`.

Condition: advanceStage can progress a casting without reading modelApprovedAt.

Calibration note (verbatim): advanceStage (schema.q:110-128) never requires modelApprovedAt; the 60-day cancellation runs only inside approveModel (:98-105). Worker bypass -> M. N_APPROVAL_NOT_ENFORCED is Bool-only (lifecycle.rs:46); 0.4.40 test does not cover advanceStage (multiple target writes)

Retained-question scope: advanceStage can progress a casting without reading modelApprovedAt.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/036-snapback-bronze-statue-casting/snapback/schema.q:98` through line 127
```text
98: mutation approveModel(casting: castings):
99:   require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
100:   c = castings[casting] ! else NOT_FOUND
101:   require c.stage = 'molding' else BAD_STAGE
102:   if c.unveilingAt - now >= 60d:
103:     update castings[casting] { modelApprovedAt: now }
104:   else:
105:     update castings[casting] { stage: 'cancelled', depositKept: true }
106:   return null
107: 
108: -- Foundry workers move castings along the board: molding to wax, pouring,
109: -- patina, then delivered.
110: mutation advanceStage(casting: castings, stage: enum('wax', 'pouring', 'patina', 'delivered')):
111:   require exists roles[principal = viewer, role = 'worker'] else NOT_WORKER
112:   c = castings[casting] ! else NOT_FOUND
113:   require c.stage != 'cancelled' and c.stage != 'delivered' else BAD_STAGE
114:   if stage = 'wax':
115:     require c.stage = 'molding' else BAD_TRANSITION
116:     update castings[casting] { stage }
117:   else:
118:     if stage = 'pouring':
119:       require c.stage = 'wax' else BAD_TRANSITION
120:       update castings[casting] { stage }
121:     else:
122:       if stage = 'patina':
123:         require c.stage = 'pouring' else BAD_TRANSITION
124:         update castings[casting] { stage }
125:       else:
126:         require c.stage = 'patina' else BAD_TRANSITION
127:         update castings[casting] { stage, deliveredAt: now }
```
Source bundle SHA-256: `a31a094e048c389b4a2876d1b80f5be020c2ce991462ccc599c5786b542fecec`.

**BEFORE exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:116:5` (advisory; `notes[8]`): castings.modelApprovedAt: a modeled advanceStage effect can proceed without reading this recorded approval

**AFTER exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:116:5` (advisory; `notes[7]`): castings.modelApprovedAt: a modeled advanceStage effect can proceed without reading this recorded approval

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:116:5`: advanceStage: castings.stage can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The approval diagnostic names the missing modelApprovedAt read and advanceStage. This retains the approval prerequisite question, not a separate proof of the 60-day cancellation policy.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-045F1 — retained (M)

Application: `045-snapback-storm-shelter-installs`. Pattern: `reason-whitespace`.

Condition: decideClaim accepts a whitespace crew-lead assessment because assessment is only compared with empty text.

Calibration note (verbatim): decideClaim accepts a whitespace crew-lead assessment (`text 1..N` counts spaces; schema.q:152-160). Same scale as Convex 009 F3, 024 F5, 044 F5 (whitespace reasons, M)

Retained-question scope: decideClaim accepts a whitespace crew-lead assessment because assessment is only compared with empty text.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/045-snapback-storm-shelter-installs/snapback/schema.q:152` through line 160
```text
152: mutation decideClaim(claim: claims, decision: enum('approved', 'rejected'), reason: text 1..500, crewLeadAssessment: text <=1000 ?):
153:   me = roles[viewer] ! else NOT_ENROLLED
154:   cl = claims[claim] ! else NOT_FOUND
155:   require cl.status = 'pending' or cl.status = 'assessed' else BAD_STATUS
156:   require cl.location != 'outside' or me.role = 'operations_manager' else ONLY_OPS_MANAGER
157:   require cl.location = 'outside' or me.role = 'estimator' or me.role = 'operations_manager' else NOT_PERMITTED
158:   assessment = crewLeadAssessment ?? cl.crewAssessment ?? ''
159:   require cl.location != 'outside' or assessment != '' else NEED_ASSESSMENT
160:   update claims[claim] { status: decision, decisionReason: reason, decidedBy: viewer, crewAssessment: assessment if cl.location = 'outside' else cl.crewAssessment }
```
Source bundle SHA-256: `0b2bbdf528d296c72f7b6fef6ac03e6123e199c22a111687baa27799244a9685`.

**BEFORE exact relevant matches**
- `N_BLANK_TEXT_GUARD` at `schema.q:160:3` (advisory; `notes[17]`): decideClaim: a reason/consent/assessment is compared with empty text but whitespace still passes; is nonblank evidence required?

**AFTER exact relevant matches**
- `N_BLANK_TEXT_GUARD` at `schema.q:160:3` (advisory; `notes[4]`): decideClaim: a reason/consent/assessment is compared with empty text but whitespace still passes; is nonblank evidence required?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The blank-text question names decideClaim and whitespace passing an empty-text assessment check, the precise missing nonblank condition.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-046F1 — retained (M)

Application: `046-snapback-sump-pump-repairs`. Pattern: `approval-not-enforced`.

Condition: installPart can install a backup without the separately authorized backupApprovals record/consent.

Calibration note (verbatim): approveBackup only inserts backupApprovals (schema.q:154-158); installPart (:144-147) takes any part name, so a plumber installs a backup pump with no approval or consent. Trusted-staff bypass -> M (wave-24 036 F2 rule). Approval is a table, so N_APPROVAL_NOT_ENFORCED cannot fire (lifecycle.rs:46)

Retained-question scope: installPart can install a backup without the separately authorized backupApprovals record/consent.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/046-snapback-sump-pump-repairs/snapback/schema.q:144` through line 158
```text
144: mutation installPart(job: jobs, name: text 1..80):
145:   require exists roles[principal = viewer, role = 'plumber'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
146:   j = jobs[job] ! else NOT_FOUND
147:   return insert parts { job, customer: j.customer, name }
148: 
149: mutation createInvoice(job: jobs, amount: money USD):
150:   require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'manager'] else NOT_OFFICE
151:   j = jobs[job] ! else NOT_FOUND
152:   return insert invoices { job, customer: j.customer, amount }
153: 
154: mutation approveBackup(job: jobs, consent: text 1..500):
155:   require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
156:   j = jobs[job] ! else NOT_FOUND
157:   require j.requested = 'repair' else NOT_REPAIR_ONLY 'Backup approval applies only when the customer asked for a repair.'
158:   return insert backupApprovals { job, customer: j.customer, consent, approvedBy: viewer }
```
Source bundle SHA-256: `37c20618ebbe4e7d97999c78d06baa7f1d904084e38d1d64dd60aa6900ff1edd`.

**BEFORE exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:158:10` (advisory; `notes[10]`): backupApprovals.job: a separately authorized approval for jobs is recorded but a modeled effect does not require it

**AFTER exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:158:10` (advisory; `notes[9]`): backupApprovals.job: a separately authorized approval for jobs is recorded but a modeled effect does not require it

**Broad/nearby questions excluded from coverage**
- baseline: `N_APPROVAL_INFORMATIONAL` at `schema.q:158:10`: backupApprovals.approvedAt: informational record; no operation models the approved act, so there is no inferred pending-effect gate
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:158:10`: approveBackup: checks jobs.requested but leaves it unchanged while changing backupApprovals state; could repeating this transition reuse that guard?
- final: `N_APPROVAL_INFORMATIONAL` at `schema.q:158:10`: backupApprovals.approvedAt: informational record; no operation models the approved act, so there is no inferred pending-effect gate

Rationale: The approval-table diagnostic says a separately authorized approval for jobs is recorded but a modeled effect does not require it. In this source installPart is the part-install effect and never probes backupApprovals. It retains the approval-enforcement question, without inferring a backup-name gate or proving consent validity.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w26-049F1 — retained (M)

Application: `049-snapback-wedding-dj-bookings`. Pattern: `media-carries-private-fields`.

Condition: A signed contract image is readable by DJs even though phone, price and deposit columns are hidden from them.

Calibration note (verbatim): contract image (schema.q:34) has no column read rule, so every DJ (:38) fetches the signed scan whose text carries the phone/price/deposit the column rules hide (:25-27). The couple's own read is d. Spec names the scan's opening, not its audience -> M, not H. Convex 049 F4 (DJ gets phone/price in a mutation return) is a direct field leak (H). One line + 0.4.40 test: 12 witnesses

Retained-question scope: A signed contract image is readable by DJs even though phone, price and deposit columns are hidden from them.

Source evidence:
`/home/ccheever/sb4-loop/wave26/apps/049-snapback-wedding-dj-bookings/snapback/schema.q:24` through line 39
```text
24:   coupleName: text 1..120
25:   phone: text 1..40 read <- exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'desk']
26:   price: money USD read <- exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'desk']
27:   deposit: money USD read <- exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'desk']
28:   weddingAt: time
29:   status: enum('planned', 'packed', 'playing', 'packed_down') default 'planned'
30:   songRequests: text <=2000 ?
31:   finalSongs: text 1..5000 ?
32:   timeline: text <=5000 ?
33:   venueNotes: text <=5000 ?
34:   contract: image <=10000000
35:   extraHour: bool default false
36:   extraHourReason: text 1..500 ?
37:   immutable couple, weddingAt, contract
38:   read <- .couple = viewer or exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'desk'] or exists roles[principal = viewer, role = 'dj']
39:   insert <- (exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'desk']) and exists roles[.couple, role = 'couple']
```
Source bundle SHA-256: `3b4c171310ce8bb73121a8e9ae7df590c042963821f7fa9205796f6153c3530c`.

**BEFORE exact relevant matches**
- `N_MEDIA_PRIVATE_FIELDS` at `schema.q:34:3` (advisory; `notes[10]`): bookings.contract: media has a broader audience than deposit, phone, price; can this scan expose those private fields?

**AFTER exact relevant matches**
- `N_MEDIA_PRIVATE_FIELDS` at `schema.q:34:3` (advisory; `notes[9]`): bookings.contract: media has a broader audience than deposit, phone, price; can this scan expose those private fields?

**Broad/nearby questions excluded from coverage**
- baseline: `N_INVARIANT_RESTATES_RULE` at `schema.q:44:1`: bookings.read matches or weakens current enforcement. Rule bookings.read admits a caller satisfying viewer = .couple under `.couple = viewer` (row conditions on .couple). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule bookings.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule bookings.read admits roles.role = 'desk' under `exists roles[viewer, role = 'desk']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule bookings.read admits roles.role = 'dj' under `exists roles[viewer, role = 'dj']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- final: `N_INVARIANT_RESTATES_RULE` at `schema.q:44:1`: bookings.read matches or weakens current enforcement. Rule bookings.read admits a caller satisfying viewer = .couple under `.couple = viewer` (row conditions on .couple). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule bookings.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule bookings.read admits roles.role = 'desk' under `exists roles[viewer, role = 'desk']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule bookings.read admits roles.role = 'dj' under `exists roles[viewer, role = 'dj']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?

Rationale: The media-private-fields question names the contract scan and the broader audience than deposit, phone and price. The general bookings audience question alone would not identify information carried inside the image.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-011F1 — retained (M)

Application: `011-snapback-home-battery-installs`. Pattern: `approval-not-enforced-bool`.

Condition: recordInstallation omits indoorMount/indoorApproved owner-approval gating.

Calibration note (verbatim): recordInstallation (schema.q:113-119) never reads indoorMount/indoorApproved; approveIndoorMount (:135-141) only records. An electrician installs indoors without the owner's approval (staff bypass = M). The builder acknowledged the 0.4.41 approval question as 'not a gate on work progress' (security-reviews.json)

Retained-question scope: recordInstallation omits indoorMount/indoorApproved owner-approval gating.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/011-snapback-home-battery-installs/snapback/schema.q:93` through line 118
```text
93: mutation openInstall(homeowner: principal, address: text 1..200, assessment: image <=10000000, price: money USD, indoorMount: bool):
94:   require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only coordinators may open installs.'
95:   return insert installs { homeowner, coordinator: viewer, address, assessment, price, indoorMount }
96: 
97: mutation acceptQuote(install: installs):
98:   inst = installs[install] ! else NOT_FOUND
99:   require inst.homeowner = viewer else NOT_YOUR_INSTALL 'This install belongs to another homeowner.'
100:   require inst.quoteStatus = 'pending' else QUOTE_NOT_PENDING 'This quote is no longer pending.'
101:   require now <= inst.quotedAt + 21d else QUOTE_EXPIRED 'The 21-day acceptance window has passed.'
102:   update installs[install] { quoteStatus: 'accepted', acceptedAt: now }
103:   return null
104: 
105: mutation startWiring(install: installs):
106:   require exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'electrician'] else NOT_STAFF 'Only coordinators or electricians may start wiring.'
107:   inst = installs[install] ! else NOT_FOUND
108:   require inst.quoteStatus = 'accepted' else QUOTE_NOT_ACCEPTED 'The quote must be accepted before work begins.'
109:   require inst.stage = 'survey' else BAD_STAGE 'Wiring starts from the survey stage.'
110:   update installs[install] { stage: 'wiring' }
111:   return null
112: 
113: mutation recordInstallation(install: installs):
114:   require exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'electrician'] else NOT_STAFF 'Only coordinators or electricians may record an installation.'
115:   inst = installs[install] ! else NOT_FOUND
116:   require inst.quoteStatus = 'accepted' else QUOTE_NOT_ACCEPTED 'The quote must be accepted before work begins.'
117:   require inst.stage = 'wiring' else BAD_STAGE 'Record the installation from the wiring stage.'
118:   update installs[install] { stage: 'inspection', installedAt: now, awaitingInspection: true }
```
`/home/ccheever/sb4-loop/wave28/apps/011-snapback-home-battery-installs/snapback/schema.q:128` through line 140
```text
128: mutation requestIndoorMount(install: installs):
129:   require exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'electrician'] else NOT_STAFF 'Only coordinators or electricians may request an indoor mount.'
130:   inst = installs[install] ! else NOT_FOUND
131:   require inst.indoorMount = false else ALREADY_REQUESTED 'An indoor mount was already requested for this install.'
132:   update installs[install] { indoorMount: true }
133:   return null
134: 
135: mutation approveIndoorMount(install: installs, consent: text 1..500):
136:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER 'Only the company owner may approve an indoor mount.'
137:   inst = installs[install] ! else NOT_FOUND
138:   require inst.indoorMount = true else NOT_REQUESTED 'No indoor mount was requested for this install.'
139:   require inst.indoorApproved = false else ALREADY_APPROVED 'This indoor mount was already approved.'
140:   update installs[install] { indoorApproved: true, indoorConsent: consent }
```
Source bundle SHA-256: `f2cdd1cbadfd2c286898f8474d6c9fde23811b7a5f3401766b5023f89accc62d`.

**BEFORE exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:102:3` (recorded_gate; `gates[0]`): installs.indoorApproved: a modeled acceptQuote effect can proceed without reading this recorded approval
  Attached candidate question: `invariant installs.recordInstallation only (not .indoorMount or .indoorApproved)`. No replay verdict counted.

**AFTER exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:102:3` (recorded_gate; `gates[0]`): installs.indoorApproved: a modeled acceptQuote effect can proceed without reading this recorded approval
  Attached candidate question: `invariant installs.recordInstallation only (not .indoorMount or .indoorApproved)`. No replay verdict counted.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:118:3`: recordInstallation: installs.stage can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_APPROVAL_NOT_ENFORCED` at `schema.q:102:3`: installs.indoorApproved: a modeled acceptQuote effect can proceed without reading this recorded approval
- final: `N_APPROVAL_NOT_ENFORCED` at `schema.q:102:3`: installs.indoorApproved: a modeled acceptQuote effect can proceed without reading this recorded approval

Rationale: The diagnostic names indoorApproved but its message/site misleadingly call the effect acceptQuote at 102. The supplied gate metadata explicitly carries candidate `invariant installs.recordInstallation only (not .indoorMount or .indoorApproved)`, so the same relevant installation question is present. Only that question expression is used; no witness, reachability or gate-coverage claim is made.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-011F2 — retained (M)

Application: `011-snapback-home-battery-installs`. Pattern: `unvalidated-principal-argument`.

Condition: openInstall accepts an unvalidated homeowner principal, letting the coordinator name itself and accept its quote.

Calibration note (verbatim): openInstall (schema.q:93-95) stores any principal as homeowner; the coordinator names itself and accepts its own quote (acceptQuote :97-103). The builder acknowledged N_ARGUMENT_GRANT with 'a mis-addressed quote can never be accepted', which is false

Retained-question scope: openInstall accepts an unvalidated homeowner principal, letting the coordinator name itself and accept its quote.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/011-snapback-home-battery-installs/snapback/schema.q:93` through line 103
```text
93: mutation openInstall(homeowner: principal, address: text 1..200, assessment: image <=10000000, price: money USD, indoorMount: bool):
94:   require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only coordinators may open installs.'
95:   return insert installs { homeowner, coordinator: viewer, address, assessment, price, indoorMount }
96: 
97: mutation acceptQuote(install: installs):
98:   inst = installs[install] ! else NOT_FOUND
99:   require inst.homeowner = viewer else NOT_YOUR_INSTALL 'This install belongs to another homeowner.'
100:   require inst.quoteStatus = 'pending' else QUOTE_NOT_PENDING 'This quote is no longer pending.'
101:   require now <= inst.quotedAt + 21d else QUOTE_EXPIRED 'The 21-day acceptance window has passed.'
102:   update installs[install] { quoteStatus: 'accepted', acceptedAt: now }
103:   return null
```
Source bundle SHA-256: `f2cdd1cbadfd2c286898f8474d6c9fde23811b7a5f3401766b5023f89accc62d`.

**BEFORE exact relevant matches**
- `N_ARGUMENT_GRANT` at `schema.q:95:10` (advisory; `notes[11]`): openInstall writes argument homeowner straight into reader-grant column installs.homeowner

**AFTER exact relevant matches**
- `N_ARGUMENT_GRANT` at `schema.q:95:10` (advisory; `notes[9]`): openInstall: saw `exists roles[principal = viewer, role = 'coordinator']`; not proved: recipient role/relationship at schema.q:95:10; writes argument homeowner straight into reader-grant column installs.homeowner

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:95:10`: openInstall: installs.homeowner can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The argument-grant question names openInstall's direct homeowner write into the reader-grant column. It asks about validating exactly the principal that later satisfies inst.homeowner = viewer.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-013F1 — uncovered_before (M)

Application: `013-snapback-lifting-sling-inspections`. Pattern: `approval-not-enforced-table`.

Condition: requestLift ignores repaired-fittings/chief return-to-service approval and checks only inspection age and ownership.

Calibration note (verbatim): requestLift (schema.q:129-134) checks only inspection age; the chief's returns table (:65-77, returnToService :120-125) is read by nothing, so a repaired sling lifts with no chief approval. Wave-26 046 shape (approval table)

Retained-question scope: requestLift ignores repaired-fittings/chief return-to-service approval and checks only inspection age and ownership.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/013-snapback-lifting-sling-inspections/snapback/schema.q:111` through line 134
```text
111: -- A shop inspector records that the sling's fittings were repaired.
112: mutation markRepaired(sling: slings, repaired: bool):
113:   require exists roles[viewer, role = 'inspector'] else NOT_INSPECTOR 'Only shop inspectors mark repaired fittings.'
114:   s = slings[sling] ! else NOT_FOUND
115:   update slings[sling] { repairedFittings: repaired }
116:   return null
117: 
118: -- Only the chief inspector approves returning a sling to service,
119: -- recording the test certificate and the reason.
120: mutation returnToService(sling: slings, certificate: text 4..120, reason: text 10..500):
121:   require exists roles[viewer, role = 'chief'] else NOT_CHIEF 'Only the chief inspector returns slings to service.'
122:   s = slings[sling] ! else NOT_FOUND
123:   require s.status = 'tagged' else BAD_STATUS 'Only tagged slings may return to service.'
124:   update slings[sling] { status: 'in_service' }
125:   return insert returns { sling, owner: s.owner, chief: viewer, certificate, reason }
126: 
127: -- A crew asks whether its own sling may lift. A sling whose last inspection
128: -- is older than 12 months (365 days) is refused for lifting.
129: mutation requestLift(sling: slings):
130:   require exists roles[viewer, role = 'crew'] else NOT_CREW 'Only crane crews request lifts.'
131:   s = slings[sling] ! else NOT_FOUND
132:   require s.owner = viewer else NOT_OWNER 'Crews may lift only their own slings.'
133:   require now - (s.lastInspectionAt ?? 0) <= 365d else SLING_OVERDUE 'The last inspection is older than 12 months; this sling is refused for lifting.'
134:   return null
```
Source bundle SHA-256: `60ec4b92071ebc205868e44306f8a4fc1a990d41c1b49043426d8ca86b223d33`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:108:3`: slings: transitions advanceSling, returnToService do not require attached inspections[sling = parent].tagPhoto; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.
- final: `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:108:3`: slings: transitions advanceSling, returnToService do not require attached inspections[sling = parent].tagPhoto; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

Rationale: The nearby child-evidence question requires inspections.tagPhoto before advanceSling/returnToService. It does not ask whether requestLift requires the chief's returns approval or in_service status. There is no exact baseline question.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-013F2 — uncovered_before (M)

Application: `013-snapback-lifting-sling-inspections`. Pattern: `guard-on-one-path-only`.

Condition: advanceSling received-to-examined omits the old-chain proof-test prerequisite present on logInspection.

Calibration note (verbatim): the >10-year chain proof-test prerequisite is on logInspection (:91) but advanceSling (:104-109) moves received->examined without it. Sibling-path shape (wave-26 018 F1)

Retained-question scope: advanceSling received-to-examined omits the old-chain proof-test prerequisite present on logInspection.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/013-snapback-lifting-sling-inspections/snapback/schema.q:87` through line 108
```text
87: mutation logInspection(sling: slings, tagPhoto: image <=5000000, price: money USD, notes: text <=500 ?):
88:   require exists roles[viewer, role = 'counter'] else NOT_COUNTER 'Only the counter inspector logs inspections.'
89:   s = slings[sling] ! else NOT_FOUND
90:   require price > 0 else BAD_PRICE 'The inspection price must be positive.'
91:   require s.kind != 'chain' or now - s.manufacturedAt <= 3650d or s.lastProofTestAt != null else NEEDS_PROOF_TEST 'A chain sling older than 10 years must be proof tested before any inspection.'
92:   update slings[sling] { lastInspectionAt: now }
93:   return insert inspections { sling, owner: s.owner, inspector: viewer, tagPhoto, price, notes }
94: 
95: -- A shop inspector proof tests a sling and records the certificate.
96: mutation logProofTest(sling: slings, certificate: text 4..120):
97:   require exists roles[viewer, role = 'inspector'] else NOT_INSPECTOR 'Only shop inspectors proof test slings.'
98:   s = slings[sling] ! else NOT_FOUND
99:   update slings[sling] { lastProofTestAt: now }
100:   return insert proofTests { sling, owner: s.owner, tester: viewer, certificate }
101: 
102: -- A shop inspector moves a sling along the board: received -> examined ->
103: -- load tested -> tagged. Returning to service is the chief's approval.
104: mutation advanceSling(sling: slings, status: enum('examined', 'load_tested', 'tagged')):
105:   require exists roles[viewer, role = 'inspector'] else NOT_INSPECTOR 'Only shop inspectors move slings along the board.'
106:   s = slings[sling] ! else NOT_FOUND
107:   require (s.status = 'received' and status = 'examined') or (s.status = 'examined' and status = 'load_tested') or (s.status = 'load_tested' and status = 'tagged') else BAD_TRANSITION 'Slings move received -> examined -> load tested -> tagged, one step at a time.'
108:   update slings[sling] { status }
```
Source bundle SHA-256: `60ec4b92071ebc205868e44306f8a4fc1a990d41c1b49043426d8ca86b223d33`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:108:3`: slings: transitions advanceSling, returnToService do not require attached inspections[sling = parent].tagPhoto; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:93:10`: logInspection: checks slings.kind but leaves it unchanged while changing inspections state; could repeating this transition reuse that guard?
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:108:3`: advanceSling: slings.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- final: `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:108:3`: slings: transitions advanceSling, returnToService do not require attached inspections[sling = parent].tagPhoto; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

Rationale: An inspection photo requirement is not the age/kind-dependent lastProofTestAt requirement. The standing kind guard reuse question and generic status edit question do not identify this sibling-path prerequisite.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-015F1 — retained (L)

Application: `015-snapback-mobility-scooter-rentals`. Pattern: `board-audience-too-wide`.

Condition: serviceBoard exposes other renters' service events, including handledBy, to every renter role.

Calibration note (verbatim): serviceEvents read <- exists roles[principal = viewer] (:86) and serviceBoard (:118-119) show every role, including renters, other renters' return events with handledBy principal

Retained-question scope: serviceBoard exposes other renters' service events, including handledBy, to every renter role.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/015-snapback-mobility-scooter-rentals/snapback/schema.q:80` through line 88
```text
80: table serviceEvents:
81:   scooter: scooters
82:   stage: enum('returned', 'cleaned', 'charged', 'ready')
83:   at: time default now
84:   handledBy: principal
85:   immutable scooter, stage, at, handledBy
86:   read <- exists roles[principal = viewer]
87:   insert <- exists roles[principal = viewer]
88:   online only
```
`/home/ccheever/sb4-loop/wave28/apps/015-snapback-mobility-scooter-rentals/snapback/schema.q:118` through line 119
```text
118: query serviceBoard(c: cursor ?):
119:   return serviceEvents last 100 by .id after c
```
Source bundle SHA-256: `e0bbe115a3fc3f838148b2222ebc538c94a993136bcab15f97320746ec0c4ca5`.

**BEFORE exact relevant matches**
- `N_BROAD_READ` at `schema.q:86:3` (advisory; `notes[9]`): serviceEvents.read: branch `exists roles[viewer]` lets every roles member (roles: desk, manager, renter, technician) read every row, regardless of ownership

**AFTER exact relevant matches**
- `N_BROAD_READ` at `schema.q:86:3` (advisory; `notes[9]`): serviceEvents.read: branch `exists roles[viewer]` lets every roles member (roles: desk, manager, renter, technician) read every row, regardless of ownership

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The broad-read diagnostic is specific here: it names serviceEvents, enumerates renter among the admitted roles, and says every row is readable regardless of ownership. Those are the actual missing audience restriction and cross-renter rows, unlike generic lifecycle policy advice.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-019F1 — retained (M)

Application: `019-snapback-mature-tree-transplants`. Pattern: `approval-on-one-path-setter`.

Condition: setAccount upserts an existing balance, permitting a dispatcher to erase debt without owner-only writeOff and its audit record.

Calibration note (verbatim): setAccount (schema.q:40-43) upserts balance, so a dispatcher zeroes an existing balance: a write-off without the owner's writeOff (:66-72) or its audit row. The builder acknowledged the create/edit question as 'distinct creation vs forgiveness authority is intended'; the upsert is also an edit

Retained-question scope: setAccount upserts an existing balance, permitting a dispatcher to erase debt without owner-only writeOff and its audit record.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/019-snapback-mature-tree-transplants/snapback/schema.q:28` through line 43
```text
28: table accounts:
29:   client: principal
30:   cardRef: text 1..60
31:   balance: money USD
32:   unique client
33:   immutable client
34:   read <- exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'owner']
35:   insert <- exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'owner']
36:   update <- exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'owner']
37:   cap 2000
38:   online only
39: 
40: mutation setAccount(client: principal, cardRef: text 1..60, balance: money USD):
41:   require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'owner'] else NOT_PRIVILEGED
42:   require exists roles[principal = client, role = 'client'] else NOT_CLIENT 'Accounts open only for registered clients.'
43:   return upsert accounts[client] { client, cardRef, balance }
```
`/home/ccheever/sb4-loop/wave28/apps/019-snapback-mature-tree-transplants/snapback/schema.q:66` through line 72
```text
66: mutation writeOff(account: accounts, amount: money USD, reason: text 1..280):
67:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER 'Only the company owner can write off a balance.'
68:   a = accounts[account] ! else NOT_FOUND
69:   require amount > 0 else BAD_AMOUNT 'Write-off amount must be positive.'
70:   require a.balance >= amount else OVERDRAWN 'Write-off exceeds the balance owed.'
71:   update accounts[account] { balance: a.balance - amount }
72:   return insert writeoffs { account, amount, reason, recordedBy: viewer }
```
Source bundle SHA-256: `458845cb8a3c16768ca3940258337c185db503429187afff060532cbd9a11cfa`.

**BEFORE exact relevant matches**
- `N_INSERT_WRITE_INTENT` at `schema.q:43:10` (advisory; `notes[19]`): setAccount: accounts.balance can be supplied at insert/upsert without the edit restriction of writeOff: exists roles[viewer, role = 'owner'] and (exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'owner']); creation admission: (exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'owner']) and (exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'owner'])

**AFTER exact relevant matches**
- `N_INSERT_WRITE_INTENT` at `schema.q:43:10` (advisory; `notes[18]`): setAccount: accounts.balance can be supplied at insert/upsert without the edit restriction of writeOff: exists roles[viewer, role = 'owner'] and (exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'owner']); creation admission: (exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'owner']) and (exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'owner'])

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The write-intent diagnostic names the setAccount insert/upsert path for accounts.balance and explicitly compares it with writeOff's owner-only edit restriction. This retains the bypassed write-off authority question; it does not separately infer the missing audit row.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-019F2 — uncovered_before (M)

Application: `019-snapback-mature-tree-transplants`. Pattern: `state-machine`.

Condition: advanceMove accepts skipped/reversed target statuses without a declared transition relation.

Calibration note (verbatim): advanceMove (schema.q:136-144) takes any status: booked->planted and planted->booked accepted. Convex state-machine holes are M (wave 26)

Retained-question scope: advanceMove accepts skipped/reversed target statuses without a declared transition relation.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/019-snapback-mature-tree-transplants/snapback/schema.q:136` through line 144
```text
136: mutation advanceMove(move: moves, status: enum('booked', 'dug', 'onroad', 'planted')):
137:   require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'driver'] else NOT_MOVER
138:   m = moves[move] ! else NOT_FOUND
139:   t = trees[m.tree] ! else NOT_FOUND
140:   if status != 'booked':
141:     require t.certIssuedAt <= now else CERT_FUTURE 'Health certificate issue date is in the future.'
142:     require now - t.certIssuedAt <= 30d else CERT_EXPIRED 'Health certificate is older than 30 days; the tree cannot travel.'
143:   update moves[move] { status }
144:   return null
```
Source bundle SHA-256: `458845cb8a3c16768ca3940258337c185db503429187afff060532cbd9a11cfa`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_INVARIANT_RESTATES_RULE` at `schema.q:169:1`: moves.read matches or weakens current enforcement. Rule moves.read admits a caller satisfying viewer = .client under `.client = viewer` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule moves.read admits roles.role = 'dispatcher' under `exists roles[viewer, role = 'dispatcher']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule moves.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule moves.read admits roles.role = 'driver' under `exists roles[viewer, role = 'driver']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- final: `N_INVARIANT_RESTATES_RULE` at `schema.q:169:1`: moves.read matches or weakens current enforcement. Rule moves.read admits a caller satisfying viewer = .client under `.client = viewer` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule moves.read admits roles.role = 'dispatcher' under `exists roles[viewer, role = 'dispatcher']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule moves.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule moves.read admits roles.role = 'driver' under `exists roles[viewer, role = 'driver']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?

Rationale: The source setter has no source-to-target transition check. Audience invariants and tree certificate/read notes do not ask for allowed status edges; broad guarded-stage questions would not establish that coverage either.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-023F1 — retained (M)

Application: `023-snapback-rv-roof-repairs`. Pattern: `evidence-as-text`.

Condition: Required roof photos are optional text URLs rather than uploaded media.

Calibration note (verbatim): photo1/photo2 are `text <=500 format url ?` (schema.q:44-45, openJob :60-62): the required roof photos are optional URLs, no upload. Wave-26 024 F1 shape

Retained-question scope: Verified uploaded roof photos versus text references; optionality itself is not named.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/023-snapback-rv-roof-repairs/snapback/schema.q:40` through line 45
```text
40: table jobs:
41:   owner: principal
42:   vehicle: text 1..80
43:   notes: text 1..500
44:   photo1: text <=500 format url ?
45:   photo2: text <=500 format url ?
```
`/home/ccheever/sb4-loop/wave28/apps/023-snapback-rv-roof-repairs/snapback/schema.q:60` through line 62
```text
60: mutation openJob(owner: principal, vehicle: text 1..80, notes: text 1..500, photo1: text <=500 format url ?, photo2: text <=500 format url ?, tearCm: int 0..500, quotedCents: int 0..100000000):
61:   require exists roster[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER 'Only a dispatcher opens jobs.'
62:   return insert jobs { owner, vehicle, notes, photo1, photo2, tearCm, quotedCents, status: 'booked', kind: 'membrane' if tearCm > 15 else 'patch', createdAt: now }
```
Source bundle SHA-256: `be1968646832f218f429cd344e94b1a452076349260060f5ab395ed2a25052b6`.

**BEFORE exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:44:3` (advisory; `notes[5]`): jobs.photo1: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?
- `N_TEXT_EVIDENCE` at `schema.q:45:3` (advisory; `notes[6]`): jobs.photo2: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**AFTER exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:44:3` (advisory; `notes[3]`): jobs.photo1: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?
- `N_TEXT_EVIDENCE` at `schema.q:45:3` (advisory; `notes[4]`): jobs.photo2: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The questions name photo1/photo2 and whether verified uploaded media are required instead of text references. They retain the upload representation question, not an independent must-supply/optional-presence question.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-024F1 — uncovered_before (M)

Application: `024-snapback-safe-moving-jobs`. Pattern: `dependent-window`.

Condition: scheduleVisit does not cap scheduledAt at movedAt + 60d; completing against caller time does not enforce the scheduled obligation.

Calibration note (verbatim): scheduleVisit (schema.q:139-143) does not bound scheduledAt by movedAt + 60d; completion is checked only against a caller-supplied completedAt (:150-151), so the 60-day rule is never structurally enforced. Wave-24/26 031 F1 precedent (M)

Retained-question scope: scheduleVisit does not cap scheduledAt at movedAt + 60d; completing against caller time does not enforce the scheduled obligation.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/024-snapback-safe-moving-jobs/snapback/schema.q:139` through line 152
```text
139: mutation scheduleVisit(move: moves, kind: enum('anchor_check', 'service'), scheduledAt: time, notes: text 1..1000 ?):
140:   m = moves[move] ! else NOT_FOUND
141:   require m.surveyor = viewer or exists roles[viewer, role = 'mover'] or exists roles[viewer, role = 'manager'] else NOT_CREW
142:   require kind = 'service' or m.movedAt != null else MOVE_NOT_DONE
143:   return insert visits { move, client: m.client, kind, scheduledAt, notes, createdBy: viewer, done: false, completedAt: null }
144: 
145: mutation completeVisit(visit: visits, completedAt: time ?):
146:   v = visits[visit] ! else NOT_FOUND
147:   m = moves[v.move] ! else NOT_FOUND
148:   require v.createdBy = viewer or exists roles[viewer, role = 'mover'] or exists roles[viewer, role = 'manager'] else NOT_CREW
149:   require not v.done else ALREADY_DONE
150:   at = completedAt ?? now
151:   require v.kind = 'service' or m.movedAt = null or at <= m.movedAt + 60d else ANCHOR_CHECK_OVERDUE
152:   update visits[visit] { done: true, completedAt: at }
```
Source bundle SHA-256: `e8a8d208927ac5fc1cd52fbd88bc0e6b3e6d0a69dbf1302398e46cedf989e6cd`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_CALLER_TIME` at `schema.q:152:3`: completeVisit: caller time completedAt is bounded on only one side of a stored anchor; does the window also forbid dates before/after that anchor?
- final: `N_CALLER_TIME` at `schema.q:152:3`: completeVisit: caller time completedAt is bounded on only one side of a stored anchor; does the window also forbid dates before/after that anchor?

Rationale: The only nearby time question is about completeVisit's one-sided completedAt bound. It does not ask whether scheduleVisit.scheduledAt must be <= movedAt + 60d; it cannot count as that missing schedule bound.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-024F2 — retained (L)

Application: `024-snapback-safe-moving-jobs`. Pattern: `one-sided-window-caller-time`.

Condition: completeVisit permits caller completedAt before movedAt and permits backdating because its bound is only above.

Calibration note (verbatim): completeVisit (schema.q:145-152) bounds the caller-supplied completedAt only above; a completion before the move is stored. Wave-26 024 F2 / 018 F2 precedent (L). The same caller time also lets a late completion be backdated under the bound

Retained-question scope: completeVisit permits caller completedAt before movedAt and permits backdating because its bound is only above.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/024-snapback-safe-moving-jobs/snapback/schema.q:145` through line 152
```text
145: mutation completeVisit(visit: visits, completedAt: time ?):
146:   v = visits[visit] ! else NOT_FOUND
147:   m = moves[v.move] ! else NOT_FOUND
148:   require v.createdBy = viewer or exists roles[viewer, role = 'mover'] or exists roles[viewer, role = 'manager'] else NOT_CREW
149:   require not v.done else ALREADY_DONE
150:   at = completedAt ?? now
151:   require v.kind = 'service' or m.movedAt = null or at <= m.movedAt + 60d else ANCHOR_CHECK_OVERDUE
152:   update visits[visit] { done: true, completedAt: at }
```
Source bundle SHA-256: `e8a8d208927ac5fc1cd52fbd88bc0e6b3e6d0a69dbf1302398e46cedf989e6cd`.

**BEFORE exact relevant matches**
- `N_CALLER_TIME` at `schema.q:152:3` (advisory; `notes[12]`): completeVisit: caller time completedAt is bounded on only one side of a stored anchor; does the window also forbid dates before/after that anchor?

**AFTER exact relevant matches**
- `N_CALLER_TIME` at `schema.q:152:3` (advisory; `notes[12]`): completeVisit: caller time completedAt is bounded on only one side of a stored anchor; does the window also forbid dates before/after that anchor?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The caller-time diagnostic names completedAt and the one-sided stored-anchor bound, asking about the missing opposite side. This retains the pre-move completion question; it is not proof that backdating or lateness is enforced.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-032F2 — uncovered_before (L)

Application: `032-snapback-assisted-living-placements`. Pattern: `caller-time-unbounded`.

Condition: recordVisit accepts an unbounded caller at, including future-dated follow-ups that clear overdueFollowups.

Calibration note (verbatim): recordVisit (schema.q:94-97) stores a caller-supplied visit time with no bound: a visit dated 91 days ahead of a same-day move-in is accepted and clears overdueFollowups (:72-74). Lateness itself is an obligation (d); the future-dated record is the wave-26 018 F2 shape (L). Convex 032 refuses future-dated visits (visits.ts:58)

Retained-question scope: recordVisit accepts an unbounded caller at, including future-dated follow-ups that clear overdueFollowups.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/032-snapback-assisted-living-placements/snapback/schema.q:72` through line 74
```text
72: query overdueFollowups(c: cursor ?):
73:   require exists staff[principal = viewer] else NOT_STAFF
74:   return placements where .status = 'moved_in' and .movedInAt != null and .movedInAt + 90d < now and not exists visits[placement = .id] last 50 by .id after c
```
`/home/ccheever/sb4-loop/wave28/apps/032-snapback-assisted-living-placements/snapback/schema.q:94` through line 97
```text
94: mutation recordVisit(placement: placements, at: time, notes: text 1..1000):
95:   require exists staff[principal = viewer, role = 'coordinator'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'liaison'] else NOT_STAFF
96:   p = placements[placement] ! else NOT_FOUND
97:   return insert visits { placement, family: p.family, at, notes, conductedBy: viewer }
```
Source bundle SHA-256: `dfeec40ee0f14603b9b3f613e597ca986d120fd01f7dc80ff69fec312d72dfd1`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: recordVisit stores caller at without a bound and overdueFollowups tests visit existence. No emitted baseline question names the at/server-time bound or future follow-up records; read-authority advice does not cover it.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-036F1 — retained (M)

Application: `036-snapback-wax-figure-commissions`. Pattern: `approval-not-invalidated`.

Condition: changeLikeness replaces likenessScan during clay_sculpt without invalidating likenessApproved/At.

Calibration note (verbatim): changeLikeness (schema.q:94-99) replaces likenessScan during clay_sculpt and leaves likenessApproved/At set; advanceStage (:113-120) then molds the unapproved replacement after the 60-day cutoff. Wave-26 033 F1 shape (approval invalidation), on a media input

Retained-question scope: changeLikeness replaces likenessScan during clay_sculpt without invalidating likenessApproved/At.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/036-snapback-wax-figure-commissions/snapback/schema.q:20` through line 34
```text
20:   client: principal
21:   title: text 3..120
22:   likenessScan: image <=10000000
23:   quotedPrice: money USD
24:   extraCost: money USD default 0
25:   unveilingAt: time
26:   likenessApproved: bool default false
27:   likenessApprovedAt: time ?
28:   stage: enum('clay_sculpt', 'molding', 'wax_pour', 'hair_insertion', 'delivered', 'cancelled') default 'clay_sculpt'
29:   deliveredAt: time ?
30:   immutable client, unveilingAt
31:   cap 500 by client
32:   read <- .client = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'artist'] or exists roles[viewer, role = 'owner']
33:   insert <- exists roles[viewer, role = 'coordinator']
34:   update <- exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'artist'] or exists roles[viewer, role = 'owner']
```
`/home/ccheever/sb4-loop/wave28/apps/036-snapback-wax-figure-commissions/snapback/schema.q:84` through line 119
```text
84: mutation approveLikeness(figure: figures):
85:   require exists roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
86:   f = figures[figure] ! else NOT_FOUND
87:   require not f.likenessApproved else ALREADY_APPROVED
88:   require f.stage != 'cancelled' and f.stage != 'delivered' else BAD_STAGE
89:   require now <= f.unveilingAt - 60d else TOO_LATE
90:   update figures[figure] { likenessApproved: true, likenessApprovedAt: now }
91:   return null
92: 
93: -- A likeness change before the mold is made needs no extra cost.
94: mutation changeLikeness(figure: figures, likenessScan: image <=10000000):
95:   require exists roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
96:   f = figures[figure] ! else NOT_FOUND
97:   require f.stage = 'clay_sculpt' else MOLD_MADE
98:   update figures[figure] { likenessScan }
99:   return null
100: 
101: -- Only the studio owner can approve a likeness change after the mold is
102: -- made, recording the extra cost as an invoice.
103: mutation approveLikenessChange(figure: figures, likenessScan: image <=10000000, extraCost: money USD):
104:   require exists roles[viewer, role = 'owner'] else NOT_OWNER
105:   f = figures[figure] ! else NOT_FOUND
106:   require f.stage != 'clay_sculpt' and f.stage != 'cancelled' and f.stage != 'delivered' else BAD_STAGE
107:   require extraCost > 0 else BAD_COST
108:   update figures[figure] { likenessScan, extraCost: f.extraCost + extraCost }
109:   insert invoices { figure, client: f.client, amount: extraCost, kind: 'extra' }
110:   return null
111: 
112: -- Studio artists move figures along the live studio board.
113: mutation advanceStage(figure: figures):
114:   require exists roles[viewer, role = 'artist'] else NOT_ARTIST
115:   f = figures[figure] ! else NOT_FOUND
116:   require f.likenessApproved else NOT_APPROVED
117:   require f.stage = 'clay_sculpt' or f.stage = 'molding' or f.stage = 'wax_pour' or f.stage = 'hair_insertion' else BAD_STAGE
118:   next = 'molding' if f.stage = 'clay_sculpt' else 'wax_pour' if f.stage = 'molding' else 'hair_insertion' if f.stage = 'wax_pour' else 'delivered'
119:   update figures[figure] { stage: next, deliveredAt: now if next = 'delivered' else f.deliveredAt }
```
Source bundle SHA-256: `845ebecf0d859f571fc849310825c92e8e45c4db11a2ce358a66bdd7874f8892`.

**BEFORE exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/schema.q/figures/likenessScan/update/23ee7f4fe5fc49157e8f4416e4639c0357e184e23536b92e04dd59e3756fa621:90:3` (advisory; `notes[20]`): figures.likenessScan update: derived candidate update only old.likenessApproved != true or next.likenessApproved != true; a replayed violation needs a specification decision
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/schema.q/figures/likenessScan/update/c8047023845790f4080646427934aa6a20329524a8078215d457a397c1038c64:90:3` (advisory; `notes[21]`): figures.likenessScan update: derived candidate update only old.likenessApprovedAt = null or next.likenessApprovedAt = null; a replayed violation needs a specification decision

**AFTER exact relevant matches**
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/schema.q/figures/likenessScan/update/23ee7f4fe5fc49157e8f4416e4639c0357e184e23536b92e04dd59e3756fa621:90:3` (advisory; `notes[13]`): figures.likenessScan update: derived candidate update only old.likenessApproved != true or next.likenessApproved != true; a replayed violation needs a specification decision
- `N_DERIVED_WRITE_AUTHORITY` at `$derived/schema.q/figures/likenessScan/update/c8047023845790f4080646427934aa6a20329524a8078215d457a397c1038c64:90:3` (advisory; `notes[14]`): figures.likenessScan update: derived candidate update only old.likenessApprovedAt = null or next.likenessApprovedAt = null; a replayed violation needs a specification decision

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:108:3`: approveLikenessChange: figures.likenessScan can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:119:3`: advanceStage: checks figures.likenessApproved but leaves it unchanged while changing state; could repeating this transition reuse the same authorization?
- final: `N_EDIT_AFTER_APPROVAL` at `schema.q:108:3`: approveLikenessChange: saw `((figures[figure]) ! else NOT_FOUND.stage != 'clay_sculpt' and (figures[figure]) ! else NOT_FOUND.stage != 'cancelled' and (figures[figure]) ! else NOT_FOUND.stage != 'delivered'); (extraCost > 0); exists roles[viewer, role = 'owner']`; not proved: edit of figures.likenessScan at schema.q:108:3 is restricted by lifecycle/approval; should checked values remain editable?
- final: `N_GUARD_NOT_CONSUMED` at `schema.q:119:3`: advanceStage: saw `((figures[figure]) ! else NOT_FOUND.stage = 'clay_sculpt' or (figures[figure]) ! else NOT_FOUND.stage = 'molding' or (figures[figure]) ! else NOT_FOUND.stage = 'wax_pour' or (figures[figure]) ! else NOT_FOUND.stage = 'hair_insertion'); (figures[figure]) ! else NOT_FOUND.likenessApproved; exists roles[viewer, role = 'artist']`; not proved: unchanged figures.likenessApproved cannot authorize a repeated figures transition at schema.q:119:3

Rationale: The derived likenessScan update candidates require clearing the old Boolean approval or approval timestamp when replacing the scan. Their seed site is approveLikeness at 90, but the target is scan updates, including changeLikeness at 98. Edit advice at the separate owner-only approveLikenessChange path and reuse advice at advanceStage are not used as substitutes.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-036F2 — uncovered_before (L)

Application: `036-snapback-wax-figure-commissions`. Pattern: `sweep-lag`.

Condition: An overdue unapproved figure stays active until the scheduled daily cancelOverdue sweep runs.

Calibration note (verbatim): an overdue unapproved figure stays active until the daily cancelOverdue job (:160-166); it cannot advance (requires approval). Convex 018 F8 precedent (L)

Retained-question scope: An overdue unapproved figure stays active until the scheduled daily cancelOverdue sweep runs.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/036-snapback-wax-figure-commissions/snapback/schema.q:75` through line 80
```text
75: mutation createFigure(client: principal, title: text 3..120, likenessScan: image <=10000000, quotedPrice: money USD, unveilingAt: time):
76:   require exists roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
77:   require unveilingAt > now else BAD_UNVEILING
78:   require quotedPrice > 0 else BAD_PRICE
79:   f = insert figures { client, title, likenessScan, quotedPrice, unveilingAt }
80:   insert invoices { figure: f.id, client, amount: quotedPrice, kind: 'quote' }
```
`/home/ccheever/sb4-loop/wave28/apps/036-snapback-wax-figure-commissions/snapback/schema.q:94` through line 98
```text
94: mutation changeLikeness(figure: figures, likenessScan: image <=10000000):
95:   require exists roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
96:   f = figures[figure] ! else NOT_FOUND
97:   require f.stage = 'clay_sculpt' else MOLD_MADE
98:   update figures[figure] { likenessScan }
```
`/home/ccheever/sb4-loop/wave28/apps/036-snapback-wax-figure-commissions/snapback/schema.q:158` through line 166
```text
158: -- Figures whose likeness is still unapproved once the 60-day deadline
159: -- passes are cancelled with the deposit kept (their invoices stay).
160: job cancelOverdue(periodStart: time, periodEnd: time):
161:   for f in figures where .unveilingAt >= periodEnd - 90d and .unveilingAt < periodEnd + 60d by .unveilingAt:
162:     if not f.likenessApproved and f.stage != 'cancelled' and f.stage != 'delivered':
163:       if f.unveilingAt - 60d < periodEnd:
164:         update figures[f.id] { stage: 'cancelled' }
165: 
166: schedule cancelDaily every 1d at 00:00: cancelOverdue
```
Source bundle SHA-256: `845ebecf0d859f571fc849310825c92e8e45c4db11a2ce358a66bdd7874f8892`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
- `N_SWEEP_DEADLINE` at `schema.q:94:1` (advisory; `notes[16]`): mutation changeLikeness: saw tests figures[figure].stage (column figures.stage); scheduled job cancelOverdue has a literal update of that column and `((figures[figure]) ! else NOT_FOUND.stage = 'clay_sculpt'); exists roles[viewer, role = 'coordinator']`; not proved: guards at schema.q:94:1 exclude the sweep window for figures[figure].unveilingAt (column figures.unveilingAt, clock offset 5184000000ms); sweep may lag; this is not a proof of safety

**Broad/nearby questions excluded from coverage**
- baseline: `N_ROLE_WIDE_READ` at `schema.q:32:3`: figures.read: roles.role='artist' (`exists roles[viewer, role = 'artist']`), roles.role='owner' (`exists roles[viewer, role = 'owner']`) branches read every value of [stage] across a private/media boundary; should the spec restrict these roles to particular resource relationships or states?
- final: `N_ROLE_WIDE_READ` at `schema.q:32:3`: figures.read: roles.role='artist' (`exists roles[viewer, role = 'artist']`), roles.role='owner' (`exists roles[viewer, role = 'owner']`) branches read every value of [stage] across a private/media boundary; should the spec restrict these roles to particular resource relationships or states?

Rationale: The source sweep is daily; active status can lag. There is no baseline sweep-window question on this condition. Broad read/lifecycle policy and unrelated likeness approval-invalidation questions do not ask about the lag. The final N_SWEEP_DEADLINE at changeLikeness:94 now names the cancelOverdue window and sweep lag on the clay_sculpt write path. The analogous question at approveLikenessChange:103 is not counted: that separate non-clay path is not the calibrated overdue-unapproved clay_sculpt case.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately. The qualified candidate newly asks the condition; this is a final-only question, not retention.

### w28-043F1 — uncovered_before (L)

Application: `043-snapback-playground-safety-inspections`. Pattern: `unvalidated-principal-argument`.

Condition: approveAmendment stores any requestedBy principal without validating who requested the amendment.

Calibration note (verbatim): approveAmendment (schema.q:114-120) stores any principal as requestedBy; only the manager (top role) writes it, so this is audit-record validation, not a privilege crossing

Retained-question scope: approveAmendment stores any requestedBy principal without validating who requested the amendment.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/043-snapback-playground-safety-inspections/snapback/schema.q:114` through line 120
```text
114: mutation approveAmendment(certificate: certificates, reason: text 1..500, requestedBy: principal):
115:   require exists roles[viewer, role = 'manager'] else NOT_MANAGER
116:   cert = certificates[certificate] ! else NOT_FOUND
117:   insp = inspections[cert.inspection] ! else NOT_FOUND
118:   require insp.status = 'issued' else NOT_ISSUED
119:   update certificates[certificate] { amended: true, amendmentReason: reason, requestedBy, amendedBy: viewer, amendedAt: now }
120:   return null
```
Source bundle SHA-256: `6585dd5d86a52a68b8ec85f2ef68b3907434f5c2c598f2fea404a32571d7c01f`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_ROLE_WIDE_WRITE` at `schema.q:119:3`: approveAmendment: may any admitted role write any certificates row and record themselves? Does the spec mean owner of THIS resource?
- final: `N_ROLE_WIDE_WRITE` at `schema.q:119:3`: approveAmendment: may any admitted role write any certificates row and record themselves? Does the spec mean owner of THIS resource?

Rationale: The role-wide-write question asks whether any admitted role may write any certificate row and record themselves. It does not mention requestedBy, its unvalidated argument, or validation of the requesting principal.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-043F2 — retained (L)

Application: `043-snapback-playground-safety-inspections`. Pattern: `calendar-arithmetic`.

Condition: issueReport uses 730 fixed days for a nominal two-year certificate lifetime across leap years.

Calibration note (verbatim): expiresAt = now + 730d (:112) is one day short of two years across 2028; the error is conservative (expires early)

Retained-question scope: issueReport uses 730 fixed days for a nominal two-year certificate lifetime across leap years.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/043-snapback-playground-safety-inspections/snapback/schema.q:105` through line 112
```text
105: mutation issueReport(inspection: inspections):
106:   require exists roles[viewer, role = 'inspector'] else NOT_INSPECTOR
107:   insp = inspections[inspection] ! else NOT_FOUND
108:   require insp.status = 'written' else BAD_STATUS
109:   require insp.inspectedAt != null else NOT_INSPECTED
110:   late = insp.inspectedAt + 3d < now
111:   update inspections[inspection] { status: 'issued', issuedAt: now, flagged: late }
112:   return insert certificates { inspection, client: insp.client, issuedAt: now, expiresAt: now + 730d }
```
Source bundle SHA-256: `6585dd5d86a52a68b8ec85f2ef68b3907434f5c2c598f2fea404a32571d7c01f`.

**BEFORE exact relevant matches**
- `N_CALENDAR_DURATION` at `schema.q:112:10` (advisory; `notes[15]`): issueReport: certificates.expiresAt uses 730d; does the spec mean fixed days or a calendar anniversary? Leap years differ. (duration question)

**AFTER exact relevant matches**
- `N_CALENDAR_DURATION` at `schema.q:112:10` (advisory; `notes[12]`): issueReport: certificates.expiresAt uses 730d; does the spec mean fixed days or a calendar anniversary? Leap years differ. (duration question)

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The calendar-duration question explicitly names expiresAt, 730d and the fixed-days-versus-calendar-anniversary distinction.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-046F1 — uncovered_before (M)

Application: `046-snapback-furnace-repair-calls`. Pattern: `blank-text`.

Condition: A format character such as U+200B can serve as invisible consent for replacement approval.

Calibration note (verbatim): consent: text 1..500 (:87) counts non-whitespace (core validate.rs:146) but U+200B is a format character, not White_Space, so an invisible consent approves a replacement. Wave-26 045 F1 shape

Retained-question scope: A format character such as U+200B can serve as invisible consent for replacement approval.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/046-snapback-furnace-repair-calls/snapback/schema.q:69` through line 74
```text
69: mutation recordReplaced(job: jobs):
70:   require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
71:   j = jobs[job] ! else NOT_FOUND
72:   require j.status = 'on_site' else BAD_TRANSITION
73:   require j.requested = 'replace' or j.replacementApproved else NEEDS_APPROVAL
74:   update jobs[job] { status: 'replaced', repairedAt: now }
```
`/home/ccheever/sb4-loop/wave28/apps/046-snapback-furnace-repair-calls/snapback/schema.q:85` through line 92
```text
85: -- Only the service manager approves installing a new furnace when the
86: -- customer asked for a repair only, recording the customer's consent.
87: mutation approveReplacement(job: jobs, consent: text 1..500):
88:   require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
89:   j = jobs[job] ! else NOT_FOUND
90:   require j.requested = 'repair' else NOT_NEEDED
91:   require not j.replacementApproved else ALREADY_APPROVED
92:   update jobs[job] { replacementApproved: true, consent }
```
Source bundle SHA-256: `788844bd7daa3e2acc8290e29a4e37618309b57120ffdb0c1ea60170df85e56e`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:74:3`: recordReplaced: checks jobs.replacementApproved but leaves it unchanged while changing state; could repeating this transition reuse the same authorization?
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:92:3`: approveReplacement: jobs.replacementApproved can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: No baseline diagnostic questions invisible/format-character consent or its text validation. Approval reuse and approved-value editability do not name that missing nonblank/content condition.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w28-047F1 — retained (M)

Application: `047-snapback-henna-artist-bookings`. Pattern: `evidence-as-text`.

Condition: Required trial photos are an optional list of text values and can be absent/null/empty.

Calibration note (verbatim): trialPhotos: [text <=500] <=8 ? (schema.q:25, openBooking :82-85): the required trial photos are an optional text list; omitted, null and [] accepted

Retained-question scope: Uploaded trial-photo evidence versus text references; nonempty/required presence is not independently named.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/047-snapback-henna-artist-bookings/snapback/schema.q:22` through line 27
```text
22:   client: principal
23:   artist: principal ?
24:   status: enum('trial', 'confirmed', 'onsite', 'done', 'cancelled') default 'trial'
25:   trialPhotos: [text <=500] <=8 ?
26:   skinNotes: text <=2000 ?
27:   partySchedule: text <=2000 ?
```
`/home/ccheever/sb4-loop/wave28/apps/047-snapback-henna-artist-bookings/snapback/schema.q:81` through line 85
```text
81: -- The booking manager opens each booking with trial photos and quoted price.
82: mutation openBooking(client: principal, eventAt: time, price: int 0..100000000, clientPhone: text <=30 ?, venueContract: text <=2000 ?, trialPhotos: [text <=500] <=8 ?, skinNotes: text <=2000 ?, partySchedule: text <=2000 ?):
83:   require exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
84:   require eventAt > now else BAD_DATE 'The event must be in the future.'
85:   return insert bookings { client, eventAt, price, clientPhone, venueContract, trialPhotos, skinNotes, partySchedule }
```
Source bundle SHA-256: `8076226e4c2b75b7e197cbec507cc7249a4632c87dce2c574e0bb7d195631ed1`.

**BEFORE exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:25:3` (advisory; `notes[14]`): bookings.trialPhotos: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**AFTER exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:25:3` (advisory; `notes[11]`): bookings.trialPhotos: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The trialPhotos diagnostic asks whether uploaded media are required instead of text. This retains the representation aspect of the calibrated finding, not explicit nonempty-list enforcement.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w28-050F1 — uncovered_before (M)

Application: `050-snapback-home-generator-servicing`. Pattern: `dependent-window`.

Condition: openVisit checks now, rather than scheduledAt, against lastServiceAt + 365d.

Calibration note (verbatim): openVisit (schema.q:77-82) checks now <= lastServiceAt + 365d but not scheduledAt, so a visit is booked 394 days after the last service. Wave-26 031 F1 shape (window base)

Retained-question scope: openVisit checks now, rather than scheduledAt, against lastServiceAt + 365d.

Source evidence:
`/home/ccheever/sb4-loop/wave28/apps/050-snapback-home-generator-servicing/snapback/schema.q:75` through line 82
```text
75: -- Schedulers open a visit with the three required photos and the quoted fee.
76: -- The generator must be serviced again within 12 months of its last service.
77: mutation openVisit(generator: generators, scheduledAt: time, enginePhoto: image <=10000000, batteryPhoto: image <=10000000, switchPhoto: image <=10000000, fee: money USD):
78:   require exists roles[viewer, role = 'scheduler'] else NOT_SCHEDULER
79:   g = generators[generator] ! else NOT_FOUND
80:   require now <= g.lastServiceAt + 365d else OVERDUE_SERVICE 'This generator is overdue: it must be serviced within 12 months of its last service.'
81:   require scheduledAt >= now - 1d else IN_THE_PAST 'A visit cannot be scheduled in the past.'
82:   return insert visits { generator, owner: g.owner, scheduledAt, enginePhoto, batteryPhoto, switchPhoto, fee }
```
Source bundle SHA-256: `8c65ad2fccc3be1e0d3821378473b7364a37bebee69d96d1f7f201d4cb9fb208`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_STALE_CREATION_CHECK` at `schema.q:89:3`: visits: creation by openVisit at schema.q:82:10 checks mutable generators.lastServiceAt, but later state transition approveWorkshop at schema.q:122:3, markLoadRun at schema.q:104:3, markRepaired at schema.q:96:3, markTested at schema.q:89:3 does not recheck every column for the same applicant/resource
- final: `N_STALE_CREATION_CHECK` at `schema.q:89:3`: visits: creation by openVisit at schema.q:82:10 checks mutable generators.lastServiceAt, but later state transition approveWorkshop at schema.q:122:3, markLoadRun at schema.q:104:3, markRepaired at schema.q:96:3, markTested at schema.q:89:3 does not recheck every column for the same applicant/resource

Rationale: The stale-creation question asks later repair/test transitions to recheck mutable lastServiceAt. It does not ask whether the caller's scheduledAt is bounded by lastServiceAt + 365d at openVisit.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-002F1 — retained (M)

Application: `002-snapback-infant-helmet-fittings`. Pattern: `required-upload-optional-text`.

Condition: The required referral scan is optional URL text and orderHelmet does not require it.

Calibration note (verbatim): referralScan is optional text (`text 1..500 format url ?`, schema.q:25) and openFitting (:57-60) accepts it omitted; orderHelmet (:80-86) orders without it. Staff integrity = M. Convex requires the scan (fittings.ts:138, :149)

Retained-question scope: Verified referral upload versus text reference; required presence before ordering is not independently named.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/002-snapback-infant-helmet-fittings/snapback/schema.q:22` through line 27
```text
22:   diagnosis: text 1..500
23:   insurance: text 1..200
24:   fee: money USD
25:   referralScan: text 1..500 format url ?
26:   referralAt: time
27:   headScan: text 1..1000 ?
```
`/home/ccheever/sb4-loop/wave30/apps/002-snapback-infant-helmet-fittings/snapback/schema.q:57` through line 60
```text
57: mutation openFitting(parent: principal, babyName: text 1..80, diagnosis: text 1..500, insurance: text 1..200, fee: money USD, referralScan: text 1..500 format url ?, referralAt: time):
58:   require exists roles[viewer, role = 'frontdesk'] or exists roles[viewer, role = 'manager'] else NOT_STAFF 'Front desk or manager only.'
59:   require referralAt <= now else BAD_REFERRAL 'Referral date cannot be in the future.'
60:   return insert fittings { parent, babyName, diagnosis, insurance, fee, referralScan, referralAt, status: 'scanned' }
```
`/home/ccheever/sb4-loop/wave30/apps/002-snapback-infant-helmet-fittings/snapback/schema.q:80` through line 86
```text
80: mutation orderHelmet(fitting: fittings):
81:   require exists roles[viewer, role = 'frontdesk'] or exists roles[viewer, role = 'orthotist'] or exists roles[viewer, role = 'manager'] else NOT_STAFF 'Staff only.'
82:   f = fittings[fitting] ! else NOT_FOUND
83:   require f.status = 'scanned' else BAD_STATUS 'Only a scanned fitting can be ordered.'
84:   require f.referralAt + 183d >= now else REFERRAL_EXPIRED 'Referral is older than six months.'
85:   update fittings[fitting] { status: 'ordered' }
86:   return null
```
Source bundle SHA-256: `9034b103ec66811db805fa33004ae2cd7368146ba0005c1d6bce6081529568ea`.

**BEFORE exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:25:3` (advisory; `notes[18]`): fittings.referralScan: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**AFTER exact relevant matches**
- `N_TEXT_EVIDENCE` at `schema.q:25:3` (advisory; `notes[13]`): fittings.referralScan: text names photo/scan/sketch evidence; is verified uploaded media required, or is this deliberately a text reference?

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The specific referralScan question asks whether verified uploaded media are required instead of text. This retains the upload representation question but does not independently ask whether omitted referralScan must block ordering.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w30-004F1 — uncovered_before (M)

Application: `004-snapback-accessible-home-remodels`. Pattern: `assignment-scoped-read-role-wide`.

Condition: jobPrivate admits every coordinator instead of only the particular job's assigned coordinator.

Calibration note (verbatim): jobPrivate.read (schema.q:51) and privateDetail (:96-98) admit every coordinator; jobs.coordinator (:27) is never consulted, so an unassigned coordinator reads another job's phone, care needs and price. Excluded staff of an entitled role = M (H if per-assignment scoping is counted as an audience boundary). Convex scopes it (access.ts:13 manages(), jobs.ts:18)

Retained-question scope: jobPrivate admits every coordinator instead of only the particular job's assigned coordinator.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/004-snapback-accessible-home-remodels/snapback/schema.q:25` through line 27
```text
25: table jobs:
26:   family: principal
27:   coordinator: principal
```
`/home/ccheever/sb4-loop/wave30/apps/004-snapback-accessible-home-remodels/snapback/schema.q:42` through line 53
```text
42: table jobPrivate:
43:   job: jobs
44:   phone: text 7..30
45:   careNeeds: text 1..2000
46:   quotedCents: int 1..100000000
47:   depositCents: int 0..100000000
48:   depositStatus: enum('held', 'cancelled') default 'held'
49:   unique job
50:   immutable job, phone, careNeeds, quotedCents, depositCents
51:   read <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'coordinator']
52:   insert <- exists roles[viewer, role = 'coordinator']
53:   update <- exists roles[viewer, role = 'owner']
```
`/home/ccheever/sb4-loop/wave30/apps/004-snapback-accessible-home-remodels/snapback/schema.q:96` through line 98
```text
96: query privateDetail(job: jobs):
97:   require exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'owner'] else PRIVATE
98:   return { details: jobPrivate[job = job], cancellation: cancellations[job = job] }
```
Source bundle SHA-256: `7575c2ecbacea7dd0df0515c664dbbc6e5061e388830a0ea9b0d6c6510a5d023`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_INVARIANT_RESTATES_RULE` at `schema.q:82:1`: jobPrivate.read matches or weakens current enforcement. Rule jobPrivate.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule jobPrivate.read admits roles.role = 'coordinator' under `exists roles[viewer, role = 'coordinator']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- final: `N_INVARIANT_RESTATES_RULE` at `schema.q:82:1`: jobPrivate.read matches or weakens current enforcement. Rule jobPrivate.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule jobPrivate.read admits roles.role = 'coordinator' under `exists roles[viewer, role = 'coordinator']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?

Rationale: The invariant-restatement question describes coordinator role-wide admission with no row relationship and asks generally about audience. It never names jobs.coordinator or an assigned-coordinator equality. Under the required strict criterion this remains a relevant broad policy question, not exact assignment coverage.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-006F1 — uncovered_before (M)

Application: `006-snapback-fishing-reel-servicing`. Pattern: `entitlement-not-carried`.

Condition: Free re-service entitlement is not carried through the workflow, so returnReel bills quotedPrice again.

Calibration note (verbatim): acceptReservice (schema.q:140-148) sends the reel back to intake and returnReel (:126-131) always inserts an invoice for quotedPrice, so the free 30-day re-service is billed again. Convex invoices once at intake (reels.ts:109) and re-service adds none (faults.ts:39-41)

Retained-question scope: Free re-service entitlement is not carried through the workflow, so returnReel bills quotedPrice again.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/006-snapback-fishing-reel-servicing/snapback/schema.q:126` through line 148
```text
126: mutation returnReel(reel: reels):
127:   r = reels[reel] ! else NOT_FOUND
128:   require exists staff[principal = viewer, role = 'technician'] else NOT_TECHNICIAN 'Only a technician returns reels.'
129:   require r.status = 'testing' else BAD_TRANSITION 'Only a tested reel can be returned.'
130:   update reels[reel] { status: 'returned', returnedAt: now }
131:   return insert invoices { reel, customer: r.owner, amount: r.quotedPrice }
132: 
133: mutation reportDragFault(reel: reels, description: text 1..500):
134:   r = reels[reel] ! else NOT_FOUND
135:   require r.owner = viewer else NOT_OWNER 'Only the reel owner reports a drag fault.'
136:   require r.status = 'returned' else NOT_RETURNED 'Drag faults are reported after return.'
137:   require now <= r.returnedAt + 30d else DRAG_WINDOW_CLOSED 'Drag faults qualify for free re-service within 30 days after return.'
138:   return insert dragReports { reel, reporter: viewer, description }
139: 
140: mutation acceptReservice(report: dragReports):
141:   rep = dragReports[report] ! else NOT_FOUND
142:   require exists staff[principal = viewer, role = 'technician'] else NOT_TECHNICIAN 'Only a technician starts a re-service.'
143:   r = reels[rep.reel] ! else NOT_FOUND
144:   require r.status = 'returned' else NOT_RETURNED 'Only a returned reel re-enters service.'
145:   require now <= r.returnedAt + 30d else DRAG_WINDOW_CLOSED 'Free re-service applies within 30 days after return.'
146:   update dragReports[report] { accepted: true }
147:   update reels[rep.reel] { status: 'intake', arrivedAt: now, returnedAt: now }
148:   return null
```
Source bundle SHA-256: `c3df822afe624ea8aa70fe1d99d3b48dcdad7636844e2c62000e70f97a714e1f`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:138:10`: reportDragFault: checks reels.status but leaves it unchanged while changing dragReports state; could repeating this transition reuse that guard?
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:147:3`: acceptReservice: reels.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: No baseline question names free re-service, invoices or duplicate billing on the second return. Status editability and repeated fault reports are different conditions.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-010F1 — retained (M)

Application: `010-snapback-whitewater-rafting-trips`. Pattern: `entitlement-not-consumed`.

Condition: rebookTrip does not consume the cancelled trip, permitting repeat rebooking and a later refund.

Calibration note (verbatim): rebookTrip (schema.q:159-165) leaves the original trip cancelled_high_water, so the office rebooks it twice and refundTrip (:167-172) still refunds it: rebook OR refund becomes both. Convex marks the booking rebooked/refunded and refuses the other (bookings.ts:109-110, :166-167)

Retained-question scope: rebookTrip does not consume the cancelled trip, permitting repeat rebooking and a later refund.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/010-snapback-whitewater-rafting-trips/snapback/schema.q:159` through line 171
```text
159: mutation rebookTrip(trip: trips, tripDate: time):
160:   require exists roles[viewer, role = 'office'] else NOT_OFFICE
161:   t = trips[trip] ! else NOT_FOUND
162:   require t.status = 'cancelled_high_water' else NOT_CANCELLED 'Only a trip cancelled for high water can be rebooked.'
163:   require t.cancelledAt != null and now <= t.cancelledAt + 365d else REBOOK_WINDOW_CLOSED 'Rebooking is only possible within 12 months of cancellation.'
164:   require tripDate > now else TRIP_NOT_FUTURE 'The trip date must be in the future.'
165:   return insert trips { title: t.title, section: t.section, rapidClass: t.rapidClass, tripDate, price: t.price, createdBy: viewer, rebookedFrom: trip }
166: 
167: mutation refundTrip(trip: trips):
168:   require exists roles[viewer, role = 'office'] else NOT_OFFICE
169:   t = trips[trip] ! else NOT_FOUND
170:   require t.status = 'cancelled_high_water' else NOT_CANCELLED 'Only a trip cancelled for high water can be refunded.'
171:   update trips[trip] { status: 'refunded' }
```
Source bundle SHA-256: `dda8f617f089cf08b02c3d62af17bf349086b2521cd1a540d2b88973dce91fb3`.

**BEFORE exact relevant matches**
- `N_GUARD_NOT_CONSUMED` at `schema.q:165:10` (advisory; `notes[24]`): rebookTrip: checks trips.status but leaves it unchanged while changing trips state; could repeating this transition reuse that guard?

**AFTER exact relevant matches**
- `N_GUARD_NOT_CONSUMED` at `schema.q:165:10` (advisory; `notes[15]`): rebookTrip: saw `((trips[trip]) ! else NOT_FOUND.cancelledAt != null and now <= (trips[trip]) ! else NOT_FOUND.cancelledAt + 31536000000); ((trips[trip]) ! else NOT_FOUND.status = 'cancelled_high_water'); (tripDate > now); exists roles[viewer, role = 'office']`; not proved: unchanged trips.status cannot authorize a repeated trips transition at schema.q:165:10

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The guard-not-consumed diagnostic identifies rebookTrip's unchanged source trips.status while inserting a new trip. That is the unconsumed entitlement question. It retains a question about repeat use without proving the rebook/refund exclusivity policy.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w30-014F1 — uncovered_before (M)

Application: `014-snapback-balloon-decor-installs`. Pattern: `assignment-scoped-read-role-wide`.

Condition: Private project phone, venue contract and fee admit every lead instead of the project's own lead.

Calibration note (verbatim): projects has no lead column; read (clientPhone, venueContract, fee) <- any lead (schema.q:41), so lead B reads lead A's client phone, contract and fee. Excluded staff of an entitled role = M. Convex 014 F4 is the same hole (M)

Retained-question scope: Private project phone, venue contract and fee admit every lead instead of the project's own lead.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/014-snapback-balloon-decor-installs/snapback/schema.q:23` through line 43
```text
23: table projects:
24:   client: principal
25:   title: text 1..80
26:   venue: text 1..120
27:   entrancePhoto: text <=500 format url
28:   hallPhoto: text <=500 format url
29:   balloonPlan: text 1..2000
30:   riggingNotes: text 1..500
31:   clientPhone: text 1..40
32:   venueContract: text 1..2000
33:   fee: money USD
34:   eventAt: time
35:   status: enum('planned', 'inflated', 'installed', 'taken_down') default 'planned'
36:   takedownAt: time ?
37:   freeArch: bool default false
38:   freeArchReason: text 1..200 ?
39:   immutable client, entrancePhoto, hallPhoto, clientPhone, venueContract, fee, eventAt
40:   read <- .client = viewer or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'installer']
41:   read (clientPhone, venueContract, fee) <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'lead']
42:   insert <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'lead']
43:   update <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'installer']
```
Source bundle SHA-256: `fa9dec04559bb40592d9ae5458277ddaa760a75057e42a55b944f590dbec6854`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_INVARIANT_RESTATES_RULE` at `schema.q:49:1`: projects.clientPhone read matches or weakens current enforcement. Rule projects.clientPhone.read admits a caller satisfying viewer = .client and roles.role = 'owner' under `.client = viewer and exists roles[viewer, role = 'owner']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits a caller satisfying viewer = .client and roles.role = 'lead' under `.client = viewer and exists roles[viewer, role = 'lead']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'lead' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'installer' and roles.role = 'owner' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'installer' and roles.role = 'lead' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- baseline: `N_INVARIANT_RESTATES_RULE` at `schema.q:50:1`: projects.venueContract read matches or weakens current enforcement. Rule projects.venueContract.read admits a caller satisfying viewer = .client and roles.role = 'owner' under `.client = viewer and exists roles[viewer, role = 'owner']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits a caller satisfying viewer = .client and roles.role = 'lead' under `.client = viewer and exists roles[viewer, role = 'lead']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'lead' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'installer' and roles.role = 'owner' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'installer' and roles.role = 'lead' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- baseline: `N_INVARIANT_RESTATES_RULE` at `schema.q:51:1`: projects.fee read matches or weakens current enforcement. Rule projects.fee.read admits a caller satisfying viewer = .client and roles.role = 'owner' under `.client = viewer and exists roles[viewer, role = 'owner']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits a caller satisfying viewer = .client and roles.role = 'lead' under `.client = viewer and exists roles[viewer, role = 'lead']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'lead' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'installer' and roles.role = 'owner' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'installer' and roles.role = 'lead' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- baseline: `N_ROLE_WIDE_READ` at `schema.q:31:3`: projects.clientPhone read: protected columns [clientPhone, fee, venueContract] admit roles.role='lead', roles.role='owner' for every value of [status]; should these roles read all rows or only the spec's resource relationships and states?
- final: `N_INVARIANT_RESTATES_RULE` at `schema.q:49:1`: projects.clientPhone read matches or weakens current enforcement. Rule projects.clientPhone.read admits a caller satisfying viewer = .client and roles.role = 'owner' under `.client = viewer and exists roles[viewer, role = 'owner']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits a caller satisfying viewer = .client and roles.role = 'lead' under `.client = viewer and exists roles[viewer, role = 'lead']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'lead' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'installer' and roles.role = 'owner' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.clientPhone.read admits roles.role = 'installer' and roles.role = 'lead' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- final: `N_INVARIANT_RESTATES_RULE` at `schema.q:50:1`: projects.venueContract read matches or weakens current enforcement. Rule projects.venueContract.read admits a caller satisfying viewer = .client and roles.role = 'owner' under `.client = viewer and exists roles[viewer, role = 'owner']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits a caller satisfying viewer = .client and roles.role = 'lead' under `.client = viewer and exists roles[viewer, role = 'lead']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'lead' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'installer' and roles.role = 'owner' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.venueContract.read admits roles.role = 'installer' and roles.role = 'lead' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- final: `N_INVARIANT_RESTATES_RULE` at `schema.q:51:1`: projects.fee read matches or weakens current enforcement. Rule projects.fee.read admits a caller satisfying viewer = .client and roles.role = 'owner' under `.client = viewer and exists roles[viewer, role = 'owner']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits a caller satisfying viewer = .client and roles.role = 'lead' under `.client = viewer and exists roles[viewer, role = 'lead']` (row conditions on .client). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'owner'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'lead' and roles.role = 'owner' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'lead' under `exists roles[viewer, role = 'lead'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'installer' and roles.role = 'owner' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'owner']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state? Rule projects.fee.read admits roles.role = 'installer' and roles.role = 'lead' under `exists roles[viewer, role = 'installer'] and exists roles[viewer, role = 'lead']` (no row relationship or lifecycle condition in this branch). Should the spec allow this audience on these rows and columns, including other people's rows and every lifecycle state?
- final: `N_ROLE_WIDE_READ` at `schema.q:31:3`: projects.clientPhone read: protected columns [clientPhone, fee, venueContract] admit roles.role='lead', roles.role='owner' for every value of [status]; should these roles read all rows or only the spec's resource relationships and states?

Rationale: The protected-column audience questions name leads and all rows but ask only generic resource relationships/states; none names assignment to THIS project or the missing project-lead link. Listed as broad policy advice, excluded from exact retention counts.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-014F2 — uncovered_before (L)

Application: `014-snapback-balloon-decor-installs`. Pattern: `one-sided-window`.

Condition: markTakenDown can run before the event because it only enforces now <= eventAt + 2d.

Calibration note (verbatim): markTakenDown (schema.q:103-108) checks only now <= eventAt + 2d, so an installer marks taken_down a week before the event (server time; status only). Convex has the same one-sided check, unreported (projects.ts:242-243)

Retained-question scope: markTakenDown can run before the event because it only enforces now <= eventAt + 2d.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/014-snapback-balloon-decor-installs/snapback/schema.q:103` through line 108
```text
103: mutation markTakenDown(project: projects):
104:   p = projects[project] ! else NOT_FOUND
105:   require exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'installer'] else NOT_STAFF
106:   require p.status = 'installed' else BAD_TRANSITION
107:   require now <= p.eventAt + 2d else TAKEDOWN_LATE
108:   update projects[project] { status: 'taken_down', takedownAt: now }
```
Source bundle SHA-256: `fa9dec04559bb40592d9ae5458277ddaa760a75057e42a55b944f590dbec6854`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_CALLER_TIME` at `schema.q:86:10`: openProject: caller time eventAt flows into projects.eventAt, which controls a server-clock deadline, without a dominating bound against now
- final: `N_CALLER_TIME` at `schema.q:86:10`: openProject: caller time eventAt flows into projects.eventAt, which controls a server-clock deadline, without a dominating bound against now

Rationale: The openProject caller-time warning asks whether the supplied eventAt is bounded against now. It does not ask markTakenDown to require now >= eventAt. It is not the same missing bound.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-018F1 — uncovered_before (M)

Application: `018-snapback-orchard-pruning-visits`. Pattern: `guard-on-one-path-only`.

Condition: pruneTouchup omits quarantine approval, permit and fee although pruneVisit checks it.

Calibration note (verbatim): pruneVisit checks quarantine approval (schema.q:107-108) but pruneTouchup (:168-176) prunes a missed tree on a quarantined orchard with no lead approval, permit or fee. Staff bypass = M. Convex 018 F5 is the same hole (repruneMissed)

Retained-question scope: pruneTouchup omits quarantine approval, permit and fee although pruneVisit checks it.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/018-snapback-orchard-pruning-visits/snapback/schema.q:101` through line 109
```text
101: mutation pruneVisit(visit: visits):
102:   r = roles[viewer]
103:   require r != null and (r.role = 'pruner' or r.role = 'lead') else NOT_PRUNER
104:   v = visits[visit] ! else NOT_FOUND
105:   require v.status = 'marked' else BAD_STATUS 'Only a marked visit can be pruned.'
106:   o = orchards[v.orchard] ! else NOT_FOUND
107:   if o.quarantine:
108:     require exists approvals[visit] else QUARANTINE_APPROVAL_REQUIRED 'A quarantined orchard needs the lead pruner approval first.'
109:   update visits[visit] { status: 'pruned' }
```
`/home/ccheever/sb4-loop/wave30/apps/018-snapback-orchard-pruning-visits/snapback/schema.q:161` through line 176
```text
161: mutation recordMissed(visit: visits, treeTag: text 1..40):
162:   r = roles[viewer]
163:   require r != null and (r.role = 'pruner' or r.role = 'lead') else NOT_PRUNER
164:   v = visits[visit] ! else NOT_FOUND
165:   require v.status = 'pruned' or v.status = 'chipped' else BAD_STATUS 'Missed trees are recorded after pruning.'
166:   return insert touchups { visit, grower: v.grower, treeTag }
167: 
168: mutation pruneTouchup(touchup: touchups):
169:   r = roles[viewer]
170:   require r != null and (r.role = 'pruner' or r.role = 'lead') else NOT_PRUNER
171:   t = touchups[touchup] ! else NOT_FOUND
172:   require t.done = false else BAD_STATUS 'This tree is already pruned.'
173:   v = visits[t.visit] ! else NOT_FOUND
174:   require now <= v.visitDate + 30d else TOUCHUP_WINDOW_PASSED 'A missed tree may be pruned within 30 days of the visit.'
175:   update touchups[touchup] { done: true, doneAt: now }
176:   return null
```
Source bundle SHA-256: `a35c590182c612e5d917919c133b207a7e281f20d6611467d4845e3c3314596a`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:109:3`: pruneVisit: checks orchards.quarantine but leaves it unchanged while changing visits state; could repeating this transition reuse that guard?
- baseline: `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/1002e670a702d24b28738934fc9498bde934129b6fb95893c927acae67a653c3/schema.q:109:3`: visits.status update: inferred effect prerequisite (.status != 'pruned' or (not .orchard.quarantine or (exists approvals[visit = .id]))); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision
- final: `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/1002e670a702d24b28738934fc9498bde934129b6fb95893c927acae67a653c3/schema.q:109:3`: visits.status update: inferred effect prerequisite (.status != 'pruned' or (not .orchard.quarantine or (exists approvals[visit = .id]))); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision

Rationale: The derived candidate governs visits.status becoming pruned, not touchups.done becoming true in pruneTouchup. Advice about a standing quarantine guard on pruneVisit does not identify the missing guard on the sibling touchup path.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-023F1 — uncovered_before (L)

Application: `023-snapback-gutter-repair-calls`. Pattern: `one-sided-window-caller-time`.

Condition: openJob allows a long-run replacement scheduled before now because only its upper 14-day limit is checked.

Calibration note (verbatim): openJob (schema.q:101-105) bounds a long-run replacement's caller scheduledAt only above (<= now + 14d); a date 30 days in the past is stored. Convex books with server time only (jobs.ts:149-190)

Retained-question scope: openJob allows a long-run replacement scheduled before now because only its upper 14-day limit is checked.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/023-snapback-gutter-repair-calls/snapback/schema.q:101` through line 105
```text
101: mutation openJob(owner: principal, address: text 5..200, runLengthFt: int 1..500, jobKind: enum('repair', 'replacement'), quotedPrice: money USD, scheduledAt: time, seamPhoto: image <=10000000, hangerPhoto: image <=10000000, downspoutPhoto: image <=10000000, replacementFor: jobs ?):
102:   require exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'manager'] else NOT_DISPATCHER 'Only dispatchers or the branch manager open jobs.'
103:   require runLengthFt <= 50 or jobKind = 'replacement' else LONG_RUN_NEEDS_REPLACEMENT 'A run over 50 ft must be booked as a full replacement.'
104:   require runLengthFt <= 50 or scheduledAt <= now + 14d else REPLACEMENT_WINDOW 'A replacement for a long run must be scheduled within 14 days.'
105:   return insert jobs { owner, dispatcher: viewer, address, runLengthFt, jobKind, quotedPrice, status: 'booked', seamPhoto, hangerPhoto, downspoutPhoto, scheduledAt, replacementFor }
```
Source bundle SHA-256: `0b1b6874b2a99b75c4cb765c803c4629800a4eb27eb7db7818f88ef63c3357c9`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:105:10`: openJob: jobs.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_REFERENCE_UNCHECKED` at `schema.q:105:10`: mutation openJob stores argument replacementFor directly in jobs.replacementFor, without a mandatory lookup of jobs[replacementFor] on every committing path: a reference accepts any well-formed id even when the row is absent
- final: `N_REFERENCE_UNCHECKED` at `schema.q:105:10`: mutation openJob stores argument replacementFor directly in jobs.replacementFor, without a mandatory lookup of jobs[replacementFor] on every committing path: a reference accepts any well-formed id even when the row is absent

Rationale: No baseline question names scheduledAt's missing lower bound. Editability of jobs.status and reference existence for replacementFor are unrelated despite the identical insert site.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-025F1 — uncovered_before (M)

Application: `025-snapback-chainsaw-safety-certifications`. Pattern: `caller-asserted-counter`.

Condition: logExam trusts caller attempt instead of deriving sitting count, enabling approval and fee/prior-history bypass.

Calibration note (verbatim): logExam (schema.q:91-110) trusts the caller's attempt number: the registrar labels a third sitting attempt=2 and skips the manager approval (:108-109), or attempt=1 to skip the prior-failure/half-price rule (:94-96). Convex derives the attempt from the latest exam (exams.ts:75-123)

Retained-question scope: logExam trusts caller attempt instead of deriving sitting count, enabling approval and fee/prior-history bypass.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/025-snapback-chainsaw-safety-certifications/snapback/schema.q:91` through line 110
```text
91: mutation logExam(candidate: principal, fee: int 0..100000, photoId: image <=5000000, attempt: int 1..10, priorExam: exams ?):
92:   require exists roles[viewer, role = 'registrar'] else NOT_REGISTRAR
93:   require exists roles[principal = candidate, role = 'candidate'] else NOT_CANDIDATE
94:   if attempt = 1:
95:     require fee = 20000 else BAD_FEE 'First sitting costs 20000 cents.'
96:     require priorExam = null else BAD_PRIOR 'First sitting has no prior exam.'
97:   else:
98:     require priorExam != null else BAD_PRIOR 'Retest needs its prior exam.'
99:     p = exams[priorExam] ! else NOT_FOUND
100:     require p.candidate = candidate else BAD_PRIOR 'Prior exam belongs to another candidate.'
101:     require p.status = 'failed' else NOT_FAILED 'Retest needs a failed prior exam.'
102:     require p.failedAt != null else NOT_FAILED 'Prior exam has no failure time.'
103:     within = now <= p.failedAt + 30d
104:     if within:
105:       require fee = 10000 else BAD_FEE 'Retest within 30 days costs 10000 cents.'
106:     else:
107:       require fee = 20000 else BAD_FEE 'Retest after 30 days costs 20000 cents.'
108:     if attempt >= 3:
109:       require exists retestApprovals[candidate = candidate, priorExam = priorExam] else NOT_APPROVED 'Beyond the second attempt needs manager approval.'
110:   return insert exams { candidate, status: 'booked', fee, photoId, attempt, createdAt: now }
```
Source bundle SHA-256: `a158805636666c7562b6b2898c1c2afed6e8011278bc3c59d80715e98a4b74c0`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_APPROVAL_NOT_ENFORCED` at `schema.q:152:10`: retestApprovals.priorExam: a separately authorized approval for exams is recorded but a modeled effect does not require it
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:110:10`: logExam: exams.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- final: `N_APPROVAL_NOT_ENFORCED` at `schema.q:152:10`: retestApprovals.priorExam: a separately authorized approval for exams is recorded but a modeled effect does not require it

Rationale: The approval diagnostic says a modeled effect lacks retest approval, but never names caller attempt, derivation from exam history or dishonest attempt labels. The source does check approval for attempt >= 3. A generic approval question does not cover the missing trusted counter.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-025F2 — uncovered_before (M)

Application: `025-snapback-chainsaw-safety-certifications`. Pattern: `approval-not-bound-to-subject`.

Condition: Retest approval is bound to candidate/priorExam rather than the intended next sitting and can be reused.

Calibration note (verbatim): the approval key is (candidate, priorExam) (schema.q:51-58, :109) and priorExam may be any failed exam of the candidate, so an approval granted after the second failure is reused for a fifth sitting. Convex binds approval to attemptNumber (exams.ts:113-122)

Retained-question scope: Retest approval is bound to candidate/priorExam rather than the intended next sitting and can be reused.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/025-snapback-chainsaw-safety-certifications/snapback/schema.q:50` through line 59
```text
50: -- Granted before the registrar logs the new sitting; keyed by candidate + prior failed exam.
51: table retestApprovals:
52:   candidate: principal
53:   priorExam: exams
54:   reason: text 1..500
55:   recommendation: text 1..500
56:   approvedBy: principal
57:   at: time default now
58:   unique candidate, priorExam
59:   immutable candidate, priorExam
```
`/home/ccheever/sb4-loop/wave30/apps/025-snapback-chainsaw-safety-certifications/snapback/schema.q:91` through line 110
```text
91: mutation logExam(candidate: principal, fee: int 0..100000, photoId: image <=5000000, attempt: int 1..10, priorExam: exams ?):
92:   require exists roles[viewer, role = 'registrar'] else NOT_REGISTRAR
93:   require exists roles[principal = candidate, role = 'candidate'] else NOT_CANDIDATE
94:   if attempt = 1:
95:     require fee = 20000 else BAD_FEE 'First sitting costs 20000 cents.'
96:     require priorExam = null else BAD_PRIOR 'First sitting has no prior exam.'
97:   else:
98:     require priorExam != null else BAD_PRIOR 'Retest needs its prior exam.'
99:     p = exams[priorExam] ! else NOT_FOUND
100:     require p.candidate = candidate else BAD_PRIOR 'Prior exam belongs to another candidate.'
101:     require p.status = 'failed' else NOT_FAILED 'Retest needs a failed prior exam.'
102:     require p.failedAt != null else NOT_FAILED 'Prior exam has no failure time.'
103:     within = now <= p.failedAt + 30d
104:     if within:
105:       require fee = 10000 else BAD_FEE 'Retest within 30 days costs 10000 cents.'
106:     else:
107:       require fee = 20000 else BAD_FEE 'Retest after 30 days costs 20000 cents.'
108:     if attempt >= 3:
109:       require exists retestApprovals[candidate = candidate, priorExam = priorExam] else NOT_APPROVED 'Beyond the second attempt needs manager approval.'
110:   return insert exams { candidate, status: 'booked', fee, photoId, attempt, createdAt: now }
```
`/home/ccheever/sb4-loop/wave30/apps/025-snapback-chainsaw-safety-certifications/snapback/schema.q:147` through line 152
```text
147: mutation approveRetest(candidate: principal, priorExam: exams, reason: text 1..500, recommendation: text 1..500):
148:   require exists roles[viewer, role = 'manager'] else NOT_MANAGER
149:   p = exams[priorExam] ! else NOT_FOUND
150:   require p.candidate = candidate else BAD_PRIOR 'Approval is for the prior exam candidate.'
151:   require p.status = 'failed' else NOT_FAILED 'Only a failed exam can be re-approved.'
152:   return upsert retestApprovals[candidate = candidate, priorExam = priorExam] { candidate, priorExam, reason, recommendation, approvedBy: viewer, at: now }
```
Source bundle SHA-256: `a158805636666c7562b6b2898c1c2afed6e8011278bc3c59d80715e98a4b74c0`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_APPROVAL_NOT_ENFORCED` at `schema.q:152:10`: retestApprovals.priorExam: a separately authorized approval for exams is recorded but a modeled effect does not require it
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:152:10`: approveRetest: checks exams.status but leaves it unchanged while changing retestApprovals state; could repeating this transition reuse that guard?
- final: `N_APPROVAL_NOT_ENFORCED` at `schema.q:152:10`: retestApprovals.priorExam: a separately authorized approval for exams is recorded but a modeled effect does not require it

Rationale: The generic approval-enforcement question does not name approval binding to the new attempt or invalidation after use. The guard-not-consumed question at approveRetest concerns a failed exam remaining failed while recording approval; it does not ask whether logExam reuses that approval across sittings.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-030F1 — retained (M)

Application: `030-snapback-acoustic-noise-studies`. Pattern: `required-upload-optional`.

Condition: Required sound recordings are optional/empty and openStudy accepts no recordings.

Calibration note (verbatim): recordings is an optional list (`[file <=10000000] <=4 ?`, schema.q:34) and openStudy (:96-100) accepts null; the customer receives a study with no recordings. Convex requires at least one (studies.ts:82-84)

Retained-question scope: Required sound recordings are optional/empty and openStudy accepts no recordings.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/030-snapback-acoustic-noise-studies/snapback/schema.q:30` through line 35
```text
30:   customer: principal
31:   siteKind: enum('office', 'venue', 'building_site')
32:   address: text 1..200
33:   price: money USD
34:   recordings: [file <=10000000] <=4 ?
35:   status: enum('booked', 'measured', 'reviewed', 'reported') default 'booked'
```
`/home/ccheever/sb4-loop/wave30/apps/030-snapback-acoustic-noise-studies/snapback/schema.q:96` through line 100
```text
96: mutation openStudy(customer: principal, siteKind: enum('office', 'venue', 'building_site'), address: text 1..200, price: money USD, recordings: [file <=10000000] <=4 ?):
97:   require exists roles[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
98:   require exists roles[principal = customer, role = 'customer'] else NOT_CUSTOMER
99:   require price > 0 else BAD_PRICE
100:   return insert studies { customer, siteKind, address, price, recordings }
```
Source bundle SHA-256: `444433f15a82fdd1657b2e55f9cad2120d20859a65070110a597740a44f2f2c9`.

**BEFORE exact relevant matches**
- `N_OPTIONAL_EVIDENCE` at `schema.q:34:3` (advisory; `notes[1]`): studies.recordings permits omitted or empty media evidence

**AFTER exact relevant matches**
- `N_OPTIONAL_EVIDENCE` at `schema.q:34:3` (advisory; `notes[1]`): studies.recordings permits omitted or empty media evidence

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The optional-evidence question names studies.recordings and explicitly states that omitted or empty media evidence is permitted.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w30-030F2 — uncovered_before (M)

Application: `030-snapback-acoustic-noise-studies`. Pattern: `state-machine`.

Condition: publishReport accepts measured status and can bypass the reviewed stage.

Calibration note (verbatim): publishReport (schema.q:116-124) accepts status measured or reviewed, so an engineer reports without the review stage. Convex 030 F5 is the same hole (M)

Retained-question scope: publishReport accepts measured status and can bypass the reviewed stage.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/030-snapback-acoustic-noise-studies/snapback/schema.q:109` through line 124
```text
109: mutation markReviewed(study: studies):
110:   s = studies[study] ! else NOT_FOUND
111:   require exists roles[principal = viewer, role = 'engineer'] else NOT_ENGINEER
112:   require s.status = 'measured' else BAD_STATUS
113:   update studies[study] { status: 'reviewed' }
114:   return null
115: 
116: mutation publishReport(study: studies, body: text 1..5000, quoteAmount: money USD):
117:   s = studies[study] ! else NOT_FOUND
118:   require exists roles[principal = viewer, role = 'engineer'] or exists roles[principal = viewer, role = 'service_manager'] else NOT_AUTHOR
119:   require s.status = 'measured' or s.status = 'reviewed' else BAD_STATUS
120:   require s.measuredAt != null else NOT_MEASURED
121:   require quoteAmount >= 0 else BAD_QUOTE
122:   late = now > s.measuredAt + 5d
123:   update studies[study] { status: 'reported' }
124:   return insert reports { study, customer: s.customer, body, quoteAmount, isLate: late, validUntil: now + 30d }
```
Source bundle SHA-256: `444433f15a82fdd1657b2e55f9cad2120d20859a65070110a597740a44f2f2c9`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:123:3`: publishReport: studies.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The baseline edit question asks about status editability without a lifecycle/approval condition. It does not name the missing reviewed-only precondition or the measured-to-reported bypass. Guarded stages are not declared-transition coverage.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-030F3 — uncovered_before (L)

Application: `030-snapback-acoustic-noise-studies`. Pattern: `upload-content-unchecked`.

Condition: recordings uses an unrestricted file type rather than requiring sound/audio MIME types.

Calibration note (verbatim): recordings is `file` with no type list (schema.q:34), so the default verifiable list admits text/plain as a 'sound recording'; Quarry can restrict it (`file <=N ('audio/wav', 'audio/mpeg', 'audio/flac')`). Convex stores unchecked strings, unreported

Retained-question scope: recordings uses an unrestricted file type rather than requiring sound/audio MIME types.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/030-snapback-acoustic-noise-studies/snapback/schema.q:30` through line 35
```text
30:   customer: principal
31:   siteKind: enum('office', 'venue', 'building_site')
32:   address: text 1..200
33:   price: money USD
34:   recordings: [file <=10000000] <=4 ?
35:   status: enum('booked', 'measured', 'reviewed', 'reported') default 'booked'
```
`/home/ccheever/sb4-loop/wave30/apps/030-snapback-acoustic-noise-studies/snapback/schema.q:96` through line 100
```text
96: mutation openStudy(customer: principal, siteKind: enum('office', 'venue', 'building_site'), address: text 1..200, price: money USD, recordings: [file <=10000000] <=4 ?):
97:   require exists roles[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
98:   require exists roles[principal = customer, role = 'customer'] else NOT_CUSTOMER
99:   require price > 0 else BAD_PRICE
100:   return insert studies { customer, siteKind, address, price, recordings }
```
Source bundle SHA-256: `444433f15a82fdd1657b2e55f9cad2120d20859a65070110a597740a44f2f2c9`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_OPTIONAL_EVIDENCE` at `schema.q:34:3`: studies.recordings permits omitted or empty media evidence
- final: `N_OPTIONAL_EVIDENCE` at `schema.q:34:3`: studies.recordings permits omitted or empty media evidence

Rationale: The recordings question concerns omitted/empty evidence, not accepted content types. Same column/site is insufficient: no baseline message asks for audio-only content or exclusion of text/plain.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-033F1 — retained (M)

Application: `033-snapback-garage-floor-coatings`. Pattern: `approval-not-enforced-bool`.

Condition: advanceJob topcoats a damp-signed slab without consulting dampApproved owner approval.

Calibration note (verbatim): approveDamp (schema.q:105-111) records dampApproved but advanceJob (:87-97) never reads dampSigned/dampApproved; crew coat a damp-signed slab to topcoated without the owner. Staff bypass = M. Convex gates the advance (jobs.ts:205-207)

Retained-question scope: advanceJob topcoats a damp-signed slab without consulting dampApproved owner approval.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/033-snapback-garage-floor-coatings/snapback/schema.q:79` through line 111
```text
79: mutation acceptQuote(job: jobs):
80:   j = jobs[job] ! else NOT_FOUND
81:   require j.customer = viewer else NOT_CUSTOMER
82:   require j.status = 'quoted' else BAD_STATUS
83:   require now <= j.quoteCreatedAt + 14d else QUOTE_LAPSED
84:   update jobs[job] { status: 'booked', acceptedAt: now, bookedAt: now }
85:   return jobs[job]
86: 
87: mutation advanceJob(job: jobs):
88:   require exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'owner'] else NOT_CREW
89:   j = jobs[job] ! else NOT_FOUND
90:   require j.status = 'booked' or j.status = 'grinding' or j.status = 'crack_filling' else BAD_STATUS
91:   if j.status = 'booked':
92:     update jobs[job] { status: 'grinding' }
93:   else if j.status = 'grinding':
94:     update jobs[job] { status: 'crack_filling' }
95:   else:
96:     update jobs[job] { status: 'topcoated', topcoatedAt: now }
97:   return jobs[job]
98: 
99: mutation markDamp(job: jobs):
100:   j = jobs[job] ! else NOT_FOUND
101:   require j.customer = viewer else NOT_CUSTOMER
102:   update jobs[job] { dampSigned: true }
103:   return jobs[job]
104: 
105: mutation approveDamp(job: jobs, consent: text 1..500):
106:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
107:   j = jobs[job] ! else NOT_FOUND
108:   require j.dampSigned = true else NO_DAMP_SIGNOFF
109:   require j.dampApproved = false else BAD_STATUS
110:   update jobs[job] { dampApproved: true, dampConsent: consent }
111:   return jobs[job]
```
Source bundle SHA-256: `aecca6627a94824947263446c037ccceda69a96717a6320ff1e09af081c6b4d7`.

**BEFORE exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:84:3` (recorded_gate; `gates[0]`): jobs.dampApproved: a modeled acceptQuote effect can proceed without reading this recorded approval
  Attached candidate question: `invariant jobs.advanceJob only (not .dampSigned or .dampApproved)`. No replay verdict counted.

**AFTER exact relevant matches**
- `N_APPROVAL_NOT_ENFORCED` at `schema.q:84:3` (recorded_gate; `gates[0]`): jobs.dampApproved: a modeled acceptQuote effect can proceed without reading this recorded approval
  Attached candidate question: `invariant jobs.advanceJob only (not .dampSigned or .dampApproved)`. No replay verdict counted.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:96:5`: advanceJob: jobs.status can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_APPROVAL_NOT_ENFORCED` at `schema.q:84:3`: jobs.dampApproved: a modeled acceptQuote effect can proceed without reading this recorded approval
- final: `N_APPROVAL_NOT_ENFORCED` at `schema.q:84:3`: jobs.dampApproved: a modeled acceptQuote effect can proceed without reading this recorded approval

Rationale: The message misleadingly seeds acceptQuote at 84, but the supplied gate metadata carries the exact candidate `invariant jobs.advanceJob only (not .dampSigned or .dampApproved)`. That actual question, not a witness-success or production-gate claim, establishes relevance to the calibrated advance path.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w30-033F2 — retained (M)

Application: `033-snapback-garage-floor-coatings`. Pattern: `required-evidence-child-optional`.

Condition: acceptQuote and advanceJob can proceed without any required before-photos row.

Calibration note (verbatim): openJob (schema.q:74-77) takes no photos; photos are a side table (:118-137) that acceptQuote/advanceJob never require, so a job is topcoated with zero before photos. Convex requires 2-20 photos incl. a crack and an oil stain (jobs.ts:58-65)

Retained-question scope: acceptQuote and advanceJob can proceed without any required before-photos row.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/033-snapback-garage-floor-coatings/snapback/schema.q:74` through line 97
```text
74: mutation openJob(customer: principal, address: text 1..200, description: text 1..1000 ?, priceCents: int 0..):
75:   require exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'estimator'] else NOT_STAFF
76:   require exists directory[principal = customer] else NOT_CUSTOMER
77:   return insert jobs { customer, estimator: viewer, address, description, priceCents }
78: 
79: mutation acceptQuote(job: jobs):
80:   j = jobs[job] ! else NOT_FOUND
81:   require j.customer = viewer else NOT_CUSTOMER
82:   require j.status = 'quoted' else BAD_STATUS
83:   require now <= j.quoteCreatedAt + 14d else QUOTE_LAPSED
84:   update jobs[job] { status: 'booked', acceptedAt: now, bookedAt: now }
85:   return jobs[job]
86: 
87: mutation advanceJob(job: jobs):
88:   require exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'owner'] else NOT_CREW
89:   j = jobs[job] ! else NOT_FOUND
90:   require j.status = 'booked' or j.status = 'grinding' or j.status = 'crack_filling' else BAD_STATUS
91:   if j.status = 'booked':
92:     update jobs[job] { status: 'grinding' }
93:   else if j.status = 'grinding':
94:     update jobs[job] { status: 'crack_filling' }
95:   else:
96:     update jobs[job] { status: 'topcoated', topcoatedAt: now }
97:   return jobs[job]
```
`/home/ccheever/sb4-loop/wave30/apps/033-snapback-garage-floor-coatings/snapback/schema.q:118` through line 137
```text
118: table photos:
119:   job: jobs
120:   uploader: principal
121:   caption: text 1..200 ?
122:   image: image <=10000000
123:   immutable job
124:   cap 50 by job
125:   read <- exists jobs[.job, customer = viewer] or exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'estimator'] or exists roles[principal = viewer, role = 'crew']
126:   insert <- exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'estimator']
127:   online only
128: 
129: query jobPhotos(job: jobs, c: cursor ?):
130:   require exists jobs[job] else NOT_FOUND
131:   return photos where .job = job last 50 by .id after c
132: 
133: mutation addPhoto(job: jobs, image: image <=10000000, caption: text 1..200 ?):
134:   require exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'estimator'] else NOT_STAFF
135:   j = jobs[job] ! else NOT_FOUND
136:   require j.status = 'quoted' else BAD_STATUS
137:   return insert photos { job: j.id, uploader: viewer, caption, image }
```
Source bundle SHA-256: `aecca6627a94824947263446c037ccceda69a96717a6320ff1e09af081c6b4d7`.

**BEFORE exact relevant matches**
- `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:84:3` (advisory; `notes[6]`): jobs: transitions acceptQuote, advanceJob do not require attached photos[job = parent].image; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

**AFTER exact relevant matches**
- `N_CHILD_EVIDENCE_PRESENCE` at `schema.q:84:3` (advisory; `notes[5]`): jobs: transitions acceptQuote, advanceJob do not require attached photos[job = parent].image; must a photo/file child exist before advancing? Text photo/URL fields are a name-based evidence question.

**Broad/nearby questions excluded from coverage**
None needed to explain this verdict; unrelated lane diagnostics are excluded (full inventories in JSON).

Rationale: The child-evidence question explicitly names photos[job = parent].image existence before acceptQuote and advanceJob. It does not prove photo counts or required photo categories.

Verdict: At least one exact, semantically relevant baseline question remains in the qualified candidate.

### w30-035F1 — uncovered_before (M)

Application: `035-snapback-drapery-cleaning-batches`. Pattern: `state-machine`.

Condition: advanceStage accepts skipped/reversed stages and can jump inspection directly to finished.

Calibration note (verbatim): advanceStage (schema.q:92-98) accepts any target stage except the current one; a cleaner jumps inspection -> finished, skipping cleaning and flameproofing, and markReady (:107-113) accepts it. Convex steps NEXT_STAGE (batches.ts:214-227)

Retained-question scope: advanceStage accepts skipped/reversed stages and can jump inspection directly to finished.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/035-snapback-drapery-cleaning-batches/snapback/schema.q:92` through line 112
```text
92: mutation advanceStage(batch: batches, stage: enum('inspection', 'cleaning', 'flameproofing', 'pleating', 'finished')):
93:   b = batches[batch] ! else NOT_FOUND
94:   require exists roles[principal = viewer, role = 'cleaner'] or exists roles[principal = viewer, role = 'owner'] else NOT_WORKROOM
95:   require b.status = 'approved' else BAD_STATUS
96:   require stage != b.stage else NO_CHANGE
97:   update batches[batch] { stage }
98:   return null
99: 
100: mutation approveDye(batch: batches, dyeColor: text 1..60, dyeConsent: text 1..500):
101:   b = batches[batch] ! else NOT_FOUND
102:   require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
103:   require b.status = 'approved' else BAD_STATUS
104:   update batches[batch] { dyeColor, dyeConsent }
105:   return null
106: 
107: mutation markReady(batch: batches):
108:   b = batches[batch] ! else NOT_FOUND
109:   require exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'owner'] else NOT_STAFF
110:   require b.status = 'approved' else BAD_STATUS
111:   require b.stage = 'finished' else NOT_FINISHED
112:   update batches[batch] { status: 'ready', readyAt: now }
```
Source bundle SHA-256: `ee74bc980be3140808afbf8be878bc7d9164ae33087befaa5bf2383584512ffe`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:97:3`: advanceStage: batches.stage can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?

Rationale: The baseline stage-editability question does not name any permitted source/destination edge, required cleaning/flameproofing sequence or inspection-to-finished skip. A generic lifecycle question cannot count as declared-transition coverage.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

### w30-038F1 — uncovered_before (M)

Application: `038-snapback-welding-gas-deliveries`. Pattern: `guard-scoped-to-duplicable-row`.

Condition: A duplicate workshop row for the same owner gives a fresh debt scope and bypasses the credit hold.

Calibration note (verbatim): pastDue (schema.q:59-62) is keyed by workshop row, and createWorkshop (:83-86) lets a dispatcher open a duplicate workshop for the same owner, then scheduleDelivery (:88-95) skips the credit hold. Staff bypass of the manager approval = M. Convex has the same hole, unreported (ops.ts:15-18 createAccount; model.ts:17 debt by accountId)

Retained-question scope: A duplicate workshop row for the same owner gives a fresh debt scope and bypasses the credit hold.

Source evidence:
`/home/ccheever/sb4-loop/wave30/apps/038-snapback-welding-gas-deliveries/snapback/schema.q:14` through line 24
```text
14:   owner: principal
15:   name: text 2..100
16:   address: text 5..240
17:   standing: bool
18:   lastDelivery: time ?
19:   restockDue: time
20:   immutable owner
21:   read <- .owner = viewer or exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'driver'] or exists roles[viewer, role = 'manager']
22:   insert <- exists roles[viewer, role = 'dispatcher']
23:   update <- exists roles[viewer, role = 'dispatcher']
24:   online only
```
`/home/ccheever/sb4-loop/wave30/apps/038-snapback-welding-gas-deliveries/snapback/schema.q:59` through line 62
```text
59: fn pastDue(workshop: workshops):
60:   if staff():
61:     return exists deliveries where .workshop = workshop and .paid = false and .deliveredAt != null and .deliveredAt < now - 30d
62:   return exists deliveries where .owner = viewer and .workshop = workshop and .paid = false and .deliveredAt != null and .deliveredAt < now - 30d
```
`/home/ccheever/sb4-loop/wave30/apps/038-snapback-welding-gas-deliveries/snapback/schema.q:83` through line 109
```text
83: mutation createWorkshop(owner: principal, name: text 2..100, address: text 5..240, standing: bool):
84:   require exists roles[viewer, role = 'dispatcher'] else DISPATCHER_ONLY
85:   require exists roles[owner, role = 'workshop'] else WORKSHOP_ACCOUNT_REQUIRED
86:   return insert workshops { owner, name, address, standing, restockDue: now + 14d }
87: 
88: mutation scheduleDelivery(workshop: workshops, driver: principal, scheduledAt: time):
89:   require exists roles[viewer, role = 'dispatcher'] else DISPATCHER_ONLY
90:   w = workshops[workshop] ! else NOT_FOUND
91:   require exists roles[driver, role = 'driver'] else DRIVER_REQUIRED
92:   require scheduledAt >= now - 1m else PAST_SCHEDULE
93:   require not pastDue(workshop) else CREDIT_HOLD 'An unpaid delivery is older than 30 days. Account manager approval is required.'
94:   require not w.standing or scheduledAt <= w.restockDue else RESTOCK_DEADLINE 'Standing orders must be restocked within 14 days. An overdue restock requires an account manager emergency approval.'
95:   return insert deliveries { workshop, owner: w.owner, workshopName: w.name, driver, scheduledAt, status: 'scheduled' }
96: 
97: mutation approveEmergency(workshop: workshops, driver: principal, reason: text 10..500):
98:   require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
99:   w = workshops[workshop] ! else NOT_FOUND
100:   require exists roles[driver, role = 'driver'] else DRIVER_REQUIRED
101:   return insert deliveries { workshop, owner: w.owner, workshopName: w.name, driver, scheduledAt: now, status: 'scheduled', emergencyReason: reason, approvedBy: viewer, approvedAt: now }
102: 
103: mutation loadDelivery(delivery: deliveries):
104:   d = deliveries[delivery] ! else NOT_FOUND
105:   require exists roles[viewer, role = 'driver'] and d.driver = viewer else ASSIGNED_DRIVER_ONLY
106:   require d.status = 'scheduled' else BAD_STATUS
107:   require now >= d.scheduledAt else TOO_EARLY
108:   require d.approvedBy != null or not pastDue(d.workshop) else CREDIT_HOLD
109:   update deliveries[delivery] { status: 'loaded' }
```
Source bundle SHA-256: `89385d4e367aacc3e95090316c95949123cf93341405df3a36af35954e2f8463`.

**BEFORE exact relevant matches**
None.

**AFTER exact relevant matches**
None.

**Broad/nearby questions excluded from coverage**
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:86:10`: createWorkshop: workshops.standing can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_EDIT_AFTER_APPROVAL` at `schema.q:86:10`: createWorkshop: workshops.restockDue can change without a lifecycle/approval condition; should approved evidence or checked values remain editable?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:95:10`: scheduleDelivery: checks workshops.standing but leaves it unchanged while changing deliveries state; could repeating this transition reuse that guard?
- baseline: `N_GUARD_NOT_CONSUMED` at `schema.q:119:3`: logDelivery: checks workshops.standing but leaves it unchanged while changing deliveries state; could repeating this transition reuse that guard?
- baseline: `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/889741b43d990b40541072dfabb0e378f9fa8232ec60375398f70fd54e80a1f4/schema.q:109:3`: deliveries.status update: inferred effect prerequisite (.status != 'loaded' or (.approvedBy != null or not pastDue(.workshop))); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision
- baseline: `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/b6db27a0ad92cea919c5ca310d79c092ae7e093f06f10fc4aaf066775f369f2a/schema.q:119:3`: deliveries.status update: inferred effect prerequisite (.status != 'delivered' or (.approvedBy != null or not pastDue(.workshop))); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision
- final: `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/889741b43d990b40541072dfabb0e378f9fa8232ec60375398f70fd54e80a1f4/schema.q:109:3`: deliveries.status update: inferred effect prerequisite (.status != 'loaded' or (.approvedBy != null or not pastDue(.workshop))); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision
- final: `N_DERIVED_WRITE_AUTHORITY` at `$derived/sibling-approval/b6db27a0ad92cea919c5ca310d79c092ae7e093f06f10fc4aaf066775f369f2a/schema.q:119:3`: deliveries.status update: inferred effect prerequisite (.status != 'delivered' or (.approvedBy != null or not pastDue(.workshop))); judge before entering the selected destination, permitting atomic approval consumption; a replayed violation needs a specification decision

Rationale: No baseline diagnostic asks whether workshop identity is duplicable per owner or whether debt must aggregate across duplicate workshop rows. Standing-order guard reuse and pastDue(.workshop) prerequisites remain scoped to the chosen row, so neither is duplicate-resource coverage.

Verdict: No baseline question names the actual missing condition; excluded from the retention denominator. Broad/nearby advice is listed separately.

## Source/result custody hashes

- w26-002-snapback-compression-garment-fittings: source bundle `2181c58cb9e0249df90078f415157c18a23b697ead42fa86c51101df65837c25`.
  Source `/home/ccheever/sb4-loop/wave26/apps/002-snapback-compression-garment-fittings/snapback/schema.q` — `f109a1d032a67b153c8a1b81c960583e92c20de2de26145b97272ca301ceaa0a`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-002-snapback-compression-garment-fittings.json` — `7241ef1d5b37b39a133c323f027717a3c60d8183d77899f8ff9867b2075a25a3`.

- w26-008-snapback-stucco-repair-jobs: source bundle `62ef92d4fbaa3ad991a1e073166b6c5873743ed2b189452a4bd784854249ef0b`.
  Source `/home/ccheever/sb4-loop/wave26/apps/008-snapback-stucco-repair-jobs/snapback/schema.q` — `2b4846f2ef437d68d8c5969c33d0825f3cc29ebd673ad2d734ebf7587c148ed6`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-008-snapback-stucco-repair-jobs.json` — `af9a4372e6342bced32f6ad6d37dd9ba51e16b4e128c43a649c4e2e33e31954e`.

- w26-018-snapback-livestock-ultrasound-scans: source bundle `2c2291b716f699e4b0e367b4fae916cb727a2947d0ee261682e6773bf9fa4938`.
  Source `/home/ccheever/sb4-loop/wave26/apps/018-snapback-livestock-ultrasound-scans/snapback/schema.q` — `17e34b6af244258b7bd23c09bb3b47882b73a7bb399b2ab045191522b1837f3c`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-018-snapback-livestock-ultrasound-scans.json` — `661544a7f1132ffe6e8433126b162a458d88c72c4fcebe03f1d1c2060e61e4d7`.

- w26-020-snapback-llama-trekking-trips: source bundle `b858f88a3cf9a1dfe97301ef67d3bb58eb2ee28f046ef48f06cbda5a747cdd85`.
  Source `/home/ccheever/sb4-loop/wave26/apps/020-snapback-llama-trekking-trips/snapback/schema.q` — `50052394974df2470bd0e0d1757c64f5aa2a44a2f971e4d2fc4fe3f3667dc955`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-020-snapback-llama-trekking-trips.json` — `e1d3c5ce90aa2082235383041bb5c073c0a658649904f3ecc7ec1d8b942bf86e`.

- w26-024-snapback-billiard-table-relocations: source bundle `925f8faf758c6ca13eb8f77230d36446b8e0fa867cf50a99b25f0258ae755810`.
  Source `/home/ccheever/sb4-loop/wave26/apps/024-snapback-billiard-table-relocations/snapback/schema.q` — `fa41ac94918105f353c442e1f25728f84972fb2533937575b46400e744eb3c4b`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-024-snapback-billiard-table-relocations.json` — `b415d50833eef08b06f8796083b53297170ac3effd11d4f3db5d7def72c10bec`.

- w26-025-snapback-lifeguard-certification-exams: source bundle `b316a75e226990ad7dca291b9d34a1461ae69a0a56317eaa1704408ff711055c`.
  Source `/home/ccheever/sb4-loop/wave26/apps/025-snapback-lifeguard-certification-exams/snapback/schema.q` — `bbf301ffa13f5a4f66a4c099012d6526d4ce7365042c2d81b2fa9d10aef4e080`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-025-snapback-lifeguard-certification-exams.json` — `a3be06bf9e4edc722b4f68f11115398d62bf85452cf21e0ca3a9a3f6a139e959`.

- w26-031-snapback-ice-machine-cleanings: source bundle `7effae86bc723b4dc62968a1b551adf218ee00edddc9373fff3c655400bf5f27`.
  Source `/home/ccheever/sb4-loop/wave26/apps/031-snapback-ice-machine-cleanings/snapback/schema.q` — `42cecd02ca6fabebc9c9f42d2188565fb8a7e1fc539bf1b1c465690ee41704a0`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-031-snapback-ice-machine-cleanings.json` — `429193b54549407e28946034cfd23d50010ce4587f40b18db23a4820564b5089`.

- w26-033-snapback-asphalt-sealcoating-jobs: source bundle `7831c89e12a191e46587e6be1d20b332c692171aaa163f00b5539d23581963d6`.
  Source `/home/ccheever/sb4-loop/wave26/apps/033-snapback-asphalt-sealcoating-jobs/snapback/schema.q` — `9f8bdec4789ccdf17f4daa1d41adf2ee4237f93dd940cce8783ef32bf3d0d4eb`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-033-snapback-asphalt-sealcoating-jobs.json` — `ce77e50e677aeb9f6330195affde6b46718736937c4f25ffa5c1b1246b480566`.

- w26-034-snapback-luxury-watch-servicing: source bundle `6757181e00411e97a24fb4afc753b2d4af320bb388b2a08732f7aa9f7d77bb64`.
  Source `/home/ccheever/sb4-loop/wave26/apps/034-snapback-luxury-watch-servicing/snapback/schema.q` — `10f981001730cc5914f335b7268c6ee6f021f4ff487f2b683aaec3de5b2c009a`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-034-snapback-luxury-watch-servicing.json` — `76f484c60af50169a242cace0e77c632967a00df6e656fbfca4e7e590bc17b53`.

- w26-036-snapback-bronze-statue-casting: source bundle `a31a094e048c389b4a2876d1b80f5be020c2ce991462ccc599c5786b542fecec`.
  Source `/home/ccheever/sb4-loop/wave26/apps/036-snapback-bronze-statue-casting/snapback/schema.q` — `13ce915836f9638fcd487ca192016a10b2234e4822a8fc9a5d223f369d410c5e`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-036-snapback-bronze-statue-casting.json` — `4d264f2d7c99ddc1efd74b145387c87acb8e335f9a4fe59655118eaf85c9bb03`.

- w26-045-snapback-storm-shelter-installs: source bundle `0b2bbdf528d296c72f7b6fef6ac03e6123e199c22a111687baa27799244a9685`.
  Source `/home/ccheever/sb4-loop/wave26/apps/045-snapback-storm-shelter-installs/snapback/schema.q` — `212b8db4e0568249bfd62afdb347f9cf99b44cbf70398d4a4bfbbf64037aef23`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-045-snapback-storm-shelter-installs.json` — `bad62d23d43020d35f69098fcfac1d260658ef979c094dd61923417ef60e986d`.

- w26-046-snapback-sump-pump-repairs: source bundle `37c20618ebbe4e7d97999c78d06baa7f1d904084e38d1d64dd60aa6900ff1edd`.
  Source `/home/ccheever/sb4-loop/wave26/apps/046-snapback-sump-pump-repairs/snapback/schema.q` — `0a96345bcaf662c266ac54dda00d3df82dcad8bfd3cd54279b829d02acc88d87`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-046-snapback-sump-pump-repairs.json` — `438816ef51c0888a36382811c1526ed88579632d09ed018ede43d9e464fc4034`.

- w26-049-snapback-wedding-dj-bookings: source bundle `3b4c171310ce8bb73121a8e9ae7df590c042963821f7fa9205796f6153c3530c`.
  Source `/home/ccheever/sb4-loop/wave26/apps/049-snapback-wedding-dj-bookings/snapback/schema.q` — `d53b0d92f9b872228996f8805153972a74664d271a7ce13179f25aa264be4291`.
  Qualified result `/tmp/secp-evidence/accepted-final/w26-049-snapback-wedding-dj-bookings.json` — `a0e550be044b2053888e5304749539cfbcf580cb93dcc574f028b9c77203386e`.

- w28-011-snapback-home-battery-installs: source bundle `f2cdd1cbadfd2c286898f8474d6c9fde23811b7a5f3401766b5023f89accc62d`.
  Source `/home/ccheever/sb4-loop/wave28/apps/011-snapback-home-battery-installs/snapback/schema.q` — `8082cebd1e328174572b18089b8ce058dbb2d6cd629dba9a21d8cfeab645e9a4`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-011-snapback-home-battery-installs.json` — `6e834bed028e105d39474e60b487eecf3ffc65b84f83f5b869df1038fdd8a11d`.

- w28-013-snapback-lifting-sling-inspections: source bundle `60ec4b92071ebc205868e44306f8a4fc1a990d41c1b49043426d8ca86b223d33`.
  Source `/home/ccheever/sb4-loop/wave28/apps/013-snapback-lifting-sling-inspections/snapback/schema.q` — `f998ac0bbc1b5ad1d2b337a07775be05ef200ab56325f49354c8a08789eb97c0`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-013-snapback-lifting-sling-inspections.json` — `e08066b06410cc09dd22e3893ff2115bf0e76d49975d308e65dc607d6a803200`.

- w28-015-snapback-mobility-scooter-rentals: source bundle `e0bbe115a3fc3f838148b2222ebc538c94a993136bcab15f97320746ec0c4ca5`.
  Source `/home/ccheever/sb4-loop/wave28/apps/015-snapback-mobility-scooter-rentals/snapback/schema.q` — `d79d48ca0cff98e0f7834013fba849202f3a75765ce9aef5a3a3834c79f13d73`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-015-snapback-mobility-scooter-rentals.json` — `528f0a00a544b2af484ab932ec1d7283fc3608b917eba17616634e7f3954eccf`.

- w28-019-snapback-mature-tree-transplants: source bundle `458845cb8a3c16768ca3940258337c185db503429187afff060532cbd9a11cfa`.
  Source `/home/ccheever/sb4-loop/wave28/apps/019-snapback-mature-tree-transplants/snapback/schema.q` — `879ae88fb1380b3f0b21c9dde435a38d11c5fbde297952f808cc65457b146ef9`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-019-snapback-mature-tree-transplants.json` — `f92579f3dd10d713953b021edfe55d57be88b6224c95b292ebfd2f1565b14233`.

- w28-023-snapback-rv-roof-repairs: source bundle `be1968646832f218f429cd344e94b1a452076349260060f5ab395ed2a25052b6`.
  Source `/home/ccheever/sb4-loop/wave28/apps/023-snapback-rv-roof-repairs/snapback/schema.q` — `e4f079d851a17e1b8686e17ee7c88ea0c8b4878270b21dff6ec0f8270cba2516`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-023-snapback-rv-roof-repairs.json` — `6b9e1343b49c11b7dd7087008c7a2e8b5d5bdd09e10cdfde2acb7478fe4f8634`.

- w28-024-snapback-safe-moving-jobs: source bundle `e8a8d208927ac5fc1cd52fbd88bc0e6b3e6d0a69dbf1302398e46cedf989e6cd`.
  Source `/home/ccheever/sb4-loop/wave28/apps/024-snapback-safe-moving-jobs/snapback/schema.q` — `6a8b361b3244eb15d2cedd82daa53b12379f17bdb31ff40d123ce482a7ad9d58`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-024-snapback-safe-moving-jobs.json` — `faf01e80d52a7f43d85cd7718fe8dd204ba8ff44ba0c41d5fd289736fd1c34fe`.

- w28-032-snapback-assisted-living-placements: source bundle `dfeec40ee0f14603b9b3f613e597ca986d120fd01f7dc80ff69fec312d72dfd1`.
  Source `/home/ccheever/sb4-loop/wave28/apps/032-snapback-assisted-living-placements/snapback/schema.q` — `af7408fb70b39513467612e398f1cf279797dbee60ad76db12ba6b4a0af83a76`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-032-snapback-assisted-living-placements.json` — `b0dedd489aeac767bc9063655f54cd1e705e901d16a04dc3e6d98a7e8495b2a6`.

- w28-036-snapback-wax-figure-commissions: source bundle `845ebecf0d859f571fc849310825c92e8e45c4db11a2ce358a66bdd7874f8892`.
  Source `/home/ccheever/sb4-loop/wave28/apps/036-snapback-wax-figure-commissions/snapback/schema.q` — `08cd7bd79f4b3065f9eaba253303079af344323580d96dccd58f02edac53056f`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-036-snapback-wax-figure-commissions.json` — `88a5d6d6925124dd08271816f8b568d6abefb46ca966545fe02e9ded5096e0fd`.

- w28-043-snapback-playground-safety-inspections: source bundle `6585dd5d86a52a68b8ec85f2ef68b3907434f5c2c598f2fea404a32571d7c01f`.
  Source `/home/ccheever/sb4-loop/wave28/apps/043-snapback-playground-safety-inspections/snapback/schema.q` — `cab2b7754b5b4597b1f52e78d377f5539d940e5663fe3d7976579bff4391df98`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-043-snapback-playground-safety-inspections.json` — `5558fdd2317088629b050922ef60c5057712af008b083f7f678e0be26948ddee`.

- w28-046-snapback-furnace-repair-calls: source bundle `788844bd7daa3e2acc8290e29a4e37618309b57120ffdb0c1ea60170df85e56e`.
  Source `/home/ccheever/sb4-loop/wave28/apps/046-snapback-furnace-repair-calls/snapback/schema.q` — `db262784dbdf626ac842372d73f4a2de213422bbc483a264c06e8979a757d503`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-046-snapback-furnace-repair-calls.json` — `32fd92bb601376f9ecce19b03db015637787b3d98dacea36057fe00e8a753fce`.

- w28-047-snapback-henna-artist-bookings: source bundle `8076226e4c2b75b7e197cbec507cc7249a4632c87dce2c574e0bb7d195631ed1`.
  Source `/home/ccheever/sb4-loop/wave28/apps/047-snapback-henna-artist-bookings/snapback/schema.q` — `da3399744525efdc7e4c98a16c8d3aa177e9bb17de58774652dd0ac1ea389ed3`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-047-snapback-henna-artist-bookings.json` — `3a78198229d7d7a0d09ced6329b3c1fdf00ae32803a28396d5c890c122dadc81`.

- w28-050-snapback-home-generator-servicing: source bundle `8c65ad2fccc3be1e0d3821378473b7364a37bebee69d96d1f7f201d4cb9fb208`.
  Source `/home/ccheever/sb4-loop/wave28/apps/050-snapback-home-generator-servicing/snapback/schema.q` — `012bfefcc48b8296550381c3d17212be79f1902d572f1b6f05a2524d7fc5048c`.
  Qualified result `/tmp/secp-evidence/accepted-final/w28-050-snapback-home-generator-servicing.json` — `63d4888a538c9cf12e3b1b61899f9bbf344cceccd1d87f3bcf1ec06d9407a47b`.

- w30-002-snapback-infant-helmet-fittings: source bundle `9034b103ec66811db805fa33004ae2cd7368146ba0005c1d6bce6081529568ea`.
  Source `/home/ccheever/sb4-loop/wave30/apps/002-snapback-infant-helmet-fittings/snapback/schema.q` — `13a27232340e32586262037ae39f2c9630f8d8f308da6bbeb334749afac30175`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-002-snapback-infant-helmet-fittings.json` — `ab62d6bfdb2baf842c67774bae7f59bcb5c62fe0a191b77d461b83e8ca770fde`.

- w30-004-snapback-accessible-home-remodels: source bundle `7575c2ecbacea7dd0df0515c664dbbc6e5061e388830a0ea9b0d6c6510a5d023`.
  Source `/home/ccheever/sb4-loop/wave30/apps/004-snapback-accessible-home-remodels/snapback/schema.q` — `9b9794afc2d8ee22f89bca08d6fef0f0efc5386120fb1da31f451b94681f4778`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-004-snapback-accessible-home-remodels.json` — `8371875d6df15ee7bc109c5fdac2e80dbdcd1bbdb3abc56d3093e52e60c17915`.

- w30-006-snapback-fishing-reel-servicing: source bundle `c3df822afe624ea8aa70fe1d99d3b48dcdad7636844e2c62000e70f97a714e1f`.
  Source `/home/ccheever/sb4-loop/wave30/apps/006-snapback-fishing-reel-servicing/snapback/schema.q` — `a6a78dc7e09a4a5bae8122553199710e294bc00e6308611c1ffebadf941894a9`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-006-snapback-fishing-reel-servicing.json` — `943ed27206dda20cb3a15405f9d5bbfff9ad6f6fc37067ecf25fb925808feb7e`.

- w30-010-snapback-whitewater-rafting-trips: source bundle `dda8f617f089cf08b02c3d62af17bf349086b2521cd1a540d2b88973dce91fb3`.
  Source `/home/ccheever/sb4-loop/wave30/apps/010-snapback-whitewater-rafting-trips/snapback/schema.q` — `c1efcb5a6c4d77820dc8b1956a5db9f0a313d7cec54f66269e2338f91d1a65b0`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-010-snapback-whitewater-rafting-trips.json` — `91fd512bdc9d4b33ae4c41d9f983e32782a0f486646d2399ed8604b019700596`.

- w30-014-snapback-balloon-decor-installs: source bundle `fa9dec04559bb40592d9ae5458277ddaa760a75057e42a55b944f590dbec6854`.
  Source `/home/ccheever/sb4-loop/wave30/apps/014-snapback-balloon-decor-installs/snapback/schema.q` — `99c9823228cc50930a3229f0eecb2e4e6628c82d5d0d9f1cf403c2121981a4ab`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-014-snapback-balloon-decor-installs.json` — `4341ae72fad9861d1c52d7b491ca905c3af6e9364727513738b3c509cfa126b3`.

- w30-018-snapback-orchard-pruning-visits: source bundle `a35c590182c612e5d917919c133b207a7e281f20d6611467d4845e3c3314596a`.
  Source `/home/ccheever/sb4-loop/wave30/apps/018-snapback-orchard-pruning-visits/snapback/schema.q` — `5227a0fe8239f3b39617bb9dd57bb3f7cdc863baa82b17a34596688c57a7c30f`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-018-snapback-orchard-pruning-visits.json` — `041f0af625214e205198d1a7dd2f42f4fca0510bcfda6fc92cf5a1210926e13c`.

- w30-023-snapback-gutter-repair-calls: source bundle `0b1b6874b2a99b75c4cb765c803c4629800a4eb27eb7db7818f88ef63c3357c9`.
  Source `/home/ccheever/sb4-loop/wave30/apps/023-snapback-gutter-repair-calls/snapback/schema.q` — `7333e8663d05405f38e057c594f64b6832b52cc94abd3d8757500e416f94533d`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-023-snapback-gutter-repair-calls.json` — `e7720029dacd7dbf5a486d8867c53e552a05e529fb34669a6a09d8f6ef233fbe`.

- w30-025-snapback-chainsaw-safety-certifications: source bundle `a158805636666c7562b6b2898c1c2afed6e8011278bc3c59d80715e98a4b74c0`.
  Source `/home/ccheever/sb4-loop/wave30/apps/025-snapback-chainsaw-safety-certifications/snapback/schema.q` — `3d0aa3a00136e31027bd2b59ce44e4ec26c424be80638ed83b297d4cbdcbebe6`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-025-snapback-chainsaw-safety-certifications.json` — `2293918f70ab61a853142f57fc85a552b1b1cd6c256582bc5af3a7db67ae4703`.

- w30-030-snapback-acoustic-noise-studies: source bundle `444433f15a82fdd1657b2e55f9cad2120d20859a65070110a597740a44f2f2c9`.
  Source `/home/ccheever/sb4-loop/wave30/apps/030-snapback-acoustic-noise-studies/snapback/schema.q` — `4bd4dcab293956bdc4bfb7dca17f9a717fdfec735287ccb90550f18716428e08`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-030-snapback-acoustic-noise-studies.json` — `42d41de639d76626fa45ba7ccad027bb19aef9ec600e93af481022f647a3f45b`.

- w30-033-snapback-garage-floor-coatings: source bundle `aecca6627a94824947263446c037ccceda69a96717a6320ff1e09af081c6b4d7`.
  Source `/home/ccheever/sb4-loop/wave30/apps/033-snapback-garage-floor-coatings/snapback/schema.q` — `3cefc074528db8e63dd1d1a2b2e84b1c7f3f873b18e8fc656564e28e57283825`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-033-snapback-garage-floor-coatings.json` — `3c1324796a6950589cdc4a91b7b25beed1fcbe102ee0c3b241285c1f84b9b2b1`.

- w30-035-snapback-drapery-cleaning-batches: source bundle `ee74bc980be3140808afbf8be878bc7d9164ae33087befaa5bf2383584512ffe`.
  Source `/home/ccheever/sb4-loop/wave30/apps/035-snapback-drapery-cleaning-batches/snapback/schema.q` — `2e94a75b665e15957bf820a67ab33154839d41916d9614d4eb705b2eefc52f05`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-035-snapback-drapery-cleaning-batches.json` — `1778e65ef3fe409dc55f09761cbdac58f6a0b13c0c7f6f49fdcb4f9dd9e4e9d7`.

- w30-038-snapback-welding-gas-deliveries: source bundle `89385d4e367aacc3e95090316c95949123cf93341405df3a36af35954e2f8463`.
  Source `/home/ccheever/sb4-loop/wave30/apps/038-snapback-welding-gas-deliveries/snapback/schema.q` — `02af6074edb2e0c644676d43db64845b80576d075fe2602a4019e6b1557cdb7c`.
  Qualified result `/tmp/secp-evidence/accepted-final/w30-038-snapback-welding-gas-deliveries.json` — `223046070827658d0beaa2838375e9b80e02d5be23ff61e9da89c78c0302f06f`.

The calibration records contain related findings that share an underlying hole (for example wave26 025F1/F2). Counts above are per commissioned finding, not deduplicated root causes. `uncovered_before` is a baseline absence, not a regression. Broad questions are never promoted to exact matches to improve a count.
