# Wave30 independent manual SECP precision review

Frozen code: `11a2842a93`. Executable SHA256: `1d1ff5d2453f984ea66ecc48a6abfae905007b755fcedd2b464b28b623cc09b8`. All 50 lanes were manually inspected; all 50 before/after source-bundle hashes match the inspected `.q` files. The 51 source files include lane 017’s separate `invariants.q`. No apps, executables or tests were run by this review; no credentials read, source edits or agents used.

**653 before notes: 510 false, 143 real questions, 0 uncertain. 190 after notes: 60 false, 130 real questions, 0 uncertain.** This does not meet zero false on wave30. Every note occurrence, original-message SHA256 and exact source evidence is in [wave30-manual.json](/tmp/secp-evidence/wave30-manual.json).

A real question is a reviewable policy case, not an exploit, forbidden domain behavior or calibrated-hole detection. Domain intent remains unresolved for multiplicity/admin-policy choices. No uncertain classification was forced into false or real to meet a target. Static source judgments do not prove runtime safety.

## Counts per code and phase

| Code | Before false | Before real | Before uncertain | After false | After real | After uncertain |
|---|---:|---:|---:|---:|---:|---:|
| N_ARGUMENT_GRANT | 54 | 10 | 0 | 5 | 10 | 0 |
| N_DEPENDENT_WINDOW | 4 | 0 | 0 | 4 | 0 | 0 |
| N_EDIT_AFTER_APPROVAL | 276 | 2 | 0 | 3 | 1 | 0 |
| N_GUARD_NOT_CONSUMED | 53 | 19 | 0 | 0 | 1 | 0 |
| N_LOOKUP_FILTERED | 101 | 103 | 0 | 34 | 103 | 0 |
| N_QUERY_FILTERED | 14 | 5 | 0 | 6 | 5 | 0 |
| N_SWEEP_DEADLINE | 8 | 4 | 0 | 8 | 10 | 0 |

## Every remaining false / uncertain occurrence

All entries below are **false**; no uncertain occurrences remain. IDs use the original zero-based note index, so shared source sites remain distinct. SHA256 is abbreviated here; full digests and verbatim messages are in JSON. Each line reference is to that lane’s `snapback/schema.q`.

| Lane / original index | Code and site | Message SHA256 prefix | Exact evidence lines and reason |
|---|---|---|---|
| 003 / 5 | N_SWEEP_DEADLINE schema.q:100:1 | `8b369670702d6333` | 100, 101, 103, 104, 128, 130, 131: Pickup explicitly accepts ready and offered_for_sale; sweep changes ready to offered_for_sale, so it does not revoke pickup. No deadline bypass premise for this action. |
| 004 / 9 | N_LOOKUP_FILTERED schema.q:128:10 | `d449518899d27ad8` | 37, 65, 116, 117, 118, 128, 131, 132, 140, 141: Preceding staff guards imply jobs.read and rooms read through that same job. |
| 004 / 10 | N_LOOKUP_FILTERED schema.q:155:10 | `fb35b39d0ad8e552` | 78, 149, 155: Owner role guard precedes and implies cancellations.read. |
| 008 / 19 | N_LOOKUP_FILTERED schema.q:151:10 | `ad3f29db03aa3d89` | 40, 146, 151: Crew guard precedes return lookup and implies jobs.read. |
| 010 / 19 | N_LOOKUP_FILTERED schema.q:128:7 | `d331ebd3c01b9a9b` | 34, 127, 128, 153, 154: Preceding guide/head-guide or office/head-guide branches all imply trips.read. |
| 010 / 20 | N_LOOKUP_FILTERED schema.q:154:7 | `b6ed25e57805233c` | 34, 127, 128, 153, 154: Preceding guide/head-guide or office/head-guide branches all imply trips.read. |
| 011 / 11 | N_SWEEP_DEADLINE schema.q:84:1 | `654feb13da52eca2` | 85, 86, 88, 116, 117: Guard explicitly excludes closed and requires quoteDeadline > now for quote stage on same install. Disjunction handles already-accepted stages without an irrelevant quote deadline. |
| 012 / 26 | N_LOOKUP_FILTERED schema.q:145:10 | `492767db646d307a` | 4, 5, 6, 7, 9, 49, 70, 76, 82, 92, 105, 130, 139, 140, 141, 145: production/producer/owner helpers expand to staff roles admitted by each exact table read rule; guards precede lookups. |
| 013 / 15 | N_LOOKUP_FILTERED schema.q:96:7 | `c246492b00fd05ad` | 22, 44, 55, 56, 95, 102, 110, 123: staff() executes inspector/chief require before lookups; either branch implies ladders/inspections.read. |
| 013 / 16 | N_LOOKUP_FILTERED schema.q:103:7 | `3d2408b5171ec0b8` | 22, 44, 55, 56, 95, 102, 110, 123: staff() executes inspector/chief require before lookups; either branch implies ladders/inspections.read. |
| 013 / 17 | N_LOOKUP_FILTERED schema.q:105:7 | `bb4963c9a9bdd3aa` | 22, 44, 55, 56, 95, 102, 110, 123: staff() executes inspector/chief require before lookups; either branch implies ladders/inspections.read. |
| 013 / 18 | N_LOOKUP_FILTERED schema.q:111:7 | `19422d929b12ccd7` | 22, 44, 55, 56, 95, 102, 110, 123: staff() executes inspector/chief require before lookups; either branch implies ladders/inspections.read. |
| 013 / 19 | N_LOOKUP_FILTERED schema.q:124:7 | `06ea10f7293b7fe1` | 22, 44, 55, 56, 95, 102, 110, 123: staff() executes inspector/chief require before lookups; either branch implies ladders/inspections.read. |
| 013 / 20 | N_LOOKUP_FILTERED schema.q:126:7 | `ca74b5209b823557` | 22, 44, 55, 56, 95, 102, 110, 123: staff() executes inspector/chief require before lookups; either branch implies ladders/inspections.read. |
| 017 / 15 | N_EDIT_AFTER_APPROVAL schema.q:115:3 | `c5c20f4ae05901d1` | 97, 100, 101, 102, 103, 113, 114, 115: Same-party status guards constrain every listed change; cancellation derives deposit policy from event date. |
| 018 / 4 | N_ARGUMENT_GRANT schema.q:81:10 | `4e8df0dd3eed6b23` | 71, 78, 79, 81: Grower must equal actual orchard owner; insert policy additionally requires manager and same orchard/grower relationship. |
| 018 / 7 | N_LOOKUP_FILTERED schema.q:52:7 | `0c4b05a5ec7c6f58` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 10 | N_LOOKUP_FILTERED schema.q:96:7 | `30f65872f62d4088` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 11 | N_LOOKUP_FILTERED schema.q:104:7 | `096798fea7c086ea` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 12 | N_LOOKUP_FILTERED schema.q:106:7 | `35c36e93bae748c1` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 13 | N_LOOKUP_FILTERED schema.q:115:7 | `8debae0eaf266936` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 16 | N_LOOKUP_FILTERED schema.q:164:7 | `a53a1a36d4f0694b` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 17 | N_LOOKUP_FILTERED schema.q:171:7 | `1ea45b4d376f7947` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 018 / 18 | N_LOOKUP_FILTERED schema.q:173:7 | `4d38e2443cc53acb` | 15, 36, 70, 94, 95, 102, 103, 113, 114, 154, 162, 163, 169, 170, 50, 51: Exact roles[viewer] lookup plus non-null manager/pruner/lead guard precedes these resource reads and implies their staff audience. |
| 020 / 7 | N_ARGUMENT_GRANT schema.q:117:10 | `b68a9456e85739dc` | 110, 111, 112, 117, 118: Authorized office reads exact roles[principal=rider], requires person.role=rider, then copies that validated rider into ride and receipt. Recipient role is explicitly proved; no self-only relationship requirement is stated. |
| 020 / 8 | N_ARGUMENT_GRANT schema.q:118:3 | `97b782054586eca9` | 110, 111, 112, 117, 118: Authorized office reads exact roles[principal=rider], requires person.role=rider, then copies that validated rider into ride and receipt. Recipient role is explicitly proved; no self-only relationship requirement is stated. |
| 020 / 16 | N_LOOKUP_FILTERED schema.q:138:10 | `6d299eb8d5a39ab9` | 35, 50, 51, 52, 117, 118, 134, 135, 138: Only receipt insertion copies rider from the same fresh ride, with immutable rider/ride fields and unique ride. The preceding ride-owner-or-office/owner guard therefore proves this linked receipt audience; initial ride lookup remains separately real. |
| 022 / 6 | N_ARGUMENT_GRANT schema.q:82:10 | `c630fe86996fe248` | 78, 79, 80, 82: Authorized desk reads exact roles[principal=rider] and requires its role=rider before assigning that recipient. Recipient role is answered by actual keyed guard, not merely a variable name. |
| 022 / 11 | N_LOOKUP_FILTERED schema.q:79:7 | `ce2cc6114728c6ba` | 9, 39, 78, 79, 85, 86, 92, 93, 102, 103: Preceding assistant/owner or workshop guard directly implies each exact resource read rule. |
| 024 / 14 | N_DEPENDENT_WINDOW schema.q:116:10 | `678bb45ee3f526d4` | 82, 83, 91, 114, 115, 116, 123, 125: scheduleService inserts kind=service, distinct from anchor checks. anchorDueAt governs anchor checks, not arbitrary later service visits; premise is irrelevant. |
| 024 / 15 | N_DEPENDENT_WINDOW schema.q:126:3 | `6fa2a2d30abce39c` | 82, 83, 97, 120, 121, 122, 123, 124, 125, 126: Anchor visit.deadline is copied from same installation now+60d as anchorDueAt and immutable; anchor rescheduling explicitly checks scheduledAt <= that deadline. Service visits intentionally have a separate window. |
| 024 / 21 | N_LOOKUP_FILTERED schema.q:86:10 | `49608e0c101b5555` | 49, 77, 78, 86, 98, 119, 120, 130, 131: Preceding installer/operations guard proves exact installs/visits.read audience. |
| 025 / 10 | N_ARGUMENT_GRANT schema.q:152:10 | `2271f55546785689` | 148, 149, 150, 152: Manager validates candidate equals actual priorExam.candidate before keyed approval grant. |
| 027 / 19 | N_LOOKUP_FILTERED schema.q:143:7 | `31e82a50e8bfc45a` | 24, 40, 51, 142, 149, 159, 167, 179, 193: All branches of preceding manager/workshop guards imply read policy of exact museums/builds/pricing table. |
| 027 / 20 | N_LOOKUP_FILTERED schema.q:152:7 | `911db6a159eb38be` | 24, 40, 51, 142, 149, 159, 167, 179, 193: All branches of preceding manager/workshop guards imply read policy of exact museums/builds/pricing table. |
| 027 / 21 | N_LOOKUP_FILTERED schema.q:190:10 | `67d221877f98b41e` | 24, 40, 51, 142, 149, 159, 167, 179, 193: All branches of preceding manager/workshop guards imply read policy of exact museums/builds/pricing table. |
| 029 / 15 | N_LOOKUP_FILTERED schema.q:94:7 | `a7d94f3b01af1053` | 15, 53, 90, 93, 94, 100, 101, 106, 107, 112, 113: Completed mayDispatch proves office or driver role, either admitted by shipments.read before second lookup; office() directly proves reschedule read. |
| 029 / 17 | N_LOOKUP_FILTERED schema.q:101:7 | `866cb44b21d24bd6` | 15, 53, 90, 93, 94, 100, 101, 106, 107, 112, 113: Completed mayDispatch proves office or driver role, either admitted by shipments.read before second lookup; office() directly proves reschedule read. |
| 029 / 19 | N_LOOKUP_FILTERED schema.q:107:7 | `e21cbe62f24ffbfd` | 15, 53, 90, 93, 94, 100, 101, 106, 107, 112, 113: Completed mayDispatch proves office or driver role, either admitted by shipments.read before second lookup; office() directly proves reschedule read. |
| 031 / 17 | N_LOOKUP_FILTERED schema.q:182:7 | `7fc23e8c4fef10c8` | 22, 36, 53, 181, 186, 191, 199, 220: Preceding planner/manager or technician guards imply exact building/tower/cleaning read policy. |
| 031 / 18 | N_LOOKUP_FILTERED schema.q:217:10 | `a0951da874d5339e` | 22, 36, 53, 181, 186, 191, 199, 220: Preceding planner/manager or technician guards imply exact building/tower/cleaning read policy. |
| 032 / 14 | N_DEPENDENT_WINDOW schema.q:138:10 | `a60a75071371a430` | 19, 40, 49, 52, 133, 134, 135, 136, 137, 138, 145, 146, 147, 148, 149, 150, 153, 154, 155: Campus visit startsAt is not enrolled-placement checkin deadline. schools has no deadline column. Checkin due is created on enrollment and enforced by recordCheckin; name-based parent deadline premise is irrelevant for scheduling campus visits. |
| 032 / 15 | N_DEPENDENT_WINDOW schema.q:138:10 | `de817aa71c23b6e3` | 19, 40, 49, 52, 133, 134, 135, 136, 137, 138, 145, 146, 147, 148, 149, 150, 153, 154, 155: Campus visit startsAt is not enrolled-placement checkin deadline. schools has no deadline column. Checkin due is created on enrollment and enforced by recordCheckin; name-based parent deadline premise is irrelevant for scheduling campus visits. |
| 033 / 6 | N_EDIT_AFTER_APPROVAL schema.q:102:3 | `a1d8475cd1a5b64e` | 99, 100, 101, 102, 108, 109, 110: Only owner-scoped write to dampSigned sets true; approval requires true and no operation resets it. This cannot alter the checked value after approval, only repeat an idempotent signoff. |
| 033 / 14 | N_QUERY_FILTERED schema.q:131:10 | `f1d8fe5f2a5ae19c` | 56, 125, 130, 131, 166, 171, 172: Successful exists jobs[job] implies current row audience, which is exactly owner or staff. Photo/report predicates restrict same job and grant those same audiences. |
| 033 / 15 | N_QUERY_FILTERED schema.q:156:10 | `cf4e8b35c6c4d02a` | 54, 116, 144, 146, 154, 155, 156: Guard proves owner of same job or staff; sole invoice insert copies that immutable customer, so exact linked invoice rows have proved audience. |
| 033 / 16 | N_QUERY_FILTERED schema.q:172:10 | `7be3488c417971a6` | 56, 125, 130, 131, 166, 171, 172: Successful exists jobs[job] implies current row audience, which is exactly owner or staff. Photo/report predicates restrict same job and grant those same audiences. |
| 035 / 14 | N_SWEEP_DEADLINE schema.q:84:1 | `6eaf7345c6368bb1` | 85, 87, 88, 89, 130, 131: Same batch quoteAt age is explicitly compared to now before acceptance, in subtraction form. |
| 036 / 16 | N_SWEEP_DEADLINE schema.q:141:1 | `59e7fe8060ae3e6a` | 117, 118, 119, 124, 125, 144, 145, 153, 154, 168, 169: Both operations require carvedAt non-null. Its sole writer is carving->sewing, reachable only after deadline-checked artwork approval leaves approval stage. Cancellation job only acts in approval stage. These requests cannot admit the expiring pending-approval case. |
| 036 / 17 | N_SWEEP_DEADLINE schema.q:148:1 | `83ae8ffd54c0ad10` | 117, 118, 119, 124, 125, 144, 145, 153, 154, 168, 169: Both operations require carvedAt non-null. Its sole writer is carving->sewing, reachable only after deadline-checked artwork approval leaves approval stage. Cancellation job only acts in approval stage. These requests cannot admit the expiring pending-approval case. |
| 038 / 13 | N_LOOKUP_FILTERED schema.q:121:10 | `8e742ac3667799e2` | 41, 113, 121: Dispatcher guard precedes return read and implies deliveries.read. |
| 039 / 16 | N_QUERY_FILTERED schema.q:140:10 | `b12481c3b750af0a` | 49, 50, 135, 136, 139, 140, 155, 156, 159, 160: Visible parent implies buyer or staff audience. Child insert policies require same reservation/buyer and immutable fields preserve identity, so returned same-reservation care/photos share the proved audience. |
| 039 / 17 | N_QUERY_FILTERED schema.q:160:10 | `1fc45ea280782030` | 49, 50, 135, 136, 139, 140, 155, 156, 159, 160: Visible parent implies buyer or staff audience. Child insert policies require same reservation/buyer and immutable fields preserve identity, so returned same-reservation care/photos share the proved audience. |
| 041 / 11 | N_SWEEP_DEADLINE schema.q:79:1 | `dff2c5ba90b6de74` | 72, 73, 74, 75, 82, 83, 84, 85, 86, 121, 122: setStage requires quoteApproved=true on this trunk. Expiry job requires not quoteApproved, so mutation excludes expiring state; approval time was checked when flag was set. |
| 042 / 21 | N_SWEEP_DEADLINE schema.q:110:1 | `dbdb06ca72c4ca6b` | 111, 113, 114, 119, 120: returnItem performs exactly the terminal return that expiry job performs. Deadline is an automatic return obligation, not a cutoff revoking manual return; premise irrelevant. |
| 043 / 6 | N_EDIT_AFTER_APPROVAL schema.q:132:3 | `16e4163b94577833` | 95, 96, 98, 102, 103, 105, 114, 115, 116, 127, 128, 129, 130, 131, 132: Exact inspection stage checked. Issued-report editing only through branch-manager amendment with unapproved request and matching baseRevision. |
| 043 / 14 | N_LOOKUP_FILTERED schema.q:129:7 | `c55b6b1bc401b8b0` | 33, 34, 50, 123, 127, 129: Manager guard already proves a.branch; sole amendment insert copies same inspection branch and both links/branch immutable. Thus keyed a.inspection is in proved manager branch before second lookup. |
| 045 / 11 | N_QUERY_FILTERED schema.q:132:10 | `78a7eafdacaff9d6` | 28, 43, 44, 88, 130, 131, 132: Only claim creation binds homeowner to same install owner, and both owner/link immutable. Parent owner-or-staff guard therefore proves exact returned claims audience. |
| 046 / 13 | N_LOOKUP_FILTERED schema.q:99:7 | `dc20c79a9a8cb2ca` | 9, 23, 24, 25, 54, 95, 102, 108, 115, 122: Expanded dispatcher/technician/manager helpers precede lookups and directly imply exact roles/jobs.read policy. |
| 048 / 8 | N_SWEEP_DEADLINE schema.q:92:1 | `53608b4d382fde37` | 80, 81, 82, 95, 96, 97, 116, 117: advanceBuild requires approvedAt non-null; expiry job requires approvedAt null. This excludes the expiring state. Approval time was already checked in approveDesign. |

## Apparently lost real questions

Manual cross-code/property review found **18 semantic properties represented by 19 baseline note occurrences** absent from the final questions. These are mostly intentional-scope policy questions about repeating records; absence does not establish a regression or a hole. A surviving lookup, deadline, evidence-presence or approval warning about another property does not retain them.

| Lane | Before indices / code / site | Semantic property and cross-code assessment |
|---|---|---|
| 005 | 16, 17; N_GUARD_NOT_CONSUMED; schema.q:140 | Repeat design-change approvals/version increments in an unchanged allowed commission stage. New held/storage sweep questions address timeliness, not repeated change requests; they do not retain this property. |
| 006 | 25; N_GUARD_NOT_CONSUMED; schema.q:138 | Repeated drag-fault reports for one returned reel during its warranty window. Remaining lookups and gear-approval informational notes do not ask about repeated drag reports or free re-service billing. |
| 007 | 21; N_GUARD_NOT_CONSUMED; schema.q:96 | Multiple trial submissions for the same open commission without per-submission uniqueness. Trial evidence-presence advice asks whether a trial exists, not whether repeated submissions reuse the same parent window. |
| 008 | 20; N_GUARD_NOT_CONSUMED; schema.q:101 | Repeated course-consent records for the same active job/course. Unique approval prevents applying the same course twice but does not prevent recording repeated consents; approval informational notes do not ask this question. |
| 008 | 23; N_GUARD_NOT_CONSUMED; schema.q:172 | Repeated leak reports during one completed job warranty window. Remaining lookup warning concerns pre-read authority, not report multiplicity. |
| 018 | 8; N_EDIT_AFTER_APPROVAL; schema.q:53 | Changing the orchard quarantine classification after visit approval or progress. Derived pruning prerequisites concern visits.status at pruneVisit, not changing orchards.quarantine. Manager override may be deliberate; no exploit claim. |
| 018 | 22; N_GUARD_NOT_CONSUMED; schema.q:166 | Repeated missed-tree entries for the same visit/treeTag. Standing-role warning was false and is excluded. Remaining touchup reads do not ask about repeated treeTag entries. |
| 021 | 13; N_GUARD_NOT_CONSUMED; schema.q:135 | Multiple payment records against one polished lot without balance/unique-lot consumption. The final seven-code set is empty in this lane; ordinary access questions elsewhere are not a payment-multiplicity question. |
| 024 | 17; N_GUARD_NOT_CONSUMED; schema.q:116 | Repeated service visits scheduled against one anchored installation. Dependent-window and caller-time notes concern dates, not whether service bookings repeat. |
| 025 | 22; N_GUARD_NOT_CONSUMED; schema.q:152 | Repeated upsert approval of one failed prior exam, replacing approval reason/recommendation/time. Recipient binding and approval-not-enforced notes do not ask about reissuing/overwriting this approval. This differs from calibrated reuse of an old approval at later logExam calls. |
| 033 | 12; N_GUARD_NOT_CONSUMED; schema.q:137 | Repeated photo attachments while a job remains quoted. A retained sweep-window note at addPhoto is about expiry, and child-evidence advice asks for presence. Neither is repeated photo insertion. |
| 033 | 13; N_GUARD_NOT_CONSUMED; schema.q:180 | Repeated missed-area reports within one topcoated job window. Remaining parent-read/filtering questions are different properties. |
| 036 | 21; N_GUARD_NOT_CONSUMED; schema.q:146 | Repeated change requests for a carved mascot before closing. Approval informational and sweep questions do not constrain repeated request records. |
| 038 | 15; N_GUARD_NOT_CONSUMED; schema.q:95 | Multiple deliveries scheduled against the same standing/restock eligibility. Mutable-deadline and credit-hold effect questions do not ask about repeated scheduling. This is also not the calibrated duplicate-workshop credit-hold property. |
| 039 | 16; N_GUARD_NOT_CONSUMED; schema.q:145 | Repeated care observations while one reservation remains in care. Care readership and child evidence questions do not ask about log multiplicity. Recurring observations may be intentional. |
| 042 | 20; N_GUARD_NOT_CONSUMED; schema.q:84 | Multiple offers recorded while an item remains listed. Retained listing-expiry questions concern when offers may be recorded, not offer multiplicity. |
| 043 | 21; N_GUARD_NOT_CONSUMED; schema.q:123 | Multiple amendment requests for one issued inspection/base revision. Standing branch identity question was false and excluded. Stale-revision check prevents applying multiple amendments from one revision, but request duplication remains possible; informational approval note is not the same question. |
| 045 | 11; N_GUARD_NOT_CONSUMED; schema.q:88 | Multiple warranty claims for one completed installation/kind/window. ClaimsFor read filtering and ownership lookups do not ask whether repeated claims should be permitted. |

The cancelled-trip repeated-create question in **010 rebookTrip, schema.q:165** remains, including the rebook-versus-refund reuse property. No real lookup, recipient-grant or query-read property from the baseline was lost; one real edit-policy property and 18 repeat-policy occurrences were removed. Six new real sweep-window occurrences were added in 005 and 041.

## Calibration and separate baseline gate/refutation context

The supplied calibration has 17 non-dismissed Snapback findings and 6 dismissed findings. Only **010 F1** directly matches an in-scope real question, and it is retained. Relevant outside-scope questions are context only; none substitute for exact calibrated-hole detection or a replay.

| Lane / calibration finding | Context and limits |
|---|---|
| 002 F1 (M) | Text-reference versus verified-upload question is present; mandatory presence/optional omission is not explicitly asked. Do not count it as complete coverage of the calibrated missing-referral case. |
| 004 F1 (M) | Explicitly asks whether every coordinator should read jobPrivate without a row relationship. This is a relevant policy question about assignment scope, not proof of the calibrated violation. |
| 006 F1 (M) | No question matches billing re-service again. Repeated drag reports and gear approval notes are unrelated. |
| 010 F1 (M) | Exact existing cancelled-trip guard stays unchanged after a replacement insert. The retained repeated-create question covers the rebook/refund entitlement reuse property; no exploit replay was run. |
| 014 F1 (M) | Protected private-column lead/owner audience explicitly asks all rows versus resource relationships. Relevant scope question retained; not a refutation. |
| 014 F2 (L) | No question identifies early takedown before eventAt. Caller event date at creation is a different property. |
| 018 F1 (M) | Derived prerequisite covers pruneVisit only. It does not ask about missing approval on pruneTouchup; no calibrated touchup coverage credited. |
| 023 F1 (L) | No emitted question asks for scheduledAt lower bound in openJob; reference/evidence notes are unrelated. |
| 025 F1 (M) | General separately-authorized approval warning does not identify caller-asserted attempt and relabeling a third sitting as attempt=1/2. No exact calibrated-counter coverage credited. |
| 025 F2 (M) | General approval-enforcement advice does not identify reuse of a candidate/priorExam approval for a fifth sitting. Removed approveRetest repeated-upsert note concerns approval issuance, not logExam consumption; no exact later-attempt coverage credited. |
| 030 F1 (M) | Explicit optional/empty recordings question is relevant and retained. Source review is not an exploit replay. |
| 030 F2 (M) | False edit-without-lifecycle note does not ask whether measured->reported skips reviewed. Removal is not loss of calibrated stage-order coverage. |
| 030 F3 (L) | Optional-presence note does not ask about allowed sound MIME types. No text/plain-as-audio coverage credited. |
| 033 F1 (M) | A preexisting gate asks about dampApproved missing from acceptQuote. Record it separately from precision; its message does not establish detection of the calibrated crew advanceJob/topcoat path. No refutation/replay claim. |
| 033 F2 (M) | Explicit question names absent photos and acceptQuote/advanceJob, so the calibrated missing-child-evidence property has a retained relevant question. |
| 035 F1 (M) | False edit note ignores approved-status guard; it does not ask about arbitrary stage jumps. Do not credit removal as loss of calibrated stage-order detection. |
| 038 F1 (M) | Restock recheck warning does not identify a duplicate workshop for the same owner escaping pastDue(workshop). Repeated deliveries on an existing workshop are also unrelated. |

Recorded gate counts: before 1, after 1. Recorded check refutations: before 0, after 0. These are separate from the advisory classifications. The JSON contains exact gate records. Lane 033 returns check exit 1 in both phases with its preexisting damp-approval gate; all 50 JSON results exist and no missing result was treated as clean. No runtime replay was performed.

## Concrete SECP fixes required

- Honor exact statement-style helper requirements and keyed roster aliases (013 staff(); 018 roles[viewer] then role guard); keep the first pre-guard lookup reviewable.
- Preserve read-authority facts whose actual dependencies survive unrelated writes; return lookups remain authorized in 004,008,012,024,027,031,038. Track mayDispatch successful-call postconditions for its second reads in 029, while retaining its initial lookup questions.
- Prove every arm of directly guarded staff unions against the exact reader union, including row-dependent alternatives (010,022,027,031,046).
- Recognize actual recipient guards: keyed target rider-role checks (020/022), grower=orchard.owner (018), candidate=priorExam.candidate (025); caller staff membership alone remains insufficient.
- Follow exact parent/child ownership or branch identity from enforced insert policies/immutable constructors for 020,033,039,043,045, without accepting same-named fields on unrelated resources.
- Restrict dependent windows to actual action kind and stored anchor: service versus anchor visits (024), campus visits versus enrollment checkins and nonexistent school deadline (032).
- Exclude sweep cases using full Boolean/state guards, subtraction-form time comparisons, and source reachability (011,035,036,041,048). Do not warn about a revoked right when schema explicitly permits post-sweep pickup or the action itself is terminal return (003,042).
- Honor one-way checked-value writes and explicit approval-gated amendment policy (017 depositKept,033 dampSigned=true,043 approved/baseRevision-bound report amendment).
- For any claim of preserving every real question, reconcile the 18 semantic properties/19 occurrences listed as apparently lost. Their domain policy is unresolved; do not restore irrelevant one-shot assumptions or relabel unrelated retained warnings as coverage.

This review requests detector/reporting fixes only. It does not request changes to frozen source applications. The full baseline false inventory is retained per occurrence in JSON; the table above lists every false/uncertain item remaining after the change.
