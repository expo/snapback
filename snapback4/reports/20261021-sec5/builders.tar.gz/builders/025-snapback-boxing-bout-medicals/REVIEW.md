# Independent security-intent review

## Scope and method

Product authority: `SPEC.md`. Language and workflow authority: the installed snapback4 README and installed CLI guides (`start`, `security --full`, `testing --full`, `rules --full`). I read the authored `snapback/schema.q` and the CLI-generated per-role/per-column questionnaire. No other project's materials or package implementation were used. Questionnaire answers below are review decisions, not acceptance of generated draft policy.

Only single-line invariant declarations in the authored schema were changed. Rules, operations, comments, fields and authentication declarations retain their original bytes. No enforcement repair is included. Generated CLI artifacts are evidence, not authored policy.

## Specification decisions

The named roles are boxer, coach, matchmaker, ringside physician and commission inspector. A second user with the same role must be considered independently: another boxer cannot acquire my medical history merely by being a boxer. Coaches and matchmakers are explicitly allowed each boxer's weight, bout record and photo; the specification supplies no coach assignment, team, consent or patient-assignment restriction. Inventing one would change the product. Physicians and inspectors have club-wide clinical access for the named duties; no physician-to-patient assignment is stated.

The explicit restriction on physician notes and suspension reasons takes precedence over the general statement that boxers see their own medical history. It applies to notes wherever stored, including `exams.resultNotes`, and to value-dependent observations and downloads. A boxer may read their own exam history and scan, but may not read physician-only annotations. A scan containing those annotations would require a separate protected original and a redacted owner-visible copy.

I interpret the enumerated coach/matchmaker data access as permission for matching data, not full clinical exam files or historical exam rows. Thus exam row existence, identity, owner, date and scan are owner/physician/inspector only. This is a conservative interpretation of the specification's separation of matching data and medical history, rather than an explicit sentence naming scan recipients. The direct, unambiguous violation to check separately is owner access to physician-authored `resultNotes`.

Current exam/suspension eligibility metadata is useful to arranging safe bouts. I retain owner and named staff access to the current `boxers.examAt`, `suspensionUntil`, and their eligibility booleans: the specification explicitly restricts reasons and notes, not these eligibility values. This is an implementation choice within an underspecified audience, not a claim that coaches are explicitly granted every medical timestamp. Historical exam files remain restricted. The stronger alternative of exposing only eligibility booleans would need a separate projection; a source-column invariant would also constrain derived booleans.

The live bout card can carry participants, venue, date and confirmation/result status across participants. The specification does not define private draft/cancelled cards, a card viewer roster, or an authenticated-role-only audience. I do not invent those restrictions. Public-to-signed-in card access is retained as a documented design choice; its uncovered read exposure is not silently treated as proved confidential. Medical stoppage identifiers and explanations need separate treatment because they can disclose why a boxer is suspended.

No role assignment or historical relationship implicitly survives as elevated authority: staff predicates refer to the current viewer's role. The existing immutable owner is an authenticated ownership relationship, not a freely selected principal argument. Ownership remains meaningful even without an active boxer role; it does not confer clinical staff authority.

## Answers to the generated questionnaire

Every entry below answers both rows and named columns, including asset downloads and derived values. `Own` means the row's authenticated principal/owner equals the viewer, never another user of the same role. `All` means all club rows; `None` denies that audience. `Self` means only the viewer's own role row. All roles are current roles. A no-role/no-relationship account has no matching owned record. No expiry, consent flag, team or assignment restriction on historical reads is stated. Expired exams and expired/lifted suspensions do not make notes public or erase the owner's history.

| Row or column | No role / no relationship | Boxer | Coach | Matchmaker | Physician | Inspector |
| --- | --- | --- | --- | --- | --- | --- |
| roles.read, roles.principal, roles.role | None | Self | Self | Self | Self | Self |
| boxers.read, boxers.id | None | Own | All | All | All | All |
| boxers.owner | None | Own | All | All | All | All |
| boxers.name | None | Own | All | All | All | All |
| boxers.weightLb | None | Own | All | All | All | All |
| boxers.wins | None | Own | All | All | All | All |
| boxers.losses | None | Own | All | All | All | All |
| boxers.draws | None | Own | All | All | All | All |
| boxers.photo, photo download | None | Own | All | All | All | All |
| boxers.examAt | None | Own | All | All | All | All |
| boxers.suspensionUntil | None | Own | All | All | All | All |
| eligibility.examValid | None | Own | All | All | All | All |
| eligibility.suspended | None | Own | All | All | All | All |
| boxers.physicianNotes | None | None | None | None | All | All |
| boxers.suspensionReason | None | None | None | None | All | All |
| exams.read, exams.id | None | Own | None | None | All | All |
| exams.boxer | None | Own | None | None | All | All |
| exams.owner | None | Own | None | None | All | All |
| exams.takenAt | None | Own | None | None | All | All |
| exams.scan, scan download | None | Own, redacted if needed | None | None | All | All |
| exams.resultNotes | None | None | None | None | All | All |
| bouts.read, bouts.id | All | All | All | All | All | All |
| bouts.boxerA | All | All | All | All | All | All |
| bouts.boxerB | All | All | All | All | All | All |
| bouts.boutAt | All | All | All | All | All | All |
| bouts.venue | All | All | All | All | All | All |
| bouts.status | All | All | All | All | All | All |
| bouts.stoppedBoxer (medical stoppage) | None | None | None | None | All | All |
| bouts.method (potential clinical explanation) | None | None | None | None | All | All |

The card decisions apply to proposed, confirmed, completed and cancelled states because no per-state privacy distinction is stated. Protected result fields stay protected in every state. Publishing ordinary nonclinical sporting outcomes could be supported by an explicitly separate field; the existing free-text physician result method has no restriction preventing it from containing a clinical suspension explanation. The stopped-boxer link identifies the triggering medical event under the mandatory 30-day rule. I conservatively classify these as derived suspension reasons; this classification is a privacy interpretation, not an assertion that every sporting result is inherently medical. Do not copy protected reasons into any public card field.

The operator service seat is an implementation mechanism, not a sixth product role. It may appoint roles through trusted provisioning and receives no clinical read exemption. Other service seats have no extra access. Unauthenticated access is not authorized; real password identity is declared. The privacy of role-directory rows is an existing least-disclosure implementation choice, while trusted appointment is necessary to keep inspector/physician authority from being self-claimed.

### Authority questions

| Resource/effect | Audience, relationship and lifecycle answer |
| --- | --- |
| roles.insert/update, principal/role writes, provision | Trusted operator only; no self-promotion by any of the five product roles. The exact service name is an accepted implementation mechanism. |
| roles.delete | No deletion workflow is specified; existing denial is retained. Role immutability also prevents routine reassignment/demotion; no such workflow is required by the spec. |
| boxers.insert | An authenticated boxer can register their own record. No caller-selected owner. This is a reasonable profile-entry workflow rather than an explicit spec requirement to self-register. |
| boxers.update | Owner can maintain own matching profile; clinical staff perform clinical actions. A broad row update rule alone must not grant owners medical-field authority. |
| boxers.examAt update / recordExam | Physician records actual exam evidence and its date; owner/coach/matchmaker cannot renew medical clearance. Historical dates may be valid input, but future dates cannot create fictitious validity. |
| boxers.physicianNotes update / setNotes | Physician authors the physician notes. Inspector visibility does not by itself imply authorship. |
| boxers.suspensionUntil/reason update | Physician can impose the required suspension and inspector can lift it. Owners, coaches and matchmakers cannot edit these fields. Role-only update intent is necessary but does not prove the transition/duration requirement. |
| boxers.liftSuspension | Current commission inspector only, on an existing suspension that is still active. No physician or boxer early-lift authority. |
| boxers.delete | No deletion workflow is specified; retain denial. |
| exams.insert / recordExam | Physician recording a real exam for the selected boxer; owner copied from that boxer. Scan is required. This clinical writer workflow is inferred from the physician's duty. |
| exams.update/delete | No historical edit/removal workflow is stated; retain existing denial. |
| bouts.insert / proposeBout | Current matchmaker pairs different boxers for a future bout, using weight/experience. No boxer or coach self-confirmation. |
| bouts.update | Matchmaker manages proposal/confirmation/cancellation; physician records clinical result. A general role-wide update grant is only an upper bound, not permission for either role to perform every transition. |
| bouts.confirmBout | Current matchmaker, proposed and future bout, both boxers medically valid and not suspended at the relevant participation time. |
| bouts.cancelBout | Matchmaker, proposed or confirmed. This existing workflow is a reasonable design choice, not an explicit exclusive cancellation rule in SPEC.md. |
| bouts.recordResult / boxers.recordResult | Physician handles a confirmed bout result and a stopped participant; only a participant can receive this bout's stop. Must preserve any longer existing suspension unless inspector authorizes early lifting. |
| bouts.delete | No deletion workflow is specified; retain denial. |

No hard-coded per-coach assignment invariant, public-card state restriction, arbitrary medical-history expiry, or inspector-only blanket suspension-field writer was added. The last would wrongly prohibit the physician from imposing a suspension. Operation-specific inspector intent is included separately from the weaker physician-or-inspector column update bound.

## Lifecycle requirements and limits of declarations

The actual exam date starts one year of validity. Future-dated exams are not valid evidence, expired exams stay in history, and time passing must change eligibility without a cleanup sweep. `recordExam` accepts unbounded caller-supplied `takenAt`; `eligibility` and `confirmBout` check only the lower date bound. Validate `takenAt <= now`, retain historical input, and confirm the intended calendar-year versus 365-day convention. Confirmation uses `now` rather than the scheduled bout date: a card can be confirmed although the exam will expire before the show. Re-evaluate eligibility for participation, not just at an arbitrarily early confirmation.

A stop requires a suspension through 30 days after the actual bout stop. `recordResult` accepts unbounded `stoppedAt` and overwrites the previous deadline, so an old supplied time can produce an already-ended suspension and a later result can shorten an existing longer suspension. The leading physician role check does not establish inspector-only early-lift intent across operations. Use a trusted event time tied to the actual bout and preserve the later active deadline; permit shortening only under current inspector authority. A physician result should not be able to manufacture the effect of `liftSuspension` by choosing a time.

These are transition, evidence-time, cross-row integrity and temporal requirements. The documented invariant fragment does not provide a general old-to-next transition theorem or a reduction for every dynamic time expression. I did not substitute an incorrect `always` assertion about current validity (history is supposed to expire), or an inspector-only ordinary update predicate that would reject legitimate physician suspensions. They remain manual findings requiring enforcement and temporal cases; current role declarations are necessary partial intent, not proof of the full requirements.

## Recommended enforcement work (not performed)

1. Narrow the exam audience to the owner and current physician/inspector, including scan downloads, row existence and dates. Gate `resultNotes` to physician/inspector even for the owner. Store a redacted scan separately if the original contains private physician annotations.
2. Protect stopped-boxer and clinician method fields as potential derived suspension reasons. Publish nonclinical card data independently. A public completed status by itself is not a clinical explanation; links and text can be.
3. Give profile fields and medical fields separate authority. The current whole-row owner update rule admits updates to medical fields beyond the authored profile mutation. Current exposed operations may constrain what can be exercised; do not claim an executable owner bypass without a trace. Independently gate medical columns at the backend and preserve the medical history's owner/boxer correspondence.
4. Enforce real exam/bout times, future-date bounds, safe 30-day suspension transitions, and eligibility at participation as described above. Keep `liftSuspension` inspector-only across every path.
5. Retain password authentication and trusted role provisioning. Generated two-per-role test principals exercise security but do not prove that two real password accounts of every role have been provisioned for the application. That product acceptance requirement remains unverified in this review. No credentials were read or fabricated.
6. `bouts` is `online only`; the schema does not declare replicated live card data. Whether a frontend subscribes/refetches is outside these authored files. Verify actual live card updates separately. The counters `wins/losses/draws` also have no authored result-update logic; accurate bout records are not established by these security declarations.

## Verification results

The first expanded review had 44 declarations: check exited 0 with 14 proved and 30 unproved. Its fixture-only run reached timeout (exit 124 at 180 seconds) without emitting stdout/stderr. I removed duplicate role/profile/history-column and operation declarations where existing row/effect invariants already supplied the same bound. I also added independent column-read intent for medical stoppage and method data. The final schema has 26 declarations (the original seven are retained, with boxer insertion strengthened; 19 are added). No retained audience was widened to make a check pass.

The final-source check exited 0 and reported `ok: true`: 9 proved and 17 unproved, not 26 security proofs. Direct rule implication is not established for exam-history privacy, exam-result notes, the two medical result columns, or four medical update policies; the CLI requires concrete replay before declaring a refutation. Remaining reasons include logical refusals/existence, raw role probes, cross-table observations, opaque operation control flow and wire metadata. The check's bounded concrete campaign exhausted its time budget. The sole uncovered row/effect exposure is public signed-in `bouts.read`, deliberately documented above rather than covered by a tautology.

Final fixture and audit outcomes are recorded below after completion. Complete unedited stdout/stderr captures are `check.json`, `test.txt` and `audit.json`. Empty output on timeout is preserved as empty output. Nonzero exits and unproved paths are retained, not repaired by widening policy.
