
**Boxing Bout Medicals.** An amateur boxing club runs shows, and the matchmaker pairs boxers by weight and experience, with each boxer's medical exam scan uploaded. Coaches and the matchmaker see each boxer's weight, bout record and photo, but the ringside physician's notes and any medical suspension reason on the same boxer's record are visible only to the physician and the commission inspector. Boxers see only their own medical history, the bout card updates live as matches are confirmed, a medical exam is valid for one year after it is taken, and a boxer stopped in a bout is suspended for 30 days after it. Only the commission inspector can lift a suspension early.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
