-- Athletic Trainer Injuries (Snapback 4 / Quarry)
-- Roles: trainer, physician, coach, parent. Real password identity.
-- Privacy: row rules decide WHO sees an injury row; column rules hide
-- diagnosis/treatment/doctorNote from coaches and parents.

use identity password

table roles:
  principal: principal
  role: enum('trainer', 'physician', 'coach', 'parent')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('trainer', 'physician', 'coach', 'parent')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[principal = viewer]

table athletes:
  name: text 1..80
  parent: principal ?
  read <- .parent = viewer or exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (.parent = null and exists roles[principal = viewer, role = 'parent'])
  insert <- exists roles[principal = viewer, role = 'trainer']
  update (old, next) <- exists roles[principal = viewer, role = 'trainer'] or (exists roles[principal = viewer, role = 'parent'] and old.parent = null and next.parent = viewer)
  delete <- exists roles[principal = viewer, role = 'trainer']
  cap 500
  online only

-- Trainer registers an athlete; the parent slot starts empty and the parent
-- claims it (or the trainer fills it when the principal is known).
mutation registerAthlete(name: text 1..80, parent: principal ?):
  require exists roles[principal = viewer, role = 'trainer'] else NOT_TRAINER
  return insert athletes { name, parent }

-- A parent links themselves to their child's roster row.
mutation claimChild(athlete: athletes):
  require exists roles[principal = viewer, role = 'parent'] else NOT_PARENT
  a = athletes[athlete] ! else NOT_FOUND
  require a.parent = null else ALREADY_CLAIMED
  update athletes[athlete] { parent: viewer }
  return null

query myChildren(c: cursor ?):
  return athletes where .parent = viewer first 50 by .id after c

query allAthletes(c: cursor ?):
  require exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] else NOT_STAFF
  return athletes last 50 by .id after c

table injuries:
  athlete: athletes
  kind: enum('concussion', 'other')
  diagnosis: text 1..500 read <- exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
  treatment: text 1..1000 read <- exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
  photo: image <=5000000 ?
  doctorNote: image <=5000000 ? read <- exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
  status: enum('cleared', 'limited', 'out')
  expectedReturn: time ?
  injuredAt: time default now
  immutable athlete, kind, injuredAt
  read <- exists athletes[.athlete, parent = viewer] or exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach']
  insert <- exists roles[principal = viewer, role = 'trainer']
  update <- exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
  delete <- exists roles[principal = viewer, role = 'trainer']
  cap 5000
  online only

-- One of photo / doctorNote is required (spec: "a photo of the injury or the
-- doctor's note"). injuredAt may be backdated to the real injury date but
-- never set in the future; limited/out require an expected return date.
mutation logInjury(athlete: athletes, kind: enum('concussion', 'other'), diagnosis: text 1..500, treatment: text 1..1000, photo: image <=5000000 ?, doctorNote: image <=5000000 ?, status: enum('cleared', 'limited', 'out'), expectedReturn: time ?, injuredAt: time ?):
  require exists roles[principal = viewer, role = 'trainer'] else NOT_TRAINER
  a = athletes[athlete] ! else NOT_FOUND
  require photo != null or doctorNote != null else EVIDENCE_REQUIRED 'A photo of the injury or the doctor note is required.'
  at = injuredAt ?? now
  require at <= now else BAD_DATE 'The injury date cannot be in the future.'
  require status = 'cleared' or expectedReturn != null else NEED_RETURN_DATE 'Limited or out requires an expected return date.'
  if kind = 'concussion' and status = 'cleared':
    require exists roles[principal = viewer, role = 'physician'] else ONLY_PHYSICIAN 'Only the team physician can clear a concussion.'
    require now >= at + 7d else TOO_EARLY 'A concussion cannot be cleared within seven days.'
  return insert injuries { athlete, kind, diagnosis, treatment, photo, doctorNote, status, expectedReturn, injuredAt: at }

-- Trainers and physicians move status; concussion clears are physician-only
-- and only once seven days have passed since the injury.
mutation updateStatus(injury: injuries, status: enum('cleared', 'limited', 'out'), expectedReturn: time ?):
  require exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] else NOT_STAFF
  row = injuries[injury] ! else NOT_FOUND
  require status = 'cleared' or expectedReturn != null else NEED_RETURN_DATE 'Limited or out requires an expected return date.'
  if row.kind = 'concussion' and status = 'cleared':
    require exists roles[principal = viewer, role = 'physician'] else ONLY_PHYSICIAN 'Only the team physician can clear a concussion.'
    require now >= row.injuredAt + 7d else TOO_EARLY 'A concussion cannot be cleared within seven days.'
  update injuries[injury] { status, expectedReturn }
  return null

-- Trainers and physicians revise the clinical fields (never dropping the
-- last piece of evidence).
mutation updateClinical(injury: injuries, diagnosis: text 1..500, treatment: text 1..1000, photo: image <=5000000 ?, doctorNote: image <=5000000 ?):
  require exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] else NOT_STAFF
  row = injuries[injury] ! else NOT_FOUND
  require (photo ?? row.photo) != null or (doctorNote ?? row.doctorNote) != null else EVIDENCE_REQUIRED 'A photo of the injury or the doctor note is required.'
  update injuries[injury] { diagnosis, treatment, photo: photo ?? row.photo, doctorNote: doctorNote ?? row.doctorNote }
  return null

-- Staff roster: every injury, live. Clinical columns stay hidden for coaches
-- by the column rules above.
query roster(c: cursor ?):
  require exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] else NOT_STAFF
  return injuries last 50 by .id after c

-- A parent sees only their own child's entries.
query childInjuries(c: cursor ?):
  return injuries where exists athletes[.athlete, parent = viewer] last 50 by .injuredAt after c

query athleteInjuries(athlete: athletes, c: cursor ?):
  a = athletes[athlete] ! else NOT_FOUND
  return injuries where .athlete = athlete last 50 by .injuredAt after c

query injuryDetail(injury: injuries):
  return injuries[injury]

invariant injuries.read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and exists athletes[.athlete, parent = viewer])
invariant injuries.diagnosis read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.treatment read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.doctorNote read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.insert only exists roles[principal = viewer, role = 'trainer']
invariant injuries.athlete read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and exists athletes[.athlete, parent = viewer])
invariant injuries.photo read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and exists athletes[.athlete, parent = viewer])
invariant injuries.status read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and exists athletes[.athlete, parent = viewer])
invariant injuries.expectedReturn read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and exists athletes[.athlete, parent = viewer])
invariant injuries.injuredAt read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and exists athletes[.athlete, parent = viewer])
invariant injuries.kind read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant athletes.read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and .parent = viewer)
invariant athletes.name read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and .parent = viewer)
invariant athletes.parent read only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician'] or exists roles[principal = viewer, role = 'coach'] or (exists roles[principal = viewer, role = 'parent'] and .parent = viewer)
invariant athletes.insert only exists roles[principal = viewer, role = 'trainer']
invariant athletes.update only exists roles[principal = viewer, role = 'trainer']
invariant athletes.delete only exists roles[principal = viewer, role = 'trainer']
invariant athletes.name write only exists roles[principal = viewer, role = 'trainer']
invariant athletes.parent write only exists roles[principal = viewer, role = 'trainer']
invariant injuries.update only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.delete only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.diagnosis write only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.treatment write only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.photo write only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.doctorNote write only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.status write only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.expectedReturn write only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.athlete write only exists roles[principal = viewer, role = 'trainer']
invariant injuries.kind write only exists roles[principal = viewer, role = 'trainer']
invariant injuries.injuredAt write only exists roles[principal = viewer, role = 'trainer']
invariant injuries.logInjury only exists roles[principal = viewer, role = 'trainer']
invariant injuries.updateStatus only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant injuries.updateClinical only exists roles[principal = viewer, role = 'trainer'] or exists roles[principal = viewer, role = 'physician']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
invariant roles.delete only viewer = 'service:operator'
invariant roles.principal write only viewer = 'service:operator'
invariant roles.role write only viewer = 'service:operator'
invariant roles.provision only viewer = 'service:operator'
invariant injuries always .photo != null or .doctorNote != null
invariant injuries always .kind != 'concussion' or .status != 'cleared' or now >= .injuredAt + 7d
