
**Athletic Trainer Injuries.** A high school athletic trainer logs each injury with a photo of the injury or the doctor's note and a playing status of cleared, limited or out. Coaches see each injured athlete's entry with its status and expected return date, but not the diagnosis, treatment notes or doctor's note on the same entry, which only the athletic trainer and the team physician see. Parents see only their own child's entries, the coach's roster shows availability live as statuses change, and an athlete with a concussion cannot be cleared until at least seven days after the injury. Only the team physician can clear a concussion.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
