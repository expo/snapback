
**Luthier Crack Repairs.** A guitar and violin repair shop logs every instrument brought in with photos of each crack, worn fret or loose seam and the owner's description of the problem. The luthier writes an estimate, which the owner must approve within 14 days or the instrument is returned unrepaired, and a finished instrument not collected within 45 days of its ready notice starts a storage charge. Owners see only their own instruments and estimates, apprentices see the live bench board as jobs move through gluing, setup and final check, and only the shop owner can approve a repair that costs more than the instrument's appraised value, recording why.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
