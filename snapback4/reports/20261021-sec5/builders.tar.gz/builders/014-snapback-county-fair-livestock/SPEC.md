
**County Fair Livestock.** A county fair runs a youth livestock show, and exhibitors register each animal with its ear tag, a photo and a weight card. An animal must have been tagged at least 90 days before its entry to be eligible, and a health certificate older than 30 days at arrival is rejected. Exhibitors see only their own animals and placings, club leaders see their own club members' entries, and the barn office sees the live board of animals arriving and weighing in. Only the livestock superintendent can disqualify an animal or reweigh it after a dispute, with the original weight and the reason kept.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
