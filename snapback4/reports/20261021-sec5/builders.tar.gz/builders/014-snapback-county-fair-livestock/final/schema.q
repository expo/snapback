-- County Fair Livestock: youth livestock show entries.
-- Roles: exhibitor (registers animals), leader (club leader, reads own club),
-- office (barn office, arrival + weigh-in + live board), superintendent
-- (disqualify + reweigh + placings). Password identity; roles are
-- operator-provisioned (see guide staging).
use identity password

table roles:
  principal: principal
  role: enum('exhibitor', 'leader', 'office', 'superintendent')
  club: text 1..40
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('exhibitor', 'leader', 'office', 'superintendent'), club: text 1..40):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, club }

query myRole():
  return roles[viewer]

table animals:
  owner: principal
  club: text 1..40
  earTag: text 1..30
  species: text 1..40
  photo: image <=5000000
  weightCard: image <=5000000
  taggedAt: time
  healthCertAt: time
  weight: int 1..5000
  originalWeight: int 1..5000 ?
  status: enum('entered', 'arrived', 'weighed', 'disqualified') default 'entered'
  arrivalAt: time ?
  weighedAt: time ?
  dqReason: text 1..500 ?
  reweighReason: text 1..500 ?
  place: int 1..10 ?
  showClass: text 1..40 ?
  createdAt: time default now
  unique earTag else TAG_TAKEN
  immutable owner, club, earTag, taggedAt, healthCertAt, createdAt, photo, weightCard
  cap 50 by owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
  insert <- .owner = viewer and exists roles[principal = viewer, role = 'exhibitor']
  update <- exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
  delete <- deny
  online only

-- Spec: an animal must be tagged at least 90 days before entry.
mutation registerAnimal(earTag: text 1..30, species: text 1..40, photo: image <=5000000, weightCard: image <=5000000, taggedAt: time, healthCertAt: time, weight: int 1..5000):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'exhibitor' else NOT_EXHIBITOR
  require taggedAt <= now - 90d else TAG_TOO_RECENT 'Animal must be tagged at least 90 days before entry.'
  require healthCertAt <= now else CERT_FUTURE 'Health certificate cannot be dated in the future.'
  return insert animals { owner: viewer, club: me.club, earTag, species, photo, weightCard, taggedAt, healthCertAt, weight }

-- Spec: a health certificate older than 30 days at arrival is rejected.
mutation recordArrival(animal: animals):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'office' else NOT_OFFICE
  a = animals[animal] ! else NOT_FOUND
  require a.status = 'entered' else BAD_STATUS 'Only entered animals may arrive.'
  require a.healthCertAt >= now - 30d else CERT_EXPIRED 'Health certificate is older than 30 days.'
  update animals[a.id] { status: 'arrived', arrivalAt: now }
  return null

mutation weighIn(animal: animals, weight: int 1..5000):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'office' else NOT_OFFICE
  a = animals[animal] ! else NOT_FOUND
  require a.status = 'arrived' else BAD_STATUS 'Only arrived animals may be weighed.'
  update animals[a.id] { weight, weighedAt: now, status: 'weighed' }
  return null

-- Spec: only the superintendent may reweigh after a dispute; the original
-- weight and the reason are kept.
mutation reweigh(animal: animals, weight: int 1..5000, reason: text 1..500):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'superintendent' else NOT_SUPERINTENDENT
  a = animals[animal] ! else NOT_FOUND
  require a.status = 'weighed' else BAD_STATUS 'Only weighed animals may be reweighed.'
  update animals[a.id] { weight, originalWeight: a.originalWeight ?? a.weight, reweighReason: reason }
  return null

-- Spec: only the superintendent may disqualify; the reason is kept.
mutation disqualify(animal: animals, reason: text 1..500):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'superintendent' else NOT_SUPERINTENDENT
  a = animals[animal] ! else NOT_FOUND
  require a.status != 'disqualified' else BAD_STATUS 'Animal is already disqualified.'
  update animals[a.id] { status: 'disqualified', dqReason: reason }
  return null

mutation assignPlacing(animal: animals, place: int 1..10, showClass: text 1..40):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'superintendent' else NOT_SUPERINTENDENT
  a = animals[animal] ! else NOT_FOUND
  require a.status = 'weighed' else BAD_STATUS 'Only weighed animals may be placed.'
  update animals[a.id] { place, showClass }
  return null

query myAnimals(c: cursor ?):
  me = roles[viewer] ! else NO_ROLE
  return animals where .owner = viewer first 100 by .id after c

query clubAnimals(club: text 1..40, c: cursor ?):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'leader' and me.club = club else NOT_CLUB_LEADER
  return animals where .club = club first 100 by .id after c

query liveBoard(c: cursor ?):
  me = roles[viewer] ! else NO_ROLE
  require me.role = 'office' or me.role = 'superintendent' else NOT_BOARD
  return animals first 100 by .id after c

query animalDetail(animal: animals):
  return animals[animal]

-- Spec intent (audience and authority, not copies of the enforcement above).
-- Exhibitors read only their own animals and placings.
invariant animals.read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
-- Only the superintendent disqualifies or reweighs.
invariant animals.disqualify only exists roles[principal = viewer, role = 'superintendent']
invariant animals.reweigh only exists roles[principal = viewer, role = 'superintendent']
-- Only exhibitors register entries.
invariant animals.registerAnimal only exists roles[principal = viewer, role = 'exhibitor']
-- Only the barn office records arrival and weigh-in.
invariant animals.recordArrival only exists roles[principal = viewer, role = 'office']
invariant animals.weighIn only exists roles[principal = viewer, role = 'office']
invariant animals.id read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.owner read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.club read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.earTag read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.species read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.photo read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.weightCard read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.taggedAt read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.healthCertAt read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.weight read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.originalWeight read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.status read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.arrivalAt read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.weighedAt read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.dqReason read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.reweighReason read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.place read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.showClass read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.createdAt read only .owner = viewer or exists roles[principal = viewer, role = 'leader', club = .club] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.insert only .owner = viewer and exists roles[principal = viewer, role = 'exhibitor']
invariant animals.update only exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'superintendent']
invariant animals.delete only deny
invariant animals.originalWeight update only exists roles[principal = viewer, role = 'superintendent']
invariant animals.reweighReason update only exists roles[principal = viewer, role = 'superintendent']
invariant animals.dqReason update only exists roles[principal = viewer, role = 'superintendent']
invariant animals.status update only exists roles[principal = viewer, role = 'superintendent'] or (exists roles[principal = viewer, role = 'office'] and .status != 'disqualified')
invariant animals always .photo != null
invariant animals always .weightCard != null
invariant animals always .status != 'disqualified' or .dqReason != null
invariant animals always .originalWeight = null or .reweighReason != null
invariant animals always .reweighReason = null or .originalWeight != null
invariant roles.read only .principal = viewer or viewer = 'service:operator'
invariant roles.id read only .principal = viewer or viewer = 'service:operator'
invariant roles.principal read only .principal = viewer or viewer = 'service:operator'
invariant roles.role read only .principal = viewer or viewer = 'service:operator'
invariant roles.club read only .principal = viewer or viewer = 'service:operator'
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
invariant roles.delete only viewer = 'service:operator'
invariant roles.provision only viewer = 'service:operator'
invariant roles.principal write only viewer = 'service:operator'
invariant roles.role write only viewer = 'service:operator'
invariant roles.club write only viewer = 'service:operator'
