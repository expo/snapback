# County Fair Livestock security-intent review

This review uses only SPEC.md, the authored snapback/schema.q, the installed snapback4 README, and installed CLI guides and generated results. The guide start and guide security --full were read first. The security loop was initial check → answer its questionnaire from the spec → author independent invariants → check → test --fixture-only → audit. No rules, operations, comments, imports, or other existing non-invariant source lines were changed. No application server was started manually.

## Interpretation of the specification

The explicit privacy boundaries are ownership for exhibitors and club membership for leaders. An exhibitor role does not grant access to another exhibitor's animal, even in the same club. A leader's role does not grant access to other clubs, even when another leader can read those entries. Both leaders of a club may read its entries. The barn office has a fair-wide operational board; both office users have the same fair-wide audience. Both superintendents need fair-wide entry access to exercise the specified disqualification and disputed-reweigh functions. No per-superintendent assignment is specified.

The specification does not prescribe a separate public board, hide particular entry columns from staff, require consent, or restrict reads to particular statuses. I interpret the office board as the operational entry record, including identifying evidence, eligibility dates, arrival/weighing information, results, and dispute/disqualification information. Entered animals form its arrival queue; weighed and disqualified animals remain operational records. This is a scope interpretation of the brief, not a claim that it explicitly enumerates every office field. No invariant invents a ban on office photographs, weight cards, reasons, placings, or pre-arrival/post-weighing rows. If the intended board is a limited projection, define its field list and lifecycle explicitly and enforce it in the backend; this review does not silently invent that policy.

The same applies to entry details for the owner and the relevant club leaders: the brief grants animals/entries, not just an ear-tag projection. The specification provides no separate confidentiality rule for a disqualification reason or an original weight. Those values still cannot escape the entry's audience, including via image downloads and derived observations. Placings are not public merely because they are results.

Ownership is an enduring resource relationship: removing an exhibitor's role is not specified to revoke access to their existing animals. A signed-in owner can therefore continue to read those entries. Current leader/club, office, and superintendent assignments must be checked on every server read; a former staff role cannot retain staff authority through an old grant. There is no offline sync in this schema. No age, consent, release, or expiry policy is invented from the youth-show setting.

The auxiliary roles table is not a product roster. Keeping each user's own role/club visible to them, with administrative visibility and writes reserved for the credentialed service:operator seat, is a supporting implementation policy consistent with real authentication and protected authority. SPEC.md does not explicitly demand role-record confidentiality or name an operator role. These assertions preserve a reasonable existing provisioning boundary rather than presenting it as an extra product requirement. The service seat is included explicitly in intent and is not assumed exempt. It receives no animal read or write privilege merely from being the operator.

## Questionnaire answers: rows, each column, and lifecycle

The generated questionnaire contains 121 questions: 95 animal row/column questions, 20 role row/column questions, and six effect questions. These matrices answer all 121, with implicit IDs and the service seat assessed additionally. This matrix answers every row and column question generated in snapback/generated/security-invariants.q.draft. Each row below applies independently to all five generated audiences; the operator column additionally covers the implemented service seat. “Own” means owner = viewer; “club” means a current leader with roles.club = animals.club; “all” means fair-wide records. A caller with neither a role nor a resource relationship has no animal access. If that caller owns an existing animal, the ownership relationship still applies. Role holders with an additional ownership relationship retain their owner access. An ordinary signed-in caller never inherits the operator seat.

Every admitted read below is permitted in entered, arrived, weighed, and disqualified states. An optional value may be absent before its relevant event; absence is not permission for a wider audience to learn whether that event occurred. There is no consent condition in SPEC.md.

| Animal target | No role or relationship | Exhibitor | Leader | Office | Superintendent | Operator without another grant |
|---|---|---|---|---|---|---|
| read / logical existence | none | own | club (or own) | all | all | none |
| id | none | own | club (or own) | all | all | none |
| owner | none | own | club (or own) | all | all | none |
| club | none | own | club (or own) | all | all | none |
| earTag | none | own | club (or own) | all | all | none |
| species | none | own | club (or own) | all | all | none |
| photo / download | none | own | club (or own) | all | all | none |
| weightCard / download | none | own | club (or own) | all | all | none |
| taggedAt | none | own | club (or own) | all | all | none |
| healthCertAt | none | own | club (or own) | all | all | none |
| weight | none | own | club (or own) | all | all | none |
| originalWeight | none | own | club (or own) | all | all | none |
| status | none | own | club (or own) | all | all | none |
| arrivalAt | none | own | club (or own) | all | all | none |
| weighedAt | none | own | club (or own) | all | all | none |
| dqReason | none | own | club (or own) | all | all | none |
| reweighReason | none | own | club (or own) | all | all | none |
| place | none | own | club (or own) | all | all | none |
| showClass | none | own | club (or own) | all | all | none |
| createdAt | none | own | club (or own) | all | all | none |

The row invariant animals.read and the corresponding animals.<column> read invariants encode that audience separately from the rules. The photo and weightCard assertions include asset downloads. The original broad leader invariant was replaced: it lacked club equality. Its previous weakness was an intent defect; the current enforcement already includes club equality. A matching predicate is retained only after the above independent interpretation.

There are no authored views, maintained totals, exported files, or computed columns. originalWeight, place, showClass, status, arrivalAt, weighedAt, and the reason columns are sensitive event/result values even though stored rather than computed. Any future category, ordering, count, existence test, download, or other value-dependent derivation must respect the contributing field's audience. IDs and logical existence have explicit coverage too, even though the generated column questionnaire omits implicit IDs.

| Roles target | No role or relationship | Exhibitor | Leader | Office | Superintendent | Operator |
|---|---|---|---|---|---|---|
| read / logical existence | none; own record if one exists | own record | own record | own record | own record | all |
| id | none; own record if one exists | own record | own record | own record | own record | all |
| principal | none; own record if one exists | own record | own record | own record | own record | all |
| role | none; own record if one exists | own record | own record | own record | own record | all |
| club | none; own record if one exists | own record | own record | own record | own record | all |

Neither two users with the same role nor two leaders of the same club can read each other's role records. Club entry readership does not require roster disclosure. There is no role-record lifecycle/consent condition. roles.read and all four roles column-read declarations encode these answers. Direct raw probes used in authorization still require review as indirect observations; a private role row alone does not prove that its predicates cannot be inferred elsewhere.

## Questionnaire answers: authority and integrity

| Effect question | Answer and independent intent |
|---|---|
| animals.insert | A currently provisioned exhibitor registers their own animal. No leader, office user, superintendent, or operator registers on another user's behalf. animals.insert constrains both caller role and owner relationship. Registration copies the caller's provisioned club. The caller cannot appoint themselves exhibitor or choose another owner/club through the authored operation. |
| animals.update | The operational writers are the barn office for arrival/initial weighing and the superintendent for disqualification/disputed reweigh. No exhibitor/leader edits exist in the described workflow. animals.update declares the broad writer set; the operation/column assertions below constrain exclusive powers. The spec does not expressly assign placing authorship; the existing superintendent-only assignPlacing behavior is an implementation choice, not independently promoted to a new exclusive spec requirement. |
| animals.delete | No delete workflow is specified; deleting evidence would conflict with keeping the original weight and reason. Preserve denial with animals.delete only deny. A future retention/deletion feature needs an explicit policy. |
| roles.insert | Only credentialed service:operator provisions a role/club for a chosen principal. Ordinary account signup does not confer authority. |
| roles.update | Only that operator can change role/club assignments. No role can promote itself, appoint a peer, or self-claim another club. The service's recipient choice is trusted administration, not an invitation flow specified by this app. |
| roles.delete | Only that operator may revoke role records. Revocation must stop staff access on subsequent server reads. Existing owner access remains as explained above. |

The existing operation assertions for disqualify and reweigh express the explicit “only the livestock superintendent” requirement and are retained. The existing registerAnimal, recordArrival, and weighIn assertions express the chosen operational division and are retained. Added originalWeight, reweighReason, and dqReason update assertions protect the evidence fields across operations. They deliberately use update rather than write: exhibitors create entries with those optional fields absent, which must not require superintendent authority. The status update assertion permits only the superintendent to move into or edit a disqualified record; office arrival/weigh-in transitions remain permitted. The old-and-next-image meaning is intentional: no office operation is specified on an already disqualified animal.

The required photo and weight card get non-null integrity assertions. A disqualified record must retain a non-null reason. A stored original weight and a reweigh reason must occur together. Text minimums in the schema make a present reason nonblank. These implications capture stored-state obligations, not the full history requirement.

The 90-day tagging boundary is measured at entry, not at read time. The health certificate's 30-day boundary is measured at arrival, not at registration or a later read. Do not hide old records when these intervals elapse. The authored mutations compare server now and use inclusive boundaries, so exactly 90 days and exactly 30 days are admitted. taggedAt and healthCertAt are caller-supplied claimed evidence dates; the backend cannot establish real-world document authenticity just from timestamps. The schema makes those dates and images immutable after entry. This review does not invent a historical-date prohibition beyond the stated eligibility rules.

Exact date arithmetic and cross-operation preservation of the first pre-dispute weight are not expressible with the documented simple invariant predicate vocabulary. They remain explicit review obligations rather than tautological declarations. The authored reweigh operation saves a.originalWeight ?? a.weight, retaining the first original weight through repeated reweighs, and requires a nonblank reason. It stores only the latest reason: if “the reason kept” is intended to require a history of every dispute, an append-only dispute record is needed. The brief does not explicitly specify multiple-dispute history, so this review flags that limitation without claiming such a history exists or weakening the first-original-weight requirement.

A blanket weight-update-only-superintendent assertion would incorrectly forbid the barn office's initial weigh-in. Likewise, setting status != disqualified on every animal update would incorrectly forbid the superintendent's disqualification. The declarations avoid those mistakes. The exclusive named-operation declarations remain necessary; broad table update authority alone does not prove those exclusive operations.

## Verification results and recommendations

Results will be recorded here after the requested command loop completes. Commands are bounded with timeout, run from this directory, and full stdout/stderr is preserved without truncation in the requested files.

### Enforcement observations and recommended follow-up

- The animal read rule already enforces owner and current matching-club leader access. The replaced invariant now preserves that club boundary instead of blessing all leaders. Both current staff roles are deliberately fair-wide under the operational-record interpretation above. The matching-rule advisories are answered by the audience matrices, not suppressed.
- The table update rule admits office or superintendent on every column and status. The authored office operations currently limit their patches to arrival and initial weighing, and require the expected prior status. The independent evidence-column and disqualified-status assertions are stronger than that broad rule. Tightening backend update/field policy to the intended transition and evidence writers would make this boundary explicit across future operations. An unproved implication against the table rule is not by itself an executed office disqualification or reweigh.
- Every specified exclusive operation reads the caller's role before looking up the animal. Manual inspection finds superintendent checks before disqualify/reweigh and office checks before recordArrival/weighIn. No role-grant mutation can be called by an ordinary role; provision requires service:operator. The argument-grant advisory is assessed as trusted administrative recipient selection in this implementation. Preserve the authenticated service boundary and audit its provisioning; do not change role assignment to self-service signup.
- Refusal, hidden-unique ear-tag collision, raw role-probe, scan, and protocol-metadata paths remain proof obligations even when the direct read implication is proved. The animal-dependent status refusals follow current-role guards and are used by fair-wide operational staff. This is no demonstrated cross-owner/club leak. If a restricted caller can reach a hidden-row-sensitive refusal, unify hidden/absent/denied codes and messages or narrow the observer; do not widen the privacy invariant. Role.club is intentionally copied into the owner's entry at registration, so its strict value-flow proof can remain unresolved despite no other user's role payload being returned.
- Add focused business cases, when changes beyond invariant declarations are permitted, for two exhibitors in one club and another club, two leaders (both matching and mismatching clubs), two office users, and two superintendents. Exercise direct animalDetail, paginated myAnimals/clubAnimals/liveBoard, result fields, and both image downloads; then change role/club and repeat reads. Include a signed-in user without a role and the operator without animal grants. Use password credentials, never a development identity switch as authentication evidence.
- Add boundary/history cases for exactly 90 days versus just under 90 days at entry; exactly 30 days versus just over 30 days at arrival; office denial of disqualification and reweigh; two superintendent reweighs preserving the first original weight; nonblank reasons; and no office write on a disqualified animal. No standalone server or additional fixture files were created in this invariant-only review.

The original six declarations became 49: one read declaration replaced and 43 single-line declarations added. Existing comments and all other source lines were retained, including comments describing the original intent. Zero uncovered audit effects would mean declarations exist, not that all privacy or transition obligations are proved. No policy was weakened to obtain a green command result.
