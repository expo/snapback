use identity password

table roles:
  principal: principal
  role: enum('director', 'driver', 'musician', 'florist', 'family')
  label: text 1..100
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'director'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('director', 'driver', 'musician', 'florist', 'family'), label: text 1..100):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, label }

query myRole():
  return roles[principal = viewer]

query familyDirectory():
  require exists roles[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  return roles where .role = 'family' first 100 by .id

table arrangements:
  family: principal
  deceased: text 1..120
  location: text 1..240
  startsAt: time
  servicePlan: text 1..4000
  orderOfService: text 1..4000
  obituary: text 1..8000
  photos: [image <=5000000] <=12
  contractTotal: int 0..100000000
  paymentPlan: text 1..2000
  causeOfDeath: text 1..1000
  state: enum('draft', 'approved', 'confirmed') default 'draft'
  approvedAt: time ?
  read (contractTotal, paymentPlan, causeOfDeath) <- exists roles[principal = viewer, role = 'director']
  immutable family
  read <- .family = viewer or exists roles[principal = viewer, role = 'director'] or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
  insert <- exists roles[principal = viewer, role = 'director'] and .state = 'draft'
  update (old, next) <- exists roles[principal = viewer, role = 'director'] or (old.family = viewer and old.state = 'draft' and next.state = 'approved')
  online only

invariant arrangements.contractTotal read only exists roles[principal = viewer, role = 'director']
invariant arrangements.paymentPlan read only exists roles[principal = viewer, role = 'director']
invariant arrangements.causeOfDeath read only exists roles[principal = viewer, role = 'director']
invariant arrangements.insert only exists roles[principal = viewer, role = 'director']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
invariant arrangements.read only exists roles[principal = viewer, role = 'director'] or (.family = viewer and exists roles[principal = viewer, role = 'family']) or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
invariant arrangements.family read only exists roles[principal = viewer, role = 'director'] or .family = viewer
invariant arrangements.deceased read only exists roles[principal = viewer, role = 'director'] or .family = viewer
invariant arrangements.servicePlan read only exists roles[principal = viewer, role = 'director'] or .family = viewer
invariant arrangements.obituary read only exists roles[principal = viewer, role = 'director'] or .family = viewer
invariant arrangements.approvedAt read only exists roles[principal = viewer, role = 'director'] or .family = viewer
invariant arrangements.location read only exists roles[principal = viewer, role = 'director'] or .family = viewer or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
invariant arrangements.startsAt read only exists roles[principal = viewer, role = 'director'] or .family = viewer or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
invariant arrangements.orderOfService read only exists roles[principal = viewer, role = 'director'] or .family = viewer or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
invariant arrangements.photos read only exists roles[principal = viewer, role = 'director'] or .family = viewer or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
invariant arrangements.state read only exists roles[principal = viewer, role = 'director'] or .family = viewer or exists roles[principal = viewer, role = 'driver'] or exists roles[principal = viewer, role = 'musician'] or exists roles[principal = viewer, role = 'florist']
invariant arrangements.update only exists roles[principal = viewer, role = 'director'] or ((.family = viewer and exists roles[principal = viewer, role = 'family']) and (.state = 'draft' or .state = 'approved'))
invariant arrangements.family update only exists roles[principal = viewer, role = 'director']
invariant arrangements.deceased update only exists roles[principal = viewer, role = 'director']
invariant arrangements.location update only exists roles[principal = viewer, role = 'director']
invariant arrangements.startsAt update only exists roles[principal = viewer, role = 'director']
invariant arrangements.servicePlan update only exists roles[principal = viewer, role = 'director']
invariant arrangements.orderOfService update only exists roles[principal = viewer, role = 'director']
invariant arrangements.obituary update only exists roles[principal = viewer, role = 'director']
invariant arrangements.photos update only exists roles[principal = viewer, role = 'director']
invariant arrangements.contractTotal update only exists roles[principal = viewer, role = 'director']
invariant arrangements.paymentPlan update only exists roles[principal = viewer, role = 'director']
invariant arrangements.causeOfDeath update only exists roles[principal = viewer, role = 'director']
invariant arrangements.state update only exists roles[principal = viewer, role = 'director'] or (.family = viewer and exists roles[principal = viewer, role = 'family'])
invariant arrangements.approvedAt update only exists roles[principal = viewer, role = 'director'] or (.family = viewer and exists roles[principal = viewer, role = 'family'])
invariant arrangements.delete only exists roles[principal = viewer, role = 'director']
invariant arrangements.createArrangement only exists roles[principal = viewer, role = 'director']
invariant arrangements.updateArrangement only exists roles[principal = viewer, role = 'director']
invariant arrangements.setPhotos only exists roles[principal = viewer, role = 'director']
invariant arrangements.confirmService only exists roles[principal = viewer, role = 'director']
invariant arrangements.approveObituary only (.family = viewer and exists roles[principal = viewer, role = 'family'])
invariant arrangements always .state = 'draft' or .approvedAt != null
invariant arrangements always .approvedAt = null or .approvedAt <= .startsAt - 48h
invariant roles.principal write only viewer = 'service:operator'
invariant roles.role write only viewer = 'service:operator'
invariant roles.label write only viewer = 'service:operator'
invariant roles.delete only viewer = 'service:operator'

query board():
  return arrangements last 100 by .startsAt

query arrangement(arrangement: arrangements):
  return arrangements[arrangement]

mutation createArrangement(family: principal, deceased: text 1..120, location: text 1..240, startsAt: time, servicePlan: text 1..4000, orderOfService: text 1..4000, obituary: text 1..8000, contractTotal: int 0..100000000, paymentPlan: text 1..2000, causeOfDeath: text 1..1000):
  require exists roles[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  require exists roles[principal = family, role = 'family'] else FAMILY_REQUIRED
  require startsAt > now else FUTURE_SERVICE_REQUIRED
  return insert arrangements { family, deceased, location, startsAt, servicePlan, orderOfService, obituary, contractTotal, paymentPlan, causeOfDeath, photos: [], approvedAt: null }

mutation updateArrangement(arrangement: arrangements, deceased: text 1..120, location: text 1..240, startsAt: time, servicePlan: text 1..4000, orderOfService: text 1..4000, obituary: text 1..8000, contractTotal: int 0..100000000, paymentPlan: text 1..2000, causeOfDeath: text 1..1000):
  require exists roles[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  require startsAt > now else FUTURE_SERVICE_REQUIRED
  update arrangements[arrangement] { deceased, location, startsAt, servicePlan, orderOfService, obituary, contractTotal, paymentPlan, causeOfDeath, state: 'draft', approvedAt: null }

mutation setPhotos(arrangement: arrangements, photos: [image <=5000000] <=12):
  require exists roles[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  update arrangements[arrangement] { photos, state: 'draft', approvedAt: null }

mutation approveObituary(arrangement: arrangements):
  row = arrangements[arrangement] ! else NOT_FOUND
  require exists roles[principal = viewer, role = 'family'] and row.family = viewer else OWN_FAMILY_ONLY
  require row.state = 'draft' else ALREADY_APPROVED
  require now <= row.startsAt - 48h else APPROVAL_DEADLINE 'The obituary must be approved at least 48 hours before the service.'
  update arrangements[arrangement] { state: 'approved', approvedAt: now }

mutation confirmService(arrangement: arrangements):
  require exists roles[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  row = arrangements[arrangement] ! else NOT_FOUND
  require row.state = 'approved' and row.approvedAt != null else FAMILY_APPROVAL_REQUIRED
  require row.approvedAt <= row.startsAt - 48h else APPROVAL_DEADLINE
  require row.startsAt > now else SERVICE_STARTED
  update arrangements[arrangement] { state: 'confirmed' }
