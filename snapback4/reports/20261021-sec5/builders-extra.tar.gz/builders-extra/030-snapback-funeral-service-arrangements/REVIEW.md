# Security intent review

## Scope and method

This review uses SPEC.md, the authored snapback/schema.q, the installed snapback4 README, and the installed CLI guides (`guide start`, `guide security --full`, `guide language --find invariant`, `guide rules --full`, and `guide testing --full`). No source repository, other builder lane, ancestor instructions, external probes, or prior security findings were consulted. The installed recommended check → test → audit loop was run before adding intent and repeated afterward. The generated questionnaire contains 108 questions; the matrices and authority answers below answer every question, including roles absent from a read rule.

Only single-line `invariant ` declarations in the authored Quarry file were added. The six existing invariants remain. There are 37 additions, for 43 total. All non-invariant bytes were compared against an original snapshot and preserved. No rule, operation, authentication mode, field constraint, or fixture was repaired. CLI-generated artifacts are tool output, not authored enforcement changes.

## Independent reading of the specification

The director arranges services for all families. The specification does not partition directors by creator, assignment, or branch: either director may work on either director's arrangements. Each driver, musician, and florist may see the specified service details for every arrangement; there is no individual assignment restriction. Families are partitioned by the actual `family` principal on an arrangement, not merely by sharing a family role. Two distinct family users must not see each other's arrangements.

“Only the funeral director sees” the contract total, payment plan, and cause of death excludes families too, even on their own arrangement. Those three existing independent column invariants are confirmed and retained. They protect values and value-dependent observations, rather than just omission from a UI.

For the other columns, this review reads the enumeration of the staff view as its permitted payload: location, start time, order of service, and slideshow photos. Confirmation status and an opaque arrangement identifier are operational board information. It does not infer permission to distribute family account identity, the full service plan, the obituary under family review, the deceased name stored separately, or the exact approval timestamp to those three roles. The five corresponding new private-column assertions use director-or-own-family intent. This is an interpretation of the enumerated staff view; the specification's explicit, unambiguous director-only prohibition is the separate three-column prohibition above. The broader existing read rule was not used to supply a missing grant.

There is no confirmed-only read restriction in the specification. “Updates live as services are confirmed” requires the board to reflect changes, but does not say draft/approved services must be hidden. Every allowed read in the following matrices applies to draft, approved, and confirmed rows. Approval is a write restriction and must not be converted into loss of the family's ability to read its own arrangement. There is also no stated role-change revocation of the family's ownership relationship: read invariants keep `.family = viewer`, rather than adding an unsupported requirement that a continuing family owner have a current `family` roster value. Current staff/director privileges do require the current roster role.

## Questionnaire: arrangements rows and every column

Legend: **All** = any arrangement, without an assignment or creator restriction; **Own** = `.family = viewer`; **No** = no access. These are upper bounds, not guarantees of availability. A signed-in user with neither a role nor a relationship has no access. The operator seat has no implicit arrangement access; if separately assigned a business role, it receives exactly that role's rights. Anonymous callers have no access.

| Question/column | Director | Driver | Musician | Florist | Family | No role or relationship |
| --- | --- | --- | --- | --- | --- | --- |
| Row/existence (`arrangements.read`) | All | All | All | All | Own | No |
| `id` (implicit row identifier) | All | All | All | All | Own | No |
| `family` | All | No | No | No | Own | No |
| `deceased` | All | No | No | No | Own | No |
| `location` | All | All | All | All | Own | No |
| `startsAt` | All | All | All | All | Own | No |
| `servicePlan` | All | No | No | No | Own | No |
| `orderOfService` | All | All | All | All | Own | No |
| `obituary` | All | No | No | No | Own | No |
| `photos` | All | All | All | All | Own | No |
| `contractTotal` | All | No | No | No | No | No |
| `paymentPlan` | All | No | No | No | No | No |
| `causeOfDeath` | All | No | No | No | No | No |
| `state` | All | All | All | All | Own | No |
| `approvedAt` | All | No | No | No | Own | No |

Every explicit column has a read invariant: the three retained director-only declarations, five new director-or-own-family declarations, and five new board-audience declarations. The whole-row read invariant also protects hidden arrangement existence and the implicit identifier. No family-role-wide branch is permitted. Within each of driver/musician/florist, both users receive the same all-arrangement board rights. Within directors, both users have all-arrangement rights. Within families, user A's ownership never establishes user B's rights. No principal obtains these rights merely by supplying another user's identifier.

The same audience applies to image downloads, copied values, computed projections, filtering, sorting, counts, sums, existence results, and refusals dependent on a protected value. `photos` is not private from staff; its upload/placement authority is still director-only. `state` reveals confirmation intentionally. `approvedAt` reveals the family's exact approval event and is not needed to announce confirmation. No separately authored derived view, export, download operation, or counter exists in the authored Quarry file. `board` returns whole rows, so it does not establish a safe column projection merely by its name. The generated audit must still be consulted for opaque/unsupported observations.

## Questionnaire: roles rows and every column

The spec names five business roles, but does not specify a public staff or family directory, role labels, or a credential-provisioning API. Consequently the following metadata boundaries are implementation conventions, not newly invented business privacy requirements. No new roles-read assertions claim that SPEC.md mandates this exact directory design. The `myRole` lookup is needed for a user's own role; selecting a family is needed when a director creates an arrangement. Access to other roster metadata is not required for drivers, musicians, florists, or families.

| Question/column | Director | Driver | Musician | Florist | Family | No role or relationship | Operator seat |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Row/existence | Own; family selection needed; spec silent on other roster rows | Own | Own | Own | Own | None | Provisioned roster |
| `id` | Same as row | Own | Own | Own | Own | None | Provisioned roster |
| `principal` | Same as row | Own | Own | Own | Own | None | Provisioned roster |
| `role` | Same as row | Own | Own | Own | Own | None | Provisioned roster |
| `label` | Same as row | Own | Own | Own | Own | None | Provisioned roster |

For each of the four non-director business roles, “Own” means `.principal = viewer`, not every member of that role. The existing rule permits directors to read every roster row; this exceeds the directory functionality needed by the spec, but the spec does not explicitly make those other roster rows private from directors. That implementation choice is recorded rather than labeled a confirmed spec violation. There is no role-record lifecycle state or time-based consent requirement in the spec. A roleless principal with an existing own role record would no longer be “no role or relationship”; self metadata visibility is not an arrangement grant.

Authority must come from trusted provisioning, never self-selected role arguments or a development identity switch. The existing operator-only role insert/update declarations are retained as that concrete provisioning boundary. New `roles.principal`, `roles.role`, and `roles.label` write invariants cover insert and update of each grant-bearing/configuration value; a delete invariant permits at most that same provisioning authority. This does not introduce an operator business role or give the seat director access to arrangements. The operator is included as an ordinary checked viewer, not exempted as the trusted system principal. Its credential provisioning and custody are not proven by a literal principal comparison.

## Questionnaire: authority and lifecycle

- **Creation:** only a current director records an arrangement, for a real family principal. Neither a family nor another staff member may appoint themselves as owner or create an approved arrangement. There is no director-to-arrangement assignment requirement. The retained insert invariant and new createArrangement operation invariant protect caller authority. The existing creation guard checks the recipient's family role; `family` is immutable. These facts do not establish that real accounts were provisioned.
- **Content edits:** the director records/changes the deceased, location, start, service plan, service order, obituary, photos, contract total, payment plan, and cause of death. A family approves its own obituary rather than rewriting those values through an approval transition. Each of those columns, including the ownership principal, now has director-only update intent. The operation-specific updateArrangement and setPhotos declarations separately require current director authority.
- **Family approval:** the actual family owner approves the obituary, no later than service start minus 48 hours. Exactly 48 hours is permitted; later approval is not. It cannot approve another family's arrangement. A previously approved/confirmed arrangement cannot be changed by a family: only a director may change it. No driver, musician, florist, unrelated family, or roleless caller can approve. The approveObituary declaration records current-family and ownership authority.
- **Post-approval changes:** only a current director changes an arrangement whose old state is approved or confirmed, including its content, state, approval evidence, or deletion. Changing content must not keep treating an approval of the old obituary as approval of the new one. Existing director content/photo mutations reset to draft and clear approval; a fresh family approval is then necessary. Confirmation is a director action following family approval, not a substitute for it.
- **Deletion:** the product supplies no delete operation. The new arrangement-delete declaration allows at most a director; the omitted enforcement rule currently denies everyone. This upper bound preserves the “only director can change approved” requirement without inventing a delete feature. Roster deletion is similarly at most trusted provisioning.
- **Appointment:** business users cannot write role assignments, impersonate another family principal, or turn knowledge of an arrangement ID into authority. `provision` is operator-only; the user argument is an intended operator delegation, not open enrollment. The recipient-role check on createArrangement is appropriate; requiring an already-existing role before the operator can first provision it would be circular.

A general update invariant and state/approvedAt update invariants state necessary caller bounds. Because update policies evaluate both old and next images, the family branch must admit draft and approved images to express a valid draft → approved approval. **This is not a complete proof that a family cannot edit an already-approved row.** Neither an invariant allowing only draft images (which would wrongly reject valid approval) nor weakening the specification to allow reapproval is appropriate. The actual old/next requirement is the one stated above; its complete transition reduction remains a coverage gap. The column authority declarations and operation guards provide separate evidence, not a substitute theorem.

Two row-integrity declarations independently state that approved/confirmed rows have approval evidence and that a non-null approval timestamp is at least 48 hours before service start. The arithmetic predicate is retained even though the checker reports it outside its proof fragment. This keeps the actual deadline intent instead of replacing it with “approval timestamp exists.” The stored-time invariant alone cannot prove that the person recording the timestamp was the family, that it equals server now at approval, or that it belongs to the current obituary version. Those are operation/transition obligations. The authored approval uses server `now` and directly checks the deadline; it does not rely on a sweep or caller-supplied event time.

## Assessment and recommended enforcement changes

1. **Staff payload scope:** the whole-row board and arrangement reads currently expose `family`, `deceased`, `servicePlan`, `obituary`, and `approvedAt` to every driver, musician, and florist. That conflicts with the enumerated-staff-view interpretation used here. Preserve the new intent and add suitable column gates or a separate board entity/projection with enforced source-column privacy. Hiding these properties in a frontend is insufficient. Preserve staff access to the four required details and confirmation information.
2. **Explicit financial/medical boundary:** the three sensitive columns have director-only column gates. Confirmed independent intent agrees with them, including exclusion of the owning family. Do not broaden these invariants to include staff or families just because they can read the surrounding arrangement.
3. **Family transition versus content authority:** the table update rule permits an owner to take a draft to approved without itself requiring the current family role, restricting changed content, or checking the approval deadline. The authored approveObituary mutation supplies current family role, ownership, old-draft, server-time deadline, and a narrow state/timestamp patch; other authored arrangement mutations require a director. A broader table rule is not evidence of an executed arbitrary-patch exploit. Recommended hardening is to carry the intended content-preservation/current-family constraints into the table transition where expressible, while keeping the exact server-time guard in the mutation. Do not remove independent column update assertions to silence the mismatch.
4. **Current roles and ownership:** director and staff reads recheck roles. Family ownership is immutable, so it cannot be self-transferred through these mutations. The grant-outlives-role note identifies that ownership survives role changes. The spec does not say that changing a role severs family ownership; do not automatically treat that advisory as a confirmed violation. Approval still requires the current family role.
5. **Media and approval:** the photos list permits zero images and creation starts empty. The spec describes slideshow photos but supplies no minimum count or completion evidence requirement; an empty list during drafting is reasonable. No ungrounded minimum-photo invariant was added. A confirmed service with no photos is a product-completeness question, not proof of a privacy leak. Test coverage for populated foreign assets remains limited.
6. **Authentication, population, and live behavior:** `use identity password` matches the real-authentication requirement. No development persona declaration exists in the authored file. There are no authored fixtures or account-population evidence for two actual credentialed users of each role. The installed guide says the security campaign synthesizes two users per discovered role/seat; such private in-memory users exercise authorization but do not satisfy a demonstration that ten real accounts were provisioned. The read-only board/query schema also does not alone demonstrate the frontend's live update behavior. Account setup, successful two-user-per-role business scenarios, live board observation, approval-boundary scenarios, and approved-edit rejection require application-level evidence. These were not invented or repaired under the invariant-only constraint.

## Commands, results, and limits

Final command results are recorded below after completion. The full, unabridged stdout/stderr streams are saved as check.json, test.txt, and audit.json. Each CLI command ran from this application directory under timeout (30 seconds for guides, 60 for check/audit, 180 for test). No persistent server was started by the reviewer; test owns its isolated hosts.

RESULTS_PENDING

Finite campaigns are not security proofs. “Unproved” is not automatically a leak, and “proved direct rule” is not whole-protocol noninterference. Keep all independently confirmed requirements while addressing concrete violations or adding missing reductions. No requested enforcement repair was made.
