
**Funeral Service Arrangements.** A funeral home arranges services with families, and the funeral director records each arrangement with the service plan, obituary and slideshow photos. Drivers, musicians and florists see each arrangement's service location, start time, order of service and slideshow photos, but not the family's contract total, payment plan or the cause of death on the same arrangement, which only the funeral director sees. Families see only their own arrangement, the staff board updates live as services are confirmed, and the family must approve the obituary at least 48 hours before the service. Only the funeral director can change an approved arrangement.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
