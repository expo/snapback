
**Therapeutic Riding Sessions.** A therapeutic riding center pairs riders with horses, side walkers and a certified instructor. Volunteers see each rider's first name, assigned horse, tack, mounting method and safety notes, but not the rider's diagnosis, therapy goals or guardian contact on the same rider's record, which only instructors and the program director see. Families see only their own rider's progress notes and photos, the barn board updates live as volunteers confirm sessions, and a rider's medical form expires one year after it is signed. Only the program director can suspend a horse from lessons, recording the reason.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
