
**Knife Sharpening Drops.** A sharpening service collects knives from restaurants and home cooks, and each set is photographed and counted at drop-off. Sets are due back within five days of drop-off, and a set not collected within 60 days of the ready notice is donated. Restaurant accounts see only their own sets and counts, sharpeners see the live board of sets in the shop, and couriers see only the pickups and drop-offs on their own route. Only the shop owner can record a damaged or missing knife and issue a credit, with a photo and the reason kept.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
