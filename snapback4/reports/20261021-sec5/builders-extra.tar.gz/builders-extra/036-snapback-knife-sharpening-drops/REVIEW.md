# Independent security-intent review

This review uses SPEC.md, the authored snapback/schema.q, the installed package README, and installed CLI guides start, security --full, rules --full, and testing --full. It does not treat existing enforcement or assertions as the product specification. All authored query changes are single-line `invariant ` declarations. Rules, operations, identity configuration, comments, schedules, and all other original bytes are preserved.

## Specification decisions

- Restaurants have access only to their own sets and counts, including another restaurant account being excluded. Home cooks are customers too; their set ownership is the corresponding customer relationship. Customer ownership continues across dropped, ready, collected, and donated states: the spec gives no customer-history cutoff. Being a customer does not authorize recording incidents or issuing credits.
- Sharpeners share the live shop board, including each other's work, because no individual sharpener assignment is specified. The board comprises sets still in the shop (`dropped` or `ready`), not collected or donated sets. A query-level filter alone does not enforce that audience across other queries or derived observations.
- Couriers may observe only their own route. This requires the reader's **current** courier role and a match between the set's route and the route on that reader's role record. A stored courier principal alone is insufficient. Two couriers with distinct routes must not see each other's routes; two on the same route need not be isolated merely because they are different people. The spec does not explicitly give couriers the sharpener's live-board-only restriction or a history-retention period, so no additional courier status cutoff is invented. Route transfers and courier demotions must remove the former route grant on subsequent server reads.
- A person with a separate customer ownership relationship can still see their own customer records. Thus a demoted courier who actually owns a set can see that set as its customer, but does not retain access to somebody else's set through the old assignment.
- The shop owner manages the service and records incidents and credits. Two current owner accounts have the same shop authority; the spec gives no per-owner partition. Only a current owner can create or change incident/credit data. Required incident photo and reason must be retained with the record. There is no new operator exception to this business authority.
- The spec restricts incident **recording**, not incident readership to owners alone. I do not manufacture an owner-only financial confidentiality requirement. Incident rows and all their columns are bounded by the related set's customer, live-board, or current-route audience; they must not bypass the set's stated privacy through the parent identifier, reporter, credit, kind, reason, or photo. This is a necessary privacy upper bound, not a promise that every allowed viewer must receive every incident field. A separate incident confidentiality policy would need a product requirement.
- Role records support authentication and authorization. Self-only visibility and trusted `service:operator` provisioning are retained as the application's supporting administrative policy, consistent with credential isolation and trusted role assignment. The specification does not prescribe an operator service or a private staff directory. These are explicitly supporting design choices, not newly discovered spec requirements. Neither restaurant nor courier nor sharpener nor owner may appoint themselves an elevated role through ordinary business operations. The operator is explicitly covered by role invariants, and gains no blanket business-data exemption.
- The generated `incidents.kind = damaged/missing` audiences are record categories, not authenticated roles. Neither category grants authority. There is no consent-based grant in the spec.

## Questionnaire answers

The initial generated questionnaire contains 174 questions: seven audience questions for each of 24 row/column targets, plus six effect questions. The following matrix answers every audience/target combination, including all columns. Each entry includes the relationship and lifecycle through the definitions below. This matrix also covers file downloads, counts, existence, ordering/filter-dependent values, and derived observations of the named column; omitting a field from one projection is insufficient protection.

- **None**: no row or column value without a qualifying relationship. The generated roleless audience explicitly says “no role or relationship”; a home cook who owns a set is a different audience, covered separately below.
- **Self**: only the role record whose principal equals the viewer, all states. No same-role peer records. This is the supporting role-directory policy described above.
- **Customer**: only sets owned by this exact customer and incidents referring to those sets, all states. No other restaurant/home-cook records.
- **Route**: current courier role AND the set route equals that reader's current role-record route. For incidents, use the referenced set's route. No route match means no access, even when the set retains this viewer in its courier column. No extra courier historical cutoff is specified.
- **Live**: current sharpener role AND related set status is dropped or ready. No collected/donated peer/customer records through sharpener status alone. Both sharpeners share this live audience.
- **Shop**: current shop owner, any service set/incident and lifecycle. Both owner accounts share this authority.
- **Category**: damaged/missing is not a viewer identity; apply the actual viewer's Customer/Route/Live/Shop conditions, otherwise None. On role records apply Self. A category alone has no visibility.

For Route and Live viewers, a separate Customer relationship is also sufficient for their own customer set. The invariant predicates make this independent relationship explicit rather than preserving an old employment grant.

| Questionnaire row/column target | Signed in, no role or relationship | Courier | Shop owner | Restaurant | Sharpener | kind=damaged | kind=missing |
|---|---|---|---|---|---|---|---|
| `incidents.read` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.at` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.credit` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.kind` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.photo` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.reason` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.reporter` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `incidents.set` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `roles.read` | None | Self | Self | Self | Self | Category | Category |
| `roles.principal` | None | Self | Self | Self | Self | Category | Category |
| `roles.role` | None | Self | Self | Self | Self | Category | Category |
| `roles.route` | None | Self | Self | Self | Self | Category | Category |
| `sets.read` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.collectedAt` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.courier` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.droppedAt` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.dueAt` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.knifeCount` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.label` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.owner` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.photo` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.readyAt` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.route` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |
| `sets.status` | None | Route (+Customer) | Shop | Customer | Live (+Customer) | Category | Category |

Every matrix column value is explicitly named by a column-read invariant. Whole-row declarations also protect logical row existence. A home cook or other signed-in account with no employee role gets Customer visibility for their own sets and related incidents and no unrelated records. An unauthenticated caller has no application data access; password authentication is declared, and the CLI fixture-only campaign also reports isolated production HTTP identity challenges; these do not establish that this app has two deployed real accounts per role. `service:operator` sees role rows and provisions roles, while set/incident privacy has no service-seat exception. On incident kinds, damaged and missing have identical privacy and owner-only recording authority.

### Effect questions and authority

| Generated effect question | Answer from requirements and authority review |
|---|---|
| incidents.insert | Current shop owner only, any shop set; retain required photo, nonempty reason, kind and credit. Trusted role provisioning appoints owners. Customer ownership, employment as sharpener, and courier assignment do not confer this authority. |
| incidents.update | Any permitted correction to incident, evidence or credit must be owner-only. The spec does not demand an edit feature; current immutable fields and deny rule are acceptable stronger restrictions. Independent table and per-column write intent cover insertion and editing separately. |
| incidents.delete | The spec says photo and reason are kept. There is no specified erasure workflow or retention duration; current deny policy preserves evidence. The authored authority bound allows no non-owner deletion; it does not by itself prove permanent retention, nor authorize an owner deletion operation. |
| roles.delete | No role deletion workflow is specified. Existing omitted rule denies it. Revocation may instead update the role; all dependent reader grants must honor the current role/route. The spec does not select the administrative mechanism. |
| sets.update | The spec specifies deadlines, customer privacy, route privacy and owner-only incidents/credits, not a complete list of staff permissions to edit each set field. Do not infer that ownership permits arbitrary status, route or evidence changes. Current named mutations implement a workflow, but no invented all-field owner-only update invariant is added. Audit coverage for this broad effect remains open. |
| sets.delete | No set deletion feature is specified; existing explicit deny is consistent with keeping service records and evidence. No new deletion workflow or universal retention duration is invented. |

Supporting role insert/update and every role-column write are limited to the explicitly named operator. Set insertion keeps the simple confirmed customer-owner/shop-owner authority bound; anyone can sign in as a home-cook customer, but cannot thereby claim ownership of somebody else's existing set. No role-less caller may record an incident or credit. `incidents.reportIncident` adds operation-specific current-owner authority independently of table and column write assertions.

## Independent declarations

48 single-line declarations replace/supplement the original 11. Four focused row declarations separately state the restaurant ownership and sharpener lifecycle requirements for sets and incidents so these obligations need not depend on the complete route predicate. They include whole-row and all 21 column read audiences; role provisioning table/column authority; customer/shop set insertion authority; incident table insert/update/delete authority, every incident-column write authority, operation-specific reportIncident authority; and required set-photo, incident-photo and incident-reason integrity. The photo bounds and nonempty reason/count constraints also remain in the unchanged schema. None of these declarations repairs enforcement or grants access.

## Findings and recommended changes (not applied)

1. **Sharpener lifecycle scope is wider in the table rules than the specification.** `sets.read` grants any sharpener all states; `incidents.read` similarly grants all incident records without checking the related set's lifecycle. The board query filters live states but does not protect `incidentsFor`, mutation observations, assets, or any other backend path. Conjoin the current sharpener role with live-set status in both table/column audiences, or expose a deliberately limited live-board entity. Preserve shared access between the two sharpeners while excluding collected/donated sets through that staff role.
2. **Courier grants are disconnected from current route and role.** Both tables trust `sets.courier = viewer`. `assignRoute` checks only the caller's owner role and writes an arbitrary principal and route. It does not verify the recipient is currently a courier for that route. A transferred/demoted recipient can retain a grant. Check recipient role and route on assignment, and enforce current reader role/route at every read boundary (including incidents and asset downloads); do not rely solely on provisioning-time checks. `myRoute` checking the caller's role does not fix incidents or other observations.
3. **Owner-only incidents/credits have appropriate visible gates but require complete qualification.** The authored report mutation and insert rule require a current shop-owner role. Required photo/reason fields and immutability preserve evidence within existing operations. New invariants protect all incident columns from unauthorized insert or edit, including credit, kind, reporter and evidence. Do not weaken these because the checker leaves system/job or opaque paths unproved.
4. **Home cooks and account multiplicity need explicit qualification.** The schema has password identity, and home cooks can operate as roleless owners through `dropSet`/`mySets`. The role enum nevertheless names only restaurant, sharpener, courier and owner; it does not explicitly model the home-cook role requested by the spec's “every role” clause. No query declaration establishes two real credentialed accounts of each role. A generated fixture user is not evidence of a deployed password account. Add an explicit home-cook role or document and qualify the roleless-customer representation, and exercise at least two credentialed accounts per named role, including home cooks. This measurement forbids the required schema/account changes.
5. **Lifecycle timing is separate from privacy and remains open.** `dropSet` uses server now and dueAt=now+5d, with immutable timestamps. That records the five-day due date; it cannot establish that knives are physically returned on time. Ready notice is represented by readyAt; there is no notification delivery feature. Daily donation uses periodEnd and a strict less-than comparison, so it can leave a ready set overdue until a later sweep. `markCollected` enforces an upper bound with server now but allows equality at 60 days. Clarify the exact 60-day boundary and enforce it consistently in status transitions and any deadline-dependent access; cleanup alone cannot promise exact donation at the deadline. No temporal proof is claimed by the photo/owner invariants.
6. **Broader update and disclosure paths remain visible.** No fixes to rules, operations or refusal messages are permitted here. Review lookup-before-authorization refusals, raw parent probes, ownership-independent courier grants, and broad set-update rules against the stated audiences. Do not add a universal staff authority merely to close audit coverage. No maintained aggregate or export is authored, but knifeCount, credit, status/kind and existence are derived-information sources; their column declarations preserve the same audience for such observations. All tables are online only, so this review does not claim an offline revocation guarantee.

## Command results

The initial 44-declaration run compiled, and the finite test exited 0 with 20,646 attempts, 3,565 refusals, 1,024 ordered histories, no reachable violations, and one non-failing seed/synthetic observation. Its audit exceeded the 60-second command timeout (exit 124) before emitting output. Four focused assertions were then added without weakening the full privacy policies. The final run below is for all 48 declarations.

Complete final command output is retained in check.json, test.txt and audit.json. Exit status is reported separately rather than injected into the raw command files. A successful process exit, an unproved declaration, a synthetic observation, and an actual reachable counterexample have different meanings.
