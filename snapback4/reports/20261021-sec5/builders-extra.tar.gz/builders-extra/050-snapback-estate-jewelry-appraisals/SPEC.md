
**Estate Jewelry Appraisals.** A jewelry firm appraises estate pieces for families and attorneys, and the intake clerk photographs each piece and records its weight and markings. Assistant appraisers see each piece's photos, weights, markings and test results, but not the owner's name, address or the final appraised value on the same piece, which only the senior appraiser and the owner see. Owners see only their own pieces, intake staff see each piece's location update live as it moves between the vault and the benches, and a piece not collected within 30 days of its report is held with a fee. Only the senior appraiser can sign a report.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
