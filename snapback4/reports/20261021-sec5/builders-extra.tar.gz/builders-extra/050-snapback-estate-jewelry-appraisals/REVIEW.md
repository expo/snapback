# Security-intent review

Reviewed SPEC.md and authored snapback/schema.q. Product semantics came only from the installed snapback4 README and CLI guides, beginning with `guide start` and `guide security --full`. The first check generated `snapback/generated/security-invariants.q.draft`; the answers below cover its roles, rows, columns and write questions. No enforcement rule or operation was changed. All authored .q changes are single-line invariant declarations.

## Independent interpretation

The phrase “the owner's name, address or the final appraised value ... which only the senior appraiser and the owner see” excludes intake staff as well as assistants. Intake's photography, weighing, marking and live-location duties do not create an exception. The prior name/address assertions copied an intake exception from enforcement; those assertions have been replaced. The confidentiality follows the value across tables, downloads, projections and derived observations. In particular, an owner's roles.displayName is another representation of the owner's name.

Owners may observe only pieces they own, including existence, identifiers, images and derived values. Assistants see each piece's photos, weight, markings and tests; intake sees each piece's location and performs intake. Senior appraisal authority is firm-wide. There is no assignment, bench, creator, attorney, consent or team restriction in SPEC.md. Families and attorneys describe customers, not separate privileged roles. Two assistants/intake users/seniors have the same stated scope; two owners must not see one another's pieces. No public or unassigned signed-in audience is authorized.

The spec does not revoke read access on signing, collection, becoming overdue, moving benches or changing custody. Thus all confirmed read bounds apply before a report, after signing, before/at/after the 30-day deadline, and after collection. A row's owner relationship persists independently of its principal's current employee role; SPEC.md does not say demotion transfers property or removes the owner's personal access. Staff authority must use the current role. signedBy records the signer, not a reader assignment. The sole role enum and unique principal do not establish multiple simultaneous staff roles.

Only a senior may sign any piece's report. This is expressed both for signReport and for writes to signedAt/signedBy. The column-write predicates allow unset signature fields and require senior authority for non-null signatures. Their old-and-next-image update semantics also prohibit a non-senior from clearing an existing signature. These are authority bounds, not a claim that a signature is required at creation. Initial unconditional column-update assertions were too broad: the generated trace showed unrelated intake/test updates materializing absent optional signature fields as Null, with no signature created. Those duplicate assertions were removed; the retained column-write predicates still protect both existing and new non-null signatures. This corrects an overstatement of the specification, not a relaxation of senior-only signing. The existing createPiece intake authority and operator-only provision assertion are retained as the implementation's division of duties. The independent table insert assertion covers intake creation separately from its named operation.

## Questionnaire: piece rows and every column

Each cell applies to both users of the named role. `All` means any firm's piece, regardless of which staff member created/handled/signed it; `Own` means `.owner = viewer`, never another owner's piece. `No` excludes that audience. `U` means SPEC.md states no independent permission or prohibition for this incidental field: the added whole-row and column bounds still exclude unrelated owners and outsiders, but do not invent a narrower staff restriction. `U` is not acceptance of a broad enforcement rule as specification. The anonymous, unrelated signed-in and ordinary service audiences receive `No` for every piece row/column; no service exemption is stated.

| Question / value | Intake | Assistant | Owner | Senior |
|---|---|---|---|---|
| pieces.read / logical existence | All (intake/location workflow) | All (each piece) | Own | All |
| id | All (piece identity) | All (piece identity) | Own | All |
| owner principal | U | U | Own | U |
| title | U | U | Own | U |
| ownerName | No | No | Own | All |
| address | No | No | Own | All |
| photos and original asset downloads | All | All | Own | All |
| weightMg | All | All | Own | All |
| markings | All | All | Own | All |
| tests | U | All | Own | All |
| location (vault, bench-a, bench-b) | All, live | U | Own | U |
| intakeAt | U | U | Own | U |
| report | No for private report contents | No for private report contents | Own | All |
| valueCents | No | No | Own | All |
| signedAt | U | U | Own | U |
| signedBy | U | U | Own | U |
| collectBy | U | U | Own | U |
| collectedAt | U | U | Own | U |
| feeCents | U | U | Own | U |
| pieceCard.held (derived) | U | U | Own | U |
| pieceCard.holdingFeeCents (derived) | U | U | Own | U |

Each added general column-read invariant uses the independently confirmed own-piece-or-current-staff upper bound, including the owner principal and lifecycle metadata. The name, address and final value assertions use the stricter owner-or-current-senior bound. The existing report assertion is retained: the report is the natural container of the private appraisal, so its contents must not bypass name/address/value confidentiality. The spec does not separately declare every word of a value-free report secret; this retained report-wide boundary is conservative, not evidence for additional workflow restrictions.

The generated draft does not ask about id or the two pieceCard derivatives; they are included above deliberately. held/holdingFeeCents use collectedAt, collectBy, feeCents and server now. They must preserve the source row's owner boundary; no public aggregate is specified. There are no maintained aggregates or export operations in the authored .q file. If a future report/download copies a name/value, its audience must remain owner/senior. A principal identifier is not automatically a person's name, but joining owner to an owner roster displayName reveals that name and must obey that column's confidentiality.

## Questionnaire: roles rows and every column

Roster visibility is not itself specified. Self role lookup supports the four named workflows; no firm-wide personnel directory entitlement is stated. Intake and senior may need customer selection, but this does not authorize revealing private customer names to intake. The ordinary operator seat is an implementation mechanism, not an implicit exemption from customer privacy. No lifecycle/consent condition for roster reads is stated.

| Question / value | Intake | Assistant | Owner | Senior | No role/relationship | service:operator |
|---|---|---|---|---|---|---|
| roles.read / existence | Self; wider scope U | Self; wider scope U | Self; wider scope U | Self; wider scope U | No stated scope | Provisioning metadata as needed; scope unspecified |
| id | Same as roster row | Same | Same | Same | No stated scope | U |
| principal | Same as roster row | Same | Same | Same | No stated scope | U |
| role | Same as roster row | Same | Same | Same | No stated scope | U |
| displayName on an owner row | No unless this is the viewer | No unless this is the viewer | Self only | All owners | No | No independent privacy exemption |
| displayName on other role rows | U (self is appropriate) | U (self is appropriate) | U (self is appropriate) | U | U | U |

`roles.displayName read only .role != 'owner' or .principal = viewer or exists roles[viewer, role = 'senior']` encodes only the specified customer-name restriction. It deliberately makes no claim that employee names or all roster existence are private. A formerly-owner principal's historical pieces still carry private ownerName/address; role reassignment must not copy those names into a broadly readable field. Exact cross-table equivalence and arbitrary data-copy tracking remain limitations of these declarations.

## Questionnaire: authority and lifecycle

| Effect | Independently assessed authority and relationship/state |
|---|---|
| pieces.insert | Intake creates an estate piece and its required photos/weight/markings. The selected recipient must actually be an owner; an arbitrary principal argument must not appoint an owner. Current createPiece checks that role. No creator-only subsequent access is stated. |
| pieces.update | Duties differ by effect: intake records intake evidence; appraisers record tests; senior alone signs. Owners have no stated editing authority. A single staff-wide update rule is insufficient evidence for signature authority, hence independent signature column assertions. Movement and collection are staff custody workflows; SPEC.md does not expressly choose which staff role may perform each update. |
| pieces.delete | No deletion workflow or delegated delete authority is specified; current omission denies. No invented deletion exception or assertion was added. |
| roles.insert/update | Real authentication and role enforcement require trustworthy provisioning rather than caller-selected authority. Existing provision is operator-only and is retained. SPEC.md does not specify an administrator UI, operator enrollment protocol or exact roster-edit actor; that unresolved product choice is not converted into a new blanket roster policy. No owner, assistant, intake or senior may appoint themselves senior just by signing up. |
| roles.delete | No deletion workflow specified; current omission denies. |

Signing is explicitly senior-only; updateIntake/recordTests being locked after signing or collection, prohibiting double signing, tests-before-signing, intake-only release, a $25 amount, and requiring a settlement boolean are existing choices rather than separately stated privacy/authority requirements. They were assessed but not promoted into invented spec invariants. The stated lifecycle requirement is that an uncollected piece is held with a fee 30 days after its report. Current signReport sets collectBy using server now + 30d; pieceCard derives the hold and fee at that exact deadline; collectPiece requires settlement when overdue. No periodic sweep is needed for those derived comparisons. The invariant predicate fragment does not express this full cross-operation temporal/release guarantee; it remains a required business check, not something proved by read invariants. Read access is not withdrawn by this deadline.

## Changes and recommended enforcement work

26 declarations now express independently assessed bounds: retain the seven original declaration targets, narrow two, and add whole-row/every-general-column privacy, owner-name privacy in the roster, signature write authority and table insert authority. All other existing .q bytes are preserved. Removing invariant lines from both the original and final files gives identical 4,984 bytes (SHA-256 `5799fef88e3d55a439fd2294fc534888f981c6ad1e78e3933e17d1443eb26884`).

Recommended fixes (not applied under this measurement's invariant-only constraint):

1. Remove the intake branch from pieces.ownerName/address read rules. Intake must receive a redacted piece even when the same row includes live location and intake evidence.
2. Protect owner display names in roles and the owners projection. The current owners query returns displayName to intake. Customer selection should use an opaque identifier or another specification-compatible mechanism; it must not republish the forbidden name.
3. Enforce senior authority specifically on signature field changes, and inspect final rereads/refusals/derived observations separately. The current signReport has a leading senior requirement, but the general update rule admits all staff. A proof gap is not automatically a demonstrated signing exploit.
4. Preserve own-piece authorization on every query, asset, live refetch, future download and derived hold/fee result. Keep current staff-role checks; do not add an assignment or post-signing read restriction absent from the spec.
5. Verify at least two real password accounts for each named role and credential isolation in an appropriate acceptance environment. The schema declares password identity, but this file alone does not prove real accounts were provisioned. Generated fixtures are test principals, not proof of eight deployed accounts.

## Validation results

Final-source `test --fixture-only` exited **1**: 9,305 attempts, 2,754 refusals, 1,024 short ordered histories, and all 11 operations exercised. It reported **2 reachable violations**, both `roles.displayName` observations through `owners`, one for each generated intake principal. The two owner-name worlds produce different returned displayName values despite the independent owner/senior-only policy being false. These are `generated-fixture-trace` observations from validated initial fixtures, not proof that ordinary app operations created the initial roster. There was also one non-failing seed/synthetic observation.

The generated support roster has two principals for each of intake, assistant, senior and owner. The isolated HTTP campaigns refused 25 unauthenticated/forged-persona/development-door attempts and 32 retired-session attempts after actual refresh/logout-all. This provides finite admission evidence; it does not prove deployed account provisioning, all access paths or disconnected-device revocation.

No authored business cases ran. The campaign explicitly reports missing reductions for pieces.ownerName/address paired worlds, asset-ledger/history limits, mutation policy/write-boundary tracing, and capped observer/argument exploration. Thus the clear intake exception in the piece name/address rules remains a specification conflict even though this finite campaign did not turn those two column assertions into replayed violations. No observed non-senior signature creation was established by the final test. The corrected signature invariants must remain distinct from the tool's general write-boundary proof gaps.

Final `audit --json` exited **1**: **3 proved, 21 unproved, 2 refuted** declarations. It refuted owner-name confidentiality in roles.displayName through the authored owners query, and pieces.signedAt write authority through a **synthetic-operation** (`$security.pieces.update`) by a schema-valid assistant. The synthetic changed signedAt patch demonstrates that the broad table update rule admits a non-senior signature-field change; its stated scope explicitly does not claim application reachability from an empty store or through an authored mutation. This is separate from the two failing generated-fixture observations in test.txt. signedBy remains unproved; it is not thereby safe.

A post-test `check --json` exited **1**, retaining the matching full-test owner-name counterexample: **3 proved, 22 unproved, 1 refuted** declarations, with `ok: false`. Before the full finite campaign, check exited 0 with unproved obligations; that was not a security pass. The saved check.json is the final post-test result. Proved targets are roles.provision, pieces.createPiece and pieces.insert.

Audit still lists four uncovered effect exposures: pieces.update and roles.read/insert/update. These were assessed above; one named operation or sensitive column declaration does not specify every table effect. Roster-wide visibility and exact delegation beyond trusted provisioning are unspecified in SPEC.md; they are not silently blessed, nor replaced by invented product requirements. The unproved obligations include signature authority, refusal/existence observations, raw roster probes, mutation effects and opaque scan/derived paths. Finite success on any remaining path is not proof. Complete stdout/stderr is retained in check.json, test.txt and audit.json. All commands use the installed CLI in this application directory with timeouts (30 seconds for guides, 60 for check/audit, 180 for test); test owns its isolated hosts. No enforcement repair was made and no confirmed privacy intent was widened to obtain a pass.
