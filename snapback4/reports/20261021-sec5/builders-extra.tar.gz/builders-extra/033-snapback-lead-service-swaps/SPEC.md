
**Lead Service Swaps.** A water utility is replacing lead service pipes, and crews photograph each old pipe at the curb and inside the home. A homeowner must sign the access agreement within 30 days of the notice or the address is rescheduled, and the home's water must be sampled within 90 days after the replacement. Homeowners see only their own address, sample results and photos, crews see the live map of jobs scheduled and finished, and contractors see only the addresses assigned to them. Only the program manager can mark a home as refused or skip the sampling, recording the reason.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
