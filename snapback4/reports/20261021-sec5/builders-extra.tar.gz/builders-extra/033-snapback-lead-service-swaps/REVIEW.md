# Security intent review

This review uses SPEC.md, the authored snapback/schema.q, the installed package README, and installed CLI guides start, security --full, testing --full, rules --full and language --full. No other application or package implementation was consulted. Only single-line invariant declarations in the authored schema were replaced or added. Rules, operations, schedules, authentication, comments and other existing bytes are unchanged. Existing comments are preserved as required; their policy claims are not independent specification evidence.

## Independent interpretation

The explicit privacy boundaries are the homeowner's own address/results/photos, the contractor's assigned addresses, and the crew's scheduled/finished job map. Crew membership alone does not authorize noticed, refused or rescheduled homes. In the existing vocabulary, scheduled is scheduled; replaced, sampled and sampleSkipped are finished replacement jobs. A sampling skip is not itself proof of sampling. No per-crew assignment is specified, so two different crew users may see the same eligible map jobs. Contractors must not see another contractor's assignments and homeowners must not see another homeowner's homes. Relationships are checked against the current resource, with current role checks: a stored assignment alone must not retain a former contractor's access. A roleless user receives no business data, even if an obsolete relationship remains.

The specification does not separately spell out readership of agreement metadata, staff identifiers, refusal reasons or contractor/crew access to child records. For these underspecified details I use one bounded operational interpretation: child records and associated metadata follow the same address audience, crews remain limited to eligible jobs, and the program manager may oversee all program records. “Only the addresses assigned” is interpreted as a row boundary, not permission to read just the address text and nothing else. This is an explicit interpretation, not a claim that the specification expressly grants interior-photo or sample-result access to contractors. A narrower column policy would need product clarification; the confirmed row and lifecycle limits remain independently asserted regardless. There is no stated separate curb/interior read audience, consent-based expiry of existing photos, or post-completion expiry for owners/assigned contractors, so none is invented.

Role administration is implementation support for real authenticated users, not a newly inferred manager power: the dedicated trusted operator may provision roles; ordinary accounts, including managers, may not appoint themselves or others. Users may inspect their own role; managers may inspect the roster as oversight. The operator service seat has no implicit business-data readership and is included explicitly in grant-write intent. The privileged system/job boundary remains a separate proof limitation. Current-role checks are chosen to prevent the stale-assignment pattern discussed in the installed security guide.

## Questionnaire answers: every role and column

The following matrix answers every read question in generated/security-invariants.q.draft. Each listed column has its own column-read invariant as well as a whole-row invariant; the latter also protects logical existence. The same audience applies to value-dependent counts, existence, ordering, filters, copied/derived values and downloads. No authored aggregate/view is present. IDs and foreign references are assessed even where the questionnaire omits synthetic IDs.

H = current homeowner, matching this home's homeowner, in any lifecycle state. T = current contractor, matching this home's contractor, in any lifecycle state. C = current crew, for homes in scheduled/replaced/sampled/sampleSkipped only. M = current manager, all program homes. For child tables H/T/C refer to their current parent home. R = only the caller's own role row; managers may see every role row. None means no row, column, download or derived-value permission. An assignment removal immediately removes T from the permitted server audience; a role change removes role-dependent access. Signing deadlines do not revoke an owner's access to already existing information.

| Table / individually assessed columns | Homeowner | Contractor | Crew | Manager | Signed-in, no role/relationship | Operator seat |
| --- | --- | --- | --- | --- | --- | --- |
| homes: id, address, homeowner, contractor, status, noticeAt, replacedAt, refuseReason, lat, lng | H | T | C | M | None | None |
| agreements: id, home, signedBy, signedAt | H | T | C | M | None | None |
| photos: id, home, kind, photo, takenBy, takenAt | H | T | C | M | None | None |
| samples: id, home, leadPpb, sampledAt, skipped, skipReason, recordedBy | H | T | C | M | None | None |
| roles: id, principal, role | R | R | R | All role rows | None (no role row exists); an own row is readable if present | Only an own row if present |

The questionnaire also lists photos.kind = curb and photos.kind = interior as audiences. These are photo categories, not authenticated roles: neither grants any authority for any row or column. For both kinds evaluate the actual caller using the matrix. In particular, taking a photo does not confer access to other homeowners' photos, and the photo uploader is not an alternative homeowner/contractor relationship.

Every homes.status question has an explicit answer: noticed, refused and rescheduled exclude C; scheduled, replaced, sampled and sampleSkipped admit C. H/T/M do not depend on status. Agreements and sample skips do not widen audiences. No universal public audience exists.

## Authority and lifecycle answers

| Table | Insert authority | Update authority | Delete authority |
| --- | --- | --- | --- |
| roles | Operator service seat, never a self-claimed app role | Operator only, including role/principal columns | No described deletion workflow |
| homes | Manager creates address and ownership/assignment | Manager administers/schedules/assigns; crew records replacement and normal sampling; only manager refuses or skips with a reason | No described deletion workflow |
| agreements | Home's current homeowner, signing as self, within 30 days of notice | No described amendment workflow | No described deletion workflow |
| photos | Current crew, recorded as that crew user, required verified image | No described replacement/edit workflow | No described deletion workflow |
| samples | Current crew records actual result as self; manager alone creates skip as self with reason | No described amendment workflow | No described deletion workflow |

The deny update/delete declarations preserve the narrow described workflow; they are not a claim of an explicit perpetual-retention requirement. Managers' general access does not authorize them to create signed homeowner agreements or impersonate crews. There is no contractor write workflow in the specification. The manager determines assignments; a recipient cannot nominate themselves. Current role and resource relationship must be validated, including the chosen contractor's role. Homeowner ownership, contractor assignment and refusal reasons are protected by column-write invariants so a broad crew home update rule cannot silently acquire administrative authority. Operation-specific markRefused and skipSampling intent expresses manager authority without incorrectly forbidding every crew edit to a row that was already refused/skipped under both-image update semantics.

Independent event-time declarations require a signature by notice + 30 days and a non-skipped sample between replacement and replacement + 90 days. A skip must have a reason and no pretended sample result/time; an actual sample must have a result and time. A refused home needs a reason; completed replacement states need a replacement timestamp. Completion requires a signed agreement and both curb/interior evidence, because the described work includes photographing both old-pipe locations. These are specification assertions, not claims that the checker supports every expression. The photo-evidence operation invariant currently has an unsupported index/probe reduction and the time expressions have unsupported arithmetic/live-reference reductions; they deliberately remain declared and unproved.

The 90-day requirement is an obligation to obtain a sample, not merely permission to refuse late writes. Likewise eventual overnight rescheduling is not proof of an exact deadline transition. Temporal liveness and complete state-transition correctness need further evidence beyond these single-row/operation assertions.

## Recommended enforcement work (not applied)

1. Narrow crew reads on homes and all associated child tables to the scheduled/finished lifecycle audience. Apply the policy in backend rules, including homeDetail, homePhotos, homeSample, agreementFor and jobBoard paths, not just map display filters. Do not leave broad child rules as an alternate read channel.
2. Bind ownership/assignment access to current roles and current parent relationships. Retain the independently confirmed same-role isolation boundaries when roles or assignments change. The existing child rules allow a stored homeowner/contractor relationship without a current-role requirement.
3. Give crew writes only the administrative fields they actually need. The existing whole-row update rule permits crew updates without column restrictions; homes.homeowner, homes.contractor and homes.refuseReason write intent cannot be established from that rule alone. Existing named operations appear narrower, so a broad rule is not by itself a demonstrated exploit through an exposed mutation.
4. Preserve the leading manager guards on refusal/skip operations and require their reasons. Preserve server now for signature, replacement and sample timestamps. Validate chosen principals' roles when creating homes as well as when assigning contractors; createHome currently accepts an arbitrary homeowner principal.
5. Require both curb and interior photos before accepting replacement completion. recordReplacement currently checks an agreement but not either photo. A required image in an individual photo row proves neither that a photo row exists nor that both locations were documented.
6. Reconcile deadline semantics. signAgreement and recordSample compare server now against the deadline, which is useful. rescheduleOverdue runs daily at 03:00, so an unsigned address can remain noticed/scheduled after the 30-day limit until the sweep. A replaced home can remain unsampled indefinitely, and the current late-sample refusal does not satisfy the affirmative 90-day requirement. Enforce deadline-sensitive actions and report/handle missed obligations without recording a fake sample or silently permitting a non-manager skip.
7. Verify real-password operation and at least two distinct users of every named role. No persona switch was added. Generated in-memory users exercise role/ownership checks, but alone do not establish a deployed application with eight independently authenticated password accounts. No fixture or account files could be added under this measurement's invariant-only restriction.

## Validation

Results and limitations are recorded below after the final check → test --fixture-only → audit loop. Complete output is retained in check.json, test.txt and audit.json. Successful compilation is not a security proof. Unsupported obligations and nonzero commands are retained rather than weakening intent.
