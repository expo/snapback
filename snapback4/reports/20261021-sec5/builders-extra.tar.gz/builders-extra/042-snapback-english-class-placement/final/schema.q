use identity password

table roles:
  principal: principal
  role: enum('coordinator', 'teacher', 'learner')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator']
  insert <- viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] and .role = 'learner'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('coordinator', 'teacher', 'learner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }
query myRole():
  return roles[viewer]

table learners:
  principal: principal
  name: text 1..80
  address: text 1..240 read <- exists roles[viewer, role = 'coordinator']
  phone: text 5..30 read <- exists roles[viewer, role = 'coordinator']
  immigration: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png') ? read <- exists roles[viewer, role = 'coordinator']
  level: int 1..3
  status: enum('waitlist', 'placed')
  joinedAt: time
  lastAttendance: time
  unique principal
  immutable principal, joinedAt
  read <- .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'coordinator']
  update <- exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'teacher']
  online only

table tests:
  learner: learners
  writing: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png')
  submittedAt: time
  score: int 0..100 ?
  testedLevel: int 1..3 ?
  gradedBy: principal ?
  immutable learner, writing, submittedAt
  read <- exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists learners[.learner, principal = viewer]
  update <- exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  online only

table attendance:
  learner: learners
  at: time
  recordedBy: principal
  immutable learner, at, recordedBy
  read <- exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  online only

table promotions:
  learner: learners
  fromLevel: int 1..3
  toLevel: int 1..3
  reason: text 5..500
  actor: principal
  at: time
  immutable learner, fromLevel, toLevel, reason, actor, at
  read <- exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'coordinator'] and .actor = viewer
  online only

query learnerList(c: cursor ?):
  return learners first 50 by .id after c
query learnerDetail(learner: learners):
  return learners[learner]
query classRoster(level: int 1..3, c: cursor ?):
  require exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator'] else STAFF_ONLY
  return learners where .level = level and .status = 'placed' first 50 by .id after c
query testList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return tests where .learner = row.id last 50 by .submittedAt after c
query attendanceList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return attendance where .learner = row.id last 50 by .at after c
query promotionList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return promotions where .learner = row.id last 50 by .at after c

mutation enroll(principal: principal, name: text 1..80, address: text 1..240, phone: text 5..30):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  existing = roles[principal]
  require existing = null or existing.role = 'learner' else LEARNER_ACCOUNT_REQUIRED
  if existing = null:
    insert roles { principal, role: 'learner' }
  return insert learners { principal, name, address, phone, level: 1, status: 'waitlist', joinedAt: now, lastAttendance: now }
mutation savePrivate(learner: learners, address: text 1..240, phone: text 5..30):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  update learners[learner] { address, phone }
mutation attachImmigration(learner: learners, document: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png')):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  update learners[learner] { immigration: document }
mutation submitTest(learner: learners, writing: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png')):
  row = learners[learner] ! else NOT_FOUND
  require row.principal = viewer else OWN_TEST_ONLY
  require exists roles[viewer, role = 'learner'] else LEARNER_ONLY
  return insert tests { learner, writing, submittedAt: now }
mutation gradeTest(test: tests, score: int 0..100):
  require exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator'] else STAFF_ONLY
  row = tests[test] ! else NOT_FOUND
  require row.score = null else ALREADY_GRADED
  level = 3 if score >= 80 else 2 if score >= 50 else 1
  update tests[test] { score, testedLevel: level, gradedBy: viewer }
  update learners[row.learner] { level }
mutation recordAttendance(learner: learners):
  require exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator'] else STAFF_ONLY
  update learners[learner] { lastAttendance: now }
  return insert attendance { learner, at: now, recordedBy: viewer }
mutation place(learner: learners):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  row = learners[learner] ! else NOT_FOUND
  require now <= row.lastAttendance + 21d else ABSENCE_OVER_21_DAYS
  update learners[learner] { status: 'placed' }
mutation promote(learner: learners, level: int 1..3, reason: text 5..500):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  row = learners[learner] ! else NOT_FOUND
  require level > row.level else MUST_MOVE_UP
  require now <= row.lastAttendance + 21d else ABSENCE_OVER_21_DAYS
  insert promotions { learner, fromLevel: row.level, toLevel: level, reason, actor: viewer, at: now }
  update learners[learner] { level }

job waitlistAbsent():
  for row in learners:
    if row.status = 'placed' and now > row.lastAttendance + 21d:
      update learners[row.id] { status: 'waitlist' }
schedule absenceCheck every 1m: waitlistAbsent

-- Intent from the program specification, independent of UI visibility.
invariant learners.address read only exists roles[viewer, role = 'coordinator']
invariant learners.phone read only exists roles[viewer, role = 'coordinator']
invariant learners.immigration read only exists roles[viewer, role = 'coordinator']
invariant learners.enroll only exists roles[viewer, role = 'coordinator']
invariant learners.promote only exists roles[viewer, role = 'coordinator']
invariant promotions.insert only exists roles[viewer, role = 'coordinator']
invariant tests.insert only exists learners[.learner, principal = viewer]
invariant roles.update only viewer = 'service:operator'
invariant roles.read only .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator']
invariant roles.principal read only .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator']
invariant roles.role read only .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator']
invariant learners.read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.principal read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.name read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.level read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.status read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.joinedAt read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.lastAttendance read only .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.learner read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.writing read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.submittedAt read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.score read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.testedLevel read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.gradedBy read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant attendance.read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant attendance.learner read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant attendance.at read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant attendance.recordedBy read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.learner read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.fromLevel read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.toLevel read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.reason read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.actor read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.at read only exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.address write only exists roles[viewer, role = 'coordinator']
invariant learners.phone write only exists roles[viewer, role = 'coordinator']
invariant learners.immigration write only exists roles[viewer, role = 'coordinator']
invariant learners.insert only exists roles[viewer, role = 'coordinator']
invariant learners.update only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.level update only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.place only exists roles[viewer, role = 'coordinator']
invariant learners.savePrivate only exists roles[viewer, role = 'coordinator']
invariant learners.attachImmigration only exists roles[viewer, role = 'coordinator']
invariant learners.gradeTest only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant learners.recordAttendance only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.submitTest only exists roles[viewer, role = 'learner']
invariant tests.insert only exists learners[.learner, principal = viewer] and exists roles[viewer, role = 'learner'] and .score = null and .testedLevel = null and .gradedBy = null
invariant tests.update only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.gradeTest only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.score update only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.testedLevel update only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant tests.gradedBy update only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant attendance.insert only (exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']) and .recordedBy = viewer
invariant attendance.recordAttendance only exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
invariant promotions.insert only exists roles[viewer, role = 'coordinator'] and .actor = viewer
invariant promotions.promote only exists roles[viewer, role = 'coordinator']
invariant promotions always .toLevel > .fromLevel and .reason != ''
invariant tests always .writing != null
invariant learners always .status != 'placed' or now <= .lastAttendance + 21d
invariant roles.insert only viewer = 'service:operator' or (exists roles[viewer, role = 'coordinator'] and .role = 'learner')
invariant roles.role update only viewer = 'service:operator'
invariant roles.provision only viewer = 'service:operator'
