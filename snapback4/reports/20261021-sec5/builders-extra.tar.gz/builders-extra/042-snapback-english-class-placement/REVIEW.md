# Security-intent review

## Scope and independent interpretation

Reviewed SPEC.md and the sole authored query file, snapback/schema.q. Product semantics came only from the installed snapback4 README and CLI guides: start, security --full, testing --full, language --find invariant, and focused fixture-only/synthetic-evidence guide lookups. No application source outside this workspace or package implementation was consulted. The first commands were the required start and full security guides.

Only single-line invariant declarations were added to the authored .q file. All eight original assertions were retained after independent review, and 56 were added (64 total). Enforcement, operations, jobs, authentication and every other original byte remain unchanged. REVIEW.md and the requested command captures are review artifacts.

SPEC.md explicitly separates educational progress from address, phone and immigration documents. Teachers see **each learner's** educational information; there is no assigned-teacher or class-membership limitation. Both teachers therefore have the same educational audience across all learners, while neither gains private-file access. Both coordinators administer all learners; the specification provides no individual coordinator ownership partition. Two learners must remain isolated from each other, including counts, roster identities, derived levels and writing downloads. A learner's own address/phone/documents are still coordinator-only under the word “only.”

The specification has no consent switch, publication stage, ungraded-test embargo, or loss of progress visibility on waitlisting. Educational read audiences apply to placed and waitlisted learners, graded and ungraded tests, and historical attendance/promotion records. The 21-day condition changes placement eligibility, not permission to read progress. It must not be added to privacy intent as an invented visibility restriction.

“Own” is the immutable learners.principal identity, or that identity reached through a child row's learner reference. Keeping access to one's own educational history after an account-role change is not prohibited by this specification. Accordingly, owner-read intent does not invent a current-learner-role requirement. Current teacher/coordinator authority is required for their staff access; prior staff status alone grants nothing. Submitting a new test, in contrast, is a learner action. Signed-in users without a role **and without an ownership relationship** have no educational audience. A roleless account retaining its own learner record retains only its own progress; it gains no private fields or other learners' data. This explicitly answers the grant-outlives-role advisories without treating them as requirements absent from the spec.

Some columns support the chosen implementation rather than explicit spec fields: name/principal identify progress and roster entries; joinedAt identifies enrollment; submittedAt and gradedBy describe the learner's test; attendance.recordedBy identifies its recorder; promotion actor/time/reason describe the recorded advancement. They follow the educational audience. The spec does not separately reserve promotion reasons to coordinators. This is a bounded interpretation of “own progress,” not permission to copy address/phone/immigration contents into educational free text. Account-role lookup and trusted operator bootstrap are implementation support decisions, not new end-user roles specified by the product.

## Answers to the generated questionnaire

The following matrices answer every generated per-role row/column question. They also cover implicit ids. “All learners” means program-wide, including another teacher's/coordinator's learners; “Own learner reference only” means the referenced learners.principal equals the authenticated viewer. Every matrix entry includes the lifecycle conditions above. No role may infer a forbidden column through derived values, filtering, sorting, counts, existence, refusals, exports or asset downloads. Whole-row read intent protects hidden row existence; explicit column intent separately protects payloads and derived observations.

### learners: row and column answers

| Questionnaire target | Unrelated signed-in user | Learner | Teacher | Coordinator |
|---|---|---|---|---|
| `learners.read (row existence)` | None | Own only | All learners | All learners |
| `learners.id` | None | Own only | All learners | All learners |
| `learners.principal` | None | Own only | All learners | All learners |
| `learners.name` | None | Own only | All learners | All learners |
| `learners.level` | None | Own only | All learners | All learners |
| `learners.status` | None | Own only | All learners | All learners |
| `learners.joinedAt` | None | Own only | All learners | All learners |
| `learners.lastAttendance` | None | Own only | All learners | All learners |

| Private column | Unrelated signed-in user | Learner (including owner) | Teacher | Coordinator |
|---|---|---|---|---|
| `learners.address` | None | None | None | All learners |
| `learners.phone` | None | None | None | All learners |
| `learners.immigration` | None | None | None | All learners |

### tests: row and column answers

| Questionnaire target | Unrelated signed-in user | Learner | Teacher | Coordinator |
|---|---|---|---|---|
| `tests.read (row existence)` | None | Own learner reference only | All learners | All learners |
| `tests.id` | None | Own learner reference only | All learners | All learners |
| `tests.learner` | None | Own learner reference only | All learners | All learners |
| `tests.writing` | None | Own learner reference only | All learners | All learners |
| `tests.submittedAt` | None | Own learner reference only | All learners | All learners |
| `tests.score` | None | Own learner reference only | All learners | All learners |
| `tests.testedLevel` | None | Own learner reference only | All learners | All learners |
| `tests.gradedBy` | None | Own learner reference only | All learners | All learners |

### attendance: row and column answers

| Questionnaire target | Unrelated signed-in user | Learner | Teacher | Coordinator |
|---|---|---|---|---|
| `attendance.read (row existence)` | None | Own learner reference only | All learners | All learners |
| `attendance.id` | None | Own learner reference only | All learners | All learners |
| `attendance.learner` | None | Own learner reference only | All learners | All learners |
| `attendance.at` | None | Own learner reference only | All learners | All learners |
| `attendance.recordedBy` | None | Own learner reference only | All learners | All learners |

### promotions: row and column answers

| Questionnaire target | Unrelated signed-in user | Learner | Teacher | Coordinator |
|---|---|---|---|---|
| `promotions.read (row existence)` | None | Own learner reference only | All learners | All learners |
| `promotions.id` | None | Own learner reference only | All learners | All learners |
| `promotions.learner` | None | Own learner reference only | All learners | All learners |
| `promotions.fromLevel` | None | Own learner reference only | All learners | All learners |
| `promotions.toLevel` | None | Own learner reference only | All learners | All learners |
| `promotions.reason` | None | Own learner reference only | All learners | All learners |
| `promotions.actor` | None | Own learner reference only | All learners | All learners |
| `promotions.at` | None | Own learner reference only | All learners | All learners |

### roles: row and column answers

| Questionnaire target | Unrelated signed-in user | Learner | Teacher | Coordinator |
|---|---|---|---|---|
| `roles.read (row existence)` | None | Own principal only | Own principal only | All accounts |
| `roles.id` | None | Own principal only | Own principal only | All accounts |
| `roles.principal` | None | Own principal only | Own principal only | All accounts |
| `roles.role` | None | Own principal only | Own principal only | All accounts |

For roles, service:operator may inspect and provision account roles for trusted bootstrap. It has no implicit access to learners, attendance, tests, promotions, writing downloads or private documents; only independently acquiring an actual product role or ownership could supply that audience. The generated questionnaire does not list this service audience, so it is assessed here explicitly. An unrelated roleless account's myRole may return absence, not other users' roles. Own role lookup after a role change follows the account principal. The role catalog has no public-directory requirement.

The row/column assertions are deliberately retained even when matching current rules: the simple owner policy and program-wide teacher educational policy are confirmed from SPEC.md, rather than mechanically tightened to satisfy an advisory. learners.address/phone/immigration keep their separate coordinator-only read assertions. Every other authored column has explicit educational or account-role read intent in addition to whole-row intent. tests.testedLevel and learners.level are derived educational values with the same audience as their source scores. classRoster exposes only educational placed-row data to staff; learners cannot use it as a classmate directory. There are no authored aggregate views or export operations, but the read assertions also govern future value-dependent observations in the supported checker model.

### Authority answers (all generated effect questions)

| Table | Insert | Update | Delete |
|---|---|---|---|
| roles | Trusted operator appoints staff; current coordinator may enroll a learner, never appoint staff. No self-assigned privileged role. | Trusted operator changes roles; ordinary teachers/learners/coordinators cannot elevate themselves or another account. | No deletion operation or product requirement; omitted rule denies. |
| learners | Coordinator enrolls and binds an account to a learner; the account must not already be staff. Initial state is level 1, waitlist. | Coordinator maintains private details and places learners; staff record attendance and apply a tested level through grading. Only coordinator may advance outside testing and must record why. | No deletion operation or product requirement; omitted rule denies. |
| tests | Learner submits their own required uploaded writing sample; cannot submit as another learner or supply a self-awarded grade/testedLevel/grader. New test starts ungraded. | Staff grade a test and derive level from the score. No learner grades their own or another learner's test. | No deletion operation or product requirement; omitted rule denies. |
| attendance | Staff record attendance for any program learner, using the authenticated recorder and server event time. Learners cannot assert attendance for themselves or peers. | No editing operation in this scope; immutable historical record. | No deletion operation or product requirement; omitted rule denies. |
| promotions | Current coordinator records an upward move, with nonempty reason and their own actor attribution. | No editing operation in this scope; recorded reason/actor/levels must remain associated with the advancement. | No deletion operation or product requirement; omitted rule denies. |

Staff grading and attendance recording, coordinator maintenance, and operator bootstrap are necessary implementation choices consistent with the described workflow; the spec expressly mandates coordinator-only out-of-test advancement and coordinator placement. No stronger claim about a spec-required single grading attempt, log retention period, document type, or role-change workflow is inferred. Deletion bans were not added as new spec intent.

Relationships and appointments cannot be claimed by a caller merely writing their own principal. enroll is coordinator-gated and checks the selected account's existing role; provision is operator-gated. Learner ownership is immutable, and child references are immutable. Those facts address the argument-grant notices; a privileged caller is intended to select an account during enrollment/bootstrap, but must bind it to the correct real person through the program's provisioning process. The specification does not define invitations or consent approval, so none is invented.

### Independent authority and lifecycle assertions

Added read intent for all five tables and all non-private authored columns. Added coordinator-only writes to address/phone/immigration; enrollment/placement/private-maintenance authority; staff-only educational updates/grading/attendance; learner-only own-test submission with initially null grade fields; recorder and promotion actor attribution; role appointment/update authority; upward nonempty-reason promotion integrity; and required writing evidence. The pre-existing promotion operation restriction remains coordinator-only. General learners.level update intent permits staff because grading legitimately changes levels; operation-specific learners.promote intent separately prohibits teachers from the out-of-test path. A blanket coordinator-only level update would incorrectly prohibit testing.

Added `invariant learners always .status != 'placed' or now <= .lastAttendance + 21d`. At exactly 21 days placement remains eligible; strictly later it must be waitlisted. This preserves the actual deadline rather than accepting “eventually on the next minute sweep.” The installed checker reports the clock comparison outside its rule proof fragment; the declaration is deliberately retained as unproved. Unsupported syntax in a proof reduction is not a reason to weaken the deadline. A time-dependent row assertion is not a complete proof of a continuous-time transition.

No single local invariant here proves that **every** non-test level increase creates a matching promotion record with the same old/new levels and reason. promotions integrity and operation-role invariants cover separate necessary conditions. Cross-operation atomicity and old/next transition checks remain a distinct review obligation. Column update invariants constrain old and next row images; none incorrectly requires an already graded row to be ungraded on update.

## Review findings and recommended enforcement changes

1. **Exact 21-day placement deadline needs stronger enforcement.** waitlistAbsent runs every minute. A placed learner can remain stored as placed between the deadline and the next sweep, and classRoster filters stored status without checking the deadline. place/promote already compare server now, but that does not immediately withdraw an existing expired placement. Recommend deriving effective waitlist state and roster membership from the server deadline (or a documented exact temporal mechanism) while retaining scheduled cleanup. Do not relax the specification to one minute late. This is a source-level mismatch; the clock invariant itself has a named unsupported proof path.
2. **Table-level write policies are broader than the intended operations.** learners.update admits teachers for all mutable columns, while coordinator-only private-maintenance intent is narrower. tests.insert checks ownership without requiring a current learner role or initially null grade fields. attendance.insert does not constrain recordedBy. The existing authored mutations supply the intended guards/values. The checker's failed rule implications are not, by themselves, replayed exploits through those mutations. Recommend tightening field/table write policy where supported, preserving grading authority, and retaining explicit mutation guards and immutable attribution. Confirm any fix against actual exposed write paths before claiming a vulnerability or repair.
3. **Out-of-test promotion needs continued transition coverage.** promote currently checks coordinator, upward direction, nonempty constrained reason, inserts the record and updates level atomically. gradeTest is staff-gated, derives the tested level, and updates that learner. Keep these distinct paths and add business-case verification of their relationship and stored reason. Do not conclude the whole requirement is proved from a coordinator role invariant alone.
4. **Optional immigration upload is not an omitted-evidence violation.** SPEC.md requires a writing upload for a placement test, and writing is required. It mentions immigration documents on the file without saying every learner must supply one. Retain optional immigration documents; protect any existing document including downloads. Required writing evidence does not imply every newly enrolled learner has already completed a test.
5. **Authentication and two-user coverage need evidence at the appropriate boundary.** use identity password matches real backend authentication, with no authored persona switch. The installed security guide documents two synthesized users per discovered role/seat, so the coordinator/teacher/learner enum supplies all three role pairs to fixture generation. The text output does not enumerate each generated principal individually; role-pair coverage is based on that documented generator behavior, not independently observed six deployed password accounts. Generated in-memory principals do not establish real deployment account provisioning or credential isolation. The requested fixture-only run did exercise isolated production HTTP credential revocation and unauthenticated admission, but that is not an exhaustive authentication or deployment acceptance claim. No persistent server was started manually and no fixtures/accounts were edited.
6. **Live roster and broader observation paths remain validation obligations.** Tables are online only, which does not itself establish a broken live subscription. Verify two staff readers receive placement/waitlist changes promptly through the backend's live client mechanism; do not equate “online only” with “not live.” The CLI names unresolved refusals, raw reference probes, wire metadata, job boundaries and some operation-control paths. They are coverage limitations, not confirmed disclosures. No aggregate/download shortcut may widen the coordinator-only private-field policy.

## Command evidence

All commands ran from this workspace through the specified installed CLI. stdout and stderr were redirected together into the requested files without display truncation. Commands were bounded with timeout (30 seconds for guides, 60 for check and the initial audit, 180 for test and the audit retry). Exit status is reported separately from the captured command output.

| Command | Exit | Capture | Outcome |
|---|---|---|---|
| check --json (initial questionnaire generation) | 0 | Superseded by final check.json | Original 8 invariants, all unproved; 10 uncovered admitted effects. |
| check --json (after intent additions) | 0 | check.json | 64 invariants: 0 proved, 0 refuted, 64 unproved overall. 51 direct-rule obligations proved and 13 unproved. No uncovered admitted effects. |
| test --fixture-only | 0 | test.txt | 23,157 security attempts, 5,974 refused, 0 reachable violations; 4 non-failing seed/synthetic observations; 1,024 short ordered histories and 16 operations exercised. |
| audit --json (first attempt) | 124 | Empty stdout/stderr, superseded by retry | Reached the 60-second timeout before producing output. |
| audit --json (bounded retry) | Pending | audit.json | Pending. |

The test's isolated production hosts refused 35 unauthenticated/forged-persona/development-door attempts and 42 retired-credential attempts after refresh and logout-all. No persistent hosts were started manually. Test explicitly reports **no authored business cases; generated-fixture only**. Its ordinary operation summary is incomplete: 2 complete queries, 1 expected derived-argument probe refusal and 4 operations not run in that summary. This is not contradicted by the separately reported 16-operation security matrix.

The generated security-test.json record has 0 violations and reports 98 coverage gaps. Its completed run marker does not imply exhaustive coverage. Gaps include unsupported concrete clock expressions, capped value worlds/history observers/argument matrices, referentially valid paired-world construction, trusted job effects, write-boundary correspondence, incomplete asset-ledger transfer, and generated promotion snapshots rejected by the existing non-whitespace reason constraint. Four seed/synthetic observations are expressly non-failing supplemental evidence; test.txt does not label them as authored-operation exploit traces. No reachable violation was established by this run.

The checker retains unknown refusal/copy/raw-reference/job/wire paths and the unsupported clock predicate; those are why proved direct rule implications do not establish any whole invariant here. A successful finite campaign is not a security proof, and zero uncovered declarations means only that every admitted table effect has authored intent. Confirmed privacy and deadline intent were not widened to make checks green.


Mutation constraint verified by hashing the ordered original/current lines after excluding only lines beginning with `invariant `: SHA-256 `3b112f967ec204e213e80993260afde9c5e641126959db2e3d22e3365a3d5332`. All eight original invariant lines are also retained. No application fixtures or accounts were added or changed.
