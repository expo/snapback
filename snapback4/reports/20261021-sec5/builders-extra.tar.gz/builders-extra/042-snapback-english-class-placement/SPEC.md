
**English Class Placement.** A community English program places adult learners into levels, and each learner takes a placement test with their writing sample uploaded. Teachers see each learner's level, attendance, test scores and writing samples, but not the learner's home address, phone number or immigration documents on the same file, which only the program coordinator sees. Learners see only their own progress, class rosters update live as the coordinator places new learners, and a learner absent for more than 21 days after their last attendance is moved to the waitlist. Only the coordinator can move a learner up a level outside testing, recording why.

Model every role the spec names, with **at least two users of each role**, so
the access rules are exercised between users of the same role as well as
across roles. Users sign in with the backend's recommended real
authentication (for example password accounts); a development-only identity
switch does not count, because one user must not be able to act as another
without that user's credential. Pick reasonable field constraints. Keep the
scope to what is described; do not gold-plate. Every authorization and privacy
rule in the spec must be enforced by the backend, not only hidden in the UI.
