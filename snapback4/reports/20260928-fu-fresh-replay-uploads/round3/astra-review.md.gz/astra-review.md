The round-1 reproductions are fixed, but the audit still misses automatic token-refresh replay during local startup.

I reviewed `git diff 492ff2419..7c94f7126`. Tests ran only in disposable copies; the worktree is unchanged.

The requested reproductions pass:

- **Once-view download + credential rotation + `ECONNRESET`:** one GET; the original cause survives.
- **Ephemeral mutation + JSON 503 `E_RATE_LIMIT`:** returns the refusal, remains online, preserves queued calls, and never replays.
- **Fresh local `/schema` overload:** four bounded attempts, then a typed `E_RATE_LIMIT`.
- **Offline local client receiving probe/sync overload, then uploading:** restores reachability; upload reaches the server and returns `E_RATE_LIMIT`.
- **Concurrent uploads with `Retry-After: 1`:** controlled randomness produced first retry delays of **1000, 1062.5, 1125 and 1187.5 ms**.
- **Sign-in failures:** reset causes and plain-text HTTP status survive.

The submitted overload suite passes **79/79**, and adjacent affected tests pass **140/140**. Against the base SDK, **44 public regression cases fail**.

1. **Medium — startup still automatically replays an ambiguous token refresh. Blocks landing.**  
   [local.ts:80](/home/ccheever/sb4-intent/review-fu-r2-astra/snapback4/packages/snapback4/src/local.ts:80), [local.ts:1478](/home/ccheever/sb4-intent/review-fu-r2-astra/snapback4/packages/snapback4/src/local.ts:1478)

   The constructor performs its own refresh, ignores `E_OFFLINE`/`E_HTTP_RESPONSE`, and later unconditionally calls `scheduleRefresh()`. It bypasses the new protection in `refreshCurrent()`.

   **Reproduced through `createLocalClient()`:** reopen a saved device with a near-expiry session; let the real server consume the token and return 200, then discard that response with `ECONNRESET`. While schema/sync/probe return admission refusals, startup succeeds from saved state and arms a 60-second refresh timer. Firing that timer sends the consumed bearer again: observed refresh statuses **200, 401**, followed by **signed-out**. A plain-text startup refresh response also schedules another attempt.

   **Smallest fix:** retain the startup refresh outcome and suppress automatic scheduling after an ambiguous result, including at the end of deferred startup. Apply the same retry policy used by `refreshCurrent()`. Add the regression at construction time; existing tests refresh an already-open client.

2. **Medium — malformed ephemeral HTTP replies still become transport failures. Non-blocking alone.**  
   [ephemeral.ts:74](/home/ccheever/sb4-intent/review-fu-r2-astra/snapback4/packages/snapback4/src/ephemeral.ts:74)

   **Reproduced in both tiers:** return plain-text `busy` with HTTP 503 to public ephemeral `client.mutate()`. Direct JSON decoding throws; the result is **`E_OFFLINE`**, the HTTP status disappears, and the link becomes offline. That transition also drops waiting ephemeral calls.

   **Smallest fix:** use `readResponse()` and return status-bearing `E_HTTP_RESPONSE` for malformed envelopes. Reserve transport handling for fetch/body transport failures; keep the no-replay policy.

The **server refusal path is sound**. All three overload tests pass, including actual thread-spawn failure with an unfinished upload. `PendingRequest` refuses before the request destructor can drain, releases the permit, and counts the refusal. The fixed response remains nonblocking and bounded; diagnostic reporting retains its bounded queue and separate writer. I found no server landing blocker.

3. **Low — the jitter tests permit completely synchronized retries. Non-blocking alone.**  
   [overload.test.mjs:385](/home/ccheever/sb4-intent/review-fu-r2-astra/snapback4/packages/snapback4/test/overload.test.mjs:385)

   **Surviving mutation, executed:** replace `jitter(delay)` with `delay * 1.125`. **All 79 overload tests still pass.** Four concurrent retriers then all schedule **1125 ms**. The deterministic assertions consistently use `Math.random() === 0.5`, so they protect the multiplier but not variation.

   **Smallest fix:** vary mocked randomness across concurrent public calls and assert distinct delays, all respecting `Retry-After`. My independent concurrent-upload test rejects this mutation.

**Verdict: NOT READY.**