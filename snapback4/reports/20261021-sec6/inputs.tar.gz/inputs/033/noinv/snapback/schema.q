-- Lead Service Swaps: water utility replacing lead service pipes.
-- Roles: homeowner, crew, contractor, manager (program manager).
-- Password accounts; the local operator provisions roles (see guide staging).
use identity password

table roles:
  principal: principal
  role: enum('homeowner', 'crew', 'contractor', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'manager']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

-- One service address. noticeAt starts the 30-day access-agreement window;
-- replacedAt starts the 90-day sampling window.
table homes:
  address: text 1..200
  homeowner: principal ?
  contractor: principal ?
  status: enum('noticed', 'scheduled', 'replaced', 'sampled', 'refused', 'rescheduled', 'sampleSkipped')
  noticeAt: time ?
  replacedAt: time ?
  refuseReason: text 1..500 ?
  lat: int -90000000..90000000
  lng: int -180000000..180000000
  -- Required pipe photo coverage summary, visible only to the program manager.
  -- 'both': photos show the old pipe at curb and inside; 'curbOnly' /
  -- 'interiorOnly': just that location; 'none': neither pictured yet.
  photoCoverage: enum('both', 'curbOnly', 'interiorOnly', 'none') default 'none' read <- exists roles[viewer, role = 'manager']
  cap 10000
  read <- exists homes[.id, homeowner = viewer] or exists homes[.id, contractor = viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew']
  online only

-- The homeowner's signed access agreement; one per home.
table agreements:
  home: homes
  signedBy: principal
  signedAt: time default now
  unique home
  immutable home, signedBy
  read <- exists homes[.home, homeowner = viewer] or exists homes[.home, contractor = viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists homes[.home, homeowner = viewer]
  online only

-- Crew photos of the old pipe: at the curb and inside the home.
table photos:
  home: homes
  kind: enum('curb', 'interior')
  photo: image <=8000000
  takenBy: principal
  takenAt: time default now
  immutable home, kind, photo, takenBy
  cap 100 by home
  read <- exists homes[.home, homeowner = viewer] or exists homes[.home, contractor = viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew']
  online only

-- The post-replacement water sample; one row per home. A manager may record
-- a skip with a reason instead of a result.
table samples:
  home: homes
  leadPpb: int 0..10000 ?
  sampledAt: time ?
  skipped: bool default false
  skipReason: text 1..500 ?
  recordedBy: principal
  unique home
  immutable home, recordedBy
  read <- exists homes[.home, homeowner = viewer] or exists homes[.home, contractor = viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  online only

mutation provision(principal: principal, role: enum('homeowner', 'crew', 'contractor', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

query myHome(c: cursor ?):
  return homes where .homeowner = viewer first 50 by .id after c

query assignedHomes(c: cursor ?):
  return homes where .contractor = viewer first 50 by .id after c

query jobBoard(c: cursor ?):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  return homes first 50 by .id after c

query homeDetail(target: homes):
  return homes[target]

query homePhotos(target: homes, c: cursor ?):
  return photos where .home = target first 50 by .id after c

query agreementFor(target: homes):
  return agreements[home = target]

query homeSample(target: homes):
  return samples[home = target]

query roster(c: cursor ?):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return roles first 50 by .principal after c

mutation createHome(address: text 1..200, homeowner: principal ?, lat: int -90000000..90000000, lng: int -180000000..180000000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return insert homes { address, homeowner, contractor: null, status: 'noticed', noticeAt: now, replacedAt: null, refuseReason: null, lat, lng, photoCoverage: 'none' }

mutation assignContractor(target: homes, contractor: principal):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  h = homes[target] ! else NOT_FOUND
  require exists roles[principal = contractor, role = 'contractor'] else NOT_CONTRACTOR
  update homes[target] { contractor }
  return null

mutation scheduleHome(target: homes):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  h = homes[target] ! else NOT_FOUND
  require h.status = 'noticed' else BAD_STATUS
  update homes[target] { status: 'scheduled' }
  return null

mutation signAgreement(target: homes):
  h = homes[target] ! else NOT_FOUND
  require h.homeowner = viewer else NOT_YOUR_HOME
  -- The 30-day access deadline is the primary rule: a home the sweep already
  -- rescheduled still reports the closed window rather than a bare status.
  require h.noticeAt != null and now <= h.noticeAt + 30d else SIGN_WINDOW_CLOSED
  require h.status = 'noticed' or h.status = 'scheduled' else BAD_STATUS
  require not exists agreements[home = target] else ALREADY_SIGNED
  return insert agreements { home: target, signedBy: viewer }

mutation recordReplacement(target: homes):
  require exists roles[viewer, role = 'crew'] else NOT_CREW
  h = homes[target] ! else NOT_FOUND
  require h.status = 'noticed' or h.status = 'scheduled' else BAD_STATUS
  require exists agreements[home = target] else NO_AGREEMENT
  update homes[target] { status: 'replaced', replacedAt: now }
  return null

mutation placePhoto(target: homes, kind: enum('curb', 'interior'), photo: image <=8000000):
  require exists roles[viewer, role = 'crew'] else NOT_CREW
  h = homes[target] ! else NOT_FOUND
  insert photos { home: target, kind, photo, takenBy: viewer, takenAt: now }
  -- Keep the coverage summary in step with the photos as they change.
  if exists photos[home = target, kind = 'curb']:
    if exists photos[home = target, kind = 'interior']:
      update homes[target] { photoCoverage: 'both' }
    else:
      update homes[target] { photoCoverage: 'curbOnly' }
  else:
    if exists photos[home = target, kind = 'interior']:
      update homes[target] { photoCoverage: 'interiorOnly' }
    else:
      update homes[target] { photoCoverage: 'none' }
  return null

-- Recompute one address's coverage from its current photos. Used to migrate
-- pre-v2 addresses and to reconcile after a rollback window.
mutation refreshCoverage(target: homes):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  h = homes[target] ! else NOT_FOUND
  if exists photos[home = target, kind = 'curb']:
    if exists photos[home = target, kind = 'interior']:
      update homes[target] { photoCoverage: 'both' }
    else:
      update homes[target] { photoCoverage: 'curbOnly' }
  else:
    if exists photos[home = target, kind = 'interior']:
      update homes[target] { photoCoverage: 'interiorOnly' }
    else:
      update homes[target] { photoCoverage: 'none' }
  return null

-- Manager-only read of the coverage summary for one address.
query coverageFor(target: homes):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  h = homes[target] ! else NOT_FOUND
  return { coverage: h.photoCoverage }

mutation recordSample(target: homes, leadPpb: int 0..10000):
  require exists roles[viewer, role = 'crew'] else NOT_CREW
  h = homes[target] ! else NOT_FOUND
  require h.status = 'replaced' else BAD_STATUS
  require h.replacedAt != null and now <= h.replacedAt + 90d else SAMPLE_WINDOW_CLOSED
  require not exists samples[home = target] else ALREADY_SAMPLED
  insert samples { home: target, leadPpb, sampledAt: now, skipped: false, skipReason: null, recordedBy: viewer }
  update homes[target] { status: 'sampled' }
  return null

mutation markRefused(target: homes, reason: text 1..500):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  h = homes[target] ! else NOT_FOUND
  update homes[target] { status: 'refused', refuseReason: reason }
  return null

mutation skipSampling(target: homes, reason: text 1..500):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  h = homes[target] ! else NOT_FOUND
  require h.status = 'replaced' else BAD_STATUS
  require not exists samples[home = target] else ALREADY_SAMPLED
  insert samples { home: target, leadPpb: null, sampledAt: null, skipped: true, skipReason: reason, recordedBy: viewer }
  update homes[target] { status: 'sampleSkipped' }
  return null

-- Overnight sweep: a notice with no signed agreement past its 30-day window
-- goes back for rescheduling.
job rescheduleOverdue():
  for h in homes:
    if (h.status = 'noticed' or h.status = 'scheduled') and h.noticeAt != null and h.noticeAt + 30d < now and not exists agreements[home = h.id]:
      update homes[h.id] { status: 'rescheduled' }

schedule rescheduleDaily every 1d at 03:00: rescheduleOverdue

-- Spec privacy intent: a homeowner sees only their own address, sample
-- results and photos; a contractor sees only assigned addresses; crews see
-- scheduled and finished jobs; the manager sees everything.
-- Spec: only the program manager may see the pipe photo coverage summary.
