-- Luthier Crack Repairs.
-- Roles: customer (instrument owner), apprentice (bench board viewer),
-- luthier (writes estimates, moves bench), shopOwner (over-appraisal approver).
-- Every table is online only: the browser uses createApp without a device.

use identity password

-- Staff roster. Signup grants no role; only the local operator seat assigns.
table roles:
  principal: principal
  role: enum('customer', 'apprentice', 'luthier', 'shopOwner')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'shopOwner'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('customer', 'apprentice', 'luthier', 'shopOwner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[principal = viewer]

-- An instrument brought in for repair. Photos show each crack / worn fret /
-- loose seam; problem is the owner's description; status drives the bench.
table instruments:
  owner: principal
  label: text 1..80
  kind: enum('guitar', 'violin', 'other')
  problem: text 1..1000
  appraisedValue: money USD
  photos: [image <=5000000] <=4 ?
  status: enum('intake', 'estimated', 'approved', 'gluing', 'setup', 'finalCheck', 'ready', 'collected', 'returned') default 'intake'
  readyAt: time ?
  collectedAt: time ?
  storageCents: int ?
  at: time default now
  immutable owner
  read <- .owner = viewer or exists roles[viewer, role = 'apprentice'] or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner']
  insert <- .owner = viewer or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner']
  update <- .owner = viewer or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner']
  delete <- deny
  cap 200 by owner
  online only

-- A luthier's estimate for one instrument. expiresAt is set 14 days after
-- writing; approveEstimate refuses after that and the nightly job flips
-- stale pending rows to expired and returns the instrument unrepaired.
table estimates:
  instrument: instruments on delete restrict
  owner: principal
  amount: money USD
  notes: text 1..500
  status: enum('pending', 'approved', 'declined', 'expired') default 'pending'
  createdAt: time default now
  expiresAt: time
  decidedAt: time ?
  overReason: text 1..500 ?
  overApprovedBy: principal ?
  appraisal: enum('within', 'above', 'needed')
  immutable instrument, owner, amount, createdAt, expiresAt
  read <- .owner = viewer or exists roles[viewer, role = 'apprentice'] or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner']
  insert <- exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner']
  update (old, next) <- (old.owner = viewer or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner']) and (old.appraisal = next.appraisal or exists roles[viewer, role = 'shopOwner'])
  delete <- deny
  cap 20 by instrument
  online only

-- v2 migration: every pre-existing estimate carries the comparison the rules
-- imply. Appraised values are always recorded, so 'needed' has no rows yet;
-- the branch keeps the declared rule total if that ever changes.
backfill estimates appraisal(amount: money USD, instrument: instruments):
  {appraisal: 'needed' if instruments[instrument].appraisedValue = null else 'within' if amount <= (instruments[instrument].appraisedValue ?? amount - amount) else 'above'}

-- Customers log their own instruments; staff log intake on a customer's behalf.
mutation bringInstrument(label: text 1..80, kind: enum('guitar', 'violin', 'other'), problem: text 1..1000, appraisedValue: money USD, photos: [image <=5000000] <=4 ?):
  return insert instruments { owner: viewer, label, kind, problem, appraisedValue, photos, status: 'intake' }

mutation logIntake(owner: principal, label: text 1..80, kind: enum('guitar', 'violin', 'other'), problem: text 1..1000, appraisedValue: money USD):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF
  return insert instruments { owner, label, kind, problem, appraisedValue, status: 'intake' }

-- The luthier's estimate. Starts (or restarts) the 14-day approval window.
mutation writeEstimate(instrument: instruments, amount: money USD, notes: text 1..500):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF
  require amount >= amount - amount else BAD_AMOUNT 'Estimate amounts cannot be negative.'
  i = instruments[instrument] ! else NOT_FOUND
  require i.status = 'intake' or i.status = 'estimated' else BAD_STATUS 'Estimates are written at intake.'
  e = insert estimates { instrument, owner: i.owner, amount, notes, expiresAt: now + 14d, appraisal: 'needed' if i.appraisedValue = null else 'within' if amount <= i.appraisedValue else 'above' }
  update instruments[instrument] { status: 'estimated' }
  return e

-- The instrument owner's approval: only within 14 days, and never above the
-- appraised value (that path belongs to approveOverAppraisal).
mutation approveEstimate(estimate: estimates):
  e = estimates[estimate] ! else NOT_FOUND
  i = instruments[e.instrument] ! else NOT_FOUND
  require e.status = 'pending' or e.status = 'expired' else BAD_STATUS 'This estimate is already decided.'
  require e.expiresAt > now else EXPIRED 'This estimate expired after 14 days; the instrument is returned unrepaired.'
  require e.status = 'pending' else BAD_STATUS 'This estimate is already decided.'
  require e.amount <= i.appraisedValue else NEEDS_SHOP_OWNER 'Above appraised value: only the shop owner may approve, recording why.'
  require e.owner = viewer else NOT_OWNER 'Only the instrument owner approves this estimate.'
  update estimates[estimate] { status: 'approved', decidedAt: now }
  update instruments[e.instrument] { status: 'approved' }
  return null

-- The shop owner's over-appraisal approval, with the recorded reason.
mutation approveOverAppraisal(estimate: estimates, reason: text 1..500):
  require exists roles[viewer, role = 'shopOwner'] else NOT_SHOP_OWNER 'Only the shop owner approves above appraised value.'
  e = estimates[estimate] ! else NOT_FOUND
  i = instruments[e.instrument] ! else NOT_FOUND
  require e.status = 'pending' or e.status = 'expired' else BAD_STATUS 'This estimate is already decided.'
  require e.expiresAt > now else EXPIRED 'This estimate expired after 14 days.'
  require e.status = 'pending' else BAD_STATUS 'This estimate is already decided.'
  require e.amount > i.appraisedValue else NOT_OVER_APPRAISAL 'At or below appraised value: the instrument owner approves.'
  update estimates[estimate] { status: 'approved', decidedAt: now, overReason: reason, overApprovedBy: viewer }
  update instruments[e.instrument] { status: 'approved' }
  return null

-- Only the shop owner may change the appraisal comparison after an estimate
-- is written; luthiers and instrument owners cannot.
mutation setAppraisal(estimate: estimates, appraisal: enum('within', 'above', 'needed')):
  require exists roles[viewer, role = 'shopOwner'] else NOT_SHOP_OWNER 'Only the shop owner changes the appraisal comparison.'
  e = estimates[estimate] ! else NOT_FOUND
  update estimates[estimate] { appraisal }
  return estimates[estimate]

-- The instrument owner declines the repair; the instrument goes back.
mutation declineEstimate(estimate: estimates):
  e = estimates[estimate] ! else NOT_FOUND
  require e.status = 'pending' else BAD_STATUS 'This estimate is already decided.'
  require e.owner = viewer else NOT_OWNER 'Only the instrument owner declines this estimate.'
  update estimates[estimate] { status: 'declined', decidedAt: now }
  update instruments[e.instrument] { status: 'returned' }
  return null

-- Bench flow: approved -> gluing -> setup -> finalCheck -> ready.
-- Only working staff move the bench; apprentices watch the board.
mutation beginRepair(instrument: instruments):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF 'Only working staff move the bench.'
  i = instruments[instrument] ! else NOT_FOUND
  require i.status = 'approved' else BAD_STATUS 'Repair starts from an approved estimate.'
  update instruments[instrument] { status: 'gluing' }
  return null

mutation advanceBench(instrument: instruments):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF 'Only working staff move the bench.'
  i = instruments[instrument] ! else NOT_FOUND
  require i.status = 'gluing' or i.status = 'setup' else BAD_STATUS 'The bench moves gluing -> setup -> final check.'
  update instruments[instrument] { status: 'setup' if i.status = 'gluing' else 'finalCheck' }
  return null

mutation markReady(instrument: instruments):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF 'Only working staff move the bench.'
  i = instruments[instrument] ! else NOT_FOUND
  require i.status = 'finalCheck' else BAD_STATUS 'Only a final-checked instrument is marked ready.'
  update instruments[instrument] { status: 'ready', readyAt: now }
  return null

-- Collecting a finished instrument. Past 45 days after the ready notice the
-- $5/day storage charge starts; it is recorded on the instrument.
mutation collectInstrument(instrument: instruments):
  i = instruments[instrument] ! else NOT_FOUND
  require i.status = 'ready' else BAD_STATUS 'Only a ready instrument is collected.'
  require i.owner = viewer or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_ALLOWED 'Only the owner collects, or staff hand it over.'
  require i.readyAt != null else NOT_READY 'This instrument has no ready notice yet.'
  overdue = (now - i.readyAt) / 1d - 45
  fee = overdue * 500 if overdue > 0 else 0
  update instruments[instrument] { status: 'collected', collectedAt: now, storageCents: fee }
  return { fee }

-- A customer's own bench.
query myInstruments(c: cursor ?):
  return instruments where .owner = viewer last 50 by .at after c

-- The live bench board: staff only (apprentices watch, luthiers work).
query benchBoard(c: cursor ?):
  require exists roles[viewer, role = 'apprentice'] or exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF 'The bench board is staff only.'
  return instruments where .status = 'gluing' or .status = 'setup' or .status = 'finalCheck' last 50 by .at after c

-- Everything on the books: working staff only.
query allInstruments(c: cursor ?):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF 'Working staff only.'
  return instruments where .status != 'collected' last 50 by .at after c

query instrumentDetail(inst: instruments):
  return instruments[inst]

-- Estimates for one instrument; the instrument lookup keeps owners to their own.
query estimatesFor(instrument: instruments, c: cursor ?):
  i = instruments[instrument] ! else NOT_FOUND
  return estimates where .instrument = instrument last 20 by .createdAt after c

query pendingEstimates(c: cursor ?):
  require exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'shopOwner'] else NOT_STAFF 'Working staff only.'
  return estimates where .status = 'pending' last 50 by .createdAt after c

-- Nightly: expire stale pending estimates and return their instruments.
job expireEstimates(periodStart: time, periodEnd: time):
  for e in estimates where .createdAt >= periodEnd - 30d and .createdAt < periodEnd by .createdAt:
    if e.status = 'pending' and e.expiresAt <= periodEnd:
      update estimates[e.id] { status: 'expired', decidedAt: periodEnd }
      i = instruments[e.instrument]
      if i != null and i.status = 'estimated':
        update instruments[e.instrument] { status: 'returned' }

schedule nightly every 1d at 03:00: expireEstimates
