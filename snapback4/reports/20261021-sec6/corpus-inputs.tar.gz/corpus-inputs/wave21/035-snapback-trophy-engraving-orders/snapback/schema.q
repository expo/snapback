use identity password
use server

-- Roles are granted only by the local shop operator, never by a signup form.
table roles:
  principal: principal
  role: enum('customer', 'engraver', 'owner')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('customer', 'engraver', 'owner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

fn staff():
  return exists roles[viewer, role = 'engraver'] or exists roles[viewer, role = 'owner']

query myRole():
  r = roles[viewer]
  return r.role if r != null else 'customer'

table orders:
  customer: principal
  title: text 1..100
  quantity: int 1..500
  engravingQuantity: int 0.. default 0
  engravingCounted: bool default false
  eventAt: time
  logo: file <=2000000 ('image/png', 'image/jpeg', 'application/pdf')
  names: file <=262144 ('text/plain', 'text/csv')
  createdAt: time default now
  stage: enum('submitted', 'proof-sent', 'expired', 'queued', 'engraving', 'complete') default 'submitted'
  proofDeadline: time default 0
  approvedAt: time ?
  approvedBy: principal ?
  queueAt: time ?
  rushFee: money USD default 0
  freeReengrave: bool default false
  immutable customer, title, quantity, eventAt, logo, createdAt
  read <- .customer = viewer or exists roles[viewer, role = 'engraver'] or exists roles[viewer, role = 'owner']
  insert <- .customer = viewer
  update <- .customer = viewer or exists roles[viewer, role = 'engraver'] or exists roles[viewer, role = 'owner']
  online only

table proofs:
  order: orders
  document: file <=2000000 ('application/pdf', 'image/png', 'image/jpeg')
  note: text 1..2000
  sentAt: time
  sentBy: principal
  unique order
  immutable order
  read through .order
  insert <- exists roles[viewer, role = 'engraver'] or exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'engraver'] or exists roles[viewer, role = 'owner']
  online only

table reengraves:
  order: orders
  requestedBy: principal
  correction: text 1..1000
  requestedAt: time default now
  state: enum('pending', 'approved', 'declined') default 'pending'
  mistakeBy: enum('customer', 'shop') ?
  decidedBy: principal ?
  decidedAt: time ?
  decisionNote: text <=1000 ?
  unique order else REENGRAVE_ALREADY_REQUESTED
  immutable order, requestedBy, correction, requestedAt
  read through .order
  insert <- .requestedBy = viewer and exists orders[.order, customer = viewer]
  update <- exists roles[viewer, role = 'owner']
  online only

query myOrders(c: cursor ?):
  return orders where .customer = viewer last 100 by .createdAt after c

query productionBoard(c: cursor ?):
  require staff() else NOT_STAFF
  return orders where .stage != 'complete' and .stage != 'expired' and (.stage != 'proof-sent' or .proofDeadline > now) first 100 by .queueAt after c

query shopHistory(c: cursor ?):
  require staff() else NOT_STAFF
  return orders where .stage = 'complete' or .stage = 'expired' or (.stage = 'proof-sent' and .proofDeadline <= now) last 100 by .createdAt after c

query orderDetails(order: orders):
  return orders[order] ! else NOT_FOUND

query proofFor(order: orders):
  o = orders[order] ! else NOT_FOUND
  return proofs[order = o.id]

query reengraveFor(order: orders):
  o = orders[order] ! else NOT_FOUND
  return reengraves[order = o.id]

mutation createOrder(title: text 1..100, quantity: int 1..500, eventAt: time, logo: file <=2000000 ('image/png', 'image/jpeg', 'application/pdf'), names: file <=262144 ('text/plain', 'text/csv')):
  require not staff() else CUSTOMER_ONLY
  require eventAt > now else EVENT_IN_PAST
  require eventAt <= now + 730d else EVENT_TOO_FAR
  counted = nameCounts[asset = names.id, principal = viewer] ! else NAMES_NOT_COUNTED 'Prepare the names file before submitting the order.'
  return insert orders { customer: viewer, title, quantity, eventAt, logo, names, engravingQuantity: counted.entries, engravingCounted: true, queueAt: now }

mutation sendProof(order: orders, document: file <=2000000 ('application/pdf', 'image/png', 'image/jpeg'), note: text 1..2000):
  require staff() else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.stage = 'submitted' or o.stage = 'expired' or (o.stage = 'proof-sent' and o.proofDeadline <= now) else PROOF_ALREADY_SENT
  upsert proofs[order = order] { order, document, note, sentAt: now, sentBy: viewer }
  update orders[order] { stage: 'proof-sent', proofDeadline: now + 5d, queueAt: o.queueAt if o.stage = 'submitted' else now }

mutation approveProof(order: orders):
  o = orders[order] ! else NOT_FOUND
  require o.customer = viewer else NOT_CUSTOMER
  require o.stage = 'proof-sent' else PROOF_NOT_PENDING
  require now < o.proofDeadline else PROOF_EXPIRED 'The five-day approval window has closed. Ask the shop for a new proof.'
  fee = 2500 if o.eventAt < now + 10d else 0
  update orders[order] { stage: 'queued', approvedAt: now, approvedBy: viewer, rushFee: fee }

mutation startEngraving(order: orders):
  require staff() else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.stage = 'queued' else NOT_QUEUED
  update orders[order] { stage: 'engraving' }

mutation finishOrder(order: orders):
  require staff() else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.stage = 'engraving' else NOT_ENGRAVING
  update orders[order] { stage: 'complete' }

mutation requestReengrave(order: orders, correction: text 1..1000):
  o = orders[order] ! else NOT_FOUND
  require o.customer = viewer else NOT_CUSTOMER
  require o.stage = 'complete' else NOT_COMPLETE
  return insert reengraves { order, requestedBy: viewer, correction }

mutation decideReengrave(request: reengraves, approve: bool, mistakeBy: enum('customer', 'shop'), note: text 1..1000):
  require exists roles[viewer, role = 'owner'] else OWNER_ONLY
  r = reengraves[request] ! else NOT_FOUND
  require r.state = 'pending' else ALREADY_DECIDED
  o = orders[r.order] ! else NOT_FOUND
  require o.stage = 'complete' else NOT_COMPLETE
  update reengraves[request] { state: 'approved' if approve else 'declined', mistakeBy, decidedBy: viewer, decidedAt: now, decisionNote: note }
  if approve:
    update orders[r.order] { stage: 'queued', queueAt: now, freeReengrave: true }

-- Catch up every overdue proof, including deadlines missed during downtime.
job expireProofs(periodStart: time, periodEnd: time):
  for o in orders:
    if o.stage = 'proof-sent' and o.proofDeadline <= periodEnd:
      update orders[o.id] { stage: 'expired', queueAt: null }

schedule proofExpiry every 1m: expireProofs

-- The worker derives these receipts from authorized file bytes, never client counts.
table nameCounts:
  asset: id
  principal: principal
  entries: int 0..
  unique asset, principal
  read <- .principal = viewer or viewer = 'service:worker'
  insert <- viewer = 'service:worker'
  update <- viewer = 'service:worker'
  online only

mutation recordNameCount(asset: id, principal: principal, entries: int 0..):
  require viewer = 'service:worker' else WORKER_ONLY
  return upsert nameCounts[asset, principal] { asset, principal, entries }

action prepareNames(asset: id) returns { entries: int 0.. } retry 1 deadline 1m

mutation reviseEngravingQuantity(order: orders, names: file <=262144 ('text/plain', 'text/csv')):
  require exists roles[viewer, role = 'owner'] else OWNER_ONLY
  o = orders[order] ! else NOT_FOUND
  counted = nameCounts[asset = names.id, principal = viewer] ! else NAMES_NOT_COUNTED
  update orders[order] { names, engravingQuantity: counted.entries, engravingCounted: true }
