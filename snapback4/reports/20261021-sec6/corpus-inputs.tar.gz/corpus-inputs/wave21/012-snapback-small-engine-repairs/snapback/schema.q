-- Small Engine Repairs: mowers, chainsaws, generators.
-- Roles: customer (machine owner), clerk (intake counter), mechanic, shop_owner.
-- Real password identity; operator provisions roles. Personas exist for local dev/test only.

use identity password
use personas clerk1, clerk2, mech1, mech2, shop1, shop2, cust1, cust2

table roles:
  principal: principal
  role: enum('customer', 'clerk', 'mechanic', 'shop_owner')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

table machines:
  owner: principal
  machineType: enum('mower', 'chainsaw', 'generator')
  photo: image <=5000000 ?
  reportedSymptoms: text 1..500 renamed from complaint
  status: enum('intake', 'quote_pending', 'quote_approved', 'ready', 'picked_up', 'returned_unrepaired', 'sold') default 'intake'
  clerk: principal ?
  mechanic: principal ?
  diagnosis: text 1..1000 ?
  quoteAmount: money USD ?
  quoteExpiresAt: time ?
  approvedAt: time ?
  readyAt: time ?
  pickedUpAt: time ?
  warrantyRequested: bool default false
  warrantyApproved: bool default false
  warrantyReason: text 1..500 ?
  feeWaived: bool default false
  feeWaiveReason: text 1..500 ?
  createdAt: time default now
  immutable owner
  cap 500 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner']
  insert <- exists roles[viewer, role = 'clerk']
  update <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner']
  online only

table parts:
  machine: machines
  name: text 1..100
  status: enum('ordered', 'arrived', 'installed') default 'ordered'
  orderedBy: principal
  orderedAt: time default now
  immutable machine, orderedBy
  cap 50 by machine
  read <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] or exists machines[.machine, owner = viewer]
  insert <- exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner']
  update <- exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner']
  online only

query myRole():
  return roles[viewer]

query customersList(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] else NOT_STAFF
  return roles where .role = 'customer' first 50 by .principal after c { principal }

query myMachines(c: cursor ?):
  return machines where .owner = viewer last 50 by .id after c

query machineDetail(machine: machines):
  return machines[machine]

query repairBoard(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] else NOT_STAFF
  return machines last 50 by .id after c

query partsOnOrder(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] else NOT_STAFF
  return parts where .status = 'ordered' first 50 by .id after c

query partsFor(machine: machines, c: cursor ?):
  return parts where .machine = machine first 50 by .id after c

mutation provision(principal: principal, role: enum('customer', 'clerk', 'mechanic', 'shop_owner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation tagMachine(owner: principal, machineType: enum('mower', 'chainsaw', 'generator'), photo: image <=5000000, reportedSymptoms: text 1..500 alias complaint):
  require exists roles[viewer, role = 'clerk'] else NOT_CLERK
  return insert machines { owner, machineType, photo, reportedSymptoms, clerk: viewer }

mutation reviseSymptoms(machine: machines, reportedSymptoms: text 1..500):
  require exists roles[viewer, role = 'clerk'] else NOT_CLERK
  m = machines[machine] ! else NOT_FOUND
  update machines[machine] { reportedSymptoms }
  return null

mutation postDiagnosis(machine: machines, diagnosis: text 1..1000, quoteAmount: money USD):
  require exists roles[viewer, role = 'mechanic'] else NOT_MECHANIC
  m = machines[machine] ! else NOT_FOUND
  require m.status = 'intake' else BAD_STATUS
  update machines[machine] { diagnosis, quoteAmount, quoteExpiresAt: now + 10d, status: 'quote_pending', mechanic: viewer }
  return null

mutation approveQuote(machine: machines):
  m = machines[machine] ! else NOT_FOUND
  require m.owner = viewer else NOT_OWNER
  require m.status = 'quote_pending' else BAD_STATUS
  require m.quoteExpiresAt != null else BAD_STATUS
  require now <= m.quoteExpiresAt else QUOTE_EXPIRED
  update machines[machine] { status: 'quote_approved', approvedAt: now }
  return null

mutation requestWarranty(machine: machines):
  require exists roles[viewer, role = 'mechanic'] else NOT_MECHANIC
  m = machines[machine] ! else NOT_FOUND
  require m.status = 'quote_pending' else BAD_STATUS
  update machines[machine] { warrantyRequested: true }
  return null

mutation approveWarranty(machine: machines, reason: text 1..500):
  require exists roles[viewer, role = 'shop_owner'] else NOT_SHOP_OWNER
  m = machines[machine] ! else NOT_FOUND
  require m.warrantyRequested else NOT_REQUESTED
  update machines[machine] { warrantyApproved: true, warrantyReason: reason, status: 'quote_approved', approvedAt: now }
  return null

mutation waiveFee(machine: machines, reason: text 1..500):
  require exists roles[viewer, role = 'shop_owner'] else NOT_SHOP_OWNER
  m = machines[machine] ! else NOT_FOUND
  update machines[machine] { feeWaived: true, feeWaiveReason: reason }
  return null

mutation markReady(machine: machines):
  require exists roles[viewer, role = 'mechanic'] else NOT_MECHANIC
  m = machines[machine] ! else NOT_FOUND
  require m.status = 'quote_approved' else BAD_STATUS
  update machines[machine] { status: 'ready', readyAt: now }
  return null

mutation markPickedUp(machine: machines):
  require exists roles[viewer, role = 'clerk'] else NOT_CLERK
  m = machines[machine] ! else NOT_FOUND
  require m.status = 'ready' else BAD_STATUS
  require m.readyAt != null else BAD_STATUS
  require now <= m.readyAt + 60d else UNCLAIMED
  update machines[machine] { status: 'picked_up', pickedUpAt: now }
  return null

mutation orderPart(machine: machines, name: text 1..100):
  require exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] else NOT_MECHANIC
  m = machines[machine] ! else NOT_FOUND
  return insert parts { machine, name, orderedBy: viewer }

mutation markPartArrived(part: parts):
  require exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] else NOT_MECHANIC
  p = parts[part] ! else NOT_FOUND
  require p.status = 'ordered' else BAD_STATUS
  update parts[part] { status: 'arrived' }
  return null

mutation installPart(part: parts):
  require exists roles[viewer, role = 'mechanic'] or exists roles[viewer, role = 'shop_owner'] else NOT_MECHANIC
  p = parts[part] ! else NOT_FOUND
  require p.status = 'arrived' else BAD_STATUS
  update parts[part] { status: 'installed' }
  return null

job expireQuotes(periodStart: time, periodEnd: time):
  for m in machines:
    if m.status = 'quote_pending' and m.quoteExpiresAt != null and m.quoteExpiresAt <= periodEnd:
      update machines[m.id] { status: 'returned_unrepaired' }

job sellUnclaimed(periodStart: time, periodEnd: time):
  for m in machines:
    if m.status = 'ready' and m.readyAt != null and m.readyAt + 60d <= periodEnd:
      update machines[m.id] { status: 'sold' }

schedule expireCheck every 1d: expireQuotes
schedule sellCheck every 1d: sellUnclaimed
