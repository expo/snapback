-- Auto Body Repairs.
-- Roles: owner, estimator, technician, customer. Real password accounts only
-- (no personas, so no development identity switch exists).
use identity password

-- Roster: one row per user. Customers self-register via claimCustomer;
-- staff roles are granted by the shop owner (or the local operator for bootstrap).
table appRoles:
  principal: principal
  role: enum('owner', 'estimator', 'technician', 'customer')
  unique principal
  immutable principal
  read <- .principal = viewer or exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  insert <- (.principal = viewer and .role = 'customer') or viewer = 'service:operator' or exists appRoles[viewer, role = 'owner']
  update <- viewer = 'service:operator' or exists appRoles[viewer, role = 'owner']
  delete <- viewer = 'service:operator' or exists appRoles[viewer, role = 'owner']
  cap 100
  online only

-- v2: the 'detailing' stage is renamed to 'final preparation' (status + step stage).
-- The column domains retain the retired 'detailing' variant so rollback never
-- strands a row: no operation displays, writes or transitions through it, and the
-- day-two migration moves every existing row via the app's own operations.
-- Only the shop owner may move an order into or out of final preparation.
-- A repair order. Technicians read the vehicle, photos, parts and steps, but the
-- four sensitive columns are additionally gated to estimator/owner via column
-- read rules (row audience AND column rule). Customers read only their own rows.
table repairOrders:
  customer: principal
  vehicle: text 1..120
  phone: text 3..30 ?
  read (phone) <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  claimNumber: text 1..60 ?
  read (claimNumber) <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  laborRate: int 1..500 ?
  read (laborRate) <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  partsMarkup: int 0..200 ?
  read (partsMarkup) <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  damagePhotos: [image <=5000000] <=8 ?
  status: enum('intake', 'body', 'paint', 'detailing', 'final preparation', 'completed', 'picked-up') default 'intake'
  completedAt: time ?
  pickedUpAt: time ?
  storageCents: int default 0
  createdAt: time default now
  immutable customer
  read <- .customer = viewer or exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
  insert <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  update <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
  cap 500 by customer
  online only

table parts:
  order: repairOrders
  name: text 1..80
  qty: int 1..100
  unitCents: int 0..
  immutable order
  read <- exists repairOrders[.order, customer = viewer] or exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
  insert <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  update <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  cap 100 by order
  online only

table repairSteps:
  order: repairOrders
  title: text 1..120
  stage: enum('body', 'paint', 'detailing', 'final preparation')
  position: int 0..
  done: bool default false
  immutable order
  read <- exists repairOrders[.order, customer = viewer] or exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
  insert <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  update <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
  cap 100 by order
  online only

-- Extra work found after the estimate. Anyone on staff reads them; only the
-- shop owner may approve or reject.
table supplements:
  order: repairOrders
  description: text 1..300
  amountCents: int 1..
  status: enum('requested', 'approved', 'rejected') default 'requested'
  requestedBy: principal
  decidedAt: time ?
  immutable order, requestedBy
  read <- exists repairOrders[.order, customer = viewer] or exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
  insert <- exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
  update <- exists appRoles[viewer, role = 'owner']
  cap 50 by order
  online only

-- Privacy intent from the spec, stated independently of the rules.
invariant repairOrders.read only .customer = viewer or exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician']
invariant repairOrders.phone read only exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
invariant repairOrders.claimNumber read only exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
invariant repairOrders.laborRate read only exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
invariant repairOrders.partsMarkup read only exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
invariant repairOrders.insert only exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator']
invariant supplements.update only exists appRoles[viewer, role = 'owner']

query myRole():
  return appRoles[viewer]

query customers(c: cursor ?):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] else NOT_STAFF
  return appRoles where .role = 'customer' first 100 by .id after c

query roster(c: cursor ?):
  require exists appRoles[viewer, role = 'owner'] else NOT_OWNER
  return appRoles last 100 by .id after c

query myOrders(c: cursor ?):
  return repairOrders where .customer = viewer last 50 by .createdAt after c

query staffBoard(c: cursor ?):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician'] else NOT_STAFF
  return repairOrders last 50 by .createdAt after c

query orderCard(order: repairOrders):
  return repairOrders[order]

query orderParts(order: repairOrders, c: cursor ?):
  return parts where .order = order first 100 by .id after c

query orderSteps(order: repairOrders, c: cursor ?):
  return repairSteps where .order = order first 100 by .position after c

query orderSupplements(order: repairOrders, c: cursor ?):
  return supplements where .order = order first 50 by .id after c

-- Live progress for the customer screen: the order plus the server clock, so
-- the UI can show the storage grace countdown without another round trip.
query orderStatus(order: repairOrders):
  o = repairOrders[order] ! else NOT_FOUND
  return { order: o, now }

-- Local operator (staging/probe setup) or the shop owner grants roles.
mutation provision(principal: principal, role: enum('owner', 'estimator', 'technician', 'customer')):
  require viewer = 'service:operator' or exists appRoles[viewer, role = 'owner'] else NOT_OPERATOR
  return upsert appRoles[principal] { principal, role }

-- Self-service: a fresh signup registers as a customer.
mutation claimCustomer():
  require not exists appRoles[viewer] else HAS_ROLE
  return insert appRoles { principal: viewer, role: 'customer' }

mutation createOrder(customer: principal, vehicle: text 1..120, phone: text 3..30 ?, claimNumber: text 1..60 ?, laborRate: int 1..500 ?, partsMarkup: int 0..200 ?, damagePhotos: [image <=5000000] <=8 ?):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] else NOT_ESTIMATOR
  return insert repairOrders { customer, vehicle, phone, claimNumber, laborRate, partsMarkup, damagePhotos }

mutation addPart(order: repairOrders, name: text 1..80, qty: int 1..100, unitCents: int 0..):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] else NOT_ESTIMATOR
  o = repairOrders[order] ! else NOT_FOUND
  require o.status != 'picked-up' else CLOSED
  return insert parts { order, name, qty, unitCents }

mutation addStep(order: repairOrders, title: text 1..120, stage: enum('body', 'paint', 'detailing', 'final preparation'), position: int 0..):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] else NOT_ESTIMATOR
  o = repairOrders[order] ! else NOT_FOUND
  require o.status != 'picked-up' else CLOSED
  require stage != 'detailing' else RETIRED
  return insert repairSteps { order, title, stage, position }

mutation setStepDone(step: repairSteps, done: bool):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician'] else NOT_STAFF
  s = repairSteps[step] ! else NOT_FOUND
  update repairSteps[step] { done }
  return null

-- Forward-only progress: intake -> body -> paint -> final preparation -> completed -> picked-up.
-- ('detailing' is retired: no transition enters or advances through it; the owner-only
-- detailing -> final preparation clause rescues pre-migration stragglers.)
-- Completing stamps completedAt; pickup stamps pickedUpAt and finalizes any
-- storage fee when the 3-day grace period has passed.
mutation advanceStatus(order: repairOrders, status: enum('body', 'paint', 'detailing', 'final preparation', 'completed', 'picked-up')):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] or exists appRoles[viewer, role = 'technician'] else NOT_STAFF
  o = repairOrders[order] ! else NOT_FOUND
  require status != 'final preparation' and o.status != 'final preparation' or exists appRoles[viewer, role = 'owner'] else NOT_OWNER
  require o.status != 'picked-up' and status != o.status else CLOSED
  require (o.status = 'intake' and status = 'body') or (o.status = 'body' and status = 'paint') or (o.status = 'paint' and status = 'final preparation') or (o.status = 'detailing' and status = 'final preparation') or (o.status = 'final preparation' and status = 'completed') or (o.status = 'completed' and status = 'picked-up') else BAD_TRANSITION
  if status = 'completed':
    update repairOrders[order] { status, completedAt: now }
    return null
  if status = 'picked-up':
    overdue = (now - (o.completedAt ?? now)) / 1d - 3
    total = overdue * 3000 if overdue > 0 else 0
    update repairOrders[order] { status, pickedUpAt: now, storageCents: total if total > o.storageCents else o.storageCents }
    return null
  update repairOrders[order] { status }
  return null

mutation requestSupplement(order: repairOrders, description: text 1..300, amountCents: int 1..):
  require exists appRoles[viewer, role = 'owner'] or exists appRoles[viewer, role = 'estimator'] else NOT_ESTIMATOR
  o = repairOrders[order] ! else NOT_FOUND
  require o.status != 'picked-up' else CLOSED
  return insert supplements { order, description, amountCents, requestedBy: viewer }

mutation decideSupplement(supplement: supplements, approve: bool):
  require exists appRoles[viewer, role = 'owner'] else NOT_OWNER
  s = supplements[supplement] ! else NOT_FOUND
  require s.status = 'requested' else DECIDED
  update supplements[supplement] { status: 'approved' if approve else 'rejected', decidedAt: now }
  return null

-- Daily sweep: a finished vehicle still on the lot past the 3-day grace
-- accrues $30/day. Runs as the system; pickup finalizes the same fee.
job assessStorage(periodStart: time, periodEnd: time):
  for o in repairOrders:
    if o.status = 'completed' and o.completedAt != null and o.completedAt < periodEnd - 3d:
      days = (periodEnd - o.completedAt) / 1d - 3
      if days > 0:
        update repairOrders[o.id] { storageCents: days * 3000 }

schedule dailyStorage every 1d at 08:00: assessStorage

-- v2 migration: repair-step stages mentioning 'detailing' use the new name.
backfill repairSteps migrateStage(stage: enum('body', 'paint', 'detailing')):
  {stage: 'final preparation' if stage = 'detailing' else stage}
-- v1 truthful views: final-preparation values read as 'detailing'; forward restores them.
down repairOrders oldStatus(status: enum('intake', 'body', 'paint', 'detailing', 'final preparation', 'completed', 'picked-up')):
  {status: 'detailing' if status = 'final preparation' else status}
down repairSteps oldStage(stage: enum('body', 'paint', 'detailing', 'final preparation')):
  {stage: 'detailing' if stage = 'final preparation' else stage}
