-- E Waste Data Wipes: electronics recycler chain of custody.
-- Roles: clerk (receiving), technician (wipe/shred), client (business),
-- driver (pickup route), compliance (certificates + lost).
-- Password accounts; first roles come from the service operator (see scripts).
use identity password

table roles:
  principal: principal
  role: enum('clerk', 'technician', 'client', 'driver', 'compliance')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'compliance']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

table pickups:
  client: principal
  driver: principal ?
  route: text 1..80
  createdBy: principal
  createdAt: time default now
  immutable client, createdBy, createdAt
  read <- .client = viewer or .driver = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
  insert <- exists roles[principal = viewer, role = 'clerk']
  update <- exists roles[principal = viewer, role = 'clerk']
  online only

table devices:
  pickup: pickups
  client: principal
  serial: text 1..64
  serialEnding: text 1..4
  photo: image <=5000000
  shredPhoto: image <=5000000 ?
  status: enum('received', 'wiped', 'shredded', 'lost') default 'received'
  arrivedAt: time default now
  lostReason: text 1..500 ?
  unique serial
  immutable pickup, client, serial, photo, arrivedAt
  read <- .client = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
  insert <- exists roles[principal = viewer, role = 'clerk']
  update <- exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
  online only
backfill devices endings(serial: text 1..64):
  {serialEnding: slice(slice(serial, count(serial) - 4, count(serial)) if count(serial) >= 4 else serial, 0, 4)}

table certificates:
  pickup: pickups
  client: principal
  issuedBy: principal
  issuedAt: time default now
  note: text 1..500 ?
  unique pickup
  immutable pickup, client, issuedBy, issuedAt
  read <- .client = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
  insert <- exists roles[principal = viewer, role = 'compliance']
  update <- deny
  delete <- deny
  online only

query myRole():
  return roles[viewer]

query pickupsBoard(c: cursor ?):
  if exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']:
    return pickups last 50 by .id after c
  return pickups where .client = viewer or .driver = viewer last 50 by .id after c

query pickupDevices(pickup: pickups, c: cursor ?):
  return devices where .pickup = pickup last 50 by .id after c

query wipeQueue(c: cursor ?):
  require exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'compliance'] else NOT_STAFF
  return devices where .status = 'received' last 50 by .arrivedAt after c

query myCertificates(c: cursor ?):
  if exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']:
    return certificates last 50 by .id after c
  return certificates where .client = viewer last 50 by .id after c

mutation provision(principal: principal, role: enum('clerk', 'technician', 'client', 'driver', 'compliance')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation createPickup(client: principal, driver: principal ?, route: text 1..80):
  require exists roles[principal = viewer, role = 'clerk'] else NOT_CLERK
  return insert pickups { client, driver, route, createdBy: viewer }

mutation assignDriver(pickup: pickups, driver: principal ?):
  require exists roles[principal = viewer, role = 'clerk'] else NOT_CLERK
  p = pickups[pickup] ! else NOT_FOUND
  update pickups[pickup] { driver }
  return null

mutation logDevice(pickup: pickups, serial: text 1..64, serialEnding: text 1..4, photo: image <=5000000):
  require exists roles[principal = viewer, role = 'clerk'] else NOT_CLERK
  want = slice(serial, count(serial) - 4, count(serial)) if count(serial) >= 4 else serial
  require serialEnding = want else ENDING_MISMATCH 'The serial ending must be the last four characters of the serial number.'
  p = pickups[pickup] ! else NOT_FOUND
  return insert devices { pickup, client: p.client, serial, serialEnding, photo }

mutation markWiped(dev: devices):
  require exists roles[principal = viewer, role = 'technician'] else NOT_TECHNICIAN
  d = devices[dev] ! else NOT_FOUND
  require d.status = 'received' else BAD_STATUS
  require d.arrivedAt + 14d >= now else TOO_LATE
  update devices[dev] { status: 'wiped' }
  return null

mutation markShredded(dev: devices, shredPhoto: image <=5000000):
  require exists roles[principal = viewer, role = 'technician'] else NOT_TECHNICIAN
  d = devices[dev] ! else NOT_FOUND
  require d.status = 'received' or d.status = 'wiped' else BAD_STATUS
  require d.arrivedAt + 14d >= now else TOO_LATE
  update devices[dev] { status: 'shredded', shredPhoto }
  return null

mutation issueCertificate(pickup: pickups, note: text 1..500 ?):
  require exists roles[principal = viewer, role = 'compliance'] else NOT_COMPLIANCE
  p = pickups[pickup] ! else NOT_FOUND
  return insert certificates { pickup, client: p.client, issuedBy: viewer, note }

mutation correctSerialEnding(dev: devices, serialEnding: text 1..4):
  require exists roles[principal = viewer, role = 'compliance'] else NOT_COMPLIANCE
  d = devices[dev] ! else NOT_FOUND
  want = slice(d.serial, count(d.serial) - 4, count(d.serial)) if count(d.serial) >= 4 else d.serial
  require serialEnding = want else ENDING_MISMATCH 'The serial ending must be the last four characters of the serial number.'
  update devices[dev] { serialEnding }
  return null

mutation markLost(dev: devices, reason: text 1..200):
  require exists roles[principal = viewer, role = 'compliance'] else NOT_COMPLIANCE
  d = devices[dev] ! else NOT_FOUND
  require d.status != 'lost' else BAD_STATUS
  update devices[dev] { status: 'lost', lostReason: reason }
  return null

-- Spec privacy intent, stated independently from the rules above.
-- Clients see only their own pickups/devices/certificates; drivers see only
-- pickups assigned to them; staff audience is clerk/technician/compliance.
invariant pickups.read only .client = viewer or .driver = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
invariant devices.read only .client = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
invariant certificates.read only .client = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
invariant devices.photo read only .client = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
invariant devices.shredPhoto read only .client = viewer or exists roles[principal = viewer, role = 'clerk'] or exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
invariant pickups.insert only exists roles[principal = viewer, role = 'clerk']
invariant devices.insert only exists roles[principal = viewer, role = 'clerk']
invariant devices.update only exists roles[principal = viewer, role = 'technician'] or exists roles[principal = viewer, role = 'compliance']
invariant devices.correctSerialEnding only exists roles[principal = viewer, role = 'compliance']
invariant certificates.insert only exists roles[principal = viewer, role = 'compliance']
invariant roles.read only .principal = viewer or exists roles[principal = viewer, role = 'compliance']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
invariant pickups.update only exists roles[principal = viewer, role = 'clerk']
