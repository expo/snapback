-- Hop Kiln Lots: hop farm kiln logging, bale contracting, lab sampling.
-- Roles: crew (kiln board), buyer (contracted bales + lab results), manager (all + downgrade/reassign/sell).
use identity password

-- Roster: one row per user. Only the local operator may write it.
table roles:
  principal: principal
  role: enum('crew', 'buyer', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- deny
  online only

-- A kiln load: logged at picking with moisture + cone photos, moved into the
-- kiln within six hours of picking, dried, then baled.
-- readingCount is engine-maintained: every recorded moisture reading for the
-- load, zero when there are none. The engine rebuilds it on adoption (so
-- pre-existing loads migrate automatically) and keeps it in step as readings
-- are added or removed. Only kiln crew and the manager may see it.
table loads:
  variety: text 1..40
  weightKg: int 1..5000
  moisture: int 0..100
  photos: [image <=5000000] 1..4
  pickedAt: time default now
  pickedBy: principal
  kiln: text 1..40 ?
  kilnedAt: time ?
  driedAt: time ?
  stage: enum('picked', 'in-kiln', 'dried', 'baled') default 'picked'
  readingCount: count readings by .load
  read (readingCount) <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  immutable pickedAt, pickedBy
  read <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  delete <- deny
  online only

-- Moisture spot-readings on a load while it cures. Crew can remove a
-- mis-recorded reading; the load's engine-maintained readingCount follows.
table readings:
  load: loads
  pct: int 0..100
  at: time default now
  takenBy: principal
  immutable load, takenBy
  read <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  update <- deny
  delete <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  online only

-- A dried bale contracted to one brewery buyer.
table bales:
  load: loads
  buyer: principal
  weightKg: int 1..5000
  grade: enum('premium', 'standard', 'downgraded') default 'premium'
  baledAt: time default now
  sold: bool default false
  soldAt: time ?
  downgradeReason: text 1..200 ?
  reassignReason: text 1..200 ?
  breweryAgreement: bool default false
  immutable load, baledAt
  read <- .buyer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  delete <- deny
  online only

-- The lab sample for a bale: one sample, within three days of baling, before sale.
table samples:
  bale: bales
  moisture: int 0..100
  alphaPct: int 1..25
  notes: text <=500 ?
  sampler: principal
  sampledAt: time default now
  unique bale else ALREADY_SAMPLED 'This bale already has its lab sample.'
  immutable bale, sampler
  read <- exists bales[.bale, buyer = viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  update <- deny
  delete <- deny
  online only

query myRole():
  return roles[viewer]

query buyers(c: cursor ?):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  return roles where .role = 'buyer' first 50 by .id after c

query kilnBoard(c: cursor ?):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  return loads last 50 by .id after c

query loadReadings(load: loads, c: cursor ?):
  require exists loads[load] else NOT_FOUND
  return readings where .load = load last 50 by .id after c

query myBales(c: cursor ?):
  if exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']:
    return bales last 50 by .id after c
  return bales where .buyer = viewer last 50 by .id after c

query baleDetail(bale: bales):
  require exists bales[bale] else NOT_FOUND
  return bales[bale]

query baleSamples(bale: bales, c: cursor ?):
  require exists bales[bale] else NOT_FOUND
  return samples where .bale = bale last 20 by .id after c

mutation provision(principal: principal, role: enum('crew', 'buyer', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation logLoad(variety: text 1..40, weightKg: int 1..5000, moisture: int 0..100, photos: [image <=5000000] 1..4):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  return insert loads { variety, weightKg, moisture, photos, pickedBy: viewer }

mutation recordReading(load: loads, pct: int 0..100):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  l = loads[load] ! else NOT_FOUND
  return insert readings { load: l.id, takenBy: viewer, pct }

mutation removeReading(reading: readings):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  r = readings[reading] ! else NOT_FOUND
  delete readings[r]
  return null

mutation moveToKiln(load: loads, kiln: text 1..40):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  l = loads[load] ! else NOT_FOUND
  require l.stage = 'picked' else NOT_PICKED 'Only a freshly picked load can enter the kiln.'
  require now <= l.pickedAt + 6h else KILN_TOO_LATE 'The load missed its six-hour kiln window.'
  update loads[load] { kiln, kilnedAt: now, stage: 'in-kiln' }
  return null

mutation markDried(load: loads):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  l = loads[load] ! else NOT_FOUND
  require l.stage = 'in-kiln' else NOT_IN_KILN 'Only a load in the kiln can be marked dried.'
  update loads[load] { driedAt: now, stage: 'dried' }
  return null

mutation createBale(load: loads, weightKg: int 1..5000, buyer: principal):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  l = loads[load] ! else NOT_FOUND
  require l.stage = 'dried' else NOT_DRIED 'Only a dried load can be baled.'
  r = roles[principal = buyer] ! else NOT_A_BUYER 'The contracted party must hold the buyer role.'
  require r.role = 'buyer' else NOT_A_BUYER 'The contracted party must hold the buyer role.'
  b = insert bales { load: l.id, buyer, weightKg }
  update loads[load] { stage: 'baled' }
  return b

mutation takeSample(bale: bales, moisture: int 0..100, alphaPct: int 1..25, notes: text <=500 ?):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_CREW
  b = bales[bale] ! else NOT_FOUND
  require now <= b.baledAt + 3d else SAMPLE_TOO_LATE 'The bale missed its three-day sampling window.'
  return insert samples { bale: b.id, moisture, alphaPct, notes, sampler: viewer }

mutation sellBale(bale: bales):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  b = bales[bale] ! else NOT_FOUND
  require exists samples[bale = bale] else NOT_SAMPLED 'A bale needs its lab sample before it can be sold.'
  require not b.sold else ALREADY_SOLD 'This bale is already sold.'
  update bales[bale] { sold: true, soldAt: now }
  return null

mutation downgradeBale(bale: bales, reason: text 1..200, breweryAgreed: bool):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require breweryAgreed else NEED_BREWERY_AGREEMENT 'A downgrade needs the brewery buyer agreement recorded.'
  b = bales[bale] ! else NOT_FOUND
  update bales[bale] { grade: 'downgraded', downgradeReason: reason, breweryAgreement: true }
  return null

mutation reassignBale(bale: bales, newBuyer: principal, reason: text 1..200, breweryAgreed: bool):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require breweryAgreed else NEED_BREWERY_AGREEMENT 'A reassignment needs the brewery agreement recorded.'
  b = bales[bale] ! else NOT_FOUND
  require b.buyer != newBuyer else SAME_BUYER 'The bale is already contracted to this buyer.'
  r = roles[principal = newBuyer] ! else NOT_A_BUYER 'The new party must hold the buyer role.'
  require r.role = 'buyer' else NOT_A_BUYER 'The new party must hold the buyer role.'
  update bales[bale] { buyer: newBuyer, reassignReason: reason, breweryAgreement: true }
  return null

-- Privacy intent from the spec. Loads live on the kiln board for crew and the
-- manager only; bales and their lab results go to the contracted brewery plus
-- crew and the manager; downgrades, reassignments and sales are the manager's
-- alone, always with the brewery agreement on record.
invariant loads.read only exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant loads.readingCount read only exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant loads.insert only exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant loads.update only exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant bales.read only .buyer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant bales.insert only exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant bales.grade write only exists roles[viewer, role = 'manager']
invariant bales.buyer write only exists roles[viewer, role = 'manager']
invariant bales.sold write only exists roles[viewer, role = 'manager']
invariant samples.read only exists bales[.bale, buyer = viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
