-- Bounce House Rentals.
-- Roles: customer, crew (delivery), warehouse, owner. Roster is
-- operator-provisioned; signup alone grants no role.
use identity password

table roles:
  principal: principal
  role: enum('customer', 'crew', 'warehouse', 'owner')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'owner'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('customer', 'crew', 'warehouse', 'owner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[principal = viewer]

-- Inflatables (bounce houses and other units). Customers see only ready
-- units; crew, warehouse and the owner see the whole fleet.
table inflatables:
  name: text 1..80
  kind: text 1..80
  capacity: int 1..50
  status: enum('ready', 'needs_cleaning', 'retired')
  retireReason: text 1..500 ?
  retiredAt: time ?
  read <- .status != 'retired' or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'crew']
  delete <- deny
  online only

mutation addInflatable(name: text 1..80, kind: text 1..80, capacity: int 1..50):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return insert inflatables { name, kind, capacity, status: 'ready' }

mutation retireInflatable(inflatable: inflatables, reason: text 1..500):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  i = inflatables[inflatable] ! else NOT_FOUND
  require i.status != 'retired' else ALREADY_RETIRED
  update inflatables[inflatable] { status: 'retired', retireReason: reason, retiredAt: now }
  return null

-- Bookings. A hold is released 48h after placement unless the deposit is
-- paid (job releaseUnpaid below). A unit must be cleaned and inspected
-- after each rental before it can be booked again: createBooking admits
-- only ready units, and completeRental moves the unit to needs_cleaning.
table bookings:
  inflatable: inflatables on delete restrict
  customer: principal
  eventDate: time
  placedAt: time
  depositCents: int 0..10000000
  depositPaid: bool
  depositPaidAt: time ?
  status: enum('pending', 'confirmed', 'delivered', 'completed', 'released', 'cancelled', 'refunded')
  refundReason: text 1..500 ?
  immutable inflatable, customer, placedAt, depositCents
  unique inflatable, eventDate else DOUBLE_BOOKED 'This unit is already booked for that time.'
  read <- .customer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner']
  insert <- .customer = viewer
  update <- .customer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner']
  delete <- deny
  online only

mutation createBooking(inflatable: inflatables, eventDate: time, depositCents: int 0..10000000):
  require exists roles[viewer, role = 'customer'] else NOT_CUSTOMER
  require eventDate > now else BAD_DATE 'The event must be in the future.'
  i = inflatables[inflatable] ! else NOT_FOUND
  require i.status = 'ready' else NOT_READY 'This unit is not available for booking.'
  return insert bookings { inflatable, customer: viewer, eventDate, placedAt: now, depositCents, depositPaid: false, status: 'pending' }

mutation payDeposit(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.customer = viewer else NOT_BOOKING_OWNER
  require b.status = 'pending' else BAD_STATUS
  require b.placedAt + 48h >= now else HOLD_EXPIRED 'The 48-hour hold expired; the booking was released.'
  update bookings[booking] { depositPaid: true, depositPaidAt: now, status: 'confirmed' }
  return null

mutation cancelBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.customer = viewer else NOT_BOOKING_OWNER
  require b.status = 'pending' or b.status = 'confirmed' else BAD_STATUS
  update bookings[booking] { status: 'cancelled' }
  return null

mutation refundDeposit(booking: bookings, reason: text 1..500):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  b = bookings[booking] ! else NOT_FOUND
  require b.depositPaid = true else NO_DEPOSIT
  require b.status = 'confirmed' or b.status = 'delivered' else BAD_STATUS
  update bookings[booking] { depositPaid: false, status: 'refunded', refundReason: reason }
  return null

job releaseUnpaid():
  for b in bookings by .id:
    if b.status = 'pending' and b.depositPaid = false and b.placedAt + 48h < now:
      update bookings[b.id] { status: 'released' }

schedule releaseHourly every 1h: releaseUnpaid

-- Delivery setups: the crew photographs the setup with anchors in place
-- while the customer signs the safety sheet.
table setups:
  booking: bookings on delete restrict
  crew: principal
  customer: principal
  photo: image <=10000000
  anchorsPlaced: bool
  signedBy: text 1..120
  signedAt: time
  immutable booking, crew, customer
  unique booking
  read <- .customer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'crew']
  update <- deny
  delete <- deny
  online only

mutation recordSetup(booking: bookings, photo: image <=10000000, signedBy: text 1..120):
  require exists roles[viewer, role = 'crew'] else NOT_CREW
  b = bookings[booking] ! else NOT_FOUND
  require not exists setups[booking] else ALREADY_RECORDED
  require b.status = 'confirmed' else BAD_STATUS 'The deposit must be paid before delivery.'
  insert setups { booking, crew: viewer, customer: b.customer, photo, anchorsPlaced: true, signedBy, signedAt: now }
  update bookings[booking] { status: 'delivered' }
  return null

mutation completeRental(booking: bookings):
  require exists roles[viewer, role = 'crew'] else NOT_CREW
  b = bookings[booking] ! else NOT_FOUND
  require b.status = 'delivered' else BAD_STATUS
  update bookings[booking] { status: 'completed' }
  update inflatables[b.inflatable] { status: 'needs_cleaning' }
  return null

-- Cleanings: the warehouse cleans and inspects each unit after every
-- rental; only then is it bookable again.
table cleanings:
  inflatable: inflatables on delete restrict
  cleanedBy: principal
  inspected: bool
  notes: text <=500 ?
  at: time
  immutable inflatable, cleanedBy, at
  read <- exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'crew']
  insert <- exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner']
  update <- deny
  delete <- deny
  online only

mutation recordCleaning(inflatable: inflatables, notes: text <=500 ?):
  require exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner'] else NOT_WAREHOUSE
  i = inflatables[inflatable] ! else NOT_FOUND
  require i.status = 'needs_cleaning' else BAD_STATUS 'This unit does not need cleaning.'
  insert cleanings { inflatable, cleanedBy: viewer, inspected: true, notes, at: now }
  update inflatables[inflatable] { status: 'ready' }
  return null

-- Reads: customers see only their own bookings; crews see the live
-- delivery board; the warehouse sees which units are cleaned and ready.
query availableInflatables(c: cursor ?):
  return inflatables where .status = 'ready' first 50 by .id after c

query warehouseBoard(c: cursor ?):
  require exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner'] else NOT_WAREHOUSE
  return inflatables last 50 by .id after c

query deliveryBoard(c: cursor ?):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'owner'] else NOT_CREW
  return bookings where .status = 'confirmed' or .status = 'delivered' last 50 by .placedAt after c { id, inflatable, customer, eventDate, placedAt, status }

query myBookings(c: cursor ?):
  return bookings where .customer = viewer last 50 by .placedAt after c

query bookingDetail(booking: bookings):
  return bookings[booking]

query setupFor(booking: bookings):
  return setups[booking]

-- Setup evidence label: complete means the booking has at least one setup
-- photo and a signed safety sheet (exactly what a setups row holds: a
-- required photo plus the customer's signature), otherwise incomplete. The
-- label is derived live from the current materials, so existing bookings
-- are labelled by their current photos/signatures with those materials
-- untouched, new bookings begin incomplete, and the label follows later
-- setups. Visible only to the owner and the crew recorded on that
-- booking's setup — never to customers, warehouse, or other crews.
query setupEvidence(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require exists roles[viewer, role = 'owner'] or exists setups[booking, crew = viewer] else NOT_EVIDENCE_VIEWER
  return { evidence: 'complete' if exists setups[booking] else 'incomplete' }

query cleaningsFor(inflatable: inflatables, c: cursor ?):
  require exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'crew'] else NOT_STAFF
  return cleanings where .inflatable = inflatable last 50 by .at after c

-- Privacy intent from the spec, stated separately from enforcement.
invariant bookings.read only .customer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'owner']
invariant bookings.insert only .customer = viewer
invariant bookings.depositPaid write only .customer = viewer or exists roles[viewer, role = 'owner']
invariant setups.read only .customer = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'owner']
invariant setups.insert only exists roles[viewer, role = 'crew']
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'owner']
invariant roles.insert only viewer = 'service:operator'
invariant inflatables.status write only exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'warehouse'] or exists roles[viewer, role = 'crew']
