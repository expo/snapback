-- Archery Range Lanes.
-- Roles: member, walkin (walk-in shooter), officer (range officer),
-- coach, master (range master). Accounts are real password users; the
-- local operator provisions the first roles via `provision`.
use identity password

table roles:
  principal: principal
  role: enum('member', 'walkin', 'officer', 'coach', 'master')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

-- The numbered lanes of the range. Public timetable furniture.
table lanes:
  name: text 1..60
  active: bool default true
  unique name
  cap 40
  public 'lane numbers are public'
  insert <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  update <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'master']
  online only

-- Coach/student links, created by range staff.
table assignments:
  coach: principal
  student: principal
  unique coach, student
  immutable coach, student
  cap 100 by coach
  read <- .coach = viewer or .student = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  insert <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  online only

-- Range orientation per shooter, with the signed waiver. Valid 12 months.
table orientations:
  shooter: principal
  completedAt: time default now
  expiresAt: time
  waiver: image <=5000000
  unique shooter
  immutable shooter
  read <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  insert <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  update <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  online only

-- Lane bookings. A booking not checked in within 15 minutes after its
-- start is released by the releaser schedule below.
table bookings:
  lane: lanes on delete restrict
  shooter: principal
  startsAt: time
  endsAt: time
  checkedIn: bool default false
  released: bool default false
  immutable lane, shooter, startsAt
  unique lane, startsAt else DOUBLE_BOOKED 'That lane is already booked at this time.'
  cap 200 by shooter
  read <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  insert <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  update <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  delete <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  online only

-- Shooting records (v2 name for score cards). The table keeps its v1
-- name and columns so every existing row survives the rename bit-for-bit.
-- A shooter sees only their own; a coach sees their students'. Only the
-- shooter may write their own records.
table scores:
  shooter: principal
  at: time default now
  total: int 0..300
  notes: text <=280 ?
  immutable shooter
  cap 500 by shooter
  read <- .shooter = viewer or exists roles[viewer, role = 'master'] or exists assignments[coach = viewer, student = .shooter]
  insert <- .shooter = viewer
  update <- .shooter = viewer
  delete <- .shooter = viewer
  online only

-- Safety bans. Only the range master may ban or lift, recording the
-- reason and a photo of the incident.
table bans:
  shooter: principal
  reason: text 1..500
  photo: image <=5000000
  active: bool default true
  at: time default now
  unique shooter
  immutable shooter
  read <- .shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master']
  insert <- exists roles[viewer, role = 'master']
  update <- exists roles[viewer, role = 'master']
  online only

query myRole():
  return roles[viewer]

query lanesList(c: cursor ?):
  return lanes first 50 by .id after c

query myBookings(c: cursor ?):
  return bookings where .shooter = viewer last 50 by .startsAt after c

query laneBoard(c: cursor ?):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_OFFICER
  return bookings last 100 by .startsAt after c

query myShootingRecords(c: cursor ?):
  return scores where .shooter = viewer last 50 by .at after c

alias myScores = myShootingRecords

query studentShootingRecords(student: principal, c: cursor ?):
  require viewer = student or exists assignments[coach = viewer, student = student] or exists roles[viewer, role = 'master'] else NOT_COACH
  return scores where .shooter = student last 50 by .at after c

alias studentScores = studentShootingRecords

query myOrientation():
  return orientations[viewer]

query orientationOf(shooter: principal):
  require viewer = shooter or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_ALLOWED
  return orientations[shooter]

query myStudents(c: cursor ?):
  return assignments where .coach = viewer first 50 by .id after c

query activeBans(c: cursor ?):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_STAFF
  return bans where .active = true last 50 by .at after c

mutation provision(principal: principal, role: enum('member', 'walkin', 'officer', 'coach', 'master')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation addLane(name: text 1..60):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_STAFF
  return insert lanes { name, active: true }

mutation recordOrientation(waiver: image <=5000000):
  b = bans[viewer]
  require b = null or not b.active else BANNED 'This shooter is banned.'
  return upsert orientations[viewer] { completedAt: now, expiresAt: now + 365d, waiver }

mutation recordOrientationFor(shooter: principal, waiver: image <=5000000):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_STAFF
  return upsert orientations[shooter] { completedAt: now, expiresAt: now + 365d, waiver }

mutation bookLane(lane: lanes, startsAt: time, endsAt: time):
  l = lanes[lane] ! else NOT_FOUND
  require l.active else LANE_CLOSED 'That lane is not bookable.'
  b = bans[viewer]
  require b = null or not b.active else BANNED 'This shooter is banned.'
  o = orientations[viewer]
  require o != null and o.expiresAt >= now else NO_ORIENTATION 'A valid range orientation is required.'
  require startsAt >= now - 1h else IN_THE_PAST 'Bookings start at most an hour ago.'
  require endsAt > startsAt and endsAt <= startsAt + 8h else BAD_RANGE 'A booking is at most 8 hours.'
  return insert bookings { lane, shooter: viewer, startsAt, endsAt }

mutation checkIn(booking: bookings):
  t = bookings[booking] ! else NOT_FOUND
  require t.shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_OWNER 'Only the shooter or range staff may check in.'
  bb = bans[t.shooter]
  require bb = null or not bb.active else BANNED 'This shooter is banned.'
  require not t.released else RELEASED 'This booking was released.'
  require not t.checkedIn else ALREADY_CHECKED_IN 'Already checked in.'
  require now <= t.startsAt + 15m else TOO_LATE 'Check-in closes 15 minutes after the start.'
  update bookings[booking] { checkedIn: true }
  return null

mutation cancelBooking(booking: bookings):
  t = bookings[booking] ! else NOT_FOUND
  require t.shooter = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_OWNER 'Only the shooter or range staff may cancel.'
  delete bookings[booking]
  return null

mutation recordShootingRecord(shooter: principal, total: int 0..300, notes: text <=280 ?):
  b = bans[shooter]
  require b = null or not b.active else BANNED 'This shooter is banned.'
  require viewer = shooter else NOT_ALLOWED 'Only the shooter may record their own shooting record.'
  return insert scores { shooter, total, notes, at: now }

alias recordScore = recordShootingRecord

mutation updateShootingRecord(record: scores, total: int 0..300, notes: text <=280 ?):
  t = scores[record] ! else NOT_FOUND
  require viewer = t.shooter else NOT_ALLOWED 'Only the shooter may change their own shooting record.'
  b = bans[t.shooter]
  require b = null or not b.active else BANNED 'This shooter is banned.'
  update scores[record] { total, notes }
  return null

mutation assignStudent(coach: principal, student: principal):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_STAFF
  require coach != student else BAD_ASSIGN 'A coach cannot coach themselves.'
  cr = roles[coach] ! else NOT_FOUND
  require cr.role = 'coach' else NOT_A_COACH 'The coach must hold the coach role.'
  sr = roles[student] ! else NOT_FOUND
  require sr.role = 'member' or sr.role = 'walkin' else NOT_A_SHOOTER 'The student must be a member or walk-in shooter.'
  return insert assignments { coach, student }

mutation unassignStudent(coach: principal, student: principal):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'master'] else NOT_STAFF
  if exists assignments[coach, student]:
    delete assignments[coach, student]
  return null

mutation banShooter(shooter: principal, reason: text 1..500, photo: image <=5000000):
  require exists roles[viewer, role = 'master'] else NOT_MASTER 'Only the range master may ban.'
  return upsert bans[shooter] { reason, photo, active: true, at: now }

mutation liftBan(shooter: principal):
  require exists roles[viewer, role = 'master'] else NOT_MASTER 'Only the range master may lift a ban.'
  b = bans[shooter] ! else NOT_FOUND
  update bans[shooter] { active: false }
  return null

job releaseMissed(periodStart: time, periodEnd: time):
  for b in bookings where .startsAt >= periodEnd - 7d and .startsAt < periodEnd - 15m by .startsAt:
    if not b.checkedIn and not b.released:
      update bookings[b.id] { released: true }

schedule releaser every 5m: releaseMissed

-- Privacy intent, stated from the spec independently of the rules above.
invariant roles.read only .principal = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant roles.insert only viewer = 'service:operator'
invariant bookings.read only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant bookings.insert only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant bookings.shooter read only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant scores.read only .shooter = viewer or exists roles[principal = viewer, role = 'master'] or exists assignments[coach = viewer, student = .shooter]
invariant scores.insert only .shooter = viewer
invariant scores.update only .shooter = viewer
invariant scores.recordShootingRecord only .shooter = viewer
invariant scores.updateShootingRecord only .shooter = viewer
invariant orientations.read only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant orientations.waiver read only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant bans.read only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant bans.photo read only .shooter = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
invariant bans.banShooter only exists roles[principal = viewer, role = 'master']
invariant bans.liftBan only exists roles[principal = viewer, role = 'master']
invariant assignments.read only .coach = viewer or .student = viewer or exists roles[principal = viewer, role = 'officer'] or exists roles[principal = viewer, role = 'master']
