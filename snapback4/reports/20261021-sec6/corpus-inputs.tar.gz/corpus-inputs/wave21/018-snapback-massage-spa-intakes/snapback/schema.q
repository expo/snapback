use identity password

table roles:
  principal: principal
  role: enum('owner', 'frontdesk', 'therapist', 'client')
  name: text 1..80
  unique principal
  immutable principal
  read <- allow
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('owner', 'frontdesk', 'therapist', 'client'), name: text 1..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, name }
query me():
  return roles[viewer]
query directory():
  require exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk'] else STAFF_ONLY
  return roles first 100 by .id

table appointments:
  client: principal
  therapist: principal
  clientName: text 1..80
  therapistName: text 1..80
  reference: text 1..80
  service: enum('Swedish massage', 'Deep tissue', 'Sports recovery')
  startsAt: time
  status: enum('booked', 'cancelled', 'completed') default 'booked'
  payment: enum('unpaid', 'paid') default 'unpaid'
  deposit: enum('held', 'refunded', 'forfeited', 'waived') default 'held'
  cancelledAt: time ?
  immutable client, therapist, clientName, therapistName, service, startsAt
  read <- .client = viewer or .therapist = viewer or exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk']
  insert <- exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk']
  update <- .client = viewer or .therapist = viewer or exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk']
  online only

table intakes:
  appointment: appointments
  medications: text 1..2000
  injuries: text 1..2000
  note: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?
  completedAt: time renamed from submittedAt
  renewBy: time
  unique appointment
  immutable appointment
  read <- .appointment.client = viewer or .appointment.therapist = viewer or exists roles[principal = viewer, role = 'owner']
  insert <- .appointment.client = viewer
  update <- .appointment.client = viewer
  online only

query schedule():
  return appointments last 100 by .startsAt
query appointment(id: appointments):
  return appointments[id]
query healthHistory(appointment: appointments):
  return intakes[appointment = appointment]
query intake(appointment: appointments):
  return intakes[appointment = appointment] { id, appointment, medications, injuries, note, submittedAt: .completedAt, renewBy }

mutation book(reference: text 1..80, client: principal, therapist: principal, service: enum('Swedish massage', 'Deep tissue', 'Sports recovery'), startsAt: time):
  require exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk'] else STAFF_ONLY
  c = roles[principal = client] ! else CLIENT_NOT_FOUND
  t = roles[principal = therapist] ! else THERAPIST_NOT_FOUND
  require c.role = 'client' and t.role = 'therapist' else BAD_ROLE
  require startsAt > now and startsAt <= now + 730d else INVALID_TIME
  return insert appointments { reference, client, therapist, clientName: c.name, therapistName: t.name, service, startsAt }

-- Same UTC day/time twelve calendar months later, clamped on leap day.
fn anniversary(t: time):
  target = month(t) + 12
  dayOffset = day(t) - day(monthStart(month(t)))
  lastDay = day(monthStart(target + 1)) - day(monthStart(target)) - 1
  offset = dayOffset if dayOffset <= lastDay else lastDay
  return monthStart(target) + offset * 1d + t % 1d

mutation submitIntake(appointment: appointments, medications: text 1..2000, injuries: text 1..2000, note: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?):
  a = appointments[appointment] ! else NOT_FOUND
  require a.client = viewer else CLIENT_ONLY
  require a.status = 'booked' and now < a.startsAt else INTAKE_CLOSED 'Health history changes close when the session starts or is cancelled.'
  h = upsert intakes[appointment] { appointment, medications, injuries, note, completedAt: now, renewBy: anniversary(now) }
  return intakes[h.id] { id, appointment, medications, injuries, note, submittedAt: .completedAt, renewBy }

mutation submitHealthHistory(appointment: appointments, medications: text 1..2000, injuries: text 1..2000, note: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?):
  a = appointments[appointment] ! else NOT_FOUND
  require a.client = viewer else CLIENT_ONLY
  require a.status = 'booked' and now < a.startsAt else HISTORY_CLOSED
  return upsert intakes[appointment] { appointment, medications, injuries, note, completedAt: now, renewBy: anniversary(now) }

mutation reviseHealthHistory(appointment: appointments, medications: text 1..2000, injuries: text 1..2000, note: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?):
  a = appointments[appointment] ! else NOT_FOUND
  require a.client = viewer else CLIENT_ONLY
  require a.status = 'booked' and now < a.startsAt else HISTORY_CLOSED
  h = intakes[appointment] ! else HISTORY_REQUIRED
  return update intakes[h.id] { medications, injuries, note: note if note != null else h.note }

mutation pay(appointment: appointments):
  require exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk'] else STAFF_ONLY
  a = appointments[appointment] ! else NOT_FOUND
  require a.status = 'booked' else NOT_BOOKED
  update appointments[appointment] { payment: 'paid' }

mutation cancel(appointment: appointments):
  a = appointments[appointment] ! else NOT_FOUND
  require a.client = viewer or exists roles[principal = viewer, role = 'owner'] or exists roles[principal = viewer, role = 'frontdesk'] else CANNOT_CANCEL
  require a.status = 'booked' and now < a.startsAt else CANCELLATION_CLOSED
  update appointments[appointment] { status: 'cancelled', cancelledAt: now, deposit: 'forfeited' if a.startsAt - now < 24h else 'refunded' }

mutation waiveDeposit(appointment: appointments):
  require exists roles[principal = viewer, role = 'owner'] else OWNER_ONLY
  a = appointments[appointment] ! else NOT_FOUND
  require a.status = 'cancelled' and a.deposit = 'forfeited' else NOT_LATE_CANCELLATION
  update appointments[appointment] { deposit: 'waived' }

mutation complete(appointment: appointments):
  a = appointments[appointment] ! else NOT_FOUND
  require a.therapist = viewer or exists roles[principal = viewer, role = 'owner'] else THERAPIST_ONLY
  require a.status = 'booked' and now >= a.startsAt else SESSION_NOT_READY
  health = intakes[appointment] ! else INTAKE_REQUIRED 'Complete the health history before treatment.'
  require now <= health.renewBy else INTAKE_EXPIRED 'Renew the health history before the session.'
  update appointments[appointment] { status: 'completed' }

invariant intakes.insert only .appointment.client = viewer
invariant intakes.update only .appointment.client = viewer
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
