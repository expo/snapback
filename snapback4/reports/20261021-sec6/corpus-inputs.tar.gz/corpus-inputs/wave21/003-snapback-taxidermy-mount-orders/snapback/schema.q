use identity password

table roles:
  principal: principal
  role: enum('owner', 'clerk', 'taxidermist', 'warden', 'customer')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'clerk']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('owner', 'clerk', 'taxidermist', 'warden', 'customer')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

query customers(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else STAFF_ONLY
  return roles where .role = 'customer' first 50 by .id after c

table orders:
  customer: principal
  species: text 2..80
  tag: text 1..60 ?
  tagFollowUp: enum('tag recorded', 'tag needed')
  animalPhoto: image <=5000000
  damagePhoto: image <=5000000 ?
  damageNotes: text <=1000
  price: int 1..10000000
  depositRequired: int 1..10000000
  depositPaid: int 0..10000000
  waiverReason: text 5..500 ?
  waiverActor: principal ?
  refusalReason: text 5..500 ?
  refusalActor: principal ?
  stage: enum('queued', 'tag_hold', 'awaiting_approval', 'back_of_queue', 'approved', 'completed', 'collected', 'for_sale', 'refused')
  proof: image <=5000000 ?
  proofAt: time ?
  proofDue: time ?
  approvedAt: time ?
  completedAt: time ?
  collectionDue: time ?
  queueAt: time
  createdAt: time
  immutable customer, species, tag, animalPhoto, damagePhoto, damageNotes, price, depositRequired, createdAt
  read <- .customer = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'taxidermist']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  update <- .customer = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'taxidermist']
  online only

table tags:
  orderId: orders
  tag: text 1..60
  unique orderId
  immutable orderId, tag
  read <- exists roles[viewer, role = 'warden'] or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'taxidermist']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  online only

shape orderCard = { *, effectiveStage: 'back_of_queue' if .stage = 'awaiting_approval' and .proofDue != null and .proofDue <= now else ('for_sale' if .stage = 'completed' and .collectionDue != null and .collectionDue <= now else .stage) }

query board(c: cursor ?):
  require exists roles[viewer] and not exists roles[viewer, role = 'warden'] else ORDERS_PRIVATE
  return orders first 50 by .queueAt after c orderCard

query orderDetail(orderId: orders):
  return orders[orderId] orderCard

query tagRegister(c: cursor ?):
  require exists roles[viewer, role = 'warden'] else WARDEN_ONLY
  return tags first 50 by .id after c { tag }

mutation createOrder(customer: principal, species: text 2..80, tag: text <=60 ?, animalPhoto: image <=5000000, damagePhoto: image <=5000000 ?, damageNotes: text <=1000, price: int 1..10000000, depositRequired: int 1..10000000, depositPaid: int 0..10000000):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else INTAKE_ONLY
  require exists roles[customer, role = 'customer'] else CUSTOMER_REQUIRED
  require depositRequired <= price and depositPaid <= price else BAD_AMOUNT
  recordedTag = tag if tag != null and trim(tag) != '' else null
  o = insert orders { customer, species, tag: recordedTag, animalPhoto, damagePhoto, damageNotes, price, depositRequired, depositPaid, tagFollowUp: 'tag recorded' if tag != null and trim(tag) != '' else 'tag needed', stage: 'tag_hold' if recordedTag = null else 'queued', queueAt: now, createdAt: now }
  if recordedTag != null:
    insert tags { orderId: o.id, tag: recordedTag }
  return o

mutation recordDeposit(orderId: orders, amount: int 1..10000000):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else INTAKE_ONLY
  o = orders[orderId] ! else NOT_FOUND
  require o.stage != 'refused' and o.stage != 'collected' and o.stage != 'for_sale' else CLOSED
  require o.collectionDue = null or now < o.collectionDue else COLLECTION_EXPIRED
  require o.depositPaid + amount <= o.price else BAD_AMOUNT
  return update orders[o.id] { depositPaid: o.depositPaid + amount }

mutation waiveDeposit(orderId: orders, reason: text 5..500):
  require exists roles[viewer, role = 'owner'] else OWNER_ONLY
  o = orders[orderId] ! else NOT_FOUND
  require o.stage = 'queued' or o.stage = 'tag_hold' else BAD_STAGE
  require o.waiverReason = null else ALREADY_WAIVED
  return update orders[o.id] { waiverReason: reason, waiverActor: viewer }

mutation refuseSpecimen(orderId: orders, reason: text 5..500):
  require exists roles[viewer, role = 'owner'] else OWNER_ONLY
  o = orders[orderId] ! else NOT_FOUND
  require o.tag = null and o.stage = 'tag_hold' else NOT_MISSING_TAG
  return update orders[o.id] { stage: 'refused', refusalReason: reason, refusalActor: viewer }

mutation postProof(orderId: orders, proof: image <=5000000):
  require exists roles[viewer, role = 'taxidermist'] or exists roles[viewer, role = 'owner'] else WORKROOM_ONLY
  o = orders[orderId] ! else NOT_FOUND
  require o.tag != null else MISSING_TAG
  require o.stage = 'queued' or o.stage = 'back_of_queue' or (o.stage = 'awaiting_approval' and o.proofDue != null and now >= o.proofDue) else BAD_STAGE
  require o.depositPaid >= o.depositRequired or o.waiverReason != null else DEPOSIT_REQUIRED
  return update orders[o.id] { proof, proofAt: now, proofDue: now + 21d, stage: 'awaiting_approval' }

mutation approveProof(orderId: orders):
  o = orders[orderId] ! else NOT_FOUND
  require o.customer = viewer and exists roles[viewer, role = 'customer'] else CUSTOMER_ONLY
  require o.stage = 'awaiting_approval' else BAD_STAGE
  require o.proofDue != null and now < o.proofDue else PROOF_EXPIRED
  return update orders[o.id] { stage: 'approved', approvedAt: now }

mutation completeMount(orderId: orders):
  require exists roles[viewer, role = 'taxidermist'] or exists roles[viewer, role = 'owner'] else WORKROOM_ONLY
  o = orders[orderId] ! else NOT_FOUND
  require o.stage = 'approved' else APPROVAL_REQUIRED
  return update orders[o.id] { stage: 'completed', completedAt: now, collectionDue: now + 90d }

mutation collectMount(orderId: orders):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else INTAKE_ONLY
  o = orders[orderId] ! else NOT_FOUND
  require o.stage = 'completed' else BAD_STAGE
  require o.collectionDue != null and now < o.collectionDue else COLLECTION_EXPIRED
  require o.depositPaid = o.price else BALANCE_DUE
  return update orders[o.id] { stage: 'collected' }

job enforceDeadlines():
  for o in orders:
    if o.stage = 'awaiting_approval' and o.proofDue != null and o.proofDue <= now:
      update orders[o.id] { stage: 'back_of_queue', queueAt: now }
    if o.stage = 'completed' and o.collectionDue != null and o.collectionDue <= now:
      update orders[o.id] { stage: 'for_sale' }

schedule deadlines every 1m: enforceDeadlines

-- Kept with the release so future v1 writes receive the same historical rule.
backfill orders tagFollowUp(tag: text 1..60 ?):
  { tagFollowUp: 'tag recorded' if tag != null and trim(tag) != '' else 'tag needed' }

mutation setTagFollowUp(orderId: orders, tagFollowUp: enum('tag recorded', 'tag needed')):
  require exists roles[viewer, role = 'owner'] else OWNER_ONLY
  o = orders[orderId] ! else NOT_FOUND
  return update orders[o.id] { tagFollowUp }

invariant orders.setTagFollowUp only exists roles[viewer, role = 'owner']
