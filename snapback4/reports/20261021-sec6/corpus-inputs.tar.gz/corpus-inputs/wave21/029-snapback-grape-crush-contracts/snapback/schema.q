-- Grape Crush Contracts: custom crush winery.
-- Roles: client (grower/label), receiver (receiving crew), cellar (cellar worker), winemaker.
-- Real password identity; roster provisioned by the local operator (service:operator).
use identity password

table roles:
  principal: principal
  role: enum('client', 'receiver', 'cellar', 'winemaker')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('client', 'receiver', 'cellar', 'winemaker')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[principal = viewer]

-- Intake: the receiving crew weighs each load, tests sugar and photographs the fruit.
table loads:
  client: principal
  varietal: text 1..80
  weightKg: int 1..50000
  brix: decimal 1
  photo: image <=5000000
  arrivedAt: time default now
  crushedAt: time ?
  status: enum('pending', 'crushed', 'rejected') default 'pending'
  rejectReason: text 1..500 ?
  immutable client, arrivedAt
  read <- .client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  insert <- exists roles[viewer, role = 'receiver']
  update <- exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'winemaker']
  online only

mutation intakeLoad(client: principal, varietal: text 1..80, weightKg: int 1..50000, brix: decimal 1, photo: image <=5000000, arrivedAt: time ?):
  require exists roles[viewer, role = 'receiver'] else NOT_RECEIVER
  require exists roles[client, role = 'client'] else NOT_CLIENT
  return insert loads { client, varietal, weightKg, brix, photo, arrivedAt: arrivedAt ?? now }

-- A load must be crushed within 24 hours of arriving; late crush needs the winemaker.
mutation crushLoad(load: loads):
  require exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CREW
  l = loads[load] ! else NOT_FOUND
  require l.status = 'pending' else BAD_STATUS 'This load is already settled.'
  require now <= l.arrivedAt + 24h or exists roles[viewer, role = 'winemaker'] else OVERDUE_CRUSH 'This load arrived over 24 hours ago; only the winemaker may crush it now.'
  update loads[load] { status: 'crushed', crushedAt: now }
  return null

-- Only the winemaker may reject a load for rot, recording the reason.
mutation rejectLoad(load: loads, reason: text 1..500):
  require exists roles[viewer, role = 'winemaker'] else NOT_WINEMAKER
  l = loads[load] ! else NOT_FOUND
  require l.status = 'pending' else BAD_STATUS 'This load is already settled.'
  update loads[load] { status: 'rejected', rejectReason: reason }
  return null

-- Tanks: vessels the cellar crew manages.
table tanks:
  name: text 1..80
  status: enum('empty', 'fermenting', 'ready') default 'empty'
  currentClient: principal ?
  inoculatedAt: time ?
  unique name else TANK_TAKEN 'That tank name is taken.'
  read <- exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  insert <- exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  update <- exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  online only

mutation createTank(name: text 1..80):
  require exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CELLAR
  return insert tanks { name, status: 'empty' }

-- Lots: a client's wine, with their written protocol on file.
-- exceptionLabel tracks whether the winemaker approved an addition outside the
-- written protocol ('approved exception') or not ('no approved exception').
-- New lots start 'no approved exception'; only the winemaker may change it.
table lots:
  client: principal
  load: loads ?
  tank: tanks ?
  protocol: text 1..500
  exceptionLabel: enum('approved exception', 'no approved exception') default 'no approved exception'
  inoculatedAt: time ?
  lastReadingAt: time ?
  createdAt: time default now
  immutable client, createdAt
  read <- .client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  insert <- exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  update (old, next) <- (exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']) and (old.exceptionLabel = next.exceptionLabel or exists roles[viewer, role = 'winemaker'])
  online only

mutation createLot(client: principal, load: loads, tank: tanks ?, protocol: text 1..500):
  require exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CELLAR
  require exists roles[client, role = 'client'] else NOT_CLIENT
  ld = loads[load] ! else NOT_FOUND
  require ld.client = client else WRONG_CLIENT 'That load belongs to a different client.'
  if tank != null:
    t = tanks[tank] ! else NOT_FOUND
    require t.status = 'empty' else TANK_BUSY 'That tank is already in use.'
    update tanks[tank] { status: 'fermenting', currentClient: client, inoculatedAt: now }
  return insert lots { client, load, tank, protocol, inoculatedAt: now if tank != null else null }

-- Fermentation readings, due every 12 hours after a tank is inoculated.
table readings:
  lot: lots
  client: principal
  brix: decimal 1 ?
  tempC: decimal 1 ?
  at: time default now
  takenBy: principal default viewer
  immutable lot, client, at, takenBy
  read <- .client = viewer or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  insert <- exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  online only

mutation addReading(lot: lots, brix: decimal 1 ?, tempC: decimal 1 ?):
  require exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CELLAR
  l = lots[lot] ! else NOT_FOUND
  require l.inoculatedAt != null else NOT_INOCULATED 'This lot has not been inoculated yet.'
  update lots[lot] { lastReadingAt: now }
  return insert readings { lot, client: l.client, brix, tempC }

-- Charges for the client's bill: only the winemaker posts them.
table charges:
  lot: lots
  client: principal
  amount: money USD
  memo: text 1..200
  at: time default now
  immutable lot, client, amount, at
  read <- .client = viewer or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  insert <- exists roles[viewer, role = 'winemaker']
  online only

mutation addCharge(lot: lots, amount: money USD, memo: text 1..200):
  require exists roles[viewer, role = 'winemaker'] else NOT_WINEMAKER
  l = lots[lot] ! else NOT_FOUND
  return insert charges { lot, client: l.client, amount, memo }

-- Additions: only the winemaker may approve one outside the client's protocol, with a reason.
table additions:
  lot: lots
  client: principal
  description: text 1..300
  outsideProtocol: bool default false
  status: enum('pending', 'approved', 'rejected') default 'pending'
  reason: text 1..500 ?
  requestedBy: principal default viewer
  decidedBy: principal ?
  immutable lot, client, requestedBy
  read <- .client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  insert <- exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
  update <- exists roles[viewer, role = 'winemaker']
  online only

mutation requestAddition(lot: lots, description: text 1..300, outsideProtocol: bool):
  require exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CELLAR
  l = lots[lot] ! else NOT_FOUND
  return insert additions { lot, client: l.client, description, outsideProtocol }

mutation decideAddition(addition: additions, approve: bool, reason: text 1..500):
  require exists roles[viewer, role = 'winemaker'] else NOT_WINEMAKER
  a = additions[addition] ! else NOT_FOUND
  require a.status = 'pending' else ALREADY_DECIDED 'This addition was already decided.'
  if approve and a.outsideProtocol:
    update lots[a.lot] { exceptionLabel: 'approved exception' }
  update additions[addition] { status: 'approved' if approve else 'rejected', reason, decidedBy: viewer }
  return null

-- Only the winemaker may change a lot's protocol exception label.
mutation setExceptionLabel(lot: lots, label: enum('approved exception', 'no approved exception')):
  require exists roles[viewer, role = 'winemaker'] else NOT_WINEMAKER
  l = lots[lot] ! else NOT_FOUND
  update lots[lot] { exceptionLabel: label }
  return null

-- Boards and watches.
query loadsBoard(c: cursor ?):
  if exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']:
    return loads last 50 by .id after c
  return loads where .client = viewer last 50 by .id after c

query tanksBoard(c: cursor ?):
  require exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CREW
  return tanks last 50 by .id after c

query lotsBoard(c: cursor ?):
  if exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']:
    return lots last 50 by .id after c
  return lots where .client = viewer last 50 by .id after c

query lotDetail(lot: lots):
  return lots[lot]

query readingsFor(lot: lots, c: cursor ?):
  l = lots[lot] ! else NOT_FOUND
  require l.client = viewer or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_ALLOWED
  return readings where .lot = lot last 50 by .at after c

query chargesFor(lot: lots, c: cursor ?):
  l = lots[lot] ! else NOT_FOUND
  require l.client = viewer or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_ALLOWED
  return charges where .lot = lot last 50 by .at after c

query myCharges(c: cursor ?):
  return charges where .client = viewer last 50 by .at after c

query additionsFor(lot: lots, c: cursor ?):
  l = lots[lot] ! else NOT_FOUND
  require l.client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_ALLOWED
  return additions where .lot = lot last 50 by .id after c

-- Loads still pending more than 24h after arrival: flagged to the winemaker.
query overdueLoads(c: cursor ?):
  require exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CREW
  return loads where .status = 'pending' and .arrivedAt < now - 24h last 50 by .id after c

-- Lots inoculated more than 12h ago with no recent reading.
query dueLots(c: cursor ?):
  require exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker'] else NOT_CREW
  return lots where .inoculatedAt != null and (.lastReadingAt = null or .lastReadingAt < now - 12h) last 50 by .id after c

query myDueLots(c: cursor ?):
  return lots where .client = viewer and .inoculatedAt != null and (.lastReadingAt = null or .lastReadingAt < now - 12h) last 50 by .id after c

-- Privacy intent from the spec.
invariant loads.read only .client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
invariant tanks.read only exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
invariant lots.read only .client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
invariant readings.read only .client = viewer or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
invariant charges.read only .client = viewer or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
invariant additions.read only .client = viewer or exists roles[viewer, role = 'receiver'] or exists roles[viewer, role = 'cellar'] or exists roles[viewer, role = 'winemaker']
invariant loads.rejectLoad only exists roles[viewer, role = 'winemaker']
invariant additions.decideAddition only exists roles[viewer, role = 'winemaker']
invariant lots.setExceptionLabel only exists roles[viewer, role = 'winemaker']
invariant charges.addCharge only exists roles[viewer, role = 'winemaker']
