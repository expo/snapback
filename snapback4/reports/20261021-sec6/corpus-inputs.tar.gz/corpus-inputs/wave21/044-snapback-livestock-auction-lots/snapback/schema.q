use identity password

-- Only a local store operator assigns roles; signing up never grants a role.
table roles:
  principal: principal
  role: enum('crew', 'office', 'buyer', 'consignor', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[principal = viewer, role = 'office']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only
mutation provision(principal: principal, role: enum('crew', 'office', 'buyer', 'consignor', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal = principal] { principal, role }
query myRole():
  return roles[principal = viewer]
query participants():
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  return roles first 1000 by .id

-- No consignor identifier or private financial terms ever live on a public lot.
table lots:
  tag: text 1..60
  breed: text 1..80
  head: int 1..500
  totalWeight: int 1..2000000 ?
  minWeight: int 1..5000 ?
  maxWeight: int 1..5000 ?
  photos: [image <=5000000] <=6 ?
  papers: file <=5000000 ('application/pdf', 'text/plain') ?
  status: enum('bidding', 'sold', 'withdrawn', 'released') default 'bidding'
  priceCents: int 1..100000000 ?
  soldAt: time ?
  activeSale: sales ?
  arrivedAt: time default now
  read <- exists roles[principal = viewer, role = 'buyer'] or exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'manager'] or exists ownership[lot = .id, consignor = viewer]
  insert <- exists roles[principal = viewer, role = 'office']
  update <- exists roles[principal = viewer, role = 'crew'] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'manager']
  online only

table ownership:
  lot: lots
  consignor: principal
  unique lot
  immutable lot, consignor
  read <- .consignor = viewer or exists roles[principal = viewer, role = 'office']
  insert <- exists roles[principal = viewer, role = 'office']
  online only

table officeTerms:
  lot: lots
  name: text 1..100
  phone: text 7..30
  minimumSalePriceCents: int 0..100000000 ?
  unique lot
  immutable lot
  read <- exists roles[principal = viewer, role = 'office']
  insert <- exists roles[principal = viewer, role = 'office']
  update <- exists roles[principal = viewer, role = 'office']
  online only

table sales:
  lot: lots
  buyer: principal
  priceCents: int 1..100000000
  soldAt: time
  paid: bool default false
  released: bool default false
  voided: bool default false
  read <- exists roles[principal = viewer, role = 'manager'] or .buyer = viewer or exists roles[principal = viewer, role = 'office'] or exists ownership[lot = .lot, consignor = viewer]
  insert <- exists roles[principal = viewer, role = 'office']
  update <- exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'manager']
  online only

table decisions:
  lot: lots
  actor: principal
  action: enum('withdraw', 'reopen')
  reason: text 5..500
  at: time default now
  immutable lot, actor, action, reason, at
  read <- exists roles[principal = viewer, role = 'manager'] or exists roles[principal = viewer, role = 'office']
  insert <- .actor = viewer and exists roles[principal = viewer, role = 'manager']
  online only

query listLots():
  return lots last 500 by .id
query lot(lot: lots):
  return lots[lot]
query officeDetails(lot: lots):
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  terms = officeTerms[lot = lot] ! else NOT_FOUND
  return { terms: { id: terms.id, lot: terms.lot, name: terms.name, phone: terms.phone, minimumSalePriceCents: terms.minimumSalePriceCents, reserveCents: terms.minimumSalePriceCents }, owner: ownership[lot = lot] }
query settlements():
  return sales last 500 by .id
query decisionHistory():
  require exists roles[principal = viewer, role = 'manager'] or exists roles[principal = viewer, role = 'office'] else MANAGER_OR_OFFICE
  return decisions last 500 by .id

mutation createLot(tag: text 1..60, breed: text 1..80, head: int 1..500, consignor: principal, name: text 1..100, phone: text 7..30, minimumSalePriceCents: int 0..100000000 ? alias reserveCents):
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  require exists roles[principal = consignor, role = 'consignor'] else NOT_CONSIGNOR
  row = insert lots { tag, breed, head }
  insert ownership { lot: row.id, consignor }
  insert officeTerms { lot: row.id, name, phone, minimumSalePriceCents }
  return row

mutation recordArrival(lot: lots, totalWeight: int 1..2000000, minWeight: int 1..5000, maxWeight: int 1..5000, photos: [image <=5000000] <=6, papers: file <=5000000 ('application/pdf', 'text/plain')):
  require exists roles[principal = viewer, role = 'crew'] else CREW_ONLY
  row = lots[lot] ! else NOT_FOUND
  require row.status = 'bidding' else NOT_BIDDING
  require minWeight <= maxWeight and totalWeight >= row.head * minWeight and totalWeight <= row.head * maxWeight else BAD_WEIGHTS
  require len(photos) >= 1 else PHOTO_REQUIRED
  update lots[lot] { totalWeight, minWeight, maxWeight, photos, papers }

mutation sellLot(lot: lots, buyer: principal, priceCents: int 1..100000000):
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  row = lots[lot] ! else NOT_FOUND
  terms = officeTerms[lot = lot] ! else NOT_FOUND
  require row.status = 'bidding' else NOT_BIDDING
  require row.totalWeight != null else NOT_WEIGHED
  require exists roles[principal = buyer, role = 'buyer'] else NOT_BUYER
  require terms.minimumSalePriceCents = null or priceCents >= terms.minimumSalePriceCents else BELOW_MINIMUM_SALE_PRICE
  sale = insert sales { lot, buyer, priceCents, soldAt: now }
  update lots[lot] { status: 'sold', priceCents, soldAt: now, activeSale: sale.id }
  return sale

mutation markPaid(sale: sales):
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  row = sales[sale] ! else NOT_FOUND
  require not row.voided else VOIDED
  update sales[sale] { paid: true }

mutation releaseLot(sale: sales):
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  row = sales[sale] ! else NOT_FOUND
  require not row.voided and not row.released else NOT_RELEASABLE
  require row.paid or now < row.soldAt + 48h else PAYMENT_OVERDUE 'Payment is required after 48 hours.'
  target = lots[row.lot] ! else NOT_FOUND
  require target.status = 'sold' else NOT_SOLD
  update sales[sale] { released: true }
  update lots[row.lot] { status: 'released' }

mutation withdrawLot(lot: lots, reason: text 5..500):
  require exists roles[principal = viewer, role = 'manager'] else MANAGER_ONLY
  row = lots[lot] ! else NOT_FOUND
  require row.status = 'bidding' else NOT_BIDDING
  update lots[lot] { status: 'withdrawn' }
  return insert decisions { lot, actor: viewer, action: 'withdraw', reason }

mutation reopenBidding(lot: lots, reason: text 5..500):
  require exists roles[principal = viewer, role = 'manager'] else MANAGER_ONLY
  row = lots[lot] ! else NOT_FOUND
  require row.status = 'withdrawn' or row.status = 'sold' else NOT_REOPENABLE
  if row.activeSale != null:
    sale = sales[row.activeSale] ! else NOT_FOUND
    require not sale.paid and not sale.released else ALREADY_PAID
    update sales[sale.id] { voided: true }
  update lots[lot] { status: 'bidding', priceCents: null, soldAt: null, activeSale: null }
  return insert decisions { lot, actor: viewer, action: 'reopen', reason }

-- Independent privacy and authority declarations from the product spec.
invariant officeTerms.read only exists roles[principal = viewer, role = 'office']
invariant ownership.read only .consignor = viewer or exists roles[principal = viewer, role = 'office']
invariant roles.role write only viewer = 'service:operator'
invariant decisions.insert only exists roles[principal = viewer, role = 'manager']
invariant lots.withdrawLot only exists roles[principal = viewer, role = 'manager']
invariant lots.reopenBidding only exists roles[principal = viewer, role = 'manager']

-- Sale office alone controls the optional USD cent amount, including clearing it.
mutation setMinimumSalePrice(lot: lots, minimumSalePriceCents: int 0..100000000 ?):
  require exists roles[principal = viewer, role = 'office'] else OFFICE_ONLY
  terms = officeTerms[lot = lot] ! else NOT_FOUND
  update officeTerms[terms.id] { minimumSalePriceCents }

invariant officeTerms.minimumSalePriceCents update only exists roles[principal = viewer, role = 'office']

