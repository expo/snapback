-- Fine Art Crating: crating and moving artworks for collectors and galleries.
-- Roles: registrar (sees everything, files claims), handler (packs, photos),
-- driver (loads, delivers), client (owns shipments, confirms receipt).
use identity password

table roles:
  principal: principal
  role: enum('registrar', 'handler', 'driver', 'client')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'registrar'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('registrar', 'handler', 'driver', 'client')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

query clients(c: cursor ?):
  return roles where .role = 'client' first 50 by .id after c

-- A shipment of one artwork. Insured value and party names are registrar-only
-- via column rules; staff and the owning client share the operational row.
table shipments:
  client: principal
  title: text 1..120
  crate: text 1..80
  handling: text 1..1000
  address: text 1..500
  insuredValue: money USD ? read <- exists roles[viewer, role = 'registrar']
  seller: text 1..120 read <- exists roles[viewer, role = 'registrar']
  buyer: text 1..120 read <- exists roles[viewer, role = 'registrar']
  insuranceCheck: enum('amount recorded', 'amount needed') read <- exists roles[viewer, role = 'registrar']
  status: enum('created', 'packed', 'loaded', 'delivered', 'confirmed', 'claimed') default 'created'
  deliveredAt: time ?
  confirmedAt: time ?
  overdue: bool default false
  createdAt: time default now
  immutable client, createdAt
  read <- exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] or exists roles[viewer, role = 'driver'] or .client = viewer
  insert <- exists roles[viewer, role = 'registrar']
  update <- exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] or exists roles[viewer, role = 'driver'] or .client = viewer
  online only

-- v2 backfill: every pre-existing shipment keeps its row. v1 required an
-- insured value on every shipment, so each row predating v2 had one recorded
-- (including explicit zeros) and migrates to 'amount recorded'. The input is
-- the immutable creation time on purpose: the value itself may change later
-- under v2, and a backfill keyed on a mutable input would refuse forward
-- after such a native edit. Shipments first recorded under v2 carry the check
-- their creating mutation authored, including 'amount needed'.
backfill shipments insuranceCheck(createdAt: time):
  {insuranceCheck: 'amount recorded'}

-- Condition photos. The owning client is copied onto each row so audience is
-- row-local; staff see every photo.
table photos:
  shipment: shipments
  client: principal
  author: principal
  photo: image <=10000000
  caption: text <=200 ?
  at: time default now
  immutable shipment, client, author
  read <- exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] or exists roles[viewer, role = 'driver'] or .client = viewer
  insert <- .author = viewer and (exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler']) and exists shipments[.shipment, client = .client]
  online only

-- Insurance claims: only the registrar files; the owning client may read its own.
table claims:
  shipment: shipments
  client: principal
  damage: text 1..2000
  amount: money USD ?
  filedAt: time default now
  unique shipment
  immutable shipment, client
  read <- exists roles[viewer, role = 'registrar'] or .client = viewer
  insert <- exists roles[viewer, role = 'registrar']
  online only

mutation createShipment(client: principal, title: text 1..120, crate: text 1..80, handling: text 1..1000, address: text 1..500, insuredValue: money USD ?, seller: text 1..120, buyer: text 1..120):
  require exists roles[viewer, role = 'registrar'] else NOT_REGISTRAR
  require exists roles[client, role = 'client'] else NOT_CLIENT 'shipments belong to a provisioned client'
  return insert shipments { client, title, crate, handling, address, insuredValue, seller, buyer, insuranceCheck: 'amount recorded' if insuredValue != null else 'amount needed' }

-- v2: the registrar may record or clear the insured value later; the check
-- follows the same present-including-zero vs absent rule as creation.
mutation setInsuredValue(shipment: shipments, insuredValue: money USD ?):
  require exists roles[viewer, role = 'registrar'] else NOT_REGISTRAR
  s = shipments[shipment] ! else NOT_FOUND
  return update shipments[s.id] { insuredValue, insuranceCheck: 'amount recorded' if insuredValue != null else 'amount needed' }

mutation addPhoto(shipment: shipments, photo: image <=10000000, caption: text <=200 ?):
  require exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] else NOT_STAFF
  s = shipments[shipment] ! else NOT_FOUND
  require s.status = 'created' else ALREADY_CRATED
  return insert photos { shipment: s.id, client: s.client, author: viewer, photo, caption }

mutation packShipment(shipment: shipments, photo: photos):
  require exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] else NOT_STAFF
  s = shipments[shipment] ! else NOT_FOUND
  require s.status = 'created' else BAD_STATUS
  p = photos[photo] ! else NOT_FOUND
  require p.shipment = shipment else WRONG_PHOTO 'that photo shows a different shipment'
  return update shipments[s.id] { status: 'packed' }

mutation loadShipment(shipment: shipments):
  require exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'driver'] else NOT_DRIVER
  s = shipments[shipment] ! else NOT_FOUND
  require s.status = 'packed' else BAD_STATUS
  return update shipments[s.id] { status: 'loaded' }

mutation deliverShipment(shipment: shipments):
  require exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'driver'] else NOT_DRIVER
  s = shipments[shipment] ! else NOT_FOUND
  require s.status = 'loaded' else BAD_STATUS
  return update shipments[s.id] { status: 'delivered', deliveredAt: now }

mutation confirmReceipt(shipment: shipments):
  s = shipments[shipment] ! else NOT_FOUND
  require s.client = viewer else NOT_RECEIVER
  require s.status = 'delivered' else BAD_STATUS
  require s.deliveredAt != null and s.deliveredAt + 48h >= now else CONFIRM_LATE 'confirmation is due within 48 hours of delivery'
  return update shipments[s.id] { status: 'confirmed', confirmedAt: now }

mutation fileClaim(shipment: shipments, damage: text 1..2000, amount: money USD ?):
  require exists roles[viewer, role = 'registrar'] else NOT_REGISTRAR
  s = shipments[shipment] ! else NOT_FOUND
  require s.status = 'delivered' or s.status = 'confirmed' else BAD_STATUS
  c = insert claims { shipment: s.id, client: s.client, damage, amount }
  update shipments[s.id] { status: 'claimed' }
  return c

-- Flags delivered shipments the receiver never confirmed within 48 hours,
-- so the live dispatch board can surface them.
job flagOverdue(periodStart: time, periodEnd: time):
  for s in shipments:
    if s.status = 'delivered' and s.deliveredAt != null and s.deliveredAt + 48h < periodEnd and not s.overdue:
      update shipments[s.id] { overdue: true }

schedule overdueHourly every 1h: flagOverdue

query board(c: cursor ?):
  return shipments first 50 by .id after c

query shipment(id: shipments):
  return shipments[id]

query photosFor(shipment: shipments, c: cursor ?):
  return photos where .shipment = shipment first 50 by .id after c

query claimFor(shipment: shipments):
  return claims[shipment = shipment]

-- Spec intent, checked independently of the rules above.
invariant shipments.read only exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] or exists roles[viewer, role = 'driver'] or .client = viewer
invariant shipments.insuredValue read only exists roles[viewer, role = 'registrar']
invariant shipments.insuranceCheck read only exists roles[viewer, role = 'registrar']
invariant shipments.seller read only exists roles[viewer, role = 'registrar']
invariant shipments.buyer read only exists roles[viewer, role = 'registrar']
invariant photos.read only exists roles[viewer, role = 'registrar'] or exists roles[viewer, role = 'handler'] or exists roles[viewer, role = 'driver'] or .client = viewer
invariant claims.read only exists roles[viewer, role = 'registrar'] or .client = viewer
invariant claims.insert only exists roles[viewer, role = 'registrar']
