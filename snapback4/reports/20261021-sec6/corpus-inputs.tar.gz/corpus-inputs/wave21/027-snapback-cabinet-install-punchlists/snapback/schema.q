use identity password

-- Roles are provisioned by the local store operator; signup grants no role.
table people:
  principal: principal
  role: enum('homeowner', 'installer', 'office', 'owner')
  name: text 1..80
  crew: text 1..40
  unique principal
  immutable principal
  read <- .principal = viewer or exists people[viewer, role = 'office'] or exists people[viewer, role = 'owner'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('homeowner', 'installer', 'office', 'owner'), name: text 1..80, crew: text 1..40):
  require viewer = 'service:operator' else OPERATOR_ONLY
  return upsert people[principal] { principal, role, name, crew }

query myProfile():
  return people[principal = viewer]

query directory():
  require exists people[viewer, role = 'office'] or exists people[viewer, role = 'owner'] else OFFICE_ONLY
  return people first 100 by .id

table jobs:
  title: text 1..100
  address: text 1..240
  homeowner: principal
  crew: text 1..40
  phase: enum('planned', 'walkthrough', 'followup', 'complete') default 'planned'
  walkthroughAt: time ?
  fixDueAt: time ?
  lastClosedAt: time ?
  paymentDueAt: time ?
  immutable title, address, homeowner, crew
  read <- .homeowner = viewer or exists people[viewer, role = 'installer', crew = .crew] or exists people[viewer, role = 'office'] or exists people[viewer, role = 'owner']
  insert <- (exists people[viewer, role = 'office'] or exists people[viewer, role = 'owner']) and .phase = 'planned'
  update <- exists people[viewer, role = 'installer', crew = .crew] or exists people[viewer, role = 'owner']
  online only

table items:
  job: jobs
  description: text 3..1000
  location: text 1..100
  photo: image <=8000000
  loggedBy: principal
  loggedAt: time
  route: enum('repair', 'accepted without repair') default 'repair'
  state: enum('open', 'fixed', 'waived') default 'open'
  closedAt: time ?
  closedBy: principal ?
  resolution: text 3..1000 ?
  immutable job, description, location, photo, loggedBy, loggedAt
  read through .job
  insert <- .loggedBy = viewer and (exists people[viewer, role = 'installer', crew = .job.crew] or exists people[viewer, role = 'owner']) and .state = 'open' and .route = 'repair'
  update (old, next) <- (old.state = 'open' and (next.route = old.route or exists people[viewer, role = 'owner']) and ((next.state = 'open' and exists people[viewer, role = 'owner']) or (next.state = 'fixed' and next.route = 'repair' and (exists people[viewer, role = 'installer', crew = old.job.crew] or exists people[viewer, role = 'owner'])) or (next.state = 'waived' and next.route = 'accepted without repair' and exists people[viewer, role = 'owner']))) or (old.state = 'waived' and next.state = 'waived' and next.route = 'accepted without repair' and exists people[viewer, role = 'owner'])
  cap 100 by job
  online only

table signoffs:
  item: items
  homeowner: principal
  reason: text 3..1000
  statement: text 10..1000
  signedAt: time
  unique item
  immutable item, homeowner, reason, statement, signedAt
  read through .item
  insert <- .homeowner = viewer and .homeowner = .item.job.homeowner
  online only

query listJobs(c: cursor ?):
  return jobs last 100 by .id after c

query jobDetails(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  punches = items where .job = job
  approvals = []
  for p in punches:
    approval = signoffs[item = p.id]
    if approval != null:
      approvals = approvals + [approval]
  return { job: j, items: punches, signoffs: approvals, serverNow: now }

query openBoard(c: cursor ?):
  require exists people[viewer, role = 'office'] or exists people[viewer, role = 'owner'] else OFFICE_ONLY
  return items where .state = 'open' first 100 by .id after c { id, description, location, route, job: jobs[.job], loggedAt }

mutation createJob(title: text 1..100, address: text 1..240, homeowner: principal, crew: text 1..40):
  require exists people[viewer, role = 'office'] or exists people[viewer, role = 'owner'] else OFFICE_ONLY
  require exists people[homeowner, role = 'homeowner'] else HOMEOWNER_REQUIRED
  require exists people where .role = 'installer' and .crew = crew else CREW_REQUIRED
  return insert jobs { title, address, homeowner, crew }

mutation startWalkthrough(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  require exists people[viewer, role = 'installer', crew = j.crew] or exists people[viewer, role = 'owner'] else CREW_ONLY
  require j.phase = 'planned' else ALREADY_STARTED
  update jobs[job] { phase: 'walkthrough', walkthroughAt: now, fixDueAt: now + 14d }

mutation logItem(job: jobs, description: text 3..1000, location: text 1..100, photo: image <=8000000):
  j = jobs[job] ! else NOT_FOUND
  require exists people[viewer, role = 'installer', crew = j.crew] or exists people[viewer, role = 'owner'] else CREW_ONLY
  require j.phase = 'walkthrough' else WALKTHROUGH_ONLY
  require j.fixDueAt != null and now <= j.fixDueAt else DEADLINE_PASSED
  return insert items { job, description, location, photo, loggedBy: viewer, loggedAt: now, route: 'repair' }

mutation finishWalkthrough(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  require exists people[viewer, role = 'installer', crew = j.crew] or exists people[viewer, role = 'owner'] else CREW_ONLY
  require j.phase = 'walkthrough' else WALKTHROUGH_ONLY
  require j.fixDueAt != null and now <= j.fixDueAt else DEADLINE_PASSED
  require exists items where .job = job else NO_PUNCH_ITEMS
  update jobs[job] { phase: 'followup' }

mutation signOffWaiver(item: items, reason: text 3..1000, statement: text 10..1000):
  p = items[item] ! else NOT_FOUND
  j = jobs[p.job] ! else NOT_FOUND
  require j.homeowner = viewer else HOMEOWNER_ONLY
  require j.phase = 'followup' and p.state = 'open' else ITEM_LOCKED
  return insert signoffs { item, homeowner: viewer, reason, statement, signedAt: now }

mutation closeFixed(item: items, resolution: text 3..1000):
  p = items[item] ! else NOT_FOUND
  j = jobs[p.job] ! else NOT_FOUND
  require exists people[viewer, role = 'installer', crew = j.crew] or exists people[viewer, role = 'owner'] else CREW_ONLY
  require j.phase = 'followup' and p.state = 'open' else ITEM_LOCKED
  require j.fixDueAt != null and now <= j.fixDueAt else DEADLINE_PASSED
  require p.route = 'repair' else REPAIR_ROUTE_REQUIRED
  update items[item] { state: 'fixed', closedAt: now, closedBy: viewer, resolution }
  if not exists items where .job = p.job and .state = 'open':
    update jobs[p.job] { phase: 'complete', lastClosedAt: now, paymentDueAt: now + 10d }

mutation closeWaived(item: items):
  require exists people[viewer, role = 'owner'] else OWNER_ONLY
  p = items[item] ! else NOT_FOUND
  j = jobs[p.job] ! else NOT_FOUND
  require j.phase = 'followup' and p.state = 'open' else ITEM_LOCKED
  s = signoffs[item = item] ! else SIGNOFF_REQUIRED
  require s.homeowner = j.homeowner else SIGNOFF_REQUIRED
  update items[item] { state: 'waived', route: 'accepted without repair', closedAt: now, closedBy: viewer, resolution: s.reason }
  if not exists items where .job = p.job and .state = 'open':
    update jobs[p.job] { phase: 'complete', lastClosedAt: now, paymentDueAt: now + 10d }

-- Deployment reconciles legacy waived rows through this same owner-only mutation.
-- The literal default handles open/fixed rows and v1 writes without mutable-input backfill preimages.
mutation setRoute(item: items, route: enum('repair', 'accepted without repair')):
  require exists people[viewer, role = 'owner'] else OWNER_ONLY
  p = items[item] ! else NOT_FOUND
  require p.state = 'open' or (p.state = 'waived' and route = 'accepted without repair') else ITEM_LOCKED
  if route = 'accepted without repair':
    s = signoffs[item = item] ! else SIGNOFF_REQUIRED
    j = jobs[p.job] ! else NOT_FOUND
    require s.homeowner = j.homeowner else SIGNOFF_REQUIRED
  update items[item] { route }
