use identity password

table roles:
  principal: principal
  role: enum('customer', 'counter', 'framer', 'owner')
  name: text 1..100
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or (exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'framer'] or exists roles[principal = viewer, role = 'owner'])
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table orders:
  customer: principal
  title: text 1..120
  frame: text 1..100
  mat: text 1..100
  glazingChoice: enum('standard', 'non-glare', 'museum') renamed from glass
  photo: image <=8000000
  mockup: image <=8000000 ?
  state: enum('draft', 'awaiting', 'expired', 'approved', 'cutting', 'joining', 'fitting', 'fitted', 'ready', 'storage', 'collected', 'damaged') default 'draft'
  createdAt: time default now
  sentAt: time ?
  approvalDue: time ?
  approvedAt: time ?
  pickupAt: time ?
  storageDue: time ?
  storageFee: int 0.. default 0
  damaged: text <=500 ?
  damageWhy: text <=1000 ?
  redoCount: int 0.. default 0
  immutable customer, title, frame, mat, photo, createdAt
  read <- .customer = viewer or (exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'framer'] or exists roles[principal = viewer, role = 'owner'])
  insert <- exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'owner']
  update (old, next) <- (old.glazingChoice = next.glazingChoice or exists roles[principal = viewer, role = 'counter']) and (old.customer = viewer or exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'framer'] or exists roles[principal = viewer, role = 'owner'])
  online only

table redos:
  order: orders
  damaged: text 1..500
  reason: text 1..1000
  approval: text 1..1000
  approvedBy: principal
  at: time default now
  costTo: enum('shop') default 'shop'
  read <- exists roles[principal = viewer, role = 'owner']
  insert <- .approvedBy = viewer and exists roles[principal = viewer, role = 'owner']
  online only

mutation provision(principal: principal, role: enum('customer', 'counter', 'framer', 'owner'), name: text 1..100):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, name }

query myProfile():
  return roles[principal = viewer]

query customers(c: cursor ?):
  require exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'owner'] else NOT_COUNTER
  return roles where .role = 'customer' first 100 by .id after c

-- Read compatibility for released v1 clients; glass is an API projection only.
shape orderView = { *, glass: .glazingChoice }

query orderList(c: cursor ?):
  return orders last 100 by .createdAt after c orderView

query orderDetail(order: orders):
  return orders[order] orderView

query redoHistory(c: cursor ?):
  require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
  return redos last 100 by .at after c

mutation createOrder(customer: principal, title: text 1..120, frame: text 1..100, mat: text 1..100, glazingChoice: enum('standard', 'non-glare', 'museum') alias glass, photo: image <=8000000):
  require exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'owner'] else NOT_COUNTER
  require exists roles[principal = customer, role = 'customer'] else NOT_CUSTOMER
  return insert orders { customer, title, frame, mat, glazingChoice, photo }

mutation sendMockup(order: orders, mockup: image <=8000000):
  require exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'owner'] else NOT_COUNTER
  o = orders[order] ! else NOT_FOUND
  require o.state = 'draft' or o.state = 'expired' or (o.state = 'awaiting' and (o.approvalDue ?? 0) <= now) else BAD_STATE
  return update orders[order] { mockup, state: 'awaiting', sentAt: now, approvalDue: now + 7d }

mutation approveMockup(order: orders):
  o = orders[order] ! else NOT_FOUND
  require o.customer = viewer and exists roles[principal = viewer, role = 'customer'] else NOT_YOUR_ORDER
  require o.state = 'awaiting' else BAD_STATE
  require now < (o.approvalDue ?? 0) else APPROVAL_EXPIRED 'The seven-day approval window has closed. Ask the shop to resend.'
  return update orders[order] { state: 'approved', approvedAt: now }

mutation advanceWork(order: orders):
  require exists roles[principal = viewer, role = 'framer'] or exists roles[principal = viewer, role = 'owner'] else NOT_FRAMER
  o = orders[order] ! else NOT_FOUND
  require o.state = 'approved' or o.state = 'cutting' or o.state = 'joining' or o.state = 'fitting' else BAD_STATE
  next = 'cutting' if o.state = 'approved' else 'joining' if o.state = 'cutting' else 'fitting' if o.state = 'joining' else 'fitted'
  return update orders[order] { state: next }

mutation pickupNotice(order: orders):
  require exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'owner'] else NOT_COUNTER
  o = orders[order] ! else NOT_FOUND
  require o.state = 'fitted' else BAD_STATE
  return update orders[order] { state: 'ready', pickupAt: now, storageDue: now + 60d }

mutation collectOrder(order: orders):
  require exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'owner'] else NOT_COUNTER
  o = orders[order] ! else NOT_FOUND
  require o.state = 'ready' or o.state = 'storage' else BAD_STATE
  fee = 2500 if now >= (o.storageDue ?? 0) else o.storageFee
  return update orders[order] { state: 'collected', storageFee: fee }

mutation reportDamage(order: orders, damaged: text 1..500, reason: text 1..1000):
  require (exists roles[principal = viewer, role = 'counter'] or exists roles[principal = viewer, role = 'framer'] or exists roles[principal = viewer, role = 'owner']) else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.state = 'approved' or o.state = 'cutting' or o.state = 'joining' or o.state = 'fitting' or o.state = 'fitted' or o.state = 'ready' else BAD_STATE
  return update orders[order] { state: 'damaged', damaged, damageWhy: reason }

mutation approveRedo(order: orders, approval: text 1..1000):
  require exists roles[principal = viewer, role = 'owner'] else NOT_OWNER
  o = orders[order] ! else NOT_FOUND
  require o.state = 'damaged' else BAD_STATE
  damaged = o.damaged ! else NO_DAMAGE
  reason = o.damageWhy ! else NO_REASON
  insert redos { order, damaged, reason, approval, approvedBy: viewer }
  return update orders[order] { state: 'approved', redoCount: o.redoCount + 1, pickupAt: null, storageDue: null, storageFee: 0 }

job deadlines():
  for o in orders:
    if o.state = 'awaiting' and (o.approvalDue ?? 0) <= now:
      update orders[o.id] { state: 'expired' }
    if o.state = 'ready' and (o.storageDue ?? 0) <= now:
      update orders[o.id] { state: 'storage', storageFee: 2500 }

schedule deadlineSweep every 1m: deadlines

-- Glazing edits use a dedicated operation; workflow writes must retain the cell.
mutation changeGlazing(order: orders, glazingChoice: enum('standard', 'non-glare', 'museum')):
  require exists roles[principal = viewer, role = 'counter'] else NOT_COUNTER
  o = orders[order] ! else NOT_FOUND
  return update orders[order] { glazingChoice }

invariant orders.glazingChoice update only exists roles[principal = viewer, role = 'counter']
