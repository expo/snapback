use identity password

table roles:
  principal: principal
  role: enum('jumper', 'student', 'instructor', 'manifest', 'adviser')
  unique principal
  immutable principal
  read <- viewer != null
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table eligibility:
  owner: principal
  name: text 1..80 default 'New jumper'
  reservePaperwork: enum('dated evidence', 'undated evidence', 'evidence missing') default 'evidence missing'
  repackAt: time ?
  lastJump: time
  grounded: bool default false
  solo: bool default false
  instructor: principal ?
  unique owner
  immutable owner
  read <- .owner = viewer or exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'adviser'] or .instructor = viewer
  insert <- viewer = 'service:operator'
  update (old, next) <- (viewer = 'service:operator' and next.reservePaperwork = old.reservePaperwork) or exists roles[viewer, role = 'adviser'] or (old.owner = viewer and next.lastJump = old.lastJump and next.grounded = old.grounded and next.solo = old.solo and next.instructor = old.instructor and next.reservePaperwork = old.reservePaperwork) or (exists roles[viewer, role = 'manifest'] and next.name = old.name and next.repackAt = old.repackAt and next.grounded = old.grounded and next.solo = old.solo and next.instructor = old.instructor and next.reservePaperwork = old.reservePaperwork)
  online only

table documents:
  owner: principal
  repackAt: time
  repack: image <=5000000
  license: image <=5000000
  unique owner
  immutable owner
  read <- .owner = viewer
  insert <- .owner = viewer
  update <- .owner = viewer
  online only

table loads:
  title: text 1..80
  plane: text 1..30
  capacity: int 1..24
  state: enum('open', 'departed') default 'open'
  createdAt: time default now
  departedAt: time ?
  read <- viewer != null
  insert <- exists roles[viewer, role = 'manifest']
  update <- exists roles[viewer, role = 'manifest']
  online only

table bookings:
  load: loads
  owner: principal
  kind: enum('solo', 'refresher', 'instruction')
  companion: principal ?
  at: time default now
  unique load, owner else ALREADY_BOOKED
  cap 24 by load
  immutable load, owner, kind, companion
  read <- .owner = viewer or exists roles[viewer, role = 'manifest']
  insert <- .owner = viewer or exists roles[viewer, role = 'manifest']
  delete <- .owner = viewer or exists roles[viewer, role = 'manifest']
  online only
table manifestSeats:
  load: loads
  owner: principal
  kind: enum('solo', 'refresher', 'instruction')
  companion: principal ?
  active: bool default true
  unique load, owner
  cap 500 by load
  immutable load, owner
  read <- exists roles[viewer, role = 'manifest']
  insert <- .owner = viewer or exists roles[viewer, role = 'manifest']
  update <- .owner = viewer or exists roles[viewer, role = 'manifest']
  online only
view occupancy: count bookings by .load
  read <- viewer != null

table logbook:
  owner: principal
  load: loads
  kind: enum('solo', 'refresher', 'instruction')
  instructor: principal ?
  at: time default now
  immutable owner, load, kind, instructor, at
  read <- .owner = viewer
  insert <- exists roles[viewer, role = 'manifest']
  online only

table progress:
  student: principal
  instructor: principal
  note: text 1..500
  at: time default now
  immutable student, instructor, note, at
  read <- .student = viewer or exists eligibility[owner = .student, instructor = viewer]
  insert <- .instructor = viewer and exists eligibility[owner = .student, instructor = viewer]
  online only

table decisions:
  subject: principal
  adviser: principal
  action: enum('clearSolo', 'ground')
  reason: text 5..500
  at: time default now
  immutable subject, adviser, action, reason, at
  read <- .subject = viewer or exists roles[viewer, role = 'adviser']
  insert <- .adviser = viewer and exists roles[viewer, role = 'adviser']
  online only

mutation provision(principal: principal, role: enum('jumper', 'student', 'instructor', 'manifest', 'adviser'), lastJump: time ?):
  require viewer = 'service:operator' else NOT_OPERATOR
  require lastJump = null or lastJump <= now else FUTURE_DATE
  enrolled = exists roles[principal = principal]
  upsert roles[principal = principal] { principal, role }
  if enrolled:
    return update eligibility[owner = principal] { lastJump: lastJump ?? now - 61d, solo: role != 'student' }
  return insert eligibility { owner: principal, lastJump: lastJump ?? now - 61d, solo: role != 'student', reservePaperwork: 'evidence missing' }

query me():
  require viewer != null else SIGN_IN
  return { principal: viewer, role: roles[principal = viewer], safety: eligibility[owner = viewer], today: day(now) }

query directory(c: cursor ?):
  require exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'adviser'] else STAFF_ONLY
  return eligibility last 100 by .id after c { *, role: roles[principal = .owner].role }

query board(c: cursor ?):
  require viewer != null else SIGN_IN
  return loads last 100 by .createdAt after c { id, title, plane, capacity, state, departedAt, occupied: occupancy[.id] }

query myDocuments(owner: principal):
  require owner = viewer else PRIVATE
  return documents[owner = owner]

query myBookings(owner: principal, c: cursor ?):
  require owner = viewer else PRIVATE
  return bookings where .owner = owner last 100 by .at after c

query myLogbook(owner: principal, c: cursor ?):
  require owner = viewer else PRIVATE
  return logbook where .owner = owner last 100 by .at after c

query myDecisions(owner: principal, c: cursor ?):
  require owner = viewer or exists roles[viewer, role = 'adviser'] else PRIVATE
  return decisions where .subject = owner last 100 by .at after c

query students(c: cursor ?):
  require exists roles[viewer, role = 'instructor'] else INSTRUCTOR_ONLY
  return eligibility where .instructor = viewer last 100 by .id after c

query studentProgress(student: principal, c: cursor ?):
  require student = viewer or exists eligibility[owner = student, instructor = viewer] else NOT_YOUR_STUDENT
  return progress where .student = student last 100 by .at after c

mutation saveDocuments(name: text 1..80, repackAt: time, repack: image <=5000000, license: image <=5000000):
  require exists roles[principal = viewer] else NOT_ENROLLED
  require day(repackAt) <= day(now) and repackAt >= 0 else FUTURE_DATE
  upsert documents[owner = viewer] { owner: viewer, repackAt, repack, license }
  return update eligibility[owner = viewer] { name, repackAt }

mutation assignInstructor(student: principal, instructor: principal):
  require exists roles[viewer, role = 'adviser'] else ADVISER_ONLY
  require exists roles[student, role = 'student'] else NOT_STUDENT
  require exists roles[instructor, role = 'instructor'] else NOT_INSTRUCTOR
  return update eligibility[owner = student] { instructor }

mutation addProgress(student: principal, note: text 1..500):
  require exists roles[viewer, role = 'instructor'] else INSTRUCTOR_ONLY
  require exists eligibility[owner = student, instructor = viewer] else NOT_YOUR_STUDENT
  return insert progress { student, instructor: viewer, note }

mutation clearSolo(student: principal, reason: text 5..500):
  require exists roles[viewer, role = 'adviser'] else ADVISER_ONLY
  require exists roles[student, role = 'student'] else NOT_STUDENT
  insert decisions { subject: student, adviser: viewer, action: 'clearSolo', reason }
  return update eligibility[owner = student] { solo: true }

mutation ground(jumper: principal, reason: text 5..500):
  require exists roles[viewer, role = 'adviser'] else ADVISER_ONLY
  insert decisions { subject: jumper, adviser: viewer, action: 'ground', reason }
  return update eligibility[owner = jumper] { grounded: true }

mutation createLoad(title: text 1..80, plane: text 1..30, capacity: int 1..24):
  require exists roles[viewer, role = 'manifest'] else MANIFEST_ONLY
  return insert loads { title, plane, capacity }

fn safe(jumper: principal):
  e = eligibility[owner = jumper] ! else NOT_FOUND
  require not e.grounded else GROUNDED
  require e.repackAt != null else DOCUMENTS_REQUIRED
  require day(now) - day(e.repackAt) <= 180 else REPACK_EXPIRED
  return e

mutation book(load: loads, jumper: principal, kind: enum('solo', 'refresher')):
  require jumper = viewer or exists roles[viewer, role = 'manifest'] else NOT_YOURS
  l = loads[load] ! else NOT_FOUND
  require l.state = 'open' else LOAD_DEPARTED
  e = safe(jumper)
  require not exists bookings[load, jumper] else ALREADY_BOOKED
  if kind = 'refresher':
    require exists roles[viewer, role = 'manifest'] else MANIFEST_REFRESHER
    require exists roles[jumper, role = 'student'] else NOT_STUDENT
    require e.instructor != null else INSTRUCTOR_REQUIRED
    i = safe(e.instructor)
    require (occupancy[load] ?? 0) + 2 <= l.capacity else FULL
    require not exists bookings[load, e.instructor] else INSTRUCTOR_BOOKED
    upsert manifestSeats[load, e.instructor] { load, owner: e.instructor, active: true, kind: 'instruction', companion: jumper }
    upsert manifestSeats[load, jumper] { load, owner: jumper, active: true, kind, companion: e.instructor }
    insert bookings { load, owner: e.instructor, kind: 'instruction', companion: jumper }
    return insert bookings { load, owner: jumper, kind, companion: e.instructor }
  require e.solo else SOLO_NOT_CLEARED
  if exists roles[jumper, role = 'student']:
    require day(now) - day(e.lastJump) <= 60 else REFRESHER_REQUIRED
  require (occupancy[load] ?? 0) < l.capacity else FULL
  upsert manifestSeats[load, jumper] { load, owner: jumper, active: true, kind, companion: null }
  return insert bookings { load, owner: jumper, kind, companion: null }

mutation cancel(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  l = loads[b.load] ! else NOT_FOUND
  require l.state = 'open' else LOAD_DEPARTED
  if b.companion != null:
    require exists roles[viewer, role = 'manifest'] else MANIFEST_REFRESHER
    update manifestSeats[b.load, b.companion] { active: false }
    delete bookings[b.load, b.companion]
  update manifestSeats[b.load, b.owner] { active: false }
  delete bookings[booking]

mutation depart(load: loads):
  require exists roles[viewer, role = 'manifest'] else MANIFEST_ONLY
  l = loads[load] ! else NOT_FOUND
  require l.state = 'open' else LOAD_DEPARTED
  require (occupancy[load] ?? 0) > 0 else EMPTY_LOAD
  passengers = manifestSeats where .load = load and .active = true first 24 by .id
  for b in passengers:
    e = safe(b.owner)
    if b.kind = 'solo':
      require e.solo else SOLO_NOT_CLEARED
      if exists roles[b.owner, role = 'student']:
        require day(now) - day(e.lastJump) <= 60 else REFRESHER_REQUIRED
  for b in passengers:
    insert logbook { owner: b.owner, load, kind: b.kind, instructor: b.companion if b.kind = 'refresher' else null }
    update eligibility[owner = b.owner] { lastJump: now }
  return update loads[load] { state: 'departed', departedAt: now }

mutation setReservePaperwork(jumper: principal, label: enum('dated evidence', 'undated evidence', 'evidence missing')):
  require exists roles[viewer, role = 'adviser'] else ADVISER_ONLY
  return update eligibility[owner = jumper] { reservePaperwork: label }
