use identity password

table roles:
  principal: principal
  role: enum('volunteer', 'supervisor', 'familyServices', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('volunteer', 'supervisor', 'familyServices', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query me():
  return roles[viewer]

query crew():
  require exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'manager'] else NOT_CONSTRUCTION_STAFF
  return roles where .role = 'volunteer' first 100 by .id

table sites:
  supervisor: principal
  name: text 1..100
  address: text 5..240
  closed: bool default false
  closureReason: text <=500 default ''
  immutable supervisor
  read <- exists roles[viewer]
  insert <- .supervisor = viewer and exists roles[viewer, role = 'supervisor']
  update <- exists roles[viewer, role = 'manager']
  online only

table families:
  site: sites
  income: int 0..100000000
  mortgageTerms: text 1..2000
  contact: text 3..500
  unique site
  immutable site
  read <- exists roles[viewer, role = 'familyServices']
  insert <- exists roles[viewer, role = 'familyServices']
  update <- exists roles[viewer, role = 'familyServices']
  online only

table tasks:
  site: sites
  author: principal
  title: text 1..140
  instructions: text 1..2000
  buildPlanUrl: text <=1000 renamed from planUrl
  photoUrl: text <=1000
  progress: int 0..100 default 0
  sawRequired: bool
  immutable site, author
  read <- exists roles[viewer]
  insert <- .author = viewer and .site.supervisor = viewer and exists roles[viewer, role = 'supervisor']
  update <- .author = viewer and .site.supervisor = viewer and exists roles[viewer, role = 'supervisor']
  online only

table safety:
  principal: principal
  completedAt: time ?
  sawApproved: bool default false
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'manager']
  online only

table signups:
  task: tasks
  principal: principal
  minutes: int 0..720 default 0
  cancelled: bool default false
  unique task, principal
  immutable task, principal
  read <- .principal = viewer
  insert <- .principal = viewer and exists roles[viewer, role = 'volunteer']
  update <- .principal = viewer and exists roles[viewer, role = 'volunteer']
  online only

view taskTotals: count signups where not .cancelled by .task
  read <- exists roles[viewer]
  disclosure reviewed 'The board discloses only aggregate signup counts, never identities or hours.'
  online only

fn orientationExpiry(completed: time):
  target = monthStart(month(completed) + 12)
  offsetDays = day(completed) - day(monthStart(month(completed)))
  lastDay = (monthStart(month(completed) + 13) - target) / 1d - 1
  return target + min(offsetDays, lastDay) * 1d + (completed % 1d)

query siteBoard():
  require exists roles[viewer] else NO_ROLE
  return sites first 100 by .id

query taskBoard(site: sites):
  require exists roles[viewer] else NO_ROLE
  return tasks where .site = site first 100 by .id { *, planUrl: .buildPlanUrl, signupCount: taskTotals[.id] }

query familyFor(site: sites):
  require exists roles[viewer, role = 'familyServices'] else FAMILY_PRIVATE
  return families[site]

query mySignups(owner: principal):
  require owner = viewer else SIGNUPS_PRIVATE
  return signups where .principal = owner first 200 by .id

query signupFor(record: signups):
  return signups[record]

query safetyFor(who: principal):
  s = safety[who]
  return { record: s, expiresAt: orientationExpiry(s.completedAt) if s.completedAt != null else null, current: s.completedAt != null and now < orientationExpiry(s.completedAt) }

mutation createSite(name: text 1..100, address: text 5..240):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  return insert sites { supervisor: viewer, name, address }

mutation closeSite(site: sites, reason: text 3..500):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  update sites[site] { closed: true, closureReason: reason }

mutation saveFamily(site: sites, income: int 0..100000000, mortgageTerms: text 1..2000, contact: text 3..500):
  require exists roles[viewer, role = 'familyServices'] else FAMILY_PRIVATE
  require exists sites[site] else NOT_FOUND
  return upsert families[site] { site, income, mortgageTerms, contact }

mutation postTask(site: sites, title: text 1..140, instructions: text 1..2000, buildPlanUrl: text <=1000 alias planUrl, photoUrl: text <=1000, sawRequired: bool):
  s = sites[site] ! else NOT_FOUND
  require exists roles[viewer, role = 'supervisor'] and s.supervisor = viewer else NOT_SITE_SUPERVISOR
  require not s.closed else SITE_CLOSED
  postedTask = insert tasks { site, author: viewer, title, instructions, buildPlanUrl, photoUrl, sawRequired }
  return postedTask { *, planUrl: .buildPlanUrl }

mutation updateTask(task: tasks, progress: int 0..100, photoUrl: text <=1000, buildPlanUrl: text <=1000 alias planUrl):
  t = tasks[task] ! else NOT_FOUND
  require t.author = viewer and exists roles[viewer, role = 'supervisor'] else NOT_SITE_SUPERVISOR
  siteRow = sites[t.site] ! else NOT_FOUND
  require not siteRow.closed else SITE_CLOSED
  update tasks[task] { progress, photoUrl, buildPlanUrl }
  return tasks[task] { *, planUrl: .buildPlanUrl }

mutation recordOrientation(who: principal, completedAt: time):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  require exists roles[who, role = 'volunteer'] else NOT_VOLUNTEER
  require completedAt <= now and completedAt >= 946684800000 else INVALID_COMPLETION
  return upsert safety[who] { principal: who, completedAt }

mutation approveSaws(who: principal):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require exists roles[who, role = 'volunteer'] else NOT_VOLUNTEER
  return upsert safety[who] { principal: who, sawApproved: true }

mutation signupTask(task: tasks):
  require exists roles[viewer, role = 'volunteer'] else NOT_VOLUNTEER
  t = tasks[task] ! else NOT_FOUND
  siteRow = sites[t.site] ! else NOT_FOUND
  require not siteRow.closed else SITE_CLOSED
  s = safety[viewer] ! else ORIENTATION_REQUIRED
  require s.completedAt != null else ORIENTATION_REQUIRED
  require now < orientationExpiry(s.completedAt) else ORIENTATION_EXPIRED
  require not t.sawRequired or s.sawApproved else SAW_APPROVAL_REQUIRED
  require not exists signups[task, viewer, cancelled = false] else ALREADY_SIGNED_UP
  return upsert signups[task, viewer] { task, principal: viewer, cancelled: false, minutes: 0 }

mutation logHours(record: signups, minutes: int 1..720):
  s = signups[record] ! else NOT_FOUND
  require s.principal = viewer else SIGNUPS_PRIVATE
  update signups[record] { minutes }

mutation cancelSignup(record: signups):
  s = signups[record] ! else NOT_FOUND
  require s.principal = viewer else SIGNUPS_PRIVATE
  update signups[record] { cancelled: true }

-- Independent build-plan replacement/removal, protected even for signed-up volunteers.
mutation replaceBuildPlans(task: tasks, buildPlanUrl: text <=1000):
  t = tasks[task] ! else NOT_FOUND
  s = sites[t.site] ! else NOT_FOUND
  require exists roles[viewer, role = 'supervisor'] and s.supervisor = viewer and t.author = viewer else NOT_SITE_SUPERVISOR
  require not s.closed else SITE_CLOSED
  update tasks[task] { buildPlanUrl }
