use identity password

table roles:
  principal: principal
  role: enum('pianist', 'teacher', 'office', 'juror', 'chair')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'chair'] or .role = 'teacher' and exists roles[principal = viewer, role = 'pianist']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('pianist', 'teacher', 'office', 'juror', 'chair')):
  require viewer = 'service:operator' else NOT_OPERATOR
  upsert roles[principal] { principal, role }

fn office(): exists roles[principal = viewer, role = 'office']
fn chair(): exists roles[principal = viewer, role = 'chair']
fn entrant(): exists roles[principal = viewer, role = 'pianist'] or exists roles[principal = viewer, role = 'teacher']

query myRole():
  return roles[principal = viewer]
query teachers(c: cursor ?):
  require entrant() else NOT_ENTRANT
  return roles where .role = 'teacher' first 100 by .id after c
query jurors(c: cursor ?):
  require office() or chair() else NOT_OFFICE
  return roles where .role = 'juror' first 100 by .id after c

table entries:
  age: int 5..18
  ageGroup: enum('Junior 5–10', 'Intermediate 11–14', 'Senior 15–18')
  repertoire: text 10..3000
  video: video <=50000000
  status: enum('submitted', 'screening', 'accepted', 'assigned', 'scored', 'decided')
  submittedAt: time
  immutable age, ageGroup, repertoire, video, submittedAt
  read <- exists grants[.id, viewer] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'chair']
  insert <- exists roles[principal = viewer, role = 'pianist'] or exists roles[principal = viewer, role = 'teacher']
  update <- exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'chair'] or exists roles[principal = viewer, role = 'juror']
  online only

table identities:
  entry: entries
  pianist: principal ?
  teacher: principal
  name: text 2..100
  hometown: text 2..100
  certificate: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?
  identityEvidenceLabel: enum('certificate supplied', 'certificate missing') default 'certificate supplied' read <- exists roles[principal = viewer, role = 'office']
  unique entry
  immutable entry, pianist, teacher, name, hometown
  read <- .pianist = viewer or .teacher = viewer or exists roles[principal = viewer, role = 'office']
  insert <- .pianist = viewer or .teacher = viewer
  update <- exists roles[principal = viewer, role = 'office']
  online only

table grants:
  entry: entries
  principal: principal
  until: time ?
  unique entry, principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'chair']
  insert <- .principal = viewer or exists roles[principal = viewer, role = 'office'] or created entries[.entry]
  update <- exists roles[principal = viewer, role = 'office']
  delete <- exists roles[principal = viewer, role = 'office']
  expire at .until
  online only

table assignments:
  entry: entries
  juror: principal
  dueAt: time
  assignedAt: time
  scored: bool
  round: int 1..
  unique entry
  immutable entry
  read <- .juror = viewer or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'chair']
  insert <- exists roles[principal = viewer, role = 'office']
  update <- exists roles[principal = viewer, role = 'office'] or .juror = viewer
  online only

table scores:
  entry: entries
  juror: principal
  value: int 0..100
  comment: text 1..1000
  at: time
  unique entry, juror
  read <- exists roles[principal = viewer, role = 'chair']
  insert <- .juror = viewer and exists roles[principal = viewer, role = 'juror']
  online only

table decisions:
  entry: entries
  kind: enum('tie-break', 'disqualified')
  reason: text 5..1000
  actor: principal
  at: time
  unique entry
  read <- exists grants[.entry, viewer] or exists roles[principal = viewer, role = 'office'] or exists roles[principal = viewer, role = 'chair']
  insert <- .actor = viewer and exists roles[principal = viewer, role = 'chair']
  online only

mutation submitEntry(name: text 2..100, hometown: text 2..100, age: int 5..18, repertoire: text 10..3000, teacher: principal, certificate: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?, video: video <=50000000):
  require entrant() else NOT_ENTRANT
  require len(trim(name)) >= 2 and len(trim(hometown)) >= 2 and len(trim(repertoire)) >= 10 else BLANK_FIELDS
  require exists roles[principal = teacher, role = 'teacher'] else NOT_TEACHER
  isTeacher = exists roles[principal = viewer, role = 'teacher']
  require not isTeacher or teacher = viewer else NOT_YOUR_STUDENT
  e = insert entries { age, ageGroup: 'Junior 5–10' if age <= 10 else 'Intermediate 11–14' if age <= 14 else 'Senior 15–18', repertoire, video, status: 'submitted', submittedAt: now }
  insert grants { entry: e.id, principal: viewer, until: null }
  if teacher != viewer:
    insert grants { entry: e.id, principal: teacher, until: null }
  insert identities { entry: e.id, pianist: null if isTeacher else viewer, teacher, name, hometown, certificate, identityEvidenceLabel: 'certificate missing' if certificate = null else 'certificate supplied' }
  return e.id

query listEntries(c: cursor ?):
  require exists roles[principal = viewer] else NO_ROLE
  return entries last 100 by .id after c
query entry(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  return e
query identity(entry: entries):
  return identities[entry]
query assignment(entry: entries):
  return assignments[entry]
query result(entry: entries):
  return decisions[entry]
query chairScores(entry: entries, c: cursor ?):
  require chair() else NOT_CHAIR
  return scores where .entry = entry first 100 by .id after c

mutation screen(entry: entries, status: enum('screening', 'accepted')):
  require office() else NOT_OFFICE
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'submitted' or e.status = 'screening' else WRONG_STAGE
  update entries[entry] { status }

mutation assign(entry: entries, juror: principal):
  require office() else NOT_OFFICE
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'accepted' else WRONG_STAGE
  require exists roles[principal = juror, role = 'juror'] else NOT_JUROR
  insert assignments { entry, juror, dueAt: now + 10d, assignedAt: now, scored: false, round: 1 }
  insert grants { entry, principal: juror, until: now + 10d }
  update entries[entry] { status: 'assigned' }

mutation score(entry: entries, value: int 0..100, comment: text 1..1000):
  require exists roles[principal = viewer, role = 'juror'] else NOT_JUROR
  a = assignments[entry] ! else NOT_ASSIGNED
  require a.juror = viewer else NOT_ASSIGNED
  require now < a.dueAt else DEADLINE_PASSED
  require not a.scored else ALREADY_SCORED
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'assigned' else WRONG_STAGE
  insert scores { entry, juror: viewer, value, comment, at: now }
  update assignments[entry] { scored: true }
  update entries[entry] { status: 'scored' }

mutation decide(entry: entries, kind: enum('tie-break', 'disqualified'), reason: text 5..1000):
  require chair() else NOT_CHAIR
  require len(trim(reason)) >= 5 else REASON_REQUIRED
  e = entries[entry] ! else NOT_FOUND
  require e.status != 'decided' else ALREADY_DECIDED
  require kind = 'disqualified' or e.status = 'scored' else NOT_SCORED
  insert decisions { entry, kind, reason, actor: viewer, at: now }
  update entries[entry] { status: 'decided' }

job reassign():
  for a in assignments:
    if not a.scored and a.dueAt <= now:
      e = entries[a.entry]
      if e != null and e.status = 'assigned':
        for candidate in roles where .role = 'juror' first 100 by .id:
          if candidate.principal != a.juror:
            update assignments[a.id] { juror: candidate.principal, dueAt: now + 10d, assignedAt: now, round: a.round + 1 }
            upsert grants[a.entry, candidate.principal] { entry: a.entry, principal: candidate.principal, until: now + 10d }
            break
schedule assignmentDeadlines every 1m: reassign


mutation setCertificate(entry: entries, certificate: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?):
  require office() else NOT_OFFICE
  i = identities[entry] ! else NOT_FOUND
  update identities[i.id] { certificate, identityEvidenceLabel: 'certificate missing' if certificate = null else 'certificate supplied' }
