-- Search Rescue Callouts.
-- Roles: member, team_leader, incident_commander. Roster is operator-provisioned.
-- All tables are online only: the board is live and needs no offline partition.

use identity password

table roles:
  principal: principal
  role: enum('member', 'team_leader', 'incident_commander')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('member', 'team_leader', 'incident_commander')):
  require viewer = 'service:operator' else NOT_OPERATOR 'Only the local operator may provision roles.'
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

-- First aid (and other) certificates. A member uploads their own photo.
-- Leaders and the incident commander may read every record (they must verify
-- currency before assigning); members read only their own.
table trainingRecords:
  member: principal
  certType: text 1..40
  issuedAt: time
  validUntil: time
  photo: image <=8000000 ?
  photoCount: int default 0 read <- .member = viewer or exists roles[principal = viewer, role = 'incident_commander']
  uploadedAt: time default now
  immutable member, certType, issuedAt, validUntil
  read <- .member = viewer or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander']
  insert <- .member = viewer
  update <- .member = viewer
  delete <- .member = viewer
  cap 50 by member
  online only

-- A paged search. Every enrolled member can read open pages; leaders and the
-- incident commander also see closed ones. Only leaders / the commander page.
table callouts:
  title: text 1..120
  description: text 1..2000
  status: enum('open', 'closed') default 'open'
  createdBy: principal
  createdAt: time default now
  closedReason: text 1..500 ?
  closedAt: time ?
  immutable createdBy, createdAt
  read <- exists roles[principal = viewer]
  insert <- exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] or viewer = 'service:operator'
  update <- exists roles[principal = viewer, role = 'incident_commander'] or viewer = 'service:operator'
  delete <- deny
  cap 500
  online only

-- Availability answers. A member reads only their own history;
-- leaders and the incident commander read the whole board.
table responses:
  callout: callouts
  member: principal
  availability: enum('available', 'unavailable', 'en_route')
  at: time default now
  immutable callout, member
  unique callout, member
  read <- .member = viewer or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander']
  insert <- .member = viewer
  update <- .member = viewer
  delete <- .member = viewer
  cap 500 by callout
  online only

table teams:
  callout: callouts
  name: text 1..80
  status: enum('active', 'stood_down') default 'active'
  standDownReason: text 1..500 ?
  createdAt: time default now
  lastRadioCheck: time ?
  immutable callout, createdAt
  read <- exists roles[principal = viewer]
  insert <- exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] or viewer = 'service:operator'
  -- Assigned members may update their team's row only through the checkIn
  -- mutation (the only member-callable mutation that writes teams, and it
  -- sets lastRadioCheck alone); stand-down stays commander-only there.
  update <- exists assignments[team = .id, member = viewer] or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] or viewer = 'service:operator'
  delete <- deny
  cap 20 by callout
  online only

table assignments:
  team: teams
  member: principal
  assignedAt: time default now
  immutable team, member
  unique team, member
  read <- .member = viewer or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander']
  insert <- exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] or viewer = 'service:operator'
  update <- deny
  delete <- exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] or viewer = 'service:operator'
  cap 30 by team
  online only

table checkins:
  team: teams
  checkedBy: principal
  note: text 1..500 ?
  at: time default now
  immutable team, checkedBy, at
  read <- .checkedBy = viewer or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander']
  insert <- .checkedBy = viewer
  update <- deny
  delete <- deny
  cap 500 by team
  online only

table clues:
  team: teams
  foundBy: principal
  note: text 1..500
  photo: image <=8000000 ?
  at: time default now
  immutable team, foundBy, at
  read <- .foundBy = viewer or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander']
  insert <- .foundBy = viewer
  update <- deny
  delete <- deny
  cap 200 by team
  online only

query openCallouts(c: cursor ?):
  require exists roles[principal = viewer] else NOT_ENROLLED 'Only enrolled team members may read callouts.'
  return callouts where .status = 'open' last 50 by .createdAt after c

query allCallouts(c: cursor ?):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may list every callout.'
  return callouts last 50 by .createdAt after c

query myTraining(c: cursor ?):
  return trainingRecords where .member = viewer last 50 by .uploadedAt after c

query trainingOf(member: principal, c: cursor ?):
  return trainingRecords where .member = member last 50 by .uploadedAt after c

query myResponses(c: cursor ?):
  return responses where .member = viewer last 50 by .at after c

query calloutResponses(callout: callouts, c: cursor ?):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may read the response board.'
  return responses where .callout = callout first 100 by .id after c

query boardTeams(callout: callouts, c: cursor ?):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may read the live board.'
  return teams where .callout = callout first 50 by .id after c

query teamMembers(team: teams, c: cursor ?):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may read team rosters.'
  return assignments where .team = team first 50 by .id after c

query myAssignments(c: cursor ?):
  return assignments where .member = viewer first 50 by .id after c

query teamCheckins(team: teams, c: cursor ?):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may read radio checks.'
  return checkins where .team = team last 50 by .at after c

query teamClues(team: teams, c: cursor ?):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may read clues.'
  return clues where .team = team last 50 by .at after c

-- A team not heard from more than an hour after its last radio check
-- (or more than an hour after it was formed, when it never checked in).
query overdueTeams(callout: callouts):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_LEADER 'Only team leaders and the incident commander may read overdue flags.'
  return teams where .callout = callout and .status = 'active' and ((.lastRadioCheck = null and .createdAt < now - 1h) or (.lastRadioCheck != null and .lastRadioCheck < now - 1h)) first 50 by .id

query firstAidCert(member: principal):
  m = member
  require m = viewer or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_PERMITTED 'Members may read only their own certificates.'
  return trainingRecords where .member = m and .certType = 'first_aid' last 5 by .issuedAt

mutation pageCallout(title: text 1..120, description: text 1..2000):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_PERMITTED 'Only team leaders and the incident commander may page a callout.'
  return insert callouts { title, description, status: 'open', createdBy: viewer }

mutation respond(callout: callouts, availability: enum('available', 'unavailable', 'en_route')):
  c = callouts[callout] ! else NOT_FOUND
  require c.status = 'open' else CALLOUT_CLOSED 'This callout is closed.'
  return upsert responses[callout, viewer] { callout, member: viewer, availability, at: now }

mutation uploadCertificate(certType: text 1..40, issuedAt: time, photo: image <=8000000 ?):
  require issuedAt <= now else ISSUED_IN_FUTURE 'A certificate cannot be issued in the future.'
  require issuedAt >= now - 3650d else TOO_OLD 'A certificate issued more than ten years ago cannot be registered.'
  return insert trainingRecords { member: viewer, certType, issuedAt, validUntil: issuedAt + 730d, photo, photoCount: 1 if photo != null else 0 }

-- No mutation edits trainingRecords rows after insert (the photo is
-- write-once through uploadCertificate), so the count stays aligned by
-- construction. This also keeps rollback/forward safe: the backfill input
-- below never changes after a row gains the column, and a changed input
-- would wedge forward with E_ADOPT.

mutation createTeam(callout: callouts, name: text 1..80):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_PERMITTED 'Only team leaders and the incident commander may form a search team.'
  c = callouts[callout] ! else NOT_FOUND
  require c.status = 'open' else CALLOUT_CLOSED 'This callout is closed.'
  return insert teams { callout, name, status: 'active' }

-- A member whose first aid certificate lapsed (issued more than two years
-- ago) cannot be assigned to a search team.
mutation assignMember(team: teams, member: principal):
  require exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_PERMITTED 'Only team leaders and the incident commander may assign members.'
  t = teams[team] ! else NOT_FOUND
  require t.status = 'active' else TEAM_STOOD_DOWN 'This team was stood down.'
  fresh = false
  for r in trainingRecords where .member = member and .certType = 'first_aid' by .issuedAt:
    if r.validUntil >= now:
      fresh = true
  require fresh else CERT_LAPSED 'This member has no valid first aid certificate.'
  if exists assignments[team, member]:
    return assignments[team, member]
  return insert assignments { team, member }

mutation checkIn(team: teams, note: text 1..500 ?, at: time ?):
  t = teams[team] ! else NOT_FOUND
  require t.status = 'active' else TEAM_STOOD_DOWN 'This team was stood down.'
  require exists assignments[team, viewer] or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_ON_TEAM 'Only assigned members, team leaders and the incident commander may log a radio check.'
  stamp = at ?? now
  update teams[team] { lastRadioCheck: stamp }
  return insert checkins { team, checkedBy: viewer, note, at: stamp }

mutation attachClue(team: teams, note: text 1..500, photo: image <=8000000 ?, at: time ?):
  t = teams[team] ! else NOT_FOUND
  require t.status = 'active' else TEAM_STOOD_DOWN 'This team was stood down.'
  require exists assignments[team, viewer] or exists roles[principal = viewer, role = 'team_leader'] or exists roles[principal = viewer, role = 'incident_commander'] else NOT_ON_TEAM 'Only assigned members, team leaders and the incident commander may attach clues.'
  return insert clues { team, foundBy: viewer, note, photo, at: at ?? now }

mutation closeSearch(callout: callouts, reason: text 1..500):
  require exists roles[principal = viewer, role = 'incident_commander'] else NOT_PERMITTED 'Only the incident commander may close a search.'
  c = callouts[callout] ! else NOT_FOUND
  require c.status = 'open' else ALREADY_CLOSED 'This callout is already closed.'
  update callouts[callout] { status: 'closed', closedReason: reason, closedAt: now }
  return null

mutation standDownTeam(team: teams, reason: text 1..500):
  require exists roles[principal = viewer, role = 'incident_commander'] else NOT_PERMITTED 'Only the incident commander may stand down a team.'
  t = teams[team] ! else NOT_FOUND
  require t.status = 'active' else ALREADY_STOOD_DOWN 'This team is already stood down.'
  update teams[team] { status: 'stood_down', standDownReason: reason }
  return null

-- v2 migration: every pre-existing training record gains the photo count
-- implied by the photo already attached to it (one attachment counts once;
-- no photo counts zero). Applies on deploy and catches up older writes on
-- forward.
backfill trainingRecords photoCount(photo: image <=8000000 ?):
  {photoCount: 1 if photo != null else 0}
