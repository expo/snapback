use identity password

table roles:
  principal: principal
  role: enum('coordinator', 'driver', 'rider', 'director')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or (.role = 'rider' and exists roles[viewer, role = 'coordinator'])
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('coordinator', 'driver', 'rider', 'director')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query me():
  return roles[viewer]

query riders():
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  return roles where .role = 'rider' first 200 by .id

table rides:
  rider: principal
  pickup: text 5..240
  destination: text 3..160
  appointmentAt: time
  requestedAt: time
  status: enum('pending', 'open', 'claimed')
  driver: principal ?
  approvedBy: principal ?
  immutable rider, pickup, destination, appointmentAt, requestedAt
  read <- exists roles[viewer, role = 'coordinator'] or (.status = 'pending' and exists roles[viewer, role = 'director']) or (.rider = viewer and exists roles[viewer, role = 'rider']) or (exists roles[viewer, role = 'driver'] and (.status = 'open' or .driver = viewer))
  insert <- exists roles[viewer, role = 'coordinator']
  update <- exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'driver']
  online only

table privateDetails:
  ride: rides
  phone: text <=30 read <- exists roles[viewer, role = 'coordinator']
  emergencyContact: text <=200 read <- exists roles[viewer, role = 'coordinator']
  medicalReason: text 3..500 read <- exists roles[viewer, role = 'coordinator']
  coverageLabel: enum('phone and emergency contact', 'phone only', 'emergency contact only', 'neither recorded') default 'phone and emergency contact'
  unique ride
  immutable ride
  read <- exists roles[viewer, role = 'coordinator'] or (exists roles[viewer, role = 'rider'] and exists rides[id = .ride, rider = viewer])
  insert <- exists roles[viewer, role = 'coordinator']
  update <- exists roles[viewer, role = 'coordinator']
  online only

invariant privateDetails.coverageLabel read only exists roles[viewer, role = 'coordinator'] or (exists roles[viewer, role = 'rider'] and exists rides[id = .ride, rider = viewer])
invariant privateDetails.phone read only exists roles[viewer, role = 'coordinator']
invariant privateDetails.emergencyContact read only exists roles[viewer, role = 'coordinator']
invariant privateDetails.medicalReason read only exists roles[viewer, role = 'coordinator']
invariant roles.role write only viewer = 'service:operator'

fn saveRide(rider: principal, pickup: text 5..240, destination: text 3..160, appointmentAt: time, phone: text <=30, emergencyContact: text <=200, medicalReason: text 3..500, late: bool):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  require count(trim(phone)) = 0 or count(trim(phone)) >= 7 else INVALID_PHONE
  require count(trim(emergencyContact)) = 0 or count(trim(emergencyContact)) >= 5 else INVALID_EMERGENCY_CONTACT
  require exists roles[rider, role = 'rider'] else INVALID_RIDER
  require appointmentAt <= now + 365d else TOO_FAR 'Appointments must be within one year.'
  if late:
    require appointmentAt < now + 72h else NOT_LATE
    require appointmentAt >= now - 14d else TOO_OLD 'Retrospective exceptions must be within 14 days.'
  else:
    require appointmentAt >= now + 72h else ADVANCE_NOTICE 'At least 72 hours notice is required; send a late request for director approval.'
  ride = insert rides { rider, pickup, destination, appointmentAt, requestedAt: now, status: 'pending' if late else 'open', driver: null, approvedBy: null }
  insert privateDetails { ride: ride.id, phone: trim(phone), emergencyContact: trim(emergencyContact), medicalReason, coverageLabel: coverage(phone, emergencyContact) }
  return { id: ride.id }

mutation createRide(rider: principal, pickup: text 5..240, destination: text 3..160, appointmentAt: time, phone: text <=30, emergencyContact: text <=200, medicalReason: text 3..500):
  return saveRide(rider, pickup, destination, appointmentAt, phone, emergencyContact, medicalReason, false)

mutation requestLate(rider: principal, pickup: text 5..240, destination: text 3..160, appointmentAt: time, phone: text <=30, emergencyContact: text <=200, medicalReason: text 3..500):
  return saveRide(rider, pickup, destination, appointmentAt, phone, emergencyContact, medicalReason, true)

query listRides():
  return rides last 200 by .id

query ride(ride: rides):
  return rides[ride]

query privateRide(ride: rides):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  return privateDetails[ride]

mutation approveLate(ride: rides):
  require exists roles[viewer, role = 'director'] else DIRECTOR_ONLY
  row = rides[ride] ! else NOT_FOUND
  require row.status = 'pending' else NOT_PENDING
  update rides[ride] { status: 'open', approvedBy: viewer }
  return { id: ride }

mutation claimRide(ride: rides):
  require exists roles[viewer, role = 'driver'] else DRIVER_ONLY
  row = rides[ride] ! else NOT_FOUND
  require row.status = 'open' else NOT_OPEN
  update rides[ride] { status: 'claimed', driver: viewer } if .status = 'open'
  return { id: ride }

table mileageLogs:
  ride: rides
  driver: principal
  photo: image <=5000000
  miles: int 1..2000
  submittedAt: time
  unique ride
  immutable ride, driver, photo, miles, submittedAt
  read <- (.driver = viewer and exists roles[viewer, role = 'driver']) or exists roles[viewer, role = 'coordinator']
  insert <- .driver = viewer and exists roles[viewer, role = 'driver'] and exists rides[id = .ride, driver = viewer, status = 'claimed']
  online only

query mileage(ride: rides):
  return mileageLogs[ride]

mutation submitMileage(ride: rides, photo: image <=5000000, miles: int 1..2000):
  require exists roles[viewer, role = 'driver'] else DRIVER_ONLY
  row = rides[ride] ! else NOT_FOUND
  require row.driver = viewer and row.status = 'claimed' else NOT_ASSIGNED
  require now >= row.appointmentAt else RIDE_NOT_FINISHED
  require now <= row.appointmentAt + 14d else DEADLINE_PASSED 'Mileage photos are due within 14 days after the appointment.'
  return insert mileageLogs { ride, driver: viewer, photo, miles, submittedAt: now }

fn coverage(phone: text <=30, emergencyContact: text <=200):
  return 'phone and emergency contact' if count(trim(phone)) > 0 and count(trim(emergencyContact)) > 0 else 'phone only' if count(trim(phone)) > 0 else 'emergency contact only' if count(trim(emergencyContact)) > 0 else 'neither recorded'


down privateDetails legacyContacts(phone: text <=30, emergencyContact: text <=200):
  {phone: phone if count(phone) >= 7 else 'Not recorded', emergencyContact: emergencyContact if count(emergencyContact) >= 5 else 'Not recorded'}

query contactCoverage(ride: rides):
  require exists roles[viewer, role = 'coordinator'] or (exists roles[viewer, role = 'rider'] and exists rides[id = ride, rider = viewer]) else CONTACT_COVERAGE_PRIVATE
  details = privateDetails[ride] ! else NOT_FOUND
  return {contactCoverage: details.coverageLabel}

mutation updateContacts(ride: rides, phone: text <=30, emergencyContact: text <=200):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  require count(trim(phone)) = 0 or count(trim(phone)) >= 7 else INVALID_PHONE
  require count(trim(emergencyContact)) = 0 or count(trim(emergencyContact)) >= 5 else INVALID_EMERGENCY_CONTACT
  details = privateDetails[ride] ! else NOT_FOUND
  update privateDetails[details.id] {phone: trim(phone), emergencyContact: trim(emergencyContact), coverageLabel: coverage(phone, emergencyContact)}
  return {id: ride}

-- Release activation reconciles historical values through this idempotent operation.
mutation reconcileCoverage(ride: rides):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  details = privateDetails[ride] ! else NOT_FOUND
  phone = details.phone ! else NOT_FOUND
  emergencyContact = details.emergencyContact ! else NOT_FOUND
  update privateDetails[details.id] {coverageLabel: coverage(phone, emergencyContact)}
  return {id: ride}
