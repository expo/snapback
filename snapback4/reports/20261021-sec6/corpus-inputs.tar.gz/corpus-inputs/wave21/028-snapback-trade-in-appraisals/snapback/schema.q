use identity password

table roles:
  principal: principal
  role: enum('appraiser', 'salesperson', 'manager', 'customer')
  name: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'appraiser'] or exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('appraiser', 'salesperson', 'manager', 'customer'), name: text 1..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, name }

query myRole():
  require exists roles[viewer] else NO_ROLE
  return roles[viewer]

query customers():
  require exists roles[viewer, role = 'appraiser'] or exists roles[viewer, role = 'manager'] else STAFF_ONLY
  return roles where .role = 'customer' first 100 by .id

table appraisals:
  customer: principal
  appraiser: principal
  vehicle: text 3..100
  vin: text 17..17
  mileage: int 0..2000000
  currentMileage: int 0..2000000
  condition: enum('excellent', 'good', 'fair', 'poor')
  notes: text <=3000
  history: text 1..3000
  appraisedAt: time
  expiresAt: time
  recon: int 0..100000000 ? read <- exists roles[viewer, role = 'manager']
  wholesale: int 0..100000000 ? read <- exists roles[viewer, role = 'manager']
  offer: int 0..100000000 ?
  approvalReason: text <=1000 ? read <- exists roles[viewer, role = 'manager']
  approvedBy: principal ?
  acceptedAt: time ?
  immutable customer, appraiser, vehicle, vin, mileage, condition, history, appraisedAt, expiresAt
  read <- .customer = viewer or exists roles[viewer, role = 'appraiser'] or exists roles[viewer, role = 'salesperson'] or exists roles[viewer, role = 'manager']
  insert <- .appraiser = viewer and exists roles[viewer, role = 'appraiser']
  update (old, next) <- (old.customer = viewer or exists roles[viewer, role = 'appraiser'] or exists roles[viewer, role = 'manager']) and (next.notes = old.notes or (old.appraiser = viewer and exists roles[viewer, role = 'appraiser']))
  online only

invariant appraisals.read only .customer = viewer or exists roles[viewer, role = 'appraiser'] or exists roles[viewer, role = 'salesperson'] or exists roles[viewer, role = 'manager']
invariant appraisals.recon read only exists roles[viewer, role = 'manager']
invariant appraisals.wholesale read only exists roles[viewer, role = 'manager']
invariant appraisals.approvalReason read only exists roles[viewer, role = 'manager']

-- The historical storage key remains stable for rollback. Both client generations
-- receive their field spelling from the same scalar; there is no second source of truth.
shape appraisalPublic = { id, customer, appraiser, vehicle, vin, mileage, currentMileage, condition, notes, inspectionObservations: .notes, history, appraisedAt, expiresAt, offer, approvedBy, acceptedAt }
shape appraisalManager = { *, inspectionObservations: .notes }

query queue():
  require exists roles[viewer] else NO_ROLE
  if exists roles[viewer, role = 'manager']:
    return appraisals last 100 by .id appraisalManager
  return appraisals last 100 by .id appraisalPublic

query appraisal(appraisal: appraisals):
  require exists roles[viewer] else NO_ROLE
  if exists roles[viewer, role = 'manager']:
    return appraisals[appraisal] appraisalManager
  return appraisals[appraisal] appraisalPublic

mutation createAppraisal(customer: principal, vehicle: text 3..100, vin: text 17..17, mileage: int 0..2000000, condition: enum('excellent', 'good', 'fair', 'poor'), inspectionObservations: text <=3000 default '' alias notes, history: text 1..3000):
  require exists roles[viewer, role = 'appraiser'] else APPRAISER_ONLY
  require exists roles[customer, role = 'customer'] else CUSTOMER_REQUIRED
  changed = insert appraisals { customer, appraiser: viewer, vehicle, vin, mileage, currentMileage: mileage, condition, notes: inspectionObservations, history, appraisedAt: now, expiresAt: now + 7d }
  if exists roles[viewer, role = 'manager']:
    return changed appraisalManager
  return changed appraisalPublic

mutation recordMileage(appraisal: appraisals, mileage: int 0..2000000):
  a = appraisals[appraisal] ! else NOT_FOUND
  require a.customer = viewer or exists roles[viewer, role = 'appraiser'] or exists roles[viewer, role = 'manager'] else MILEAGE_FORBIDDEN
  require mileage >= a.currentMileage else MILEAGE_CANNOT_DECREASE
  require a.acceptedAt = null else ALREADY_ACCEPTED
  changed = update appraisals[appraisal] { currentMileage: mileage }
  if exists roles[viewer, role = 'manager']:
    return changed appraisalManager
  return changed appraisalPublic

mutation valueOffer(appraisal: appraisals, recon: int 0..100000000, wholesale: int 0..100000000, offer: int 0..100000000, reason: text <=1000):
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  a = appraisals[appraisal] ! else NOT_FOUND
  require a.expiresAt > now and a.currentMileage < a.mileage + 250 else OFFER_EXPIRED
  require a.acceptedAt = null else ALREADY_ACCEPTED
  require offer <= wholesale or reason != '' else APPROVAL_REASON_REQUIRED
  changed = update appraisals[appraisal] { recon, wholesale, offer, approvalReason: reason, approvedBy: viewer }
  if exists roles[viewer, role = 'manager']:
    return changed appraisalManager
  return changed appraisalPublic

mutation acceptOffer(appraisal: appraisals):
  a = appraisals[appraisal] ! else NOT_FOUND
  require a.customer = viewer and exists roles[viewer, role = 'customer'] else CUSTOMER_ONLY
  require a.expiresAt > now and a.currentMileage < a.mileage + 250 else OFFER_EXPIRED
  require a.offer != null else NO_OFFER
  require a.acceptedAt = null else ALREADY_ACCEPTED
  changed = update appraisals[appraisal] { acceptedAt: now }
  if exists roles[viewer, role = 'manager']:
    return changed appraisalManager
  return changed appraisalPublic

table photos:
  appraisal: appraisals
  photo: image <=8000000
  caption: text 1..160
  immutable appraisal, photo, caption
  read through .appraisal
  insert <- exists roles[viewer, role = 'appraiser']
  online only

query photos(appraisal: appraisals):
  require exists roles[viewer] else NO_ROLE
  return photos where .appraisal = appraisal first 40 by .id

mutation attachPhoto(appraisal: appraisals, photo: image <=8000000, caption: text 1..160):
  require exists roles[viewer, role = 'appraiser'] else APPRAISER_ONLY
  require exists appraisals[appraisal] else NOT_FOUND
  return insert photos { appraisal, photo, caption }

mutation updateInspectionObservations(appraisal: appraisals, inspectionObservations: text <=3000):
  a = appraisals[appraisal] ! else NOT_FOUND
  require exists roles[viewer, role = 'appraiser'] and a.appraiser = viewer else RECORDING_APPRAISER_ONLY
  changed = update appraisals[appraisal] { notes: inspectionObservations }
  return changed appraisalPublic
