-- Kitchen Incubator Bookings.
-- Roles: business (food businesses), attendant (live board + inspections),
-- manager (suspend/unsuspend). Provisioned by the local operator.
use identity password

table roles:
  principal: principal
  role: enum('business', 'attendant', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('business', 'attendant', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR 'Only the local operator may grant roles.'
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

-- One business profile per account. insuranceExpiresAt tracks the latest
-- insurance certificate so booking-time checks are a single row read.
table businesses:
  principal: principal
  name: text 1..80
  insuranceExpiresAt: time ?
  failedCheck: bool default false
  suspended: bool default false
  suspendReason: text 1..280 ?
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  insert <- .principal = viewer
  update <- .principal = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  online only

query myBusiness():
  return businesses[viewer]

query allBusinesses(c: cursor ?):
  require exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF 'Only kitchen staff may list businesses.'
  return businesses first 50 by .id after c

mutation registerBusiness(name: text 1..80):
  require exists roles[principal = viewer, role = 'business'] else NOT_BUSINESS 'Only business accounts may register.'
  return upsert businesses[viewer] { principal: viewer, name }

-- Food handler cards and insurance certificates uploaded by a business.
table documents:
  owner: principal
  kind: enum('handler_card', 'insurance')
  expiresAt: time ?
  scan: image <=5000000 ?
  ref: text <=80 ?
  at: time default now
  cap 200 by owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  insert <- .owner = viewer
  online only

query myDocuments(c: cursor ?):
  return documents where .owner = viewer last 50 by .at after c

query documentsFor(owner: principal, c: cursor ?):
  require owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_PERMITTED 'Businesses read only their own documents.'
  return documents where .owner = owner last 50 by .at after c

mutation uploadHandlerCard(expiresAt: time ?, scan: image <=5000000 ?, ref: text <=80 ?):
  require exists roles[principal = viewer, role = 'business'] else NOT_BUSINESS 'Only business accounts may upload cards.'
  b = businesses[viewer] ! else NO_BUSINESS 'Register the business first.'
  return insert documents { owner: viewer, kind: 'handler_card', expiresAt, scan, ref }

mutation uploadInsurance(expiresAt: time, scan: image <=5000000 ?, ref: text <=80 ?):
  require exists roles[principal = viewer, role = 'business'] else NOT_BUSINESS 'Only business accounts may upload insurance.'
  require expiresAt > now else EXPIRED 'Insurance must not already be expired.'
  b = businesses[viewer] ! else NO_BUSINESS 'Register the business first.'
  row = insert documents { owner: viewer, kind: 'insurance', expiresAt, scan, ref }
  update businesses[b.id] { insuranceExpiresAt: expiresAt }
  return row

-- Cooking-time sessions. The settleBookings job cancels sessions whose
-- insurance expired before the session ends, completes ended sessions and
-- charges a cleaning fee when no station photos arrived within 30 minutes.
table bookings:
  owner: principal
  startsAt: time
  endsAt: time
  status: enum('booked', 'cancelled', 'completed') default 'booked'
  cancelReason: text <=280 ?
  feeCharged: bool default false
  feeNote: text <=280 ?
  createdAt: time default now
  immutable owner, startsAt, endsAt
  cap 1000 by owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  insert <- .owner = viewer
  update <- .owner = viewer
  online only

query myBookings(c: cursor ?):
  return bookings where .owner = viewer first 50 by .startsAt after c

query bookingBoard(c: cursor ?):
  require exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF 'Only kitchen staff may see the booking board.'
  return bookings first 50 by .startsAt after c

query bookingDetail(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_PERMITTED 'Businesses read only their own bookings.'
  bid = b.id
  return { booking: b, photos: cleaningPhotos where .booking = bid last 10 by .at { id, at } }

mutation createBooking(startsAt: time, endsAt: time):
  require exists roles[principal = viewer, role = 'business'] else NOT_BUSINESS 'Only business accounts may book.'
  b = businesses[viewer] ! else NO_BUSINESS 'Register the business first.'
  require not b.suspended else SUSPENDED 'This business is suspended.'
  require startsAt < endsAt else BAD_RANGE 'A session must end after it starts.'
  require endsAt - startsAt >= 30m and endsAt - startsAt <= 12h else BAD_LENGTH 'Sessions run 30 minutes to 12 hours.'
  require startsAt >= now - 1d else IN_THE_PAST 'Sessions cannot start more than a day ago.'
  cover = b.insuranceExpiresAt ?? 0
  require cover >= endsAt else INSURANCE_INVALID 'Insurance must cover the whole session.'
  return insert bookings { owner: viewer, startsAt, endsAt }

mutation cancelBooking(booking: bookings):
  bk = bookings[booking] ! else NOT_FOUND
  require bk.owner = viewer else NOT_OWNER 'Only the booking owner may cancel it.'
  require bk.status = 'booked' else NOT_BOOKED 'Only booked sessions can be cancelled.'
  update bookings[bk.id] { status: 'cancelled', cancelReason: 'cancelled by business' }
  return null

-- Photos of the cleaned station, due within 30 minutes of the session end.
table cleaningPhotos:
  booking: bookings
  owner: principal
  photo: image <=5000000
  at: time default now
  immutable booking, owner
  cap 20 by booking
  read <- .owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  insert <- .owner = viewer
  online only

mutation uploadCleaningPhoto(booking: bookings, photo: image <=5000000):
  require exists roles[principal = viewer, role = 'business'] else NOT_BUSINESS 'Only business accounts may upload cleaning photos.'
  bk = bookings[booking] ! else NOT_FOUND
  require bk.owner = viewer else NOT_OWNER 'Photos belong to the booking owner.'
  require bk.status = 'booked' or bk.status = 'completed' else NOT_ACTIVE 'Photos belong to active sessions.'
  require bk.endsAt <= now else TOO_EARLY 'Upload after the session ends.'
  require now <= bk.endsAt + 30m else WINDOW_CLOSED 'Cleaning photos are due within 30 minutes of the session ending.'
  return insert cleaningPhotos { booking: bk.id, owner: viewer, photo }

job settleBookings(periodStart: time, periodEnd: time):
  for b in bookings:
    if b.status = 'booked':
      biz = businesses[b.owner]
      if biz = null:
        update bookings[b.id] { status: 'cancelled', cancelReason: 'business profile missing' }
      else:
        cover = biz.insuranceExpiresAt ?? 0
        if cover < b.endsAt:
          update bookings[b.id] { status: 'cancelled', cancelReason: 'insurance expired before session' }
        else if b.endsAt <= periodEnd:
          bid = b.id
          if exists cleaningPhotos where .booking = bid:
            update bookings[b.id] { status: 'completed' }
          else if b.endsAt + 30m <= periodEnd:
            update bookings[b.id] { status: 'completed', feeCharged: true, feeNote: 'no cleaning photos within 30 minutes' }

schedule settle every 5m: settleBookings

-- Storage shelves assigned to businesses by kitchen staff.
table shelves:
  owner: principal
  label: text 1..60
  location: text <=60 ?
  cap 12 by owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  insert <- exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  update <- .owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  delete <- exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  online only

query myShelves(c: cursor ?):
  return shelves where .owner = viewer first 50 by .id after c

query shelvesFor(owner: principal, c: cursor ?):
  require owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_PERMITTED 'Businesses read only their own shelves.'
  return shelves where .owner = owner first 50 by .id after c

mutation assignShelf(owner: principal, label: text 1..60, location: text <=60 ?):
  require exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF 'Only kitchen staff may assign shelves.'
  t = businesses[owner] ! else NO_BUSINESS 'The business must be registered.'
  return insert shelves { owner, label, location }

mutation updateShelfLabel(shelf: shelves, label: text 1..60):
  s = shelves[shelf] ! else NOT_FOUND
  require s.owner = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_PERMITTED 'Only the shelf owner or staff may relabel it.'
  update shelves[s.id] { label }
  return null

mutation releaseShelf(shelf: shelves):
  require exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF 'Only kitchen staff may release shelves.'
  delete shelves[shelf]
  return null

-- Inspection findings (what was observed) plus manager-owned follow-up
-- instructions (corrective work requested from the business). v1 `note`
-- cells carry over unchanged as `finding`; follow-up starts empty.
table inspections:
  subject: principal
  author: principal
  finding: text 1..1000 renamed from note
  followUp: text 1..1000 ?
  passed: bool
  at: time default now
  immutable subject, author, finding, passed, at
  read <- .subject = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  insert <- exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager']
  update <- exists roles[principal = viewer, role = 'manager']
  online only

query myInspections(c: cursor ?):
  return inspections where .subject = viewer last 50 by .at after c

query inspectionsFor(subject: principal, c: cursor ?):
  require subject = viewer or exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_PERMITTED 'Businesses read only their own inspection notes.'
  return inspections where .subject = subject last 50 by .at after c

mutation addInspection(subject: principal, finding: text 1..1000 alias note, passed: bool):
  require exists roles[principal = viewer, role = 'attendant'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF 'Only kitchen staff may write inspections.'
  biz = businesses[subject] ! else NO_BUSINESS 'The business must be registered.'
  row = insert inspections { subject, author: viewer, finding, passed }
  if not passed:
    update businesses[biz.id] { failedCheck: true }
  return row

-- Only the kitchen manager may change follow-up instructions; kitchen
-- attendants and businesses cannot.
mutation setFollowUp(inspection: inspections, followUp: text 1..1000 ?):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the kitchen manager may change follow-up instructions.'
  row = inspections[inspection] ! else NOT_FOUND
  update inspections[row.id] { followUp }
  return null

-- Only the kitchen manager may suspend, after a failed cleaning check, with
-- the reason kept on the business row.
mutation suspendBusiness(subject: principal, reason: text 1..280):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the kitchen manager may suspend a business.'
  biz = businesses[subject] ! else NOT_FOUND
  require biz.failedCheck else NO_FAILED_CHECK 'Suspension needs a failed cleaning check.'
  update businesses[biz.id] { suspended: true, suspendReason: reason }
  return null

mutation unsuspendBusiness(subject: principal):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the kitchen manager may lift a suspension.'
  biz = businesses[subject] ! else NOT_FOUND
  update businesses[biz.id] { suspended: false, failedCheck: false }
  return null
