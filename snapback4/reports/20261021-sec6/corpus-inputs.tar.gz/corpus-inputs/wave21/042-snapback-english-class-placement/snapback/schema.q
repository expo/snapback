use identity password

table roles:
  principal: principal
  role: enum('coordinator', 'teacher', 'learner')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator']
  insert <- viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] and .role = 'learner'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('coordinator', 'teacher', 'learner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }
query myRole():
  return roles[viewer]

table learners:
  principal: principal
  name: text 1..80
  address: text 1..240 read <- exists roles[viewer, role = 'coordinator']
  phone: text 5..30 read <- exists roles[viewer, role = 'coordinator']
  immigration: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png') ? read <- exists roles[viewer, role = 'coordinator']
  level: int 1..3
  status: enum('waitlist', 'placed')
  joinedAt: time
  lastAttendance: time
  unique principal
  immutable principal, joinedAt
  read <- .principal = viewer or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'coordinator']
  update <- exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'teacher']
  online only

table tests:
  learner: learners
  -- Stable asset home retained for existing uploads and v1 clients. Public v2 name: placementWritingSample.
  writing: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png') ?
  submittedAt: time
  score: int 0..100 ?
  testedLevel: int 1..3 ?
  gradedBy: principal ?
  immutable learner, submittedAt
  read <- exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists learners[.learner, principal = viewer]
  update (old, next) <- exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'teacher'] and old.writing = next.writing
  online only

table attendance:
  learner: learners
  at: time
  recordedBy: principal
  immutable learner, at, recordedBy
  read <- exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  online only

table promotions:
  learner: learners
  fromLevel: int 1..3
  toLevel: int 1..3
  reason: text 5..500
  actor: principal
  at: time
  immutable learner, fromLevel, toLevel, reason, actor, at
  read <- exists learners[.learner, principal = viewer] or exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'coordinator'] and .actor = viewer
  online only

query learnerList(c: cursor ?):
  return learners first 50 by .id after c
query learnerDetail(learner: learners):
  return learners[learner]
query classRoster(level: int 1..3, c: cursor ?):
  require exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator'] else STAFF_ONLY
  return learners where .level = level and .status = 'placed' first 50 by .id after c
query testList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return tests where .learner = row.id last 50 by .submittedAt after c
query attendanceList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return attendance where .learner = row.id last 50 by .at after c
query promotionList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return promotions where .learner = row.id last 50 by .at after c

mutation enroll(principal: principal, name: text 1..80, address: text 1..240, phone: text 5..30):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  existing = roles[principal]
  require existing = null or existing.role = 'learner' else LEARNER_ACCOUNT_REQUIRED
  if existing = null:
    insert roles { principal, role: 'learner' }
  return insert learners { principal, name, address, phone, level: 1, status: 'waitlist', joinedAt: now, lastAttendance: now }
mutation savePrivate(learner: learners, address: text 1..240, phone: text 5..30):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  update learners[learner] { address, phone }
mutation attachImmigration(learner: learners, document: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png')):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  update learners[learner] { immigration: document }
mutation submitTest(learner: learners, placementWritingSample: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png') ? alias writing):
  row = learners[learner] ! else NOT_FOUND
  require row.principal = viewer else OWN_TEST_ONLY
  require exists roles[viewer, role = 'learner'] else LEARNER_ONLY
  return insert tests { learner, writing: placementWritingSample, submittedAt: now }
mutation gradeTest(test: tests, score: int 0..100):
  require exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator'] else STAFF_ONLY
  row = tests[test] ! else NOT_FOUND
  require row.score = null else ALREADY_GRADED
  level = 3 if score >= 80 else 2 if score >= 50 else 1
  update tests[test] { score, testedLevel: level, gradedBy: viewer }
  update learners[row.learner] { level }
mutation recordAttendance(learner: learners):
  require exists roles[viewer, role = 'teacher'] or exists roles[viewer, role = 'coordinator'] else STAFF_ONLY
  update learners[learner] { lastAttendance: now }
  return insert attendance { learner, at: now, recordedBy: viewer }
mutation place(learner: learners):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  row = learners[learner] ! else NOT_FOUND
  require now <= row.lastAttendance + 21d else ABSENCE_OVER_21_DAYS
  update learners[learner] { status: 'placed' }
mutation promote(learner: learners, level: int 1..3, reason: text 5..500):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  row = learners[learner] ! else NOT_FOUND
  require level > row.level else MUST_MOVE_UP
  require now <= row.lastAttendance + 21d else ABSENCE_OVER_21_DAYS
  insert promotions { learner, fromLevel: row.level, toLevel: level, reason, actor: viewer, at: now }
  update learners[learner] { level }

job waitlistAbsent():
  for row in learners:
    if row.status = 'placed' and now > row.lastAttendance + 21d:
      update learners[row.id] { status: 'waitlist' }
schedule absenceCheck every 1m: waitlistAbsent

-- Intent from the program specification, independent of UI visibility.
invariant learners.address read only exists roles[viewer, role = 'coordinator']
invariant learners.phone read only exists roles[viewer, role = 'coordinator']
invariant learners.immigration read only exists roles[viewer, role = 'coordinator']
invariant learners.enroll only exists roles[viewer, role = 'coordinator']
invariant learners.promote only exists roles[viewer, role = 'coordinator']
invariant promotions.insert only exists roles[viewer, role = 'coordinator']
invariant tests.insert only exists learners[.learner, principal = viewer]
invariant roles.update only viewer = 'service:operator'

-- v2 result name; the legacy endpoint intentionally keeps its original projection.
shape placementTest = { id, learner, placementWritingSample: .writing, submittedAt, score, testedLevel, gradedBy }
query placementTestList(learner: learners, c: cursor ?):
  row = learners[learner] ! else NOT_FOUND
  return tests where .learner = row.id last 50 by .submittedAt after c placementTest
mutation replacePlacementWritingSample(test: tests, placementWritingSample: file <=5000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png') ?):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  row = tests[test] ! else NOT_FOUND
  update tests[row.id] { writing: placementWritingSample }
