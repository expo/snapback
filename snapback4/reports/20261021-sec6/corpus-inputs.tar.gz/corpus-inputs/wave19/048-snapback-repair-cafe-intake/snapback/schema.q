-- Repair Cafe Intake.
-- Roles: visitor, fixer (roster), host (hostSeats, first two claimants).
-- Visitors log broken items with a photo + fault; fixers claim items in
-- their skill category from a live queue; unclaimed items expire 45 minutes
-- after intake and the visitor rebooks; electrical items need a safety test
-- by a qualified fixer before return, waivable only by the host with a reason.
-- v2: items.fault is the visitor's reported fault (carried word for word);
-- items.assessment is the repairer's assessment, null until assessed, writable
-- only by the claiming fixer or the host.
use identity password

table hostSeats:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- .principal = viewer
  cap 2
  online only

table roster:
  principal: principal
  role: enum('visitor', 'fixer')
  skill: enum('electrical', 'mechanical', 'textile', 'general') default 'general'
  qualified: bool default false
  unique principal
  read <- .principal = viewer or exists hostSeats[viewer]
  insert <- .principal = viewer and (.role = 'visitor' or .role = 'fixer')
  update (old, next) <- old.principal = viewer and next.principal = viewer and next.role = old.role and next.qualified = old.qualified or exists hostSeats[viewer]
  immutable principal
  cap 500
  online only

table contacts:
  owner: principal
  detail: text 1..120
  unique owner
  read <- .owner = viewer or exists hostSeats[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  immutable owner
  cap 500
  online only

table items:
  owner: principal
  title: text 1..80
  category: enum('electrical', 'mechanical', 'textile', 'general')
  fault: text 1..500
  assessment: text 1..500 ?
  photo: image <=8000000
  status: enum('queued', 'claimed', 'ready', 'returned', 'expired') default 'queued'
  claimedBy: principal ?
  createdAt: time default now
  safetyStatus: enum('notneeded', 'pending', 'passed', 'failed', 'waived') default 'pending'
  safetyBy: principal ?
  safetyAt: time ?
  waiverReason: text 1..280 ?
  waivedBy: principal ?
  read <- .owner = viewer or exists hostSeats[viewer] or exists roster[principal = viewer, role = 'fixer', skill = .category]
  insert <- .owner = viewer or exists hostSeats[viewer]
  update (old, next) <- old.owner = viewer or exists hostSeats[viewer] or old.claimedBy = viewer or exists roster[principal = viewer, role = 'fixer', skill = old.category]
  immutable owner, createdAt, category
  cap 2000
  online only

table notes:
  item: items on delete cascade
  author: principal
  text: text 1..500
  at: time default now
  immutable item, author, at
  read through .item
  insert <- .author = viewer and (exists items[.item, owner = viewer] or exists hostSeats[viewer] or exists items[.item, claimedBy = viewer])
  cap 5000
  online only

invariant hostSeats.read only .principal = viewer
invariant roster.read only .principal = viewer or exists hostSeats[viewer]
invariant contacts.read only .owner = viewer or exists hostSeats[viewer]
invariant items.read only .owner = viewer or exists hostSeats[viewer] or exists roster[principal = viewer, role = 'fixer', skill = .category]
invariant contacts.insert only .owner = viewer

query myItems(c: cursor ?):
  return items where .owner = viewer last 50 by .id after c

query queue(c: cursor ?):
  me = roster[principal = viewer] ! else NOT_REGISTERED 'Register as a fixer first.'
  require me.role = 'fixer' else NOT_FIXER 'Only fixers see the repair queue; the host uses all items.'
  return items where .status = 'queued' and .category = me.skill last 50 by .id after c

query itemDetail(item: items):
  return items[item]

query itemNotes(item: items, c: cursor ?):
  return notes where .item = item first 50 by .id after c

query allItems(c: cursor ?):
  require exists hostSeats[viewer] else NOT_HOST 'Only the host sees every item.'
  return items last 100 by .id after c

query myContact():
  return contacts[owner = viewer]

query visitorContact(owner: principal):
  require exists hostSeats[viewer] else NOT_HOST 'Only the host sees visitor contact details.'
  return contacts[owner]

query myRoster():
  return roster[principal = viewer]

query amHost():
  return exists hostSeats[viewer]

query myClaimed(c: cursor ?):
  return items where .claimedBy = viewer last 50 by .id after c

query allRoster(c: cursor ?):
  require exists hostSeats[viewer] else NOT_HOST 'Only the host sees the roster.'
  return roster last 100 by .id after c

mutation register(role: enum('visitor', 'fixer'), skill: enum('electrical', 'mechanical', 'textile', 'general') ?, contact: text 1..120 ?):
  require role = 'visitor' or role = 'fixer' else BAD_ROLE 'Role is visitor or fixer; hosts claim a host seat.'
  require role = 'visitor' or skill != null else SKILL_NEEDED 'Fixers state their skill category.'
  upsert roster[principal = viewer] { principal: viewer, role, skill: skill ?? 'general' }
  if contact != null:
    upsert contacts[owner = viewer] { owner: viewer, detail: contact }
  return null

mutation claimHostSeat():
  return insert hostSeats { principal: viewer } if absent

mutation setQualified(target: principal, qualified: bool):
  require exists hostSeats[viewer] else NOT_HOST 'Only the host marks fixers qualified.'
  r = roster[target] ! else NOT_FOUND
  require r.role = 'fixer' and r.skill = 'electrical' else NOT_ELECTRICAL_FIXER 'Only an electrical fixer can be marked qualified.'
  update roster[target] { qualified }
  return null

mutation intake(owner: principal, title: text 1..80, category: enum('electrical', 'mechanical', 'textile', 'general'), fault: text 1..500, photo: image <=8000000):
  require owner = viewer and exists roster[principal = viewer, role = 'visitor'] or exists hostSeats[viewer] else NOT_ALLOWED 'Visitors log their own items; the host may log for anyone.'
  return insert items { owner, title, category, fault, photo, safetyStatus: 'pending' if category = 'electrical' else 'notneeded' }

mutation claim(item: items):
  t = items[item] ! else NOT_FOUND
  require t.status = 'queued' else BAD_STATE 'Only queued items can be claimed.'
  require now - t.createdAt <= 45m else CLAIM_WINDOW_CLOSED 'Unclaimed after 45 minutes; the visitor must rebook.'
  me = roster[principal = viewer] ! else NOT_FIXER 'Only a registered fixer claims items.'
  require me.role = 'fixer' and me.skill = t.category else WRONG_SKILL 'Fixers claim items in their own skill category.'
  update items[item] { status: 'claimed', claimedBy: viewer }
  return null

mutation markReady(item: items):
  t = items[item] ! else NOT_FOUND
  require t.status = 'claimed' else BAD_STATE 'Only claimed items become ready.'
  require t.claimedBy = viewer or exists hostSeats[viewer] else NOT_ALLOWED 'Only the claiming fixer or host marks ready.'
  update items[item] { status: 'ready' }
  return null

mutation setAssessment(item: items, assessment: text 1..500 ?):
  t = items[item] ! else NOT_FOUND
  require t.claimedBy = viewer or exists hostSeats[viewer] else NOT_ALLOWED 'Only the claiming fixer or the host updates the repair assessment.'
  update items[item] { assessment }
  return null

mutation addNote(item: items, text: text 1..500):
  t = items[item] ! else NOT_FOUND
  require t.owner = viewer or exists hostSeats[viewer] or t.claimedBy = viewer else NOT_ALLOWED 'Only the visitor, the claiming fixer or the host adds notes.'
  return insert notes { item, author: viewer, text }

mutation recordSafety(item: items, passed: bool, note: text 1..280 ?):
  t = items[item] ! else NOT_FOUND
  require t.category = 'electrical' else NOT_ELECTRICAL 'Only electrical items need a safety test.'
  require t.safetyStatus = 'pending' or t.safetyStatus = 'failed' else BAD_STATE 'This item already passed its safety test.'
  me = roster[principal = viewer] ! else NOT_FIXER 'Only a registered fixer tests safety.'
  require me.role = 'fixer' and me.qualified else NOT_QUALIFIED 'A qualified fixer performs the safety test.'
  update items[item] { safetyStatus: 'passed' if passed else 'failed', safetyBy: viewer, safetyAt: now }
  if note != null:
    insert notes { item, author: viewer, text: note }
  return null

mutation waiveSafety(item: items, reason: text 1..280):
  require exists hostSeats[viewer] else NOT_HOST 'Only the host waives a safety test.'
  t = items[item] ! else NOT_FOUND
  require t.category = 'electrical' else NOT_ELECTRICAL 'Only electrical items need a safety test.'
  update items[item] { safetyStatus: 'waived', waiverReason: reason, waivedBy: viewer }
  return null

mutation returnItem(item: items):
  require exists hostSeats[viewer] else NOT_HOST 'Only the host returns items.'
  t = items[item] ! else NOT_FOUND
  require t.status = 'ready' else BAD_STATE 'Only ready items are returned.'
  require t.safetyStatus = 'notneeded' or t.safetyStatus = 'passed' or t.safetyStatus = 'waived' else SAFETY_BLOCKED 'An electrical item needs a passed safety test or a host waiver.'
  update items[item] { status: 'returned' }
  return null

mutation rebook(item: items, photo: image <=8000000):
  t = items[item] ! else NOT_FOUND
  require t.status = 'expired' else BAD_STATE 'Only expired items are rebooked.'
  require t.owner = viewer or exists hostSeats[viewer] else NOT_ALLOWED 'Only the visitor or host rebooks.'
  return insert items { owner: t.owner, title: t.title, category: t.category, fault: t.fault, photo, safetyStatus: 'pending' if t.category = 'electrical' else 'notneeded' }

job expireUnclaimed(periodStart: time, periodEnd: time):
  for i in items where .createdAt >= periodEnd - 7d and .createdAt < periodEnd by .createdAt:
    if i.status = 'queued' and now - i.createdAt > 45m:
      update items[i.id] { status: 'expired' }

schedule sweepQueue every 1m: expireUnclaimed
