use identity password

table people:
  principal: principal
  name: text 2..80
  role: enum('farmer', 'mixer', 'veterinarian', 'qualityManager')
  unique principal
  immutable principal, role, name
  public 'Authenticated account directory; no credentials or private business data'
  insert <- viewer = 'service:ops'
  online only

-- Stable orders storage is the v1 wire/storage contract. All rows are veterinary feed authorizations.
-- medication stores written instructions; batch.order retains the same authorization ID.
table orders:
  kind: enum('veterinaryFeedAuthorization') default 'veterinaryFeedAuthorization'
  farmer: principal
  vet: principal
  title: text 3..120
  medication: text 2..120
  writtenAt: time
  expiresAt: time
  document: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg') ?
  immutable farmer, vet, title, writtenAt, expiresAt, kind
  read <- .farmer = viewer or .vet = viewer or exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager']
  insert <- .vet = viewer and exists people[principal = viewer, role = 'veterinarian']
  update <- (.farmer = viewer and exists people[principal = viewer, role = 'farmer']) or (.vet = viewer and exists people[principal = viewer, role = 'veterinarian'])
  online only

table batches:
  label: text 3..100
  kind: enum('medicated', 'flush', 'plain')
  order: orders ?
  mixer: principal
  kilograms: int 1..50000
  at: time
  state: enum('sampling', 'failed', 'released')
  photo: image <=5000000 ?
  reason: text 5..500 ?
  releasedBy: principal ?
  immutable label, kind, order, mixer, kilograms, at
  read <- exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager']
  insert <- .mixer = viewer and exists people[principal = viewer, role = 'mixer']
  update <- exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager']
  online only

table mill:
  key: text 1..20
  dirty: bool default false
  active: batches ?
  unique key
  immutable key
  read <- exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager']
  online only

table deliveries:
  batch: batches
  farmer: principal
  label: text 3..100
  kilograms: int 1..50000
  cents: int 1..100000000
  at: time
  unique batch
  immutable batch, farmer, label, kilograms, cents, at
  read <- .farmer = viewer or exists people[principal = viewer, role = 'qualityManager']
  insert <- exists people[principal = viewer, role = 'qualityManager']
  online only

mutation enroll(principal: principal, name: text 2..80, role: enum('farmer', 'mixer', 'veterinarian', 'qualityManager')):
  require viewer = 'service:ops' else FORBIDDEN
  insert people { principal, name, role }
  if not exists mill[key = 'main']:
    insert mill { key: 'main' }

query me():
  return people[principal = viewer]
query directory():
  return people first 100 by .id
query listOrders():
  return orders last 100 by .id
query orderById(order: orders):
  return orders[order]
query board():
  require exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager'] else FORBIDDEN
  return { line: mill[key = 'main'], batches: batches last 100 by .id }
query batchById(batch: batches):
  return batches[batch]
query listDeliveries():
  return deliveries last 100 by .id
query deliveryById(delivery: deliveries):
  return deliveries[delivery]

mutation issueOrder(farmer: principal, title: text 3..120, medication: text 2..120, writtenAt: time):
  require exists people[principal = viewer, role = 'veterinarian'] else FORBIDDEN
  require exists people[principal = farmer, role = 'farmer'] else BAD_FARMER
  require writtenAt <= now and writtenAt >= now - 730d else BAD_DATE
  target = monthStart(month(writtenAt) + 6)
  following = monthStart(month(writtenAt) + 7)
  dayIndex = day(writtenAt) - day(monthStart(month(writtenAt)))
  expiresAt = target + min(dayIndex, (following - target) / 1d - 1) * 1d + writtenAt % 1d
  return insert orders { farmer, vet: viewer, title, medication, writtenAt, expiresAt }

mutation uploadOrder(order: orders, document: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg')):
  require exists people[principal = viewer, role = 'farmer'] else FORBIDDEN
  o = orders[order] ! else NOT_FOUND
  require o.farmer = viewer else FORBIDDEN
  require now < o.expiresAt else ORDER_EXPIRED
  require o.document = null else ALREADY_UPLOADED
  update orders[order] { document }

mutation startBatch(label: text 3..100, kind: enum('medicated', 'flush', 'plain'), order: orders ?, kilograms: int 1..50000):
  require exists people[principal = viewer, role = 'mixer'] else FORBIDDEN
  line = mill[key = 'main'] ! else NOT_FOUND
  require line.active = null else BATCH_ACTIVE 'Finish the active batch and release any failed test first.'
  require kind != 'plain' or line.dirty = false else FLUSH_REQUIRED 'A photographed flush must follow medicated feed before plain feed.'
  if kind = 'medicated':
    require order != null else ORDER_REQUIRED
    o = orders[order] ! else NOT_FOUND
    require o.document != null else DOCUMENT_REQUIRED
    require now < o.expiresAt else ORDER_EXPIRED
  else:
    require order = null else UNEXPECTED_ORDER
  if kind = 'flush':
    require line.dirty = true else FLUSH_NOT_NEEDED
  b = insert batches { label, kind, order, mixer: viewer, kilograms, at: now, state: 'sampling' }
  update mill[line.id] { active: b.id, dirty: true if kind = 'medicated' else line.dirty }
  return b

mutation recordSample(batch: batches, photo: image <=5000000, passed: bool):
  require exists people[principal = viewer, role = 'mixer'] else FORBIDDEN
  b = batches[batch] ! else NOT_FOUND
  line = mill[key = 'main'] ! else NOT_FOUND
  require line.active = b.id and b.state = 'sampling' else BAD_STATE
  update batches[b.id] { photo, state: 'released' if passed else 'failed' }
  if passed:
    update mill[line.id] { active: null, dirty: false if b.kind = 'flush' else line.dirty }

mutation releaseFailed(batch: batches, reason: enum('Retest confirmed safe', 'Laboratory error verified', 'QA risk assessment approved')):
  require exists people[principal = viewer, role = 'qualityManager'] else FORBIDDEN
  b = batches[batch] ! else NOT_FOUND
  line = mill[key = 'main'] ! else NOT_FOUND
  require b.state = 'failed' and line.active = b.id else BAD_STATE
  update batches[b.id] { state: 'released', reason, releasedBy: viewer }
  update mill[line.id] { active: null, dirty: false if b.kind = 'flush' else line.dirty }

mutation deliver(batch: batches, farmer: principal, cents: int 1..100000000):
  require exists people[principal = viewer, role = 'qualityManager'] else FORBIDDEN
  b = batches[batch] ! else NOT_FOUND
  require b.state = 'released' and b.kind != 'flush' else NOT_DELIVERABLE
  require exists people[principal = farmer, role = 'farmer'] else BAD_FARMER
  if b.kind = 'medicated':
    o = orders[b.order] ! else NOT_FOUND
    require o.farmer = farmer else WRONG_FARMER
  return insert deliveries { batch, farmer, label: b.label, kilograms: b.kilograms, cents, at: now }

-- Canonical v2 operations; original names remain compatible aliases.
query listAuthorizations():
  return orders last 100 by .id
query authorizationById(authorization: orders):
  return orders[authorization]

mutation issueAuthorization(farmer: principal, title: text 3..120, medication: text 2..120, writtenAt: time):
  require exists people[principal = viewer, role = 'veterinarian'] else FORBIDDEN
  require exists people[principal = farmer, role = 'farmer'] else BAD_FARMER
  require writtenAt <= now and writtenAt >= now - 730d else BAD_DATE
  target = monthStart(month(writtenAt) + 6)
  following = monthStart(month(writtenAt) + 7)
  dayIndex = day(writtenAt) - day(monthStart(month(writtenAt)))
  expiresAt = target + min(dayIndex, (following - target) / 1d - 1) * 1d + writtenAt % 1d
  return insert orders { farmer, vet: viewer, title, medication, writtenAt, expiresAt }

mutation uploadAuthorization(authorization: orders, document: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg')):
  require exists people[principal = viewer, role = 'farmer'] else FORBIDDEN
  o = orders[authorization] ! else NOT_FOUND
  require o.farmer = viewer else FORBIDDEN
  require now < o.expiresAt else ORDER_EXPIRED
  require o.document = null else ALREADY_UPLOADED
  update orders[authorization] { document }

mutation reviseInstructions(authorization: orders, instructions: text 2..120):
  require exists people[principal = viewer, role = 'veterinarian'] else FORBIDDEN
  a = orders[authorization] ! else NOT_FOUND
  require a.vet = viewer else FORBIDDEN
  update orders[authorization] { medication: instructions }
  return orders[authorization]
