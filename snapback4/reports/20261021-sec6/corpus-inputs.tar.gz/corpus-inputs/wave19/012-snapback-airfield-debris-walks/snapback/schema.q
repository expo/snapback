-- Airfield Debris Walks.
-- Roles: ops (operations staff, walk runways), duty (duty manager, overdue
-- alerts), tower (tower controllers, live clear/debris view), ramp (airline
-- ramp agents, report debris, see only their own reports), manager (airport
-- operations manager, closes/reopens runways with a reason).
use identity password

-- One row per roster member. The first manager bootstraps via
-- bootstrapManager (gated by the founders cap); afterwards only a manager
-- grants roles.
table founders:
  principal: principal
  unique principal
  immutable principal
  public 'founding manager record'
  insert <- .principal = viewer
  cap 1
  online only

table staff:
  principal: principal
  role: enum('ops', 'duty', 'tower', 'ramp', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[viewer, role = 'manager']
  insert <- .principal = viewer or exists staff[viewer, role = 'manager'] or viewer = 'service:ops'
  update <- exists staff[viewer, role = 'manager']
  delete <- exists staff[viewer, role = 'manager']
  online only

-- Runways and taxiways. Readable by anyone signed in (tower's live board,
-- ramp agents filing reports); writes only through mutations.
table areas:
  name: text 1..60
  status: enum('open', 'closed') default 'open'
  lastWalkAt: time ?
  lastWalkBy: principal ?
  closedReason: text 1..280 ?
  closedBy: principal ?
  closedAt: time ?
  reopenReason: text 1..280 ?
  unique name else NAME_TAKEN 'An area with this name already exists.'
  immutable name
  public 'areas are visible to all signed-in users'
  insert <- exists staff[viewer, role = 'manager']
  update <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'ops']
  online only

-- Each inspection walk of an area, logged by operations staff.
table walks:
  area: areas
  walker: principal
  at: time default now
  notes: text <=280 ?
  immutable area, walker
  read <- .walker = viewer or exists staff[viewer]
  insert <- .walker = viewer
  cap 10000 by area
  online only

-- Debris found, with photo and discovery location (v2 name for where the
-- item was found; the legacy `location` column mirrors it so v1 clients and
-- rollbacks keep reading the same value). Ramp agents read only their own
-- reports; ops, duty, tower and managers read every report. After filing,
-- only the airport operations manager may change the discovery location.
table reports:
  area: areas
  reporter: principal
  walk: walks ?
  location: text 1..200
  discoveryLocation: text 1..200 ?
  description: text <=500 ?
  photo: image <=5000000
  at: time default now
  immutable area, reporter
  read <- .reporter = viewer or exists staff[viewer, role = 'ops'] or exists staff[viewer, role = 'duty'] or exists staff[viewer, role = 'tower'] or exists staff[viewer, role = 'manager']
  insert <- .reporter = viewer
  update <- exists staff[viewer, role = 'manager']
  cap 10000 by area
  online only

-- Audit trail of runway closures and reopenings with reasons.
table events:
  area: areas
  actor: principal
  action: enum('close', 'reopen')
  reason: text 1..280
  at: time default now
  immutable area, actor, action
  read <- exists staff[viewer]
  insert <- exists staff[viewer, role = 'manager']
  cap 10000 by area
  online only

query myRole():
  return staff[viewer]

query areasList(c: cursor ?):
  return areas first 100 by .id after c

query walksFor(area: areas, c: cursor ?):
  return walks where .area = area last 50 by .at after c

query myReports(c: cursor ?):
  return reports where .reporter = viewer last 50 by .at after c

query allReports(c: cursor ?):
  require exists staff[viewer, role = 'ops'] or exists staff[viewer, role = 'duty'] or exists staff[viewer, role = 'tower'] or exists staff[viewer, role = 'manager'] else NOT_PRIVILEGED 'Only operations, duty, tower and manager roles may read every report.'
  return reports last 50 by .at after c

-- An open area is overdue when it was never walked or its last walk is
-- older than four hours. This is the duty manager's alert feed.
query overdueAreas(c: cursor ?):
  require exists staff[viewer, role = 'ops'] or exists staff[viewer, role = 'duty'] or exists staff[viewer, role = 'tower'] or exists staff[viewer, role = 'manager'] else NOT_PRIVILEGED 'Only operations, duty, tower and manager roles may read overdue areas.'
  return areas where .status = 'open' and (.lastWalkAt = null or .lastWalkAt < now - 4h) first 50 by .id after c

mutation bootstrapManager():
  require not exists staff[viewer] else ALREADY_STAFF 'This account already has a role.'
  insert founders { principal: viewer }
  return insert staff { principal: viewer, role: 'manager' }

mutation grantRole(who: principal, role: enum('ops', 'duty', 'tower', 'ramp', 'manager')):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the operations manager may grant roles.'
  return upsert staff[who] { role }

mutation createArea(name: text 1..60):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the operations manager may create areas.'
  return insert areas { name }

mutation logWalk(area: areas, notes: text <=280 ?):
  require exists staff[viewer, role = 'ops'] else NOT_OPS 'Only operations staff may log walks.'
  a = areas[area] ! else NOT_FOUND
  require a.status = 'open' else AREA_CLOSED 'This area is closed.'
  w = insert walks { area, walker: viewer, notes }
  update areas[area] { lastWalkAt: now, lastWalkBy: viewer }
  return w

mutation reportDebris(area: areas, location: text 1..200 ?, discoveryLocation: text 1..200 ?, description: text <=500 ?, photo: image <=5000000, walkRef: walks ?):
  a = areas[area] ! else NOT_FOUND
  if walkRef != null:
    w = walks[walkRef] ! else NOT_FOUND
    require w.area = area else WRONG_WALK 'That walk was for a different area.'
  if discoveryLocation != null:
    return insert reports { area, reporter: viewer, walk: walkRef, location: discoveryLocation, discoveryLocation, description, photo }
  require location != null else MISSING_LOCATION 'A discovery location is required.'
  return insert reports { area, reporter: viewer, walk: walkRef, location, discoveryLocation: location, description, photo }

-- After a report is filed, only the airport operations manager may change
-- its discovery location. The legacy `location` column mirrors the new
-- value so v1 clients and a v1 rollback keep reading the same value.
mutation updateDiscoveryLocation(report: reports, discoveryLocation: text 1..200):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the operations manager may change a discovery location.'
  row = reports[report] ! else NOT_FOUND
  update reports[report] { location: discoveryLocation, discoveryLocation }
  return null

mutation closeRunway(area: areas, reason: text 1..280):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the operations manager may close a runway.'
  a = areas[area] ! else NOT_FOUND
  require a.status = 'open' else ALREADY_CLOSED 'This area is already closed.'
  update areas[area] { status: 'closed', closedReason: reason, closedBy: viewer, closedAt: now }
  insert events { area, actor: viewer, action: 'close', reason }
  return null

mutation reopenRunway(area: areas, reason: text 1..280):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the operations manager may reopen a runway.'
  a = areas[area] ! else NOT_FOUND
  require a.status = 'closed' else NOT_CLOSED 'This area is not closed.'
  update areas[area] { status: 'open', reopenReason: reason, closedReason: null, closedBy: null, closedAt: null }
  insert events { area, actor: viewer, action: 'reopen', reason }
  return null

-- Independent privacy intent; guide security states unproved paths.
invariant reports.read only .reporter = viewer or exists staff[viewer, role = 'ops'] or exists staff[viewer, role = 'duty'] or exists staff[viewer, role = 'tower'] or exists staff[viewer, role = 'manager']
invariant staff.read only .principal = viewer or exists staff[viewer, role = 'manager']
