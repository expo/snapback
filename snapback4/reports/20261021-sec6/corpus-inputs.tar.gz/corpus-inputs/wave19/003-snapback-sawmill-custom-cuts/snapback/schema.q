-- Sawmill Custom Cuts.
-- Roles: customers are any signed-in user; sawyers and yard hands hold a
-- staff row; owners hold an owners row (first via bootstrapOwner, more via
-- addOwner).
use identity password

table owners:
  principal: principal
  unique principal
  public 'the mill owner is public knowledge'
  insert <- allow
  online only

table staff:
  principal: principal
  role: enum('sawyer', 'yardhand')
  unique principal
  read <- .principal = viewer or exists owners[viewer]
  insert <- exists owners[viewer]
  update <- exists owners[viewer]
  delete <- exists owners[viewer]
  immutable principal
  online only

-- Customer directory so the yard can attribute logs. Names are public;
-- logs themselves stay private.
table customers:
  principal: principal
  name: text 1..80
  unique principal
  public 'the yard needs to attribute logs to customers'
  insert <- .principal = viewer
  update <- .principal = viewer
  immutable principal
  online only

table millLogs:
  owner: principal
  species: text 1..60
  timberGroup: enum('softwood', 'hardwood', 'unclassified') default 'unclassified'
  photo: image <=4000000
  status: enum('intake', 'queued', 'milling', 'milled', 'collected') default 'intake'
  intakeAt: time default now
  priceCents: int 0..100000000
  metalFound: bool default false
  bladeFeeCents: int 0..100000000 default 0
  bladeFeeWaived: bool default false
  waiverReason: text 0..500 ?
  milledAt: time ?
  collectedAt: time ?
  immutable owner
  cap 500 by owner
  read <- .owner = viewer or exists staff[viewer] or exists owners[viewer]
  insert <- exists staff[principal = viewer, role = 'yardhand'] or exists owners[viewer]
  update <- .owner = viewer or exists staff[viewer] or exists owners[viewer]
  online only

-- One public row per waiting log: id + intake time only, so any customer
-- can count how many jobs are ahead of theirs without seeing other logs.
table queueSlots:
  log: millLogs
  intakeAt: time
  unique log
  immutable log, intakeAt
  public 'queue order is visible so customers see their live position'
  insert <- exists staff[viewer] or exists owners[viewer]
  delete <- exists staff[viewer] or exists owners[viewer]
  online only

table cutItems:
  log: millLogs
  label: text 1..120
  qty: int 1..10000
  priceCents: int 0..100000000
  immutable log
  cap 50 by log
  read through .log
  insert <- .log.owner = viewer
  update <- .log.owner = viewer
  delete <- .log.owner = viewer
  online only

mutation register(name: text 1..80):
  return upsert customers[viewer] { principal: viewer, name }

mutation bootstrapOwner():
  require not exists owners else OWNER_SEATED
  return insert owners { principal: viewer }

mutation assignStaff(who: principal, role: enum('sawyer', 'yardhand')):
  require exists owners[viewer] else NOT_OWNER
  return upsert staff[who] { role }

mutation addOwner(who: principal):
  require exists owners[viewer] else NOT_OWNER
  require not exists owners[who] else ALREADY_OWNER
  return insert owners { principal: who }

mutation intake(customer: principal, species: text 1..60, photo: image <=4000000, priceCents: int 0..100000000, timberGroup: enum('softwood', 'hardwood', 'unclassified') ?):
  require exists staff[principal = viewer, role = 'yardhand'] or exists owners[viewer] else NOT_YARDHAND
  c = customers[customer] ! else UNKNOWN_CUSTOMER
  log = insert millLogs { owner: customer, species, photo, priceCents, status: 'intake', timberGroup: timberGroup ?? 'unclassified' }
  insert queueSlots { log, intakeAt: log.intakeAt }
  return log

mutation queueLog(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  require exists staff[principal = viewer, role = 'sawyer'] or exists owners[viewer] else NOT_SAWYER
  require l.status = 'intake' else BAD_STATUS
  update millLogs[log] { status: 'queued' }
  return null

mutation startMilling(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  require exists staff[principal = viewer, role = 'sawyer'] or exists owners[viewer] else NOT_SAWYER
  require l.status = 'queued' else BAD_STATUS
  update millLogs[log] { status: 'milling' }
  if exists queueSlots[log]:
    delete queueSlots[log]
  return null

mutation finishMilling(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  require exists staff[principal = viewer, role = 'sawyer'] or exists owners[viewer] else NOT_SAWYER
  require l.status = 'milling' else BAD_STATUS
  update millLogs[log] { status: 'milled', milledAt: now }
  return null

mutation flagMetal(log: millLogs, feeCents: int 0..100000000):
  l = millLogs[log] ! else NOT_FOUND
  require exists staff[principal = viewer, role = 'sawyer'] or exists owners[viewer] else NOT_SAWYER
  require (l.status = 'milling' or l.status = 'milled') else BAD_STATUS
  update millLogs[log] { metalFound: true, bladeFeeCents: feeCents }
  return null

-- Only the mill owner may change a log's timber group after intake.
mutation setTimberGroup(log: millLogs, timberGroup: enum('softwood', 'hardwood', 'unclassified')):
  require exists owners[viewer] else NOT_OWNER
  l = millLogs[log] ! else NOT_FOUND
  update millLogs[log] { timberGroup }
  return null

mutation waiveBladeFee(log: millLogs, reason: text 1..500):
  require exists owners[viewer] else NOT_OWNER
  l = millLogs[log] ! else NOT_FOUND
  require l.metalFound else NO_METAL_FEE
  require not l.bladeFeeWaived else ALREADY_WAIVED
  update millLogs[log] { bladeFeeWaived: true, waiverReason: reason }
  return null

mutation collectLog(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  require l.owner = viewer or exists staff[viewer] or exists owners[viewer] else NOT_ALLOWED
  require l.status = 'milled' else BAD_STATUS
  update millLogs[log] { status: 'collected', collectedAt: now }
  return null

mutation addCut(log: millLogs, label: text 1..120, qty: int 1..1000, priceCents: int 0..100000000):
  l = millLogs[log] ! else NOT_FOUND
  require l.owner = viewer else NOT_LOG_OWNER
  require (l.status = 'intake' or l.status = 'queued') else CUT_LOCKED
  return insert cutItems { log, label, qty, priceCents }

mutation editCut(item: cutItems, label: text 1..120, qty: int 1..1000, priceCents: int 0..100000000):
  i = cutItems[item] ! else NOT_FOUND
  l = millLogs[i.log] ! else NOT_FOUND
  require l.owner = viewer else NOT_LOG_OWNER
  require (l.status = 'intake' or l.status = 'queued') else CUT_LOCKED
  update cutItems[item] { label, qty, priceCents }
  return null

mutation removeCut(item: cutItems):
  i = cutItems[item] ! else NOT_FOUND
  l = millLogs[i.log] ! else NOT_FOUND
  require l.owner = viewer else NOT_LOG_OWNER
  require (l.status = 'intake' or l.status = 'queued') else CUT_LOCKED
  delete cutItems[item]
  return null

-- Full rows with prices: the owning customer and the owner.
query myLogs(c: cursor ?):
  return millLogs where .owner = viewer first 100 by .intakeAt after c

query logDetail(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  require l.owner = viewer or exists owners[viewer] else NOT_ALLOWED
  return millLogs[log]

query queuePosition(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  ahead = count(queueSlots where .intakeAt < l.intakeAt)
  return { status: l.status, position: ahead + 1 if (l.status = 'intake' or l.status = 'queued') else 0 }

-- Milling view without prices: sawyers and the owner.
query millQueue(c: cursor ?):
  require exists staff[viewer] or exists owners[viewer] else NOT_STAFF
  return millLogs where .status in ['intake', 'queued', 'milling', 'milled'] first 100 by .intakeAt after c { id, species, timberGroup, status, intakeAt, owner, photo }

-- Cut list with prices: the owning customer and the owner.
query cutList(log: millLogs, c: cursor ?):
  l = millLogs[log] ! else NOT_FOUND
  require l.owner = viewer or exists owners[viewer] else NOT_ALLOWED
  return cutItems where .log = log first 100 by .id after c

-- Cut list without prices: any reader of the log (customer, staff, owner).
query cutListBlind(log: millLogs, c: cursor ?):
  l = millLogs[log] ! else NOT_FOUND
  return cutItems where .log = log first 100 by .id after c { id, label, qty }

query allLogs(c: cursor ?):
  require exists owners[viewer] else NOT_OWNER
  return millLogs first 100 by .intakeAt after c

query customerList(c: cursor ?):
  require exists staff[viewer] or exists owners[viewer] else NOT_STAFF
  return customers first 100 by .id after c

query myRole():
  return { owner: exists owners[viewer], staff: staff[viewer] }

query myCustomer():
  return customers[viewer]

-- Bill for one log: milling price, outstanding blade fee, and storage at
-- $2/day past 30 days after milling until collection.
query logBill(log: millLogs):
  l = millLogs[log] ! else NOT_FOUND
  require l.owner = viewer or exists owners[viewer] else NOT_ALLOWED
  end = l.collectedAt ?? now
  days = 0 if l.milledAt = null else (end - l.milledAt) / 1d
  late = days - 30 if days > 30 else 0
  return { priceCents: l.priceCents, bladeFeeCents: l.bladeFeeCents, bladeFeeWaived: l.bladeFeeWaived, waiverReason: l.waiverReason, storageCents: late * 200, milledAt: l.milledAt, collectedAt: l.collectedAt }
