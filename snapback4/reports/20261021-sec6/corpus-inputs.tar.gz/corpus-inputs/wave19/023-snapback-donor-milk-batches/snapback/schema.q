use identity password

table accounts:
  principal: principal
  role: enum('donor', 'lab', 'director', 'pharmacist')
  hospital: text 1..80 ?
  unique principal
  immutable principal, role, hospital
  read <- .principal = viewer or exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director']
  insert <- viewer = 'service:provisioner' or (.principal = viewer and .role = 'donor' and .hospital = null)
  online only

table donors:
  owner: principal
  name: text 1..80
  screening: enum('pending', 'clear', 'concern', 'approved', 'rejected') default 'pending'
  screeningNote: text 1..1000 ?
  screenedBy: principal ?
  decisionReason: text 10..1000 ?
  decidedBy: principal ?
  unique owner
  immutable owner, name
  read <- .owner = viewer or exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director']
  insert <- .owner = viewer and exists accounts[principal = viewer, role = 'donor']
  update <- exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director']
  online only

table donations:
  donor: donors
  owner: principal
  ml: int 50..10000
  collectedAt: time
  state: enum('pledged', 'received', 'pooled') default 'pledged'
  freezer: text 1..80 ?
  receivedBy: principal ?
  receivedAt: time ?
  batch: batches ?
  at: time default now
  immutable donor, owner, ml, collectedAt, at
  read <- .owner = viewer or exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director']
  insert <- .owner = viewer and exists accounts[principal = viewer, role = 'donor']
  update <- exists accounts[principal = viewer, role = 'lab']
  online only

table batches:
  label: text 1..80
  ml: int 50..200000
  state: enum('pooled', 'culturing', 'passed', 'failed', 'dispensed') default 'pooled'
  pasteurizedAt: time ?
  expiresAt: time ?
  culturePhoto: image <=5000000 ?
  cultureNote: text 1..1000 ?
  hospital: text 1..80 ?
  dispensedAt: time ?
  at: time default now
  immutable label, ml, at
  read <- exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director'] or exists accounts[principal = viewer, role = 'pharmacist', hospital = .hospital] or (exists accounts[principal = viewer, role = 'pharmacist'] and exists batchReaders[batch = .id, principal = viewer])
  insert <- exists accounts[principal = viewer, role = 'lab']
  update <- exists accounts[principal = viewer, role = 'lab']
  online only

table distributions:
  batch: batches
  reach: enum('not yet dispensed', 'one hospital', 'multiple hospitals')
  unique batch
  immutable batch
  read <- exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director']
  insert <- exists accounts[principal = viewer, role = 'lab']
  update <- exists accounts[principal = viewer, role = 'lab']
  online only

table batchReaders:
  batch: batches
  principal: principal
  unique batch, principal
  immutable batch, principal
  read <- .principal = viewer or exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director']
  insert <- exists accounts[principal = viewer, role = 'lab']
  online only

table custody:
  batch: batches
  actor: principal
  event: text 1..80
  note: text 1..1000
  at: time default now
  immutable batch, actor, event, note, at
  read through live .batch
  cap 25 by batch
  insert <- .actor = viewer and exists accounts[principal = viewer, role = 'lab']
  online only

mutation provision(principal: principal, role: enum('donor', 'lab', 'director', 'pharmacist'), hospital: text 1..80 ?):
  require viewer = 'service:provisioner' else FORBIDDEN
  require (role = 'pharmacist' and hospital != null) or (role != 'pharmacist' and hospital = null) else BAD_HOSPITAL
  return insert accounts { principal, role, hospital }

query me():
  return accounts[principal = viewer]

query donorList():
  require exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director'] else FORBIDDEN
  return donors first 200 by .id

query donorRecord(donor: donors):
  return donors[donor]

query myDonor():
  return donors[owner = viewer]

query donationList():
  require exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director'] else FORBIDDEN
  return donations first 500 by .id

query myDonations():
  return donations where .owner = viewer first 200 by .id { id, ml, collectedAt, state, at }

query donationRecord(donation: donations):
  d = donations[donation]
  return d { id, ml, collectedAt, state, at }

query batchBoard():
  require exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director'] else FORBIDDEN
  return batches last 200 by .at { *, distributionReach: distributions[batch = .id].reach }

fn hospitalDispatchTime(batch: batches, hospital: text 1..80 ?):
  result = null
  for event in custody where .batch = batch first 25 by .id:
    if event.event = 'Dispensed' and event.note = hospital:
      if event.at > (result ?? 0):
        result = event.at
  return result

query hospitalBatches():
  a = accounts[principal = viewer] ! else FORBIDDEN
  require a.role = 'pharmacist' else FORBIDDEN
  readers = batchReaders where .principal = viewer last 200 by .id
  result = []
  for r in readers:
    b = batches[r.batch]
    if b != null:
      result = result + [b { *, hospital: a.hospital, dispensedAt: hospitalDispatchTime(b.id, a.hospital) }]
  return result

query batchRecord(batch: batches):
  b = batches[batch]
  a = accounts[principal = viewer]
  if a != null and a.role = 'pharmacist':
    return b { *, hospital: a.hospital, dispensedAt: hospitalDispatchTime(batch, a.hospital) }
  return b { * }

query distributionReach(batch: batches):
  require exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director'] else FORBIDDEN
  require exists batches[batch] else NOT_FOUND
  return distributions[batch = batch] ! else MIGRATION_REQUIRED

query chain(batch: batches):
  require exists batches[batch] else NOT_FOUND
  a = accounts[principal = viewer]
  if a != null and a.role = 'pharmacist':
    return custody where .batch = batch and (.event != 'Dispensed' or .note = a.hospital) first 100 by .at
  return custody where .batch = batch first 100 by .at

query hospitals():
  require exists accounts[principal = viewer, role = 'lab'] or exists accounts[principal = viewer, role = 'director'] else FORBIDDEN
  return accounts where .role = 'pharmacist' first 100 by .id { hospital }

mutation registerDonor(name: text 1..80):
  if not exists accounts[principal = viewer]:
    insert accounts { principal: viewer, role: 'donor', hospital: null }
  return insert donors { owner: viewer, name }

mutation screenDonor(donor: donors, result: enum('clear', 'concern'), note: text 1..1000):
  require exists accounts[principal = viewer, role = 'lab'] else FORBIDDEN
  d = donors[donor] ! else NOT_FOUND
  require d.screening = 'pending' else ALREADY_SCREENED
  update donors[donor] { screening: result, screeningNote: note, screenedBy: viewer }

mutation decideConcern(donor: donors, approve: bool, reason: text 10..1000):
  require exists accounts[principal = viewer, role = 'director'] else FORBIDDEN
  d = donors[donor] ! else NOT_FOUND
  require d.screening = 'concern' else NO_CONCERN
  update donors[donor] { screening: 'approved' if approve else 'rejected', decisionReason: reason, decidedBy: viewer }

mutation donate(ml: int 50..10000, collectedAt: time):
  d = donors[owner = viewer] ! else NOT_FOUND
  require d.screening = 'clear' or d.screening = 'approved' else NOT_APPROVED
  require collectedAt <= now and collectedAt >= now - 180d else BAD_COLLECTION_DATE
  return insert donations { donor: d.id, owner: viewer, ml, collectedAt }

mutation receiveDonation(donation: donations, freezer: text 1..80):
  require exists accounts[principal = viewer, role = 'lab'] else FORBIDDEN
  d = donations[donation] ! else NOT_FOUND
  require d.state = 'pledged' else ALREADY_RECEIVED
  update donations[donation] { state: 'received', freezer, receivedBy: viewer, receivedAt: now }

mutation poolBatch(label: text 1..80, donations: [donations] <=20):
  require exists accounts[principal = viewer, role = 'lab'] else FORBIDDEN
  require len(donations) > 0 else EMPTY_POOL
  total = 0
  for donation in donations:
    d = donations[donation] ! else NOT_FOUND
    require d.state = 'received' else NOT_RECEIVED
    total = total + d.ml
  b = insert batches { label, ml: total }
  insert distributions { batch: b.id, reach: 'not yet dispensed' }
  for donation in donations:
    d = donations[donation] ! else NOT_FOUND
    require d.state = 'received' else NOT_RECEIVED
    update donations[donation] { state: 'pooled', batch: b.id }
    insert custody { batch: b.id, actor: viewer, event: 'Frozen milk received and pooled', note: d.freezer ?? 'Frozen storage' }
  return b

mutation pasteurize(batch: batches):
  require exists accounts[principal = viewer, role = 'lab'] else FORBIDDEN
  b = batches[batch] ! else NOT_FOUND
  require b.state = 'pooled' else BAD_STATE
  target = month(now) + 6
  dayIndex = day(now) - day(monthStart(month(now)))
  daysInTarget = day(monthStart(target + 1)) - day(monthStart(target))
  expiry = monthStart(target) + min(dayIndex, daysInTarget - 1) * 1d + now % 1d
  update batches[batch] { state: 'culturing', pasteurizedAt: now, expiresAt: expiry }
  insert custody { batch, actor: viewer, event: 'Pasteurized', note: 'Culture pending; six calendar month expiry set.' }

mutation recordCulture(batch: batches, passed: bool, photo: image <=5000000, note: text 1..1000):
  require exists accounts[principal = viewer, role = 'lab'] else FORBIDDEN
  b = batches[batch] ! else NOT_FOUND
  require b.state = 'culturing' else BAD_STATE
  require (b.expiresAt ?? 0) > now else EXPIRED
  update batches[batch] { state: 'passed' if passed else 'failed', culturePhoto: photo, cultureNote: note }
  insert custody { batch, actor: viewer, event: 'Culture passed' if passed else 'Culture failed', note }

mutation dispense(batch: batches, hospital: text 1..80):
  require exists accounts[principal = viewer, role = 'lab'] else FORBIDDEN
  b = batches[batch] ! else NOT_FOUND
  require b.state = 'passed' or b.state = 'dispensed' else CULTURE_NOT_PASSED
  require (b.pasteurizedAt ?? 0) <= now and (b.expiresAt ?? 0) > now else EXPIRED
  -- A target must have an actual pharmacist account.
  recipients = accounts where .role = 'pharmacist' and .hospital = hospital first 1 by .id
  require len(recipients) > 0 else UNKNOWN_HOSPITAL
  priorOther = exists custody where .batch = batch and .event = 'Dispensed' and .note != hospital
  upsert distributions[batch = batch] { batch, reach: 'multiple hospitals' if priorOther else 'one hospital' }
  for recipient in accounts where .role = 'pharmacist' and .hospital = hospital first 100 by .id:
    insert batchReaders { batch, principal: recipient.principal } if absent
  update batches[batch] { state: 'dispensed', hospital, dispensedAt: now }
  insert custody { batch, actor: viewer, event: 'Dispensed', note: hospital }

-- Idempotent, server-authoritative migration: reads every batch with a resumable job cursor.
-- Also reconciles v1-era writes after rollback; no defaults guess historical reach.
job reconcileDistribution():
  for b in batches:
    history = custody where .batch = b.id and .event = 'Dispensed' first 25 by .id
    hospitals = group(history, 'note') { hospital: .key }
    reach = 'not yet dispensed'
    if len(hospitals) = 1:
      reach = 'one hospital'
    if len(hospitals) > 1:
      reach = 'multiple hospitals'
    upsert distributions[batch = b.id] { batch: b.id, reach }
    for h in hospitals:
      for recipient in accounts where .role = 'pharmacist' and .hospital = h.hospital first 100 by .id:
        insert batchReaders { batch: b.id, principal: recipient.principal } if absent
