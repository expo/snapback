-- Gem Lab Certificates: intake -> blind double grading -> director resolution -> release.
-- Privacy shape: the submitting jeweler lives only on `submissions`;
-- `stones` carries no jeweler column, so graders read lab numbers only.
-- Grades are readable by their own grader and the director; the certificate
-- is a revealed copy the owning jeweler may read after release.
use identity password
use personas alice, bob

-- Roster: exactly one role per principal. First director is provisioned by
-- the service operator seat; afterwards directors manage the roster.
table roles:
  principal: principal
  role: enum('jeweler', 'grader', 'intake', 'director')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'director']
  insert <- exists roles[viewer, role = 'director'] or viewer = 'service:operator'
  update <- exists roles[viewer, role = 'director'] or viewer = 'service:operator'
  delete <- exists roles[viewer, role = 'director'] or viewer = 'service:operator'
  online only

-- A jeweler's submission. `stone` is linked by intake; before that it is null.
table submissions:
  jeweler: principal
  description: text 1..200
  weightCt: decimal 2
  shape: text 1..40
  status: enum('submitted', 'intaked') default 'submitted'
  stone: stones ?
  createdAt: time default now
  immutable jeweler, createdAt
  cap 500 by jeweler
  read <- .jeweler = viewer or exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director']
  insert <- .jeweler = viewer
  update <- exists roles[viewer, role = 'intake']
  online only

-- The lab stone. No jeweler column: graders see lab numbers only.
-- `gradeCount` is engine-maintained over private grades (parent readers
-- receive the count, including counts over private sources).
table stones:
  labNo: text 3..20
  submission: submissions
  weightCt: decimal 2
  -- Required intake weight band, derived from the recorded weight: weights
  -- below one carat (weightCt < 100 minor units) receive 'under-one-carat';
  -- weights of exactly one carat or higher receive 'one-carat-or-more'.
  -- Older rows adopt the literal default below; the intake desk corrects any
  -- mislabelled row through correctWeightBand.
  weightBand: enum('under-one-carat', 'one-carat-or-more') default 'under-one-carat'
  shape: text 1..40
  photos: [image <=5000000] <=4 ?
  location: enum('intake', 'grading', 'vault', 'released') default 'intake'
  released: bool default false
  intakeAt: time default now
  gradeCount: count grades by stone
  immutable labNo, intakeAt, submission
  unique labNo else LABNO_TAKEN
  unique submission
  cap 5000
  read <- exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'grader'] or exists submissions[.submission, jeweler = viewer]
  insert <- exists roles[viewer, role = 'intake']
  update <- exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director']
  online only

-- Blind grades: a grader reads only their own grade; the director reads both.
-- At most two grades per stone (two independent graders).
table grades:
  stone: stones
  grader: principal
  color: text 1..20
  clarity: text 1..20
  cut: text 1..20
  comment: text <=500 ?
  at: time default now
  immutable stone, grader
  unique stone, grader else ALREADY_GRADED
  cap 2 by stone
  read <- .grader = viewer or exists roles[viewer, role = 'director']
  insert <- .grader = viewer and exists roles[viewer, role = 'grader']
  online only

-- Director-only split resolution: keeps both grades, records the final call.
table resolutions:
  stone: stones
  color: text 1..20
  clarity: text 1..20
  cut: text 1..20
  reason: text 1..500
  director: principal
  at: time default now
  unique stone
  immutable stone
  read <- exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'intake']
  insert <- .director = viewer and exists roles[viewer, role = 'director']
  update <- .director = viewer and exists roles[viewer, role = 'director']
  online only

-- Revealed copy: readable by the owning jeweler only once it exists.
table certificates:
  stone: stones
  submission: submissions
  labNo: text 3..20
  weightCt: decimal 2
  shape: text 1..40
  color: text 1..20
  clarity: text 1..20
  cut: text 1..20
  issuedAt: time default now
  releasedBy: principal
  unique stone
  immutable stone, submission, labNo, weightCt, shape, color, clarity, cut, issuedAt, releasedBy
  read <- exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'intake'] or exists submissions[id = .submission, jeweler = viewer]
  insert <- exists roles[viewer, role = 'director'] and exists stones[.stone, submission = .submission]
  online only

-- Bag movements. The intake desk watches these live; jewelers track their own.
table movements:
  stone: stones
  submission: submissions
  location: enum('intake', 'grading', 'vault', 'released')
  at: time default now
  mover: principal
  immutable stone, location, at, submission, mover
  cap 200 by stone
  read <- exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'intake'] or exists submissions[id = .submission, jeweler = viewer]
  insert <- (exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director']) and exists stones[.stone, submission = .submission]
  online only

query myRole():
  return roles[viewer]

query roster(c: cursor ?):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  return roles last 50 by .principal after c

query mySubmissions(c: cursor ?):
  return submissions where .jeweler = viewer last 50 by .createdAt after c

query intakeQueue(c: cursor ?):
  require exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director'] else NOT_INTAKE
  return submissions last 50 by .createdAt after c

query labStones(c: cursor ?):
  require exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director'] else NOT_INTAKE
  return stones last 100 by .intakeAt after c

query gradingQueue(c: cursor ?):
  require exists roles[viewer, role = 'grader'] else NOT_GRADER
  return stones where not .released last 100 by .intakeAt after c

query myGrades(c: cursor ?):
  require exists roles[viewer, role = 'grader'] else NOT_GRADER
  return grades where .grader = viewer last 100 by .at after c

query gradesForStone(stone: stones):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  s = stones[stone] ! else NOT_FOUND
  return grades where .stone = s.id first 10 by .at

query stoneDetail(stone: stones):
  return stones[stone]

query movementsFor(stone: stones, c: cursor ?):
  return movements where .stone = stone last 50 by .at after c

query myCertificates(c: cursor ?):
  return certificates where exists submissions[.submission, jeweler = viewer] last 50 by .issuedAt after c

query certificateFor(stone: stones):
  return certificates[stone]

query resolutionFor(stone: stones):
  return resolutions[stone]

query overdueStones(c: cursor ?):
  require exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director'] else NOT_INTAKE
  return stones where .intakeAt <= now - 10d and not .released and .gradeCount < 2 last 50 by .intakeAt after c

mutation provision(who: principal, role: enum('jeweler', 'grader', 'intake', 'director')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal = who] { principal: who, role }

mutation grantRole(who: principal, role: enum('jeweler', 'grader', 'intake', 'director')):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  return upsert roles[principal = who] { principal: who, role }

mutation submitStone(description: text 1..200, weightCt: decimal 2, shape: text 1..40):
  require exists roles[viewer, role = 'jeweler'] else NOT_JEWELER
  require weightCt >= 1 and weightCt <= 100000 else BAD_WEIGHT 'Declared weight must be 0.01 to 1000 carats.'
  return insert submissions { jeweler: viewer, description, weightCt, shape }

mutation intakeStone(submission: submissions, labNo: text 3..20, weightCt: decimal 2, shape: text 1..40, photos: [image <=5000000] <=4 ?):
  require exists roles[viewer, role = 'intake'] else NOT_INTAKE
  require weightCt >= 1 and weightCt <= 100000 else BAD_WEIGHT 'Weight must be 0.01 to 1000 carats.'
  sub = submissions[submission] ! else NOT_FOUND
  require sub.status = 'submitted' else ALREADY_INTAKED 'This submission is already intaked.'
  band = 'one-carat-or-more' if weightCt >= 100 else 'under-one-carat'
  s = insert stones { labNo, submission, weightCt, weightBand: band, shape, photos }
  update submissions[submission] { status: 'intaked', stone: s.id }
  insert movements { stone: s.id, submission, location: 'intake', mover: viewer }
  return s

-- Intake-only weight-band correction. The band must always match the stone's
-- recorded weight under the intake rule (< 1.00 ct vs >= 1.00 ct), so this
-- repairs mislabelled rows (including rows released before v2) and refuses
-- any other value. Graders, jewelers and directors cannot call it; no other
-- mutation writes weightBand, so graders cannot change it either.
mutation correctWeightBand(stone: stones, weightBand: enum('under-one-carat', 'one-carat-or-more')):
  require exists roles[viewer, role = 'intake'] else NOT_INTAKE
  s = stones[stone] ! else NOT_FOUND
  expected = 'one-carat-or-more' if s.weightCt >= 100 else 'under-one-carat'
  require weightBand = expected else BAND_MISMATCH 'The band must match the recorded weight: under one carat below 1.00 ct, one carat or more at or above.'
  update stones[stone] { weightBand }
  return stones[stone]

mutation moveStone(stone: stones, location: enum('intake', 'grading', 'vault', 'released')):
  require exists roles[viewer, role = 'intake'] else NOT_INTAKE
  require location != 'released' else USE_RELEASE 'Releasing a stone mints its certificate; call releaseStone.'
  s = stones[stone] ! else NOT_FOUND
  require not s.released else ALREADY_RELEASED
  update stones[stone] { location }
  return insert movements { stone, submission: s.submission, location, mover: viewer }

mutation gradeStone(stone: stones, color: text 1..20, clarity: text 1..20, cut: text 1..20, comment: text <=500 ?):
  require exists roles[viewer, role = 'grader'] else NOT_GRADER
  s = stones[stone] ! else NOT_FOUND
  require not s.released else ALREADY_RELEASED
  return insert grades { stone, grader: viewer, color, clarity, cut, comment }

mutation resolveSplit(stone: stones, gradeA: grades, gradeB: grades, color: text 1..20, clarity: text 1..20, cut: text 1..20, reason: text 1..500):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  s = stones[stone] ! else NOT_FOUND
  require not s.released else ALREADY_RELEASED
  ga = grades[gradeA] ! else NOT_FOUND
  gb = grades[gradeB] ! else NOT_FOUND
  require ga.stone = stone and gb.stone = stone else WRONG_STONE 'Both grades must belong to this stone.'
  require ga.grader != gb.grader else SAME_GRADER 'A split needs two independent graders.'
  require ga.color != gb.color or ga.clarity != gb.clarity or ga.cut != gb.cut else NOT_SPLIT 'The grades agree; nothing to resolve.'
  return upsert resolutions[stone] { stone, color, clarity, cut, reason, director: viewer }

mutation releaseStone(stone: stones, gradeA: grades, gradeB: grades):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  s = stones[stone] ! else NOT_FOUND
  require not s.released else ALREADY_RELEASED
  require s.gradeCount >= 2 else NEED_TWO_GRADES 'Two independent grades are required before release.'
  ga = grades[gradeA] ! else NOT_FOUND
  gb = grades[gradeB] ! else NOT_FOUND
  require ga.stone = stone and gb.stone = stone else WRONG_STONE 'Both grades must belong to this stone.'
  require ga.grader != gb.grader else SAME_GRADER 'Release needs two independent graders.'
  certColor = ga.color
  certClarity = ga.clarity
  certCut = ga.cut
  if ga.color != gb.color or ga.clarity != gb.clarity or ga.cut != gb.cut:
    r = resolutions[stone] ! else SPLIT_UNRESOLVED 'Split grades need a director resolution before release.'
    certColor = r.color
    certClarity = r.clarity
    certCut = r.cut
  cert = insert certificates { stone, submission: s.submission, labNo: s.labNo, weightCt: s.weightCt, shape: s.shape, color: certColor, clarity: certClarity, cut: certCut, releasedBy: viewer }
  update stones[stone] { released: true, location: 'released' }
  insert movements { stone, submission: s.submission, location: 'released', mover: viewer }
  return cert

-- Independent privacy intent; `guide security` states unproved paths.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'director']
invariant submissions.read only .jeweler = viewer or exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director']
invariant stones.read only exists roles[viewer, role = 'intake'] or exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'grader'] or exists submissions[.submission, jeweler = viewer]
invariant grades.read only .grader = viewer or exists roles[viewer, role = 'director']
invariant resolutions.read only exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'intake']
invariant certificates.read only exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'intake'] or exists submissions[id = .submission, jeweler = viewer]
invariant movements.read only exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'intake'] or exists submissions[id = .submission, jeweler = viewer]
