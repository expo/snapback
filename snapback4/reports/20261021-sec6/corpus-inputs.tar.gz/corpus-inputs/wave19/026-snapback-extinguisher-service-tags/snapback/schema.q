-- Extinguisher Service Tags.
-- A fire protection company services extinguishers in client buildings.
-- Technicians log inspections with tag + gauge photos. A unit comes due
-- 12 calendar months after its last inspection (due at the first instant of
-- that month); units due within 30 days are on the dispatcher's route list.
-- Building managers see only their own buildings' units, technicians only
-- buildings on their assigned routes, dispatchers watch inspections land
-- live. Only the service manager takes a unit out of service / returns it,
-- with the reason recorded and visible to the client.
use identity password

-- Roster: one row per person. Readers see only their own row; rule probes
-- below still test any row (rule `exists` does not borrow the read rule).
-- The first service manager is enrolled by the ops seat's Bearer [REDACTED]
-- (minted with `snapback4 token --service ops` against the store).
table roles:
  principal: principal
  role: enum('dispatcher', 'technician', 'building_manager', 'service_manager')
  unique principal
  cap 200
  read <- .principal = viewer
  insert <- exists roles[viewer, role = 'service_manager'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'service_manager'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'service_manager'] or viewer = 'service:ops'
  online only

table buildings:
  name: text 1..80
  address: text 1..200
  manager: principal
  immutable manager
  cap 500
  read <- .manager = viewer or exists routes[technician = viewer, building = .id] or exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  insert <- exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  update <- exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  delete <- exists roles[viewer, role = 'service_manager']
  online only

-- A technician's assignment to a building. Managed by dispatch.
table routes:
  technician: principal
  building: buildings
  unique technician, building
  cap 500 by technician
  immutable technician, building
  read <- .technician = viewer or exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  insert <- exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  delete <- exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  online only

table units:
  building: buildings
  label: text 1..40
  location: text 1..120
  -- v2: 'out_of_service' is retired but stays declared so rows written before
  -- the rename (and releases rolled back to v1) keep reading instead of going
  -- dormant. No write path below produces it; new decisions record
  -- 'unavailable_for_use'. See adoptUnavailableWording.
  status: enum('in_service', 'out_of_service', 'unavailable_for_use') default 'in_service'
  statusReason: text 1..500 ?
  statusAt: time ?
  statusBy: principal ?
  installedAt: time default now
  lastServicedAt: time default now
  dueAt: time default now
  immutable building, label
  unique building, label else LABEL_TAKEN
  cap 2000 by building
  read through .building
  insert <- exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
  update <- exists roles[viewer, role = 'service_manager'] or exists routes[technician = viewer, building = .building]
  online only

-- One inspection log per visit. Insert-only: history is never rewritten.
table inspections:
  unit: units
  technician: principal
  at: time default now
  tagPhoto: image <=10000000
  gaugePhoto: image <=10000000
  gauge: enum('normal', 'low', 'high', 'damaged')
  notes: text <=500 ?
  immutable unit, technician, at
  cap 5000 by unit
  read through .unit
  insert <- .technician = viewer and exists routes[technician = viewer, building = .unit.building]
  online only

-- Everyone's own role, for gating the UI. Rules still decide permission.
query myRole():
  return roles[principal = viewer]

-- Dispatchers and service managers see every building on one page.
query buildingsAll(c: cursor ?):
  require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'service_manager'] else NOT_STAFF
  return buildings last 50 by .id after c

-- A building manager's own buildings.
query buildingsManaged(c: cursor ?):
  require exists roles[principal = viewer, role = 'building_manager'] else NOT_MANAGER_CLIENT
  return buildings where .manager = viewer last 50 by .id after c

-- The buildings on the signed-in technician's routes.
query buildingsAssigned(c: cursor ?):
  require exists roles[principal = viewer, role = 'technician'] else NOT_TECHNICIAN
  return buildings where exists routes[technician = viewer, building = .id] last 50 by .id after c

-- Units of one building. Rows outside the caller's audience read as missing,
-- so an unauthorized caller gets an empty page, never another client's rows.
query unitsOf(building: buildings, c: cursor ?):
  return units where .building = building last 100 by .id after c

-- The dispatcher's route list: every unit due within the next 30 days
-- (including overdue ones). New units start due at installation.
query routeList(c: cursor ?):
  require exists roles[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
  return units where .dueAt <= now + 30d last 100 by .dueAt after c { id, label, location, status, dueAt, lastServicedAt, site: buildings[.building] }

-- Inspection history of one unit, newest first.
query inspectionsOf(unit: units, c: cursor ?):
  return inspections where .unit = unit last 50 by .at after c

-- Live feed the dispatcher watches while technicians work.
query recentInspections(c: cursor ?):
  require exists roles[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
  return inspections last 50 by .at after c { id, at, technician, gauge, notes, logged: units[.unit] }

mutation grantRole(who: principal, role: enum('dispatcher', 'technician', 'building_manager', 'service_manager')):
  require exists roles[principal = viewer, role = 'service_manager'] or viewer = 'service:ops' else NOT_MANAGER
  return upsert roles[principal = who] { principal: who, role }

mutation addBuilding(name: text 1..80, address: text 1..200, manager: principal):
  require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'service_manager'] else NOT_STAFF
  return insert buildings { name, address, manager }

mutation addUnit(building: buildings, label: text 1..40, location: text 1..120):
  require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'service_manager'] else NOT_STAFF
  b = buildings[building] ! else NOT_FOUND
  return insert units { building: b.id, label, location }

mutation assignRoute(technician: principal, building: buildings):
  require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'service_manager'] else NOT_STAFF
  b = buildings[building] ! else NOT_FOUND
  return insert routes { technician, building: b.id }

mutation unassignRoute(technician: principal, building: buildings):
  require exists roles[principal = viewer, role = 'dispatcher'] or exists roles[principal = viewer, role = 'service_manager'] else NOT_STAFF
  r = routes[technician, building] ! else NOT_FOUND
  delete routes[r.id]
  return null

mutation logInspection(unit: units, tagPhoto: image <=10000000, gaugePhoto: image <=10000000, gauge: enum('normal', 'low', 'high', 'damaged'), notes: text <=500 ?, performedAt: time ?):
  require exists roles[principal = viewer, role = 'technician'] else NOT_TECHNICIAN
  u = units[unit] ! else NOT_FOUND
  require exists routes[technician = viewer, building = u.building] else NOT_ON_ROUTE
  at = performedAt ?? now
  require at <= now else IN_FUTURE
  require at >= u.lastServicedAt else STALE
  due = monthStart(month(at) + 12)
  update units[unit] { lastServicedAt: at, dueAt: due }
  return insert inspections { unit, technician: viewer, at, tagPhoto, gaugePhoto, gauge, notes }

-- v2: records 'unavailable_for_use' (the renamed status). Name and arguments
-- are unchanged so v1 clients keep calling it.
mutation setOutOfService(unit: units, reason: text 1..500):
  require exists roles[principal = viewer, role = 'service_manager'] else NOT_MANAGER
  u = units[unit] ! else NOT_FOUND
  require u.status = 'in_service' else ALREADY_OUT
  update units[unit] { status: 'unavailable_for_use', statusReason: reason, statusAt: now, statusBy: viewer }
  return null

-- v2: returns an 'unavailable_for_use' unit to service. Any service manager
-- may do this (unchanged authority); name and arguments are unchanged.
mutation returnToService(unit: units):
  require exists roles[principal = viewer, role = 'service_manager'] else NOT_MANAGER
  u = units[unit] ! else NOT_FOUND
  require u.status = 'unavailable_for_use' else ALREADY_IN_SERVICE
  update units[unit] { status: 'in_service', statusReason: null, statusAt: now, statusBy: viewer }
  return null

-- v2: correct the reason of an 'unavailable_for_use' decision. Only the
-- service manager who recorded it (statusBy) may correct it: other service
-- managers get NOT_RECORDER, and technicians, building managers and
-- dispatchers get NOT_MANAGER. Nothing else changes: the status, who
-- recorded it and when are preserved, and the reason stays visible to the
-- unit's readers through the unchanged unitsOf read path.
mutation correctUnavailableReason(unit: units, reason: text 1..500):
  require exists roles[principal = viewer, role = 'service_manager'] else NOT_MANAGER
  u = units[unit] ! else NOT_FOUND
  require u.status = 'unavailable_for_use' else NOT_UNAVAILABLE
  require u.statusBy = viewer else NOT_RECORDER
  update units[unit] { statusReason: reason }
  return null

-- v2 migration: adopt the renamed status for one legacy row, preserving its
-- recorded reason, recorder and timestamp. Service managers only; refused
-- with NOTHING_TO_MIGRATE when there is nothing to convert. The production
-- proofs iterate this over every pre-v2 'out_of_service' row (idempotent).
mutation adoptUnavailableWording(unit: units):
  require exists roles[principal = viewer, role = 'service_manager'] else NOT_MANAGER
  u = units[unit] ! else NOT_FOUND
  require u.status = 'out_of_service' else NOTHING_TO_MIGRATE
  update units[unit] { status: 'unavailable_for_use' }
  return null

-- Independent privacy intent; guide security states unproved paths.
invariant roles.read only .principal = viewer
invariant buildings.read only .manager = viewer or exists routes[technician = viewer, building = .id] or exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
-- units inherit their building's readers (read through .building), so the
-- building manager sees them too; the roster/route arms restate directly.
invariant units.read only exists routes[technician = viewer, building = .building] or exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
invariant inspections.read only exists routes[technician = viewer, building = .unit.building] or exists roles[viewer, role = 'dispatcher'] or exists roles[viewer, role = 'service_manager']
