-- Hyperbaric Chamber Log.
-- Roles: physician, operator, attendant, technician (staff roster) + patient.
-- Real auth: email + password accounts. No dev personas.
use identity password

-- Singleton bootstrap: exactly one unit row, created once by the founding
-- physician together with their own staff row. `cap 1` refuses a second
-- founder; every later physician is created by a physician.
table unit:
  founder: principal
  foundedAt: time default now
  unique founder
  cap 1
  read <- allow
  insert <- .founder = viewer
  online only

-- Staff roster. Anyone may claim a non-physician seat for themselves;
-- physician seats require an existing physician (or the founder flow).
-- The roster is readable by its owner and by physicians.
table staff:
  principal: principal
  name: text 1..80
  role: enum('physician', 'operator', 'attendant', 'technician')
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[principal = viewer, role = 'physician']
  insert <- (.principal = viewer and .role != 'physician') or exists staff[principal = viewer, role = 'physician'] or created unit[founder = viewer]
  update (old, next) <- exists staff[principal = viewer, role = 'physician'] or (old.principal = viewer and next.principal = old.principal and next.role = old.role)
  delete <- exists staff[principal = viewer, role = 'physician']
  online only

-- Patients. Anyone may register themselves; staff may register anyone.
-- A patient reads only their own row; any staff member reads the census.
table patients:
  principal: principal
  name: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[viewer]
  insert <- .principal = viewer or exists staff[viewer]
  update <- .principal = viewer or exists staff[principal = viewer, role = 'physician']
  online only

-- Diagnoses. Technicians are deliberately excluded from the read rule:
-- they see treatments but never diagnoses.
table diagnoses:
  patient: patients
  patientPrincipal: principal
  text: text 1..2000
  author: principal
  at: time default now
  immutable patient, patientPrincipal, author
  read <- .patientPrincipal = viewer or exists staff[principal = viewer, role = 'physician'] or exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'attendant']
  insert <- exists staff[principal = viewer, role = 'physician']
  update <- exists staff[principal = viewer, role = 'physician']
  delete <- exists staff[principal = viewer, role = 'physician']
  cap 500 by patient
  online only

-- Treatment plans. A plan ends after its prescribed (+ extended) sessions
-- or 60 days after it starts; only a physician creates or extends one.
table plans:
  patient: patients
  patientPrincipal: principal
  physician: principal
  prescribedSessions: int 1..60
  startAt: time
  createdAt: time default now
  immutable patient, patientPrincipal, physician, prescribedSessions, startAt
  read <- .patientPrincipal = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'physician']
  cap 20 by patientPrincipal
  online only

-- Prescription history (v2). Every treatment plan carries a required
-- description: 'original' (the original prescription) or 'extended' (extended
-- by physician). It lives in its own table so its audience can stay narrow:
-- only the hyperbaric physician and the patient concerned may see it;
-- technicians, operators, inside attendants and other patients may not.
-- New plans start as 'original' (written by createPlan); extendPlan flips the
-- row to 'extended', where it stays after completion. Plans that predate v2
-- get their row from backfillRxHistory: 'extended' when a recorded physician
-- extension exists, otherwise 'original'. prescriptionHistory falls back to
-- the same derivation when a row is absent, so the description is always
-- present (required) even for rows written while an older release was live.
table prescription_histories:
  plan: plans
  patientPrincipal: principal
  history: enum('original', 'extended') default 'original'
  unique plan
  immutable plan, patientPrincipal
  read <- .patientPrincipal = viewer or exists staff[principal = viewer, role = 'physician']
  insert <- exists staff[principal = viewer, role = 'physician']
  update (old, next) <- exists staff[principal = viewer, role = 'physician']
  online only

-- Plan extensions. Only a physician, with the reason recorded.
table plan_extensions:
  plan: plans
  patientPrincipal: principal
  physician: principal
  extraSessions: int 1..20
  reason: text 1..500
  at: time default now
  immutable plan, patientPrincipal, physician, extraSessions, reason
  read <- .patientPrincipal = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'physician']
  cap 20 by plan
  online only

view sessionCounts: count treatments by .plan, .patientPrincipal
  read <- .patientPrincipal = viewer or exists staff[viewer]
  online only

view planExtras: sum plan_extensions of .extraSessions by .plan, .patientPrincipal
  read <- .patientPrincipal = viewer or exists staff[viewer]
  online only

-- Signed consent scans. A consent must be on file before any session is
-- logged. Operators and physicians file them.
table consents:
  patient: patients
  patientPrincipal: principal
  scan: image <=10000000
  uploadedBy: principal
  at: time default now
  unique patient
  immutable patient, patientPrincipal, scan
  read <- .patientPrincipal = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'physician']
  online only

-- Treatment sessions. The operator logs the pressure profile with a photo
-- of the safety checklist before every session. Attendants and operators
-- watch the timer (startedAt/endsAt) and patient status live.
table treatments:
  plan: plans
  patient: patients
  patientPrincipal: principal
  operator: principal
  profile: text 1..4000
  maxKpa: int 100..400
  checklistPhoto: image <=10000000
  coldReported: bool default false
  coldApproved: bool default false
  coldReason: text <=500 ?
  coldApprovedBy: principal ?
  status: enum('planned', 'in_progress', 'completed', 'cancelled') default 'planned'
  patientStatus: enum('stable', 'nausea', 'ear-pain', 'anxious', 'emergency', 'resting') default 'stable'
  startedAt: time ?
  endsAt: time ?
  currentKpa: int 0..400 ?
  at: time default now
  immutable plan, patient, patientPrincipal, operator, profile, checklistPhoto
  read <- .patientPrincipal = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'physician']
  update (old, next) <- exists staff[principal = viewer, role = 'physician'] or exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'attendant'] or exists patients[old.patient, principal = viewer]
  cap 80 by plan
  online only

-- Reads

query whoAmI():
  return viewer

query myStaff():
  return staff[principal = viewer]

query myPatient():
  return patients[principal = viewer]

query staffList(c: cursor ?):
  if exists staff[viewer, role = 'physician']:
    return staff after c first 50 by .principal
  return staff where .principal = viewer after c first 50 by .principal

query patientList(c: cursor ?):
  if exists staff[viewer]:
    return patients after c first 50 by .principal
  return patients where .principal = viewer after c first 50 by .principal

query plansFor(patient: patients, c: cursor ?):
  return plans where .patient = patient after c first 50 by .id

query planStatus(plan: plans):
  p = plans[plan] ! else NOT_FOUND
  used = sessionCounts[p.id, p.patientPrincipal] ?? 0
  extra = planExtras[p.id, p.patientPrincipal] ?? 0
  total = p.prescribedSessions + extra
  expired = now > p.startAt + 60d
  return { plan: p, used, extra, total, expired, ended: used >= total or expired }

query treatmentsFor(patient: patients, c: cursor ?):
  return treatments where .patient = patient after c first 50 by .at

query treatmentsForPlan(plan: plans, c: cursor ?):
  return treatments where .plan = plan after c first 50 by .at

query treatmentDetail(treatment: treatments):
  return treatments[treatment]

query liveChamber(c: cursor ?):
  if exists staff[viewer]:
    return treatments where .status = 'in_progress' after c first 20 by .at
  return treatments where .status = 'in_progress' and .patientPrincipal = viewer after c first 20 by .at

query diagnosesFor(patient: patients, c: cursor ?):
  return diagnoses where .patient = patient after c first 20 by .at

query consentsFor(patient: patients, c: cursor ?):
  return consents where .patient = patient after c first 20 by .at

query extensionsFor(plan: plans, c: cursor ?):
  return plan_extensions where .plan = plan after c first 20 by .at

-- Required prescription history description for one plan: 'original
-- prescription' or 'extended by physician'. Visible only to the hyperbaric
-- physician and the patient concerned; everyone else gets NOT_FOUND, the same
-- answer as for a plan they cannot see. The stored row (written by
-- createPlan, flipped by extendPlan, backfilled for older plans) wins; when
-- no row exists the value derives from the recorded extensions, so the
-- description is always present and always truthful.
query prescriptionHistory(plan: plans):
  p = plans[plan] ! else NOT_FOUND
  require p.patientPrincipal = viewer or exists staff[principal = viewer, role = 'physician'] else NOT_FOUND 'Only the hyperbaric physician and the patient concerned see the prescription history.'
  h = prescription_histories[plan = p.id]
  extended = h.history = 'extended' if h != null else exists plan_extensions where .plan = p.id
  return { plan: p.id, extended, history: 'extended by physician' if extended else 'original prescription' }

-- Writes

mutation foundUnit(name: text 1..80):
  require not exists staff[viewer] else ALREADY_STAFF 'This account already holds a staff seat.'
  insert unit { founder: viewer }
  return insert staff { principal: viewer, name, role: 'physician' }

mutation registerStaff(role: text 1..20, name: text 1..80):
  require not exists staff[viewer] else ALREADY_STAFF 'This account already holds a staff seat.'
  require role = 'operator' or role = 'attendant' or role = 'technician' else BAD_ROLE 'Physician seats are granted by a physician.'
  return insert staff { principal: viewer, name, role: role }

-- Physician seats are granted by a physician: the candidate files a claim,
-- a physician seats it. (A mutation only ever sees its own caller, so the
-- candidate must first make themselves visible through a claim row.)
table physician_claims:
  claimant: principal
  name: text 1..80
  unique claimant
  immutable claimant
  read <- .claimant = viewer or exists staff[principal = viewer, role = 'physician']
  insert <- .claimant = viewer
  delete <- .claimant = viewer or exists staff[principal = viewer, role = 'physician']
  online only

query physicianClaims(c: cursor ?):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician reviews physician claims.'
  return physician_claims after c first 50 by .claimant

mutation claimPhysicianSeat(name: text 1..80):
  require not exists staff[viewer] else ALREADY_STAFF 'This account already holds a staff seat.'
  return insert physician_claims { claimant: viewer, name }

mutation seatPhysicianClaim(claim: physician_claims):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician grants physician seats.'
  c = physician_claims[claim] ! else NOT_FOUND
  require not exists staff[c.claimant] else ALREADY_STAFF 'This account already holds a staff seat.'
  delete physician_claims[claim]
  return insert staff { principal: c.claimant, name: c.name, role: 'physician' }

mutation createPatientProfile(name: text 1..80):
  require not exists patients[principal = viewer] else ALREADY_PATIENT 'This account already has a patient profile.'
  return insert patients { principal: viewer, name }

mutation recordDiagnosis(patient: patients, text: text 1..2000):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician records diagnoses.'
  p = patients[patient] ! else NOT_FOUND
  return insert diagnoses { patient: p.id, patientPrincipal: p.principal, text, author: viewer }

mutation createPlan(patient: patients, prescribedSessions: int 1..60, startAt: time):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician creates treatment plans.'
  require startAt <= now else BAD_START 'A plan cannot start in the future.'
  p = patients[patient] ! else NOT_FOUND
  pl = insert plans { patient: p.id, patientPrincipal: p.principal, physician: viewer, prescribedSessions, startAt }
  insert prescription_histories { plan: pl.id, patientPrincipal: pl.patientPrincipal, history: 'original' }
  return pl

mutation extendPlan(plan: plans, extraSessions: int 1..20, reason: text 1..500):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician extends a treatment plan.'
  p = plans[plan] ! else NOT_FOUND
  ext = insert plan_extensions { plan: p.id, patientPrincipal: p.patientPrincipal, physician: viewer, extraSessions, reason }
  upsert prescription_histories[p.id] { patientPrincipal: p.patientPrincipal, history: 'extended' }
  return ext

-- Backfill for plans that predate v2 (or were written while an older release
-- was live): records 'extended' when a physician extension is on file,
-- otherwise 'original'. Idempotent: plans that already carry a row keep it.
mutation backfillRxHistory(plan: plans):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician backfills prescription history.'
  p = plans[plan] ! else NOT_FOUND
  extended = exists plan_extensions where .plan = p.id
  insert prescription_histories { plan: p.id, patientPrincipal: p.patientPrincipal, history: 'extended' if extended else 'original' } if absent
  return prescription_histories[plan = p.id]

mutation uploadConsent(patient: patients, scan: image <=10000000):
  require exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'physician'] else NOT_AUTHORIZED 'Only the chamber operator or physician files consent scans.'
  p = patients[patient] ! else NOT_FOUND
  return insert consents { patient: p.id, patientPrincipal: p.principal, scan, uploadedBy: viewer }

mutation logTreatment(plan: plans, profile: text 1..4000, maxKpa: int 100..400, photo: image <=10000000, coldReported: bool ?):
  require exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'physician'] else NOT_AUTHORIZED 'Only the chamber operator logs treatments.'
  p = plans[plan] ! else NOT_FOUND
  require exists consents[patient = p.patient] else NO_CONSENT 'A signed consent scan must be on file before the first session.'
  used = sessionCounts[p.id, p.patientPrincipal] ?? 0
  extra = planExtras[p.id, p.patientPrincipal] ?? 0
  require used < p.prescribedSessions + extra else PLAN_COMPLETE 'This plan has used all of its prescribed sessions.'
  require now <= p.startAt + 60d else PLAN_EXPIRED 'This plan ended 60 days after it started.'
  cold = coldReported ?? false
  return insert treatments { plan: p.id, patient: p.patient, patientPrincipal: p.patientPrincipal, operator: viewer, profile, maxKpa, checklistPhoto: photo, coldReported: cold }

mutation reportCold(treatment: treatments):
  t = treatments[treatment] ! else NOT_FOUND
  p = patients[t.patient] ! else NOT_FOUND
  require p.principal = viewer else NOT_PATIENT 'Only the patient reports a cold on their own session.'
  require not t.coldReported else ALREADY_REPORTED 'A cold is already reported on this session.'
  update treatments[treatment] { coldReported: true }
  return null

mutation approveCold(treatment: treatments, reason: text 1..500):
  require exists staff[principal = viewer, role = 'physician'] else NOT_PHYSICIAN 'Only a hyperbaric physician approves treating a patient who reports a cold.'
  t = treatments[treatment] ! else NOT_FOUND
  require t.coldReported else NO_COLD 'No cold is reported on this session.'
  require not t.coldApproved else ALREADY_APPROVED 'This cold approval is already recorded.'
  update treatments[treatment] { coldApproved: true, coldReason: reason, coldApprovedBy: viewer }
  return null

mutation beginTreatment(treatment: treatments):
  require exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'physician'] else NOT_AUTHORIZED 'Only the chamber operator starts a session.'
  t = treatments[treatment] ! else NOT_FOUND
  require t.status = 'planned' else BAD_STATUS 'Only a planned session can start.'
  require not t.coldReported or t.coldApproved else COLD_APPROVAL_REQUIRED 'A reported cold needs physician approval first.'
  p = plans[t.plan] ! else NOT_FOUND
  require now <= p.startAt + 60d else PLAN_EXPIRED 'This plan ended 60 days after it started.'
  update treatments[treatment] { status: 'in_progress', startedAt: now }
  return null

mutation completeTreatment(treatment: treatments):
  require exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'physician'] else NOT_AUTHORIZED 'Only the chamber operator completes a session.'
  t = treatments[treatment] ! else NOT_FOUND
  require t.status = 'in_progress' else BAD_STATUS 'Only a session in progress can complete.'
  update treatments[treatment] { status: 'completed', endsAt: now }
  return null

mutation updatePatientStatus(treatment: treatments, status: text 1..20, currentKpa: int 0..400 ?):
  require exists staff[principal = viewer, role = 'operator'] or exists staff[principal = viewer, role = 'attendant'] or exists staff[principal = viewer, role = 'physician'] else NOT_AUTHORIZED 'Only chamber crew update patient status.'
  require status = 'stable' or status = 'nausea' or status = 'ear-pain' or status = 'anxious' or status = 'emergency' or status = 'resting' else BAD_STATUS_VALUE 'Unknown patient status.'
  t = treatments[treatment] ! else NOT_FOUND
  require t.status = 'planned' or t.status = 'in_progress' else BAD_STATUS 'Status follows a live session.'
  update treatments[treatment] { patientStatus: status, currentKpa: currentKpa }
  return null
