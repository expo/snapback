-- Squash Ladder Challenges.
-- Members challenge players up to three rungs above them; played within ten
-- days or the challenged player forfeits; winner uploads a score-card photo;
-- captain-only void/freeze with logged reasons; staff see bookings not results.
use identity password

-- One row per account. Rank-holding players are exactly the current members:
-- grantRole removes the ranks row when leaving the member role.
table roles:
  principal: principal
  role: enum('member', 'captain', 'staff')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
  insert <- (.principal = viewer and (.role = 'member' or (.role = 'captain' and not exists club[name = 'club']))) or exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
  update <- exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
  delete <- deny
  online only

-- Singleton bootstrap flag plus the monotonic ladder counter.
table club:
  name: text 1..40
  nextRung: int
  unique name
  immutable name
  public 'club bootstrap flag and ladder counter'
  insert <- .name = 'club'
  update <- .name = 'club'
  cap 1
  online only

-- Public ladder: rung 1 is the top. Readable by every registered user.
table ranks:
  member: principal
  rung: int
  frozen: bool default false
  unique member
  unique rung
  immutable member
  read <- exists roles[principal = viewer]
  insert <- .member = viewer or exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
  update <- .member = viewer or exists duels[challenger = viewer, challenged = .member] or exists duels[challenger = .member, challenged = viewer] or exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
  delete <- exists roles[principal = viewer, role = 'captain']
  cap 500
  online only

-- Display names: on the public ladder, visible to every registered user.
table profiles:
  principal: principal
  displayName: text 1..40
  unique principal
  immutable principal
  read <- exists roles[principal = viewer]
  insert <- .principal = viewer or exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
  update <- .principal = viewer or viewer = 'service:operator'
  delete <- deny
  cap 1000
  online only

-- Contact details and injury notes: the account itself plus the captain.
table privateProfiles:
  principal: principal
  contact: text 1..200
  injuryNotes: text <=500 ?
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'captain']
  insert <- .principal = viewer or viewer = 'service:operator'
  update <- .principal = viewer or viewer = 'service:operator'
  delete <- deny
  cap 1000
  online only

-- Challenges (booked matches): the two players, staff and the captain.
table challenges:
  challenger: principal
  challenged: principal
  issuedAt: time default now
  playBy: time
  status: enum('open', 'played', 'forfeited', 'voided') default 'open'
  court: text 1..40 ?
  playAt: time ?
  aRung: int
  bRung: int
  immutable challenger, challenged, issuedAt, playBy, aRung, bRung
  read <- .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'staff'] or exists roles[principal = viewer, role = 'captain']
  insert <- .challenger = viewer
  update <- .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'staff'] or exists roles[principal = viewer, role = 'captain']
  delete <- deny
  cap 2000
  online only

-- One open duel per pair: a unique marker so issuing never needs a scan.
table duels:
  challenger: principal
  challenged: principal
  unique challenger, challenged
  immutable challenger, challenged
  read <- .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'staff'] or exists roles[principal = viewer, role = 'captain']
  insert <- .challenger = viewer
  delete <- .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'captain']
  cap 2000
  online only

-- Results: the two players plus the captain. Staff are excluded on purpose.
-- cancellationExplanation is the v2 rename of the void reason, attached to the
-- match itself: set when the captain voids (or backfilled for older voids),
-- null for results that were never voided. It inherits this table's read rule,
-- so only the two players and the captain ever see it.
table results:
  challenge: challenges
  challenger: principal
  challenged: principal
  winner: principal
  score: text 1..100
  photo: image <=5000000 ?
  recordedAt: time default now
  winnerFromRung: int ?
  winnerToRung: int ?
  cancellationExplanation: text 1..500 ?
  unique challenge
  immutable challenge, challenger, challenged, winner, score, photo, recordedAt, winnerFromRung, winnerToRung
  read <- .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'captain']
  insert <- .winner = viewer
  update <- exists roles[principal = viewer, role = 'captain']
  delete <- deny
  cap 2000
  online only

-- Void/freeze/grant reasons: the captain only.
table auditLog:
  at: time default now
  actor: principal
  action: enum('void', 'freeze', 'unfreeze', 'grant')
  target: principal
  reason: text 1..500
  immutable at, actor, action, target, reason
  read <- exists roles[principal = viewer, role = 'captain']
  insert <- exists roles[principal = viewer, role = 'captain']
  cap 2000
  online only

query myRole():
  return roles[principal = viewer]

query allRoles(c: cursor ?):
  require exists roles[principal = viewer] else NOT_REGISTERED 'Register first.'
  return roles first 100 by .id after c

query ladder(c: cursor ?):
  require exists roles[principal = viewer] else NOT_REGISTERED 'Register first.'
  return ranks first 200 by .rung after c { *, name: profiles[.member].displayName }

-- One page per audience, no branching: a role probe in an `if` left every
-- branch partial, while each single-audience page below reads complete.
query myChallenges(c: cursor ?):
  require exists roles[principal = viewer] else NOT_REGISTERED 'Register first.'
  return challenges where .challenger = viewer last 100 by .id after c

query challengesAgainstMe(c: cursor ?):
  require exists roles[principal = viewer] else NOT_REGISTERED 'Register first.'
  return challenges where .challenged = viewer last 100 by .id after c

query allChallenges(c: cursor ?):
  require exists roles[principal = viewer, role = 'captain'] or exists roles[principal = viewer, role = 'staff'] else NOT_STAFF 'Only staff and the captain see every match.'
  return challenges last 100 by .id after c

query resultFor(challenge: challenges):
  return results[challenge = challenge]

query myPrivate():
  return privateProfiles[principal = viewer]

query directory(c: cursor ?):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can see contact details.'
  return privateProfiles first 200 by .id after c

query audit(c: cursor ?):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can see the audit log.'
  return auditLog last 200 by .id after c

mutation registerMember(displayName: text 1..40, contact: text 1..200, injuryNotes: text <=500 ?):
  require roles[principal = viewer] = null else ALREADY_REGISTERED 'This account already has a role.'
  clubRow = club[name = 'club'] ! else NO_CLUB 'The club is not initialized yet.'
  rung = clubRow.nextRung
  insert roles { principal: viewer, role: 'member' }
  insert profiles { principal: viewer, displayName }
  insert privateProfiles { principal: viewer, contact, injuryNotes }
  insert ranks { member: viewer, rung }
  update club[clubRow.id] { nextRung: rung + 1 }
  return { rung }

mutation claimCaptain(displayName: text 1..40, contact: text 1..200):
  require roles[principal = viewer] = null else ALREADY_REGISTERED 'This account already has a role.'
  require club[name = 'club'] = null else CAPTAIN_EXISTS 'A captain already exists.'
  insert roles { principal: viewer, role: 'captain' }
  insert profiles { principal: viewer, displayName }
  insert privateProfiles { principal: viewer, contact, injuryNotes: null }
  insert club { name: 'club', nextRung: 1 }
  return null

mutation grantRole(who: principal, role: enum('member', 'captain', 'staff'), displayName: text 1..40):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can grant roles.'
  require who != viewer else NO_SELF_GRANT 'You already hold your own role.'
  upsert roles[principal = who] { principal: who, role }
  if role = 'member':
    insert profiles { principal: who, displayName } if absent
    if ranks[member = who] = null:
      clubRow = club[name = 'club'] ! else NO_CLUB 'The club is not initialized yet.'
      made = insert ranks { member: who, rung: clubRow.nextRung } if absent
      if made != null:
        update club[clubRow.id] { nextRung: clubRow.nextRung + 1 }
  else:
    if exists ranks[member = who]:
      delete ranks[member = who]
  insert auditLog { actor: viewer, action: 'grant', target: who, reason: 'granted role' }
  return null

mutation issueChallenge(target: principal, court: text 1..40 ?, playAt: time ?):
  me = roles[principal = viewer] ! else NOT_REGISTERED 'Register first.'
  require me.role = 'member' else NOT_PLAYER 'Only ladder members can issue challenges.'
  require target != viewer else NO_SELF_CHALLENGE 'You cannot challenge yourself.'
  a = ranks[member = viewer] ! else NOT_RANKED 'You have no ladder position.'
  b = ranks[member = target] ! else NOT_RANKED 'That player has no ladder position.'
  require not a.frozen and not b.frozen else FROZEN 'A frozen position cannot play.'
  require not exists duels[challenger = viewer, challenged = target] else OPEN_CHALLENGE 'An open challenge already exists between you.'
  require not exists duels[challenger = target, challenged = viewer] else OPEN_CHALLENGE 'An open challenge already exists between you.'
  gap = a.rung - b.rung
  require gap >= 1 and gap <= 3 else BAD_RUNG 'You may only challenge up to three rungs above you.'
  row = insert challenges { challenger: viewer, challenged: target, issuedAt: now, playBy: now + 10d, court, playAt, aRung: a.rung, bRung: b.rung }
  insert duels { challenger: viewer, challenged: target }
  return row.id

mutation bookMatch(challenge: challenges, court: text 1..40, playAt: time):
  require exists roles[principal = viewer, role = 'staff'] or exists roles[principal = viewer, role = 'captain'] else NOT_STAFF 'Only court staff can book matches.'
  c = challenges[challenge] ! else NOT_FOUND 'No such challenge.'
  require c.status = 'open' else NOT_OPEN 'Only open challenges can be booked.'
  update challenges[c.id] { court, playAt }
  return null

mutation reportResult(challenge: challenges, winner: principal, score: text 1..100, photo: image <=5000000 ?):
  c = challenges[challenge] ! else NOT_FOUND 'No such challenge.'
  require c.status = 'open' else NOT_OPEN 'This challenge is already decided.'
  require now <= c.playBy else FORFEIT_DUE 'The ten-day window has passed.'
  require winner = c.challenger or winner = c.challenged else BAD_WINNER 'The winner must be one of the players.'
  require winner = viewer else NOT_WINNER 'Only the winner uploads the score card.'
  require photo != null else PHOTO_REQUIRED 'A photo of the signed score card is required.'
  require score != 'forfeit' else BAD_SCORE 'Played results need the real score.'
  a = ranks[member = c.challenger] ! else NOT_RANKED 'A player has no ladder position.'
  b = ranks[member = c.challenged] ! else NOT_RANKED 'A player has no ladder position.'
  ar = a.rung
  br = b.rung
  champWon = winner = c.challenger
  if champWon:
    update ranks[a.id] { rung: -ar }
    update ranks[b.id] { rung: ar }
    update ranks[a.id] { rung: br }
  insert results { challenge: c.id, challenger: c.challenger, challenged: c.challenged, winner, score, photo, recordedAt: now, winnerFromRung: ar if champWon else br, winnerToRung: br if champWon else ar, cancellationExplanation: null }
  update challenges[c.id] { status: 'played' }
  d = duels[c.challenger, c.challenged]
  if d != null:
    delete duels[d.id]
  return null

-- v2: the void `reason` is renamed to the result `cancellationExplanation`,
-- attached to the match's own result row (visible to the two players and the
-- captain via the results read rule) instead of living only in the
-- captain-only audit log. The audit entry is still written with the same text
-- so no record is lost and freeze/unfreeze/grant reasons keep their name.
mutation voidResult(challenge: challenges, cancellationExplanation: text 1..500):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can void results.'
  c = challenges[challenge] ! else NOT_FOUND 'No such challenge.'
  require c.status = 'played' or c.status = 'forfeited' else NOT_DECIDED 'Only decided challenges can be voided.'
  r = results[challenge = c.id] ! else NO_RESULT 'No result recorded.'
  a = ranks[member = c.challenger]
  b = ranks[member = c.challenged]
  if r.winnerToRung != r.winnerFromRung and a != null and b != null and a.rung = r.winnerToRung and b.rung = r.winnerFromRung:
    update ranks[a.id] { rung: -a.rung }
    update ranks[b.id] { rung: a.rung }
    update ranks[a.id] { rung: b.rung }
  update results[r.id] { cancellationExplanation }
  update challenges[c.id] { status: 'voided' }
  d = duels[c.challenger, c.challenged]
  if d != null:
    delete duels[d.id]
  insert auditLog { actor: viewer, action: 'void', target: c.challenger, reason: cancellationExplanation }
  return null

-- One-shot migration for results voided before v2, whose explanation lives
-- only in the audit log. A script pairs each unexplained voided match with its
-- void audit entry and calls this once per match; the guards keep it exact
-- (only voided matches, only once) and captain-only.
mutation setCancellationExplanation(challenge: challenges, cancellationExplanation: text 1..500):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can set cancellation explanations.'
  c = challenges[challenge] ! else NOT_FOUND 'No such challenge.'
  require c.status = 'voided' else NOT_VOIDED 'Only voided matches carry a cancellation explanation.'
  r = results[challenge = c.id] ! else NO_RESULT 'No result recorded.'
  require r.cancellationExplanation = null else ALREADY_SET 'This match already has a cancellation explanation.'
  update results[r.id] { cancellationExplanation }
  return null

mutation freezePosition(who: principal, reason: text 1..500):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can freeze positions.'
  e = ranks[member = who] ! else NOT_RANKED 'That player has no ladder position.'
  update ranks[e.id] { frozen: true }
  insert auditLog { actor: viewer, action: 'freeze', target: who, reason }
  return null

mutation unfreezePosition(who: principal, reason: text 1..500):
  require exists roles[principal = viewer, role = 'captain'] else NOT_CAPTAIN 'Only the captain can unfreeze positions.'
  e = ranks[member = who] ! else NOT_RANKED 'That player has no ladder position.'
  update ranks[e.id] { frozen: false }
  insert auditLog { actor: viewer, action: 'unfreeze', target: who, reason }
  return null

-- For accounts that received the member role without registering themselves
-- (captain grant or operator provisioning): create the private row once.
mutation completeProfile(contact: text 1..200, injuryNotes: text <=500 ?):
  me = roles[principal = viewer] ! else NOT_REGISTERED 'Register first.'
  require me.role = 'member' else NOT_PLAYER 'Only ladder members hold a private profile.'
  require privateProfiles[principal = viewer] = null else ALREADY_DONE 'Private profile already exists.'
  insert privateProfiles { principal: viewer, contact, injuryNotes }
  return null

mutation updateContact(contact: text 1..200, injuryNotes: text <=500 ?):
  p = privateProfiles[principal = viewer] ! else NOT_REGISTERED 'Register first.'
  update privateProfiles[p.id] { contact, injuryNotes }
  return null

-- Staging/operator provisioning for probe:serve seeding (never called by the UI).
mutation provision(who: principal, role: enum('member', 'captain', 'staff'), displayName: text 1..40):
  require viewer = 'service:operator' else NOT_OPERATOR 'Operator only.'
  upsert roles[principal = who] { principal: who, role }
  insert profiles { principal: who, displayName } if absent
  insert privateProfiles { principal: who, contact: 'withheld', injuryNotes: null } if absent
  if role = 'member':
    if club[name = 'club'] = null:
      insert club { name: 'club', nextRung: 1 } if absent
    clubRow = club[name = 'club'] ! else NO_CLUB 'The club is not initialized yet.'
    made = insert ranks { member: who, rung: clubRow.nextRung } if absent
    if made != null:
      update club[clubRow.id] { nextRung: clubRow.nextRung + 1 }
  return null

-- Overdue open challenges are forfeited to the challenger once a day.
job forfeitOverdue(periodStart: time, periodEnd: time):
  for c in challenges where .playBy >= periodEnd - 90d and .playBy < periodEnd by .playBy:
    if c.status = 'open' and c.playBy < periodEnd:
      a = ranks[member = c.challenger]
      b = ranks[member = c.challenged]
      if a != null and b != null:
        ar = a.rung
        br = b.rung
        update ranks[a.id] { rung: -ar }
        update ranks[b.id] { rung: ar }
        update ranks[a.id] { rung: br }
        insert results { challenge: c.id, challenger: c.challenger, challenged: c.challenged, winner: c.challenger, score: 'forfeit', photo: null, recordedAt: periodEnd, winnerFromRung: ar, winnerToRung: br, cancellationExplanation: null }
      else:
        insert results { challenge: c.id, challenger: c.challenger, challenged: c.challenged, winner: c.challenger, score: 'forfeit', photo: null, recordedAt: periodEnd, winnerFromRung: null, winnerToRung: null, cancellationExplanation: null }
      update challenges[c.id] { status: 'forfeited' }
      d = duels[c.challenger, c.challenged]
      if d != null:
        delete duels[d.id]

schedule forfeitCheck every 1d at 03:00: forfeitOverdue

query whoAmI():
  return viewer

-- (debug queries removed)

-- Independent privacy intent; guide security states unproved paths.
invariant roles.read only .principal = viewer or exists roles[principal = viewer, role = 'captain']
invariant roles.insert only .principal = viewer or exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
invariant roles.update only exists roles[principal = viewer, role = 'captain'] or viewer = 'service:operator'
invariant ranks.read only exists roles[principal = viewer]
invariant profiles.read only exists roles[principal = viewer]
invariant privateProfiles.read only .principal = viewer or exists roles[principal = viewer, role = 'captain']
invariant privateProfiles.contact write only .principal = viewer or viewer = 'service:operator'
invariant privateProfiles.injuryNotes write only .principal = viewer or viewer = 'service:operator'
invariant challenges.read only .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'staff'] or exists roles[principal = viewer, role = 'captain']
invariant results.read only .challenger = viewer or .challenged = viewer or exists roles[principal = viewer, role = 'captain']
invariant auditLog.read only exists roles[principal = viewer, role = 'captain']
