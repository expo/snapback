use identity password

table roles:
  principal: principal
  role: enum('band', 'engineer', 'manager')
  name: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table engineers:
  principal: principal
  name: text 1..80
  unique principal
  read <- exists roles[viewer]
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table calendar:
  room: enum('A', 'B')
  startsAt: time
  endsAt: time
  holdUntil: time
  state: enum('held', 'paid', 'released', 'cancelled') default 'held'
  immutable room, startsAt, endsAt, holdUntil
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'band']
  update <- exists sessions[.id, band = viewer] or exists roles[viewer, role = 'manager']
  online only

table sessions:
  slot: calendar
  band: principal
  engineer: principal
  title: text 1..120
  visitCategory: enum('first', 'returning') default 'first'
  visitCategoryAssigned: bool default false
  unique slot
  immutable slot, band, engineer, title
  read <- .band = viewer or .engineer = viewer or exists roles[viewer, role = 'manager']
  insert <- .band = viewer and exists roles[viewer, role = 'band']
  update <- exists roles[viewer, role = 'manager']
  online only

table rates:
  session: sessions
  band: principal
  cents: int 1..10000000
  unique session
  immutable session, band
  read <- .band = viewer or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager']
  online only

table deposits:
  session: sessions
  band: principal
  cents: int 10000..10000
  paidAt: time default now
  unique session
  immutable session, band, cents, paidAt
  read <- .band = viewer or exists roles[viewer, role = 'manager']
  insert <- .band = viewer or exists roles[viewer, role = 'manager']
  online only

table notes:
  session: sessions
  engineer: principal
  body: text 1..4000
  unique session
  immutable session, engineer
  read <- .engineer = viewer
  insert <- .engineer = viewer
  update <- .engineer = viewer
  online only

table files:
  session: sessions
  band: principal
  engineer: principal
  label: text 1..120
  asset: file <=25000000 ('audio/wav', 'audio/mpeg', 'audio/flac', 'application/zip', 'text/plain')
  at: time default now
  immutable session, band, engineer, label, asset, at
  read <- .band = viewer or .engineer = viewer or exists roles[viewer, role = 'manager']
  insert <- .engineer = viewer
  online only

table refunds:
  session: sessions
  band: principal
  manager: principal
  cents: int 10000..10000
  reason: text 3..1000
  at: time default now
  unique session
  immutable session, band, manager, cents, reason, at
  read <- .band = viewer or exists roles[viewer, role = 'manager']
  insert <- .manager = viewer and exists roles[viewer, role = 'manager']
  online only

mutation provision(principal: principal, role: enum('band', 'engineer', 'manager'), name: text 1..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  upsert roles[principal] { principal, role, name }
  if role = 'engineer':
    upsert engineers[principal] { principal, name }

fn placementDeadline(slot: calendar):
  row = calendar[slot] ! else NOT_FOUND
  return row.holdUntil

query me():
  return roles[viewer]
query roster():
  return engineers first 100 by .id
query timetable(c: cursor ?):
  return calendar last 100 by .startsAt after c
query mySessions(c: cursor ?):
  return sessions last 100 by .id after c
query sessionDetail(session: sessions):
  return sessions[session]
query sessionRate(session: sessions):
  return rates[session]
query sessionDeposit(session: sessions):
  return deposits[session]
query sessionNote(session: sessions):
  return notes[session]
query sessionFiles(session: sessions, c: cursor ?):
  return files where .session = session last 100 by .at after c
query sessionRefund(session: sessions):
  return refunds[session]

mutation book(room: enum('A', 'B'), startsAt: time, hours: int 1..12, engineer: principal, title: text 1..120):
  require exists roles[viewer, role = 'band'] else NOT_BAND
  require exists engineers[engineer] else NOT_ENGINEER
  require startsAt > now else IN_THE_PAST
  require startsAt <= now + 365d else TOO_FAR
  endsAt = startsAt + hours * 1h
  require not exists calendar where .room = room and .state = 'paid' and .startsAt < endsAt and .endsAt > startsAt else ROOM_BUSY
  require not exists calendar where .room = room and .state = 'held' and .startsAt < endsAt and .endsAt > startsAt and .holdUntil > now else ROOM_BUSY
  slot = insert calendar { room, startsAt, endsAt, holdUntil: now + 48h }
  category = 'returning' if exists sessions where .band = viewer and placementDeadline(.slot) < slot.holdUntil else 'first'
  return insert sessions { slot: slot.id, band: viewer, engineer, title, visitCategory: category, visitCategoryAssigned: true }

mutation setRate(session: sessions, cents: int 1..10000000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  s = sessions[session] ! else NOT_FOUND
  return upsert rates[session] { session, band: s.band, cents }

mutation payDeposit(session: sessions):
  s = sessions[session] ! else NOT_FOUND
  require s.band = viewer or exists roles[viewer, role = 'manager'] else NOT_PAYER
  slot = calendar[s.slot] ! else NOT_FOUND
  require slot.state = 'held' else NOT_HELD
  require now < slot.holdUntil else HOLD_EXPIRED
  insert deposits { session, band: s.band, cents: 10000 }
  update calendar[s.slot] { state: 'paid' }

mutation cancel(session: sessions):
  s = sessions[session] ! else NOT_FOUND
  slot = calendar[s.slot] ! else NOT_FOUND
  require s.band = viewer or exists roles[viewer, role = 'manager'] else NOT_OWNER
  require slot.state = 'held' or slot.state = 'paid' else NOT_ACTIVE
  require slot.state != 'paid' or exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require slot.state != 'held' or now < slot.holdUntil else HOLD_EXPIRED
  update calendar[s.slot] { state: 'cancelled' }

mutation refund(session: sessions, reason: text 3..1000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  s = sessions[session] ! else NOT_FOUND
  d = deposits[session] ! else NO_DEPOSIT
  require not exists refunds[session] else ALREADY_REFUNDED
  return insert refunds { session, band: s.band, manager: viewer, cents: d.cents, reason }

mutation saveNote(session: sessions, body: text 1..4000):
  require exists roles[viewer, role = 'engineer'] else NOT_ENGINEER
  s = sessions[session] ! else NOT_FOUND
  require s.engineer = viewer else NOT_ASSIGNED
  return upsert notes[session] { session, engineer: viewer, body }

mutation attachFile(session: sessions, label: text 1..120, asset: file <=25000000 ('audio/wav', 'audio/mpeg', 'audio/flac', 'application/zip', 'text/plain')):
  require exists roles[viewer, role = 'engineer'] else NOT_ENGINEER
  s = sessions[session] ! else NOT_FOUND
  require s.engineer = viewer else NOT_ASSIGNED
  return insert files { session, band: s.band, engineer: viewer, label, asset }

job releaseHolds(periodStart: time, periodEnd: time):
  for slot in calendar where .holdUntil <= periodEnd by .holdUntil:
    if slot.state = 'held':
      update calendar[slot.id] { state: 'released' }
schedule release every 1m: releaseHolds

-- Migration uses the immutable placement timestamp encoded in v1's hold deadline.
-- The marker preserves explicit manager corrections on every subsequent forward.
job migrateVisits():
  for s in sessions:
    if not s.visitCategoryAssigned:
      placed = calendar[s.slot] ! else NOT_FOUND
      category = 'returning' if exists sessions where .band = s.band and placementDeadline(.slot) < placed.holdUntil else 'first'
      update sessions[s.id] { visitCategory: category, visitCategoryAssigned: true }

mutation correctVisitCategory(session: sessions, visitCategory: enum('first', 'returning')):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  s = sessions[session] ! else NOT_FOUND
  return update sessions[s.id] { visitCategory, visitCategoryAssigned: true }
