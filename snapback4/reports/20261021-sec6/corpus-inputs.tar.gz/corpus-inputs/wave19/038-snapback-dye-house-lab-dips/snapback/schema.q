use identity password

table roles:
  principal: principal
  role: enum('buyer', 'colorist', 'accountManager', 'manager', 'production')
  brand: text 1..80
  label: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table colors:
  name: text 1..100
  standard: text 1..120
  hex: text 7..7
  brand: text 1..80
  colorist: principal
  accountManager: principal
  immutable brand, colorist, accountManager
  read <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand] or (.colorist = viewer and exists roles[viewer, role = 'colorist']) or (.accountManager = viewer and exists roles[viewer, role = 'accountManager'])
  insert <- exists roles[viewer, role = 'manager']
  online only

table prices:
  color: colors
  brand: text 1..80
  accountManager: principal
  centsPerKg: int 1..1000000
  unique color
  immutable color, brand, accountManager
  read <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand] or (.accountManager = viewer and exists roles[viewer, role = 'accountManager'])
  insert <- exists roles[viewer, role = 'manager']
  online only

table dips:
  color: colors
  brand: text 1..80
  colorist: principal
  accountManager: principal
  photo: image <=5000000
  lightness: int 0..10000
  a: int -12800..12700
  b: int -12800..12700
  notes: text <=1000
  uploadedAt: time
  dueAt: time
  status: enum('pending', 'approved', 'revisionNeeded') default 'pending'
  response: text <=500 default ''
  respondedBy: principal ?
  reminded: bool default false
  managerReleased: bool default false
  immutable color, brand, colorist, accountManager, uploadedAt, dueAt, photo, lightness, a, b, notes
  read <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand] or (.colorist = viewer and exists roles[viewer, role = 'colorist']) or (.accountManager = viewer and exists roles[viewer, role = 'accountManager'])
  insert <- .colorist = viewer and exists roles[viewer, role = 'colorist']
  update (old, next) <- (exists roles[viewer, role = 'buyer', brand = old.brand] and (old.status = 'pending' or old.respondedBy = viewer) and next.respondedBy = viewer and next.managerReleased = old.managerReleased and next.reminded = old.reminded) or (exists roles[viewer, role = 'manager'] and next.status = old.status and next.response = old.response and next.respondedBy = old.respondedBy and next.reminded = old.reminded and next.managerReleased = true)
  online only

table recipes:
  dip: dips
  color: colors
  brand: text 1..80
  colorist: principal
  colorName: text 1..100
  formula: text 1..2000
  productionReady: bool default false
  releaseReason: text <=500 default ''
  releasedBy: principal ?
  unique dip
  immutable dip, color, brand, colorist, colorName, formula
  read <- (.colorist = viewer and exists roles[viewer, role = 'colorist']) or exists roles[viewer, role = 'manager'] or (.productionReady = true and exists roles[viewer, role = 'production'])
  insert <- .colorist = viewer and exists roles[viewer, role = 'colorist']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand]
  online only

table reminders:
  dip: dips
  recipient: principal
  colorName: text 1..100
  at: time
  unique dip
  read <- .recipient = viewer or exists roles[viewer, role = 'manager']
  online only

mutation provision(principal: principal, role: enum('buyer', 'colorist', 'accountManager', 'manager', 'production'), brand: text 1..80, label: text 1..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, brand, label }

query myRole():
  return roles[viewer]

query directory():
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return roles first 100 by .id

query listColors(c: cursor ?):
  r = roles[viewer] ! else NO_ROLE
  if r.role = 'manager':
    return colors last 50 by .id after c
  if r.role = 'buyer':
    return colors where .brand = r.brand last 50 by .id after c
  if r.role = 'colorist':
    return colors where .colorist = viewer last 50 by .id after c
  return colors where .accountManager = viewer last 50 by .id after c

query listDips(color: colors, c: cursor ?):
  require exists colors[color] else NOT_FOUND
  return dips where .color = color last 50 by .id after c

query listRecipes(c: cursor ?):
  r = roles[viewer] ! else NO_ROLE
  if r.role = 'manager':
    return recipes last 50 by .id after c
  if r.role = 'production':
    return recipes where .productionReady = true last 50 by .id after c
  return recipes where .colorist = viewer last 50 by .id after c

query priceFor(color: colors):
  return prices[color = color]

query myReminders(c: cursor ?):
  require exists roles[viewer] else NO_ROLE
  return reminders where .recipient = viewer last 50 by .at after c

mutation createColor(name: text 1..100, standard: text 1..120, hex: text 7..7, brand: text 1..80, colorist: principal, accountManager: principal, centsPerKg: int 1..1000000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require exists roles[colorist, role = 'colorist'] else NOT_COLORIST
  require exists roles[accountManager, role = 'accountManager'] else NOT_ACCOUNT_MANAGER
  c = insert colors { name, standard, hex, brand, colorist, accountManager }
  insert prices { color: c.id, brand, accountManager, centsPerKg }
  return c

mutation uploadDip(color: colors, photo: image <=5000000, lightness: int 0..10000, a: int -12800..12700, b: int -12800..12700, notes: text <=1000, formula: text 1..2000):
  require exists roles[viewer, role = 'colorist'] else NOT_COLORIST
  c = colors[color] ! else NOT_FOUND
  require c.colorist = viewer else NOT_ASSIGNED
  d = insert dips { color, brand: c.brand, colorist: viewer, accountManager: c.accountManager, photo, lightness, a, b, notes, uploadedAt: now, dueAt: now + 5d }
  insert recipes { dip: d.id, color, brand: c.brand, colorist: viewer, colorName: c.name, formula }
  return d

mutation respond(dip: dips, decision: enum('approved', 'revisionNeeded', 'rejected'), response: text 1..500):
  require exists roles[viewer, role = 'buyer'] else NOT_BUYER
  d = dips[dip] ! else NOT_FOUND
  require d.status = 'pending' or d.respondedBy = viewer else NOT_DECISION_OWNER
  if decision = 'approved':
    update dips[dip] { status: 'approved', response, respondedBy: viewer }
    update recipes[dip = dip] { productionReady: true }
  else:
    update dips[dip] { status: 'revisionNeeded', response, respondedBy: viewer }
    if not d.managerReleased:
      update recipes[dip = dip] { productionReady: false }
  return dips[dip]

mutation releaseRecipe(recipe: recipes, reason: text 10..500):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  r = recipes[recipe] ! else NOT_FOUND
  require not r.productionReady else ALREADY_RELEASED
  update recipes[recipe] { productionReady: true, releaseReason: reason, releasedBy: viewer }
  update dips[r.dip] { managerReleased: true }
  return recipes[recipe]

job remindUnanswered(periodStart: time, periodEnd: time):
  for d in dips where .dueAt <= periodEnd by .dueAt:
    if d.status = 'pending' and not d.reminded:
      c = colors[d.color] ! else NOT_FOUND
      insert reminders { dip: d.id, recipient: d.accountManager, colorName: c.name, at: periodEnd }
      update dips[d.id] { reminded: true }

schedule fiveDayReminders every 1m: remindUnanswered

invariant prices.read only exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand] or (.accountManager = viewer and exists roles[viewer, role = 'accountManager'])
invariant recipes.read only (.colorist = viewer and exists roles[viewer, role = 'colorist']) or exists roles[viewer, role = 'manager'] or (.productionReady = true and exists roles[viewer, role = 'production'])
invariant recipes.insert only .colorist = viewer and exists roles[viewer, role = 'colorist']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'

query approvalQueue(c: cursor ?):
  r = roles[viewer] ! else NO_ROLE
  require r.role != 'production' else NOT_REVIEWER
  if r.role = 'manager':
    return dips where .status = 'pending' last 50 by .id after c
  if r.role = 'buyer':
    return dips where .brand = r.brand and .status = 'pending' last 50 by .id after c
  if r.role = 'colorist':
    return dips where .colorist = viewer and .status = 'pending' last 50 by .id after c
  return dips where .accountManager = viewer and .status = 'pending' last 50 by .id after c

invariant colors.read only exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand] or (.colorist = viewer and exists roles[viewer, role = 'colorist']) or (.accountManager = viewer and exists roles[viewer, role = 'accountManager'])
invariant dips.read only exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'buyer', brand = .brand] or (.colorist = viewer and exists roles[viewer, role = 'colorist']) or (.accountManager = viewer and exists roles[viewer, role = 'accountManager'])
invariant reminders.read only .recipient = viewer or exists roles[viewer, role = 'manager']
