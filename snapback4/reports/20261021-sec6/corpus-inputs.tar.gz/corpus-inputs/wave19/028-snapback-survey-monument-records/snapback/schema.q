use identity password

table people:
  principal: principal
  name: text 1..80
  role: enum('crew', 'office', 'surveyor', 'client')
  unique principal
  immutable principal, name, role
  read <- .principal = viewer or exists people[principal = viewer, role = 'office'] or viewer = 'service:provision'
  insert <- viewer = 'service:provision'
  online only

table jobs:
  title: text 1..120
  site: text 1..200
  client: principal
  crew: principal
  closedAt: time ?
  checkedAt: time ?
  flagged: bool default false
  at: time default now
  immutable title, site, client, crew, at
  read <- .crew = viewer or exists people[principal = viewer, role = 'office'] or exists people[principal = viewer, role = 'surveyor']
  insert <- exists people[principal = viewer, role = 'office']
  update <- .crew = viewer or exists people[principal = viewer, role = 'office'] or exists people[principal = viewer, role = 'surveyor']
  online only

table monuments:
  job: jobs
  label: text 1..60
  kind: enum('found', 'set')
  latE7: int -900000000..900000000
  lonE7: int -1800000000..1800000000
  positionLatE7: int -900000000..900000000 ?
  positionLonE7: int -1800000000..1800000000 ?
  description: text 1..2000
  photo: image <=5000000 ?
  actor: principal
  at: time default now
  disturbed: bool default false
  immutable job, label, kind, description, photo, actor, at
  read through .job
  insert <- .actor = viewer and exists jobs[.job] and (exists people[principal = viewer, role = 'crew'] or exists people[principal = viewer, role = 'surveyor'])
  update <- exists people[principal = viewer, role = 'surveyor']
  online only

table notes:
  job: jobs
  body: text 1..2000
  actor: principal
  at: time default now
  immutable job, body, actor, at
  read through .job
  insert <- .actor = viewer and exists jobs[.job]
  online only

table history:
  monument: monuments
  reason: text 3..1000
  actor: principal
  at: time default now
  immutable monument, reason, actor, at
  read through .monument
  insert <- .actor = viewer and exists people[principal = viewer, role = 'surveyor']
  online only

table plats:
  job: jobs
  client: principal
  title: text 1..120
  document: file <=10000000 ('application/pdf')
  revision: int 1..
  reviewedAt: time ?
  reviewer: principal ?
  signedAt: time ?
  signer: principal ?
  unique job
  immutable job, client
  read <- (.client = viewer and .signedAt != null) or exists people[principal = viewer, role = 'office'] or exists people[principal = viewer, role = 'surveyor'] or exists jobs[.job, crew = viewer]
  insert <- exists people[principal = viewer, role = 'office'] or exists people[principal = viewer, role = 'surveyor']
  update <- exists people[principal = viewer, role = 'office'] or exists people[principal = viewer, role = 'surveyor']
  online only

table invoices:
  job: jobs
  client: principal
  description: text 1..200
  cents: int 1..100000000
  issuedAt: time default now
  immutable job, client, description, cents, issuedAt
  read <- .client = viewer or exists people[principal = viewer, role = 'office']
  insert <- exists people[principal = viewer, role = 'office']
  online only

query me():
  return people[principal = viewer]
query directory():
  require exists people[principal = viewer, role = 'office'] else FORBIDDEN
  return people first 100 by .id
query jobList():
  return jobs last 100 by .id { *, overdue: .closedAt != null and now > .closedAt + 10d and (.checkedAt = null or .checkedAt > .closedAt + 10d) }
query jobRecord(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  return { job: j, overdue: j.closedAt != null and now > j.closedAt + 10d and (j.checkedAt = null or j.checkedAt > j.closedAt + 10d), monuments: monuments where .job = job first 500 by .id, notes: notes where .job = job last 100 by .id }
query monumentHistory(monument: monuments):
  m = monuments[monument] ! else NOT_FOUND
  return history where .monument = monument first 100 by .id
query platForJob(job: jobs):
  return plats[job = job]
query myPlats():
  return plats last 100 by .id
query billing():
  return invoices last 100 by .id

mutation provision(principal: principal, name: text 1..80, role: enum('crew', 'office', 'surveyor', 'client')):
  require viewer = 'service:provision' else FORBIDDEN
  return insert people { principal, name, role }
mutation createJob(title: text 1..120, site: text 1..200, client: principal, crew: principal):
  require exists people[principal = viewer, role = 'office'] else FORBIDDEN
  require exists people[principal = client, role = 'client'] else BAD_CLIENT
  require exists people[principal = crew, role = 'crew'] else BAD_CREW
  return insert jobs { title, site, client, crew }
mutation addMonument(job: jobs, label: text 1..60, kind: enum('found', 'set'), latE7: int -900000000..900000000, lonE7: int -1800000000..1800000000, description: text 1..2000, photo: image <=5000000 ?):
  j = jobs[job] ! else NOT_FOUND
  require j.closedAt = null else FIELDWORK_CLOSED
  return insert monuments { job, label, kind, latE7, lonE7, positionLatE7: latE7, positionLonE7: lonE7, description, photo, actor: viewer }
mutation addNote(job: jobs, body: text 1..2000):
  j = jobs[job] ! else NOT_FOUND
  require j.closedAt = null else FIELDWORK_CLOSED
  return insert notes { job, body, actor: viewer }
mutation closeFieldwork(job: jobs):
  j = jobs[job] ! else NOT_FOUND
  require j.crew = viewer or exists people[principal = viewer, role = 'office'] else FORBIDDEN
  require j.closedAt = null else FIELDWORK_CLOSED
  return update jobs[job] { closedAt: now }
mutation saveDraft(job: jobs, title: text 1..120, document: file <=10000000 ('application/pdf')):
  j = jobs[job] ! else NOT_FOUND
  require j.closedAt != null else FIELDWORK_OPEN
  require exists people[principal = viewer, role = 'office'] or exists people[principal = viewer, role = 'surveyor'] else FORBIDDEN
  p = plats[job = job]
  if p != null:
    require p.signedAt = null else ALREADY_SIGNED
    update jobs[job] { checkedAt: null }
    return update plats[p.id] { title, document, revision: p.revision + 1, reviewedAt: null, reviewer: null }
  return insert plats { job, client: j.client, title, document, revision: 1 }
mutation reviewPlat(job: jobs):
  require exists people[principal = viewer, role = 'surveyor'] else FORBIDDEN
  j = jobs[job] ! else NOT_FOUND
  p = plats[job = job] ! else NOT_FOUND
  require j.closedAt != null else FIELDWORK_OPEN
  require p.signedAt = null else ALREADY_SIGNED
  update jobs[job] { checkedAt: now, flagged: j.flagged or now > j.closedAt + 10d }
  return update plats[p.id] { reviewedAt: now, reviewer: viewer }
mutation signPlat(job: jobs):
  require exists people[principal = viewer, role = 'surveyor'] else FORBIDDEN
  p = plats[job = job] ! else NOT_FOUND
  require p.reviewedAt != null else REVIEW_REQUIRED
  require p.signedAt = null else ALREADY_SIGNED
  return update plats[p.id] { signedAt: now, signer: viewer }
mutation disturbMonument(monument: monuments, reason: text 3..1000):
  require exists people[principal = viewer, role = 'surveyor'] else FORBIDDEN
  m = monuments[monument] ! else NOT_FOUND
  require not m.disturbed else ALREADY_DISTURBED
  insert history { monument, reason, actor: viewer }
  return update monuments[monument] { disturbed: true }
mutation issueInvoice(job: jobs, description: text 1..200, cents: int 1..100000000):
  require exists people[principal = viewer, role = 'office'] else FORBIDDEN
  j = jobs[job] ! else NOT_FOUND
  return insert invoices { job, client: j.client, description, cents }

job flagOverdue():
  for j in jobs:
    if j.closedAt != null and now > j.closedAt + 10d and (j.checkedAt = null or j.checkedAt > j.closedAt + 10d) and not j.flagged:
      update jobs[j.id] { flagged: true }
schedule deadlineCheck every 1m: flagOverdue

-- Public v2 vocabulary; legacy addMonument remains an adapter for v1 clients.
mutation recordMonument(job: jobs, label: text 1..60, kind: enum('found', 'set'), positionLatE7: int -900000000..900000000, positionLonE7: int -1800000000..1800000000, description: text 1..2000, photo: image <=5000000 ?):
  j = jobs[job] ! else NOT_FOUND
  require j.closedAt = null else FIELDWORK_CLOSED
  return insert monuments { job, label, kind, latE7: positionLatE7, lonE7: positionLonE7, positionLatE7, positionLonE7, description, photo, actor: viewer }

mutation correctMonumentPosition(monument: monuments, positionLatE7: int -900000000..900000000, positionLonE7: int -1800000000..1800000000):
  require exists people[principal = viewer, role = 'surveyor'] else FORBIDDEN
  m = monuments[monument] ! else NOT_FOUND
  return update monuments[monument] { latE7: positionLatE7, lonE7: positionLonE7, positionLatE7, positionLonE7 }

-- Expand/backfill, kept nullable so v1 can insert rows during a rollback.
-- Exact integer copies; no defaults, projection math, truncation or reordering.
job migratePositions():
  for m in monuments:
    if m.positionLatE7 = null or m.positionLonE7 = null:
      update monuments[m.id] { positionLatE7: m.latE7, positionLonE7: m.lonE7 }
