-- Drawbridge Opening Log.
-- Roles: operator (boat), tender (bridge tender), roadcrew, supervisor.
-- Real password auth only; no dev personas.
use identity password

table roles:
  principal: principal
  role: enum('operator', 'tender', 'roadcrew', 'supervisor')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'supervisor']
  insert <- exists roles[viewer, role = 'supervisor'] or exists supervisorSeat[1, claimer = viewer]
  update <- exists roles[viewer, role = 'supervisor'] or exists supervisorSeat[1, claimer = viewer]
  delete <- exists roles[viewer, role = 'supervisor']
  online only

-- The supervisor seat: whoever takes seat 1 first (one insert wins, the
-- rest get null from `if absent`) may claim the supervisor role, with no
-- dev door and no counting over hidden rows.
table supervisorSeat:
  seat: int
  claimer: principal
  unique seat
  immutable seat, claimer
  public 'the supervisor seat shows only that it is taken'
  insert <- .claimer = viewer and .seat = 1
  online only

-- An operator's advance request for an opening.
table requests:
  operator: principal
  vessel: text 1..60
  requestedAt: time
  arrivedAt: time ?
  status: enum('pending', 'arrived', 'opened', 'refused', 'lapsed') default 'pending'
  refusalReason: text 1..200 ?
  openedAt: time ?
  immutable operator, vessel, requestedAt
  cap 200 by operator
  read <- .operator = viewer or exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor']
  insert <- .operator = viewer
  update <- .operator = viewer or exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor']
  online only

-- Anonymized queue slots: order + status only. No vessel, no operator, no
-- time, so operators can compute their place in the queue without reading
-- anyone else's request, and road crews learn nothing about vessels.
table queueEntries:
  request: requests
  status: enum('pending', 'arrived', 'opened', 'refused', 'lapsed') default 'pending'
  unique request
  immutable request
  cap 10000
  public 'queue order and status are visible to every signed-in user; vessel details stay private'
  insert <- created requests[.request]
  update <- exists requests[.request, operator = viewer] or exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor']
  online only

-- The tender's log: every opening with vessel name, call name (v2) and
-- channel snapshot. Tender and supervisor only; road crews must not see
-- vessel details. callName is optional so v1 rows adopt additively; every
-- writer fills it (v1-era rows are backfilled from vessel), and only the
-- tender may change it afterwards via renameCallName.
table openings:
  tender: principal
  vessel: text 1..60
  callName: text 1..60 ?
  snapshot: image <=5000000
  at: time default now
  request: requests ?
  immutable tender, vessel, snapshot, at, request
  cap 2000
  read <- exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor']
  insert <- exists roles[viewer, role = 'tender']
  update <- exists roles[viewer, role = 'tender']
  online only

-- Span up/down times. Public: this is what road crews watch.
table spanEvents:
  at: time default now
  up: bool
  note: text 1..120 ?
  cap 5000
  public 'span up/down times are public; vessel details stay in the tender log'
  insert <- exists roles[viewer, role = 'tender']
  online only

query myRole():
  return roles[principal = viewer]

query allRoles(c: cursor ?):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  return roles last 50 by .id after c

query myRequests(c: cursor ?):
  return requests where .operator = viewer last 50 by .requestedAt after c

-- Place in the queue: 1 + the number of still-waiting entries ahead.
-- Client-minted ids are time-ordered, so id order is queue order.
query myPlace(req: requests):
  r = requests[req] ! else NOT_FOUND
  require r.operator = viewer else NOT_FOUND
  e = queueEntries[request = req] ! else NOT_FOUND
  return count(queueEntries where (.status = 'pending' or .status = 'arrived') and .id < e.id) + 1

query queue(c: cursor ?):
  require exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor'] else NOT_STAFF
  return requests where (.status = 'pending' or .status = 'arrived') first 50 by .requestedAt after c

query tenderLog(c: cursor ?):
  require exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor'] else NOT_STAFF
  return openings last 50 by .at after c

query spanStatus():
  return spanEvents last 1 by .at

query spanHistory(c: cursor ?):
  return spanEvents last 50 by .at after c

-- Bootstrap: whoever takes the supervisor seat first becomes supervisor.
-- Later claims find the seat taken and get HAS_SUPERVISOR. The seat holder
-- can always reclaim (for example after a demotion), so the county cannot
-- lock itself out of supervision.
mutation claimFirstSupervisor():
  s = insert supervisorSeat { seat: 1, claimer: viewer } if absent
  if s = null:
    holder = supervisorSeat[1] ! else HAS_SUPERVISOR
    require holder.claimer = viewer else HAS_SUPERVISOR 'A supervisor already exists.'
  return upsert roles[principal = viewer] { principal: viewer, role: 'supervisor' }

mutation grantRole(who: principal, role: enum('operator', 'tender', 'roadcrew', 'supervisor')):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR 'Only the bridge supervisor manages roles.'
  return upsert roles[principal = who] { principal: who, role }

-- Commercial vessels request an opening in advance (up to 7 days ahead).
mutation requestOpening(vessel: text 1..60, requestedAt: time):
  require exists roles[viewer, role = 'operator'] else NOT_OPERATOR 'Only boat operators file opening requests.'
  require requestedAt >= now - 1m else IN_THE_PAST 'The requested time must be now or in the future.'
  require requestedAt <= now + 7d else TOO_FAR 'Openings can be requested up to 7 days ahead.'
  r = insert requests { operator: viewer, vessel, requestedAt }
  insert queueEntries { request: r.id, status: 'pending' }
  return r

-- The vessel has arrived. Owner or tender records it, inside the window.
mutation markArrived(req: requests):
  r = requests[req] ! else NOT_FOUND
  require r.operator = viewer or exists roles[viewer, role = 'tender'] else NOT_ALLOWED 'Only the vessel operator or the tender records arrival.'
  require now <= r.requestedAt + 30m else LAPSED 'The vessel did not arrive within 30 minutes after its requested time.'
  require r.status = 'pending' else ALREADY_DECIDED 'This request is already decided.'
  update requests[req] { arrivedAt: now, status: 'arrived' }
  update queueEntries[request = req] { status: 'arrived' }
  return null

-- The tender logs each opening with vessel name, call name and channel
-- snapshot. Linked to an arrived request, or a walk-up with no request.
-- callName is optional for old (v1) clients, which never send it: the
-- server then files the vessel name as the call name, so every stored
-- opening still carries one.
mutation logOpening(vessel: text 1..60, snapshot: image <=5000000, req: requests ?, callName: text 1..60 ?):
  require exists roles[viewer, role = 'tender'] else NOT_TENDER 'Only the bridge tender logs openings.'
  name = callName ?? vessel
  insert spanEvents { up: true }
  if req != null:
    r = requests[req] ! else NOT_FOUND
    require now <= r.requestedAt + 30m else LAPSED 'The request lapsed before the opening.'
    require r.status = 'arrived' else NOT_ARRIVED 'The vessel must arrive before its opening is logged.'
    require r.vessel = vessel else VESSEL_MISMATCH 'The vessel name does not match the request.'
    update requests[req] { status: 'opened', openedAt: now }
    update queueEntries[request = req] { status: 'opened' }
    return insert openings { tender: viewer, vessel, callName: name, snapshot, request: req }
  return insert openings { tender: viewer, vessel, callName: name, snapshot }

-- Only the bridge tender may change an opening's call name.
mutation renameCallName(opening: openings, callName: text 1..60):
  require exists roles[viewer, role = 'tender'] else NOT_TENDER 'Only the bridge tender changes call names.'
  o = openings[opening] ! else NOT_FOUND
  update openings[opening] { callName }
  return null

-- One-shot migration: copy the vessel name exactly as the call name for
-- every opening that predates call names. Tender-run after each v2
-- activation; a no-op once every row carries one.
mutation backfillCallNames():
  require exists roles[viewer, role = 'tender'] else NOT_TENDER 'Only the bridge tender migrates call names.'
  patched = 0
  for o in openings:
    if o.callName = null:
      update openings[o.id] { callName: o.vessel }
      patched = patched + 1
  return patched

-- The tender lowers the span after the vessel passes.
mutation lowerSpan(note: text 1..120 ?):
  require exists roles[viewer, role = 'tender'] else NOT_TENDER 'Only the bridge tender moves the span.'
  return insert spanEvents { up: false, note }

-- Only the supervisor can refuse an opening (high wind), with reason logged.
mutation refuseOpening(req: requests, reason: text 1..200):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR 'Only the bridge supervisor can refuse an opening.'
  r = requests[req] ! else NOT_FOUND
  require now <= r.requestedAt + 30m else LAPSED 'The request has already lapsed.'
  require r.status = 'pending' or r.status = 'arrived' else ALREADY_DECIDED 'This request is already decided.'
  update requests[req] { status: 'refused', refusalReason: reason }
  update queueEntries[request = req] { status: 'refused' }
  return null

-- A request lapses when the vessel has not arrived within 30 minutes
-- after its requested time. Mutations enforce the same deadline against
-- `now`, so nothing can slip between deadline and sweep.
job sweepLapsed(periodStart: time, periodEnd: time):
  for r in requests where .requestedAt >= periodEnd - 30d and .requestedAt < periodEnd - 30m by .requestedAt:
    if r.status = 'pending' and r.arrivedAt = null:
      update requests[r.id] { status: 'lapsed' }
  for e in queueEntries where (.status = 'pending' or .status = 'arrived') by .id:
    r = requests[e.request]
    if r != null and (r.status = 'opened' or r.status = 'refused' or r.status = 'lapsed'):
      update queueEntries[e.id] { status: r.status }

schedule lapseSweep every 1m: sweepLapsed

-- Independent privacy intent; guide security states unproved paths.
invariant requests.read only .operator = viewer or exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor']
invariant requests.insert only .operator = viewer
invariant openings.read only exists roles[viewer, role = 'tender'] or exists roles[viewer, role = 'supervisor']
invariant openings.insert only exists roles[viewer, role = 'tender']
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'supervisor']
