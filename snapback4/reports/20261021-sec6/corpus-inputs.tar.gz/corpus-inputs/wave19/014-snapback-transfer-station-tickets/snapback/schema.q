use identity password

-- Provisioned by a private operator seat, never by public signup.
table accounts:
  principal: principal
  name: text 1..80
  role: enum('resident', 'hauler', 'attendant', 'foreman', 'manager')
  company: text 1..80
  unique principal
  immutable principal, role, company
  read <- .principal = viewer or exists accounts[viewer, role = 'attendant'] or exists accounts[viewer, role = 'manager'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table permits:
  resident: principal
  issuedAt: time
  allowance: int 1..10000
  unique resident
  immutable resident, issuedAt, allowance
  read <- .resident = viewer or exists accounts[viewer, role = 'manager'] or exists accounts[viewer, role = 'attendant']
  insert <- exists accounts[viewer, role = 'manager']
  online only

table tickets:
  label: text 1..100
  resident: principal
  company: text 1..80
  haulerName: text 1..80
  -- material is the v1 compatibility mirror; declaredMaterial is the v2 name.
  material: enum('household', 'wood', 'yard', 'metal', 'construction')
  declaredMaterial: enum('household', 'wood', 'yard', 'metal', 'construction') ?
  photo: image <=5000000
  banned: bool
  bannedReason: text <=300
  originalGross: int 1..100000
  originalTare: int 0..100000 ?
  gross: int 1..100000
  tare: int 0..100000 ?
  net: int 0..100000 default 0
  state: enum('arriving', 'held', 'rejected', 'complete')
  decision: enum('approved', 'rejected') ?
  decisionReason: text <=500 default ''
  decidedBy: principal ?
  decidedAt: time ?
  createdBy: principal
  arrivedAt: time default now
  completedAt: time ?
  immutable label, resident, company, haulerName, photo, banned, bannedReason, originalGross, createdBy, arrivedAt
  read <- (.resident = viewer and exists accounts[viewer, role = 'resident']) or exists accounts[viewer, company = .company, role = 'hauler'] or exists accounts[viewer, role = 'attendant'] or exists accounts[viewer, role = 'foreman'] or exists accounts[viewer, role = 'manager']
  insert <- exists accounts[viewer, role = 'attendant'] and .createdBy = viewer
  update (old, next) <- exists accounts[viewer, role = 'attendant'] or (exists accounts[viewer, role = 'manager'] and old.material = next.material and old.declaredMaterial = next.declaredMaterial)
  online only

table adjustments:
  ticket: tickets
  manager: principal
  oldGross: int
  oldTare: int
  newGross: int
  newTare: int
  reason: text 3..500
  at: time default now
  immutable ticket, manager, oldGross, oldTare, newGross, newTare, reason, at
  read through .ticket
  insert <- exists accounts[viewer, role = 'manager'] and .manager = viewer
  online only

invariant permits.read only .resident = viewer or exists accounts[viewer, role = 'manager'] or exists accounts[viewer, role = 'attendant']

fn anniversary(issued: time, years: int):
  m = month(issued) + years * 12
  offset = issued - monthStart(month(issued))
  days = (monthStart(m + 1) - monthStart(m)) / 1d
  return monthStart(m) + min(offset / 1d, days - 1) * 1d + offset % 1d

fn cycleStart(issued: time):
  years = year(now) - year(issued)
  a = anniversary(issued, years)
  return a if a <= now else anniversary(issued, years - 1)

query me():
  return accounts[viewer]

query directory(c: cursor ?):
  require exists accounts[viewer, role = 'attendant'] or exists accounts[viewer, role = 'manager'] else STAFF_ONLY
  return accounts first 100 by .id after c

query board(c: cursor ?):
  a = accounts[viewer] ! else NOT_ENROLLED
  if a.role = 'resident':
    return tickets where .resident = viewer last 50 by .arrivedAt after c
  if a.role = 'hauler':
    return tickets where .company = a.company last 50 by .arrivedAt after c
  return tickets last 50 by .arrivedAt after c

query ticket(id: tickets):
  require exists accounts[viewer] else NOT_ENROLLED
  return tickets[id]

query history(id: tickets, c: cursor ?):
  require exists tickets[id] else NOT_FOUND
  return adjustments where .ticket = id last 50 by .at after c

query allowance():
  require exists accounts[viewer, role = 'resident'] else RESIDENT_ONLY
  p = permits[resident = viewer]
  if p = null:
    return null
  start = cycleStart(p.issuedAt)
  finish = anniversary(p.issuedAt, year(start) - year(p.issuedAt) + 1)
  used = sum(tickets where .resident = viewer and .state = 'complete' and .completedAt >= start and .completedAt < finish, .net)
  return { permit: p, start, finish, used, remaining: max(0, p.allowance - used) }

mutation provision(who: principal, name: text 1..80, role: enum('resident', 'hauler', 'attendant', 'foreman', 'manager'), company: text 1..80):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert accounts { principal: who, name, role, company }

mutation issuePermit(resident: principal, allowance: int 1..10000):
  require exists accounts[viewer, role = 'manager'] else MANAGER_ONLY
  require exists accounts[resident, role = 'resident'] else NOT_RESIDENT
  p = permits[resident = resident]
  if p != null:
    return p
  return insert permits { resident, issuedAt: now, allowance }

mutation arrive(label: text 1..100, resident: principal, hauler: principal, material: enum('household', 'wood', 'yard', 'metal', 'construction') ?, declaredMaterial: enum('household', 'wood', 'yard', 'metal', 'construction') ?, photo: image <=5000000, gross: int 1..100000, banned: bool, bannedReason: text <=300):
  require exists accounts[viewer, role = 'attendant'] else ATTENDANT_ONLY
  require exists accounts[resident, role = 'resident'] else NOT_RESIDENT
  h = accounts[hauler] ! else NOT_HAULER
  require h.role = 'hauler' else NOT_HAULER
  require not banned or len(bannedReason) >= 3 else BANNED_REASON_REQUIRED
  recorded = declaredMaterial ?? material
  require recorded != null else DECLARED_MATERIAL_REQUIRED
  require declaredMaterial = null or material = null or declaredMaterial = material else MATERIAL_CONFLICT
  return insert tickets { label, resident, company: h.company, haulerName: h.name, material: recorded, declaredMaterial: recorded, photo, banned, bannedReason, originalGross: gross, gross, state: 'held' if banned else 'arriving', createdBy: viewer }

mutation weighOut(id: tickets, tare: int 0..100000):
  require exists accounts[viewer, role = 'attendant'] else ATTENDANT_ONLY
  t = tickets[id] ! else NOT_FOUND
  require t.state = 'arriving' else LOAD_NOT_RELEASED
  require tare < t.gross else BAD_WEIGHT
  update tickets[id] { originalTare: tare, tare, net: t.gross - tare, state: 'complete', completedAt: now }

mutation decide(id: tickets, decision: enum('approved', 'rejected'), reason: text 3..500):
  require exists accounts[viewer, role = 'manager'] else MANAGER_ONLY
  t = tickets[id] ! else NOT_FOUND
  require t.state = 'held' else NOT_HELD
  update tickets[id] { decision, decisionReason: reason, decidedBy: viewer, decidedAt: now, state: 'arriving' if decision = 'approved' else 'rejected' }

mutation adjust(id: tickets, gross: int 1..100000, tare: int 0..100000, reason: text 3..500):
  require exists accounts[viewer, role = 'manager'] else MANAGER_ONLY
  t = tickets[id] ! else NOT_FOUND
  require t.state = 'complete' else NOT_COMPLETE
  require tare < gross else BAD_WEIGHT
  oldTare = t.tare ! else NOT_COMPLETE
  insert adjustments { ticket: id, manager: viewer, oldGross: t.gross, oldTare, newGross: gross, newTare: tare, reason }
  update tickets[id] { gross, tare, net: gross - tare }

-- Copies exact wording only, without consulting load state or banned-material rules.
-- Idempotent so v1-created rows can be backfilled after every forward activation.
mutation migrateDeclaredMaterial(id: tickets):
  require exists accounts[viewer, role = 'attendant'] else ATTENDANT_ONLY
  t = tickets[id] ! else NOT_FOUND
  if t.declaredMaterial = null:
    update tickets[id] { declaredMaterial: t.material }

mutation changeDeclaredMaterial(id: tickets, declaredMaterial: enum('household', 'wood', 'yard', 'metal', 'construction')):
  require exists accounts[viewer, role = 'attendant'] else ATTENDANT_ONLY
  t = tickets[id] ! else NOT_FOUND
  update tickets[id] { declaredMaterial, material: declaredMaterial }
