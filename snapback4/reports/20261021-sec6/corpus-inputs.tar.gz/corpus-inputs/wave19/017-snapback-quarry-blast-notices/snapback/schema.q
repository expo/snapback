-- Quarry Blast Notices.
-- A stone quarry schedules blasts; neighbors are notified at schedule time;
-- a blast cannot fire less than 24h after its notice was sent. The blaster
-- uploads the blast plan and afterward records the seismograph reading from
-- the nearest home. A reading above the permitted limit opens a report that
-- only the regulator can close, with findings recorded.
use identity password

-- Roster: one row per user. Only the local operator (service seat) writes it;
-- the manager grants day-to-day changes through the provision mutation.
table roles:
  principal: principal
  role: enum('neighbor', 'blaster', 'crew', 'manager', 'regulator')
  unique principal
  immutable principal
  read <- .principal = viewer
  insert <- viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  delete <- viewer = 'service:operator'
  online only

-- A registered neighbor property. The manager registers properties; the
-- blaster reads them to record which home a reading came from.
table properties:
  owner: principal
  label: text 1..120
  unique owner
  immutable owner
  cap 500
  read <- .owner = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'blaster']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager']
  delete <- exists roles[viewer, role = 'manager']
  online only

-- A scheduled blast. Every roster member may read rows, but each query
-- projects only what its role may see: neighbors get dates via blastDates.
table blasts:
  label: text 1..80
  site: text 1..120
  scheduledAt: time
  noticeSentAt: time ?
  status: enum('scheduled', 'fired', 'cancelled') default 'scheduled'
  firedAt: time ?
  assessment: enum('awaiting reading', 'within limit', 'above limit') default 'awaiting reading'
  createdBy: principal
  immutable createdBy
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew']
  online only

-- The blast plan, uploaded by the blaster. Neighbors and regulators cannot
-- read these rows at all.
table blastPlans:
  blast: blasts
  planText: text 1..4000
  uploadedBy: principal
  uploadedAt: time default now
  unique blast
  immutable blast
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager']
  online only

-- Site-clear checklist for one blast. The crew owns it; managers may help.
table checklistItems:
  blast: blasts
  item: text 1..200
  done: bool default false
  updatedBy: principal ?
  unique blast, item
  cap 50 by blast
  immutable blast
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  delete <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
  online only

view openChecks: count checklistItems where not .done by .blast
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']

view checkTotals: count checklistItems by .blast
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']

-- Seismograph reading from the nearest home, recorded after firing.
-- value and limit are tenths of mm/s peak particle velocity.
table readings:
  blast: blasts
  property: properties
  owner: principal
  value: int 0..1000
  limit: int default 50
  takenAt: time default now
  recordedBy: principal
  immutable blast, property, owner
  read <- .owner = viewer or exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator']
  insert <- exists roles[viewer, role = 'blaster']
  update <- exists roles[viewer, role = 'blaster']
  online only

-- Reading assessment support (v2). Above-limit counts and per-blast reading
-- totals drive the blast assessment; both stay with quarry staff who already
-- read every reading. The assessment label itself is exposed only through
-- the manager/regulator query below, never through staff-wide queries.
view aboveReadings: count readings where .value > .limit by .blast
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator']

view readingTotals: count readings by .blast
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator']

-- Opened automatically when a reading exceeds its limit. Only the
-- regulator may change (close) a report.
table reports:
  blast: blasts
  reading: readings
  property: properties
  owner: principal
  value: int 0..1000
  limit: int
  status: enum('open', 'closed') default 'open'
  findings: text 1..2000 ?
  closedBy: principal ?
  closedAt: time ?
  unique reading
  immutable blast, reading, property, owner, value, limit
  read <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator']
  insert <- exists roles[viewer, role = 'blaster']
  update <- exists roles[viewer, role = 'regulator']
  online only

-- One notice per neighbor property per blast, written when the blast is
-- scheduled. Neighbors read only their own.
table notices:
  blast: blasts
  recipient: principal
  sentAt: time default now
  message: text 1..300
  unique blast, recipient else ALREADY_NOTIFIED
  immutable blast, recipient
  read <- .recipient = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'blaster']
  insert <- exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager']
  online only

-- Neighbor complaints. Authors read their own; only the manager reads all.
table complaints:
  author: principal
  blast: blasts ?
  body: text 1..1000
  createdAt: time default now
  immutable author
  read <- .author = viewer or exists roles[viewer, role = 'manager']
  insert <- .author = viewer and exists roles[viewer, role = 'neighbor']
  online only

query whoAmI():
  return viewer

query myRole():
  return roles[viewer]

-- Neighbors see only blast dates (and status) here.
query blastDates(c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  return blasts first 100 by .scheduledAt after c { id, scheduledAt, status }

-- Full scheduling detail for quarry staff and the regulator.
query blastDetail(blast: blasts):
  require exists roles[viewer] else NOT_SIGNED_IN
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  return { id: b.id, label: b.label, site: b.site, scheduledAt: b.scheduledAt, noticeSentAt: b.noticeSentAt, status: b.status, firedAt: b.firedAt, plan: blastPlans[blast] }

query blastPlan(blast: blasts):
  require exists roles[viewer] else NOT_SIGNED_IN
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  return blastPlans[blast]

query myNotices(c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  return notices where .recipient = viewer last 50 by .sentAt after c { id, blast, sentAt, message }

-- Live firing countdown and notice age for the crew.
query countdown(blast: blasts):
  require exists roles[viewer] else NOT_SIGNED_IN
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  return { blast: b.id, scheduledAt: b.scheduledAt, noticeSentAt: b.noticeSentAt, status: b.status, remainingMs: b.scheduledAt - now }

query checklist(blast: blasts, c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  require exists blasts[blast] else NOT_FOUND
  return checklistItems where .blast = blast first 50 by .id after c

query myProperty():
  require exists roles[viewer] else NOT_SIGNED_IN
  return properties[viewer]

query propertiesList(c: cursor ?):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return properties first 50 by .id after c

-- A neighbor reads the readings near their own property.
query myReadings(c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  return readings where .owner = viewer last 50 by .takenAt after c

query readingsFor(blast: blasts, c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator'] else NOT_ALLOWED
  require exists blasts[blast] else NOT_FOUND
  return readings where .blast = blast last 50 by .takenAt after c

-- A blast's reading assessment. Only the quarry manager and the regulator
-- may see it: neighbors and crew members (and the blaster) cannot call this,
-- and no other query projects the assessment column.
query blastAssessment(blast: blasts):
  require exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  return { blast: b.id, assessment: b.assessment }

query myComplaints(c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  return complaints where .author = viewer last 50 by .createdAt after c

-- Only the quarry manager sees complaints in full.
query allComplaints(c: cursor ?):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return complaints last 50 by .createdAt after c

query listReports(c: cursor ?):
  require exists roles[viewer] else NOT_SIGNED_IN
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator'] else NOT_ALLOWED
  return reports last 50 by .id after c

-- The manager (or operator seat) grants and changes roles.
mutation provision(who: principal, role: enum('neighbor', 'blaster', 'crew', 'manager', 'regulator')):
  require viewer = 'service:operator' or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  return upsert roles[who] { principal: who, role }

mutation registerProperty(owner: principal, label: text 1..120):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return upsert properties[owner] { owner, label }

-- Scheduling a blast sends its notice immediately: one notice row per
-- registered property, and the notice timestamp the 24h rule enforces.
mutation scheduleBlast(label: text 1..80, site: text 1..120, scheduledAt: time):
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  require scheduledAt > now else BLAST_IN_PAST 'The blast must be scheduled in the future.'
  b = insert blasts { label, site, scheduledAt, noticeSentAt: now, createdBy: viewer }
  for p in properties first 500 by .id:
    insert notices { blast: b.id, recipient: p.owner, sentAt: now, message: 'Blast notice: ' + label }
  return b

mutation uploadPlan(blast: blasts, planText: text 1..4000):
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  require b.status = 'scheduled' else BAD_STATUS 'The plan can only change before firing.'
  return upsert blastPlans[blast] { blast, planText, uploadedBy: viewer, uploadedAt: now }

mutation addChecklistItem(blast: blasts, item: text 1..200):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  require b.status = 'scheduled' else BAD_STATUS 'The checklist is closed after firing.'
  return insert checklistItems { blast, item }

mutation tickChecklistItem(item: checklistItems, done: bool):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  i = checklistItems[item] ! else NOT_FOUND
  update checklistItems[item] { done, updatedBy: viewer }
  return null

-- Firing needs the 24h notice window and a complete site-clear checklist.
mutation fireBlast(blast: blasts):
  require exists roles[viewer, role = 'blaster'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  require b.status = 'scheduled' else BAD_STATUS 'Only a scheduled blast can fire.'
  require b.noticeSentAt != null else NO_NOTICE 'No notice was sent for this blast.'
  require now - b.noticeSentAt >= 24h else TOO_SOON 'The blast cannot fire less than 24 hours after its notice was sent.'
  require checkTotals[blast] >= 1 else NO_CHECKLIST 'The site-clear checklist is empty.'
  require openChecks[blast] = 0 else CHECKLIST_OPEN 'The site is not clear.'
  update blasts[blast] { status: 'fired', firedAt: now }
  return null

-- Recorded afterward, from the nearest home. Above the limit opens a report.
-- Every recording also refreshes the blast's reading assessment: above limit
-- when any recorded reading for the blast exceeds its limit, within limit
-- when readings exist and none exceed, awaiting reading only when none do
-- (a fresh blast starts there through the column default).
mutation recordReading(blast: blasts, property: properties, value: int 0..1000):
  require exists roles[viewer, role = 'blaster'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  require b.status = 'fired' else NOT_FIRED 'Readings are recorded after firing.'
  p = properties[property] ! else NOT_FOUND
  priorAbove = aboveReadings[blast]
  r = insert readings { blast, property, owner: p.owner, value, recordedBy: viewer }
  update blasts[blast] { assessment: 'above limit' if value > r.limit or priorAbove > 0 else 'within limit' }
  if value > r.limit:
    insert reports { blast, reading: r.id, property, owner: p.owner, value, limit: r.limit }
  return r

-- Correct a recorded reading. The blast assessment is recomputed from all of
-- the blast's readings under the same rule. A correction upward opens a
-- report like a fresh recording; a correction downward never closes one:
-- only the regulator closes reports.
mutation correctReading(reading: readings, value: int 0..1000):
  require exists roles[viewer, role = 'blaster'] else NOT_ALLOWED
  r = readings[reading] ! else NOT_FOUND
  priorAbove = aboveReadings[r.blast]
  oldAbove = 1 if r.value > r.limit else 0
  newAbove = 1 if value > r.limit else 0
  above = priorAbove - oldAbove + newAbove
  update readings[reading] { value }
  update blasts[r.blast] { assessment: 'above limit' if above > 0 else 'within limit' }
  if value > r.limit:
    rep = reports[reading]
    if rep = null:
      insert reports { blast: r.blast, reading: r.id, property: r.property, owner: r.owner, value, limit: r.limit }
  return null

-- Recompute one blast's assessment from its readings (migration backfill and
-- repair). Idempotent: awaiting reading with no readings, otherwise above
-- limit when any reading exceeds its limit, within limit otherwise.
mutation reassessBlast(blast: blasts):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  b = blasts[blast] ! else NOT_FOUND
  total = readingTotals[blast]
  above = aboveReadings[blast]
  update blasts[blast] { assessment: 'awaiting reading' }
  if total > 0:
    update blasts[blast] { assessment: 'within limit' }
  if above > 0:
    update blasts[blast] { assessment: 'above limit' }
  return null

mutation fileComplaint(blast: blasts ?, body: text 1..1000):
  require exists roles[viewer, role = 'neighbor'] else NOT_NEIGHBOR
  if blast != null:
    b = blasts[blast] ! else NOT_FOUND
  return insert complaints { author: viewer, blast, body }

-- Only the regulator closes a report, with findings recorded.
mutation closeReport(report: reports, findings: text 1..2000):
  require exists roles[viewer, role = 'regulator'] else NOT_ALLOWED
  r = reports[report] ! else NOT_FOUND
  require r.status = 'open' else ALREADY_CLOSED 'This report is already closed.'
  update reports[report] { status: 'closed', findings, closedBy: viewer, closedAt: now }
  return null

mutation cancelBlast(blast: blasts):
  require exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] else NOT_ALLOWED
  b = blasts[blast] ! else NOT_FOUND
  require b.status = 'scheduled' else BAD_STATUS 'Only a scheduled blast can be cancelled.'
  update blasts[blast] { status: 'cancelled' }
  return null

-- Privacy intent, stated separately from the rules (guide security).
-- Neighbors read only blast dates (via blastDates) and the readings near
-- their own property; plans and checklists stay with quarry staff; only the
-- manager reads complaints in full; reports stay with blaster/manager/regulator.
invariant roles.read only .principal = viewer
invariant blasts.read only exists roles[viewer]
invariant blastPlans.read only exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant checklistItems.read only exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant openChecks.read only exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant checkTotals.read only exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager']
invariant properties.read only .owner = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'blaster']
invariant readings.read only .owner = viewer or exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator']
invariant reports.read only exists roles[viewer, role = 'blaster'] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'regulator']
invariant reports.update only exists roles[viewer, role = 'regulator']
invariant notices.read only .recipient = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'blaster']
invariant complaints.read only .author = viewer or exists roles[viewer, role = 'manager']
invariant complaints.insert only .author = viewer and exists roles[viewer, role = 'neighbor']
