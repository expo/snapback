-- Venison Processing Tags (v2).
-- Roles: hunter, clerk (intake), butcher, owner.
-- Clerks intake carcasses for hunters. Each carcass carries an "intake tag
-- reference" (the reference shown on the hunter's tag) plus a required photo
-- of the tag. `tagNumber` is the v1 name of the same value, kept as a
-- dual-written legacy mirror so a v1 release rollback keeps every row
-- readable; new code must use `intakeTagRef`.
-- Carcasses must be cut within 7 days (flagged to owner when overdue).
-- Wrapped orders must be collected within 14 days (then donated).
-- Only the owner can extend a pickup deadline, with the reason kept.
-- Only the intake clerk may correct an intake tag reference after intake.
use identity password

table roles:
  principal: principal
  role: enum('hunter', 'clerk', 'butcher', 'owner')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  insert <- .principal = viewer or exists roles[viewer, role = 'owner'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'owner'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'owner'] or viewer = 'service:ops'
  cap 10000
  online only

table profiles:
  principal: principal
  displayName: text 3..40
  phone: text 7..20
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  insert <- .principal = viewer
  update <- .principal = viewer
  delete <- .principal = viewer
  cap 10000
  online only

table carcasses:
  hunter: principal
  tagNumber: text 1..40
  intakeTagRef: text 1..40 ?
  tagPhoto: image <=5000000
  intakeAt: time default now
  cutAt: time ?
  immutable hunter, tagPhoto, intakeAt
  read <- .hunter = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  update (old, next) <- (exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner']) and (next.intakeTagRef = old.intakeTagRef or exists roles[viewer, role = 'clerk']) and (next.tagNumber = old.tagNumber or exists roles[viewer, role = 'clerk'])
  delete <- exists roles[viewer, role = 'owner']
  cap 1000 by hunter
  online only

table orders:
  carcass: carcasses
  hunter: principal
  cuts: text 1..500
  status: enum('queued', 'cut', 'wrapped', 'collected', 'donated') default 'queued'
  wrappedAt: time ?
  pickupDeadline: time ?
  collectedAt: time ?
  unique carcass
  immutable carcass, hunter
  read <- .hunter = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner']
  delete <- exists roles[viewer, role = 'owner']
  cap 500 by hunter
  online only

table extensions:
  order: orders
  hunter: principal
  newDeadline: time
  reason: text 1..280
  extendedBy: principal
  at: time default now
  immutable order, hunter, newDeadline, reason, extendedBy, at
  read <- .hunter = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'owner']
  update <- deny
  delete <- deny
  cap 20 by order
  online only

query myRole():
  return roles[viewer]

query myProfile():
  return profiles[viewer]

query hunterDirectory(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return roles where .role = 'hunter' first 50 by .id after c

query hunterProfile(hunter: principal):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return profiles[hunter]

query myCarcasses(c: cursor ?):
  return carcasses where .hunter = viewer first 50 by .id after c

query myOrders(c: cursor ?):
  return orders where .hunter = viewer first 50 by .id after c

query carcassOne(id: carcasses):
  return carcasses[id]

query orderOne(id: orders):
  return orders[id]

query allCarcasses(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return carcasses first 50 by .id after c

query cuttingBoard(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return orders where .status != 'collected' and .status != 'donated' first 50 by .id after c

query overdueCarcasses(c: cursor ?):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return carcasses where .cutAt = null and .intakeAt < now - 7d first 50 by .id after c

query pendingPickups(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return orders where .status = 'wrapped' first 50 by .id after c

query extensionsOf(order: orders, c: cursor ?):
  return extensions where .order = order first 50 by .id after c

mutation joinAsHunter():
  return insert roles { principal: viewer, role: 'hunter' }

-- The first owner is granted by the shop operator with the service:ops
-- seat (`snapback4 token --service ops`, then grantRole); there is no
-- self-claim, so shop ownership can never be raced by a stranger.
mutation grantRole(who: principal, role: enum('hunter', 'clerk', 'butcher', 'owner')):
  require exists roles[viewer, role = 'owner'] or viewer = 'service:ops' else NOT_OWNER
  return upsert roles[who] { role }

mutation saveProfile(displayName: text 3..40, phone: text 7..20):
  return upsert profiles[viewer] { displayName, phone }

-- v2 intake: the canonical argument is `intakeTagRef` (the reference shown
-- on the tag). The v1 `tagNumber` argument is still accepted and means the
-- same value, so v1 clients keep working; both columns are stored.
mutation intakeCarcass(hunter: principal, tagPhoto: image <=5000000, tagNumber: text 1..40 ?, intakeTagRef: text 1..40 ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_CLERK
  require exists roles[hunter, role = 'hunter'] or exists profiles[principal = hunter] else UNKNOWN_HUNTER
  require tagNumber != null or intakeTagRef != null else MISSING_REF
  if tagNumber != null:
    return insert carcasses { hunter, tagNumber, intakeTagRef: tagNumber, tagPhoto, intakeAt: now }
  require intakeTagRef != null else MISSING_REF
  return insert carcasses { hunter, tagNumber: intakeTagRef, intakeTagRef, tagPhoto, intakeAt: now }

-- v2 correction: only the intake clerk may correct the reference after
-- intake. Both columns move together so the legacy mirror never diverges.
mutation correctIntakeTagRef(carcass: carcasses, intakeTagRef: text 1..40):
  require exists roles[viewer, role = 'clerk'] else NOT_CLERK
  c = carcasses[carcass] ! else NOT_FOUND
  update carcasses[carcass] { intakeTagRef, tagNumber: intakeTagRef }
  return null

mutation placeOrder(carcass: carcasses, cuts: text 1..500):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_CLERK
  c = carcasses[carcass] ! else NOT_FOUND
  return insert orders { carcass, hunter: c.hunter, cuts }

mutation markCut(order: orders):
  require exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_CUTTER
  o = orders[order] ! else NOT_FOUND
  require o.status = 'queued' else BAD_STATUS
  update carcasses[o.carcass] { cutAt: now }
  update orders[order] { status: 'cut' }
  return null

mutation markWrapped(order: orders):
  require exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_CUTTER
  o = orders[order] ! else NOT_FOUND
  require o.status = 'cut' else BAD_STATUS
  update orders[order] { status: 'wrapped', wrappedAt: now, pickupDeadline: now + 14d }
  return null

mutation collectOrder(order: orders):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner'] else NOT_CLERK
  o = orders[order] ! else NOT_FOUND
  require o.status = 'wrapped' else BAD_STATUS
  require o.pickupDeadline != null and now <= o.pickupDeadline else OVERDUE
  update orders[order] { status: 'collected', collectedAt: now }
  return null

-- Donation happens only through the donateDaily job below, so the 14-day
-- rule is enforced by the server clock even when nobody clicks anything.
mutation extendDeadline(order: orders, newDeadline: time, reason: text 1..280):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  o = orders[order] ! else NOT_FOUND
  require o.status = 'wrapped' else BAD_STATUS
  require o.pickupDeadline != null and newDeadline > o.pickupDeadline else BAD_DEADLINE
  update orders[order] { pickupDeadline: newDeadline }
  return insert extensions { order, hunter: o.hunter, newDeadline, reason, extendedBy: viewer, at: now }

job donateOverdue():
  for o in orders by .id:
    if o.status = 'wrapped':
      if o.pickupDeadline != null and o.pickupDeadline < now:
        update orders[o.id] { status: 'donated' }

schedule donateDaily every 1d at 06:00: donateOverdue

invariant carcasses.read only .hunter = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner']
invariant orders.read only .hunter = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'butcher'] or exists roles[viewer, role = 'owner']
invariant profiles.read only .principal = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
invariant extensions.read only .hunter = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'owner']
