-- Coin Grading Submissions.
-- A coin club gathers members' coins into bulk submissions to a grading
-- service. Officers photograph each coin at intake and again in its graded
-- holder. A submission closes 14 days after it opens. Members follow status
-- live; members see only their own coins; the treasurer sees declared values
-- for insurance but never member addresses; only the president may accept a
-- coin into a closed submission, with the reason recorded.
--
-- Privacy is enforced per audience with one table per audience: `coins`
-- carries owner identity and address (owner, officer, president only) while
-- `insurance` carries only value identity (treasurer, officer, president).
-- Both rows are written atomically by the same mutation.
use identity password

-- Officers and the president can read the roster: intake (addCoin /
-- acceptLateCoin) must verify that a coin's owner is a current member, and
-- that probe can only see rows the viewer may read. Members and treasurers
-- see only their own row.
table roles:
  principal: principal
  role: enum('member', 'officer', 'treasurer', 'president')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

-- Bulk submission to the grading service. Readable by every signed-in
-- member so they can follow status live. Opened only by officers; the
-- 14-day window is enforced by mutation `require` checks on server `now`,
-- not by read rules (a rule cannot vary with time).
table submissions:
  title: text 1..80
  openedAt: time
  openedBy: principal
  status: enum('intake', 'shipped', 'grading', 'returned') default 'intake'
  statusNote: text <=280 ?
  updatedAt: time default now
  immutable openedAt, openedBy
  read <- allow
  insert <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
  update <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
  online only

-- One member coin in a submission. The owner must already hold the member
-- role; the rule probe sees roster rows even though officers cannot read
-- the roster table's other rows.
table coins:
  submission: submissions
  owner: principal
  description: text 1..200
  declaredValue: money USD
  insuranceTier: enum('standard', 'enhanced', 'special') default 'standard'
  address: text 1..300
  grade: text <=20 ?
  intakePhoto: image <=5000000
  gradedPhoto: image <=5000000 ?
  lateReason: text <=280 ?
  addedAt: time default now
  addedBy: principal
  immutable submission, owner, addedBy
  cap 1000 by submission
  read <- .owner = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
  insert <- (exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']) and exists roles[.owner, role = 'member']
  update (old, next) <- exists roles[viewer, role = 'officer'] or (exists roles[viewer, role = 'president'] and next.insuranceTier = old.insuranceTier)
  online only

-- Insurance copy of a coin: value identity without owner or address, so the
-- treasurer audience physically cannot read member addresses.
table insurance:
  coin: coins
  submission: submissions
  description: text 1..200
  declaredValue: money USD
  insuranceTier: enum('standard', 'enhanced', 'special') default 'standard'
  unique coin
  immutable coin, submission
  read <- exists roles[viewer, role = 'treasurer'] or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
  insert <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
  update <- exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
  online only

query myRole():
  return roles[viewer]

query submissions(c: cursor ?):
  return submissions last 50 by .id after c

query myCoins(c: cursor ?):
  return coins where .owner = viewer last 100 by .id after c

query officerCoins(submission: submissions, c: cursor ?):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] else NOT_OFFICER
  return coins where .submission = submission last 100 by .id after c

query insuranceRows(submission: submissions, c: cursor ?):
  require exists roles[viewer, role = 'treasurer'] or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] else NOT_INSURANCE
  return insurance where .submission = submission last 100 by .id after c

-- First-admin seat: only the local filesystem operator provisions roles, so
-- there is no public first-user race and no self-promotion path.
mutation provision(principal: principal, role: enum('member', 'officer', 'treasurer', 'president')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation openSubmission(title: text 1..80, openedAt: time ?):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] else NOT_OFFICER
  opened = openedAt ?? now
  require opened <= now else BAD_OPENED_AT 'A submission cannot open in the future.'
  return insert submissions { title, openedAt: opened, openedBy: viewer }

mutation updateSubmissionStatus(submission: submissions, status: enum('intake', 'shipped', 'grading', 'returned'), statusNote: text <=280 ?):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] else NOT_OFFICER
  s = submissions[submission] ! else NOT_FOUND
  update submissions[submission] { status, statusNote: statusNote ?? s.statusNote, updatedAt: now }
  return null

mutation addCoin(submission: submissions, owner: principal, description: text 1..200, declaredValue: money USD, address: text 1..300, intakePhoto: image <=5000000):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] else NOT_OFFICER
  s = submissions[submission] ! else NOT_FOUND
  require now < s.openedAt + 14d else SUBMISSION_CLOSED 'This submission is closed; only the president may accept a late coin with a recorded reason.'
  require exists roles[owner, role = 'member'] else NOT_MEMBER 'Coins may only be recorded for club members.'
  tier = 'standard' if declaredValue <= 100 else 'enhanced' if declaredValue <= 1000 else 'special'
  coin = insert coins { submission, owner, description, declaredValue, insuranceTier: tier, address, intakePhoto, addedBy: viewer }
  ins = insert insurance { coin, submission, description, declaredValue, insuranceTier: tier }
  return { coin: coin.id, insurance: ins.id }

-- The single privileged path into a closed submission. Open-window intake
-- must use addCoin instead, so every late coin carries its reason.
mutation acceptLateCoin(submission: submissions, owner: principal, description: text 1..200, declaredValue: money USD, address: text 1..300, intakePhoto: image <=5000000, reason: text 1..280):
  require exists roles[viewer, role = 'president'] else NOT_PRESIDENT
  s = submissions[submission] ! else NOT_FOUND
  require now >= s.openedAt + 14d else NOT_CLOSED 'Late acceptance needs a closed submission; use addCoin while it is open.'
  require exists roles[owner, role = 'member'] else NOT_MEMBER 'Coins may only be recorded for club members.'
  tier = 'standard' if declaredValue <= 100 else 'enhanced' if declaredValue <= 1000 else 'special'
  coin = insert coins { submission, owner, description, declaredValue, insuranceTier: tier, address, intakePhoto, addedBy: viewer, lateReason: reason }
  ins = insert insurance { coin, submission, description, declaredValue, insuranceTier: tier }
  return { coin: coin.id, insurance: ins.id }

-- Insurance tier override. Only the submission officer may change a coin's
-- tier; members, the treasurer and the president cannot. The tier travels
-- with the coin into the insurance copy so the treasurer audience keeps
-- seeing the current tier without ever seeing member addresses.
mutation setInsuranceTier(coin: coins, tier: enum('standard', 'enhanced', 'special')):
  require exists roles[viewer, role = 'officer'] else NOT_OFFICER
  c = coins[coin] ! else NOT_FOUND
  update coins[coin] { insuranceTier: tier }
  ins = insurance[coin] ! else NOT_FOUND
  update insurance[ins] { insuranceTier: tier }
  return null

-- Graded-holder photo and grade, recorded after return. Grading finishes
-- after shipping, so this path stays open after the submission closes.
mutation setGrade(coin: coins, grade: text <=20, gradedPhoto: image <=5000000):
  require exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] else NOT_OFFICER
  c = coins[coin] ! else NOT_FOUND
  update coins[coin] { grade, gradedPhoto }
  return null

-- Independent privacy intent; `guide security` states unproved paths.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president'] or viewer = 'service:operator'
invariant coins.read only .owner = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
invariant insurance.read only exists roles[viewer, role = 'treasurer'] or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
invariant submissions.insert only exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'president']
