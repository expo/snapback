-- Storage Lien Auctions.
-- Roles: tenant, frontdesk (front desk staff), bidder, manager (district manager).
-- Real password authentication; roles live in accounts and every rule probes them.
use identity password

-- Roster: one row per registered user. Self-registration covers tenant/bidder;
-- frontdesk/manager come from assignRole (manager) or the one-time bootstrap.
table accounts:
  principal: principal
  role: enum('tenant', 'frontdesk', 'bidder', 'manager')
  name: text 1..40
  unique principal
  read <- .principal = viewer or exists accounts[viewer, role = 'manager']
  insert <- .principal = viewer or exists accounts[viewer, role = 'manager']
  update <- .principal = viewer or exists accounts[viewer, role = 'manager']
  online only

-- Whole-table cap of 1: only the first bootstrapManager call succeeds.
table managerSeal:
  at: time default now
  cap 1
  insert <- allow
  online only

-- Rental units. Tenants read only their own; staff read all; bidders read none
-- (bidders see lien sales through the public listings/inventory tables only).
-- Tenants update only through payRent (balance/lock fields); staff mutations
-- own the rest.
table units:
  unitNumber: text 1..12
  tenant: principal ?
  monthlyCents: int 1..1000000
  balanceCents: int 0..100000000
  rentDueAt: time
  locked: bool default false
  lockoutAt: time ?
  lockPhoto: image <=5000000 ?
  saleState: enum('none', 'listed', 'stopped', 'sold') default 'none'
  followup: enum('sale', 'lockout', 'routine') default 'routine'
  unique unitNumber else UNIT_TAKEN
  read <- .tenant = viewer or exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  insert <- exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  update <- .tenant = viewer or exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  delete <- exists accounts[viewer, role = 'manager']
  online only

-- Tenant payment cards. Owner-only in every direction: front desk staff have
-- no read access, so unit status never leaks card details.
table paymentCards:
  owner: principal
  last4: text 4..4
  brand: text 1..20
  unique owner
  read <- .owner = viewer
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
  online only

-- Lockout / lien notices. Written by the sweep job and the staff processing
-- mutations only; tenants read their own, staff read all.
table notices:
  tenant: principal
  unit: units
  body: text 1..500
  at: time default now
  read <- .tenant = viewer or exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  insert <- exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  online only

-- Public lien-sale listings. Created by the sweep job or staff processing;
-- only the district manager may change one (stop/close).
table listings:
  unit: units
  label: text 1..40
  description: text 1..500
  status: enum('open', 'stopped', 'sold') default 'open'
  endsAt: time
  stopReason: text 1..500 ?
  stoppedBy: principal ?
  settledAt: time ?
  unique unit else ALREADY_LISTED
  public 'lien sale listings are public so bidders can browse them'
  insert <- exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  update <- exists accounts[viewer, role = 'manager']
  online only

-- Staff inventory of a listed unit. Every row carries a photo (required
-- evidence); bidders read, only staff write.
table inventoryItems:
  listing: listings
  photo: image <=5000000
  note: text 1..200
  at: time default now
  public 'inventory photos are public so bidders can see the unit'
  insert <- exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  online only

-- Auction bids. Public during the auction so every bidder sees them live.
table bids:
  listing: listings
  bidder: principal
  amountCents: int 1..100000000
  at: time default now
  immutable listing, bidder, amountCents
  public 'bids are public so the auction updates live for everyone'
  insert <- .bidder = viewer
  online only

-- Recorded late-fee waivers. Only the district manager creates one, always
-- with a reason. The tenant of the unit may read it; staff read all.
table waivers:
  unit: units
  tenant: principal ?
  cents: int 1..100000000
  reason: text 1..500
  waivedBy: principal
  at: time default now
  read <- .tenant = viewer or exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
  insert <- exists accounts[viewer, role = 'manager']
  online only

-- Independent privacy intent; `guide security` states unproved paths.
invariant accounts.read only .principal = viewer or exists accounts[viewer, role = 'manager']
invariant units.read only .tenant = viewer or exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']
invariant paymentCards.read only .owner = viewer
invariant notices.read only .tenant = viewer or exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager']

-- The automatic pipeline. Lockout 30 days after rent is due while a balance
-- is owed; lien sale 60 days after the lockout while still unpaid; each step
-- leaves a notice for the tenant. Staff mutations below mirror the same
-- predicates for manual processing.
job lienSweep():
  for u in units by .id:
    if not u.locked and u.balanceCents > 0 and u.rentDueAt + 30d <= now:
      update units[u] { locked: true, lockoutAt: now }
      t = u.tenant
      if t != null:
        insert notices { tenant: t, unit: u.id, body: 'Your unit is locked for nonpayment. Pay your balance to regain access.' }
  for v in units by .id:
    lo = v.lockoutAt
    if v.locked and v.saleState = 'none' and v.balanceCents > 0 and lo != null and lo + 60d <= now:
      update units[v] { saleState: 'listed' }
      insert listings { unit: v.id, label: v.unitNumber, description: 'Lien sale for storage unit. Contents sold as-is.', endsAt: now + 14d, status: 'open' }
      t2 = v.tenant
      if t2 != null:
        insert notices { tenant: t2, unit: v.id, body: 'Your unit is going to lien sale for nonpayment. Pay your balance immediately.' }

schedule lienDaily every 1d at 03:00: lienSweep

query myAccount():
  return accounts[principal = viewer]

query directory(c: cursor ?):
  require exists accounts[viewer, role = 'manager'] else NOT_MANAGER
  return accounts after c first 100 by .id

query myUnits(c: cursor ?):
  return units where .tenant = viewer after c first 100 by .id

query allUnits(c: cursor ?):
  require exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager'] else NOT_STAFF
  return units after c first 100 by .id

query unitDetail(unit: units):
  return units[unit]

query myNotices(c: cursor ?):
  return notices where .tenant = viewer after c first 100 by .id

query allNotices(c: cursor ?):
  require exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager'] else NOT_STAFF
  return notices after c first 100 by .id

query myCards(c: cursor ?):
  return paymentCards where .owner = viewer after c first 50 by .id

query cardFor(owner: principal):
  require owner = viewer else CARD_PRIVATE
  return paymentCards[owner]

query openListings(c: cursor ?):
  return listings where .status = 'open' after c first 100 by .id

query allListings(c: cursor ?):
  require exists accounts[viewer, role = 'frontdesk'] or exists accounts[viewer, role = 'manager'] else NOT_STAFF
  return listings after c first 100 by .id

query listingDetail(listing: listings):
  return listings[listing]

query bidsFor(listing: listings, c: cursor ?):
  return bids where .listing = listing after c last 100 by .id

query winningBid(listing: listings, c: cursor ?):
  return bids where .listing = listing after c last 1 by .amountCents

query inventoryFor(listing: listings, c: cursor ?):
  return inventoryItems where .listing = listing after c first 100 by .id

query waiversFor(unit: units, c: cursor ?):
  return waivers where .unit = unit after c first 50 by .id

mutation registerSelf(role: enum('tenant', 'frontdesk', 'bidder', 'manager'), name: text 1..40):
  require role = 'tenant' or role = 'bidder' else BAD_ROLE
  old = accounts[viewer]
  require old = null else ALREADY_REGISTERED
  return insert accounts { principal: viewer, role, name }

mutation bootstrapManager(name: text 1..40):
  old = accounts[viewer]
  require old = null else ALREADY_REGISTERED
  insert managerSeal { at: now }
  return insert accounts { principal: viewer, role: 'manager', name }

mutation assignRole(who: principal, role: enum('tenant', 'frontdesk', 'bidder', 'manager'), name: text 1..40):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'manager' else NOT_MANAGER
  return upsert accounts[who] { principal: who, role, name }

mutation createUnit(unitNumber: text 1..12, tenant: principal ?, monthlyCents: int 1..1000000, rentDueAt: time, balanceCents: int 0..100000000 ?):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  -- New units start as routine: they are never listed and carry no lockout
  -- photograph yet, so the migration rule (sale if listed, else lockout if
  -- photographed, else routine) always yields routine here.
  return insert units { unitNumber, tenant, monthlyCents, rentDueAt, balanceCents: balanceCents ?? 0, followup: 'routine' }

mutation setRentDue(unit: units, rentDueAt: time):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  u = units[unit] ! else NOT_FOUND
  update units[unit] { rentDueAt }
  return units[unit]

mutation recordCharge(unit: units, cents: int 1..100000000):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  u = units[unit] ! else NOT_FOUND
  update units[unit] { balanceCents: u.balanceCents + cents }
  return units[unit]

mutation adjustLockout(unit: units, lockoutAt: time ?):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  u = units[unit] ! else NOT_FOUND
  require u.locked else NOT_LOCKED
  update units[unit] { lockoutAt }
  return units[unit]

mutation payRent(unit: units, cents: int 1..100000000):
  u = units[unit] ! else NOT_FOUND
  require u.tenant = viewer else NOT_TENANT
  require u.balanceCents > 0 else NO_BALANCE
  require cents <= u.balanceCents else OVERPAY
  nb = u.balanceCents - cents
  update units[unit] { balanceCents: nb, locked: false if nb = 0 and u.saleState = 'none' else u.locked, lockoutAt: null if nb = 0 and u.saleState = 'none' else u.lockoutAt, rentDueAt: now + 30d if nb = 0 else u.rentDueAt }
  return units[unit]

mutation saveCard(last4: text 4..4, brand: text 1..20):
  me = accounts[viewer] ! else NOT_REGISTERED
  return upsert paymentCards[viewer] { owner: viewer, last4, brand }

mutation deleteCard():
  me = accounts[viewer] ! else NOT_REGISTERED
  c = paymentCards[viewer] ! else NOT_FOUND
  delete paymentCards[c]

mutation placeLockPhoto(unit: units, photo: image <=5000000):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  u = units[unit] ! else NOT_FOUND
  require u.locked else NOT_LOCKED
  update units[unit] { lockPhoto: photo }
  return units[unit]

mutation processLockout(unit: units):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  u = units[unit] ! else NOT_FOUND
  require not u.locked else ALREADY_LOCKED
  require u.balanceCents > 0 else NO_BALANCE
  require u.rentDueAt + 30d <= now else TOO_EARLY
  t = u.tenant ! else NO_TENANT
  update units[unit] { locked: true, lockoutAt: now }
  insert notices { tenant: t, unit: u.id, body: 'Your unit is locked for nonpayment. Pay your balance to regain access.' }
  return units[unit]

mutation processLienSale(unit: units):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  u = units[unit] ! else NOT_FOUND
  require u.locked else NOT_LOCKED
  require u.saleState = 'none' else ALREADY_LISTED
  require u.balanceCents > 0 else NO_BALANCE
  lo = u.lockoutAt ! else NO_LOCKOUT
  require lo + 60d <= now else TOO_EARLY
  t = u.tenant ! else NO_TENANT
  update units[unit] { saleState: 'listed' }
  listing = insert listings { unit: u.id, label: u.unitNumber, description: 'Lien sale for storage unit. Contents sold as-is.', endsAt: now + 14d, status: 'open' }
  insert notices { tenant: t, unit: u.id, body: 'Your unit is going to lien sale for nonpayment. Pay your balance immediately.' }
  return listing

mutation addInventory(listing: listings, photo: image <=5000000, note: text 1..200):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'frontdesk' or me.role = 'manager' else NOT_STAFF
  l = listings[listing] ! else NOT_FOUND
  require l.status = 'open' else SALE_CLOSED
  return insert inventoryItems { listing, photo, note }

mutation placeBid(listing: listings, amountCents: int 1..100000000):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'bidder' else NOT_BIDDER
  l = listings[listing] ! else NOT_FOUND
  require l.status = 'open' else SALE_CLOSED
  require now <= l.endsAt else AUCTION_ENDED
  top = max(bids where .listing = listing, .amountCents)
  require amountCents > (top ?? 0) else TOO_LOW
  return insert bids { listing, bidder: viewer, amountCents }

mutation stopSale(listing: listings, reason: text 1..500):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'manager' else NOT_MANAGER
  l = listings[listing] ! else NOT_FOUND
  require l.status = 'open' else SALE_CLOSED
  u = units[l.unit] ! else NOT_FOUND
  update listings[listing] { status: 'stopped', stopReason: reason, stoppedBy: viewer, settledAt: now }
  update units[l.unit] { saleState: 'stopped', locked: false if u.balanceCents = 0 else u.locked, lockoutAt: null if u.balanceCents = 0 else u.lockoutAt }
  return listings[listing]

mutation closeSale(listing: listings):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'manager' else NOT_MANAGER
  l = listings[listing] ! else NOT_FOUND
  require l.status = 'open' else SALE_CLOSED
  require now >= l.endsAt else TOO_EARLY
  update listings[listing] { status: 'sold', settledAt: now }
  update units[l.unit] { saleState: 'sold' }
  return listings[listing]

-- Follow-up category. Set to routine when a unit is added; afterwards only
-- the district manager may change it. No other mutation writes this field,
-- so front desk staff and tenants cannot change it through lockouts, photos,
-- charges or payments either: those operations leave the category exactly
-- as it was.
mutation setFollowup(unit: units, followup: enum('sale', 'lockout', 'routine')):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'manager' else NOT_MANAGER
  u = units[unit] ! else NOT_FOUND
  update units[unit] { followup }
  return units[unit]

mutation waiveFees(unit: units, cents: int 1..100000000, reason: text 1..500):
  me = accounts[viewer] ! else NOT_REGISTERED
  require me.role = 'manager' else NOT_MANAGER
  u = units[unit] ! else NOT_FOUND
  require cents <= u.balanceCents else OVERPAY
  require u.balanceCents > 0 else NO_BALANCE
  nb = u.balanceCents - cents
  update units[unit] { balanceCents: nb, locked: false if nb = 0 and u.saleState = 'none' else u.locked, lockoutAt: null if nb = 0 and u.saleState = 'none' else u.lockoutAt }
  return insert waivers { unit: u.id, tenant: u.tenant, cents, reason, waivedBy: viewer }
