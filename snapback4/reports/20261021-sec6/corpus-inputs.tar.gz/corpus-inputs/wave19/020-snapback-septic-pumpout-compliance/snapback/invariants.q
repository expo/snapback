invariant roles.read only .principal = viewer
invariant roles.insert only .principal = viewer or exists roles[viewer, role = 'officer']
invariant properties.read only .owner = viewer or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
invariant properties.insert only .owner = viewer
invariant properties.delete only .owner = viewer
invariant reports.read only .pumper = viewer or exists properties[.property, owner = viewer] or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
invariant reports.insert only .pumper = viewer
invariant extensions.read only exists properties[.property, owner = viewer] or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
invariant explanations.read only exists properties[.property, owner = viewer] or exists roles[viewer, role = 'officer']
invariant extensions.insert only exists roles[viewer, role = 'officer']
invariant reminders.read only .owner = viewer or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
