-- Prison Book Mailings: volunteers answer letters from incarcerated readers.
-- Roles: coordinator, letter_reader, packer, volunteer, donor.
-- Private contact details (facility reader number, address) live in
-- requestPrivate, visible only to the assigned packer and the coordinator.
-- `inmateNo` is the v1 name of the number, kept as a compat mirror of
-- `facilityReaderNo`. Donors see only
-- the mailed-books total. A package for a facility rejected in the last 60
-- days is held for coordinator review. Only the coordinator can block a
-- reader or change facility rules, always with a recorded reason.
use identity password

table members:
  principal: principal
  role: enum('coordinator', 'letter_reader', 'packer', 'volunteer', 'donor')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table facilities:
  name: text 1..80
  rulesText: text 1..2000
  lastRejectedAt: time ?
  unique name else FACILITY_TAKEN 'A facility with this name already exists.'
  read <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
  insert <- exists members[principal = viewer, role = 'coordinator']
  update <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer']
  cap 200
  online only

table readers:
  displayName: text 1..80
  facility: facilities
  blocked: bool default false
  immutable facility
  read <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
  insert <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader']
  update <- exists members[principal = viewer, role = 'coordinator']
  cap 2000
  online only

table packages:
  reader: readers
  facility: facilities
  titles: text 1..200
  scan: image <=10000000
  status: enum('open', 'claimed', 'held', 'mailed', 'rejected') default 'open'
  claimedBy: principal ?
  createdBy: principal
  createdAt: time default now
  decidedAt: time ?
  note: text <=500 ?
  immutable reader, facility, createdBy, createdAt
  read <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
  insert <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader']
  update <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer']
  cap 5000
  online only

table requestPrivate:
  package: packages
  facilityReaderNo: text 1..40 ?
  inmateNo: text 1..40 ?
  address: text 1..300
  assignee: principal ?
  unique package
  immutable package, address
  read <- .assignee = viewer or exists members[principal = viewer, role = 'coordinator']
  insert <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader']
  update <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer']
  online only

table rejections:
  facility: facilities
  package: packages ?
  reason: text 1..500
  at: time default now
  actor: principal
  immutable facility, package, reason, at, actor
  read <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
  insert <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer']
  cap 5000
  online only

table facilityRuleAudits:
  facility: facilities
  rules: text 1..2000
  reason: text 1..500
  actor: principal
  at: time default now
  immutable facility, rules, reason, actor, at
  read <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
  insert <- exists members[principal = viewer, role = 'coordinator']
  cap 5000
  online only

table readerBlocks:
  reader: readers
  reason: text 1..500
  blocked: bool
  actor: principal
  at: time default now
  immutable reader, reason, blocked, actor, at
  read <- exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
  insert <- exists members[principal = viewer, role = 'coordinator']
  cap 5000
  online only

view booksSent: count packages where .status = 'mailed' by .status
  read <- allow

invariant members.read only .principal = viewer or viewer = 'service:operator'
invariant members.role write only viewer = 'service:operator'
invariant requestPrivate.read only .assignee = viewer or exists members[principal = viewer, role = 'coordinator']
invariant packages.read only exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
invariant readers.read only exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']
invariant facilities.read only exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer']

query myRole():
  return members[principal = viewer]

query totals():
  require exists members[viewer] else NOT_MEMBER 'Sign in with a provisioned volunteer account.'
  return booksSent['mailed'] ?? 0

query board(c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer'] else NOT_ALLOWED 'This board is for volunteers, readers, packers and the coordinator.'
  return packages last 50 by .id after c

query heldQueue(c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator reviews held packages.'
  return packages where .status = 'held' last 50 by .id after c

query facilitiesList(c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer'] else NOT_ALLOWED 'This list is not for donors.'
  return facilities first 50 by .id after c

query readersList(c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer'] else NOT_ALLOWED 'This list is not for donors.'
  return readers first 50 by .id after c

query privateFor(pkg: packages):
  return requestPrivate[package = pkg]

query rejectionsFor(facility: facilities, c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] or exists members[principal = viewer, role = 'packer'] or exists members[principal = viewer, role = 'volunteer'] else NOT_ALLOWED 'This history is not for donors.'
  return rejections where .facility = facility last 50 by .at after c

query auditsRules(c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator reads the audit trail.'
  return facilityRuleAudits last 50 by .id after c

query auditsBlocks(c: cursor ?):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator reads the audit trail.'
  return readerBlocks last 50 by .id after c

mutation provision(principal: principal, role: enum('coordinator', 'letter_reader', 'packer', 'volunteer', 'donor')):
  require viewer = 'service:operator' else NOT_OPERATOR 'Only the local operator provisions roles.'
  return upsert members[principal] { role }

mutation addFacility(name: text 1..80, rulesText: text 1..2000):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator manages facilities.'
  return insert facilities { name, rulesText }

mutation setFacilityRules(facility: facilities, rules: text 1..2000, reason: text 1..500):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator changes facility rules.'
  f = facilities[facility] ! else NOT_FOUND
  update facilities[facility] { rulesText: rules }
  return insert facilityRuleAudits { facility, rules, reason, actor: viewer, at: now }

mutation addReader(displayName: text 1..80, facility: facilities):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] else NOT_READER 'Only letter readers and the coordinator register readers.'
  f = facilities[facility] ! else NOT_FOUND
  return insert readers { displayName, facility, blocked: false }

mutation logRequest(reader: readers, facility: facilities, titles: text 1..200, scan: image <=10000000, facilityReaderNo: text 1..40 ?, inmateNo: text 1..40 ?, address: text 1..300):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'letter_reader'] else NOT_READER 'Only letter readers and the coordinator log requests.'
  r = readers[reader] ! else NOT_FOUND
  require not r.blocked else READER_BLOCKED 'This reader is blocked.'
  f = facilities[facility] ! else NOT_FOUND
  require r.facility = facility else WRONG_FACILITY 'The reader is registered at a different facility.'
  number = facilityReaderNo ?? inmateNo
  p = insert packages { reader, facility, titles, scan, status: 'open', createdBy: viewer, createdAt: now }
  insert requestPrivate { package: p.id, facilityReaderNo: number, inmateNo: number, address }
  return p

mutation setFacilityReaderNumber(pkg: packages, facilityReaderNo: text 1..40 ?):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator changes facility reader numbers.'
  p = packages[pkg] ! else NOT_FOUND
  r = requestPrivate[package = pkg] ! else NOT_FOUND
  update requestPrivate[package = pkg] { facilityReaderNo: facilityReaderNo, inmateNo: facilityReaderNo }
  return requestPrivate[package = pkg]

mutation claimPackage(pkg: packages):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer'] else NOT_PACKER 'Only packers and the coordinator claim packages.'
  p = packages[pkg] ! else NOT_FOUND
  require p.status = 'open' else BAD_STATE 'Only open packages can be claimed.'
  f = facilities[p.facility] ! else NOT_FOUND
  cutoff = now - 60d
  recent = f.lastRejectedAt ?? 0
  status = 'held' if recent >= cutoff else 'claimed'
  update packages[pkg] { status, claimedBy: viewer }
  update requestPrivate[package = pkg] { assignee: viewer }
  return packages[pkg]

mutation releasePackage(pkg: packages):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator releases held packages.'
  p = packages[pkg] ! else NOT_FOUND
  require p.status = 'held' else BAD_STATE 'Only held packages can be released.'
  update packages[pkg] { status: 'claimed' }
  return packages[pkg]

mutation mailPackage(pkg: packages):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer'] else NOT_PACKER 'Only packers and the coordinator mail packages.'
  p = packages[pkg] ! else NOT_FOUND
  require p.status = 'claimed' else BAD_STATE 'Only claimed packages can be mailed.'
  require p.claimedBy = viewer or exists members[principal = viewer, role = 'coordinator'] else NOT_HANDLER 'Only the packer handling this package can mail it.'
  update packages[pkg] { status: 'mailed', decidedAt: now }
  return packages[pkg]

mutation rejectPackage(pkg: packages, reason: text 1..500, at: time ?):
  require exists members[principal = viewer, role = 'coordinator'] or exists members[principal = viewer, role = 'packer'] else NOT_PACKER 'Only packers and the coordinator record rejections.'
  p = packages[pkg] ! else NOT_FOUND
  require p.status = 'claimed' or p.status = 'open' else BAD_STATE 'Only open or claimed packages can be rejected.'
  stamp = at ?? now
  require stamp <= now else BAD_TIME 'A rejection cannot be in the future.'
  update packages[pkg] { status: 'rejected', decidedAt: stamp, note: reason }
  insert rejections { facility: p.facility, package: pkg, reason, at: stamp, actor: viewer }
  update facilities[p.facility] { lastRejectedAt: stamp }
  return packages[pkg]

mutation blockReader(reader: readers, reason: text 1..500):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator blocks readers.'
  r = readers[reader] ! else NOT_FOUND
  update readers[reader] { blocked: true }
  return insert readerBlocks { reader, reason, blocked: true, actor: viewer, at: now }

mutation unblockReader(reader: readers, reason: text 1..500):
  require exists members[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR 'Only the coordinator unblocks readers.'
  r = readers[reader] ! else NOT_FOUND
  update readers[reader] { blocked: false }
  return insert readerBlocks { reader, reason, blocked: false, actor: viewer, at: now }
