use identity password

-- Roles are granted only by the local filesystem operator, never at signup.
table roles:
  principal: principal
  role: enum('contractor', 'monitor', 'worker', 'owner', 'supervisor', 'designer')
  unique principal
  immutable principal, role
  read <- allow
  insert <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('contractor', 'monitor', 'worker', 'owner', 'supervisor', 'designer')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return insert roles { principal, role }

query myRole():
  return roles[principal = viewer]

query directory():
  require exists roles[principal = viewer] else NOT_ENROLLED
  return roles first 100 by .id

table jobs:
  title: text 3..100
  address: text 5..200
  contractor: principal
  monitor: principal
  owner: principal
  supervisor: principal
  designer: principal
  workerA: principal
  workerB: principal
  createdAt: time
  immutable contractor, monitor, owner, supervisor, designer, workerA, workerB, title, address, createdAt
  read <- .contractor = viewer or .monitor = viewer or .owner = viewer or .supervisor = viewer or .designer = viewer or .workerA = viewer or .workerB = viewer
  insert <- .contractor = viewer and exists roles[principal = viewer, role = 'contractor']
  online only

query listJobs():
  return jobs last 100 by .id

mutation createJob(title: text 3..100, address: text 5..200, monitor: principal, owner: principal, supervisor: principal, designer: principal, workerA: principal, workerB: principal):
  require exists roles[principal = viewer, role = 'contractor'] else NOT_CONTRACTOR
  require exists roles[principal = monitor, role = 'monitor'] else INVALID_MONITOR
  require exists roles[principal = owner, role = 'owner'] else INVALID_OWNER
  require exists roles[principal = supervisor, role = 'supervisor'] else INVALID_SUPERVISOR
  require exists roles[principal = designer, role = 'designer'] else INVALID_DESIGNER
  require exists roles[principal = workerA, role = 'worker'] else INVALID_WORKER
  require exists roles[principal = workerB, role = 'worker'] else INVALID_WORKER
  return insert jobs { title, address, contractor: viewer, monitor, owner, supervisor, designer, workerA, workerB, createdAt: now }

table containments:
  job: jobs
  name: text 2..80
  boundary: text 10..2000
  revision: int 1..
  validUntil: time ?
  clearance: samples ?
  activeSample: samples ?
  dismantledAt: time ?
  immutable job, name
  read <- .job.contractor = viewer or .job.monitor = viewer or .job.owner = viewer or .job.supervisor = viewer or .job.designer = viewer or .job.workerA = viewer or .job.workerB = viewer
  insert <- .job.designer = viewer
  update <- .job.designer = viewer or .job.monitor = viewer or .job.contractor = viewer
  online only

table boundaryHistory:
  area: containments
  before: text <=2000
  afterBoundary: text 10..2000
  reason: text 10..500
  designer: principal
  at: time
  revision: int 1..
  immutable area, before, afterBoundary, reason, designer, at, revision
  read <- .area.job.contractor = viewer or .area.job.monitor = viewer or .area.job.owner = viewer or .area.job.supervisor = viewer or .area.job.designer = viewer or .area.job.workerA = viewer or .area.job.workerB = viewer
  insert <- .area.job.designer = viewer and .designer = viewer
  online only

mutation createContainment(job: jobs, name: text 2..80, boundary: text 10..2000, reason: text 10..500):
  j = jobs[job] ! else NOT_FOUND
  require j.designer = viewer else NOT_DESIGNER
  a = insert containments { job, name, boundary, revision: 1 }
  insert boundaryHistory { area: a.id, before: '', afterBoundary: boundary, reason, designer: viewer, at: now, revision: 1 }
  return a

mutation changeBoundary(area: containments, boundary: text 10..2000, reason: text 10..500):
  a = containments[area] ! else NOT_FOUND
  require a.job.designer = viewer else NOT_DESIGNER
  require a.dismantledAt = null else ALREADY_DISMANTLED
  insert boundaryHistory { area, before: a.boundary, afterBoundary: boundary, reason, designer: viewer, at: now, revision: a.revision + 1 }
  return update containments[area] { boundary, revision: a.revision + 1, validUntil: null, clearance: null, activeSample: null }

query listContainments(job: jobs):
  require exists jobs[job] else NOT_FOUND
  return containments where .job = job first 100 by .id { id, job, name, boundary, revision, validUntil, clearance, dismantledAt, cleared: .validUntil != null and .validUntil >= now, serverNow: now }

query boundaryLog(area: containments):
  require exists containments[area] else NOT_FOUND
  return boundaryHistory where .area = area first 100 by .id

table samples:
  area: containments
  monitor: principal
  revision: int 1..
  sampledAt: time
  labName: text 2..120 ?
  fibers: int 0..100000 ?
  result: enum('meets clearance limit', 'fail') ?
  report: file <=2000000 ?
  uploadedAt: time ?
  signedAt: time ?
  immutable area, monitor, revision, sampledAt
  read <- .area.job.contractor = viewer or .area.job.monitor = viewer or .area.job.owner = viewer or .area.job.supervisor = viewer or .area.job.designer = viewer or .area.job.workerA = viewer or .area.job.workerB = viewer
  insert <- .area.job.monitor = viewer and .monitor = viewer
  update <- .area.job.monitor = viewer and .monitor = viewer
  online only

mutation collectSample(area: containments):
  a = containments[area] ! else NOT_FOUND
  require a.job.monitor = viewer else NOT_MONITOR
  require a.dismantledAt = null else ALREADY_DISMANTLED
  s = insert samples { area, monitor: viewer, revision: a.revision, sampledAt: now }
  update containments[area] { validUntil: null, clearance: null, activeSample: s.id }
  return s

mutation uploadLabResult(sample: samples, labName: text 2..120, fibers: int 0..100000, report: file <=2000000):
  s = samples[sample] ! else NOT_FOUND
  a = containments[s.area] ! else NOT_FOUND
  require a.job.monitor = viewer else NOT_MONITOR
  require a.activeSample = sample else SAMPLE_SUPERSEDED
  require s.signedAt = null else ALREADY_SIGNED
  require s.area.dismantledAt = null else ALREADY_DISMANTLED
  require s.revision = s.area.revision else BOUNDARY_CHANGED
  return update samples[sample] { labName, fibers, result: 'meets clearance limit' if fibers <= 10 else 'fail', report, uploadedAt: now }

mutation signClearance(sample: samples):
  s = samples[sample] ! else NOT_FOUND
  a = containments[s.area] ! else NOT_FOUND
  require a.job.monitor = viewer else NOT_MONITOR
  require a.activeSample = sample else SAMPLE_SUPERSEDED
  require s.area.dismantledAt = null else ALREADY_DISMANTLED
  require s.signedAt = null else ALREADY_SIGNED
  require s.report != null and s.fibers != null else LAB_REQUIRED
  require s.revision = s.area.revision else BOUNDARY_CHANGED
  require s.sampledAt + 72h >= now else RESAMPLE_REQUIRED
  update samples[sample] { signedAt: now }
  return update containments[s.area] { clearance: sample, validUntil: s.sampledAt + 72h if s.fibers <= 10 else null }

query listSamples(area: containments):
  require exists containments[area] else NOT_FOUND
  return samples where .area = area last 100 by .id

mutation dismantle(area: containments):
  a = containments[area] ! else NOT_FOUND
  require a.job.contractor = viewer else NOT_CONTRACTOR
  require a.dismantledAt = null else ALREADY_DISMANTLED
  require a.validUntil != null else CLEARANCE_REQUIRED
  require a.validUntil >= now else RESAMPLE_REQUIRED
  return update containments[area] { dismantledAt: now }

table exposures:
  job: jobs
  worker: principal
  at: time
  minutes: int 1..1440
  activity: text 3..200
  medicalNotes: text 1..2000
  immutable job, worker, at, minutes, activity, medicalNotes
  read <- .worker = viewer
  insert <- .worker = viewer and exists roles[principal = viewer, role = 'worker'] and (.job.workerA = viewer or .job.workerB = viewer)
  online only

mutation logExposure(job: jobs, minutes: int 1..1440, activity: text 3..200, medicalNotes: text 1..2000):
  require exists roles[principal = viewer, role = 'worker'] else NOT_WORKER
  j = jobs[job] ! else NOT_FOUND
  require j.workerA = viewer or j.workerB = viewer else NOT_ASSIGNED
  return insert exposures { job, worker: viewer, at: now, minutes, activity, medicalNotes }

query myExposures():
  return exposures where .worker = viewer last 100 by .id

query exposureRecord(record: exposures):
  return exposures[record] ! else PRIVATE_RECORD

-- A deployment-only deterministic backfill. System jobs bypass user rules;
-- ordinary accounts cannot trigger this door. Never changes measurements,
-- collection times, signatures, validity or boundaries. Reconciles v1 edits
-- after forward as well as filling samples collected on v1.
job migrateSampleResults():
  for s in samples:
    expected = null if s.fibers = null else 'meets clearance limit' if s.fibers <= 10 else 'fail'
    if s.result != expected:
      update samples[s.id] { result: expected }
