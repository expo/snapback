use identity password

table roles:
  principal: principal
  role: enum('parent', 'coach', 'judge', 'headJudge', 'referee')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'coach'] or exists roles[principal = viewer, role = 'referee']
  insert <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('parent', 'coach', 'judge', 'headJudge', 'referee')):
  require viewer = 'service:operator' else NOT_OPERATOR
  insert roles { principal, role }
query myRole():
  return roles[principal = viewer]
query directory():
  require exists roles[principal = viewer, role = 'coach'] or exists roles[principal = viewer, role = 'referee'] else NOT_STAFF
  return roles first 100 by .id

table meets:
  title: text 1..100
  referee: principal
  head: principal
  judgeOne: principal
  judgeTwo: principal
  startsAt: time
  immutable referee, head, judgeOne, judgeTwo, startsAt
  read <- exists roles[principal = viewer]
  insert <- .referee = viewer and exists roles[principal = viewer, role = 'referee'] and exists roles[principal = .head, role = 'headJudge'] and exists roles[principal = .judgeOne, role = 'judge'] and exists roles[principal = .judgeTwo, role = 'judge']
  online only
mutation createMeet(title: text 1..100, head: principal, judgeOne: principal, judgeTwo: principal, startsAt: time):
  require exists roles[principal = viewer, role = 'referee'] else NOT_REFEREE
  require judgeOne != judgeTwo else DISTINCT_JUDGES
  require startsAt > now else FUTURE_EVENT
  return insert meets { title, referee: viewer, head, judgeOne, judgeTwo, startsAt }
query listMeets():
  return meets last 100 by .id

table routines:
  meet: meets
  coach: principal
  parent: principal
  competitor: text 1..20
  apparatus: enum('Vault', 'Bars', 'Beam', 'Floor')
  released: bool default false
  unique meet, competitor, apparatus
  immutable meet, coach, parent, competitor, apparatus
  read <- .coach = viewer or .parent = viewer or .meet.head = viewer or .meet.judgeOne = viewer or .meet.judgeTwo = viewer or .meet.referee = viewer
  insert <- .coach = viewer and exists roles[principal = viewer, role = 'coach'] and exists roles[principal = .parent, role = 'parent']
  update <- .meet.head = viewer
  online only

table identities:
  routine: routines
  meet: meets
  name: text 1..80
  unique routine
  immutable routine, meet
  read <- .routine.coach = viewer or .routine.parent = viewer or exists meets[.meet, referee = viewer]
  insert <- .routine.coach = viewer and exists routines[.routine, meet = .meet]
  online only

mutation registerRoutine(meet: meets, parent: principal, competitor: text 1..20, name: text 1..80, apparatus: enum('Vault', 'Bars', 'Beam', 'Floor')):
  require exists roles[principal = viewer, role = 'coach'] else NOT_COACH
  m = meets[meet] ! else NOT_FOUND
  require now < m.startsAt else EVENT_STARTED
  r = insert routines { meet, coach: viewer, parent, competitor, apparatus }
  insert identities { routine: r.id, meet, name }
  return r
query listRoutines(meet: meets):
  return routines where .meet = meet first 100 by .id
query identity(routine: routines):
  return identities[routine = routine]

table sheets:
  routine: routines
  meet: meets
  document: file <=5000000
  unique routine
  immutable routine, meet
  read <- .routine.coach = viewer or exists meets[.meet, head = viewer] or exists meets[.meet, judgeOne = viewer] or exists meets[.meet, judgeTwo = viewer] or exists meets[.meet, referee = viewer]
  insert <- .routine.coach = viewer and exists routines[.routine, meet = .meet]
  update <- .routine.coach = viewer
  online only
mutation uploadSheet(routine: routines, document: file <=5000000):
  r = routines[routine] ! else NOT_FOUND
  m = meets[r.meet] ! else NOT_FOUND
  require r.coach = viewer else NOT_COACH
  require now < m.startsAt else EVENT_STARTED
  upsert sheets[routine = routine] { routine, meet: r.meet, document }
query routineSheet(routine: routines):
  return sheets[routine = routine]

table photos:
  routine: routines
  photo: image <=5000000
  caption: text 1..120
  read <- .routine.coach = viewer or .routine.parent = viewer
  insert <- .routine.coach = viewer
  online only
mutation addPhoto(routine: routines, photo: image <=5000000, caption: text 1..120):
  r = routines[routine] ! else NOT_FOUND
  require r.coach = viewer else NOT_COACH
  return insert photos { routine, photo, caption }
query routinePhotos(routine: routines):
  return photos where .routine = routine first 50 by .id

table marks:
  routine: routines
  meet: meets
  judge: principal
  score: int 0..10000
  deductions: text 1..1000
  unique routine, judge
  cap 2 by routine
  immutable routine, meet, judge
  read <- .judge = viewer or (.routine.released and (.routine.coach = viewer or exists meets[.meet, head = viewer] or exists meets[.meet, judgeOne = viewer] or exists meets[.meet, judgeTwo = viewer] or exists meets[.meet, referee = viewer]))
  insert <- .judge = viewer and (exists meets[.meet, judgeOne = viewer] or exists meets[.meet, judgeTwo = viewer]) and exists routines[.routine, meet = .meet]
  update <- .judge = viewer and not .routine.released
  online only
mutation submitMark(routine: routines, score: int 0..10000, deductions: text 1..1000):
  r = routines[routine] ! else NOT_FOUND
  m = meets[r.meet] ! else NOT_FOUND
  require viewer = m.judgeOne or viewer = m.judgeTwo else NOT_PANEL_JUDGE
  require not r.released else ALREADY_RELEASED
  upsert marks[routine, viewer] { routine, meet: r.meet, judge: viewer, score, deductions }
query routineMarks(routine: routines):
  return marks where .routine = routine first 10 by .id

table results:
  routine: routines
  meet: meets
  score: int 0..10000
  postedAt: time
  unique routine
  immutable routine, meet, postedAt
  read through .routine
  insert <- .routine.meet.head = viewer and exists routines[.routine, meet = .meet]
  update <- .routine.meet.referee = viewer
  online only
mutation releaseScore(routine: routines):
  r = routines[routine] ! else NOT_FOUND
  m = meets[r.meet] ! else NOT_FOUND
  require m.head = viewer else NOT_HEAD_JUDGE
  require not r.released else ALREADY_RELEASED
  update routines[routine] { released: true }
  a = marks[routine, m.judgeOne] ! else MISSING_MARK
  b = marks[routine, m.judgeTwo] ! else MISSING_MARK
  return insert results { routine, meet: r.meet, score: (a.score + b.score) / 2, postedAt: now }
query scoreboard(meet: meets):
  return results where .meet = meet first 100 by .id

-- Stable legacy storage name: a product rename must preserve IDs and old clients.
-- kind is the literal-default migration for every historic inquiry.
table inquiries:
  kind: enum('scoreReviewRequest') default 'scoreReviewRequest'
  routine: routines
  meet: meets
  coach: principal
  reason: text 5..1000
  filedAt: time
  unique routine
  immutable routine, meet, coach, reason, filedAt
  read <- .coach = viewer or exists meets[.meet, referee = viewer]
  insert <- .coach = viewer and .routine.coach = viewer and exists routines[.routine, meet = .meet]
  online only
mutation fileInquiry(routine: routines, reason: text 5..1000):
  r = routines[routine] ! else NOT_FOUND
  require r.coach = viewer else NOT_COACH
  s = results[routine = routine] ! else SCORE_NOT_POSTED
  require now >= s.postedAt and now < s.postedAt + 5m else INQUIRY_CLOSED
  return insert inquiries { routine, meet: r.meet, coach: viewer, reason, filedAt: now }
query routineInquiry(routine: routines):
  return inquiries[routine = routine]

-- New product operations; legacy operations above remain compatible.
mutation fileScoreReviewRequest(routine: routines, reason: text 5..1000):
  r = routines[routine] ! else NOT_FOUND
  require r.coach = viewer else NOT_COACH
  s = results[routine = routine] ! else SCORE_NOT_POSTED
  require now >= s.postedAt and now < s.postedAt + 5m else SCORE_REVIEW_REQUEST_CLOSED
  return insert inquiries { routine, meet: r.meet, coach: viewer, reason, filedAt: now }
query routineScoreReviewRequest(routine: routines):
  return inquiries[routine = routine]

table adjustments:
  routine: routines
  meet: meets
  referee: principal
  beforeScore: int 0..10000
  afterScore: int 0..10000
  reason: text 5..1000
  changedAt: time
  immutable routine, meet, referee, beforeScore, afterScore, reason, changedAt
  read <- .routine.coach = viewer or exists meets[.meet, referee = viewer]
  insert <- .referee = viewer and exists meets[.meet, referee = viewer] and exists routines[.routine, meet = .meet]
  online only
mutation changeScore(routine: routines, score: int 0..10000, reason: text 5..1000):
  r = routines[routine] ! else NOT_FOUND
  m = meets[r.meet] ! else NOT_FOUND
  require m.referee = viewer else NOT_MEET_REFEREE
  s = results[routine = routine] ! else SCORE_NOT_POSTED
  insert adjustments { routine, meet: r.meet, referee: viewer, beforeScore: s.score, afterScore: score, reason, changedAt: now }
  update results[s.id] { score }
query routineAdjustments(routine: routines):
  return adjustments where .routine = routine first 100 by .id
