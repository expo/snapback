-- Busking Pitch Rota: city-managed street-performer pitch bookings.
-- Personas: alice and bob are performers; carol is city staff.
-- Two-hour slots, weekly cap of 3 bookings, 15-minute check-in window,
-- public now/next board without contact details, staff suspensions logged.

use identity
use personas alice, bob, carol

table staff:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table performers:
  principal: principal
  stageName: text 1..60
  genre: text 1..40 ?
  photo: image <=5000000 ?
  suspended: bool default false
  unique principal else ALREADY_REGISTERED 'This account already registered as a performer.'
  immutable principal
  cap 1 by principal
  public 'the performer directory is public'
  insert <- .principal = viewer
  update <- .principal = viewer or exists staff[viewer]
  online only

table performerContacts:
  performer: performers
  owner: principal
  contact: text 1..120
  unique performer
  immutable performer, owner
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  online only

table pitches:
  name: text 1..80
  area: text 1..80
  spot: text 1..120
  active: bool default true
  unique name else PITCH_NAME_TAKEN 'A pitch with this name already exists.'
  public 'the pitch map is public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  online only

table bookings:
  pitch: pitches on delete restrict
  performer: performers on delete restrict
  holder: principal
  startsAt: time
  endsAt: time
  checkedInAt: time ?
  createdAt: time default now
  unique pitch, startsAt else DOUBLE_BOOKED 'That pitch is already booked at that time.'
  immutable pitch, performer, holder, startsAt, endsAt
  cap 50 by holder
  public 'booking times are public; contact details live elsewhere'
  insert <- .holder = viewer
  update <- .holder = viewer or exists staff[viewer]
  delete <- .holder = viewer or exists staff[viewer]
  online only

view weeklyCount: count bookings by .holder, bucket(.startsAt, 7d)
  read <- .holder = viewer

table complaints:
  status: enum('open', 'reviewing', 'resolved') default 'open'
  reporter: principal
  performer: performers on delete restrict
  text: text 1..500
  at: time default now
  immutable reporter, performer
  cap 100 by reporter
  read <- .reporter = viewer or exists staff[viewer]
  insert <- .reporter = viewer and .status = 'open'
  update <- exists staff[viewer]
  online only

view complaintCount: count complaints by .performer
  read <- exists staff[viewer]

table complaintReviews:
  complaint: complaints on delete restrict
  reporter: principal
  status: enum('reviewing', 'resolved')
  note: text 1..300
  decidedBy: principal
  at: time default now
  immutable complaint, reporter, status, note, decidedBy, at
  read <- .reporter = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  online only

table suspensions:
  performer: performers on delete restrict
  subject: principal
  reason: text 1..300
  decidedBy: principal
  at: time default now
  immutable performer, subject, reason, decidedBy
  read <- .subject = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  online only

table releases:
  pitch: pitches on delete keep
  performer: performers on delete keep
  holder: principal
  startsAt: time
  releasedAt: time
  reason: text 1..300
  immutable pitch, performer, holder, startsAt, releasedAt, reason
  read <- .holder = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  online only

query pitchesList(c: cursor ?):
  return pitches first 50 by .id after c

query directory(c: cursor ?):
  return performers first 50 by .id after c

query nowPlaying():
  return bookings where .startsAt <= now and .endsAt > now first 50 by .startsAt { id, startsAt, endsAt, checkedInAt, pitch: pitches[.pitch], performer: performers[.performer] }

query upcoming(c: cursor ?):
  return bookings where .startsAt > now first 20 by .startsAt after c { id, startsAt, endsAt, checkedInAt, pitch: pitches[.pitch], performer: performers[.performer] }

query myBookings(c: cursor ?):
  return bookings where .holder = viewer last 20 by .startsAt after c { id, startsAt, endsAt, checkedInAt, pitch: pitches[.pitch], performer: performers[.performer] }

query myPerformer():
  return performers[principal = viewer]

query amStaff():
  return exists staff[viewer]

query myContacts(c: cursor ?):
  return performerContacts where .owner = viewer first 5 by .id after c

query complaintsBoard(c: cursor ?):
  if exists staff[viewer]:
    return complaints last 50 by .at after c
  return complaints where .reporter = viewer last 50 by .at after c

query suspensionsLog(c: cursor ?):
  if exists staff[viewer]:
    return suspensions last 50 by .at after c
  return suspensions where .subject = viewer last 50 by .at after c

query releasesLog(c: cursor ?):
  if exists staff[viewer]:
    return releases last 50 by .releasedAt after c
  return releases where .holder = viewer last 50 by .releasedAt after c

mutation register(stageName: text 1..60, genre: text 1..40 ?, photo: image <=5000000 ?):
  return insert performers { principal: viewer, stageName, genre, photo }

mutation updateProfile(stageName: text 1..60 ?, genre: text 1..40 ?, photo: image <=5000000 ?):
  p = performers[viewer] ! else NOT_REGISTERED 'Register as a performer first.'
  require not p.suspended else SUSPENDED 'Suspended performers cannot edit their profile.'
  update performers[viewer] { stageName: stageName ?? p.stageName, genre: genre ?? p.genre, photo: photo ?? p.photo }
  return null

mutation setContact(contact: text 1..120):
  p = performers[viewer] ! else NOT_REGISTERED 'Register as a performer first.'
  upsert performerContacts[performer = p.id] { performer: p.id, owner: viewer, contact }
  return null

mutation addPitch(name: text 1..80, area: text 1..80, spot: text 1..120):
  require exists staff[viewer] else NOT_STAFF 'Only city staff manage pitches.'
  return insert pitches { name, area, spot }

mutation setPitchActive(pitch: pitches, active: bool):
  require exists staff[viewer] else NOT_STAFF 'Only city staff manage pitches.'
  s = pitches[pitch] ! else NOT_FOUND
  update pitches[pitch] { active }
  return null

mutation book(pitch: pitches, startsAt: time):
  s = pitches[pitch] ! else NOT_FOUND
  require s.active else PITCH_CLOSED 'That pitch is currently closed.'
  p = performers[viewer] ! else NOT_REGISTERED 'Register as a performer first.'
  require not p.suspended else SUSPENDED 'Suspended performers cannot book.'
  require startsAt > now else IN_THE_PAST 'Slots must start in the future.'
  require startsAt < now + 90d else TOO_FAR_AHEAD 'Slots open at most 90 days ahead.'
  require not exists bookings[pitch, startsAt] else DOUBLE_BOOKED 'That pitch is already booked at that time.'
  require (weeklyCount[viewer, bucket(startsAt, 7d)] ?? 0) < 3 else WEEKLY_CAP 'The weekly cap is 3 bookings.'
  return insert bookings { pitch, performer: p.id, holder: viewer, startsAt, endsAt: startsAt + 2h }

mutation checkIn(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.holder = viewer else NOT_OWNER 'Only the booking holder can check in.'
  p = performers[viewer] ! else NOT_REGISTERED 'Register as a performer first.'
  require not p.suspended else SUSPENDED 'Suspended performers cannot check in.'
  require now >= b.startsAt - 30m else TOO_EARLY 'Check-in opens 30 minutes before the slot.'
  require now <= b.startsAt + 15m else MISSED 'The 15-minute check-in window has passed.'
  update bookings[booking] { checkedInAt: now }
  return null

mutation cancelBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.holder = viewer else NOT_OWNER 'Only the booking holder can cancel.'
  require b.startsAt > now else STARTED 'A slot that has started cannot be cancelled.'
  delete bookings[booking]
  return null

mutation complain(performer: performers, text: text 1..500):
  p = performers[performer] ! else NOT_FOUND
  return insert complaints { reporter: viewer, performer, text, at: now }

mutation suspend(performer: performers, reason: text 1..300):
  require exists staff[viewer] else NOT_STAFF 'Only city staff can suspend performers.'
  p = performers[performer] ! else NOT_FOUND
  require (complaintCount[performer] ?? 0) >= 2 else INSUFFICIENT_COMPLAINTS 'At least two complaints are required before suspension.'
  update performers[performer] { suspended: true }
  return insert suspensions { performer, subject: p.principal, reason, decidedBy: viewer, at: now }

mutation unsuspend(performer: performers):
  require exists staff[viewer] else NOT_STAFF 'Only city staff can lift suspensions.'
  p = performers[performer] ! else NOT_FOUND
  update performers[performer] { suspended: false }
  return null

job releaseMissed(periodStart: time, periodEnd: time):
  for b in bookings where .startsAt >= periodEnd - 1d and .startsAt < periodEnd by .startsAt:
    if b.checkedInAt = null and b.startsAt + 15m < periodEnd:
      insert releases { pitch: b.pitch, performer: b.performer, holder: b.holder, startsAt: b.startsAt, releasedAt: periodEnd, reason: 'Released: no check-in within 15 minutes.' }
      delete bookings[b.id]

schedule releaser every 5m: releaseMissed

-- An operator grants staff membership; sign-up never grants a role.
mutation grantStaff(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR 'Only the city operator can appoint staff.'
  return insert staff { principal }

query complaintReviewsLog(c: cursor ?):
  if exists staff[viewer]:
    return complaintReviews last 50 by .at after c
  return complaintReviews where .reporter = viewer last 50 by .at after c

mutation reviewComplaint(complaint: complaints, status: enum('reviewing', 'resolved'), note: text 1..300):
  require exists staff[viewer] else NOT_STAFF 'Only city staff can review complaints.'
  c = complaints[complaint] ! else NOT_FOUND
  require c.status != 'resolved' else ALREADY_RESOLVED 'Resolved complaints cannot be changed.'
  require not (c.status = 'reviewing' and status = 'reviewing') else NO_CHANGE 'Choose a different review status.'
  update complaints[complaint] { status }
  return insert complaintReviews { complaint, reporter: c.reporter, status, note, decidedBy: viewer }
