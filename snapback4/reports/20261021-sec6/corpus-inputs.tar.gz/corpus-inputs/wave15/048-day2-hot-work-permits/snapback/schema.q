-- Hot Work Permits.
--
-- Workers (alice, bob: welders/roofers) request a permit for an area + shift.
-- The site safety manager (carol) approves after reviewing the checklist and
-- photos. An approved permit expires at end of shift; permits left open are
-- escalated to the manager by a scheduled sweep. A fire watch must sign off
-- 60 minutes after work stops before the permit can close. The insurer's
-- auditor (audrey) gets a read-only log of every permit.

use identity
use personas alice, bob, carol, audrey

-- Role roster, managed out of band (seeded, never written by the app).
table staff:
  principal: principal
  role: enum('manager', 'auditor')
  unique principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- deny
  delete <- deny
  online only

table permits:
  requester: principal
  area: text 1..80
  shift: enum('day', 'swing', 'night')
  workType: enum('welding', 'roofing', 'cutting', 'grinding')
  status: enum('requested', 'approved', 'rejected', 'closed', 'escalated', 'suspended')
  safetyState: enum('clear', 'held') default 'clear'
  combustiblesCleared: bool
  extinguishersReady: bool
  ventilationOk: bool
  photos: text <=1000 ?
  requestedAt: time default now
  shiftEnd: time
  workStoppedAt: time ?
  firewatchAt: time ?
  firewatchBy: principal ?
  decidedBy: principal ?
  decidedAt: time ?
  immutable requester, area, shift, workType, requestedAt, shiftEnd
  read <- .requester = viewer or exists staff[viewer]
  insert <- .requester = viewer and not exists staff[viewer, role = 'auditor']
  update <- .requester = viewer or exists staff[viewer, role = 'manager']
  delete <- deny
  cap 500
  online only

-- A worker's own permits. Staff calling it see only their own rows (they
-- have none); the audit log below is the full view.
query myPermits(c: cursor ?):
  return permits where .requester = viewer last 50 by .requestedAt, .id after c

-- The caller's roster row, if any (null for workers). Lets the UI show roles;
-- authorization itself stays in the table rules.
query myRole():
  return staff[principal = viewer]

-- Read-only log of every permit. Workers see only their own rows through it;
-- the manager and the auditor see everything. Never refuses, so it stays
-- green for every persona.
query auditLog(c: cursor ?):
  if exists staff[viewer]:
    return permits last 100 by .requestedAt, .id after c
  return permits where .requester = viewer last 100 by .requestedAt, .id after c

mutation requestPermit(area: text 1..80, shift: enum('day', 'swing', 'night'), workType: enum('welding', 'roofing', 'cutting', 'grinding'), shiftEnd: time, combustiblesCleared: bool, extinguishersReady: bool, ventilationOk: bool, photos: text <=1000 ?):
  require shiftEnd > now else BAD_SHIFT 'The shift must end in the future.'
  row = insert permits { requester: viewer, area, shift, workType, status: 'requested', combustiblesCleared, extinguishersReady, ventilationOk, photos, requestedAt: now, shiftEnd }
  return { id: row.id }

mutation approvePermit(permit: permits):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the safety manager can approve permits.'
  p = permits[permit] ! else NOT_FOUND
  require p.safetyState = 'clear' else SAFETY_HOLD 'Clear the safety hold and review the area before approving.'
  require p.status = 'requested' or p.status = 'escalated' else BAD_STATE 'Only requested or escalated permits can be approved.'
  require p.combustiblesCleared and p.extinguishersReady and p.ventilationOk else CHECKLIST_INCOMPLETE 'All checklist items must be confirmed before approval.'
  update permits[permit] { status: 'approved', decidedBy: viewer, decidedAt: now }
  return { id: p.id }

mutation rejectPermit(permit: permits):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER 'Only the safety manager can reject permits.'
  p = permits[permit] ! else NOT_FOUND
  require p.status = 'requested' or p.status = 'escalated' else BAD_STATE 'Only requested or escalated permits can be rejected.'
  update permits[permit] { status: 'rejected', decidedBy: viewer, decidedAt: now }
  return { id: p.id }

mutation stopWork(permit: permits):
  p = permits[permit] ! else NOT_FOUND
  require p.requester = viewer or exists staff[viewer, role = 'manager'] else NOT_ALLOWED 'Only the requester or the safety manager can stop work.'
  require p.status = 'approved' else BAD_STATE 'Work can only stop on an approved permit.'
  update permits[permit] { workStoppedAt: now }
  return { id: p.id }

mutation firewatchSignoff(permit: permits):
  p = permits[permit] ! else NOT_FOUND
  require p.requester = viewer or exists staff[viewer, role = 'manager'] else NOT_ALLOWED 'Only the requester or the safety manager can record the fire watch sign-off.'
  require p.status = 'approved' else BAD_STATE 'The fire watch signs off on an approved permit.'
  require p.workStoppedAt != null else WORK_NOT_STOPPED 'Stop work before the fire watch sign-off.'
  require now >= p.workStoppedAt + 60m else TOO_EARLY 'The fire watch sign-off is due 60 minutes after work stops.'
  update permits[permit] { firewatchAt: now, firewatchBy: viewer }
  return { id: p.id }

mutation closePermit(permit: permits):
  p = permits[permit] ! else NOT_FOUND
  require p.requester = viewer or exists staff[viewer, role = 'manager'] else NOT_ALLOWED 'Only the requester or the safety manager can close a permit.'
  require p.status = 'approved' else BAD_STATE 'Only approved permits can close.'
  require p.firewatchAt != null else FIREWATCH_REQUIRED 'The fire watch must sign off before the permit can close.'
  update permits[permit] { status: 'closed' }
  return { id: p.id }

-- Permits left open past the end of the shift escalate to the safety manager.
job escalateOverdue():
  for p in permits:
    if (p.status = 'requested' or p.status = 'approved') and p.shiftEnd < now:
      update permits[p.id] { status: 'escalated' }

schedule escalateSweep every 5m: escalateOverdue

-- Trusted local operator provisions staff; signing up never grants a role.
mutation provisionStaff(principal: principal, role: enum('manager', 'auditor')):
  require viewer = 'service:operator' else NOT_OPERATOR
  row = insert staff { principal, role }
  return { id: row.id }

-- Append-only reasons and manager clearance preserve a safety audit trail.
table safetyHolds:
  permit: permits
  owner: principal
  placedBy: principal
  reason: text 1..500
  placedAt: time default now
  clearedBy: principal ?
  clearedAt: time ?
  immutable permit, owner, placedBy, reason, placedAt
  read <- .owner = viewer or exists staff[viewer]
  insert <- .placedBy = viewer and (.owner = viewer or exists staff[viewer, role = 'manager']) and not exists staff[viewer, role = 'auditor']
  update <- exists staff[viewer, role = 'manager']
  delete <- deny
  online only

query safetyLog(c: cursor ?):
  if exists staff[viewer]:
    return safetyHolds last 100 by .placedAt, .id after c
  return safetyHolds where .owner = viewer last 100 by .placedAt, .id after c

mutation placeSafetyHold(permit: permits, reason: text 1..500):
  p = permits[permit] ! else NOT_FOUND
  require (p.requester = viewer or exists staff[viewer, role = 'manager']) and not exists staff[viewer, role = 'auditor'] else NOT_ALLOWED
  require p.status = 'requested' or p.status = 'approved' or p.status = 'escalated' else BAD_STATE
  require p.safetyState = 'clear' else SAFETY_HOLD
  row = insert safetyHolds { permit, owner: p.requester, placedBy: viewer, reason, placedAt: now }
  update permits[permit] { safetyState: 'held', status: 'suspended', workStoppedAt: now, firewatchAt: null, firewatchBy: null }
  return { id: row.id }

mutation clearSafetyHold(hold: safetyHolds):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  h = safetyHolds[hold] ! else NOT_FOUND
  require h.clearedAt = null else BAD_STATE
  p = permits[h.permit] ! else NOT_FOUND
  require p.safetyState = 'held' and p.status = 'suspended' else BAD_STATE
  update safetyHolds[hold] { clearedBy: viewer, clearedAt: now }
  update permits[h.permit] { safetyState: 'clear', status: 'requested', decidedBy: null, decidedAt: null, workStoppedAt: null, firewatchAt: null, firewatchBy: null }
  return { id: p.id }
