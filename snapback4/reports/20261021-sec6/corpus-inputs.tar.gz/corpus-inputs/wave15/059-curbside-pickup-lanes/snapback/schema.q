use personas alice, bob, staff, manager

table roles:
  principal: principal
  role: enum('staff', 'manager')
  unique principal
  read <- .principal = viewer
  online only

table windows:
  label: text 1..80
  startsAt: time
  endsAt: time
  capacity: int 1..30
  public 'Pickup windows and aggregate occupancy are visible to customers.'
  update <- exists roles[viewer, role = 'manager']
  online only

table orders:
  owner: principal
  window: windows
  customerName: text 1..60
  groceryNote: text 1..200
  status: enum('booked', 'waiting', 'delivering', 'received') default 'booked'
  lane: int 1..6 ?
  arrivalSource: enum('tap', 'geofence') ?
  arrivedAt: time ?
  arrivalHour: int ?
  waitMs: int 0.. default 0
  receivedAt: time ?
  bookedAt: time default now
  unique window, owner else ALREADY_BOOKED 'You already have an order in this window.'
  immutable owner, window, customerName, groceryNote, bookedAt
  read <- .owner = viewer or exists roles[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer or exists roles[viewer]
  online only

table receiptCodes:
  order: orders
  owner: principal
  code: int 1000..9999
  unique order
  immutable order, owner, code
  read <- .owner = viewer
  insert <- .owner = viewer and .order.owner = viewer
  online only

view occupied: count orders by .window
  read <- allow
view laneUse: count orders where .status = 'waiting' or .status = 'delivering' by .lane
  read <- allow
view hourlyCount: count orders where .status = 'received' by .arrivalHour
  read <- exists roles[viewer, role = 'manager']
view hourlyWait: sum orders of .waitMs where .status = 'received' by .arrivalHour
  read <- exists roles[viewer, role = 'manager']

query myRole():
  return roles[viewer]
query pickupWindows(c: cursor ?):
  return windows first 50 by .startsAt after c { id, label, startsAt, endsAt, capacity, booked: occupied[.id] }
query myOrders(c: cursor ?):
  return orders where .owner = viewer last 30 by .bookedAt after c
query myCode(order: orders):
  return receiptCodes[order]
query laneBoard(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF 'The lane board is for store staff.'
  return orders where .status in ['waiting', 'delivering'] first 100 by .arrivedAt after c
query hourStats(hour: int):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return { hour, orders: hourlyCount[hour], waitMs: hourlyWait[hour] }

mutation book(window: windows, customerName: text 1..60, groceryNote: text 1..200, code: int 1000..9999):
  require not exists roles[viewer] else CUSTOMER_ONLY
  w = windows[window] ! else NOT_FOUND
  require w.endsAt > now else WINDOW_CLOSED
  require not exists orders[window, viewer] else ALREADY_BOOKED
  require occupied[window] < w.capacity else WINDOW_FULL 'This pickup window is full.'
  o = insert orders { owner: viewer, window, customerName, groceryNote }
  insert receiptCodes { order: o.id, owner: viewer, code }
  return o
mutation arrive(order: orders, lane: int 1..6, source: enum('tap', 'geofence')):
  o = orders[order] ! else NOT_FOUND
  require o.owner = viewer else NOT_OWNER
  require o.status = 'booked' else BAD_STATUS
  require laneUse[lane] = 0 else LANE_BUSY 'Choose an available lane.'
  update orders[order] { status: 'waiting', lane, arrivalSource: source, arrivedAt: now, arrivalHour: now / 1h }
mutation bringOut(order: orders):
  require exists roles[viewer] else NOT_STAFF
  o = orders[order] ! else NOT_FOUND
  require o.status = 'waiting' else BAD_STATUS
  at = o.arrivedAt ! else NOT_ARRIVED
  update orders[order] { status: 'delivering', waitMs: now - at }
mutation confirmReceipt(order: orders, code: int 1000..9999):
  o = orders[order] ! else NOT_FOUND
  require o.owner = viewer else NOT_OWNER
  require o.status = 'delivering' else BAD_STATUS
  secret = receiptCodes[order] ! else NOT_FOUND
  require secret.code = code else WRONG_CODE 'That receipt code does not match.'
  update orders[order] { status: 'received', receivedAt: now }
mutation setCapacity(window: windows, capacity: int 1..30):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  w = windows[window] ! else NOT_FOUND
  require capacity >= occupied[window] else BELOW_BOOKED 'Capacity cannot be below existing bookings.'
  update windows[window] { capacity }
