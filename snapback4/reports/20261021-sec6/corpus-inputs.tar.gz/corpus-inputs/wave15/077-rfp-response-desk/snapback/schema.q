use personas alice, bob, carol

table staff:
  principal: principal
  name: text 1..60
  role: enum('manager', 'owner', 'partner')
  unique principal
  public 'Team directory is visible to proposal staff in this development demo.'
  insert <- deny
  update <- deny
  delete <- deny
  online only

table proposals:
  title: text 3..120
  client: text 2..80
  deadline: time
  state: enum('active', 'signed') default 'active'
  signedBy: principal ?
  signedAt: time ?
  createdAt: time default now
  search title, client
  read <- exists staff[viewer] and (.state = 'active' or exists staff[principal = viewer, role = 'partner'])
  insert <- exists staff[principal = viewer, role = 'manager'] and .state = 'active' and .signedBy = null and .signedAt = null
  update <- exists staff[principal = viewer, role = 'partner']
  delete <- deny
  immutable title, client, deadline, createdAt
  online only

table sections:
  proposal: proposals
  title: text 2..100
  owner: principal
  due: time
  status: enum('writing', 'review', 'approved') default 'writing'
  cap 40 by proposal
  immutable proposal, title, owner, due
  read <- (.owner = viewer or exists staff[principal = viewer, role = 'manager'] or exists staff[principal = viewer, role = 'partner']) and (.proposal.state = 'active' or exists staff[principal = viewer, role = 'partner'])
  insert <- exists staff[principal = viewer, role = 'manager'] and .proposal.state = 'active' and .status = 'writing'
  update <- .proposal.state = 'active' and (.owner = viewer or exists staff[principal = viewer, role = 'manager'])
  delete <- deny
  online only

table checks:
  section: sections
  proposal: proposals
  label: text 2..160
  done: bool default false
  cap 40 by section
  immutable section, proposal, label
  read <- (exists sections[.section, owner = viewer] or exists staff[principal = viewer, role = 'manager'] or exists staff[principal = viewer, role = 'partner']) and (exists proposals[.proposal, state = 'active'] or exists staff[principal = viewer, role = 'partner'])
  insert <- exists staff[principal = viewer, role = 'manager'] and .section.proposal.state = 'active' and .done = false and exists sections[.section, proposal = .proposal]
  update <- .section.proposal.state = 'active' and (.section.owner = viewer or exists staff[principal = viewer, role = 'manager'])
  delete <- deny
  online only

table drafts:
  section: sections
  proposal: proposals
  author: principal
  document: file <=5000000 ('application/pdf', 'text/plain', 'text/markdown')
  at: time default now
  immutable section, proposal, author, document, at
  read <- (exists sections[.section, owner = viewer] or exists staff[principal = viewer, role = 'manager'] or exists staff[principal = viewer, role = 'partner']) and (exists proposals[.proposal, state = 'active'] or exists staff[principal = viewer, role = 'partner'])
  insert <- .author = viewer and .section.owner = viewer and .section.proposal.state = 'active' and exists sections[.section, proposal = .proposal]
  update <- deny
  delete <- deny
  online only

table comments:
  draft: drafts
  section: sections
  proposal: proposals
  author: principal
  body: text 1..2000
  at: time default now
  immutable draft, section, proposal, author, body, at
  read <- (exists sections[.section, owner = viewer] or exists staff[principal = viewer, role = 'manager'] or exists staff[principal = viewer, role = 'partner']) and (exists proposals[.proposal, state = 'active'] or exists staff[principal = viewer, role = 'partner'])
  insert <- .author = viewer and (exists staff[principal = viewer, role = 'manager'] or exists staff[principal = viewer, role = 'partner']) and .draft.section.proposal.state = 'active' and exists drafts[.draft, section = .section, proposal = .proposal]
  update <- deny
  delete <- deny
  online only

fn manager():
  require exists staff[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the proposal manager can do this.'
fn editable(section: sections):
  s = sections[section] ! else NOT_FOUND
  p = proposals[s.proposal] ! else NOT_FOUND
  require p.state = 'active' else PACKAGE_LOCKED 'This package has been signed and locked.'
  return s

query me():
  return staff[principal = viewer]
query team():
  return staff first 50 by .name
query board(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF
  return proposals where .state = 'active' first 50 by .deadline after c
query library(q: text <=100, c: cursor ?):
  require exists staff[principal = viewer, role = 'partner'] else NOT_PARTNER 'The proposal library is reserved for partners.'
  return proposals where .state = 'signed' matching q last 50 by .signedAt after c
query sectionsOf(proposal: proposals):
  p = proposals[proposal] ! else NOT_FOUND
  if exists staff[principal = viewer, role = 'owner']:
    return sections where .proposal = proposal and .owner = viewer first 40 by .due
  return sections where .proposal = proposal first 40 by .due
query checklist(section: sections):
  s = sections[section] ! else NOT_FOUND
  return checks where .proposal = s.proposal and .section = section first 40 by .id
query draftsOf(section: sections, c: cursor ?):
  s = sections[section] ! else NOT_FOUND
  return drafts where .proposal = s.proposal and .section = section last 50 by .at after c
query commentsOf(draft: drafts, c: cursor ?):
  d = drafts[draft] ! else NOT_FOUND
  return comments where .proposal = d.proposal and .section = d.section and .draft = draft first 50 by .at after c

mutation createProposal(title: text 3..120, client: text 2..80, deadline: time):
  manager()
  require deadline > now else BAD_DEADLINE 'Submission deadline must be in the future.'
  return insert proposals {title, client, deadline}
mutation addSection(proposal: proposals, title: text 2..100, owner: principal, due: time):
  manager()
  p = proposals[proposal] ! else NOT_FOUND
  require p.state = 'active' else PACKAGE_LOCKED
  require due <= p.deadline and due > now else BAD_DUE 'Section due date must be in the future and before submission.'
  assignee = staff[principal = owner] ! else NOT_STAFF
  require assignee.role != 'partner' else NOT_STAFF 'Assign a manager or section owner.'
  return insert sections {proposal, title, owner, due}
mutation addCheck(section: sections, label: text 2..160):
  manager()
  s = editable(section)
  require s.status != 'approved' else SECTION_APPROVED
  return insert checks {section, proposal: s.proposal, label}
mutation setCheck(check: checks, done: bool):
  row = checks[check] ! else NOT_FOUND
  s = editable(row.section)
  require s.owner = viewer or exists staff[principal = viewer, role = 'manager'] else NOT_OWNER
  require s.status != 'approved' else SECTION_APPROVED 'Approved sections cannot be changed.'
  update checks[check] {done}
mutation uploadDraft(section: sections, document: file <=5000000 ('application/pdf', 'text/plain', 'text/markdown')):
  s = editable(section)
  require s.owner = viewer else NOT_OWNER 'Only the section owner can upload a draft.'
  require s.status != 'approved' else SECTION_APPROVED
  d = insert drafts {section, proposal: s.proposal, author: viewer, document}
  update sections[section] {status: 'review'}
  return d
mutation comment(draft: drafts, body: text 1..2000):
  d = drafts[draft] ! else NOT_FOUND
  s = editable(d.section)
  require exists staff[principal = viewer, role = 'manager'] or exists staff[principal = viewer, role = 'partner'] else NOT_REVIEWER
  return insert comments {draft, section: d.section, proposal: d.proposal, author: viewer, body}
mutation approveSection(section: sections):
  manager()
  s = editable(section)
  require s.status = 'review' else NOT_IN_REVIEW
  require exists drafts where .section = section and .proposal = s.proposal else DRAFT_REQUIRED
  require count(checks where .proposal = s.proposal and .section = section) > 0 else CHECKLIST_REQUIRED
  require count(checks where .proposal = s.proposal and .section = section and .done = false) = 0 else COMPLIANCE_INCOMPLETE
  update sections[section] {status: 'approved'}
mutation signOff(proposal: proposals):
  require exists staff[principal = viewer, role = 'partner'] else NOT_PARTNER
  p = proposals[proposal] ! else NOT_FOUND
  require p.state = 'active' else PACKAGE_LOCKED
  require count(sections where .proposal = proposal) > 0 else SECTIONS_REQUIRED
  require count(sections where .proposal = proposal and .status != 'approved') = 0 else SECTIONS_INCOMPLETE 'Every section must be approved before sign-off.'
  update proposals[proposal] {state: 'signed', signedBy: viewer, signedAt: now}
