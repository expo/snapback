-- Walkathon Lap Pledges backend.
-- Sponsors pledge cents-per-lap for a walker (optional cap in cents).
-- Organizers (roster table, seeded in fixtures) record laps and manage teams.
-- Lap counts are public; pledges are visible to sponsor, walker, organizer.
use identity
use personas alice, bob, carol

table teams:
  name: text 1..80
  unique name
  public 'team names are shown on the public leaderboard'
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  sync

table organizers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table walkers:
  principal: principal
  name: text 1..80
  team: teams ?
  unique principal
  public 'the walker roster is public so sponsors can find walkers'
  insert <- .principal = viewer
  update <- .principal = viewer or exists organizers[viewer]
  delete <- deny
  online only

table laps:
  walker: walkers
  n: int 1..1000
  at: time default now
  unique walker, n
  immutable walker, n
  public 'live lap counts are public'
  insert <- exists organizers[viewer]
  update <- deny
  delete <- exists organizers[viewer]
  sync

table pledges:
  sponsor: principal
  walker: walkers
  perLap: int 10..100000
  maxTotal: int 1..10000000 ?
  immutable sponsor, walker
  read <- .sponsor = viewer or .walker.principal = viewer or exists organizers[viewer]
  insert <- .sponsor = viewer
  update <- .sponsor = viewer
  delete <- .sponsor = viewer
  cap 200 by walker
  online only

view lapCounts: count laps by .walker

query walkersList(c: cursor ?):
  return walkers first 50 by .id after c

query teamsList(c: cursor ?):
  return teams first 50 by .id after c

query lapsFor(walker: walkers, c: cursor ?):
  return laps where .walker = walker first 200 by .n after c

query lapCount(walker: walkers):
  return lapCounts[walker]

query myPledges(c: cursor ?):
  return pledges where .sponsor = viewer first 100 by .id after c

query walkerPledges(walker: walkers, c: cursor ?):
  return pledges where .walker = walker first 100 by .id after c

query allPledges(c: cursor ?):
  require exists organizers[viewer] else NOT_ORGANIZER
  return pledges first 100 by .id after c

query teamsBoard(c: cursor ?):
  require exists organizers[viewer] else NOT_ORGANIZER
  return teams first 50 by .id after c

mutation registerWalker(name: text 1..80, team: teams):
  require exists teams[team] else NOT_FOUND
  return insert walkers { principal: viewer, name, team }

mutation setMyTeam(team: teams ?):
  w = walkers[principal = viewer] ! else NOT_WALKER
  require team = null or exists teams[team] else NOT_FOUND
  update walkers[w.id] { team }
  return null

mutation createTeam(name: text 1..80):
  require exists organizers[viewer] else NOT_ORGANIZER
  return insert teams { name }

mutation recordLap(walker: walkers):
  require exists organizers[viewer] else NOT_COUNTER
  require exists walkers[walker] else NOT_FOUND
  n = count(laps where .walker = walker) + 1
  return insert laps { walker, n }

mutation pledge(walker: walkers, perLap: int 10..100000, maxTotal: int 1..10000000 ?):
  require exists walkers[walker] else NOT_FOUND
  return insert pledges { sponsor: viewer, walker, perLap, maxTotal }

mutation setCap(pledge: pledges, maxTotal: int 1..10000000 ?):
  p = pledges[pledge] ! else NOT_FOUND
  require p.sponsor = viewer else NOT_SPONSOR
  update pledges[pledge] { maxTotal }
  return null

mutation retractPledge(pledge: pledges):
  p = pledges[pledge] ! else NOT_FOUND
  require p.sponsor = viewer else NOT_SPONSOR
  delete pledges[pledge]
  return null
