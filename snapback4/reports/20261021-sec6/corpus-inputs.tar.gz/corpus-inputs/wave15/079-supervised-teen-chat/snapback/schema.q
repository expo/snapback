use personas alice, bob, morgan, robin, pat, quinn, dana

table staff:
  principal: principal
  name: text 1..60
  role: enum('moderator', 'director')
  trained: bool
  unique principal
  read <- allow
  online only

table memberships:
  principal: principal
  parent: principal
  name: text 1..40
  status: enum('active', 'muted', 'removed') default 'active'
  unique principal
  immutable principal, parent, name
  read <- .principal = viewer or .parent = viewer or exists staff[viewer]
  update <- exists staff[principal = viewer, role = 'moderator', trained = true]
  online only

table supervision:
  room: text 1..20
  moderator: principal
  expiresAt: time
  unique room
  read <- allow
  insert <- .moderator = viewer and exists staff[principal = viewer, role = 'moderator', trained = true]
  update (old, next) <- next.moderator = viewer and exists staff[principal = viewer, role = 'moderator', trained = true]
  delete <- .moderator = viewer
  expire at .expiresAt
  online only

table messages:
  sender: principal
  name: text 1..40
  body: text 1..1000
  at: time default now
  immutable sender, name, body, at
  read <- exists staff[principal = viewer, role = 'moderator', trained = true] or exists memberships[principal = viewer, status = 'active'] or exists memberships[principal = viewer, status = 'muted']
  insert <- .sender = viewer and exists memberships[principal = viewer, status = 'active'] and exists supervision[room = 'commons']
  online only

table flags:
  message: messages
  reporter: principal
  reason: text 3..240
  at: time default now
  read <- exists staff[principal = viewer, role = 'moderator', trained = true]
  insert <- .reporter = viewer and (exists memberships[principal = viewer, status = 'active'] or exists staff[principal = viewer, role = 'moderator', trained = true])
  online only

table actions:
  subject: principal
  parent: principal
  name: text 1..40
  actor: principal
  action: enum('mute', 'remove')
  reason: text 3..240
  at: time default now
  immutable subject, parent, name, actor, action, reason, at
  read <- .subject = viewer or .parent = viewer or exists staff[viewer]
  insert <- .actor = viewer and exists staff[principal = viewer, role = 'moderator', trained = true]
  online only

table shifts:
  moderator: principal
  startsAt: time
  endsAt: time
  note: text 1..120
  read <- exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'director']
  online only

query myMembership():
  return memberships[principal = viewer]
query family():
  return memberships where .parent = viewer first 20 by .id
query roomStatus():
  return supervision[room = 'commons']
query chat():
  require exists memberships[principal = viewer, status = 'active'] or exists memberships[principal = viewer, status = 'muted'] or exists staff[principal = viewer, role = 'moderator', trained = true] else CHAT_PRIVATE
  return messages last 100 by .at
query roster():
  require exists staff[principal = viewer, role = 'moderator', trained = true] else MODERATOR_ONLY
  return memberships first 100 by .id
query flagged():
  require exists staff[principal = viewer, role = 'moderator', trained = true] else MODERATOR_ONLY
  return flags last 50 by .at { id, reason, reporter, at, message: messages[.message] }
query flagContext(flag: flags):
  require exists staff[principal = viewer, role = 'moderator', trained = true] else MODERATOR_ONLY
  f = flags[flag] ! else NOT_FOUND
  m = messages[f.message] ! else NOT_FOUND
  return { flag: f, message: m, before: messages where .at <= m.at last 8 by .at, after: messages where .at > m.at first 8 by .at }
query myActions():
  return actions where .subject = viewer last 50 by .at
query familyActions():
  return actions where .parent = viewer last 50 by .at
query audit():
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  return actions last 100 by .at
query schedule():
  require exists staff[viewer] else STAFF_ONLY
  return shifts first 100 by .startsAt
query moderators():
  return staff where .role = 'moderator' and .trained = true first 20 by .id

mutation supervise():
  require exists staff[principal = viewer, role = 'moderator', trained = true] else MODERATOR_ONLY
  return upsert supervision[room = 'commons'] { room: 'commons', moderator: viewer, expiresAt: now + 20s }
mutation leaveRoom():
  s = supervision[room = 'commons'] ! else ROOM_CLOSED
  require s.moderator = viewer else NOT_SUPERVISOR
  delete supervision[s.id]
  return null
mutation send(body: text 1..1000):
  member = memberships[principal = viewer] ! else NOT_MEMBER
  require member.status = 'active' else CANNOT_SEND
  require exists supervision[room = 'commons'] else ROOM_CLOSED 'A trained moderator must be present.'
  return insert messages { sender: viewer, name: member.name, body }
mutation flagMessage(message: messages, reason: text 3..240):
  m = messages[message] ! else NOT_FOUND
  return insert flags { message: m.id, reporter: viewer, reason }
mutation moderate(member: memberships, action: enum('mute', 'remove'), reason: text 3..240):
  require exists staff[principal = viewer, role = 'moderator', trained = true] else MODERATOR_ONLY
  m = memberships[member] ! else NOT_FOUND
  require m.status != 'removed' else ALREADY_REMOVED
  update memberships[member] { status: 'muted' if action = 'mute' else 'removed' }
  return insert actions { subject: m.principal, parent: m.parent, name: m.name, actor: viewer, action, reason }
mutation addShift(moderator: principal, startsAt: time, endsAt: time, note: text 1..120):
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  require exists staff[principal = moderator, role = 'moderator', trained = true] else NOT_TRAINED
  require endsAt > startsAt and endsAt <= startsAt + 12h else INVALID_SHIFT
  return insert shifts { moderator, startsAt, endsAt, note }
