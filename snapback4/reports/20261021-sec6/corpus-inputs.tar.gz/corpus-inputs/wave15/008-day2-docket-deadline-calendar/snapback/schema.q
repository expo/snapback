-- Docket Deadline Calendar.
-- Personas: alice (attorney), bob (paralegal), carol (managing partner).
-- Attorneys see matters they lead, paralegals matters they support,
-- the partner sees everything. Deadline changes need second-person approval
-- and are logged; a daily job writes escalating reminders.

use identity password
use personas alice, bob, carol

table staff:
  principal: principal
  role: enum('attorney', 'paralegal', 'partner')
  unique principal
  read <- exists staff[principal = viewer] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

table matters:
  title: text 1..100
  clientName: text 1..100 ?
  lead: principal
  support: principal ?
  immutable lead
  read <- .lead = viewer or .support = viewer or exists staff[principal = viewer, role = 'partner']
  insert <- exists staff[principal = viewer]
  update <- deny
  delete <- deny
  online only

table rules:
  kind: enum('motion_served', 'complaint_filed', 'discovery_requested', 'subpoena_received')
  daysOut: int 1..365
  note: text 1..200 ?
  unique kind
  immutable kind
  read <- exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  update <- exists staff[principal = viewer]
  delete <- deny
  online only

table triggers:
  matter: matters
  kind: enum('motion_served', 'complaint_filed', 'discovery_requested', 'subpoena_received')
  occurredAt: time default now
  enteredBy: principal
  immutable matter, kind, occurredAt
  read <- exists matters[.matter, lead = viewer] or exists matters[.matter, support = viewer] or exists staff[principal = viewer, role = 'partner']
  insert <- .enteredBy = viewer
  update <- deny
  delete <- deny
  online only

table deadlines:
  matter: matters
  trigger: triggers
  kind: enum('motion_served', 'complaint_filed', 'discovery_requested', 'subpoena_received')
  dueAt: time
  status: enum('open', 'completed') default 'open'
  priority: enum('normal', 'urgent') default 'normal'
  immutable matter, trigger, kind
  read <- exists matters[.matter, lead = viewer] or exists matters[.matter, support = viewer] or exists staff[principal = viewer, role = 'partner']
  insert <- allow
  update <- allow
  delete <- deny
  online only

table changeRequests:
  matter: matters
  deadline: deadlines
  requester: principal
  newDueAt: time
  reason: text 1..300
  status: enum('pending', 'approved', 'rejected') default 'pending'
  reviewer: principal ?
  decidedAt: time ?
  immutable matter, deadline, requester, newDueAt
  read <- exists matters[.matter, lead = viewer] or exists matters[.matter, support = viewer] or exists staff[principal = viewer, role = 'partner']
  insert <- .requester = viewer
  update <- allow
  delete <- deny
  online only

table audit:
  matter: matters
  deadline: deadlines
  actor: principal
  at: time default now
  action: text 1..60
  detail: text 1..300 ?
  immutable matter, deadline, actor, at, action
  read <- exists matters[.matter, lead = viewer] or exists matters[.matter, support = viewer] or exists staff[principal = viewer, role = 'partner']
  insert <- allow
  update <- deny
  delete <- deny
  online only

table reminders:
  matter: matters
  deadline: deadlines
  level: enum('seven_day', 'three_day', 'one_day', 'overdue')
  sentAt: time default now
  dueAt: time
  message: text 1..200
  unique deadline, level
  immutable matter, deadline, level, dueAt
  read <- exists matters[.matter, lead = viewer] or exists matters[.matter, support = viewer] or exists staff[principal = viewer, role = 'partner']
  insert <- allow
  update <- deny
  delete <- deny
  online only

table priorityChanges:
  matter: matters
  deadline: deadlines
  actor: principal
  at: time default now
  priority: enum('normal', 'urgent')
  reason: text 1..300
  immutable matter, deadline, actor, at, priority, reason
  read <- exists matters[.matter, lead = viewer] or exists matters[.matter, support = viewer] or exists staff[principal = viewer, role = 'partner']
  insert <- .actor = viewer
  update <- deny
  delete <- deny
  online only

query priorityHistory(deadline: deadlines):
  d = deadlines[deadline] ! else NOT_FOUND
  return priorityChanges where .deadline = deadline last 50 by .at

mutation setPriority(deadline: deadlines, priority: enum('normal', 'urgent'), reason: text 1..300):
  d = deadlines[deadline] ! else NOT_FOUND
  require d.status = 'open' else DEADLINE_CLOSED
  require d.priority != priority else NO_CHANGE
  update deadlines[deadline] { priority }
  return insert priorityChanges { matter: d.matter, deadline, actor: viewer, priority, reason }

mutation grantStaff(principal: principal, role: enum('attorney', 'paralegal', 'partner')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal, role }

query myMatters():
  return matters last 50 by .id

query matterTriggers(matter: matters):
  m = matters[matter] ! else NOT_FOUND
  return triggers where .matter = matter last 50 by .occurredAt

query matterDeadlines(matter: matters):
  m = matters[matter] ! else NOT_FOUND
  return deadlines where .matter = matter first 50 by .dueAt

query myUpcoming():
  return deadlines where .dueAt >= now first 50 by .dueAt

query dueThisWeek():
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'partner' else NOT_PARTNER
  return deadlines where .dueAt >= now and .dueAt < now + 7d first 100 by .dueAt

query pendingChanges():
  return changeRequests where .status = 'pending' last 50 by .id

query auditFor(deadline: deadlines):
  d = deadlines[deadline] ! else NOT_FOUND
  return audit where .deadline = deadline last 50 by .at

query myReminders():
  return reminders last 50 by .sentAt

mutation addMatter(title: text 1..100, clientName: text 1..100 ?, lead: principal, support: principal ?):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'attorney' or s.role = 'partner' else NOT_PERMITTED 'Only attorneys and the managing partner create matters.'
  return insert matters { title, clientName, lead, support }

mutation addRule(kind: enum('motion_served', 'complaint_filed', 'discovery_requested', 'subpoena_received'), daysOut: int 1..365, note: text 1..200 ?):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'attorney' or s.role = 'partner' else NOT_PERMITTED 'Only attorneys and the managing partner maintain rules.'
  return insert rules { kind, daysOut, note }

mutation updateRule(kind: enum('motion_served', 'complaint_filed', 'discovery_requested', 'subpoena_received'), daysOut: int 1..365):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'attorney' or s.role = 'partner' else NOT_PERMITTED 'Only attorneys and the managing partner maintain rules.'
  r = rules[kind = kind] ! else NO_RULE
  update rules[r.id] { daysOut }
  return null

mutation recordTrigger(matter: matters, kind: enum('motion_served', 'complaint_filed', 'discovery_requested', 'subpoena_received'), occurredAt: time ?):
  m = matters[matter] ! else NOT_FOUND
  r = rules[kind = kind] ! else NO_RULE 'No deadline rule for this trigger kind yet.'
  at = occurredAt ?? now
  t = insert triggers { matter, kind, occurredAt: at, enteredBy: viewer }
  due = at + r.daysOut * 1d
  d = insert deadlines { matter, kind, trigger: t.id, dueAt: due }
  return { trigger: t.id, deadline: d.id, dueAt: due }

mutation requestChange(deadline: deadlines, newDueAt: time, reason: text 1..300):
  d = deadlines[deadline] ! else NOT_FOUND
  require d.status = 'open' else DEADLINE_CLOSED 'This deadline is already completed.'
  require newDueAt != d.dueAt else NO_CHANGE 'The proposed date is the current date.'
  c = insert changeRequests { matter: d.matter, deadline, requester: viewer, newDueAt, reason }
  insert audit { matter: d.matter, deadline, actor: viewer, action: 'change_requested', detail: reason }
  return { request: c.id }

mutation decideChange(request: changeRequests, approve: bool):
  c = changeRequests[request] ! else NOT_FOUND
  require c.status = 'pending' else ALREADY_DECIDED 'This request was already decided.'
  require c.requester != viewer else SELF_APPROVAL 'A second person must approve deadline changes.'
  if approve:
    update deadlines[c.deadline] { dueAt: c.newDueAt }
    update changeRequests[request] { status: 'approved', reviewer: viewer, decidedAt: now }
    insert audit { matter: c.matter, deadline: c.deadline, actor: viewer, action: 'change_approved' }
  else:
    update changeRequests[request] { status: 'rejected', reviewer: viewer, decidedAt: now }
    insert audit { matter: c.matter, deadline: c.deadline, actor: viewer, action: 'change_rejected' }
  return null

mutation completeDeadline(deadline: deadlines):
  d = deadlines[deadline] ! else NOT_FOUND
  require d.status = 'open' else ALREADY_CLOSED 'This deadline is already completed.'
  update deadlines[deadline] { status: 'completed' }
  insert audit { matter: d.matter, deadline, actor: viewer, action: 'completed' }
  return null

job sendReminders(periodStart: time, periodEnd: time):
  for d in deadlines:
    if d.status = 'open':
      if d.dueAt < periodEnd:
        if not exists reminders[d.id, 'overdue']:
          m = matters[d.matter]
          if m != null:
            insert reminders { matter: d.matter, deadline: d.id, level: 'overdue', dueAt: d.dueAt, message: m.title + ' is overdue — urgent review needed' }
      if d.dueAt >= periodEnd and d.dueAt < periodEnd + 1d:
        if not exists reminders[d.id, 'one_day']:
          m = matters[d.matter]
          if m != null:
            insert reminders { matter: d.matter, deadline: d.id, level: 'one_day', dueAt: d.dueAt, message: m.title + ' due within one day' }
      if d.dueAt >= periodEnd + 1d and d.dueAt < periodEnd + 3d:
        if not exists reminders[d.id, 'three_day']:
          m = matters[d.matter]
          if m != null:
            insert reminders { matter: d.matter, deadline: d.id, level: 'three_day', dueAt: d.dueAt, message: m.title + ' due within three days' }
      if d.dueAt >= periodEnd + 3d and d.dueAt < periodEnd + 7d:
        if not exists reminders[d.id, 'seven_day']:
          m = matters[d.matter]
          if m != null:
            insert reminders { matter: d.matter, deadline: d.id, level: 'seven_day', dueAt: d.dueAt, message: m.title + ' due within seven days' }
schedule dailyReminders every 1d at 09:00: sendReminders
