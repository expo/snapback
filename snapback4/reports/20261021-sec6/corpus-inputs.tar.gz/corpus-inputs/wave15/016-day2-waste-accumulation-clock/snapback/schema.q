use identity password
use personas alice, bob, ehs, inspector

-- Membership is provisioned by the EHS office (or the initial service seat),
-- never by a lab account. Signup alone grants no role.
table people:
  principal: principal
  lab: text 1..60
  role: enum('lab', 'ehs', 'inspector')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or exists people[viewer, role = 'ehs']
  online only

table containers:
  lab: text 1..60
  creator: principal
  contents: text 3..240
  room: text 1..40
  startedAt: time
  deadline: time
  status: enum('filling', 'requested', 'scheduled', 'collected', 'cancelled')
  hazard: enum('general', 'flammable', 'corrosive', 'reactive', 'toxic') default 'general'
  flagged: bool default false
  scheduledAt: time ?
  collectedAt: time ?
  immutable lab, creator, contents, room, startedAt, deadline
  read <- exists people[viewer, lab = .lab] or exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'inspector']
  insert <- .creator = viewer and exists people[viewer, role = 'lab', lab = .lab] and .status = 'filling' and .flagged = false
  update (old, next) <- exists people[viewer, role = 'ehs'] or (exists people[viewer, role = 'lab', lab = old.lab] and next.hazard = old.hazard and next.flagged = old.flagged and next.scheduledAt = old.scheduledAt and next.collectedAt = old.collectedAt and ((old.status = 'filling' and next.status = 'requested') or ((old.status = 'filling' or old.status = 'requested') and next.status = 'cancelled')))
  online only

-- Handling remarks and cancellation reasons. Labs see their own lab's notes;
-- EHS and inspectors see everything. Written by cancelContainer and addNote.
table containerNotes:
  container: containers
  lab: text 1..60
  author: principal
  body: text 3..240
  at: time
  immutable container, lab, author, body, at
  read <- exists people[viewer, lab = .lab] or exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'inspector']
  insert <- .author = viewer and (exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'lab', lab = .lab])
  online only

table pickupEvents:
  container: containers
  lab: text 1..60
  contents: text 3..240
  room: text 1..40
  kind: enum('requested', 'scheduled', 'collected', 'cancelled')
  actor: principal
  at: time
  scheduledAt: time ?
  photo: image <=5000000 ?
  immutable container, lab, contents, room, kind, actor, at, scheduledAt, photo
  read <- exists people[viewer, lab = .lab] or exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'inspector']
  insert <- .actor = viewer and (exists people[viewer, role = 'ehs'] or (exists people[viewer, role = 'lab', lab = .lab] and (.kind = 'requested' or .kind = 'cancelled')))
  online only

query identity():
  return people[viewer]

query openContainers(c: cursor ?):
  p = people[viewer] ! else NO_MEMBERSHIP
  if exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'inspector']:
    return containers where .status in ['filling', 'requested', 'scheduled'] first 50 by .status after c
  return containers where .lab = p.lab and .status in ['filling', 'requested', 'scheduled'] first 50 by .status after c

query pickupHistory(c: cursor ?):
  p = people[viewer] ! else NO_MEMBERSHIP
  if exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'inspector']:
    return pickupEvents last 50 by .id after c
  return pickupEvents where .lab = p.lab last 50 by .id after c

query containerNotesFor(container: containers, c: cursor ?):
  p = people[viewer] ! else NO_MEMBERSHIP
  if exists people[viewer, role = 'ehs'] or exists people[viewer, role = 'inspector']:
    return containerNotes where .container = container last 50 by .id after c
  return containerNotes where .container = container and .lab = p.lab last 50 by .id after c

mutation enrollMember(member: principal, lab: text 1..60, role: enum('lab', 'ehs', 'inspector')):
  require viewer = 'service:ops' or exists people[viewer, role = 'ehs'] else EHS_ONLY
  return insert people { principal: member, lab, role }

mutation startContainer(contents: text 3..240, room: text 1..40, startedAt: time, hazard: enum('general', 'flammable', 'corrosive', 'reactive', 'toxic')):
  p = people[viewer] ! else NO_MEMBERSHIP
  require p.role = 'lab' else LAB_ONLY
  require startedAt <= now and startedAt >= now - 365d else INVALID_START 'Choose a start date within the last year.'
  return insert containers { lab: p.lab, creator: viewer, contents, room, startedAt, deadline: startedAt + 90d, status: 'filling', hazard, flagged: false }

-- Void a container started in error (wrong room, damaged vessel) so no EHS
-- trip is wasted. Labs cancel their own open containers; EHS can cancel any
-- open one. The cancellation stays in the permanent pickup history and the
-- reason is kept as a container note.
mutation cancelContainer(container: containers, reason: text 3..240):
  p = people[viewer] ! else NO_MEMBERSHIP
  require p.role = 'lab' or p.role = 'ehs' else EHS_ONLY
  x = containers[container] ! else NOT_FOUND
  require p.role = 'ehs' or x.lab = p.lab else LAB_ONLY
  require x.status = 'filling' or x.status = 'requested' or x.status = 'scheduled' else BAD_STATUS
  require x.status = 'filling' or x.status = 'requested' or p.role = 'ehs' else EHS_ONLY
  update containers[container] { status: 'cancelled' }
  insert pickupEvents { container, lab: x.lab, contents: x.contents, room: x.room, kind: 'cancelled', actor: viewer, at: now }
  return insert containerNotes { container, lab: x.lab, author: viewer, body: reason, at: now }

mutation addNote(container: containers, body: text 3..240):
  p = people[viewer] ! else NO_MEMBERSHIP
  require p.role = 'lab' or p.role = 'ehs' else EHS_ONLY
  x = containers[container] ! else NOT_FOUND
  require p.role = 'ehs' or x.lab = p.lab else LAB_ONLY
  return insert containerNotes { container, lab: x.lab, author: viewer, body, at: now }

mutation requestPickup(container: containers):
  p = people[viewer] ! else NO_MEMBERSHIP
  require p.role = 'lab' else LAB_ONLY
  x = containers[container] ! else NOT_FOUND
  require x.lab = p.lab else LAB_ONLY
  require x.status = 'filling' else BAD_STATUS
  update containers[container] { status: 'requested' }
  return insert pickupEvents { container, lab: x.lab, contents: x.contents, room: x.room, kind: 'requested', actor: viewer, at: now }

mutation schedulePickup(container: containers, scheduledAt: time):
  p = people[viewer] ! else NO_MEMBERSHIP
  require p.role = 'ehs' else EHS_ONLY
  x = containers[container] ! else NOT_FOUND
  require x.status = 'requested' else BAD_STATUS
  require scheduledAt >= now and scheduledAt <= now + 30d else INVALID_SCHEDULE
  update containers[container] { status: 'scheduled', scheduledAt }
  return insert pickupEvents { container, lab: x.lab, contents: x.contents, room: x.room, kind: 'scheduled', actor: viewer, at: now, scheduledAt }

mutation confirmPickup(container: containers, photo: image <=5000000):
  p = people[viewer] ! else NO_MEMBERSHIP
  require p.role = 'ehs' else EHS_ONLY
  x = containers[container] ! else NOT_FOUND
  require x.status = 'scheduled' else BAD_STATUS
  update containers[container] { status: 'collected', collectedAt: now }
  return insert pickupEvents { container, lab: x.lab, contents: x.contents, room: x.room, kind: 'collected', actor: viewer, at: now, photo }

job flagDeadlines():
  for x in containers:
    if x.status != 'collected' and not x.flagged and x.deadline <= now + 7d:
      update containers[x.id] { flagged: true }
schedule hourlyDeadlineCheck every 1h: flagDeadlines
