use identity
use personas alice, bob, carol

-- Privileged role roster: the publisher's publicists. Seeded via /seed
-- (dev) since the insert rule requires an existing publicist; in production
-- the first publicist is enrolled with grantPublicist through the service seat.
table publicists:
  principal: principal
  unique principal
  read <- (.principal = viewer or exists publicists[viewer]) or viewer = 'service:ops'
  insert <- (exists publicists[viewer]) or viewer = 'service:ops'
  delete <- exists publicists[viewer]
  cap 10
  online only

-- Approved reviewers/booksellers. Only publicists approve.
table reviewers:
  principal: principal
  name: text 1..80
  immutable principal
  unique principal
  read <- (.principal = viewer or exists publicists[viewer]) or viewer = 'service:ops'
  insert <- (exists publicists[viewer]) or viewer = 'service:ops'
  delete <- exists publicists[viewer]
  cap 1000
  online only

-- The catalog is public; only publicists manage it.
table books:
  title: text 1..200
  author: text 1..100
  pubDate: time
  blurb: text 1..2000 ?
  public 'The catalog is public.'
  insert <- exists publicists[viewer]
  update <- exists publicists[viewer]
  delete <- exists publicists[viewer]
  cap 1000
  online only

-- One watermarked, expiring copy per (book, reviewer).
table copies:
  book: books
  reviewer: principal
  watermark: text 1..120
  linkExpiry: time
  openedAt: time ?
  format: enum('ebook', 'audio') default 'ebook'
  immutable book, reviewer
  unique book, reviewer
  read <- (.reviewer = viewer or exists publicists[viewer]) or viewer = 'service:ops'
  insert <- (exists publicists[viewer]) or viewer = 'service:ops'
  update <- .reviewer = viewer or exists publicists[viewer]
  delete <- exists publicists[viewer]
  cap 500 by reviewer
  online only

-- Embargo: a review is visible to its author and publicists immediately,
-- to everyone else only after the publish job flips `published`.
table reviews:
  book: books
  reviewer: principal
  rating: int 1..5
  body: text 1..5000
  published: bool default false
  postedAt: time default now
  immutable book, reviewer
  unique book, reviewer
  read <- .reviewer = viewer or exists publicists[viewer] or .published = true
  insert <- .reviewer = viewer
  update <- .reviewer = viewer
  cap 500 by book
  online only

-- Written only by the reminder job (system principal bypasses rules).
table reminders:
  book: books
  reviewer: principal
  message: text 1..300
  createdAt: time default now
  immutable book, reviewer
  unique book, reviewer
  read <- .reviewer = viewer or exists publicists[viewer]
  insert <- deny
  cap 500 by reviewer
  online only

-- Publicist-picked featured review per book, shown on the catalog as the
-- pull-quote. One per book so the catalog stays curated, not crowded.
table spotlights:
  book: books
  review: reviews
  note: text 1..200
  unique book
  public 'Featured reviews are public.'
  insert <- exists publicists[viewer]
  update <- exists publicists[viewer]
  delete <- exists publicists[viewer]
  cap 1000
  online only

query myRole():
  return { publicist: exists publicists[viewer], reviewer: exists reviewers[viewer] }

query catalog(c: cursor ?):
  return books last 50 by .id after c

query bookDetail(book: books):
  return books[book]

query myCopies(c: cursor ?):
  return copies where .reviewer = viewer last 50 by .id after c

query copyDetail(copy: copies):
  return copies[copy]

query downloadCopy(copy: copies):
  c = copies[copy] ! else NOT_FOUND
  require now <= c.linkExpiry else LINK_EXPIRED 'This link has expired.'
  return { watermark: c.watermark, book: c.book, expiry: c.linkExpiry }

query reviewsFor(book: books, c: cursor ?):
  return reviews where .book = book last 50 by .id after c

query myReviews(c: cursor ?):
  return reviews where .reviewer = viewer last 50 by .id after c

query myReminders(c: cursor ?):
  return reminders where .reviewer = viewer last 50 by .id after c

query dashboard(book: books, c: cursor ?):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may view the dashboard.'
  return copies where .book = book last 50 by .id after c

query reviewerList(c: cursor ?):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may list reviewers.'
  return reviewers last 100 by .id after c

query spotlightFor(book: books):
  return spotlights[book = book]

mutation addBook(title: text 1..200, author: text 1..100, pubDate: time, blurb: text 1..2000 ?):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may add books.'
  return insert books { title, author, pubDate, blurb }

mutation approveReviewer(who: principal, name: text 1..80):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may approve reviewers.'
  insert reviewers { principal: who, name }
  return null

-- Production bootstrap: enrolls the first publicist through the operator seat.
-- Signup grants no role, so without this no production account could act.
mutation grantPublicist(who: principal):
  require viewer = 'service:ops' else NOT_OPERATOR 'Only the operator seat may grant the first publicist.'
  return insert publicists { principal: who }

mutation sendCopy(book: books, reviewer: principal, watermark: text 1..120, daysValid: int 1..90, format: enum('ebook', 'audio')):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may send copies.'
  require exists reviewers[reviewer] else NOT_APPROVED 'Reviewer is not approved.'
  b = books[book] ! else NOT_FOUND
  require b.pubDate > now else TOO_LATE 'Advance copies end at publication: this book is already out.'
  return insert copies { book: b.id, reviewer, watermark, linkExpiry: now + daysValid * 1d, format }

mutation openCopy(copy: copies):
  c = copies[copy] ! else NOT_FOUND
  require c.reviewer = viewer else NOT_YOURS 'This copy belongs to another reviewer.'
  require now <= c.linkExpiry else LINK_EXPIRED 'This link has expired.'
  update copies[copy] { openedAt: now }
  return null

mutation postReview(book: books, rating: int 1..5, body: text 1..5000):
  b = books[book] ! else NOT_FOUND
  require exists copies[book = b.id, reviewer = viewer] else NO_COPY 'You have no advance copy of this book.'
  return upsert reviews[book = b.id, reviewer = viewer] { book: b.id, reviewer: viewer, rating, body }

mutation reissueCopy(copy: copies, daysValid: int 1..90):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may reissue links.'
  c = copies[copy] ! else NOT_FOUND
  update copies[copy] { linkExpiry: now + daysValid * 1d }
  return null

mutation featureReview(review: reviews, note: text 1..200):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may feature reviews.'
  r = reviews[review] ! else NOT_FOUND
  return upsert spotlights[book = r.book] { book: r.book, review: r.id, note }

mutation unfeature(book: books):
  require exists publicists[viewer] else NOT_PUBLICIST 'Only publicists may remove features.'
  delete spotlights[book = book]
  return null

-- Release day: publish every review whose book is out.
job publishReviews():
  for r in reviews:
    b = books[r.book]
    if b != null and b.pubDate <= now and not r.published:
      update reviews[r.id] { published: true }

-- A week after release, nudge reviewers who never posted (once each).
job remindMissing():
  for c in copies:
    b = books[c.book]
    if b != null and b.pubDate + 7d <= now:
      if not exists reviews[c.book, c.reviewer]:
        if not exists reminders[c.book, c.reviewer]:
          insert reminders { book: c.book, reviewer: c.reviewer, message: 'Please post your review: the embargo has lifted and readers are waiting.' }

schedule dailyPublish every 1d at 08:00: publishReviews
schedule dailyRemind every 1d at 09:00: remindMissing
