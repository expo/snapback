-- Wildlife Crossing Reports backend. Personas: alice (reporter/driver),
-- bob (biologist, privileged reviewer), carol (state DOT official).
use personas alice, bob, carol

-- Role roster: one row per privileged user. Seeded via fixtures;
-- no app operation writes it.
table staff:
  principal: principal
  role: enum('biologist', 'dot')
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table reports:
  reporter: principal
  speciesGuess: text 1..60
  confirmedSpecies: text 1..60 ?
  sensitive: bool default false
  kind: enum('roadkill', 'live-crossing')
  status: enum('submitted', 'confirmed', 'merged', 'needs-review') default 'submitted'
  segment: text 1..40
  lat: int -90000000..90000000
  lng: int -180000000..180000000
  observedAt: time
  photoUrl: text <=500 format url ?
  notes: text <=500 ?
  duplicateOf: reports ?
  immutable reporter, observedAt
  read <- .reporter = viewer or exists staff[viewer]
  insert <- .reporter = viewer
  update <- exists staff[principal = viewer, role = 'biologist'] or exists staff[principal = viewer, role = 'dot']
  delete <- deny
  cap 1000 by reporter
  online only

-- Public hotspot clusters by road segment and UTC month. Segment-level counts
-- never expose exact coordinates, so this aggregate is public even for
-- sensitive species.
view hotspots: count reports by .segment, month(.observedAt)
  read <- allow
  online only

-- A reporter's own submissions, newest first.
query myReports(c: cursor ?):
  return reports where .reporter = viewer last 50 by .observedAt after c

-- Full detail. Hidden rows read as NOT_FOUND before the require runs.
query reportDetail(id: reports):
  r = reports[id] ! else NOT_FOUND
  require r.reporter = viewer or exists staff[viewer] else NOT_ALLOWED 'Only the reporter or staff may read this report.'
  return r

-- Biologist/DOT work queue: everything awaiting a decision.
query reviewQueue(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Only staff may read the review queue.'
  return reports where .status = 'submitted' or .status = 'needs-review' first 50 by .observedAt after c

-- DOT cluster drill-down: every report on one road segment.
query segmentReports(segment: text 1..40, c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Only staff may read reports by segment.'
  return reports where .segment = segment first 50 by .observedAt after c

-- Public map: hotspot counts for one UTC month (month 681 is 2026-10).
-- A null month means the current month, so callers never hard-code a key.
-- No coordinates, no species detail.
query publicHotspots(month: int ?, c: cursor ?):
  m = month ?? month(now)
  return hotspots where .month = m first 100 by .segment after c

-- A driver/volunteer files a report. Coordinates are integer microdegrees.
mutation submitReport(speciesGuess: text 1..60, kind: enum('roadkill', 'live-crossing'), segment: text 1..40, lat: int -90000000..90000000, lng: int -180000000..180000000, observedAt: time, photoUrl: text <=500 format url ?, notes: text <=500 ?):
  return insert reports { reporter: viewer, speciesGuess, kind, segment, lat, lng, observedAt, photoUrl, notes }

-- Biologist confirms the species from the photo; flags sensitive species whose
-- exact location stays out of detailed non-staff views.
mutation confirmReport(id: reports, confirmedSpecies: text 1..60, sensitive: bool):
  require exists staff[principal = viewer, role = 'biologist'] else NOT_BIOLOGIST 'Only the biologist may confirm reports.'
  r = reports[id] ! else NOT_FOUND
  require r.status = 'submitted' or r.status = 'needs-review' else BAD_STATUS 'Only submitted reports can be confirmed.'
  update reports[id] { confirmedSpecies, sensitive, status: 'confirmed' }
  return null

-- Biologist merges a duplicate into the surviving report.
mutation mergeReport(id: reports, intoId: reports):
  require exists staff[principal = viewer, role = 'biologist'] else NOT_BIOLOGIST 'Only the biologist may merge reports.'
  r = reports[id] ! else NOT_FOUND
  keep = reports[intoId] ! else NOT_FOUND
  require id != intoId else BAD_MERGE 'A report cannot merge into itself.'
  update reports[id] { status: 'merged', duplicateOf: keep }
  return null

-- DOT office asks the biologist to take a closer look.
mutation requestReview(id: reports, notes: text <=500 ?):
  require exists staff[principal = viewer, role = 'dot'] else NOT_DOT 'Only the transportation office may request review.'
  r = reports[id] ! else NOT_FOUND
  update reports[id] { status: 'needs-review', notes: notes ?? r.notes }
  return null
