use personas alice, bob, mediator, outsider
use identity password

table members:
  principal: principal
  role: enum('parent', 'mediator')
  unique principal
  read <- exists members[viewer] or viewer = 'service:ops'
  insert <- (exists members[principal = viewer, role = 'parent'] and .role = 'mediator') or viewer = 'service:ops'
  online only

table household:
  name: text 1..80
  active: bool default false
  ordinal: int 0.. default 0
  read <- exists members[viewer] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- exists members[principal = viewer, role = 'parent']
  online only

table items:
  title: text 1..80
  detail: text <=200
  category: enum('general', 'medicine', 'school', 'sports') default 'general'
  missingStreak: int 0.. default 0
  read <- exists members[viewer]
  insert <- exists members[principal = viewer, role = 'parent']
  update <- exists members[principal = viewer, role = 'parent']
  cap 40
  online only

table handoffs:
  sender: principal
  recipient: principal
  ordinal: int 1..
  status: enum('packing', 'sent', 'complete', 'cancelled') default 'packing'
  at: time default now
  immutable sender, recipient, ordinal, at
  read <- exists members[viewer]
  insert <- .sender = viewer and exists members[principal = viewer, role = 'parent']
  update <- (.sender = viewer or .recipient = viewer) and exists members[principal = viewer, role = 'parent']
  online only

table entries:
  handoff: handoffs
  item: items
  title: text 1..80
  packed: bool default false
  confirmed: bool default false
  arrived: bool default false
  damaged: bool default false
  photo: image <=4000000 ?
  unique handoff, item
  immutable handoff, item, title
  read <- exists members[viewer]
  insert <- exists handoffs[.handoff, sender = viewer, status = 'packing']
  update <- exists handoffs[.handoff, sender = viewer, status = 'packing'] or exists handoffs[.handoff, recipient = viewer, status = 'sent']
  online only

table reports:
  entry: entries
  note: text 1..500
  resolved: bool default false
  at: time default now
  immutable entry, at
  read <- exists members[viewer]
  insert <- exists members[principal = viewer, role = 'parent']
  update <- exists members[principal = viewer, role = 'parent']
  online only

table notes:
  owner: principal
  body: text 1..1000
  at: time default now
  immutable owner, at
  read <- .owner = viewer
  insert <- .owner = viewer and exists members[principal = viewer, role = 'parent']
  online only

query family():
  require exists members[viewer] else NOT_MEMBER
  return household first 1 by .id
query roster():
  require exists members[viewer] else NOT_MEMBER
  return members first 10 by .id
query checklist():
  require exists members[viewer] else NOT_MEMBER
  return items first 40 by .id
query handoffLog():
  require exists members[viewer] else NOT_MEMBER
  return handoffs last 50 by .ordinal
query handoffItems(handoff: handoffs):
  h = handoffs[handoff] ! else NOT_FOUND
  return entries where .handoff = handoff first 40 by .id
query myNotes():
  return notes where .owner = viewer last 50 by .at
query openReports():
  require exists members[viewer] else NOT_MEMBER
  return reports where .resolved = false first 40 by .at

mutation addItem(title: text 1..80, detail: text <=200, category: enum('general', 'medicine', 'school', 'sports') ?):
  require exists members[principal = viewer, role = 'parent'] else PARENT_ONLY
  h = household['home'] ! else NOT_FOUND
  require not h.active else HANDOFF_OPEN
  categoryValue = category ?? 'general'
  return insert items { title, detail, category: categoryValue }
mutation inviteMediator(mediator: principal):
  require exists members[principal = viewer, role = 'parent'] else PARENT_ONLY
  insert members { principal: mediator, role: 'mediator' } if absent
  return null
mutation provisionHousehold(name: text 1..80):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert household { id: 'home', name }
mutation provisionMember(candidate: principal, candidateRole: enum('parent', 'mediator')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert members { principal: candidate, role: candidateRole }
mutation startHandoff(recipient: principal):
  require exists members[principal = viewer, role = 'parent'] else PARENT_ONLY
  require recipient != viewer and exists members[principal = recipient, role = 'parent'] else INVALID_RECIPIENT
  home = household['home'] ! else NOT_FOUND
  require not home.active else HANDOFF_OPEN
  list = items first 40 by .id
  require count(list) > 0 else EMPTY_CHECKLIST
  h = insert handoffs { sender: viewer, recipient, ordinal: home.ordinal + 1 }
  update household['home'] { active: true, ordinal: home.ordinal + 1 }
  for i in list:
    insert entries { handoff: h.id, item: i.id, title: i.title }
  return h
mutation pack(entry: entries, packed: bool):
  e = entries[entry] ! else NOT_FOUND
  h = handoffs[e.handoff] ! else NOT_FOUND
  require h.sender = viewer else SENDER_ONLY
  require h.status = 'packing' else NOT_PACKING
  update entries[entry] { packed }
  return null
mutation sendHandoff(handoff: handoffs):
  h = handoffs[handoff] ! else NOT_FOUND
  require h.sender = viewer else SENDER_ONLY
  require h.status = 'packing' else NOT_PACKING
  update handoffs[handoff] { status: 'sent' }
  return null
mutation receive(entry: entries, arrived: bool, damaged: bool, photo: image <=4000000 ?):
  e = entries[entry] ! else NOT_FOUND
  h = handoffs[e.handoff] ! else NOT_FOUND
  require h.recipient = viewer else RECIPIENT_ONLY
  require h.status = 'sent' else NOT_SENT
  require not e.confirmed else ALREADY_CONFIRMED
  require not damaged or (arrived and photo != null) else DAMAGE_PHOTO_REQUIRED
  update entries[entry] { confirmed: true, arrived, damaged, photo }
  return null
mutation finishHandoff(handoff: handoffs):
  h = handoffs[handoff] ! else NOT_FOUND
  require h.recipient = viewer else RECIPIENT_ONLY
  require h.status = 'sent' else NOT_SENT
  list = entries where .handoff = handoff first 40 by .id
  for e in list:
    require e.confirmed else UNCONFIRMED_ITEMS
    i = items[e.item] ! else NOT_FOUND
    update items[e.item] { missingStreak: 0 if e.arrived else i.missingStreak + 1 }
  update handoffs[handoff] { status: 'complete' }
  update household['home'] { active: false }
  return null
mutation saveNote(body: text 1..1000):
  return insert notes { owner: viewer, body }
mutation cancelHandoff(handoff: handoffs):
  h = handoffs[handoff] ! else NOT_FOUND
  require h.sender = viewer else SENDER_ONLY
  require h.status = 'packing' else NOT_PACKING
  update handoffs[handoff] { status: 'cancelled' }
  update household['home'] { active: false }
  return null
mutation reportIssue(entry: entries, note: text 1..500):
  require exists members[principal = viewer, role = 'parent'] else PARENT_ONLY
  e = entries[entry] ! else NOT_FOUND
  require e.confirmed else UNCONFIRMED_ENTRY
  return insert reports { entry: e.id, note }
mutation resolveReport(report: reports, resolved: bool):
  require exists members[principal = viewer, role = 'parent'] else PARENT_ONLY
  r = reports[report] ! else NOT_FOUND
  update reports[report] { resolved }
  return null
