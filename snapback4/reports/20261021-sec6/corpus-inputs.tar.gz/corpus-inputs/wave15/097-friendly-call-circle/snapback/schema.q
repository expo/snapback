-- Friendly Call Circle.
-- Each isolated senior gets a weekly call from an assigned volunteer, on the
-- day and time the senior chooses. The volunteer logs a short note per call
-- plus whether the senior was reached. Three missed calls in a row flags the
-- senior for the coordinator, who can request a wellness check from the
-- senior's designated contact. Seniors may pause or stop calls (via their
-- volunteer or the coordinator acting on their request).
-- Personas: alice and bob are volunteers; carol is the coordinator.

use identity
use personas alice, bob, carol

-- The coordinator roster: one row per coordinator. The first row is seeded
-- via fixtures; coordinators can grant further coordinators.
table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer or exists coordinators[viewer]
  insert <- exists coordinators[viewer]
  delete <- exists coordinators[viewer]
  online only

-- One row per enrolled senior.
table seniors:
  name: text 1..80
  volunteer: principal
  callDay: enum('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')
  callTime: text 1..20
  status: enum('active', 'paused', 'stopped') default 'active'
  contactName: text 1..80
  contactPhone: text 1..30
  missed: int 0..1000 default 0
  read <- .volunteer = viewer or exists coordinators[viewer]
  insert <- exists coordinators[viewer]
  update <- exists coordinators[viewer] or .volunteer = viewer
  delete <- exists coordinators[viewer]
  cap 500
  sync

-- One row per logged weekly call. The volunteer is copied from the senior so
-- the coordinator-or-volunteer audience syncs as a union (guide sharing).
table calls:
  senior: seniors on delete cascade
  volunteer: principal
  note: text 1..280
  reached: bool
  at: time default now
  immutable senior, volunteer
  read <- .volunteer = viewer or exists coordinators[viewer]
  insert <- .volunteer = .senior.volunteer and (.volunteer = viewer or exists coordinators[viewer])
  cap 1000 by senior
  sync

-- Wellness checks the coordinator requests from a senior's contact.
table checks:
  senior: seniors on delete cascade
  volunteer: principal
  requestedBy: principal
  note: text 1..280
  done: bool default false
  at: time default now
  immutable senior, volunteer, requestedBy
  read <- .volunteer = viewer or exists coordinators[viewer]
  insert <- .volunteer = .senior.volunteer and .requestedBy = viewer and exists coordinators[viewer]
  update <- exists coordinators[viewer]
  cap 200 by senior
  sync

query canCoordinate():
  return exists coordinators[viewer]

-- Volunteers see their own seniors; the coordinator sees everyone.
query mySeniors(c: cursor ?):
  if exists coordinators[viewer]:
    return seniors last 50 by .id after c
  return seniors where .volunteer = viewer last 50 by .id after c

-- Seniors with three missed calls in a row: the coordinator's alert list,
-- or a volunteer's own flagged seniors.
query needsAttention(c: cursor ?):
  if exists coordinators[viewer]:
    return seniors where .missed >= 3 last 50 by .id after c
  return seniors where .volunteer = viewer and .missed >= 3 last 50 by .id after c

query seniorCalls(senior: seniors, c: cursor ?):
  s = seniors[senior] ! else NOT_FOUND
  require s.volunteer = viewer or exists coordinators[viewer] else NOT_ASSIGNED
  return calls where .senior = senior last 50 by .at, .id after c

query seniorChecks(senior: seniors, c: cursor ?):
  s = seniors[senior] ! else NOT_FOUND
  require s.volunteer = viewer or exists coordinators[viewer] else NOT_ASSIGNED
  return checks where .senior = senior last 50 by .id after c

-- Coordinator summary of all recent calls.
query allCalls(c: cursor ?):
  require exists coordinators[viewer] else NOT_COORDINATOR
  return calls last 50 by .at, .id after c

mutation grantCoordinator(who: principal):
  require exists coordinators[viewer] else NOT_COORDINATOR
  return insert coordinators { principal: who } if absent

-- Only the coordinator enrolls seniors and assigns volunteers.
mutation addSenior(name: text 1..80, volunteer: principal, callDay: enum('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'), callTime: text 1..20, contactName: text 1..80, contactPhone: text 1..30):
  require exists coordinators[viewer] else NOT_COORDINATOR
  return insert seniors { name, volunteer, callDay, callTime, contactName, contactPhone }

mutation assignVolunteer(senior: seniors, volunteer: principal):
  require exists coordinators[viewer] else NOT_COORDINATOR
  s = seniors[senior] ! else NOT_FOUND
  update seniors[senior] { volunteer }
  return null

-- The senior's day/time; set by the volunteer or coordinator on request.
mutation setSchedule(senior: seniors, callDay: enum('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'), callTime: text 1..20):
  s = seniors[senior] ! else NOT_FOUND
  require s.volunteer = viewer or exists coordinators[viewer] else NOT_ASSIGNED
  update seniors[senior] { callDay, callTime }
  return null

-- Pause or stop calls; the volunteer or coordinator records the senior's wish.
mutation setStatus(senior: seniors, status: enum('active', 'paused', 'stopped')):
  s = seniors[senior] ! else NOT_FOUND
  require s.volunteer = viewer or exists coordinators[viewer] else NOT_ASSIGNED
  update seniors[senior] { status }
  return null

-- The volunteer logs each weekly call; misses accumulate a streak that
-- needsAttention reads (3 in a row flags the senior).
mutation logCall(senior: seniors, note: text 1..280, reached: bool):
  s = seniors[senior] ! else NOT_FOUND
  require s.volunteer = viewer else NOT_ASSIGNED
  update seniors[senior] { missed: 0 if reached else s.missed + 1 }
  return insert calls { senior, volunteer: viewer, note, reached }

mutation requestCheck(senior: seniors, note: text 1..280):
  require exists coordinators[viewer] else NOT_COORDINATOR
  s = seniors[senior] ! else NOT_FOUND
  return insert checks { senior, volunteer: s.volunteer, requestedBy: viewer, note }

mutation resolveCheck(check: checks):
  require exists coordinators[viewer] else NOT_COORDINATOR
  update checks[check] { done: true }
  return null
