use personas alice, bob, carol, dana, visitor
use identity

table staff:
  principal: principal
  role: enum('curator', 'director')
  unique principal
  read <- allow
  insert <- viewer = 'service:ops'
  online only

table labels:
  title: text 1..100
  body: text 1..1500
  opensAt: time
  status: enum('draft', 'approved') default 'draft'
  accessibilityStatus: enum('unchecked', 'reviewed') default 'unchecked'
  createdAt: time default now
  immutable opensAt, createdAt
  read <- exists staff[viewer] or exists assignments[.id, viewer]
  insert <- exists staff[principal = viewer, role = 'curator'] and .status = 'draft'
  update (old, next) <- (exists staff[principal = viewer, role = 'curator'] and old.status = 'draft') or exists staff[principal = viewer, role = 'director'] or (exists assignments[old.id, viewer] and old.status = 'draft' and next.status = old.status and next.title = old.title and next.body = old.body)
  online only

table assignments:
  label: labels
  principal: principal
  unique label, principal
  immutable label, principal
  read <- .principal = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'curator']
  online only

table feedback:
  label: labels
  author: principal
  kind: enum('suggestion', 'comment', 'accessibility')
  body: text 1..1500
  at: time default now
  immutable label, author, kind, body, at
  read <- exists staff[viewer] or (.author = viewer and exists assignments[.label, viewer])
  insert <- .author = viewer and exists assignments[.label, viewer] and .label.status = 'draft'
  online only

table amendments:
  label: labels
  body: text 1..1500
  accepted: bool default false
  at: time default now
  immutable label, body, at
  read <- exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'curator'] and .label.status = 'approved' and .accepted = false
  update <- exists staff[principal = viewer, role = 'director']
  online only

table publications:
  label: labels
  title: text 1..100
  body: text 1..1500
  opensAt: time
  unique label
  immutable label, opensAt
  public 'Only approved text copied by the scheduled publisher is public.'
  update <- exists staff[principal = viewer, role = 'director']
  online only

query workspace():
  return labels first 100 by .createdAt
query reviews(label: labels):
  return feedback where .label = label first 100 by .at
query assigned(label: labels):
  return assignments where .label = label first 100 by .id
query changes():
  return amendments first 100 by .at
query companion():
  return publications first 100 by .opensAt

mutation createLabel(title: text 1..100, body: text 1..1500, opensAt: time):
  require exists staff[principal = viewer, role = 'curator'] else CURATOR_ONLY
  return insert labels { title, body, opensAt }
mutation editDraft(label: labels, body: text 1..1500):
  require exists staff[principal = viewer, role = 'curator'] else CURATOR_ONLY
  l = labels[label] ! else NOT_FOUND
  require l.status = 'draft' else LABEL_LOCKED
  update labels[label] { body }
mutation assignReviewer(label: labels, principal: principal):
  require exists staff[principal = viewer, role = 'curator'] else CURATOR_ONLY
  l = labels[label] ! else NOT_FOUND
  require l.status = 'draft' else LABEL_LOCKED
  return insert assignments { label, principal } if absent
mutation addFeedback(label: labels, kind: enum('suggestion', 'comment', 'accessibility'), body: text 1..1500):
  l = labels[label] ! else NOT_FOUND
  require l.status = 'draft' else LABEL_LOCKED
  return insert feedback { label, author: viewer, kind, body }
mutation approveLabel(label: labels):
  require exists staff[principal = viewer, role = 'curator'] else CURATOR_ONLY
  l = labels[label] ! else NOT_FOUND
  require l.status = 'draft' else LABEL_LOCKED
  update labels[label] { status: 'approved' }
mutation requestChange(label: labels, body: text 1..1500):
  require exists staff[principal = viewer, role = 'curator'] else CURATOR_ONLY
  l = labels[label] ! else NOT_FOUND
  require l.status = 'approved' else NOT_APPROVED
  return insert amendments { label, body }
mutation approveChange(amendment: amendments):
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  a = amendments[amendment] ! else NOT_FOUND
  require not a.accepted else ALREADY_ACCEPTED
  update labels[a.label] { body: a.body }
  update amendments[amendment] { accepted: true }
  if exists publications[label = a.label]:
    update publications[label = a.label] { body: a.body }

job publishLabels():
  for l in labels:
    if l.status = 'approved' and l.opensAt <= now:
      p = publications[label = l.id]
      if p = null:
        insert publications { label: l.id, title: l.title, body: l.body, opensAt: l.opensAt }
schedule opening every 1m: publishLabels

mutation provisionStaff(principal: principal, role: enum('curator', 'director')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert staff { principal, role }
query myRole():
  return staff[viewer]

table accessibilityChecks:
  label: labels
  author: principal
  notes: text 1..1500
  at: time default now
  immutable label, author, notes, at
  read <- exists staff[viewer] or (.author = viewer and exists assignments[.label, viewer])
  insert <- .author = viewer and .label.status = 'draft' and (exists assignments[.label, viewer] or exists staff[principal = viewer, role = 'curator'])
  online only

query accessibilityHistory(label: labels):
  return accessibilityChecks where .label = label first 100 by .at
mutation recordAccessibility(label: labels, notes: text 1..1500):
  l = labels[label] ! else NOT_FOUND
  require l.status = 'draft' else LABEL_LOCKED
  require exists assignments[label, viewer] or exists staff[principal = viewer, role = 'curator'] else REVIEWER_ONLY
  c = insert accessibilityChecks { label, author: viewer, notes }
  update labels[label] { accessibilityStatus: 'reviewed' }
  return c
