use personas alice, bob, tess, theo, olivia
use identity

table staff:
  principal: principal
  role: enum('tester', 'officer')
  certificateUntil: time
  unique principal
  read <- .principal = viewer or exists staff[principal = viewer, role = 'officer'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table devices:
  owner: principal
  assignedTester: principal
  address: text 5..160
  serial: text 2..40
  neighborhood: enum('Northbank', 'Old Town', 'Riverside', 'Harborview')
  assembly: enum('RPZ', 'DCVA', 'PVB') default 'RPZ'
  dueAt: time
  overdue: bool default false
  compliant: bool default false
  unique serial
  immutable owner, serial, neighborhood
  read <- .owner = viewer or .assignedTester = viewer or exists staff[principal = viewer, role = 'officer']
  insert <- exists staff[principal = viewer, role = 'officer']
  update <- exists staff[principal = viewer, role = 'officer']
  online only

table reports:
  device: devices
  owner: principal
  tester: principal
  testedAt: time
  submittedAt: time default now
  result: enum('pass', 'fail')
  checkPsi: int 0..150
  reliefPsi: int 0..150
  notes: text <=1000
  gaugePhoto: image <=5000000 ?
  status: enum('pending', 'approved', 'rejected') default 'pending'
  decisionNote: text <=500 default ''
  immutable device, owner, tester, testedAt, submittedAt, result, checkPsi, reliefPsi, notes, gaugePhoto
  read <- .owner = viewer or .tester = viewer or exists staff[principal = viewer, role = 'officer']
  insert <- .tester = viewer and .status = 'pending' and exists staff[principal = viewer, role = 'tester'] and exists devices[.device, owner = .owner, assignedTester = viewer]
  update <- exists staff[principal = viewer, role = 'officer']
  online only

table followups:
  device: devices
  owner: principal
  tester: principal
  dueAt: time
  note: text <=500
  done: bool default false
  read <- .owner = viewer or .tester = viewer or exists staff[principal = viewer, role = 'officer']
  insert <- exists staff[principal = viewer, role = 'officer']
  update <- exists staff[principal = viewer, role = 'officer']
  online only

table notices:
  device: devices
  owner: principal
  dueAt: time
  createdAt: time default now
  unique device, dueAt
  read <- .owner = viewer or exists staff[principal = viewer, role = 'officer']
  online only

table neighborhoods:
  name: enum('Northbank', 'Old Town', 'Riverside', 'Harborview')
  unique name
  public 'Only neighborhood names and anonymous aggregate counts are published.'
  insert <- viewer = 'service:ops' or exists staff[principal = viewer, role = 'officer']
  online only

view deviceTotals: count devices by .neighborhood
  public 'Anonymous device count per neighborhood.'
  online only
view compliantTotals: count devices where .compliant = true by .neighborhood
  public 'Anonymous compliant count per neighborhood.'
  online only

query myRole():
  return staff[principal = viewer]
query listDevices(c: cursor ?):
  if exists staff[principal = viewer, role = 'officer']:
    return devices first 100 by .id after c
  if exists staff[principal = viewer, role = 'tester']:
    return devices where .assignedTester = viewer first 100 by .id after c
  return devices where .owner = viewer first 100 by .id after c
query listReports(c: cursor ?):
  if exists staff[principal = viewer, role = 'officer']:
    return reports last 100 by .submittedAt after c
  if exists staff[principal = viewer, role = 'tester']:
    return reports where .tester = viewer last 100 by .submittedAt after c
  return reports where .owner = viewer last 100 by .submittedAt after c
query listFollowups(c: cursor ?):
  if exists staff[principal = viewer, role = 'officer']:
    return followups last 100 by .dueAt after c
  if exists staff[principal = viewer, role = 'tester']:
    return followups where .tester = viewer last 100 by .dueAt after c
  return followups where .owner = viewer last 100 by .dueAt after c
query myNotices(c: cursor ?):
  return notices where .owner = viewer last 100 by .createdAt after c
query compliance():
  return neighborhoods first 10 by .name { name, total: deviceTotals[.name], compliant: compliantTotals[.name] }

mutation provisionStaff(principal: principal, role: enum('tester', 'officer'), certificateUntil: time):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal, role, certificateUntil }

mutation addNeighborhood(name: enum('Northbank', 'Old Town', 'Riverside', 'Harborview')):
  require viewer = 'service:ops' or exists staff[principal = viewer, role = 'officer'] else OFFICER_ONLY
  return insert neighborhoods { name }

mutation registerDevice(owner: principal, assignedTester: principal, address: text 5..160, serial: text 2..40, neighborhood: enum('Northbank', 'Old Town', 'Riverside', 'Harborview'), assembly: enum('RPZ', 'DCVA', 'PVB'), dueAt: time):
  require exists staff[principal = viewer, role = 'officer'] else OFFICER_ONLY
  require exists staff[principal = assignedTester, role = 'tester'] else NOT_CERTIFIED
  return insert devices { owner, assignedTester, address, serial, neighborhood, assembly, dueAt }

mutation submitReport(deviceId: devices, testedAt: time, result: enum('pass', 'fail'), checkPsi: int 0..150, reliefPsi: int 0..150, notes: text <=1000, gaugePhoto: image <=5000000):
  s = staff[principal = viewer] ! else TESTER_ONLY
  require s.role = 'tester' else TESTER_ONLY
  require s.certificateUntil >= now else CERTIFICATE_EXPIRED
  d = devices[deviceId] ! else NOT_FOUND
  require d.assignedTester = viewer else NOT_ASSIGNED
  require testedAt <= now and testedAt >= now - 30d else TEST_DATE_INVALID
  require result != 'pass' or (checkPsi >= 5 and reliefPsi >= 2) else PASS_READINGS_INVALID
  return insert reports { device: deviceId, owner: d.owner, tester: viewer, testedAt, result, checkPsi, reliefPsi, notes, gaugePhoto }

mutation reviewReport(report: reports, decision: enum('approved', 'rejected'), decisionNote: text 1..500):
  require exists staff[principal = viewer, role = 'officer'] else OFFICER_ONLY
  r = reports[report] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_REVIEWED
  update reports[report] { status: decision, decisionNote }
  if decision = 'approved' and r.result = 'pass':
    d = devices[r.device] ! else NOT_FOUND
    require r.testedAt + 365d > d.dueAt else STALE_REPORT
    update devices[r.device] { dueAt: r.testedAt + 365d, overdue: false, compliant: true }
  if decision = 'approved' and r.result = 'fail':
    update devices[r.device] { compliant: false }
  return reports[report]

mutation scheduleFollowup(deviceId: devices, dueAt: time, note: text <=500):
  require exists staff[principal = viewer, role = 'officer'] else OFFICER_ONLY
  d = devices[deviceId] ! else NOT_FOUND
  require dueAt > now else DUE_DATE_INVALID
  return insert followups { device: deviceId, owner: d.owner, tester: d.assignedTester, dueAt, note }

mutation resolveFollowup(followup: followups):
  require exists staff[principal = viewer, role = 'officer'] else OFFICER_ONLY
  f = followups[followup] ! else NOT_FOUND
  update followups[followup] { done: true }
  return followups[followup]

job annualSweep():
  for d in devices:
    if d.dueAt <= now + 30d:
      if not exists notices[d.id, d.dueAt]:
        insert notices { device: d.id, owner: d.owner, dueAt: d.dueAt }
    if d.dueAt < now:
      update devices[d.id] { compliant: false, overdue: d.dueAt <= now - 30d }
schedule dailySweep every 1d at 06:00: annualSweep
