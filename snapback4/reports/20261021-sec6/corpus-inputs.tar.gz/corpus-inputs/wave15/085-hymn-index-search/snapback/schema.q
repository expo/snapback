use personas alice, bob, congregation
use identity guests

table staff:
  principal: principal
  role: enum('director', 'leader')
  unique principal
  read <- .principal = viewer
  online only

table hymns:
  title: text 1..120
  tune: text 1..80
  meter: text 1..32
  musicalKey: text 1..12
  scripture: text <=160
  topics: text <=200
  search title, tune, meter, musicalKey, scripture, topics
  public 'The hymn index is available to the congregation.'
  insert <- exists staff[viewer, role = 'director']
  update <- exists staff[viewer, role = 'director']
  online only

table services:
  title: text 1..120
  date: time
  immutable date
  theme: text <=160
  published: bool default false
  read <- .published = true or exists staff[viewer]
  insert <- exists staff[viewer] and .published = false
  update <- exists staff[viewer, role = 'director']
  online only

table entries:
  service: services on delete cascade
  hymn: hymns
  serviceDate: time
  position: int 0..40
  unique service, position
  unique service, hymn
  immutable service, hymn, serviceDate
  cap 40 by service
  read <- exists services[.service, published = true] or exists staff[viewer]
  insert <- exists staff[viewer] and exists services[.service, published = false, date = .serviceDate]
  update <- exists staff[viewer] and exists services[.service, published = false]
  delete <- exists staff[viewer] and exists services[.service, published = false]
  online only

query myRole():
  return staff[principal = viewer]
query searchHymns(q: text <=100, meter: text <=32, musicalKey: text <=12, c: cursor ?):
  return hymns matching q where (meter = '' or .meter = meter) and (musicalKey = '' or .musicalKey = musicalKey) first 30 by .title after c
query serviceList(c: cursor ?):
  if exists staff[viewer]:
    return services last 30 by .date after c
  return services where .published = true last 30 by .date after c
query currentWeek():
  start = day(now) * 1d - ((day(now) + 3) % 7) * 1d
  return services where .published = true and .date >= start and .date < start + 7d first 10 by .date
query serviceEntries(service: services):
  s = services[service] ! else SERVICE_PRIVATE
  return entries where .service = service first 40 by .position { id, position, hymn: hymns[.hymn] }
query hymnUsage(hymn: hymns):
  require exists staff[viewer, role = 'director'] else DIRECTOR_ONLY
  return { total: count(entries where .hymn = hymn and .service.published = true and .serviceDate <= now), recent: count(entries where .hymn = hymn and .service.published = true and .serviceDate <= now and .serviceDate >= now - 30d) }

mutation addHymn(title: text 1..120, tune: text 1..80, meter: text 1..32, musicalKey: text 1..12, scripture: text <=160, topics: text <=200):
  require exists staff[viewer, role = 'director'] else DIRECTOR_ONLY
  return insert hymns { title, tune, meter, musicalKey, scripture, topics }
mutation updateHymn(hymn: hymns, title: text 1..120, tune: text 1..80, meter: text 1..32, musicalKey: text 1..12, scripture: text <=160, topics: text <=200):
  require exists staff[viewer, role = 'director'] else DIRECTOR_ONLY
  update hymns[hymn] { title, tune, meter, musicalKey, scripture, topics }
mutation createService(title: text 1..120, date: time, theme: text <=160):
  require exists staff[viewer] else STAFF_ONLY
  return insert services { title, date, theme }
mutation publishService(service: services, published: bool):
  require exists staff[viewer, role = 'director'] else DIRECTOR_ONLY
  update services[service] { published }
mutation addEntry(service: services, hymn: hymns, position: int 1..40):
  require exists staff[viewer] else STAFF_ONLY
  require exists hymns[hymn] else HYMN_NOT_FOUND
  s = services[service] ! else SERVICE_PRIVATE
  return insert entries { service, hymn, position, serviceDate: s.date }
mutation moveEntry(entry: entries, position: int 1..40):
  require exists staff[viewer] else STAFF_ONLY
  e = entries[entry] ! else NOT_FOUND
  other = entries[service = e.service, position = position]
  if other != null and other.id != e.id:
    update entries[e.id] { position: 0 }
    update entries[other.id] { position: e.position }
  update entries[e.id] { position }
mutation removeEntry(entry: entries):
  require exists staff[viewer] else STAFF_ONLY
  delete entries[entry]
