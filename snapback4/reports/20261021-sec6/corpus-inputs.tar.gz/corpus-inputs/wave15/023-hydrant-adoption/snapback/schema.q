-- Hydrant Adoption: neighbors adopt a hydrant on their block and keep it
-- clear of snow and debris. Adopters check in after storms; the fire
-- department (chief) sees a live map and flags overdue hydrants to the crew.
use personas alice, bob, chief

-- Where each neighbor lives. One row per person; block scope for reads.
table residents:
  principal: principal
  block: text 1..40
  unique principal
  read <- .principal = viewer or exists staff[principal = viewer]
  insert <- .principal = viewer
  update <- .principal = viewer
  cap 1 by principal
  online only

-- Privileged role: fire-department chief / city crew dispatcher.
table staff:
  principal: principal
  role: enum('chief', 'crew')
  unique principal
  read <- .principal = viewer or exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  cap 10
  online only

-- Every known hydrant. Staff-managed; adopters read only their own block.
table hydrants:
  address: text 1..120
  block: text 1..40
  status: enum('needs_clearing', 'cleared', 'flagged') default 'needs_clearing'
  read <- exists residents[principal = viewer, block = .block] or exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  update <- exists staff[principal = viewer]
  cap 500
  online only

-- One adoption per hydrant. Block is copied at insert and never changes.
table adoptions:
  hydrant: hydrants
  adopter: principal
  block: text 1..40
  at: time default now
  unique hydrant
  immutable hydrant, block
  read <- .adopter = viewer or exists residents[principal = viewer, block = .block] or exists staff[principal = viewer]
  insert <- .adopter = viewer
  delete <- .adopter = viewer
  cap 500
  online only

-- Post-storm check-ins from the adopter. Block copied at insert.
table checkins:
  hydrant: hydrants
  reporter: principal
  block: text 1..40
  photoUrl: text <=500 ?
  cleared: bool
  at: time default now
  immutable hydrant, reporter, block
  read <- .reporter = viewer or exists residents[principal = viewer, block = .block] or exists staff[principal = viewer]
  insert <- .reporter = viewer
  cap 1000 by hydrant
  online only

-- Escalations to the city crew. Staff only, end to end.
table crew_flags:
  hydrant: hydrants
  reason: text 1..200
  block: text 1..40
  resolved: bool default false
  at: time default now
  immutable hydrant, block
  read <- exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  update <- exists staff[principal = viewer]
  cap 500
  online only

-- Public leaderboard: cleared check-ins per block.
view blockClears: count checkins where .cleared = true by .block
  public 'The leaderboard is public.'
  online only

-- Adopters see only hydrants on the block they name; staff see any block.
query nearbyHydrants(block: text 1..40, c: cursor ?):
  require exists residents[principal = viewer, block = block] or exists staff[principal = viewer] else NOT_IN_BLOCK 'You can only view hydrants on your own block.'
  return hydrants where .block = block first 50 by .id after c

-- The fire department's live map: every hydrant.
query hydrantMap(c: cursor ?):
  require exists staff[principal = viewer] else NOT_STAFF 'Only fire-department staff see the full map.'
  return hydrants first 100 by .id after c

query myAdoptions(c: cursor ?):
  return adoptions where .adopter = viewer first 50 by .id after c

query recentCheckins(block: text 1..40, c: cursor ?):
  require exists residents[principal = viewer, block = block] or exists staff[principal = viewer] else NOT_IN_BLOCK 'You can only view check-ins on your own block.'
  return checkins where .block = block last 20 by .at after c

-- Open crew escalations. Staff only.
query flaggedForCrew(c: cursor ?):
  require exists staff[principal = viewer] else NOT_STAFF 'Only staff see crew flags.'
  return crew_flags where .resolved = false first 50 by .id after c

-- Public: blocks with the best clearing record.
query leaderboard(c: cursor ?):
  return blockClears first 50 by .block after c

mutation registerBlock(block: text 1..40):
  upsert residents[principal = viewer] { principal: viewer, block }
  return residents[principal = viewer]

mutation adoptHydrant(hydrant: hydrants):
  h = hydrants[hydrant] ! else NOT_FOUND
  require exists residents[principal = viewer, block = h.block] else NOT_IN_BLOCK 'You can only adopt a hydrant on your own block.'
  require not exists adoptions[hydrant = hydrant] else ALREADY_ADOPTED 'This hydrant already has an adopter.'
  return insert adoptions { hydrant, adopter: viewer, block: h.block }

mutation releaseHydrant(hydrant: hydrants):
  a = adoptions[hydrant = hydrant] ! else NOT_FOUND
  require a.adopter = viewer else NOT_YOUR_ADOPTION 'Only the adopter can release this hydrant.'
  delete adoptions[hydrant = hydrant]
  return null

mutation checkin(hydrant: hydrants, photoUrl: text <=500 ?, cleared: bool):
  h = hydrants[hydrant] ! else NOT_FOUND
  a = adoptions[hydrant = hydrant] ! else NOT_ADOPTER 'Only the adopter can check in.'
  require a.adopter = viewer else NOT_ADOPTER 'Only the adopter can check in.'
  return insert checkins { hydrant, reporter: viewer, block: h.block, photoUrl, cleared }

mutation setHydrantStatus(hydrant: hydrants, status: enum('needs_clearing', 'cleared', 'flagged')):
  require exists staff[principal = viewer] else NOT_STAFF 'Only staff update hydrant status.'
  update hydrants[hydrant] { status }
  return hydrants[hydrant]

mutation flagForCrew(hydrant: hydrants, reason: text 1..200):
  require exists staff[principal = viewer] else NOT_STAFF 'Only staff flag hydrants for the crew.'
  h = hydrants[hydrant] ! else NOT_FOUND
  return insert crew_flags { hydrant, reason, block: h.block }

mutation resolveFlag(flag: crew_flags, resolved: bool):
  require exists staff[principal = viewer] else NOT_STAFF 'Only staff resolve crew flags.'
  update crew_flags[flag] { resolved }
  return crew_flags[flag]
