-- Warming Center Tonight backend.
-- Personas: alice = intake staff, bob = volunteer/public viewer, carol = coordinator.
use identity
use personas alice, bob, carol

-- Staff roster: one row per person. Coordinator manages the roster.
-- Fixtures seed alice (intake) and carol (coordinator); bob is an outsider.
table staff:
  principal: principal
  role: enum('intake', 'coordinator')
  unique principal
  read <- allow
  insert <- exists staff[principal = viewer, role = 'coordinator']
  update <- exists staff[principal = viewer, role = 'coordinator']
  delete <- exists staff[principal = viewer, role = 'coordinator']
  online only

-- The center's nightly configuration. One row per site/night label in practice;
-- the demo seeds a single row.
table center:
  name: text 1..80
  night: text 1..40
  totalCots: int 1..500
  minStaff: int 0..50
  read <- allow
  insert <- exists staff[principal = viewer, role = 'coordinator']
  update <- exists staff[principal = viewer, role = 'coordinator']
  delete <- exists staff[principal = viewer, role = 'coordinator']
  online only

-- Private guest list: intake staff check guests in by first name + cot.
-- One guest per cot per night; only intake/coordinator staff may read or write.
table guests:
  firstName: text 1..40
  cot: int 1..500
  night: text 1..40
  checkedInAt: time default now
  unique night, cot else COT_TAKEN 'This cot is already taken tonight.'
  cap 500 by night
  read <- exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator']
  insert <- exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator']
  update <- exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator']
  delete <- exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator']
  online only

-- Volunteer shift board: public to read; anyone signed in may sign up;
-- only staff may change or remove shifts.
table shifts:
  volunteer: text 1..60
  night: text 1..40
  onDuty: bool default true
  unique night, volunteer else ALREADY_SIGNED_UP 'This volunteer is already signed up tonight.'
  cap 200 by night
  read <- allow
  insert <- allow
  update <- exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator']
  delete <- exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator']
  online only

-- Public aggregates: they disclose totals, never rows.
view guestsCheckedIn: count guests by .night
  read <- allow
  online only
view volunteersOnDuty: count shifts where .onDuty = true by .night
  read <- allow
  online only

-- Public site directory (paged so screens can list sites).
query centers(c: cursor ?):
  return center first 20 by .id after c

-- Public status page: beds available in real time.
query status(center: center, night: text 1..40):
  c = center[center] ! else NOT_FOUND
  checkedIn = guestsCheckedIn[night] ?? 0
  onDuty = volunteersOnDuty[night] ?? 0
  return { name: c.name, night, totalCots: c.totalCots, minStaff: c.minStaff, checkedIn, onDuty, bedsAvailable: c.totalCots - checkedIn, understaffed: onDuty < c.minStaff }

-- Private guest list for intake staff.
query guestList(night: text 1..40, c: cursor ?):
  require exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator'] else NOT_INTAKE
  return guests where .night = night first 100 by .cot after c

-- Public volunteer shift board.
query shiftBoard(night: text 1..40, c: cursor ?):
  return shifts where .night = night first 100 by .volunteer after c

-- Coordinator's nightly summary.
query nightly(center: center, night: text 1..40):
  require exists staff[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  c = center[center] ! else NOT_FOUND
  checkedIn = guestsCheckedIn[night] ?? 0
  onDuty = volunteersOnDuty[night] ?? 0
  return { name: c.name, night, totalCots: c.totalCots, minStaff: c.minStaff, checkedIn, onDuty, bedsAvailable: c.totalCots - checkedIn, understaffed: onDuty < c.minStaff }

-- Staffing alert: public so any viewer (including the board display) can show it.
query staffingAlert(center: center, night: text 1..40):
  c = center[center] ! else NOT_FOUND
  onDuty = volunteersOnDuty[night] ?? 0
  return { night, onDuty, minStaff: c.minStaff, understaffed: onDuty < c.minStaff }

mutation checkIn(center: center, firstName: text 1..40, cot: int 1..500, night: text 1..40):
  require exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator'] else NOT_INTAKE
  c = center[center] ! else NOT_FOUND
  require cot <= c.totalCots else COT_RANGE 'This cot number is beyond capacity.'
  return insert guests { firstName, cot, night }

mutation checkOut(guest: guests):
  require exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator'] else NOT_INTAKE
  g = guests[guest] ! else NOT_FOUND
  delete guests[guest]
  return null

mutation moveCot(guest: guests, cot: int 1..500):
  require exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator'] else NOT_INTAKE
  g = guests[guest] ! else NOT_FOUND
  update guests[guest] { cot }
  return null

mutation signUp(volunteer: text 1..60, night: text 1..40):
  return insert shifts { volunteer, night, onDuty: true }

mutation setShift(shift: shifts, onDuty: bool):
  require exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator'] else NOT_INTAKE
  s = shifts[shift] ! else NOT_FOUND
  update shifts[shift] { onDuty }
  return null

mutation removeShift(shift: shifts):
  require exists staff[principal = viewer, role = 'intake'] or exists staff[principal = viewer, role = 'coordinator'] else NOT_INTAKE
  s = shifts[shift] ! else NOT_FOUND
  delete shifts[shift]
  return null

mutation setCapacity(center: center, totalCots: int 1..500, minStaff: int 0..50):
  require exists staff[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  c = center[center] ! else NOT_FOUND
  update center[center] { totalCots, minStaff }
  return null

-- Purge names older than `before` for a night; rows (and hence counts) remain.
mutation purgeNames(night: text 1..40, before: time):
  require exists staff[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  page = guests where .night = night and .checkedInAt < before first 100 by .id
  for g in page:
    update guests[g] { firstName: 'purged' }
  return null
