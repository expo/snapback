-- Medicine Cabinet Expiry.
-- A household tracks medicines by name, expiry date and who they are for.
-- Adults (rostered) see and manage everything. Kids see nothing. A guest
-- caregiver sees only a shortlist while a time-limited grant is live; the
-- grant row expires automatically at .endsAt. A dose log records who last
-- took each medicine so two adults do not double up.

use personas alice, bob, kid, guest

-- Roster of household adults. Seeded out of band (dev /seed, fixtures).
table adults:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer
  insert <- exists adults[viewer]
  update <- deny
  delete <- exists adults[viewer]
  online only

table medicines:
  name: text 1..100
  expiresAt: time
  forWhom: text 1..40
  read <- exists adults[viewer] or (exists grants[guest = viewer] and exists shortlist[medicine = .id])
  insert <- exists adults[viewer]
  update <- exists adults[viewer]
  delete <- exists adults[viewer]
  cap 200
  online only

-- Medicines the guest caregiver may see and log doses for.
table shortlist:
  medicine: medicines on delete cascade
  unique medicine
  immutable medicine
  read <- exists adults[viewer] or exists grants[guest = viewer]
  insert <- exists adults[viewer]
  update <- deny
  delete <- exists adults[viewer]
  cap 50
  online only

-- Time-limited guest access. The row vanishes at .endsAt, ending access.
table grants:
  guest: principal
  endsAt: time
  unique guest
  immutable guest
  read <- exists adults[viewer] or .guest = viewer
  insert <- exists adults[viewer]
  update <- exists adults[viewer]
  delete <- exists adults[viewer]
  expire at .endsAt
  cap 10
  online only

table dose_logs:
  medicine: medicines on delete cascade
  takenBy: principal
  at: time default now
  immutable medicine, takenBy, at
  read <- exists adults[viewer] or (exists grants[guest = viewer] and exists shortlist[medicine = .medicine])
  insert <- exists adults[viewer] or (exists grants[guest = viewer] and exists shortlist[medicine = .medicine])
  update <- deny
  delete <- exists adults[viewer]
  cap 500 by medicine
  online only

query cabinet(c: cursor ?):
  return medicines first 50 by .expiresAt after c

query expiringSoon(c: cursor ?):
  return medicines where .expiresAt <= now + 7d first 50 by .expiresAt after c

query dropOff(c: cursor ?):
  return medicines where .expiresAt < now first 50 by .expiresAt after c

query dosesFor(medicine: medicines, c: cursor ?):
  return dose_logs where .medicine = medicine last 50 by .at after c

query shortlistMeds(c: cursor ?):
  return shortlist first 50 by .id after c

query grantsList(c: cursor ?):
  if exists adults[viewer]:
    return grants first 20 by .id after c
  return grants where .guest = viewer first 20 by .id after c

mutation addMedicine(name: text 1..100, expiresAt: time, forWhom: text 1..40):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage medicines.'
  return insert medicines { name, expiresAt, forWhom }

mutation updateExpiry(medicine: medicines, expiresAt: time):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage medicines.'
  m = medicines[medicine] ! else NOT_FOUND
  update medicines[medicine] { expiresAt }
  return null

mutation removeMedicine(medicine: medicines):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage medicines.'
  delete medicines[medicine]
  return null

mutation logDose(medicine: medicines, takenBy: principal):
  require exists adults[viewer] or exists grants[guest = viewer] else NOT_ALLOWED 'Only household adults or the guest caregiver log doses.'
  m = medicines[medicine] ! else NOT_FOUND
  return insert dose_logs { medicine, takenBy, at: now }

mutation addShortlist(medicine: medicines):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage the guest shortlist.'
  m = medicines[medicine] ! else NOT_FOUND
  return insert shortlist { medicine }

mutation removeShortlist(medicine: medicines):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage the guest shortlist.'
  delete shortlist[medicine = medicine]
  return null

mutation grantGuest(guest: principal, endsAt: time):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage guest access.'
  require endsAt > now else ENDS_IN_PAST 'Guest access must end in the future.'
  return upsert grants[guest] { guest, endsAt }

mutation revokeGuest(guest: principal):
  require exists adults[viewer] else NOT_ADULT 'Only household adults manage guest access.'
  delete grants[guest = guest]
  return null
