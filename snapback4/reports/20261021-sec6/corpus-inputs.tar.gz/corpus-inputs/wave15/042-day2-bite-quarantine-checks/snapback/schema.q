use identity
-- Development cast: alice/bob own dogs; olivia is officer; sam supervises; vera is a victim.
use personas alice, bob, olivia, sam, vera

table staff:
  insert <- viewer = 'service:ops'
  principal: principal
  role: enum('officer', 'supervisor')
  unique principal
  read <- (
 .principal = viewer
  ) or viewer = 'service:ops'
  online only

table clearances:
  token: text 32..80
  cleared: bool default false
  unique token
  immutable token
  public 'Opaque status links reveal clearance only; no case reference or personal data.'
  insert <- exists staff[viewer, role = 'officer']
  update <- exists staff[viewer, role = 'officer']
  online only

table cases:
  owner: principal
  officer: principal
  dog: text 1..80
  address: text 5..240
  startsAt: time
  endsAt: time
  clearance: clearances
  statusToken: text 32..80
  status: enum('active', 'cleared') default 'active'
  severity: enum('routine', 'severe') default 'routine'
  missed: bool default false
  clearedAt: time ?
  immutable owner, officer, dog, address, startsAt, endsAt, clearance, statusToken
  read <- .owner = viewer or .officer = viewer or exists staff[viewer, role = 'supervisor']
  insert <- .officer = viewer and exists staff[viewer, role = 'officer']
  update <- .officer = viewer and exists staff[viewer, role = 'officer']
  online only

table checkins:
  case: cases
  owner: principal
  dayNumber: int 1..10
  photo: image <=5000000
  note: text <=500
  at: time
  unique case, dayNumber else ALREADY_CHECKED_IN
  immutable case, owner, dayNumber, photo, note, at
  read through .case
  insert <- .owner = viewer and exists cases[.case, owner = viewer, status = 'active']
  cap 10 by case
  online only

table visits:
  case: cases
  officer: principal
  dayNumber: int 1..10
  finding: text 1..500
  at: time
  unique case, dayNumber else VISIT_LOGGED
  immutable case, officer, dayNumber, finding, at
  read through .case
  insert <- .officer = viewer and exists staff[viewer, role = 'officer']
  online only

table events:
  case: cases
  kind: enum('opened', 'checkin', 'missed', 'cleared', 'visit')
  dayNumber: int 0..10
  at: time
  actor: principal ?
  unique case, kind, dayNumber
  immutable case, kind, dayNumber, at, actor
  read through .case
  insert <- .actor = viewer and (exists staff[viewer, role = 'officer'] or exists cases[.case, owner = viewer])
  online only

query myStaffRole(c: cursor ?):
  return staff where .principal = viewer first 1 by .id after c

query myCases(c: cursor ?):
  if exists staff[viewer, role = 'supervisor']:
    return cases last 50 by .startsAt after c
  if exists staff[viewer, role = 'officer']:
    return cases where .officer = viewer last 50 by .startsAt after c
  return cases where .owner = viewer last 50 by .startsAt after c

query caseDetail(case: cases):
  return cases[case]

query dailyPhotos(case: cases, c: cursor ?):
  return checkins where .case = case first 10 by .dayNumber after c

query fieldVisits(case: cases, c: cursor ?):
  return visits where .case = case first 10 by .dayNumber after c

query history(case: cases, c: cursor ?):
  return events where .case = case first 50 by .at after c

query clearanceStatus(token: text 32..80):
  return clearances[token = token] { cleared }

mutation openCase(owner: principal, dog: text 1..80, address: text 5..240, token: text 32..80, severity: enum('routine', 'severe')):
  require exists staff[viewer, role = 'officer'] else OFFICER_ONLY 'Only an animal control officer may open a case.'
  statusLink = insert clearances { token, cleared: false }
  row = insert cases { owner, officer: viewer, dog, address, startsAt: now, endsAt: now + 10d, clearance: statusLink.id, statusToken: token, severity }
  insert events { case: row.id, kind: 'opened', dayNumber: 0, at: now, actor: viewer }
  return row

mutation checkIn(case: cases, photo: image <=5000000, note: text <=500):
  row = cases[case] ! else NOT_FOUND
  require row.owner = viewer else OWNER_ONLY 'Only the owner may check in.'
  require row.status = 'active' and now >= row.startsAt and now < row.endsAt else QUARANTINE_CLOSED
  n = (now - row.startsAt) / 1d + 1
  checkin = insert checkins { case, owner: viewer, dayNumber: n, photo, note, at: now }
  insert events { case, kind: 'checkin', dayNumber: n, at: now, actor: viewer }
  return checkin

mutation logVisit(case: cases, finding: text 1..500):
  require exists staff[viewer, role = 'officer'] else OFFICER_ONLY 'Only an animal control officer may log a field visit.'
  row = cases[case] ! else NOT_FOUND
  require row.status = 'active' and now >= row.startsAt and now < row.endsAt else QUARANTINE_CLOSED
  n = (now - row.startsAt) / 1d + 1
  visit = insert visits { case, officer: viewer, dayNumber: n, finding, at: now }
  insert events { case, kind: 'visit', dayNumber: n, at: now, actor: viewer }
  return visit

mutation release(case: cases):
  require exists staff[viewer, role = 'officer'] else OFFICER_ONLY
  row = cases[case] ! else NOT_FOUND
  require row.officer = viewer else ASSIGNED_OFFICER_ONLY
  require row.status = 'active' else ALREADY_CLEARED
  require row.severity = 'routine' or exists visits[case = row.id] else VISIT_REQUIRED 'Severe-bite cases need at least one officer field visit before release.'
  require now >= row.endsAt else TOO_EARLY 'The full ten-day quarantine must finish before release.'
  update cases[case] { status: 'cleared', clearedAt: now }
  update clearances[row.clearance] { cleared: true }
  insert events { case, kind: 'cleared', dayNumber: 10, at: now, actor: viewer }
  return cases[case]

job flagMissed():
  for row in cases:
    if row.status = 'active':
      for n in range(1, 11):
        if now >= row.startsAt + n * 1d and not exists checkins[row.id, n] and not exists events[row.id, 'missed', n]:
          update cases[row.id] { missed: true }
          insert events { case: row.id, kind: 'missed', dayNumber: n, at: now, actor: null }
schedule hourlyChecks every 1h: flagMissed

mutation bootstrapstaff(seat_principal: principal, seat_role: enum('officer', 'supervisor')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal: seat_principal, role: seat_role }
