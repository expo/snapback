use personas visitor, alice, bob, clara, librarian
use identity

-- Society-managed membership records become readable only after probation.
-- eligibleAt is the calendar six-month anniversary, supplied by the society.
-- Production: password accounts plus guests (visitors browse performances as
-- guests). Personas stay for development only; serve refuses them. Signup
-- grants no role: the society enrolls memberships and librarians through the
-- service:ops seat (bootstrapMembership / bootstrapLibrarian below).
table memberships:
  principal: principal
  name: text 1..60
  joinedAt: time
  eligibleAt: time
  unique principal
  read <- (.principal = viewer) or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  not before .eligibleAt
  online only

table librarians:
  principal: principal
  unique principal
  read <- (.principal = viewer) or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table routines:
  author: principal
  title: text 3..100
  performance: text 10..2000
  approvalRequired: bool
  difficulty: enum('apprentice', 'adept', 'master') default 'apprentice'
  createdAt: time default now
  immutable author, approvalRequired
  public 'Visitors can browse performance descriptions, never methods.'
  insert <- .author = viewer and exists memberships[viewer]
  online only

table favorites:
  member: principal
  routine: routines
  createdAt: time default now
  unique member, routine
  immutable member, routine, createdAt
  read <- .member = viewer
  insert <- .member = viewer and exists memberships[viewer] and exists routines[.routine]
  delete <- .member = viewer
  online only

table methods:
  routine: routines
  author: principal
  secret: text 10..5000
  approvalRequired: bool
  unique routine
  immutable routine, author, approvalRequired
  read <- exists memberships[viewer] and (.approvalRequired = false or .author = viewer or exists requests[.routine, viewer, approved = true])
  insert <- .author = viewer and exists memberships[viewer] and exists routines[.routine, author = viewer, approvalRequired = .approvalRequired]
  online only

table requests:
  routine: routines
  member: principal
  author: principal
  approved: bool default false
  requestedAt: time default now
  unique routine, member
  immutable routine, member, author
  read <- .member = viewer or .author = viewer
  insert <- .member = viewer and .approved = false and exists memberships[viewer] and exists routines[.routine, author = .author, approvalRequired = true]
  update (old, next) <- old.author = viewer and old.approved = false and next.approved = true
  online only

table methodViews:
  routine: routines
  member: principal
  viewedAt: time default now
  immutable routine, member, viewedAt
  read <- exists librarians[viewer]
  insert <- .member = viewer and exists methods[routine = .routine]
  online only

view viewCounts: count methodViews by .routine
  read <- exists routines[.routine, author = viewer] or exists librarians[viewer]
  online only

query catalog():
  return routines last 100 by .createdAt

query myStatus():
  return { principal: viewer, membership: memberships[viewer], librarian: exists librarians[viewer] }

query myRequests():
  return requests where .member = viewer last 100 by .requestedAt

query authorRequests():
  return requests where .author = viewer last 100 by .requestedAt

query myFavorites():
  return favorites where .member = viewer last 100 by .createdAt

query ownViewCount(routine: routines):
  r = routines[routine] ! else NOT_FOUND
  require r.author = viewer or exists librarians[viewer] else NOT_AUTHOR
  return viewCounts[routine]

query viewLog():
  require exists librarians[viewer] else LIBRARIAN_ONLY
  return methodViews last 100 by .viewedAt

mutation createRoutine(title: text 3..100, performance: text 10..2000, secret: text 10..5000, approvalRequired: bool, difficulty: enum('apprentice', 'adept', 'master')):
  require exists memberships[viewer] else PROBATION 'Methods require a completed six-month probation.'
  r = insert routines { author: viewer, title, performance, approvalRequired, difficulty }
  insert methods { routine: r.id, author: viewer, secret, approvalRequired }
  return r

mutation addFavorite(routine: routines):
  require exists memberships[viewer] else PROBATION 'Members keep a favorites shelf after six months of membership.'
  require exists routines[routine] else NOT_FOUND
  return insert favorites { member: viewer, routine }

mutation removeFavorite(routine: routines):
  require exists memberships[viewer] else PROBATION 'Members keep a favorites shelf after six months of membership.'
  f = favorites[member = viewer, routine = routine] ! else NOT_FOUND
  delete favorites[f.id]
  return null

mutation requestAccess(routine: routines):
  require exists memberships[viewer] else PROBATION 'Complete six months of membership before requesting a method.'
  r = routines[routine] ! else NOT_FOUND
  require r.approvalRequired else OPEN_METHOD 'This method needs no author approval.'
  require r.author != viewer else OWN_METHOD 'You already have access to your own method.'
  return insert requests { routine, member: viewer, author: r.author }

mutation approveAccess(request: requests):
  r = requests[request] ! else NOT_FOUND
  require r.author = viewer else NOT_AUTHOR
  update requests[request] { approved: true }
  return null

mutation openMethod(routine: routines):
  require exists memberships[viewer] else PROBATION 'Methods unlock after six months of membership.'
  require exists routines[routine] else NOT_FOUND
  m = methods[routine = routine] ! else METHOD_LOCKED 'The author must approve your access.'
  insert methodViews { routine, member: viewer }
  return { secret: m.secret }

mutation bootstrapMembership(principal: principal, name: text 1..60, joinedAt: time, eligibleAt: time):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert memberships { principal, name, joinedAt, eligibleAt }

mutation bootstrapLibrarian(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert librarians { principal }
