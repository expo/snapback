-- Furniture Bank Pickups.
-- Donors offer furniture (photo URL + description); staff approve/decline.
-- Approved donors book a pickup slot; drivers run that day's route.
-- Caseworkers request items for clients; client names stay hidden from
-- drivers and donors. Staff see inventory / waiting counts by category and
-- unclaimed items older than 60 days.
use identity
use personas alice, bob, carol, dave

-- Rosters. alice donates (no roster row); bob is a caseworker,
-- carol is staff, dave is a driver. Fixtures seed these in development;
-- production operators provision real accounts using the service-seat mutations.
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

table caseworkers:
  principal: principal
  agency: text 1..80
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

table drivers:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

-- Pickup slots offered by the furniture bank (day is UTC midnight).
table slots:
  day: time
  window: text 1..20
  capacity: int 1..20
  unique day, window
  immutable day, window
  read <- allow
  insert <- exists staff[principal = viewer]
  update <- deny
  delete <- deny
  online only

-- Donated items. Donors read their own rows; staff read everything;
-- drivers and caseworkers read rows only through narrow queries below
-- (projections hide donor/address from caseworkers).
table items:
  donor: principal
  category: text 1..20
  description: text 1..500
  photoUrl: text <=500 ?
  address: text 1..200
  status: enum('pending', 'approved', 'declined', 'scheduled', 'collected', 'delivered', 'withdrawn') default 'pending'
  revision: int default 1
  createdAt: time default now
  immutable donor, createdAt
  cap 200 by donor
  read <- .donor = viewer or exists staff[principal = viewer] or exists drivers[principal = viewer] or exists caseworkers[principal = viewer]
  insert <- .donor = viewer
  update <- .donor = viewer or exists staff[principal = viewer] or exists drivers[principal = viewer]
  online only

-- Scheduled collections. donor is copied at schedule time and never changes.
table pickups:
  item: items
  slot: slots
  donor: principal
  day: time
  status: enum('scheduled', 'collected') default 'scheduled'
  unique item
  immutable item, slot, donor, day
  read <- .donor = viewer or exists staff[principal = viewer] or exists drivers[principal = viewer]
  insert <- .donor = viewer and exists items[.item, donor = viewer]
  update <- .donor = viewer or exists staff[principal = viewer] or exists drivers[principal = viewer]
  online only

-- Caseworker requests. clientRef (the client's name/id) is readable only
-- by the owning caseworker and staff: no other role has any query over it.
table requests:
  caseworker: principal
  category: text 1..20
  clientRef: text 1..80
  note: text <=500 ?
  status: enum('waiting', 'fulfilled', 'cancelled') default 'waiting'
  createdAt: time default now
  immutable caseworker, createdAt
  cap 100 by caseworker
  read <- .caseworker = viewer or exists staff[principal = viewer]
  insert <- .caseworker = viewer
  update <- .caseworker = viewer or exists staff[principal = viewer]
  online only

-- Maintained counts. Staff-only disclosure channels; donors/drivers/
-- caseworkers never read a row they cannot already see, only totals for staff.
view inventoryByCategory: count items where .status = 'approved' or .status = 'scheduled' or .status = 'collected' by .category
  read <- exists staff[principal = viewer]
  online only

view waitingByCategory: count requests where .status = 'waiting' by .category
  read <- exists staff[principal = viewer]
  online only

view scheduledBySlot: count pickups where .status = 'scheduled' by .slot
  read <- allow
  online only

-- Donor inbox: everything I offered.
query myItems():
  return items where .donor = viewer first 50 by .createdAt

-- Slots still in the future. Public to the dev cast; donors book from it.
query openSlots():
  return slots where .day >= day(now) * 1d first 50 by .day

-- My scheduled collections, with the slot attached.
query myPickups():
  return pickups where .donor = viewer first 50 by .day { id, day, status, slot: slots[.slot], item: items[.item] }

-- What a caseworker may promise clients: no donor, no pickup address.
query available():
  require exists caseworkers[principal = viewer] or exists staff[principal = viewer] else NOT_CASEWORKER
  return items where .status = 'approved' or .status = 'collected' first 50 by .createdAt { id, category, description, status, revision, createdAt }

-- My agency's requests, client names included.
query myRequests():
  return requests where .caseworker = viewer first 50 by .createdAt

-- Today's route: scheduled collections with item + slot. Drivers and staff.
query route():
  require exists drivers[principal = viewer] or exists staff[principal = viewer] else NOT_DRIVER
  return pickups where .day >= day(now) * 1d and .day < day(now) * 1d + 1d and .status = 'scheduled' first 50 by .id { id, day, status, item: items[.item], slot: slots[.slot] }

-- Staff: everything awaiting a decision.
query pending():
  require exists staff[principal = viewer] else NOT_STAFF
  return items where .status = 'pending' first 50 by .createdAt

-- Staff: waiting requests, client names included.
query allRequests():
  require exists staff[principal = viewer] else NOT_STAFF
  return requests where .status = 'waiting' first 50 by .createdAt

-- Staff: approved-but-unclaimed items older than 60 days.
query stale():
  require exists staff[principal = viewer] else NOT_STAFF
  return items where .status = 'approved' and .createdAt < now - 60d first 50 by .createdAt

-- Staff: inventory counts by category.
query inventory():
  require exists staff[principal = viewer] else NOT_STAFF
  return { sofa: inventoryByCategory['sofa'] ?? 0, table: inventoryByCategory['table'] ?? 0, chair: inventoryByCategory['chair'] ?? 0, bed: inventoryByCategory['bed'] ?? 0, dresser: inventoryByCategory['dresser'] ?? 0, desk: inventoryByCategory['desk'] ?? 0, other: inventoryByCategory['other'] ?? 0 }

-- Staff: waiting requests by category.
query waiting():
  require exists staff[principal = viewer] else NOT_STAFF
  return { sofa: waitingByCategory['sofa'] ?? 0, table: waitingByCategory['table'] ?? 0, chair: waitingByCategory['chair'] ?? 0, bed: waitingByCategory['bed'] ?? 0, dresser: waitingByCategory['dresser'] ?? 0, desk: waitingByCategory['desk'] ?? 0, other: waitingByCategory['other'] ?? 0 }

-- Any signed-in donor offers an item; staff decide on it later.
mutation offer(category: text 1..20, description: text 1..500, address: text 1..200, photoUrl: text <=500 ?):
  require category = 'sofa' or category = 'table' or category = 'chair' or category = 'bed' or category = 'dresser' or category = 'desk' or category = 'other' else BAD_CATEGORY 'Unknown furniture category.'
  return insert items { donor: viewer, category, description, address, photoUrl }

-- Staff approve or decline a pending donation.
mutation review(item: items, approve: bool):
  require exists staff[principal = viewer] else NOT_STAFF
  i = items[item] ! else NOT_FOUND
  require i.status = 'pending' else NOT_PENDING 'Only pending items can be reviewed.'
  update items[item] { status: 'approved' if approve else 'declined', revision: i.revision + 1 }
  return null

-- Staff open a pickup slot.
mutation addSlot(day: time, window: text 1..20, capacity: int 1..20):
  require exists staff[principal = viewer] else NOT_STAFF
  require window = 'morning' or window = 'afternoon' or window = 'evening' else BAD_WINDOW 'Unknown pickup window.'
  return insert slots { day, window, capacity }

-- The donor books a slot for their approved item.
mutation schedule(item: items, slot: slots):
  i = items[item] ! else NOT_FOUND
  s = slots[slot] ! else NOT_FOUND
  require i.donor = viewer else NOT_YOURS 'Only the donor can schedule this item.'
  require i.status = 'approved' else NOT_APPROVED 'Only approved items can be scheduled.'
  require s.day >= day(now) * 1d else SLOT_PAST 'That slot is in the past.'
  require (scheduledBySlot[slot] ?? 0) < s.capacity else SLOT_FULL 'That slot is full.'
  require not exists pickups[item] else ALREADY_SCHEDULED 'This item already has a pickup.'
  p = insert pickups { item, slot, donor: viewer, day: s.day }
  update items[item] { status: 'scheduled', revision: i.revision + 1 }
  return p

-- The driver collects a scheduled item.
mutation collect(pickup: pickups):
  require exists drivers[principal = viewer] or exists staff[principal = viewer] else NOT_DRIVER
  p = pickups[pickup] ! else NOT_FOUND
  require p.status = 'scheduled' else NOT_SCHEDULED 'Only scheduled pickups can be collected.'
  i = items[p.item] ! else NOT_FOUND
  update pickups[pickup] { status: 'collected' }
  update items[p.item] { status: 'collected', revision: i.revision + 1 }
  return null

-- A caseworker requests an item for a client. The client name stays
-- in requests, which only the caseworker and staff can read.
mutation ask(category: text 1..20, clientRef: text 1..80, note: text <=500 ?):
  require exists caseworkers[principal = viewer] else NOT_CASEWORKER
  require category = 'sofa' or category = 'table' or category = 'chair' or category = 'bed' or category = 'dresser' or category = 'desk' or category = 'other' else BAD_CATEGORY 'Unknown furniture category.'
  return insert requests { caseworker: viewer, category, clientRef, note }

-- Staff hand a collected item to a waiting request.
mutation fulfill(request: requests, item: items):
  require exists staff[principal = viewer] else NOT_STAFF
  r = requests[request] ! else NOT_FOUND
  i = items[item] ! else NOT_FOUND
  require r.status = 'waiting' else NOT_WAITING 'Only waiting requests can be fulfilled.'
  require i.status = 'collected' else NOT_COLLECTED 'Only collected items can be handed out.'
  require i.category = r.category else CATEGORY_MISMATCH 'The item category does not match the request.'
  update requests[request] { status: 'fulfilled' }
  update items[item] { status: 'delivered', revision: i.revision + 1 }
  return null

-- An operator provisions each role explicitly; sign-up grants no privileges.
mutation grantStaff(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal }

mutation grantCaseworker(principal: principal, agency: text 1..80):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert caseworkers { principal, agency }

mutation grantDriver(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert drivers { principal }

-- Before booking, donors may withdraw an offer with an auditable reason.
-- Literal revision=1 backfills historical items without inventing timestamps.
table withdrawals:
  item: items
  donor: principal
  reason: text 1..200
  previousStatus: enum('pending', 'approved')
  itemRevision: int
  createdAt: time default now
  unique item
  immutable item, donor, reason, previousStatus, itemRevision, createdAt
  cap 200 by donor
  read <- .donor = viewer or exists staff[principal = viewer]
  insert <- .donor = viewer and exists items[.item, donor = viewer]
  update <- deny
  delete <- deny
  online only

query myWithdrawals():
  return withdrawals where .donor = viewer first 50 by .createdAt

mutation withdraw(item: items, expectedRevision: int, reason: text 1..200):
  i = items[item] ! else NOT_FOUND
  require i.donor = viewer else NOT_YOURS 'Only the donor can withdraw this offer.'
  require i.revision = expectedRevision else STALE_ITEM 'This item changed. Refresh before withdrawing.'
  require i.status = 'pending' or i.status = 'approved' else CANNOT_WITHDRAW 'Only unbooked pending or approved offers can be withdrawn.'
  receipt = insert withdrawals { item, donor: viewer, reason, previousStatus: i.status, itemRevision: i.revision }
  update items[item] { status: 'withdrawn', revision: i.revision + 1 }
  return receipt

-- Authenticated account capabilities; no privileged identities are disclosed.
query accountAccess():
  return { principal: viewer, staff: exists staff[principal = viewer], worker: exists caseworkers[principal = viewer], driver: exists drivers[principal = viewer] }
