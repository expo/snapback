use personas alice, bob, carol, dana, erin, visitor
use identity

table staff:
  principal: principal
  role: enum('office', 'head', 'director', 'reviewer')
  department: enum('cardiology', 'orthopedics')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table grievances:
  title: text 3..120
  details: text 10..4000
  complainant: text 2..120
  department: enum('cardiology', 'orthopedics')
  severity: enum('routine', 'urgent') default 'routine'
  state: enum('open', 'responded', 'escalated', 'closed') default 'open'
  createdAt: time default now
  dueAt: time
  immutable createdAt, dueAt
  read <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'reviewer'] or exists staff[principal = viewer, role = 'head', department = .department]
  insert <- exists staff[principal = viewer, role = 'office']
  update <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'head', department = .department]
  online only

table discussion:
  grievance: grievances
  author: principal
  body: text 1..4000
  kind: enum('note', 'response')
  at: time default now
  immutable grievance, author, body, kind, at
  read <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'reviewer'] or (exists staff[principal = viewer, role = 'head', department = 'cardiology'] and exists grievances[.grievance, department = 'cardiology']) or (exists staff[principal = viewer, role = 'head', department = 'orthopedics'] and exists grievances[.grievance, department = 'orthopedics'])
  insert <- .author = viewer and exists grievances[.grievance] and exists staff[principal = viewer]
  online only

table audit:
  grievance: grievances
  actor: principal ?
  event: enum('created', 'edited', 'note', 'response', 'closed', 'escalated', 'planned', 'completed')
  body: text 1..4000
  title: text 3..120
  details: text 10..4000
  complainant: text 2..120
  department: enum('cardiology', 'orthopedics')
  state: enum('open', 'responded', 'escalated', 'closed')
  publicUpdate: text 1..1000
  at: time default now
  immutable publicUpdate
  immutable grievance, actor, event, body, title, details, complainant, department, state, at
  read <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'reviewer'] or (exists staff[principal = viewer, role = 'head', department = 'cardiology'] and exists grievances[.grievance, department = 'cardiology']) or (exists staff[principal = viewer, role = 'head', department = 'orthopedics'] and exists grievances[.grievance, department = 'orthopedics'])
  insert <- exists staff[principal = viewer] and .actor = viewer
  online only

table statuses:
  grievance: grievances
  state: enum('open', 'responded', 'escalated', 'closed')
  dueAt: time
  updateText: text 1..1000
  updatedAt: time default now
  unique grievance
  immutable grievance, dueAt
  public 'Only redacted progress; opaque row ID is the shareable status link. No names, complaint details or discussion.'
  insert <- exists staff[principal = viewer, role = 'office']
  update <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or (exists staff[principal = viewer, role = 'head', department = 'cardiology'] and exists grievances[.grievance, department = 'cardiology']) or (exists staff[principal = viewer, role = 'head', department = 'orthopedics'] and exists grievances[.grievance, department = 'orthopedics'])
  online only

table plans:
  grievance: grievances
  owner: principal
  action: text 1..500
  dueAt: time
  state: enum('planned', 'done') default 'planned'
  at: time default now
  immutable grievance, owner, action, dueAt, at
  read <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'reviewer'] or (exists staff[principal = viewer, role = 'head', department = 'cardiology'] and exists grievances[.grievance, department = 'cardiology']) or (exists staff[principal = viewer, role = 'head', department = 'orthopedics'] and exists grievances[.grievance, department = 'orthopedics'])
  insert <- .owner = viewer and exists grievances[.grievance] and exists staff[principal = viewer]
  update <- exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or (exists staff[principal = viewer, role = 'head', department = 'cardiology'] and exists grievances[.grievance, department = 'cardiology']) or (exists staff[principal = viewer, role = 'head', department = 'orthopedics'] and exists grievances[.grievance, department = 'orthopedics'])
  online only

fn record(g: grievances, event: enum('created', 'edited', 'note', 'response', 'closed', 'escalated', 'planned', 'completed'), body: text 1..4000):
  r = grievances[g] ! else NOT_FOUND
  s = statuses[grievance = g] ! else NOT_FOUND
  insert audit { grievance: g, actor: viewer, event, body, title: r.title, details: r.details, complainant: r.complainant, department: r.department, state: r.state, publicUpdate: s.updateText }

query myRole():
  return staff[principal = viewer]
query worklist(c: cursor ?):
  s = staff[principal = viewer]
  if s != null:
    if s.role = 'head':
      return grievances where .department = s.department last 50 by .createdAt after c
  return grievances last 50 by .createdAt after c
query grievance(id: grievances):
  return grievances[id]
query thread(id: grievances, c: cursor ?):
  return discussion where .grievance = id first 50 by .at after c
query history(id: grievances, c: cursor ?):
  return audit where .grievance = id first 50 by .at after c
query statusLink(id: grievances):
  require exists grievances[id] else NOT_FOUND
  return statuses[grievance = id]
query publicStatus(link: statuses):
  return statuses[link] { state, dueAt, updateText, updatedAt }
query casePlans(id: grievances, c: cursor ?):
  return plans where .grievance = id first 50 by .at after c

mutation createGrievance(title: text 3..120, details: text 10..4000, complainant: text 2..120, department: enum('cardiology', 'orthopedics'), severity: enum('routine', 'urgent')):
  require exists staff[principal = viewer, role = 'office'] else OFFICE_ONLY
  g = insert grievances { title, details, complainant, department, severity, dueAt: now + 2d if severity = 'urgent' else now + 7d }
  s = insert statuses { grievance: g.id, state: 'open', dueAt: g.dueAt, updateText: 'Received as urgent. The department has two days to respond.' if severity = 'urgent' else 'Received. The department has seven days to respond.' }
  record(g.id, 'created', 'Complaint logged and assigned.')
  return { id: g.id, link: s.id }
mutation editGrievance(id: grievances, title: text 3..120, details: text 10..4000, complainant: text 2..120, department: enum('cardiology', 'orthopedics'), severity: enum('routine', 'urgent')):
  require exists staff[principal = viewer, role = 'office'] else OFFICE_ONLY
  update grievances[id] { title, details, complainant, department, severity }
  record(id, 'edited', 'Intake details or assignment updated.')
mutation addNote(id: grievances, body: text 1..4000):
  require exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'head'] or exists staff[principal = viewer, role = 'director'] else STAFF_ONLY
  g = grievances[id] ! else NOT_FOUND
  require g.state != 'closed' else CLOSED
  insert discussion { grievance: id, author: viewer, body, kind: 'note' }
  record(id, 'note', body)
mutation respond(id: grievances, body: text 1..4000, updateText: text 1..1000):
  g = grievances[id] ! else NOT_FOUND
  require exists staff[principal = viewer, role = 'head', department = g.department] else DEPARTMENT_HEAD_ONLY
  require g.state = 'open' or g.state = 'escalated' else ALREADY_RESPONDED
  insert discussion { grievance: id, author: viewer, body, kind: 'response' }
  update grievances[id] { state: 'responded' }
  update statuses[grievance = id] { state: 'responded', updateText, updatedAt: now }
  record(id, 'response', body)
mutation closeGrievance(id: grievances, updateText: text 1..1000):
  require exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] else OFFICE_OR_DIRECTOR_ONLY
  g = grievances[id] ! else NOT_FOUND
  require g.state != 'closed' else CLOSED
  require exists staff[principal = viewer, role = 'director'] or g.state = 'responded' else RESPONSE_REQUIRED
  update grievances[id] { state: 'closed' }
  update statuses[grievance = id] { state: 'closed', updateText, updatedAt: now }
  record(id, 'closed', updateText)
mutation provisionStaff(principal: principal, role: enum('office', 'head', 'director', 'reviewer'), department: enum('cardiology', 'orthopedics')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal, role, department }
mutation addPlan(id: grievances, action: text 1..500, dueAt: time):
  g = grievances[id] ! else NOT_FOUND
  require g.state != 'closed' else CLOSED
  require exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'head', department = g.department] else STAFF_ONLY
  p = insert plans { grievance: id, owner: viewer, action, dueAt }
  record(id, 'planned', action)
  return { plan: p.id }
mutation completePlan(plan: plans, updateText: text 1..1000):
  p = plans[plan] ! else NOT_FOUND
  g = grievances[p.grievance] ! else NOT_FOUND
  require g.state != 'closed' else CLOSED
  require p.state = 'planned' else ALREADY_DONE
  require exists staff[principal = viewer, role = 'office'] or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'head', department = g.department] else STAFF_ONLY
  update plans[plan] { state: 'done' }
  update statuses[grievance = g.id] { updateText, updatedAt: now }
  record(g.id, 'completed', updateText)

job escalate():
  for g in grievances:
    if g.state = 'open' and g.dueAt <= now:
      update grievances[g.id] { state: 'escalated' }
      update statuses[grievance = g.id] { state: 'escalated', updateText: 'The response is overdue and has been referred to the director.', updatedAt: now }
      insert audit { grievance: g.id, actor: null, event: 'escalated', body: 'Seven-day response deadline passed. Referred to director.', title: g.title, details: g.details, complainant: g.complainant, department: g.department, state: 'escalated', publicUpdate: 'The response is overdue and has been referred to the director.' }
schedule overdueCheck every 1m: escalate
