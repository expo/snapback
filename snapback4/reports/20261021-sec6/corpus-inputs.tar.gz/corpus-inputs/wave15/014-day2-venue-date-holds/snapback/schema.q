use identity
use personas alice, bob, carol, manager

-- A roster rather than a client-supplied role flag.
table managers:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table dates:
  day: int 1..
  booked: bool default false
  unique day
  immutable day
  public 'Date availability is shared; client details live only in private holds.'
  insert <- exists managers[viewer]
  update <- allow
  online only

table holds:
  date: dates
  owner: principal
  title: text 3..80
  expectedGuests: int 1..500 default 50
  ordinal: sequence by date
  createdAt: time default now
  expiresAt: time
  challengeUntil: time ?
  outcome: enum('held', 'released', 'booked', 'closed') default 'held'
  unique date, owner else ALREADY_REQUESTED 'You already have a request for this date.'
  immutable date, owner, ordinal, createdAt, title
  read <- .owner = viewer or exists managers[viewer]
  insert <- .owner = viewer or exists managers[viewer]
  update <- .owner = viewer or exists managers[viewer] or exists holds[.date, viewer]
  online only

-- Anonymous occupancy is intentionally readable, like a public availability
-- ledger. References cannot disclose the private owner's name or event title.
-- Expiry is server-enforced immediately; durable holds keep the history.
table queue:
  date: dates
  hold: holds on delete keep
  ordinal: int 1..
  expiresAt: time ?
  challengeUntil: time ?
  kind: enum('hold', 'booking') default 'hold'
  unique hold
  immutable date, hold, ordinal
  public 'Anonymous date occupancy supports queue positions; never store client names here.'
  insert <- exists holds[.hold, owner = viewer] or exists managers[viewer]
  update <- exists holds[.date, viewer] or exists managers[viewer]
  delete <- exists holds[.date, viewer] or exists managers[viewer]
  expire at .expiresAt
  cap 3 by date
  online only

table history:
  date: dates
  hold: holds on delete keep
  kind: enum('placed', 'challenged', 'released', 'booked', 'closed', 'brief_updated')
  at: time default now
  deadline: time ?
  immutable date, hold, kind, at, deadline
  read <- exists holds[.hold, owner = viewer] or exists managers[viewer]
  insert <- exists holds[.date, viewer] or exists managers[viewer]
  online only

fn holdCard(h: holds):
  q = queue[hold = h.id]
  d = dates[h.date] ! else NOT_FOUND
  return { id: h.id, date: h.date, day: d.day, owner: h.owner, title: h.title, expectedGuests: h.expectedGuests, createdAt: h.createdAt, expiresAt: h.expiresAt, challengeUntil: h.challengeUntil, outcome: h.outcome, active: q != null, position: 0 if q = null else count(queue where .date = h.date and .ordinal <= h.ordinal), booked: d.booked }

query myHolds(c: cursor ?):
  return holds where .owner = viewer last 20 by .createdAt after c { card: holdCard(.) }

query calendar(c: cursor ?):
  return dates first 60 by .day after c { id, day, booked, occupied: count(queue[date = .id]) }

query holdDetail(hold: holds):
  h = holds[hold] ! else NOT_FOUND
  return holdCard(h)

query holdHistory(hold: holds, c: cursor ?):
  h = holds[hold] ! else NOT_FOUND
  return history where .hold = h.id first 50 by .at after c

query managerCalendar(c: cursor ?):
  require exists managers[viewer] else MANAGER_ONLY 'The full calendar is for the venue manager.'
  return holds first 50 by .createdAt after c { card: holdCard(.) }

mutation openDate(day: int 1..):
  require exists managers[viewer] else MANAGER_ONLY
  require day > day(now) and day <= day(now) + 730 else BAD_DATE 'Choose a future date within two years.'
  return insert dates { day }

mutation placeHold(date: dates, title: text 3..80, client: principal ?): server
  d = dates[date] ! else NOT_FOUND
  require d.day > day(now) else DATE_PASSED
  require not d.booked else DATE_BOOKED
  owner = client ?? viewer
  require owner = viewer or exists managers[viewer] else CANNOT_ASSIGN 'Only the manager can place another client\'s hold.'
  require owner != 'dev:manager' else CLIENT_REQUIRED
  require count(queue where .date = date) < 3 else QUEUE_FULL 'This date already has three holds.'
  h = insert holds { date, owner, title, expiresAt: now + 14d }
  insert queue { date, hold: h.id, ordinal: h.ordinal, expiresAt: h.expiresAt }
  insert history { date, hold: h.id, kind: 'placed', deadline: h.expiresAt }
  return h

mutation releaseHold(hold: holds):
  h = holds[hold] ! else NOT_FOUND
  q = queue[hold = hold] ! else HOLD_ENDED
  require q.kind = 'hold' else ALREADY_BOOKED
  delete queue[hold = hold]
  update holds[hold] { outcome: 'released' }
  insert history { date: h.date, hold, kind: 'released' }
  return null

mutation challenge(hold: holds): server
  h = holds[hold] ! else NOT_FOUND
  mine = queue[hold = hold] ! else HOLD_ENDED
  require mine.kind = 'hold' else ALREADY_BOOKED
  line = queue where .date = h.date first 3 by .ordinal
  firstHold = first(line) ! else HOLD_ENDED
  require firstHold.hold != hold else FIRST_CANNOT_CHALLENGE 'You already have the first hold.'
  require firstHold.challengeUntil = null else ALREADY_CHALLENGED
  deadline = min(now + 48h, firstHold.expiresAt ?? now + 48h)
  update queue[firstHold.id] { expiresAt: deadline, challengeUntil: deadline }
  update holds[firstHold.hold] { expiresAt: deadline, challengeUntil: deadline }
  insert history { date: h.date, hold: firstHold.hold, kind: 'challenged', deadline }
  return { deadline }

mutation book(hold: holds): server
  h = holds[hold] ! else NOT_FOUND
  mine = queue[hold = hold] ! else HOLD_ENDED
  require mine.kind = 'hold' else ALREADY_BOOKED
  line = queue where .date = h.date first 3 by .ordinal
  firstHold = first(line) ! else HOLD_ENDED
  require firstHold.hold = hold else FIRST_ONLY 'Only the first holder can confirm a booking.'
  for q in line:
    if q.hold != hold:
      update holds[q.hold] { outcome: 'closed' }
      insert history { date: h.date, hold: q.hold, kind: 'closed' }
      delete queue[q.id]
  update holds[hold] { outcome: 'booked' }
  update queue[mine.id] { kind: 'booking', expiresAt: null, challengeUntil: null }
  update dates[h.date] { booked: true }
  insert history { date: h.date, hold, kind: 'booked' }
  return null

-- Only the operator seat can enroll real venue staff. Signup never grants a role.
mutation grantManager(principal: principal):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert managers { principal }

query workspace():
  return { manager: exists managers[viewer] }

-- Brief notes and guest estimates remain private to the holder and venue staff.
table briefRevisions:
  hold: holds
  expectedGuests: int 1..500
  note: text 3..500
  at: time default now
  immutable hold, expectedGuests, note, at
  read <- exists holds[.hold, owner = viewer] or exists managers[viewer]
  insert <- exists holds[.hold, owner = viewer] or exists managers[viewer]
  online only

query briefHistory(hold: holds, c: cursor ?):
  h = holds[hold] ! else NOT_FOUND
  return briefRevisions where .hold = h.id last 20 by .at after c

mutation updateBrief(hold: holds, expectedGuests: int 1..500, note: text 3..500):
  h = holds[hold] ! else NOT_FOUND
  require h.owner = viewer or exists managers[viewer] else NOT_FOUND
  require h.outcome = 'held' or h.outcome = 'booked' else HOLD_ENDED
  q = queue[hold = hold] ! else HOLD_ENDED
  update holds[hold] { expectedGuests }
  revision = insert briefRevisions { hold, expectedGuests, note }
  insert history { date: h.date, hold, kind: 'brief_updated' }
  return revision
