-- Pinball League Scores.
-- Personas: alice + bob are players; carol is the scorekeeper (keepers roster).
-- A machine marked out of order takes MACHINE_DOWN on submit and its board
-- refuses, so it drops out of that week's standings. Rank points are derived
-- client-side from the ordered boards (rank r of n earns n - r + 1).

use personas alice, bob, carol

table keepers:
  principal: principal
  unique principal
  read <- allow
  insert <- exists keepers[viewer]
  delete <- exists keepers[viewer]
  online only

table machines:
  name: text 1..60
  manufacturer: text 1..60 ?
  outOfOrder: bool default false
  unique name
  read <- allow
  insert <- exists keepers[viewer]
  update <- exists keepers[viewer]
  delete <- exists keepers[viewer]
  cap 50
  online only

table weeks:
  label: text 1..40
  playedAt: time default now
  unique label
  read <- allow
  insert <- exists keepers[viewer]
  update <- exists keepers[viewer]
  cap 200
  online only

table scores:
  machine: machines
  week: weeks
  player: principal
  score: int 0..
  photoUrl: text 1..500
  verified: bool default false
  unique machine, week, player
  immutable machine, week, player
  read <- allow
  insert <- .player = viewer
  update <- (.player = viewer and .verified = false) or exists keepers[viewer]
  delete <- (.player = viewer and .verified = false) or exists keepers[viewer]
  cap 5000
  online only

-- Public per-machine season board: highest scores first.
query topScores(machine: machines, c: cursor ?):
  return scores where .machine = machine last 20 by .score after c

-- One machine in one week, highest first. Out-of-order machines are out of
-- the standings: the board refuses instead of showing a stale table.
query machineBoard(machine: machines, week: weeks, c: cursor ?):
  m = machines[machine] ! else NOT_FOUND
  require not m.outOfOrder else MACHINE_DOWN 'That machine is out of order.'
  return scores where .machine = machine and .week = week last 50 by .score after c

-- Every score submitted in a week, highest first (grouped by machine in UI).
query weekScores(week: weeks, c: cursor ?):
  return scores where .week = week last 100 by .score after c

query myScores(c: cursor ?):
  return scores where .player = viewer last 50 by .id after c

query machinesList(c: cursor ?):
  return machines first 50 by .id after c

query weeksList(c: cursor ?):
  return weeks first 50 by .id after c

mutation addMachine(name: text 1..60, manufacturer: text 1..60 ?):
  require exists keepers[viewer] else NOT_KEEPER 'Only the scorekeeper manages machines.'
  return insert machines { name, manufacturer }

mutation setOutOfOrder(machine: machines, outOfOrder: bool):
  require exists keepers[viewer] else NOT_KEEPER 'Only the scorekeeper manages machines.'
  update machines[machine] { outOfOrder }
  return null

mutation addWeek(label: text 1..40):
  require exists keepers[viewer] else NOT_KEEPER 'Only the scorekeeper manages weeks.'
  return insert weeks { label }

mutation submitScore(machine: machines, week: weeks, score: int 0.., photoUrl: text 1..500):
  m = machines[machine] ! else NOT_FOUND
  w = weeks[week] ! else NOT_FOUND
  require not m.outOfOrder else MACHINE_DOWN 'That machine is out of order.'
  return upsert scores[machine, week, viewer] { machine, week, player: viewer, score, photoUrl }

mutation verifyScore(scoreId: scores, verified: bool):
  require exists keepers[viewer] else NOT_KEEPER 'Only the scorekeeper verifies scores.'
  update scores[scoreId] { verified }
  return null

mutation removeScore(scoreId: scores):
  s = scores[scoreId] ! else NOT_FOUND
  require s.player = viewer or exists keepers[viewer] else NOT_ALLOWED 'Only the submitter or the scorekeeper removes a score.'
  delete scores[scoreId]
  return null
