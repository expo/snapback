-- Go Club Handicap Ladder.
-- A ranked ladder: members challenge up to 3 places above them; handicap
-- stones equal the ladder-position difference. Results need both players'
-- confirmation before the organizer applies the ladder update. Challenges
-- lapse 14 days after they are proposed. Defenders may decline at most 3
-- challenges per season. The organizer freezes inactive positions.
use personas alice, bob, carol

table organizers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  online only

table players:
  principal: principal
  handle: text 3..20 format handle
  position: int
  frozen: bool default false
  declinesUsed: int default 0
  unique principal
  unique position
  unique handle
  public 'The ladder is visible to every member.'
  insert <- exists organizers[viewer]
  update <- .principal = viewer or exists organizers[viewer]
  immutable principal
  cap 100
  online only

table challenges:
  challenger: principal
  defender: principal
  handicap: int 1..9
  proposedTime: time
  deadline: time
  createdAt: time default now
  status: enum('proposed', 'accepted', 'declined', 'played', 'confirmed', 'withdrawn', 'lapsed')
  winner: principal ?
  reporter: principal ?
  applied: bool default false
  note: text <=140 ?
  read <- .challenger = viewer or .defender = viewer or exists organizers[viewer]
  insert <- .challenger = viewer
  update <- .challenger = viewer or .defender = viewer or exists organizers[viewer]
  immutable challenger, defender, handicap, createdAt, deadline
  cap 200
  online only

query ladder(c: cursor ?):
  return players first 100 by .position after c

query myHistory(c: cursor ?):
  return challenges where .challenger = viewer or .defender = viewer last 50 by .createdAt after c

query allChallenges(c: cursor ?):
  require exists organizers[viewer] else NOT_ORGANIZER 'Only the organizer sees every challenge.'
  return challenges last 50 by .createdAt after c

query amOrganizer():
  return exists organizers[viewer]

query handicapPreview(defender: principal):
  me = players[principal = viewer] ! else NOT_REGISTERED 'Join the ladder first.'
  them = players[principal = defender] ! else NOT_REGISTERED 'That player is not on the ladder.'
  diff = me.position - them.position
  return { challenger: me.handle, defender: them.handle, diff, handicap: diff if diff >= 1 else 0 }

mutation addPlayer(member: principal, handle: text 3..20, position: int):
  require exists organizers[viewer] else NOT_ORGANIZER 'Only the organizer adds players.'
  require position >= 1 else BAD_POSITION 'Ladder positions start at 1.'
  return insert players { principal: member, handle, position, frozen: false, declinesUsed: 0 }

mutation freezePlayer(p: players, frozen: bool):
  require exists organizers[viewer] else NOT_ORGANIZER 'Only the organizer freezes positions.'
  row = players[p] ! else NOT_FOUND
  update players[row] { frozen }
  return null

mutation resetDeclines(p: players):
  require exists organizers[viewer] else NOT_ORGANIZER 'Only the organizer opens a new season.'
  row = players[p] ! else NOT_FOUND
  update players[row] { declinesUsed: 0 }
  return null

mutation proposeChallenge(defender: principal, proposedTime: time, note: text <=140 ?):
  me = players[principal = viewer] ! else NOT_REGISTERED 'Join the ladder first.'
  them = players[principal = defender] ! else NOT_REGISTERED 'That player is not on the ladder.'
  require defender != viewer else SELF_CHALLENGE 'You cannot challenge yourself.'
  require not me.frozen else FROZEN 'Your position is frozen.'
  require not them.frozen else FROZEN 'That position is frozen.'
  require proposedTime > now else BAD_TIME 'Propose a future time.'
  diff = me.position - them.position
  require diff >= 1 and diff <= 3 else BAD_RANGE 'Challenge 1 to 3 places above you.'
  return insert challenges { challenger: viewer, defender, handicap: diff, proposedTime, deadline: now + 14d, status: 'proposed', note }

mutation acceptChallenge(challengeId: challenges):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.defender = viewer else NOT_DEFENDER 'Only the defender accepts.'
  require c.status = 'proposed' else BAD_STATUS 'Only a proposed challenge can be accepted.'
  update challenges[c] { status: 'accepted' }
  return null

mutation declineChallenge(challengeId: challenges):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.defender = viewer else NOT_DEFENDER 'Only the defender declines.'
  require c.status = 'proposed' else BAD_STATUS 'Only a proposed challenge can be declined.'
  d = players[principal = viewer] ! else NOT_REGISTERED
  require d.declinesUsed < 3 else DECLINES_EXHAUSTED 'Season decline limit reached (3).'
  update players[d] { declinesUsed: d.declinesUsed + 1 }
  update challenges[c] { status: 'declined' }
  return null

mutation retimeChallenge(challengeId: challenges, proposedTime: time):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.challenger = viewer else NOT_CHALLENGER 'Only the challenger proposes times.'
  require c.status = 'proposed' else BAD_STATUS 'Only a proposed challenge can be retimed.'
  require proposedTime > now else BAD_TIME 'Propose a future time.'
  update challenges[c] { proposedTime }
  return null

mutation withdrawChallenge(challengeId: challenges):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.challenger = viewer else NOT_CHALLENGER 'Only the challenger withdraws.'
  require c.status = 'proposed' or c.status = 'accepted' else BAD_STATUS 'Only an open challenge can be withdrawn.'
  update challenges[c] { status: 'withdrawn' }
  return null

mutation reportResult(challengeId: challenges, winner: principal):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.challenger = viewer or c.defender = viewer else NOT_PLAYER 'Only the players report.'
  require c.status = 'accepted' else BAD_STATUS 'Only an accepted challenge can report a result.'
  require winner = c.challenger or winner = c.defender else BAD_WINNER 'The winner must be a player.'
  update challenges[c] { winner, reporter: viewer, status: 'played' }
  return null

mutation confirmResult(challengeId: challenges):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.challenger = viewer or c.defender = viewer else NOT_PLAYER 'Only the players confirm.'
  require c.status = 'played' else BAD_STATUS 'There is no reported result to confirm.'
  require c.reporter != viewer else NOT_YET 'The other player must confirm.'
  update challenges[c] { status: 'confirmed' }
  return null

mutation applyResult(challengeId: challenges):
  require exists organizers[viewer] else NOT_ORGANIZER 'Only the organizer applies results.'
  c = challenges[challengeId] ! else NOT_FOUND
  require c.status = 'confirmed' else BAD_STATUS 'Both players must confirm first.'
  require not c.applied else ALREADY_APPLIED 'This result is already applied.'
  if c.winner = c.challenger:
    cp = players[principal = c.challenger] ! else NOT_REGISTERED
    dp = players[principal = c.defender] ! else NOT_REGISTERED
    update players[cp] { position: 0 }
    update players[dp] { position: cp.position }
    update players[cp] { position: dp.position }
  update challenges[c] { applied: true }
  return null

mutation lapseChallenge(challengeId: challenges):
  c = challenges[challengeId] ! else NOT_FOUND
  require c.challenger = viewer or c.defender = viewer or exists organizers[viewer] else NOT_PLAYER 'Only the players or organizer lapse this.'
  require c.status = 'proposed' or c.status = 'accepted' else BAD_STATUS 'Only an open challenge can lapse.'
  require now >= c.deadline else NOT_DUE 'The challenge has not lapsed yet.'
  update challenges[c] { status: 'lapsed' }
  return null
