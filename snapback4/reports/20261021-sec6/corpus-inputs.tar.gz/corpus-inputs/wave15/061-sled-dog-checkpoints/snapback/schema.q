-- Sled Dog Race Checkpoints.
--
-- Volunteers at remote checkpoints record each team's arrival and departure
-- offline (checkins sync publicly so every device holds them). Mandatory rest
-- is enforced per checkpoint; recordDeparture computes earlyDeparture and the
-- marshal (official) reviews it in flags. Vets log checks per dog and can drop
-- a dog; vet notes are readable only by race staff and the team's own musher.
-- The public tracker (teams, checkpoints, checkins, dogs) is world-readable.
use personas alice, bob, carol, dave

-- Roster: alice = volunteer, bob = musher (no row), carol = vet,
-- dave = official (race marshal). Seeded via fixtures as the system.
table staff:
  principal: principal
  role: enum('volunteer', 'vet', 'official')
  unique principal
  read <- .principal = viewer
  sync to .principal

table teams:
  name: text 1..80
  musher: principal
  unique name
  unique musher
  immutable musher
  public 'public race tracker'
  insert <- exists staff[viewer, role = 'official']
  update <- exists staff[viewer, role = 'official']
  sync public last 200 by .id

table checkpoints:
  name: text 1..60
  seq: int 1..50
  restMinutes: int 0..1440
  unique name
  unique seq
  immutable seq
  public 'public race tracker'
  insert <- exists staff[viewer, role = 'official']
  update <- exists staff[viewer, role = 'official']
  sync public last 50 by .seq, .id

table checkins:
  team: teams
  checkpoint: checkpoints
  arrivedAt: time
  departedAt: time ?
  recordedBy: principal
  earlyDeparture: bool default false
  unique team, checkpoint
  immutable team, checkpoint
  cap 200 by team
  public 'public race tracker'
  insert <- exists staff[viewer, role = 'volunteer'] or exists staff[viewer, role = 'official']
  update <- exists staff[viewer, role = 'volunteer'] or exists staff[viewer, role = 'official']
  delete <- exists staff[viewer, role = 'official']
  sync public last 500 by .arrivedAt, .id

table dogs:
  team: teams
  name: text 1..40
  active: bool default true
  unique team, name
  immutable team
  cap 16 by team
  public 'public team rosters'
  insert <- exists staff[viewer, role = 'official']
  update <- exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'official']
  sync public last 500 by .id

table vetchecks:
  dog: dogs
  team: teams
  musher: principal
  checkedAt: time
  status: enum('passed', 'concern', 'dropped')
  notes: text <=500 ?
  immutable dog, team, musher
  cap 100 by dog
  read <- .musher = viewer or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'official']
  insert <- exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'official']
  update <- exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'official']
  online only

query listTeams(c: cursor ?):
  return teams last 50 by .id after c

query listCheckpoints(c: cursor ?):
  return checkpoints last 20 by .seq, .id after c

query recentCheckins(c: cursor ?):
  return checkins last 100 by .arrivedAt, .id after c

query teamTimes(team: teams, c: cursor ?):
  return checkins where .team = team last 100 by .arrivedAt, .id after c

query dogsOf(team: teams, c: cursor ?):
  return dogs where .team = team last 20 by .id after c

query myTeams(c: cursor ?):
  return teams where .musher = viewer last 20 by .id after c

query checksFor(team: teams, c: cursor ?):
  return vetchecks where .team = team last 50 by .checkedAt, .id after c

query flags(c: cursor ?):
  require exists staff[viewer, role = 'official'] else NOT_OFFICIAL
  return checkins where .earlyDeparture = true first 100 by .arrivedAt, .id after c

mutation addTeam(name: text 1..80, musher: principal):
  require exists staff[viewer, role = 'official'] else NOT_OFFICIAL
  return insert teams { name, musher }

mutation addCheckpoint(name: text 1..60, seq: int 1..50, restMinutes: int 0..1440):
  require exists staff[viewer, role = 'official'] else NOT_OFFICIAL
  return insert checkpoints { name, seq, restMinutes }

mutation recordArrival(team: teams, checkpoint: checkpoints, arrivedAt: time):
  require exists staff[viewer, role = 'volunteer'] or exists staff[viewer, role = 'official'] else NOT_STAFF
  t = teams[team] ! else NOT_FOUND
  cp = checkpoints[checkpoint] ! else NOT_FOUND
  return insert checkins { team, checkpoint, arrivedAt, recordedBy: viewer }

mutation recordDeparture(checkin: checkins, departedAt: time):
  require exists staff[viewer, role = 'volunteer'] or exists staff[viewer, role = 'official'] else NOT_STAFF
  c = checkins[checkin] ! else NOT_FOUND
  cp = checkpoints[c.checkpoint] ! else NOT_FOUND
  update checkins[checkin] { departedAt, earlyDeparture: departedAt - c.arrivedAt < cp.restMinutes * 60000 }
  return null

mutation registerDog(team: teams, name: text 1..40):
  require exists staff[viewer, role = 'official'] else NOT_OFFICIAL
  t = teams[team] ! else NOT_FOUND
  return insert dogs { team, name }

mutation logCheck(dog: dogs, status: enum('passed', 'concern', 'dropped'), notes: text <=500 ?, checkedAt: time):
  require exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'official'] else NOT_VET
  d = dogs[dog] ! else NOT_FOUND
  t = teams[d.team] ! else NOT_FOUND
  insert vetchecks { dog, team: d.team, musher: t.musher, checkedAt, status, notes }
  update dogs[dog] { active: status != 'dropped' }
  return null
