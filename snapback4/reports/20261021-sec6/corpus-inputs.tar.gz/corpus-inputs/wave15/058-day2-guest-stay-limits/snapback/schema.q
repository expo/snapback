-- Guest Stay Limits: a housing co-op caps unapproved guest stays at 14
-- nights per guest per quarter. Residents log arrivals/departures;
-- the membership committee sees per-unit presence (no names) plus any
-- filed approval requests (with names). Rows expire a year after arrival.
use identity password
use personas alice, bob, carol

-- Membership-committee roster: one row per committee member. Signup grants
-- no role; the operator seat bootstraps the first members in production
-- (mint with `snapback4 token --service ops --release ./deploy`).
table committee:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

-- Private guest log: only the host resident may read or write it.
table stays:
  host: principal
  guestName: text 1..60
  unit: text 1..20
  arrive: time
  depart: time ?
  nights: int 1..365
  quarter: text 1..7
  purpose: enum('visit', 'caregiving', 'other') default 'visit'
  expiresAt: time ?
  immutable host
  read <- .host = viewer
  insert <- .host = viewer
  update <- .host = viewer
  delete <- .host = viewer
  cap 500 by host
  expire at .expiresAt
  sync to .host last 200 by .arrive

-- Committee-visible copy of the same log without guest names, written
-- atomically by the same mutations (one table per audience).
table presence:
  stay: stays on delete cascade
  host: principal
  unit: text 1..20
  arrive: time
  depart: time ?
  nights: int 1..365
  quarter: text 1..7
  purpose: enum('visit', 'caregiving', 'other') default 'visit'
  expiresAt: time ?
  unique stay
  immutable stay, host
  read <- .host = viewer or exists committee[viewer]
  insert <- .host = viewer
  update <- .host = viewer
  delete <- .host = viewer
  cap 500 by host
  expire at .expiresAt
  online only

-- Approval requests: the host's rows plus committee review.
table requests:
  host: principal
  guestName: text 1..60
  unit: text 1..20
  quarter: text 1..7
  nights: int 1..365
  status: enum('pending', 'approved', 'denied', 'withdrawn') default 'pending'
  createdAt: time default now
  immutable host
  read <- .host = viewer or exists committee[viewer]
  insert <- .host = viewer
  update <- .host = viewer or exists committee[viewer]
  delete <- .host = viewer
  cap 200 by host
  online only

-- Committee-granted extra-night allowance: a long stay (for example a
-- live-in caregiver) the committee excuses from the 14-night trigger for one
-- guest and quarter. Visible to the host and the committee.
table waivers:
  host: principal
  guestName: text 1..60
  unit: text 1..20
  quarter: text 1..7
  extraNights: int 1..365
  grantedAt: time default now
  unique host, guestName, quarter
  immutable host
  read <- .host = viewer or exists committee[viewer]
  insert <- exists committee[viewer]
  update <- exists committee[viewer]
  delete <- exists committee[viewer]
  cap 200 by host
  online only

-- Nights per host per guest per quarter (drives the 14-night trigger).
view quarterNights: sum stays of .nights by .host, .guestName, .quarter

query myStays(c: cursor ?):
  return stays where .host = viewer last 50 by .arrive after c

query guestQuarterTotal(guestName: text 1..60, quarter: text 1..7):
  return quarterNights[viewer, guestName, quarter]

query census(unit: text 1..20, c: cursor ?):
  return presence where .unit = unit last 100 by .arrive after c { id, host, unit, arrive, depart, nights, quarter, purpose }

query myRequests(c: cursor ?):
  return requests where .host = viewer last 50 by .createdAt after c

query allRequests(c: cursor ?):
  require exists committee[viewer] else NOT_COMMITTEE 'Only the membership committee reviews requests.'
  return requests last 50 by .createdAt after c

query myCommitteeRole():
  return committee where .principal = viewer first 1

query myWaivers(c: cursor ?):
  return waivers where .host = viewer last 50 by .grantedAt after c

query allWaivers(c: cursor ?):
  require exists committee[viewer] else NOT_COMMITTEE 'Only the membership committee reviews waivers.'
  return waivers last 50 by .grantedAt after c

mutation logStay(guestName: text 1..60, unit: text 1..20, arrive: time, depart: time ?, nights: int 1..365, quarter: text 1..7, purpose: enum('visit', 'caregiving', 'other')):
  require depart = null or depart >= arrive else BAD_DATES 'Departure must be on or after arrival.'
  s = insert stays { host: viewer, guestName, unit, arrive, depart, nights, quarter, purpose, expiresAt: arrive + 366d }
  insert presence { stay: s.id, host: viewer, unit, arrive, depart, nights, quarter, purpose, expiresAt: arrive + 366d }
  return s

mutation checkoutStay(stay: stays, depart: time, nights: int 1..365):
  s = stays[stay] ! else NOT_FOUND
  require depart >= s.arrive else BAD_DATES 'Departure must be on or after arrival.'
  update stays[stay] { depart, nights }
  update presence[stay] { depart, nights }
  return null

mutation fileRequest(guestName: text 1..60, unit: text 1..20, quarter: text 1..7, nights: int 1..365):
  require nights >= 14 else UNDER_LIMIT 'Approval is required only at 14 or more nights in the quarter.'
  return insert requests { host: viewer, guestName, unit, quarter, nights }

mutation decideRequest(request: requests, approve: bool):
  require exists committee[viewer] else NOT_COMMITTEE 'Only the membership committee decides requests.'
  r = requests[request] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_DECIDED 'This request has already been decided.'
  update requests[request] { status: 'approved' if approve else 'denied' }
  return null

mutation withdrawRequest(request: requests):
  r = requests[request] ! else NOT_FOUND
  require r.host = viewer else NOT_OWNER 'Only the host may withdraw this request.'
  require r.status = 'pending' else ALREADY_DECIDED 'This request has already been decided.'
  update requests[request] { status: 'withdrawn' }
  return null

mutation removeStay(stay: stays):
  s = stays[stay] ! else NOT_FOUND
  delete stays[stay]
  return null

mutation grantWaiver(host: principal, guestName: text 1..60, unit: text 1..20, quarter: text 1..7, extraNights: int 1..365):
  require exists committee[viewer] else NOT_COMMITTEE 'Only the membership committee grants waivers.'
  return insert waivers { host, guestName, unit, quarter, extraNights }

mutation bootstrapCommittee(seat: principal):
  require viewer = 'service:ops' else NOT_OPERATOR 'Only the operator seat seats the committee.'
  return insert committee { principal: seat }
