use personas alice, bob, tess, morgan

table roles:
  principal: principal
  role: enum('technician', 'manager')
  unique principal
  read <- .principal = viewer
  online only

table instruments:
  name: text 1..80
  description: text 1..200
  maintenance: bool default false
  mode: enum('standby', 'calibrate', 'measure') default 'standby'
  public 'All lab users watch instrument status.'
  update <- exists leases[instrument = .id, owner = viewer] or exists roles[principal = viewer, role = 'technician']
  online only

table sessions:
  instrument: instruments
  owner: principal
  startedAt: time
  expiresAt: time
  endedAt: time ?
  outcome: enum('active', 'released', 'expired', 'overridden') default 'active'
  durationMs: int 0.. default 0
  immutable instrument, owner, startedAt
  read <- .owner = viewer or exists roles[principal = viewer, role = 'manager']
  insert <- .owner = viewer
  update <- .owner = viewer or exists roles[principal = viewer, role = 'technician']
  online only

table leases:
  instrument: instruments
  owner: principal
  session: sessions
  startedAt: time
  expiresAt: time
  unique instrument else IN_USE
  immutable instrument, owner, session, startedAt
  public 'Current control holder and deadline are visible to lab observers.'
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer or exists roles[principal = viewer, role = 'technician']
  expire at .expiresAt
  online only

table logs:
  instrument: instruments
  owner: principal
  actor: principal
  action: enum('acquired', 'renewed', 'released', 'expired', 'overridden', 'command', 'maintenance')
  detail: text 1..240
  at: time default now
  read <- .owner = viewer or exists roles[principal = viewer, role = 'manager']
  insert <- .actor = viewer and (.owner = viewer or exists roles[principal = viewer, role = 'technician'])
  online only

view usage: sum sessions of .durationMs by .owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'manager']

query instrumentsBoard():
  return instruments first 50 by .name { id, name, description, maintenance, mode: .mode if exists leases[instrument = .id] else 'standby', lease: leases[instrument = .id] }
query mySessions():
  return sessions where .owner = viewer last 100 by .startedAt
query myLogs():
  return logs where .owner = viewer last 100 by .at
query billing(owner: principal):
  require exists roles[principal = viewer, role = 'manager'] else MANAGER_ONLY
  return usage[owner]
query sessionFor(session: sessions):
  return sessions[session]

mutation acquire(instrument: instruments, minutes: int 1..15):
  i = instruments[instrument] ! else NOT_FOUND
  require not i.maintenance else MAINTENANCE
  require not exists leases[instrument = instrument] else IN_USE
  s = insert sessions { instrument, owner: viewer, startedAt: now, expiresAt: now + minutes * 1m }
  l = insert leases { instrument, owner: viewer, session: s.id, startedAt: now, expiresAt: now + minutes * 1m }
  update instruments[instrument] { mode: 'standby' }
  insert logs { instrument, owner: viewer, actor: viewer, action: 'acquired', detail: 'Exclusive control acquired.' }
  return l

mutation renew(instrument: instruments, minutes: int 1..15):
  l = leases[instrument = instrument] ! else NO_LEASE
  require l.owner = viewer else OWNER_ONLY
  require now + minutes * 1m > l.expiresAt else WOULD_SHORTEN 'Choose a duration that extends the current deadline.'
  update leases[l.id] { expiresAt: now + minutes * 1m }
  update sessions[l.session] { expiresAt: now + minutes * 1m }
  insert logs { instrument, owner: viewer, actor: viewer, action: 'renewed', detail: 'Control lease renewed.' }

mutation release(instrument: instruments):
  l = leases[instrument = instrument] ! else NO_LEASE
  require l.owner = viewer else OWNER_ONLY
  update sessions[l.session] { endedAt: now, outcome: 'released', durationMs: now - l.startedAt }
  update instruments[instrument] { mode: 'standby' }
  delete leases[l.id]
  insert logs { instrument, owner: viewer, actor: viewer, action: 'released', detail: 'Control released.' }

mutation command(instrument: instruments, mode: enum('standby', 'calibrate', 'measure')):
  l = leases[instrument = instrument] ! else NO_LEASE
  require l.owner = viewer else OWNER_ONLY
  update instruments[instrument] { mode }
  insert logs { instrument, owner: viewer, actor: viewer, action: 'command', detail: mode }

mutation maintenance(instrument: instruments, enabled: bool, reason: text 5..200):
  require exists roles[principal = viewer, role = 'technician'] else TECHNICIAN_ONLY
  i = instruments[instrument] ! else NOT_FOUND
  if exists leases[instrument = instrument]:
    l = leases[instrument = instrument] ! else NO_LEASE
    update sessions[l.session] { endedAt: now, outcome: 'overridden', durationMs: now - l.startedAt }
    delete leases[l.id]
    insert logs { instrument, owner: l.owner, actor: viewer, action: 'overridden', detail: reason }
  update instruments[instrument] { maintenance: enabled, mode: 'standby' }
  insert logs { instrument, owner: viewer, actor: viewer, action: 'maintenance', detail: reason }

job expireSessions():
  for s in sessions:
    if s.outcome = 'active' and s.expiresAt <= now:
      update sessions[s.id] { endedAt: s.expiresAt, outcome: 'expired', durationMs: s.expiresAt - s.startedAt }
      if not exists leases[instrument = s.instrument]:
        update instruments[s.instrument] { mode: 'standby' }
      insert logs { instrument: s.instrument, owner: s.owner, actor: s.owner, action: 'expired', detail: 'Lease expired automatically.' }
schedule expirySweep every 1m: expireSessions
