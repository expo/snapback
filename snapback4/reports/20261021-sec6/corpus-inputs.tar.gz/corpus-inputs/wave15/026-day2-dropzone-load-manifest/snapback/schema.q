-- Dropzone Load Manifest.
-- Jumpers sign up for aircraft loads; the server refuses lapsed reserve
-- repacks or memberships. Manifest staff order exits and approve loads.
-- Pilots see weight only; safety officers see the audit trail.
use personas alice, bob, manny, pete, sam
use identity

table roles:
  principal: principal
  role: enum('manifest', 'pilot', 'safety')
  unique principal
  read <- .principal = viewer or exists roles[viewer] or viewer = 'service:ops'
  insert <- exists roles[viewer, role = 'safety'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'safety']
  delete <- exists roles[viewer, role = 'safety']
  online only

table jumpers:
  principal: principal
  name: text 1..60
  email: text 3..120
  phone: text 3..30 ?
  weightKg: int 30..250
  reserveRepackAt: time
  membershipExpiresAt: time
  license: enum('student', 'a', 'b', 'c', 'd', 'tandem', 'instructor')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'safety']
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table loads:
  aircraft: text 1..40
  slotTime: time
  status: enum('open', 'manifesting', 'approved', 'boarded', 'held') default 'open'
  holdCount: int 0..1000000 default 0
  maxSlots: int 1..40
  approvedBy: principal ?
  read <- allow
  insert <- exists roles[viewer, role = 'manifest']
  update <- exists roles[viewer, role = 'manifest']
  online only

table slots:
  load: loads on delete restrict
  owner: principal
  jumper: jumpers
  exitOrder: int 0..100 ?
  weightKg: int 30..250
  overridden: bool default false
  overrideReason: text 1..200 ?
  immutable load, owner, jumper
  unique load, jumper
  cap 40 by load
  read <- .owner = viewer or exists roles[viewer]
  insert <- .owner = viewer or exists roles[viewer, role = 'manifest']
  update <- exists roles[viewer, role = 'manifest']
  delete <- .owner = viewer or exists roles[viewer, role = 'manifest']
  online only

table audit_events:
  load: loads ? on delete cascade
  actor: principal
  action: text 1..40
  detail: text 1..300
  at: time default now
  immutable load, actor, action, detail, at
  read <- exists roles[viewer, role = 'safety'] or exists roles[viewer, role = 'manifest']
  insert <- .actor = viewer
  online only

view jumpTotals: count slots by .owner
  read <- .owner = viewer or exists roles[viewer]
  online only

view loadWeights: sum slots of .weightKg by .load
  read <- allow
  online only

view slotsCount: count slots by .load
  read <- allow
  online only

query loads(c: cursor ?):
  return loads last 50 by .slotTime after c

query mySlots(c: cursor ?):
  return slots where .owner = viewer last 50 by .id after c { id, load, exitOrder, weightKg, overridden, flight: loads[.load] }

query myTotals():
  return jumpTotals[viewer]

query loadSlots(load: loads, c: cursor ?):
  require exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'safety'] else NOT_MANIFEST
  return slots where .load = load first 50 by .exitOrder after c { id, exitOrder, weightKg, overridden, overrideReason, jumper: jumpers[.jumper] }

query pilotManifest(load: loads, c: cursor ?):
  require exists roles[viewer] else NOT_CREW
  return slots where .load = load first 50 by .exitOrder after c { id, exitOrder, weightKg }

query loadWeight(load: loads):
  return loadWeights[load]

query roster(c: cursor ?):
  require exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'safety'] else NOT_MANIFEST
  return jumpers last 50 by .id after c { id, name, principal }

query auditFor(load: loads, c: cursor ?):
  require exists roles[viewer, role = 'safety'] or exists roles[viewer, role = 'manifest'] else NOT_SAFETY
  return audit_events where .load = load last 50 by .at after c

mutation register(name: text 1..60, email: text 3..120, phone: text 3..30 ?, weightKg: int 30..250, reserveRepackAt: time, membershipExpiresAt: time, license: enum('student', 'a', 'b', 'c', 'd', 'tandem', 'instructor')):
  upsert jumpers[principal = viewer] { principal: viewer, name, email, phone, weightKg, reserveRepackAt, membershipExpiresAt, license }
  return jumpers[principal = viewer]

mutation createLoad(aircraft: text 1..40, slotTime: time, maxSlots: int 1..40):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  return insert loads { aircraft, slotTime, maxSlots }

mutation signup(load: loads):
  l = loads[load] ! else NOT_FOUND
  require l.status = 'open' or l.status = 'manifesting' else LOAD_CLOSED 'This load is no longer taking signups.'
  j = jumpers[principal = viewer] ! else NO_PROFILE 'Register as a jumper first.'
  require j.reserveRepackAt > now - 180d else REPACK_LAPSED 'Reserve repack is older than 180 days.'
  require j.membershipExpiresAt > now else MEMBERSHIP_LAPSED 'Membership has expired.'
  require slotsCount[load] < l.maxSlots else LOAD_FULL 'This load is full.'
  s = insert slots { load, owner: viewer, jumper: j.id, weightKg: j.weightKg }
  insert audit_events { load, actor: viewer, action: 'signup', detail: 'Self signup' }
  return s

mutation overrideSignup(load: loads, jumper: jumpers, reason: text 1..200):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  l = loads[load] ! else NOT_FOUND
  require l.status = 'open' or l.status = 'manifesting' else LOAD_CLOSED 'This load is no longer taking signups.'
  j = jumpers[jumper] ! else NOT_FOUND
  s = insert slots { load, owner: j.principal, jumper: j.id, weightKg: j.weightKg, overridden: true, overrideReason: reason }
  insert audit_events { load, actor: viewer, action: 'override', detail: reason }
  return s

mutation withdraw(slot: slots):
  s = slots[slot] ! else NOT_FOUND
  delete slots[slot]
  insert audit_events { load: s.load, actor: viewer, action: 'withdraw', detail: 'Slot withdrawn' }
  return null

mutation setExitOrder(slot: slots, exitOrder: int 0..100):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  s = slots[slot] ! else NOT_FOUND
  update slots[slot] { exitOrder }
  insert audit_events { load: s.load, actor: viewer, action: 'order', detail: 'Exit order set' }
  return null

mutation approveLoad(load: loads):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  l = loads[load] ! else NOT_FOUND
  require l.status = 'open' or l.status = 'manifesting' else LOAD_CLOSED 'This load cannot be approved from its current status.'
  update loads[load] { status: 'approved', approvedBy: viewer }
  insert audit_events { load, actor: viewer, action: 'approve', detail: 'Load approved for boarding' }
  return null

mutation boardLoad(load: loads):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  l = loads[load] ! else NOT_FOUND
  require l.status = 'approved' else NOT_APPROVED 'Approve the load before boarding.'
  update loads[load] { status: 'boarded' }
  insert audit_events { load, actor: viewer, action: 'board', detail: 'Load boarded' }
  return null

-- Only a locally minted operator seat or existing safety officer grants roles.
mutation grantRole(principal: principal, role: enum('manifest', 'pilot', 'safety')):
  require viewer = 'service:ops' or exists roles[viewer, role = 'safety'] else NOT_SAFETY
  return insert roles { principal, role }

query myRole():
  return roles[viewer]

query myProfile():
  return jumpers[principal = viewer]

-- Reasons remain private to manifest and safety staff. Pilots/jumpers see
-- the load's held status, without staff notes or passenger details.
table load_holds:
  load: loads on delete restrict
  actor: principal
  action: enum('hold', 'release')
  reason: text 1..200
  at: time default now
  immutable load, actor, action, reason, at
  read <- exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'safety']
  insert <- .actor = viewer and exists roles[viewer, role = 'manifest']
  online only

query holdHistory(load: loads, c: cursor ?):
  require exists roles[viewer, role = 'manifest'] or exists roles[viewer, role = 'safety'] else NOT_SAFETY
  return load_holds where .load = load last 50 by .at after c

mutation holdLoad(load: loads, reason: text 1..200):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  l = loads[load] ! else NOT_FOUND
  require l.status = 'open' or l.status = 'manifesting' or l.status = 'approved' else CANNOT_HOLD 'Only an unboarded, active load can be held.'
  update loads[load] { status: 'held', holdCount: l.holdCount + 1, approvedBy: null }
  insert load_holds { load, actor: viewer, action: 'hold', reason }
  insert audit_events { load, actor: viewer, action: 'hold', detail: reason }
  return loads[load]

mutation releaseHold(load: loads, reason: text 1..200):
  require exists roles[viewer, role = 'manifest'] else NOT_MANIFEST
  l = loads[load] ! else NOT_FOUND
  require l.status = 'held' else NOT_HELD 'This load is not on hold.'
  update loads[load] { status: 'manifesting', approvedBy: null }
  insert load_holds { load, actor: viewer, action: 'release', reason }
  insert audit_events { load, actor: viewer, action: 'release', detail: reason }
  return loads[load]
