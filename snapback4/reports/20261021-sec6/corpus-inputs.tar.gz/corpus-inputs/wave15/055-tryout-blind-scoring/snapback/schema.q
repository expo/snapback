use personas alice, bob, coach, director, parent, outsider

table staff:
  principal: principal
  role: enum('coach', 'director')
  unique principal
  read <- .principal = viewer
  online only

table tryouts:
  title: text 1..80
  closed: bool default false
  releaseAt: time
  read <- allow
  update <- exists evaluators[.id, viewer] or exists staff[viewer, role = 'director']
  immutable title, releaseAt
  cap 1
  online only

table evaluators:
  tryout: tryouts
  principal: principal
  submitted: bool default false
  unique tryout, principal
  read <- allow
  update <- .principal = viewer
  immutable tryout, principal
  cap 2 by tryout
  online only

table players:
  tryout: tryouts
  number: int 1..999
  unique tryout, number
  read <- exists evaluators[.tryout, viewer] or exists staff[viewer]
  immutable tryout, number
  cap 100 by tryout
  online only

table registrations:
  player: players
  parent: principal
  unique player
  read <- .parent = viewer or exists staff[viewer]
  immutable player, parent
  online only

table scores:
  tryout: tryouts
  player: players
  evaluator: principal
  technique: int 1..5
  teamwork: int 1..5
  total: int 2..10
  unique player, evaluator
  read <- .evaluator = viewer or (exists tryouts[.tryout, closed = true] and exists staff[viewer])
  insert <- .evaluator = viewer and exists evaluators[.tryout, viewer, submitted = false] and exists tryouts[.tryout, closed = false]
  update <- (.evaluator = viewer and exists evaluators[.tryout, viewer, submitted = false] and exists tryouts[.tryout, closed = false]) or exists staff[viewer, role = 'director']
  immutable tryout, player, evaluator
  online only

table decisions:
  player: players
  choice: enum('selected', 'reserve', 'declined')
  unique player
  read <- exists staff[viewer]
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  immutable player
  online only

table releases:
  player: players
  parent: principal
  number: int 1..999
  choice: enum('selected', 'reserve', 'declined')
  opensAt: time
  unique player
  read <- .parent = viewer
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  immutable player, parent, number, opensAt
  not before .opensAt
  online only

table audit:
  actor: principal
  player: players
  action: text 1..40
  beforeValue: text <=100
  afterValue: text <=100
  reason: text 5..200
  beforeTechnique: int 1..5 ?
  beforeTeamwork: int 1..5 ?
  afterTechnique: int 1..5 ?
  afterTeamwork: int 1..5 ?
  at: time default now
  read <- exists staff[viewer, role = 'director']
  insert <- .actor = viewer and exists staff[viewer]
  online only

query overview():
  return { tryout: tryouts first 1 by .id, evaluators: evaluators first 2 by .id, role: staff[viewer], seat: evaluators[tryout = 'tryout', principal = viewer] }

query numberedPlayers():
  return players first 100 by .number

query myScores():
  return scores where .evaluator = viewer first 100 by .player

query reviewScores():
  require exists staff[viewer] else STAFF_ONLY
  t = tryouts['tryout'] ! else NOT_FOUND
  require t.closed else SCORING_SEALED 'Scores stay sealed until every evaluator submits.'
  return scores first 200 by .player

query roster():
  require exists staff[viewer] else STAFF_ONLY
  return decisions first 100 by .player

query parentDecisions():
  return releases where .parent = viewer first 100 by .number

query changeAudit():
  require exists staff[viewer, role = 'director'] else DIRECTOR_ONLY
  return audit last 100 by .at

mutation saveScore(player: players, technique: int 1..5, teamwork: int 1..5):
  p = players[player] ! else NOT_FOUND
  t = tryouts[p.tryout] ! else NOT_FOUND
  require not t.closed else SCORING_CLOSED
  seat = evaluators[p.tryout, viewer] ! else NOT_EVALUATOR
  require not seat.submitted else ALREADY_SUBMITTED
  return upsert scores[player, viewer] { tryout: p.tryout, player, evaluator: viewer, technique, teamwork, total: technique + teamwork }

mutation submitSheet():
  t = tryouts['tryout'] ! else NOT_FOUND
  require not t.closed else SCORING_CLOSED
  seat = evaluators[t.id, viewer] ! else NOT_EVALUATOR
  require not seat.submitted else ALREADY_SUBMITTED
  n = count(players where .tryout = t.id)
  done = count(scores where .evaluator = viewer and .tryout = t.id)
  require n > 0 and done = n else INCOMPLETE_SHEET 'Score every numbered player before submitting.'
  update evaluators[seat.id] { submitted: true }
  remaining = count(evaluators where .tryout = t.id and .submitted = false)
  if remaining = 0:
    update tryouts[t.id] { closed: true }
  return null

mutation setDecision(player: players, choice: enum('selected', 'reserve', 'declined'), reason: text 5..200):
  require exists staff[viewer] else STAFF_ONLY
  p = players[player] ! else NOT_FOUND
  t = tryouts[p.tryout] ! else NOT_FOUND
  require t.closed else SCORING_SEALED
  old = decisions[player]
  upsert decisions[player] { player, choice }
  insert audit { actor: viewer, player, action: 'roster decision', beforeValue: old.choice ?? 'undecided', afterValue: choice, reason }
  return null

mutation correctScore(player: players, evaluator: principal, technique: int 1..5, teamwork: int 1..5, reason: text 5..200):
  require exists staff[viewer, role = 'director'] else DIRECTOR_ONLY
  p = players[player] ! else NOT_FOUND
  t = tryouts[p.tryout] ! else NOT_FOUND
  require t.closed else SCORING_OPEN
  s = scores[player, evaluator] ! else NOT_FOUND
  update scores[s.id] { technique, teamwork, total: technique + teamwork }
  insert audit { actor: viewer, player, action: 'score correction', beforeValue: 'score', afterValue: 'corrected', reason, beforeTechnique: s.technique, beforeTeamwork: s.teamwork, afterTechnique: technique, afterTeamwork: teamwork }
  return null

job publishDecisions():
  for t in tryouts:
    if t.closed and t.releaseAt <= now:
      for d in decisions:
        p = players[d.player] ! else NOT_FOUND
        r = registrations[d.player] ! else NOT_FOUND
        upsert releases[d.player] { player: d.player, parent: r.parent, number: p.number, choice: d.choice, opensAt: t.releaseAt }

schedule releaseDecisions every 1m: publishDecisions
