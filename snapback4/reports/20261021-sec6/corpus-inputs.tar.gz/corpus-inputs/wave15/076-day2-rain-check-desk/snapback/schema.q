use identity
use personas alice, bob, cashier, manager

table staff:
  principal: principal
  role: enum('cashier', 'manager')
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table profiles:
  principal: principal
  displayName: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[viewer] or viewer = 'service:ops'
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table items:
  name: text 2..80
  saleCents: int 1..100000
  quantityLimit: int 1..12
  saleEndsAt: time
  inStock: bool
  public 'Advertised grocery sale catalog'
  insert <- exists staff[viewer, role = 'manager']
  update <- exists staff[viewer, role = 'manager']
  cap 100
  online only

table rainChecks:
  customer: principal
  item: items
  quantity: int 1..12
  saleCents: int 1..100000
  noticeState: enum('waiting', 'notified') default 'waiting'
  issuedAt: time
  expiresAt: time
  immutable customer, item, quantity, saleCents, issuedAt, expiresAt
  read <- .customer = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  cap 3 by customer
  expire at .expiresAt
  online only

table audit:
  rainCheck: rainChecks on delete keep
  customer: principal
  item: items
  quantity: int 1..12
  saleCents: int 1..100000
  expiresAt: time
  actor: principal
  action: enum('issued', 'redeemed', 'notified')
  at: time
  read <- .customer = viewer or exists staff[viewer]
  insert <- exists staff[viewer] and .actor = viewer
  online only

view outstandingChecks: count rainChecks by .item
  read <- exists staff[viewer, role = 'manager']
view outstandingUnits: sum rainChecks of .quantity by .item
  read <- exists staff[viewer, role = 'manager']

query identity():
  return { principal: viewer, staff: staff[viewer], profile: profiles[principal = viewer] }
query catalog():
  return items first 100 by .name
query myChecks():
  return rainChecks where .customer = viewer first 3 by .expiresAt
query customerChecks(customer: principal):
  require exists staff[viewer] else STAFF_ONLY 'Only store staff can open the desk.'
  return rainChecks where .customer = customer first 3 by .expiresAt
query history(customer: principal, c: cursor ?):
  require customer = viewer or exists staff[viewer] else PRIVATE_HISTORY 'This customer history is private.'
  return audit where .customer = customer last 20 by .at after c
query demand():
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only the manager can view order planning.'
  return items first 100 by .name { id, name, checks: outstandingChecks[.id], units: outstandingUnits[.id] }

mutation issue(customer: principal, item: items, quantity: int 1..12):
  require exists staff[viewer] else STAFF_ONLY 'Only store staff can issue rain checks.'
  require exists profiles[principal = customer] else UNKNOWN_CUSTOMER 'Choose a registered customer.'
  product = items[item] ! else NOT_FOUND
  require not product.inStock else IN_STOCK 'This item is available; a rain check is unnecessary.'
  require product.saleEndsAt > now else SALE_ENDED 'The advertised sale has ended.'
  require quantity <= product.quantityLimit else QUANTITY_LIMIT 'The requested quantity exceeds the sale limit.'
  check = insert rainChecks { customer, item, quantity, saleCents: product.saleCents, issuedAt: now, expiresAt: now + 30d }
  insert audit { rainCheck: check.id, customer, item, quantity, saleCents: check.saleCents, expiresAt: check.expiresAt, actor: viewer, action: 'issued', at: now }
  return check
mutation redeem(rainCheck: rainChecks):
  require exists staff[viewer] else STAFF_ONLY 'Only store staff can redeem rain checks.'
  check = rainChecks[rainCheck] ! else CHECK_UNAVAILABLE 'This rain check has expired or was already redeemed.'
  product = items[check.item] ! else NOT_FOUND
  require product.inStock else NOT_RESTOCKED 'Wait until this item is restocked.'
  entry = insert audit { rainCheck, customer: check.customer, item: check.item, quantity: check.quantity, saleCents: check.saleCents, expiresAt: check.expiresAt, actor: viewer, action: 'redeemed', at: now }
  delete rainChecks[rainCheck]
  return entry
mutation setStock(item: items, inStock: bool):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY 'Only the manager can change stock availability.'
  update items[item] { inStock }

mutation register(displayName: text 1..80):
  return upsert profiles[principal = viewer] { displayName }
mutation grantStaff(principal: principal, role: enum('cashier', 'manager')):
  require viewer = 'service:ops' else OPERATOR_ONLY 'Staff roles are provisioned by the store operator.'
  p = profiles[principal = principal] ! else UNKNOWN_CUSTOMER
  return insert staff { principal: p.principal, role }
mutation createItem(name: text 2..80, saleCents: int 1..100000, quantityLimit: int 1..12, saleEndsAt: time):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY
  require saleEndsAt > now else SALE_ENDED
  return insert items { name, saleCents, quantityLimit, saleEndsAt, inStock: false }
query directory(c: cursor ?):
  require exists staff[viewer] else STAFF_ONLY
  return profiles first 20 by .displayName after c { principal, displayName }

table restockNotices:
  rainCheck: rainChecks on delete keep
  customer: principal
  item: items
  actor: principal
  message: text 1..240
  at: time
  unique rainCheck
  immutable rainCheck, customer, item, actor, message, at
  read <- .customer = viewer or exists staff[viewer]
  insert <- exists staff[viewer] and .actor = viewer
  online only
query notices(customer: principal, c: cursor ?):
  require customer = viewer or exists staff[viewer] else PRIVATE_HISTORY
  return restockNotices where .customer = customer last 20 by .at after c
mutation notifyRestock(rainCheck: rainChecks, message: text 1..240):
  require exists staff[viewer] else STAFF_ONLY 'Only store staff can record restock notices.'
  check = rainChecks[rainCheck] ! else CHECK_UNAVAILABLE
  product = items[check.item] ! else NOT_FOUND
  require product.inStock else NOT_RESTOCKED 'Wait until this item is restocked.'
  require check.noticeState = 'waiting' else ALREADY_NOTIFIED 'A restock notice is already recorded.'
  notice = insert restockNotices { rainCheck, customer: check.customer, item: check.item, actor: viewer, message, at: now }
  update rainChecks[rainCheck] { noticeState: 'notified' }
  insert audit { rainCheck, customer: check.customer, item: check.item, quantity: check.quantity, saleCents: check.saleCents, expiresAt: check.expiresAt, actor: viewer, action: 'notified', at: now }
  return notice
