-- Peer Grading Calibration.
-- Students first score instructor-graded sample essays (calibration). The
-- instructor records each student's reliability weight; only `full`-weight
-- students may submit peer reviews. Authors read aggregated, anonymous
-- feedback; the instructor can override any grade with a logged note.
use personas alice, bob, instructor

-- Privileged role roster. Provisioned out of band (fixtures / seed):
-- no persona may insert through the app.
table instructors:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- A student's essay submission.
table essays:
  author: principal
  title: text 1..120
  body: text 1..5000
  at: time
  public 'essays are listed so peers can grade them'
  insert <- .author = viewer
  update <- deny
  delete <- deny
  online only

-- Instructor-graded sample essays used for calibration.
table samples:
  setBy: principal
  title: text 1..120
  body: text 1..2000
  instructorScore: int 0..100
  public 'samples are public so students can calibrate'
  insert <- exists instructors[viewer]
  update <- exists instructors[viewer]
  delete <- exists instructors[viewer]
  online only

-- One student's score of one sample. Drift from the instructor score is
-- stored so the instructor can judge reliability.
table calibrations:
  sample: samples on delete cascade
  student: principal
  score: int 0..100
  drift: int 0..100
  ok: bool
  at: time
  unique sample, student
  immutable sample, student
  cap 795 by sample
  read <- .student = viewer or exists instructors[viewer]
  insert <- .student = viewer
  update <- .student = viewer
  delete <- deny
  online only

-- An anonymous peer review. Authors read these through the `feedbackFor`
-- projection, which drops the reviewer field.
table reviews:
  essay: essays on delete cascade
  reviewer: principal
  score: int 0..100
  comment: text 1..1000
  at: time
  unique essay, reviewer
  immutable essay, reviewer
  read <- .reviewer = viewer or exists instructors[viewer] or exists essays[.essay, author = viewer]
  insert <- .reviewer = viewer
  update <- .reviewer = viewer
  delete <- deny
  online only

-- Instructor-recorded reliability per student. `full` means the student's
-- grades count; `practice` means extra practice is required first.
table reliability:
  student: principal
  drift: int 0..100
  weight: enum('full', 'practice')
  note: text <=200 ?
  unique student
  immutable student
  read <- .student = viewer or exists instructors[viewer]
  insert <- exists instructors[viewer]
  update <- exists instructors[viewer]
  delete <- deny
  online only

-- Instructor grade override with a logged note. At most one per essay.
table overrides:
  essay: essays on delete cascade
  score: int 0..100
  note: text 1..500
  setBy: principal
  at: time
  unique essay
  immutable essay
  read <- exists essays[.essay, author = viewer] or exists instructors[viewer]
  insert <- exists instructors[viewer]
  update <- exists instructors[viewer]
  delete <- deny
  online only

query myEssays(c: cursor ?):
  return essays where .author = viewer last 50 by .id after c

query gradeQueue(c: cursor ?):
  return essays where .author != viewer last 50 by .id after c

query samples(c: cursor ?):
  return samples last 10 by .id after c

query myCalibrations(c: cursor ?):
  return calibrations where .student = viewer last 10 by .id after c

query calibrationsFor(student: principal, c: cursor ?):
  require exists instructors[principal = viewer] else NOT_INSTRUCTOR 'Only the instructor may review calibration.'
  return calibrations where .student = student last 10 by .id after c

query myReliability():
  return reliability where .student = viewer

query rosterStatus(c: cursor ?):
  require exists instructors[principal = viewer] else NOT_INSTRUCTOR 'Only the instructor may see reviewer reliability.'
  return reliability last 100 by .id after c

-- Anonymous feedback: reviewer names never reach the author.
query feedbackFor(essay: essays, c: cursor ?):
  e = essays[essay] ! else NOT_FOUND
  require e.author = viewer or exists instructors[principal = viewer] else NOT_YOURS 'Only the author or instructor may read this feedback.'
  return reviews where .essay = essay last 50 by .id after c { score, comment, at }

query overrideFor(essay: essays):
  e = essays[essay] ! else NOT_FOUND
  require e.author = viewer or exists instructors[principal = viewer] else NOT_YOURS 'Only the author or instructor may read this override.'
  return overrides[essay]

mutation submitEssay(title: text 1..120, body: text 1..5000):
  row = insert essays { author: viewer, title, body, at: now }
  return { id: row.id }

mutation scoreSample(sample: samples, score: int 0..100):
  s = samples[sample] ! else NOT_FOUND
  d = score - s.instructorScore
  drift = d if d >= 0 else 0 - d
  ok = true if drift <= 15 else false
  row = upsert calibrations[sample = sample, student = viewer] { sample, student: viewer, score, drift, ok, at: now }
  return { id: row.id, drift, ok }

mutation submitReview(essay: essays, score: int 0..100, comment: text 1..1000):
  e = essays[essay] ! else NOT_FOUND
  require e.author != viewer else SELF_GRADE 'You cannot grade your own essay.'
  require exists reliability[student = viewer, weight = 'full'] else NOT_CALIBRATED 'Finish calibration before your grades count.'
  row = upsert reviews[essay = essay, reviewer = viewer] { essay, reviewer: viewer, score, comment, at: now }
  return { id: row.id }

mutation recordReliability(student: principal, drift: int 0..100, weight: enum('full', 'practice')):
  require exists instructors[principal = viewer] else NOT_INSTRUCTOR 'Only the instructor may record reliability.'
  row = upsert reliability[student = student] { student, drift, weight }
  return { id: row.id }

mutation overrideGrade(essay: essays, score: int 0..100, note: text 1..500):
  require exists instructors[principal = viewer] else NOT_INSTRUCTOR 'Only the instructor may override a grade.'
  e = essays[essay] ! else NOT_FOUND
  row = upsert overrides[essay = essay] { essay, score, note, setBy: viewer, at: now }
  return { id: row.id }
