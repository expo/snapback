use personas alice, bob, carol, dave

-- Roster: alice and bob are customers (no row), dave is staff, carol is owner.
table roles:
  principal: principal
  role: enum('staff', 'owner')
  unique principal
  read <- .principal = viewer or exists roles[viewer]
  insert <- exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'owner']
  delete <- exists roles[viewer, role = 'owner']
  online only

-- Small-batch flavors. The public page reads these; staff manage them.
table flavors:
  name: text 1..60
  description: text <=280 ?
  tubs: int 0..100 default 10
  seasonal: bool default false
  availableFrom: time ?
  availableUntil: time ?
  unique name
  public 'todays flavors are public'
  insert <- exists roles[viewer]
  update <- exists roles[viewer]
  delete <- exists roles[viewer, role = 'owner']
  online only

-- One vote per customer per flavor for flavors they want back.
table votes:
  voter: principal
  flavor: flavors
  at: time default now
  unique voter, flavor
  immutable voter, flavor
  read <- .voter = viewer or exists roles[viewer]
  insert <- .voter = viewer
  delete <- .voter = viewer
  cap 20 by voter
  online only

-- Maintained per-flavor vote totals; only staff/owner read them.
view voteTotals: count votes by .flavor
  read <- exists roles[viewer]
  online only

-- Text-me-when-it-returns signups, one per customer per flavor.
table alerts:
  subscriber: principal
  flavor: flavors
  phone: text 7..20
  notified: bool default false
  unique subscriber, flavor
  immutable subscriber, flavor
  read <- .subscriber = viewer or exists roles[viewer]
  insert <- .subscriber = viewer
  update <- .subscriber = viewer or exists roles[viewer]
  delete <- .subscriber = viewer
  cap 20 by subscriber
  online only

-- The owner's plan for next week's rotation.
table plans:
  owner: principal
  weekOf: time
  notes: text <=500 ?
  immutable owner
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'owner']
  delete <- exists roles[viewer, role = 'owner']
  cap 52
  online only

table planItems:
  plan: plans on delete cascade
  flavor: flavors
  day: text 3..9
  immutable plan, flavor, day
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'owner']
  delete <- exists roles[viewer, role = 'owner']
  cap 21 by plan
  online only

-- Public board: seasonal flavors only inside their date window.
query board(c: cursor ?):
  return flavors where not .seasonal or (.availableFrom <= now and now <= .availableUntil) first 50 by .id after c

query flavorDetail(flavor: flavors):
  return flavors[flavor]

query myVotes(c: cursor ?):
  return votes where .voter = viewer first 50 by .id after c

query myAlerts(c: cursor ?):
  return alerts where .subscriber = viewer first 50 by .id after c

query totals(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return voteTotals first 50 by .flavor after c

query allVotes(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return votes last 50 by .id after c

query allAlerts(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return alerts last 50 by .id after c

query plans(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return plans last 20 by .weekOf after c

query planDetail(plan: plans, c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return planItems where .plan = plan first 21 by .id after c

query roster(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return roles last 50 by .id after c

query myRole():
  return roles[principal = viewer]

mutation addFlavor(name: text 1..60, description: text <=280 ?, tubs: int 0..100, seasonal: bool ?, availableFrom: time ?, availableUntil: time ?):
  require exists roles[viewer] else NOT_STAFF
  return insert flavors { name, description, tubs, seasonal: seasonal ?? false, availableFrom, availableUntil }

-- End-of-day batch count update. Tubs at zero reads as sold out.
mutation updateTubs(flavor: flavors, tubs: int 0..100):
  require exists roles[viewer] else NOT_STAFF
  update flavors[flavor] { tubs }
  return null

mutation removeFlavor(flavor: flavors):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  delete flavors[flavor]
  return null

mutation vote(flavor: flavors):
  f = flavors[flavor] ! else NOT_FOUND
  require not exists votes[viewer, flavor] else ALREADY_VOTED
  return insert votes { voter: viewer, flavor }

mutation unvote(flavor: flavors):
  require exists votes[viewer, flavor] else NOT_VOTED
  delete votes[voter = viewer, flavor = flavor]
  return null

mutation signupAlert(flavor: flavors, phone: text 7..20):
  f = flavors[flavor] ! else NOT_FOUND
  return upsert alerts[viewer, flavor] { subscriber: viewer, phone, notified: false }

mutation cancelAlert(flavor: flavors):
  require exists alerts[viewer, flavor] else NOT_SUBSCRIBED
  delete alerts[subscriber = viewer, flavor = flavor]
  return null

mutation markNotified(alert: alerts):
  require exists roles[viewer] else NOT_STAFF
  a = alerts[alert] ! else NOT_FOUND
  update alerts[alert] { notified: true }
  return null

mutation planWeek(weekOf: time, notes: text <=500 ?):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return insert plans { owner: viewer, weekOf, notes }

mutation planAddFlavor(plan: plans, flavor: flavors, day: text 3..9):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  p = plans[plan] ! else NOT_FOUND
  f = flavors[flavor] ! else NOT_FOUND
  return insert planItems { plan, flavor, day }

mutation planRemoveFlavor(item: planItems):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  delete planItems[item]
  return null

mutation grantRole(who: principal, role: enum('staff', 'owner')):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return upsert roles[who] { role }
