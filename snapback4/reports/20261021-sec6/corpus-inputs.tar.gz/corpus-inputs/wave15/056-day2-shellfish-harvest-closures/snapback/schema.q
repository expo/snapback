-- Shellfish Harvest Closures.
-- Growing areas close after heavy rainfall or a poor water sample and reopen
-- automatically when reopensAt passes, unless staff extend the closure.
-- Growers log harvests offline; staff see everything and trace tags in a recall.
-- The public map (areas + active closures) is readable by every persona.
use identity
use personas alice, bob, carol

-- Program staff roster. Seeded in development via fixtures/staff.jsonl.
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

-- Growing areas. Public so every persona (and the public map) reads them.
table areas:
  name: text 1..80
  region: text 1..80
  mapX: int 0..100
  mapY: int 0..100
  unique name
  public 'the growing-area map is public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  sync public last 200 by .id

-- One closure of an area. An area is closed while any row has reopensAt > now.
table closures:
  area: areas
  reason: enum('rainfall', 'sample', 'other')
  closedAt: time default now
  reopensAt: time
  immutable area, closedAt
  public 'closure status is public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  sync public last 500 by .id

-- One harvest log entry. A grower holds their own rows offline on the water;
-- staff read every grower's rows from the server for oversight and recall.
table harvests:
  area: areas
  grower: principal
  harvestedAt: time default now
  tag: text 1..40
  handling: enum('landed', 'chilled') default 'landed'
  immutable area, grower, harvestedAt, tag
  read <- .grower = viewer or exists staff[viewer]
  insert <- .grower = viewer
  update <- .grower = viewer
  delete <- deny
  cap 5000 by grower
  sync

-- Public: every growing area for the map (newest-first matches the sync window,
-- so devices answer offline; clients reverse for display).
query areaMap(c: cursor ?):
  return areas last 100 by .id after c

-- Public: closures still in force (automatic reopen when reopensAt passes).
query activeClosures(c: cursor ?):
  return closures where .reopensAt > now last 100 by .id after c

-- A grower's own harvest log.
query myHarvests(c: cursor ?):
  return harvests where .grower = viewer first 100 by .id after c

-- Whether the caller is program staff (drives UI role gating; rules still enforce).
query amIStaff():
  return exists staff[viewer]

-- Staff: every grower's harvests.
query allHarvests(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF
  return harvests first 100 by .id after c

-- Staff: trace a tag number in a recall. Exact match on the tag code, so the
-- answer is complete: every row carrying that tag, or an empty complete page.
query traceTag(code: text 1..40):
  require exists staff[viewer] else NOT_STAFF
  return harvests where .tag = code first 50 by .id

mutation addArea(name: text 1..80, region: text 1..80, mapX: int 0..100, mapY: int 0..100):
  require exists staff[viewer] else NOT_STAFF
  return insert areas { name, region, mapX, mapY }

mutation closeArea(area: areas, reason: enum('rainfall', 'sample', 'other'), days: int 1..60):
  require exists staff[viewer] else NOT_STAFF
  a = areas[area] ! else NOT_FOUND
  return insert closures { area, reason, reopensAt: now + days * 1d }

mutation extendClosure(closure: closures, extraDays: int 1..60):
  require exists staff[viewer] else NOT_STAFF
  c = closures[closure] ! else NOT_FOUND
  update closures[closure] { reopensAt: c.reopensAt + extraDays * 1d }
  return null

mutation logHarvest(area: areas, harvestedAt: time ?, tag: text 1..40):
  a = areas[area] ! else NOT_FOUND
  return insert harvests { area, grower: viewer, harvestedAt: harvestedAt ?? now, tag }

-- Trusted local operator provisions staff; signup never grants a role.
mutation grantStaff(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal }

-- Immutable cold-chain evidence; retained with the harvest for recall audits.
table handlingEvents:
  harvest: harvests
  grower: principal
  recordedAt: time default now
  note: text 1..200
  unique harvest
  immutable harvest, grower, recordedAt, note
  read <- .grower = viewer or exists staff[viewer]
  insert <- .grower = viewer
  update <- deny
  delete <- deny
  sync

query handlingHistory(harvest: harvests):
  return handlingEvents where .harvest = harvest first 50 by .id

mutation chillHarvest(harvest: harvests, note: text 1..200):
  h = harvests[harvest] ! else NOT_FOUND
  require h.grower = viewer else NOT_OWNER
  require h.handling = 'landed' else ALREADY_CHILLED
  update harvests[harvest] { handling: 'chilled' }
  return insert handlingEvents { harvest, grower: viewer, note }
