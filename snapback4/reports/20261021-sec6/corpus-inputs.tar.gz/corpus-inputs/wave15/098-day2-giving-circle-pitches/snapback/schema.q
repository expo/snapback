use identity
use personas alice, bob, clara, dana, visitor

table members:
  principal: principal
  role: enum('member', 'chair')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table rounds:
  title: text 3..80
  deadline: time
  budget: int 100..10000000
  locked: bool default false
  immutable deadline, budget
  read <- exists members[viewer] or exists nominations[round = .id, nominee = viewer]
  update <- exists members[viewer]
  insert <- exists members[viewer, role = 'chair']
  online only

table nominations:
  round: rounds
  nominator: principal
  nominee: principal
  name: text 3..100
  mission: text 10..500
  status: enum('nominated', 'finalist', 'declined', 'withdrawn') default 'nominated'
  statusVersion: int default 1
  unique round, nominee
  immutable round, nominator, nominee, name, mission
  read <- .nominee = viewer or exists members[viewer]
  insert <- .nominator = viewer and exists members[viewer]
  update (old, next) <- exists members[viewer, role = 'chair'] or (old.nominee = viewer and old.status != 'withdrawn' and next.status = 'withdrawn' and next.statusVersion > old.statusVersion)
  online only

table pitches:
  nomination: nominations
  owner: principal
  story: text 20..1500
  requested: int 100..10000000
  budgetFile: file <=4000000 ('application/pdf')
  unique nomination
  immutable nomination, owner
  read <- .owner = viewer or exists members[viewer]
  insert <- .owner = viewer and .owner = .nomination.nominee and .nomination.status = 'finalist'
  online only

table feedback:
  nomination: nominations
  owner: principal
  body: text 1..1000
  unique nomination
  immutable nomination, owner
  read <- .owner = viewer or exists members[viewer, role = 'chair']
  insert <- exists members[viewer, role = 'chair'] and .owner = .nomination.nominee
  update <- exists members[viewer, role = 'chair']
  online only

table ballots:
  round: rounds
  voter: principal
  ranking: [nominations] 1..5
  opensAt: time
  unique round, voter
  immutable round, voter, ranking, opensAt
  not before .opensAt
  read <- exists members[viewer, role = 'chair']
  insert <- .voter = viewer and exists members[viewer] and .opensAt = .round.deadline
  online only

table grants:
  round: rounds
  nomination: nominations
  roundTitle: text 3..80
  nonprofit: text 3..100
  amount: int 100..10000000
  at: time default now
  unique nomination
  public 'Published giving circle awards, including nonprofit and amount.'
  insert <- exists members[viewer, role = 'chair']
  online only

table statusHistory:
  nomination: nominations
  owner: principal
  actor: principal
  status: enum('nominated', 'finalist', 'declined', 'withdrawn')
  version: int
  reason: text 1..1000
  at: time default now
  unique nomination, version
  immutable nomination, owner, actor, status, version, reason, at
  read <- .owner = viewer or exists members[viewer, role = 'chair']
  insert <- .actor = viewer and .owner = .nomination.nominee and (.owner = viewer or exists members[viewer, role = 'chair'])
  online only

query applicationHistory(nomination: nominations):
  return statusHistory where .nomination = nomination first 100 by .version

query myRole():
  return members[viewer]
query roundList():
  return rounds last 20 by .deadline
query nominationList(round: rounds):
  return nominations where .round = round first 100 by .id
query myApplications():
  return nominations where .nominee = viewer first 100 by .id
query pitchList():
  return pitches first 100 by .id
query myFeedback():
  return feedback first 100 by .id
query sealedBallots(round: rounds):
  return ballots where .round = round first 100 by .id
query publicAwards():
  return grants last 100 by .at
query givingTotal():
  if exists members[viewer]:
    return { cents: sum(grants, .amount), awards: count(grants) }
  return { cents: 0, awards: 0 }

mutation createRound(title: text 3..80, deadline: time, budget: int 100..10000000):
  require exists members[viewer, role = 'chair'] else CHAIR_ONLY
  require deadline > now else FUTURE_DEADLINE
  return insert rounds { title, deadline, budget }
mutation nominate(round: rounds, nominee: principal, name: text 3..100, mission: text 10..500):
  require exists members[viewer] else MEMBERS_ONLY
  r = rounds[round] ! else NOT_FOUND
  require now < r.deadline else ROUND_CLOSED
  return insert nominations { round, nominator: viewer, nominee, name, mission }
mutation selectFinalist(nomination: nominations, status: enum('finalist', 'declined'), expectedVersion: int):
  require exists members[viewer, role = 'chair'] else CHAIR_ONLY
  n = nominations[nomination] ! else NOT_FOUND
  r = rounds[n.round] ! else NOT_FOUND
  require now < r.deadline else ROUND_CLOSED
  require not r.locked else VOTING_STARTED
  require n.status != 'withdrawn' else APPLICATION_WITHDRAWN
  require n.statusVersion = expectedVersion else STALE_STATUS
  update nominations[nomination] { status, statusVersion: n.statusVersion + 1 }
  insert statusHistory { nomination, owner: n.nominee, actor: viewer, status, version: n.statusVersion + 1, reason: 'Chair updated application status.' }
  return null
mutation submitPitch(nomination: nominations, story: text 20..1500, requested: int 100..10000000, budgetFile: file <=4000000 ('application/pdf')):
  n = nominations[nomination] ! else NOT_FOUND
  require n.nominee = viewer else OWN_APPLICATION_ONLY
  require n.status = 'finalist' else FINALISTS_ONLY
  r = rounds[n.round] ! else NOT_FOUND
  require now < r.deadline else ROUND_CLOSED
  return insert pitches { nomination, owner: viewer, story, requested, budgetFile }
mutation giveFeedback(nomination: nominations, body: text 1..1000):
  require exists members[viewer, role = 'chair'] else CHAIR_ONLY
  n = nominations[nomination] ! else NOT_FOUND
  upsert feedback[nomination] { nomination, owner: n.nominee, body }
  return null
mutation castBallot(round: rounds, ranking: [nominations] 1..5):
  require exists members[viewer] else MEMBERS_ONLY
  r = rounds[round] ! else NOT_FOUND
  require now < r.deadline else VOTING_CLOSED
  require count(ranking) = count(nominations where .round = round and .status = 'finalist') else RANK_ALL_FINALISTS
  seen = []
  for choice in ranking:
    require not (choice in seen) else DUPLICATE_RANK
    n = nominations[choice] ! else NOT_FOUND
    require n.round = round and n.status = 'finalist' else NOT_FINALIST
    require exists pitches[nomination = choice] else PITCH_REQUIRED
    seen = seen + [choice]
  update rounds[round] { locked: true }
  insert ballots { round, voter: viewer, ranking, opensAt: r.deadline }
  return { sealed: true }
mutation publishWinner(nomination: nominations, amount: int 100..10000000):
  require exists members[viewer, role = 'chair'] else CHAIR_ONLY
  n = nominations[nomination] ! else NOT_FOUND
  r = rounds[n.round] ! else NOT_FOUND
  require now >= r.deadline else VOTING_STILL_OPEN
  require n.status = 'finalist' else NOT_FINALIST
  p = pitches[nomination] ! else PITCH_REQUIRED
  require amount <= p.requested else ABOVE_REQUEST
  require sum(grants where .round = n.round, .amount) + amount <= r.budget else ABOVE_ROUND_BUDGET
  return insert grants { round: n.round, nomination, roundTitle: r.title, nonprofit: n.name, amount }

query whoAmI():
  return viewer

mutation provisionMember(principal: principal, role: enum('member', 'chair')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert members { principal, role }

mutation withdrawApplication(nomination: nominations, expectedVersion: int, reason: text 1..1000):
  n = nominations[nomination] ! else NOT_FOUND
  require n.nominee = viewer else OWN_APPLICATION_ONLY
  r = rounds[n.round] ! else NOT_FOUND
  require now < r.deadline else ROUND_CLOSED
  require not r.locked else VOTING_STARTED
  require n.status != 'withdrawn' else ALREADY_WITHDRAWN
  require n.statusVersion = expectedVersion else STALE_STATUS
  update nominations[nomination] { status: 'withdrawn', statusVersion: n.statusVersion + 1 }
  insert statusHistory { nomination, owner: viewer, actor: viewer, status: 'withdrawn', version: n.statusVersion + 1, reason }
  return { withdrawn: true }
