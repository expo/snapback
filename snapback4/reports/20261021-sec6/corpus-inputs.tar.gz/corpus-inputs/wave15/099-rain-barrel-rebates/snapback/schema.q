-- Rain Barrel Rebates: a water utility offers rebates on rain barrel
-- purchases until an annual budget is spent. Residents apply with a
-- receipt photo and a photo of the installed barrel; a utility reviewer
-- approves or rejects in order of arrival. The remaining budget is public
-- and the program closes when it reaches zero.
use identity                  -- guests sign in; use identity password would add email accounts
use personas alice, bob, rita -- alice and bob are residents, rita is the utility reviewer

-- The annual program: one row per year. The remaining budget is public.
table program:
  name: text 1..80
  budgetCents: int 1..100000000
  public 'the remaining budget is shown on a public page'
  insert <- deny
  update <- deny
  delete <- deny
  sync public last 10 by .id

-- The reviewer roster: one row per utility reviewer. Seeded with rita;
-- reviewers grant further reviewers.
table reviewers:
  principal: principal
  unique principal
  read <- .principal = viewer or exists reviewers[viewer]
  insert <- exists reviewers[viewer]
  delete <- exists reviewers[viewer]
  online only

-- One resident application per purchase. Photos are stored as URLs.
table applications:
  applicant: principal
  program: program
  neighborhood: text 1..60
  barrelGallons: int 30..220
  costCents: int 1..200000
  rebateCents: int 1..50000
  receiptUrl: text <=500 format url
  installUrl: text <=500 format url
  status: enum('pending', 'approved', 'rejected') default 'pending'
  createdAt: time default now
  decidedAt: time ?
  note: text <=280 ?
  immutable applicant, program
  cap 5 by applicant
  read <- .applicant = viewer or exists reviewers[viewer]
  insert <- .applicant = viewer
  update <- exists reviewers[viewer]
  delete <- .applicant = viewer and .status = 'pending'
  online only

-- Maintained totals. The approved total is public (it backs the public
-- remaining-budget figure); per-neighborhood figures are reviewer-only.
view approvedTotal: sum applications of .rebateCents where .status = 'approved'
  public 'anyone can see how much of the budget is spent'
view spendByNeighborhood: sum applications of .rebateCents where .status = 'approved' by .neighborhood
  read <- exists reviewers[viewer]
  online only
view appsByNeighborhood: count applications by .neighborhood, .status
  read <- exists reviewers[viewer]
  online only

-- Public page: the program, what is spent, what remains, whether closed.
query programStatus(program: program):
  p = program[program] ! else NOT_FOUND
  total = approvedTotal
  return { id: p.id, name: p.name, budgetCents: p.budgetCents, approvedCents: total, remainingCents: p.budgetCents - total, closed: p.budgetCents - total <= 0 }

-- Residents see only their own applications.
query myApplications(c: cursor ?):
  return applications where .applicant = viewer last 50 by .createdAt after c

query oneApplication(app: applications):
  return applications[app]

query amReviewer():
  return exists reviewers[viewer]

-- The reviewer works the queue oldest-first: order of arrival.
query reviewQueue(c: cursor ?):
  require exists reviewers[viewer] else NOT_REVIEWER
  return applications where .status = 'pending' first 100 by .createdAt, .id after c

-- The utility sees spending and approvals per neighborhood.
query neighborhoodSpend(c: cursor ?):
  require exists reviewers[viewer] else NOT_REVIEWER
  return spendByNeighborhood first 100 by .neighborhood after c { neighborhood, total: .value }

query neighborhoodCounts(c: cursor ?):
  require exists reviewers[viewer] else NOT_REVIEWER
  return appsByNeighborhood first 100 by .neighborhood after c { neighborhood, status, count: .value }

-- A resident applies for a rebate on one purchased barrel.
mutation apply(program: program, neighborhood: text 1..60, barrelGallons: int 30..220, costCents: int 1..200000, rebateCents: int 1..50000, receiptUrl: text <=500 format url, installUrl: text <=500 format url):
  require rebateCents <= costCents else REBATE_EXCEEDS_COST 'The rebate cannot exceed what the barrel cost.'
  p = program[program] ! else NOT_FOUND
  remaining = p.budgetCents - approvedTotal
  require remaining > 0 else PROGRAM_CLOSED 'The program budget is spent.'
  require rebateCents <= remaining else INSUFFICIENT_BUDGET 'Not enough budget remains for this rebate.'
  return insert applications { applicant: viewer, program, neighborhood, barrelGallons, costCents, rebateCents, receiptUrl, installUrl, status: 'pending' }

-- The reviewer approves in order of arrival: an older pending application
-- must be decided first.
mutation approve(app: applications):
  require exists reviewers[viewer] else NOT_REVIEWER
  a = applications[app] ! else NOT_FOUND
  require a.status = 'pending' else ALREADY_DECIDED 'This application was already decided.'
  older = count(applications where .status = 'pending' and .createdAt < a.createdAt)
  require older = 0 else OUT_OF_ORDER 'Decide the oldest pending application first.'
  p = program[a.program] ! else NOT_FOUND
  require a.rebateCents <= p.budgetCents - approvedTotal else INSUFFICIENT_BUDGET 'Not enough budget remains for this rebate.'
  update applications[app] { status: 'approved', decidedAt: now }
  return null

mutation reject(app: applications, note: text <=280 ?):
  require exists reviewers[viewer] else NOT_REVIEWER
  a = applications[app] ! else NOT_FOUND
  require a.status = 'pending' else ALREADY_DECIDED 'This application was already decided.'
  older = count(applications where .status = 'pending' and .createdAt < a.createdAt)
  require older = 0 else OUT_OF_ORDER 'Decide the oldest pending application first.'
  update applications[app] { status: 'rejected', decidedAt: now, note: note }
  return null

-- A resident withdraws their own still-pending application.
mutation withdraw(app: applications):
  a = applications[app] ! else NOT_FOUND
  require a.applicant = viewer else NOT_OWNER 'You can only withdraw your own application.'
  require a.status = 'pending' else ALREADY_DECIDED 'This application was already decided.'
  delete applications[app]
  return null

-- A reviewer grants the reviewer role to another principal.
mutation grantReviewer(who: principal):
  require exists reviewers[viewer] else NOT_REVIEWER
  return insert reviewers { principal: who }
