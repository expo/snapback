-- Ice Shanty Registry: anglers register shanties per lake, the office issues
-- tag numbers, everything comes off the ice by a legal deadline, and wardens
-- record violations. Public board shows deadlines + per-lake counts only.

use personas alice, bob, warden

-- Conservation office staff roster: one row per warden.
table wardens:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- Lake directory with the legal removal deadline. Public.
table lakes:
  name: text 1..60
  removalDeadline: time
  unique name
  public 'lake directory and removal deadlines are public'
  insert <- exists wardens[viewer]
  update <- exists wardens[viewer]
  delete <- exists wardens[viewer]
  sync last 200 by .id

-- Registered shanties. `tag` stays null until the office issues a tag number.
table shanties:
  owner: principal
  lake: lakes
  shelterName: text 1..40
  tag: text 1..12 ?
  removed: bool default false
  removedAt: time ?
  placedAt: time default now
  immutable owner, lake
  read <- .owner = viewer or exists wardens[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer or exists wardens[viewer]
  delete <- .owner = viewer
  cap 10 by owner
  sync

-- Violations recorded by wardens, with optional photo evidence. `owner` is a
-- denormalized immutable copy so the read rule needs no reference hop.
table violations:
  shanty: shanties
  owner: principal
  note: text 1..500
  photo: image <=5000000 ?
  at: time default now
  immutable shanty, owner
  read <- .owner = viewer or exists wardens[viewer]
  insert <- exists wardens[viewer]
  update <- deny
  delete <- exists wardens[viewer]
  online only

-- Public per-lake count of shanties still on the ice. Counts only, no owners.
view activeByLake: count shanties where .removed = false by .lake
  read <- allow

-- Public board: every lake with its deadline and still-out count.
query lakeBoard(c: cursor ?):
  return lakes last 100 by .id after c { id, name, removalDeadline, active: activeByLake[.id] }

query myShanties(c: cursor ?):
  return shanties where .owner = viewer last 50 by .id after c

-- Warden field check: look up shanties by displayed tag number.
query shantyByTag(tag: text 1..12):
  require exists wardens[viewer] else NOT_WARDEN
  return shanties where .tag = tag last 10 by .id

query myViolations(c: cursor ?):
  return violations where .owner = viewer last 50 by .id after c

query violationsFor(shanty: shanties, c: cursor ?):
  require exists wardens[viewer] else NOT_WARDEN
  return violations where .shanty = shanty last 50 by .id after c

-- Owner reminders: my shanties still on the ice with their lake deadlines.
query myReminders(c: cursor ?):
  return shanties where .owner = viewer and .removed = false last 50 by .id after c { id, shelterName, tag, lake: lakes[.lake] }

mutation registerShanty(lake: lakes, shelterName: text 1..40):
  l = lakes[lake] ! else NOT_FOUND
  return insert shanties { owner: viewer, lake: l.id, shelterName }

mutation issueTag(shanty: shanties, tagNumber: text 1..12):
  require exists wardens[viewer] else NOT_WARDEN
  s = shanties[shanty] ! else NOT_FOUND
  require s.tag = null else TAG_ALREADY_ISSUED
  require not exists shanties where .tag = tagNumber else TAG_TAKEN
  update shanties[shanty] { tag: tagNumber }
  return null

mutation markRemoved(shanty: shanties):
  s = shanties[shanty] ! else NOT_FOUND
  require s.owner = viewer else NOT_OWNER
  require not s.removed else ALREADY_REMOVED
  update shanties[shanty] { removed: true, removedAt: now }
  return null

mutation recordViolation(shanty: shanties, note: text 1..500, photo: image <=5000000 ?):
  require exists wardens[viewer] else NOT_WARDEN
  s = shanties[shanty] ! else NOT_FOUND
  return insert violations { shanty: s.id, owner: s.owner, note, photo }

mutation addLake(name: text 1..60, removalDeadline: time):
  require exists wardens[viewer] else NOT_WARDEN
  return insert lakes { name, removalDeadline }

mutation setDeadline(lake: lakes, removalDeadline: time):
  require exists wardens[viewer] else NOT_WARDEN
  update lakes[lake] { removalDeadline }
  return null
