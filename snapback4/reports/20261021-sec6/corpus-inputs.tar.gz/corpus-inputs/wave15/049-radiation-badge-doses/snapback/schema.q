-- Radiation Badge Doses.
-- University radiation safety: dosimetry badges issued to lab workers,
-- quarterly vendor readings, annual-limit tracking.
--
-- Domain constants (documented here; enforced in queries/mutations):
--   ANNUAL_LIMIT_MREM = 5000 (US occupational whole-body limit 5 rem)
--   WARN_MREM = 1250 (25% of the annual limit -> RSO alert, PI warn flag)
--
-- Cast (dev personas):
--   alice, bob : lab workers, members of lab 'photonics'
--   dave        : principal investigator (PI) of lab 'photonics'
--   carol       : radiation safety officer (RSO), rostered in staff

use personas alice, bob, carol, dave

-- RSO roster. One row per officer.
table staff:
  principal: principal
  role: enum('officer')
  unique principal
  read <- .principal = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  online only

-- Lab directory. Public: lab names and their PI are directory info.
table labs:
  name: text 1..40
  pi: principal
  unique name
  public 'lab directory: names and PIs are public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  online only

-- Lab roster: which workers belong to which lab.
table memberships:
  lab: text 1..40
  member: principal
  unique lab, member
  read <- .member = viewer or exists labs[name = .lab, pi = viewer] or exists staff[viewer]
  insert <- exists labs[name = .lab, pi = viewer] or exists staff[viewer]
  delete <- exists labs[name = .lab, pi = viewer] or exists staff[viewer]
  online only

-- Quarterly vendor readings. Dose in whole-body mrem for the quarter.
-- Only the worker and the RSO may read rows; the PI sees only the
-- pass/warn summary (labWarn) and never these rows.
table readings:
  worker: principal
  lab: text 1..40
  year: int 2000..2100
  quarter: text 4..7
  doseMrem: int 0..10000
  at: time default now
  unique worker, quarter
  immutable worker, lab, year, quarter
  read <- .worker = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  cap 40 by worker
  online only

-- Maintained annual totals. Explicit audience: the worker, the RSO, and
-- the PI of the worker's lab. The PI-facing query projects only the
-- worker id (warn list), never the value.
view annualDose: sum readings of .doseMrem by .lab, .worker, .year
  read <- .worker = viewer or exists staff[viewer] or exists labs[name = .lab, pi = viewer]
  online only

-- Badge lifecycle: issued -> returned | lost | late, with a due date and
-- a reminder timestamp. Workers see their own; the PI sees the lab's;
-- the RSO sees everything.
table badges:
  worker: principal
  lab: text 1..40
  quarter: text 4..7
  status: enum('issued', 'returned', 'lost', 'late')
  dueAt: time
  remindedAt: time ?
  at: time default now
  unique worker, quarter
  immutable worker, lab, quarter, dueAt
  read <- .worker = viewer or exists staff[viewer] or exists labs[name = .lab, pi = viewer]
  insert <- exists staff[viewer]
  update (old, next) <- (old.worker = viewer and next.status = 'lost') or exists staff[viewer]
  delete <- exists staff[viewer]
  online only

-- Worker: own quarterly readings for a year, newest quarter first.
query myReadings(year: int 2000..2100, c: cursor ?):
  return readings where .worker = viewer and .year = year last 20 by .quarter after c

-- Worker: own annual total against the limit (scalar mrem; 0 when no rows).
query myAnnualDose(lab: text 1..40, year: int 2000..2100):
  return annualDose[lab, viewer, year]

-- Worker: own badges.
query myBadges(c: cursor ?):
  return badges where .worker = viewer first 50 by .id after c

-- PI: members whose annual total reached 25% of the limit. Worker ids
-- only -- no dose numbers leave the server for this caller lane.
query labWarn(lab: text 1..40, year: int 2000..2100, c: cursor ?):
  require exists labs[name = lab, pi = viewer] or exists staff[viewer] else NOT_LAB_PI
  return annualDose where .lab = lab and .year = year and .value >= 1250 first 100 by .worker after c { worker }

-- PI/staff: lab roster (no doses). Members have no roster need; the page
-- is complete for exactly this audience (no conditional-complete note).
query labRoster(lab: text 1..40, c: cursor ?):
  require exists labs[name = lab, pi = viewer] or exists staff[viewer] else NOT_LAB_PI
  return memberships where .lab = lab first 100 by .member after c

-- PI/staff: badge states for a lab (statuses only, no doses).
query labBadges(lab: text 1..40, c: cursor ?):
  require exists labs[name = lab, pi = viewer] or exists staff[viewer] else NOT_LAB_PI
  return badges where .lab = lab first 100 by .id after c

-- RSO: everyone past 25% of the annual limit, with totals.
query alerts(year: int 2000..2100, c: cursor ?):
  require exists staff[viewer] else NOT_OFFICER
  return annualDose where .year = year and .value >= 1250 first 100 by .worker after c

-- RSO: badges still out past their due date (reminder worklist).
query overdueBadges(c: cursor ?):
  require exists staff[viewer] else NOT_OFFICER
  return badges where .status = 'issued' and .dueAt < now first 100 by .dueAt after c

-- RSO: register a lab.
mutation registerLab(name: text 1..40, pi: principal):
  require exists staff[viewer] else NOT_OFFICER
  return insert labs { name, pi }

-- PI/RSO: add a worker to a lab.
mutation addMember(lab: text 1..40, member: principal):
  require exists labs[name = lab, pi = viewer] or exists staff[viewer] else NOT_LAB_PI
  labRow = labs[name = lab] ! else NO_LAB
  return insert memberships { lab, member }

-- RSO: record a quarterly vendor reading.
mutation recordReading(worker: principal, lab: text 1..40, year: int 2000..2100, quarter: text 4..7, doseMrem: int 0..10000):
  require exists staff[viewer] else NOT_OFFICER
  labRow = labs[name = lab] ! else NO_LAB
  require exists memberships[lab = lab, member = worker] else NOT_MEMBER
  return insert readings { worker, lab, year, quarter, doseMrem }

-- RSO: correct a quarterly reading (annual view follows automatically).
mutation correctReading(reading: readings, doseMrem: int 0..10000):
  require exists staff[viewer] else NOT_OFFICER
  update readings[reading] { doseMrem }
  return null

-- RSO: issue a badge for a quarter.
mutation issueBadge(worker: principal, lab: text 1..40, quarter: text 4..7, dueAt: time):
  require exists staff[viewer] else NOT_OFFICER
  require exists memberships[lab = lab, member = worker] else NOT_MEMBER
  return insert badges { worker, lab, quarter, status: 'issued', dueAt }

-- Worker: report their own badge lost.
mutation reportLost(badge: badges):
  b = badges[badge] ! else NOT_FOUND
  require b.worker = viewer else NOT_OWNER
  update badges[badge] { status: 'lost' }
  return null

-- RSO: badge bookkeeping.
mutation markReturned(badge: badges):
  require exists staff[viewer] else NOT_OFFICER
  update badges[badge] { status: 'returned' }
  return null

mutation markLate(badge: badges):
  require exists staff[viewer] else NOT_OFFICER
  update badges[badge] { status: 'late' }
  return null

mutation sendReminder(badge: badges):
  require exists staff[viewer] else NOT_OFFICER
  update badges[badge] { remindedAt: now }
  return null
