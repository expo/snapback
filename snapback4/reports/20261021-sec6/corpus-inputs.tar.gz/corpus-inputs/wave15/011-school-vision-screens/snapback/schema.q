use personas alice, bob, carol, tom, dana

-- Roster is provisioned by the district, never writable by app users.
table staff:
  principal: principal
  role: enum('nurse', 'teacher', 'coordinator')
  unique principal
  read <- .principal = viewer
  sync to .principal

table schools:
  name: text 1..100
  public 'School names are public; no child data is stored here.'
  sync

table students:
  name: text 1..100
  school: schools
  classroom: text 1..40
  nurse: principal
  guardian: principal
  teacher: principal
  immutable school, nurse, guardian, teacher
  read <- .nurse = viewer or .guardian = viewer
  sync

table screenings:
  student: students
  school: schools
  nurse: principal
  guardian: principal
  leftEye: int 20..200
  rightEye: int 20..200
  outcome: enum('pass', 'refer')
  screenedAt: time default now
  unique student
  immutable student, school, nurse, guardian, leftEye, rightEye, outcome, screenedAt
  read <- .nurse = viewer or .guardian = viewer
  insert <- .nurse = viewer and exists students[.student, nurse = viewer, guardian = .guardian, school = .school]
  sync

table referrals:
  student: students
  nurse: principal
  guardian: principal
  letter: text 1..2000
  status: enum('awaiting', 'received') default 'awaiting'
  issuedAt: time default now
  doctorNote: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?
  receivedAt: time ?
  unique student
  immutable student, nurse, guardian, letter, issuedAt
  read <- .nurse = viewer or .guardian = viewer
  insert <- .nurse = viewer and exists students[.student, nurse = viewer, guardian = .guardian]
  update <- .guardian = viewer or .nurse = viewer
  sync

table seating:
  student: students
  name: text 1..100
  classroom: text 1..40
  nurse: principal
  teacher: principal
  nearFront: bool
  unique student
  immutable student, name, classroom, nurse, teacher
  read <- .teacher = viewer or .nurse = viewer
  insert <- .nurse = viewer and exists students[.student, nurse = viewer, teacher = .teacher, name = .name, classroom = .classroom]
  sync

view screenedTotals: count screenings by .school
  read <- exists staff[principal = viewer, role = 'coordinator']
  online only
view referredTotals: count screenings where .outcome = 'refer' by .school
  read <- exists staff[principal = viewer, role = 'coordinator']
  online only

query myRole():
  return staff[principal = viewer]
query schoolList():
  return schools first 100 by .id
query myStudents():
  if exists staff[principal = viewer, role = 'nurse']:
    return students where .nurse = viewer first 500 by .id
  return students where .guardian = viewer first 100 by .id
query myScreenings():
  if exists staff[principal = viewer, role = 'nurse']:
    return screenings where .nurse = viewer first 500 by .id
  return screenings where .guardian = viewer first 100 by .id
query myReferrals():
  if exists staff[principal = viewer, role = 'nurse']:
    return referrals where .nurse = viewer first 500 by .id
  return referrals where .guardian = viewer first 100 by .id
query classroomFlags():
  return seating where .teacher = viewer first 500 by .id { id, name, classroom, nearFront }
query districtRates():
  require exists staff[principal = viewer, role = 'coordinator'] else COORDINATOR_ONLY
  return schools first 100 by .id { id, name, screened: screenedTotals[.id], referred: referredTotals[.id] }
query childResult(student: students):
  return screenings[student = student]

mutation recordScreening(student: students, leftEye: int 20..200, rightEye: int 20..200):
  require exists staff[principal = viewer, role = 'nurse'] else NURSE_ONLY
  s = students[student] ! else CHILD_NOT_FOUND
  require s.nurse = viewer else NURSE_ONLY
  require not exists screenings[student = student] else ALREADY_SCREENED
  needsReferral = leftEye > 30 or rightEye > 30
  result = insert screenings { student, school: s.school, nurse: viewer, guardian: s.guardian, leftEye, rightEye, outcome: 'refer' if needsReferral else 'pass' }
  insert seating { student, name: s.name, classroom: s.classroom, nurse: viewer, teacher: s.teacher, nearFront: needsReferral }
  if needsReferral:
    insert referrals { student, nurse: viewer, guardian: s.guardian, letter: 'Dear guardian of ' + s.name + ',\n\nThe school vision screening suggests your child needs a full eye examination. Please arrange an appointment with an eye doctor and upload their note here. A screening is not a diagnosis.\n\nSchool nursing team' }
  return result

mutation attachDoctorNote(referral: referrals, doctorNote: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  r = referrals[referral] ! else REFERRAL_NOT_FOUND
  require r.guardian = viewer or r.nurse = viewer else REFERRAL_PRIVATE
  require r.status = 'awaiting' else NOTE_ALREADY_RECEIVED
  update referrals[referral] { doctorNote, status: 'received', receivedAt: now }
  return referrals[referral]
