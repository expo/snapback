-- Two-Bin Reorder Cards.
-- Personas: alice = shop floor, bob/dave = suppliers, carol = purchasing lead/owner.
use personas alice, bob, carol, dave
use identity password

-- Floor staff and the purchasing lead. Carol is the lead; alice works the floor.
table staff:
  principal: principal
  role: enum('floor', 'lead')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- exists staff[principal = viewer, role = 'lead'] or viewer = 'service:ops'
  update <- exists staff[principal = viewer, role = 'lead']
  online only

-- Supplier directory: human name bound to a persona principal.
table suppliers:
  name: text 1..40
  principal: principal
  unique name
  unique principal
  immutable name, principal
  public 'supplier directory is visible to the floor'
  insert <- exists staff[principal = viewer, role = 'lead'] or viewer = 'service:ops'
  online only

-- Parts catalog. supplier is the owning supplier's principal.
table parts:
  partNumber: text 1..40
  description: text 1..200
  supplier: principal
  usualQty: int 1..10000
  unique partNumber
  immutable partNumber
  public 'parts catalog is visible to the floor'
  insert <- exists staff[principal = viewer, role = 'lead']
  online only

-- One row per physical bin (parts are stocked in pairs). cardCode is the
-- scan card fixed to the bin.
table bins:
  part: parts
  slot: text 1..10
  cardCode: text 1..40
  unique part, slot
  unique cardCode
  immutable part, slot, cardCode
  public 'bin cards are scannable by the floor'
  insert <- exists staff[principal = viewer, role = 'lead']
  online only

-- A reorder of one bin. supplier is denormalized from the part so the read
-- rule needs no join: staff see everything, a supplier sees only its own.
table reorders:
  part: parts
  bin: bins
  supplier: principal
  qty: int 1..10000
  status: enum('open', 'shipped', 'received', 'cancelled')
  priority: enum('normal', 'rush') default 'normal'
  approved: bool default false
  shipDate: time ?
  createdAt: time default now
  dueAt: time
  immutable part, bin, supplier, createdAt, dueAt
  read <- exists staff[viewer] or .supplier = viewer
  insert <- exists staff[viewer]
  update <- exists staff[viewer] or .supplier = viewer
  online only

-- One row per cancelled reorder: the audit trail for wrong-card scans.
-- Staff can read it; anyone who cancelled can see their own rows.
table cancellations:
  reorder: reorders
  canceller: principal
  reason: text 1..200
  at: time default now
  unique reorder
  immutable reorder, canceller, reason, at
  read <- exists staff[viewer] or .canceller = viewer
  insert <- exists staff[viewer]
  online only

-- Every above-usual approval, written by approveReorder. Suppliers cannot read it.
table overrides:
  reorder: reorders
  approver: principal
  qty: int 1..10000
  usual: int 1..10000
  at: time default now
  immutable reorder, approver, qty, usual, at
  read <- exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'lead']
  online only

query partsCatalog(c: cursor ?):
  return parts first 50 by .partNumber after c

query binsOfPart(part: parts, c: cursor ?):
  return bins where .part = part first 50 by .slot after c

query suppliersDir(c: cursor ?):
  return suppliers first 50 by .name after c

-- Open (unshipped) reorders: everything for staff, own rows for a supplier.
query openReorders(c: cursor ?):
  if exists staff[viewer]:
    return reorders where .status = 'open' last 50 by .createdAt after c
  return reorders where .supplier = viewer and .status = 'open' last 50 by .createdAt after c

-- Shop floor board: past due and not received. Cancelled cards drop off.
-- Same visibility split.
query lateBoard(c: cursor ?):
  if exists staff[viewer]:
    return reorders where .dueAt < now and .status != 'received' and .status != 'cancelled' last 50 by .dueAt after c
  return reorders where .supplier = viewer and .dueAt < now and .status != 'received' and .status != 'cancelled' last 50 by .dueAt after c

-- Monthly roll-up for one supplier. Cancelled cards never shipped, so they
-- stay out of the totals. The lead may read any supplier; anyone
-- else reads only their own numbers (never a refusal, so the sweep stays green).
query supplierMonth(supplier: principal, since: time):
  if exists staff[principal = viewer, role = 'lead']:
    return { qty: sum(reorders where .supplier = supplier and .createdAt >= since and .status != 'cancelled', .qty), n: count(reorders where .supplier = supplier and .createdAt >= since and .status != 'cancelled') }
  return { qty: sum(reorders where .supplier = viewer and .createdAt >= since and .status != 'cancelled', .qty), n: count(reorders where .supplier = viewer and .createdAt >= since and .status != 'cancelled') }

-- Override log: the lead's rows, otherwise only rows the caller approved
-- (nobody outside staff approved any, so suppliers see an empty page).
query overridesLog(c: cursor ?):
  if exists staff[principal = viewer, role = 'lead']:
    return overrides last 50 by .at after c
  return overrides where .approver = viewer last 50 by .at after c

-- Cancellation log: every row for staff, own rows for the canceller.
query cancelsLog(c: cursor ?):
  if exists staff[viewer]:
    return cancellations last 50 by .at after c
  return cancellations where .canceller = viewer last 50 by .at after c

-- Scan an emptied bin's card: reorder the part's usual quantity, pre-approved.
mutation scanBin(cardCode: text 1..40):
  require exists staff[viewer] else NOT_STAFF
  b = bins[cardCode = cardCode] ! else UNKNOWN_CARD
  p = parts[b.part] ! else NOT_FOUND
  return insert reorders { part: b.part, bin: b.id, supplier: p.supplier, qty: p.usualQty, status: 'open', priority: 'normal', approved: true, createdAt: now, dueAt: now + 7d }

-- Order a specific quantity. Above the usual quantity the reorder waits for
-- lead approval (approved stays false) instead of refusing.
mutation orderStock(bin: bins, qty: int 1..10000):
  require exists staff[viewer] else NOT_STAFF
  b = bins[bin] ! else NOT_FOUND
  p = parts[b.part] ! else NOT_FOUND
  return insert reorders { part: b.part, bin, supplier: p.supplier, qty, status: 'open', priority: 'normal', approved: qty <= p.usualQty, createdAt: now, dueAt: now + 7d }

-- Approve an above-usual reorder. The approval itself is the logged override.
mutation approveReorder(reorder: reorders):
  require exists staff[principal = viewer, role = 'lead'] else NOT_LEAD
  r = reorders[reorder] ! else NOT_FOUND
  require not r.approved else ALREADY_APPROVED
  p = parts[r.part] ! else NOT_FOUND
  update reorders[reorder] { approved: true }
  return insert overrides { reorder, approver: viewer, qty: r.qty, usual: p.usualQty, at: now }

-- The owning supplier confirms a ship date. Blocked until approved.
mutation confirmShip(reorder: reorders, shipDate: time):
  r = reorders[reorder] ! else NOT_FOUND
  require r.status != 'cancelled' else CANCELLED
  require r.supplier = viewer or exists staff[principal = viewer, role = 'lead'] else NOT_YOURS
  require r.approved else NEEDS_APPROVAL
  require r.status = 'open' else BAD_STATE
  return update reorders[reorder] { status: 'shipped', shipDate }

-- Floor marks the bin refilled.
mutation receiveBin(reorder: reorders):
  require exists staff[viewer] else NOT_STAFF
  r = reorders[reorder] ! else NOT_FOUND
  require r.status != 'cancelled' else CANCELLED
  require r.status = 'shipped' else BAD_STATE
  return update reorders[reorder] { status: 'received' }

-- Cancel a mistaken reorder (wrong-card scan). Only open cards can be
-- cancelled; the cancellation row is the audit trail.
mutation cancelReorder(reorder: reorders, reason: text 1..200):
  require exists staff[viewer] else NOT_STAFF
  r = reorders[reorder] ! else NOT_FOUND
  require r.status = 'open' else BAD_STATE
  update reorders[reorder] { status: 'cancelled' }
  return insert cancellations { reorder, canceller: viewer, reason, at: now }

-- Flag an open reorder as rush (or back to normal). Only open cards move.
mutation setPriority(reorder: reorders, priority: enum('normal', 'rush')):
  require exists staff[viewer] else NOT_STAFF
  r = reorders[reorder] ! else NOT_FOUND
  require r.status = 'open' else BAD_STATE
  return update reorders[reorder] { priority }

-- Catalog management (lead only).
mutation addPart(partNumber: text 1..40, description: text 1..200, supplier: principal, usualQty: int 1..10000):
  require exists staff[principal = viewer, role = 'lead'] else NOT_LEAD
  return insert parts { partNumber, description, supplier, usualQty }

mutation addBin(part: parts, slot: text 1..10, cardCode: text 1..40):
  require exists staff[principal = viewer, role = 'lead'] else NOT_LEAD
  p = parts[part] ! else NOT_FOUND
  return insert bins { part: p.id, slot, cardCode }

-- Production bootstrap: the operator seat enrolls the first staff and
-- supplier rows for real account principals. Signup grants no role.
mutation bootstrapStaff(member: principal, role: enum('floor', 'lead')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal: member, role }

mutation bootstrapSupplier(name: text 1..40, member: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert suppliers { name, principal: member }
