-- Archive Reading Room Pulls.
-- Researchers request boxes ahead of a visit. Staff pull approved boxes onto
-- a cart for the visit date. Boxes in restricted collections need a curator's
-- approval first. Boxes pulled but not consulted within 3 days of the visit
-- return to the stacks automatically (nightly job). Staff keep a service log.

use personas alice, bob, carol
use identity

-- Roster: one row per privileged user. carol is the curator (curators may
-- also do staff pulls). Seeded via fixtures; only the system writes it.
table staff:
  principal: principal
  role: enum('staff', 'curator')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

-- Public catalog of collections.
table finding_aids:
  code: text 2..20
  title: text 1..200
  restricted: bool
  summary: text 1..2000
  unique code
  public 'finding aids are public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  online only

-- Boxes belonging to a collection. Listing is public; only staff curate it.
table boxes:
  aid: finding_aids
  label: text 1..40
  immutable aid
  public 'box listings are public'
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  delete <- exists staff[viewer]
  online only

-- A researcher's request for one box on one visit date.
-- status: pending -> approved -> on_cart -> served -> (stays, logged)
--   restricted boxes: pending -> curator_ok -> approved -> on_cart -> served
--   unconsulted carts: on_cart -> returned (nightly job, 3 days after visit)
--   staff may deny pending requests.
table requests:
  researcher: principal
  box: boxes
  topic: text 1..500
  visitDate: time
  status: enum('pending', 'approved', 'curator_ok', 'on_cart', 'served', 'returned', 'denied', 'withdrawn')
  withdrawalReason: text <=500 default ''
  createdAt: time default now
  by byCreated: createdAt, id
  by byVisit: visitDate, id
  immutable researcher, box, createdAt
  read <- .researcher = viewer or exists staff[viewer]
  insert <- .researcher = viewer
  update <- .researcher = viewer or exists staff[viewer]
  delete <- .researcher = viewer
  online only

-- Every box served, and to whom. Staff only.
table service_log:
  request: requests
  box: boxes
  servedTo: principal
  servedAt: time default now
  servedBy: principal
  read <- exists staff[viewer]
  insert <- exists staff[viewer]
  update <- deny
  delete <- deny
  online only

query findingAids(c: cursor ?):
  return finding_aids first 50 by .id after c

query boxesFor(aid: finding_aids, c: cursor ?):
  return boxes where .aid = aid first 50 by .id after c

query allBoxes(c: cursor ?):
  return boxes first 100 by .id after c

query myRequests(c: cursor ?):
  return requests where .researcher = viewer last 50 by byCreated after c

query allRequests(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  return requests last 50 by byCreated after c

query cartFor(visitDate: time, c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  return requests where .visitDate = visitDate and .status = 'on_cart' first 50 by byVisit after c

query serviceLog(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  return service_log last 50 by .id after c

query amStaff():
  return exists staff[viewer]

query amCurator():
  return exists staff[principal = viewer, role = 'curator']

mutation requestBox(box: boxes, topic: text 1..500, visitDate: time):
  require visitDate > now - 1d else IN_THE_PAST 'Visits must be today or later.'
  target = boxes[box] ! else NOT_FOUND
  return insert requests { researcher: viewer, box, topic, visitDate, status: 'pending' }

mutation cancelRequest(req: requests):
  r = requests[req] ! else NOT_FOUND
  require r.researcher = viewer else NOT_OWNER 'Only the requester can cancel.'
  require r.status = 'pending' else BAD_STATE 'Only pending requests can be cancelled.'
  delete requests[req]
  return null

mutation approveRequest(req: requests):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  r = requests[req] ! else NOT_FOUND
  b = boxes[r.box] ! else NOT_FOUND
  a = finding_aids[b.aid] ! else NOT_FOUND
  require r.status = 'pending' or r.status = 'curator_ok' else BAD_STATE 'Only pending requests can be approved.'
  require not a.restricted or r.status = 'curator_ok' else NEEDS_CURATOR 'Restricted collections need a curator first.'
  update requests[req] { status: 'approved' }
  return null

mutation curatorApprove(req: requests):
  require exists staff[principal = viewer, role = 'curator'] else NOT_CURATOR 'A curator must approve this.'
  r = requests[req] ! else NOT_FOUND
  require r.status = 'pending' else BAD_STATE 'Only pending requests can be approved.'
  update requests[req] { status: 'curator_ok' }
  return null

mutation denyRequest(req: requests):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  r = requests[req] ! else NOT_FOUND
  require r.status = 'pending' or r.status = 'curator_ok' else BAD_STATE 'Only pending requests can be denied.'
  update requests[req] { status: 'denied' }
  return null

mutation pullToCart(req: requests):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  r = requests[req] ! else NOT_FOUND
  require r.status = 'approved' else BAD_STATE 'Only approved requests go on the cart.'
  update requests[req] { status: 'on_cart' }
  return null

mutation serveBox(req: requests):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  r = requests[req] ! else NOT_FOUND
  require r.status = 'on_cart' else BAD_STATE 'Only boxes on the cart can be served.'
  update requests[req] { status: 'served' }
  insert service_log { request: req, box: r.box, servedTo: r.researcher, servedAt: now, servedBy: viewer }
  return null

-- Boxes pulled onto a cart but not consulted within 3 days of the visit
-- return to the stacks automatically.
job returnStale(periodStart: time, periodEnd: time):
  for r in requests:
    if r.status = 'on_cart' and r.visitDate + 3d < now:
      update requests[r.id] { status: 'returned' }
schedule nightly every 1d at 03:00: returnStale

-- Only a locally minted operator credential can provision the roster.
mutation grantStaff(principal: principal, role: enum('staff', 'curator')):
  require viewer = 'service:ops' else NOT_OPERATOR 'Operator only.'
  return insert staff { principal, role }

mutation createFindingAid(code: text 2..20, title: text 1..200, restricted: bool, summary: text 1..2000):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  return insert finding_aids { code, title, restricted, summary }

mutation createBox(aid: finding_aids, label: text 1..40):
  require exists staff[viewer] else NOT_STAFF 'Staff only.'
  parent = finding_aids[aid] ! else NOT_FOUND
  return insert boxes { aid, label }

-- Immutable audit, private to the researcher and reading-room staff.
table withdrawals:
  request: requests
  researcher: principal
  reason: text 1..500
  previousStatus: enum('pending', 'curator_ok', 'approved')
  withdrawnAt: time default now
  read <- .researcher = viewer or exists staff[viewer]
  insert <- .researcher = viewer
  update <- deny
  delete <- deny
  online only

query myWithdrawals(c: cursor ?):
  return withdrawals where .researcher = viewer first 50 by .id after c

mutation withdrawRequest(req: requests, reason: text 1..500):
  r = requests[req] ! else NOT_FOUND
  require r.researcher = viewer else NOT_OWNER 'Only the requester can withdraw.'
  require r.status = 'pending' or r.status = 'curator_ok' or r.status = 'approved' else BAD_STATE 'Withdraw before the box is pulled.'
  insert withdrawals { request: req, researcher: viewer, reason, previousStatus: r.status }
  update requests[req] { status: 'withdrawn', withdrawalReason: reason }
  return null
