use personas alice, bob, carol, morgan, visitor
use identity

-- Venue locations are verified registry data, never supplied by a claiming host.
-- UK National Grid decimetres; 50 international miles = 804672 dm.
table venues:
  owner: principal
  name: text 1..80
  town: text 1..60
  eastDm: int 0..7000000
  northDm: int 0..13000000
  unique owner
  immutable owner, name, town, eastDm, northDm
  insert <- viewer = 'service:ops'
  public 'Verified venue locations are public.'
  online only

table moderators:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  immutable principal
  online only

table packs:
  author: principal
  title: text 3..100
  status: enum('review', 'approved', 'rejected') default 'review'
  available: bool default true
  submittedAt: time default now
  ratingCount: count ratings by pack
  ratingTotal: sum ratings of .stars by pack
  immutable author, title, submittedAt
  read <- .status = 'approved' or .author = viewer or exists moderators[viewer]
  insert <- .author = viewer and .status = 'review' and exists venues[owner = viewer]
  update (old, next) <- exists moderators[viewer] or (old.author = viewer and old.status = 'approved' and old.available and next.available = false and next.status = old.status)
  online only

table questions:
  pack: packs
  body: text 20..12000
  unique pack
  immutable pack, body
  read <- exists claims[pack = .pack, host = viewer] or exists moderators[viewer]
  insert <- created packs[.pack, author = viewer]
  online only

table claims:
  pack: packs
  venue: venues
  host: principal
  usedAt: time default now
  eastDm: int 0..7000000
  northDm: int 0..13000000
  unique pack, venue else ALREADY_RUN 'Your venue has already run this pack.'
  unique pack, host
  immutable pack, venue, host, usedAt, eastDm, northDm
  read <- exists venues[owner = viewer] or exists moderators[viewer]
  insert <- .host = viewer and exists venues[.venue, owner = viewer] and exists packs[.pack, status = 'approved', available = true]
  online only

table ratings:
  pack: packs
  host: principal
  stars: int 1..5
  unique pack, host
  immutable pack, host
  read <- .host = viewer
  insert <- .host = viewer and exists claims[.pack, viewer]
  update <- .host = viewer and exists claims[.pack, viewer]
  online only

fn average(total: int, n: int):
  return divide(total, n, 1, 'half-away-from-zero') if n > 0 else null

view runCounts: count claims by .pack
  read <- exists packs[.pack, author = viewer]
  online only
fn withdrawalReason(pack: packs): withdrawals[pack = pack].reason
fn questionBody(pack: packs): questions[pack = pack].body
fn nearby(x: int, y: int, vx: int, vy: int):
  dx = x - vx
  dy = y - vy
  return dx * dx + dy * dy <= 647497027584

shape packCard = { id, title, average: average(.ratingTotal, .ratingCount), ratings: .ratingCount }

query catalog(c: cursor ?):
  return packs where .status = 'approved' and .available last 30 by .submittedAt after c packCard

query dashboard():
  return { venue: venues[owner = viewer], moderator: exists moderators[viewer] }

query myPacks(c: cursor ?):
  return packs where .author = viewer last 30 by .submittedAt after c { id, title, status, available, withdrawal: withdrawalReason(.id), venuesRun: runCounts[.id] }

query myClaims(c: cursor ?):
  return claims where .host = viewer last 30 by .usedAt after c { id, pack, usedAt, title: packs[.pack].title, rating: ratings[.pack, viewer].stars }

query packQuestions(pack: packs):
  return questions[pack = pack]

query moderationQueue(c: cursor ?):
  if exists moderators[viewer]:
    return packs where .status = 'review' first 30 by .submittedAt after c { id, title, author, questions: questionBody(.id) }
  return []

mutation submitPack(title: text 3..100, body: text 20..12000):
  require exists venues[owner = viewer] else HOST_REQUIRED 'Only registered hosts may submit packs.'
  p = insert packs { author: viewer, title }
  insert questions { pack: p.id, body }
  return p.id

mutation moderatePack(pack: packs, approve: bool):
  require exists moderators[viewer] else MODERATOR_REQUIRED 'Only moderators may review packs.'
  p = packs[pack] ! else NOT_FOUND
  require p.status = 'review' else ALREADY_REVIEWED
  update packs[pack] { status: 'approved' if approve else 'rejected' }
  return null

mutation claimPack(pack: packs): server
  v = venues[owner = viewer] ! else HOST_REQUIRED 'Only registered hosts may claim packs.'
  p = packs[pack] ! else NOT_FOUND
  require p.status = 'approved' else NOT_APPROVED
  require p.available else WITHDRAWN 'The author withdrew this pack from future runs.'
  require not exists claims[pack, viewer] else ALREADY_RUN 'Your venue has already run this pack.'
  require not exists claims where .pack = pack and .usedAt > now - 90d and nearby(.eastDm, .northDm, v.eastDm, v.northDm) else NEARBY_RUN 'A venue within 50 miles ran this pack in the last 90 days.'
  row = insert claims { pack, venue: v.id, host: viewer, eastDm: v.eastDm, northDm: v.northDm }
  return row.id

mutation ratePack(pack: packs, stars: int 1..5):
  require exists claims[pack, viewer] else CLAIM_REQUIRED 'Only hosts who have run this pack may rate it.'
  require exists packs[pack] else NOT_FOUND
  upsert ratings[pack, viewer] { pack, host: viewer, stars }
  return null

-- Only the local operator seat can enroll verified venues and moderators.
mutation provisionVenue(owner: principal, name: text 1..80, town: text 1..60, eastDm: int 0..7000000, northDm: int 0..13000000):
  require viewer = 'service:ops' else OPERATOR_REQUIRED
  return insert venues { owner, name, town, eastDm, northDm }

mutation grantModerator(principal: principal):
  require viewer = 'service:ops' else OPERATOR_REQUIRED
  return insert moderators { principal }

-- Withdrawal does not erase completed claims, ratings, or their question sheets.
table withdrawals:
  pack: packs
  author: principal
  reason: text 10..500
  withdrawnAt: time default now
  unique pack
  immutable pack, author, reason, withdrawnAt
  read <- .author = viewer or exists moderators[viewer]
  insert <- .author = viewer and exists packs[.pack, author = viewer, available = false]
  online only

mutation withdrawPack(pack: packs, reason: text 10..500):
  p = packs[pack] ! else NOT_FOUND
  require p.author = viewer else AUTHOR_REQUIRED 'Only the author may withdraw a pack.'
  require p.status = 'approved' else NOT_APPROVED
  require p.available else WITHDRAWN 'This pack has already been withdrawn.'
  update packs[pack] { available: false }
  row = insert withdrawals { pack, author: viewer, reason }
  return row.id
