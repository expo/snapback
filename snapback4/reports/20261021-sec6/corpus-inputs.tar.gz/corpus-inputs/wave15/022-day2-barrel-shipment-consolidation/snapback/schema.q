use personas alice, bob, operator, recipient
use identity

table operators:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table containers:
  label: text 3..40
  destination: text 2..60
  sailingDate: time
  arrived: bool default false
  unique label
  public 'Container schedules contain no family or cargo details.'
  insert <- exists operators[viewer] and not .arrived
  update <- exists operators[viewer]
  online only

table tracking:
  token: text 36..36
  recipient: text 2..80
  destination: text 2..60
  status: enum('registered', 'scheduled', 'arrived', 'collected') default 'registered'
  weightKg: int 1..300 ?
  container: containers ?
  unique token
  immutable token, recipient, destination
  public 'Capability lookup exposes only recipient and shipment status; no listing operation is published.'
  insert <- .status = 'registered' and .weightKg = null and .container = null
  update <- exists operators[viewer]
  online only

table barrels:
  owner: principal
  tracking: tracking
  contents: text 3..2000
  declaredValue: int 0..1000000
  collectionState: enum('awaiting', 'collected') default 'awaiting'
  at: time default now
  unique tracking
  immutable owner, tracking, at
  read <- .owner = viewer or exists operators[viewer]
  insert <- .owner = viewer and created tracking[.tracking]
  update <- exists operators[viewer]
  online only

table collections:
  barrel: barrels
  owner: principal
  collector: text 2..80
  recordedBy: principal
  at: time default now
  unique barrel
  immutable barrel, owner, collector, recordedBy, at
  read <- .owner = viewer or exists operators[viewer]
  insert <- exists operators[viewer] and .recordedBy = viewer and exists barrels[.barrel, owner = .owner]
  online only

table photos:
  barrel: barrels
  owner: principal
  photo: image <=4000000
  immutable barrel, owner, photo
  read <- .owner = viewer or exists operators[viewer]
  insert <- .owner = viewer and exists barrels[.barrel, owner = viewer]
  cap 6 by barrel
  online only

table notifications:
  owner: principal
  barrel: barrels
  message: text 1..200
  at: time default now
  unique barrel
  read <- .owner = viewer
  insert <- deny
  online only

query myBarrels():
  return barrels last 100 by .at { id, owner, contents, declaredValue, collectionState, tracking: tracking[.tracking], at }
query myRole():
  return { operator: exists operators[viewer] }
query collectionReceipt(barrel: barrels):
  return collections[barrel = barrel]
query containerList():
  return containers first 100 by .sailingDate
query barrelPhotos(barrel: barrels):
  return photos where .barrel = barrel first 6 by .id
query inbox():
  return notifications where .owner = viewer last 100 by .at
query track(token: text 36..36):
  return tracking[token = token] { recipient, destination, status, weightKg, container: containers[.container] }

mutation registerBarrel(recipient: text 2..80, destination: text 2..60, contents: text 3..2000, declaredValue: int 0..1000000, token: text 36..36):
  t = insert tracking { token, recipient, destination }
  return insert barrels { owner: viewer, tracking: t.id, contents, declaredValue }
mutation addPhoto(barrel: barrels, photo: image <=4000000):
  b = barrels[barrel] ! else NOT_FOUND
  require b.owner = viewer else NOT_OWNER
  return insert photos { barrel, owner: viewer, photo }
mutation createContainer(label: text 3..40, destination: text 2..60, sailingDate: time):
  require exists operators[viewer] else NOT_OPERATOR
  return insert containers { label, destination, sailingDate }
mutation assignBarrel(barrel: barrels, container: containers, weightKg: int 1..300):
  require exists operators[viewer] else NOT_OPERATOR
  b = barrels[barrel] ! else NOT_FOUND
  t = tracking[b.tracking] ! else NOT_FOUND
  c = containers[container] ! else NOT_FOUND
  require t.status = 'registered' else ALREADY_ASSIGNED
  require not c.arrived else CONTAINER_ARRIVED
  require c.destination = t.destination else WRONG_DESTINATION
  update tracking[t.id] { status: 'scheduled', weightKg, container }
  return null
mutation markArrived(container: containers):
  require exists operators[viewer] else NOT_OPERATOR
  c = containers[container] ! else NOT_FOUND
  update containers[c.id] { arrived: true }
  return null

mutation collectBarrel(barrel: barrels, collector: text 2..80):
  require exists operators[viewer] else NOT_OPERATOR
  b = barrels[barrel] ! else NOT_FOUND
  t = tracking[b.tracking] ! else NOT_FOUND
  require b.collectionState = 'awaiting' else ALREADY_COLLECTED
  require t.status = 'arrived' else NOT_ARRIVED
  receipt = insert collections { barrel, owner: b.owner, collector, recordedBy: viewer }
  update barrels[b.id] { collectionState: 'collected' }
  update tracking[t.id] { status: 'collected' }
  return receipt

job notifyArrivals():
  for b in barrels:
    t = tracking[b.tracking]
    if t != null and t.container != null:
      c = containers[t.container]
      if c != null and c.arrived and t.status != 'collected':
        update tracking[t.id] { status: 'arrived' }
        if not exists notifications[barrel = b.id]:
          insert notifications { owner: b.owner, barrel: b.id, message: 'Your barrel has arrived and is ready for collection.' }
schedule arrivalWatch every 1m: notifyArrivals

mutation grantOperator(principal: principal):
  require viewer = 'service:ops' else NOT_SERVICE
  return insert operators { principal }
