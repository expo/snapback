-- Effort Certification: quarterly staff effort certification on grants.
-- Personas: alice (staff), bob (staff + PI of a grant), carol (grants office
-- admin + supervisor). All tables online only; Exact uses the online adapter.

use personas alice, bob, carol

-- Grants-office administrators: the department-wide privileged role.
table admins:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- Supervisors: review and approve certifications.
table supervisors:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- Sponsored projects (grants). The catalog is department-visible; only the
-- grants office manages it.
table projects:
  title: text 1..80
  pi: principal
  public 'the project catalog is department-visible'
  insert <- exists admins[principal = viewer]
  update <- exists admins[principal = viewer]
  delete <- exists admins[principal = viewer]
  online only

-- One certification per staff member per quarter. Status moves
-- draft -> submitted -> approved, or submitted -> escalated -> approved.
table certifications:
  staff: principal
  quarter: text 4..10
  status: enum('draft', 'submitted', 'approved', 'escalated')
  submittedAt: time ?
  approvedAt: time ?
  unique staff, quarter else ALREADY_CERTIFIED 'There is already a certification for this quarter.'
  immutable staff, quarter
  read <- .staff = viewer or exists admins[principal = viewer]
  insert <- .staff = viewer
  update <- .staff = viewer or exists admins[principal = viewer]
  delete <- .staff = viewer
  cap 20 by staff
  online only

-- Effort lines. staff/quarter are immutable copies so a PI can read the
-- effort charged to their grants from this table alone.
table lines:
  certification: certifications on delete restrict
  project: projects
  staff: principal
  quarter: text 4..10
  percent: int 1..100
  unique certification, project else ALREADY_CHARGED 'This project is already on this certification.'
  immutable certification, project, staff, quarter
  read <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer] or exists projects[.project, pi = viewer]
  insert <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer]
  update <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer]
  delete <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer]
  cap 20 by certification
  online only

-- Reasons recorded for every change after approval.
table amendments:
  certification: certifications on delete cascade
  changedBy: principal
  reason: text 5..500
  at: time default now
  immutable certification, changedBy, at
  cap 100 by certification
  read <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer]
  insert <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer]
  update <- deny
  delete <- deny
  online only

-- Maintained percent total per certification, so submit can check the total
-- without scanning lines the caller might not read.
view certTotal: sum lines of .percent by .certification
  read <- exists certifications[.certification, staff = viewer] or exists admins[principal = viewer]
  online only

query myCertifications(c: cursor ?):
  return certifications where .staff = viewer last 50 by .id after c

query certification(cert: certifications):
  return certifications[cert]

query certificationLines(cert: certifications, c: cursor ?):
  return lines where .certification = cert last 50 by .id after c

query amendmentsFor(cert: certifications, c: cursor ?):
  return amendments where .certification = cert last 50 by .at after c

query allProjects(c: cursor ?):
  return projects last 50 by .id after c

query allCertifications(c: cursor ?):
  require exists admins[principal = viewer] else NOT_ADMIN 'Only the grants office sees every certification.'
  return certifications last 50 by .id after c

query pendingApprovals(c: cursor ?):
  require exists supervisors[principal = viewer] or exists admins[principal = viewer] else NOT_SUPERVISOR 'Only a supervisor or the grants office reviews certifications.'
  return certifications where .status != 'draft' and .status != 'approved' last 50 by .id after c

query piCharges(project: projects, c: cursor ?):
  p = projects[project] ! else NOT_FOUND
  require p.pi = viewer else NOT_PI 'Only the principal investigator sees charges to this grant.'
  return lines where .project = project last 50 by .id after c

mutation addProject(title: text 1..80, pi: principal):
  require exists admins[principal = viewer] else NOT_ADMIN 'Only the grants office manages projects.'
  return insert projects { title, pi }

mutation createCertification(quarter: text 4..10):
  return insert certifications { staff: viewer, quarter, status: 'draft' }

mutation addLine(cert: certifications, project: projects, percent: int 1..100):
  c = certifications[cert] ! else NOT_FOUND
  require c.staff = viewer else NOT_OWNER 'Only the owner edits this certification.'
  require c.status = 'draft' else CERT_LOCKED 'This certification is no longer a draft.'
  p = projects[project] ! else NOT_FOUND
  return insert lines { certification: cert, project, staff: viewer, quarter: c.quarter, percent }

mutation updateLine(line: lines, percent: int 1..100):
  l = lines[line] ! else NOT_FOUND
  c = certifications[l.certification] ! else NOT_FOUND
  require c.staff = viewer else NOT_OWNER 'Only the owner edits this certification.'
  require c.status = 'draft' else CERT_LOCKED 'This certification is no longer a draft.'
  update lines[line] { percent }
  return null

mutation removeLine(line: lines):
  l = lines[line] ! else NOT_FOUND
  c = certifications[l.certification] ! else NOT_FOUND
  require c.staff = viewer else NOT_OWNER 'Only the owner edits this certification.'
  require c.status = 'draft' else CERT_LOCKED 'This certification is no longer a draft.'
  if exists lines[line]:
    delete lines[line]

mutation removeCertification(cert: certifications):
  c = certifications[cert] ! else NOT_FOUND
  require c.staff = viewer else NOT_OWNER 'Only the owner edits this certification.'
  require c.status = 'draft' else CERT_LOCKED 'Only a draft certification can be removed.'
  if exists certifications[cert]:
    delete certifications[cert]

mutation submitCertification(cert: certifications):
  c = certifications[cert] ! else NOT_FOUND
  require c.staff = viewer else NOT_OWNER 'Only the owner submits this certification.'
  require c.status = 'draft' else CERT_LOCKED 'Only a draft certification can be submitted.'
  total = certTotal[cert] ?? 0
  require total = 100 else MUST_TOTAL_100 'Effort must total 100 percent.'
  update certifications[cert] { status: 'submitted', submittedAt: now }
  return null

mutation approveCertification(cert: certifications):
  c = certifications[cert] ! else NOT_FOUND
  require c.status = 'submitted' else NOT_SUBMITTED 'Only a submitted certification can be approved.'
  require exists supervisors[principal = viewer] or exists admins[principal = viewer] else NOT_SUPERVISOR 'Only a supervisor or the grants office approves.'
  update certifications[cert] { status: 'approved', approvedAt: now }
  return null

mutation approveEscalated(cert: certifications):
  c = certifications[cert] ! else NOT_FOUND
  require c.status = 'escalated' else NOT_ESCALATED 'Only an escalated certification can be approved here.'
  require exists admins[principal = viewer] else NOT_ADMIN 'Only the department administrator approves escalated certifications.'
  update certifications[cert] { status: 'approved', approvedAt: now }
  return null

mutation amendLine(line: lines, percent: int 1..100, reason: text 5..500):
  l = lines[line] ! else NOT_FOUND
  c = certifications[l.certification] ! else NOT_FOUND
  require c.staff = viewer or exists admins[principal = viewer] else NOT_OWNER 'Only the owner or the grants office amends an approved certification.'
  require c.status != 'draft' and c.status != 'submitted' else NOT_APPROVED 'Amendments need an approved certification; drafts change directly.'
  update lines[line] { percent }
  insert amendments { certification: l.certification, changedBy: viewer, reason }
  return null

-- Unapproved certifications older than two weeks go to the department
-- administrator. Full sweep: the period a cert was submitted in no longer
-- contains it by the time it ages out, so a period-bounded sweep would miss it.
job escalate():
  for c in certifications:
    if c.status = 'submitted' and c.submittedAt != null and c.submittedAt < now - 14d:
      update certifications[c.id] { status: 'escalated' }

schedule escalation every 1d at 09:00: escalate
