-- Scaffold Tag Board backend.
-- Personas: alice = scaffolding contractor (competent person), bob = trade
-- worker, carol = general contractor. Roles live in contractors; rules probe it.
use identity
use personas alice, bob, carol

table contractors:
  principal: principal
  role: enum('scaffold', 'trade', 'gc')
  unique principal
  insert <- viewer = 'service:ops'
  public 'crew roster is visible to everyone on site'
  online only

table scaffolds:
  label: text 1..80
  location: text 1..120
  erectedBy: principal
  erectedAt: time default now
  validUntil: time ?
  immutable erectedBy, erectedAt
  cap 200
  public 'every trade sees tag status on the site map'
  insert <- exists contractors[principal = viewer, role = 'scaffold']
  update <- exists contractors[principal = viewer, role = 'scaffold']
  online only

table inspections:
  scaffold: scaffolds
  inspector: principal
  inspectedAt: time default now
  validUntil: time
  photo: image <=10000000 ?
  notes: text <=500 ?
  immutable scaffold, inspector, inspectedAt
  cap 500 by scaffold
  public 'inspection history is visible to everyone on site'
  insert <- exists contractors[principal = viewer, role = 'scaffold']
  online only

table defects:
  scaffold: scaffolds
  reporter: principal
  description: text 1..500
  at: time default now
  resolved: bool default false
  immutable scaffold, reporter, at
  cap 200 by scaffold
  public 'defects are visible to everyone on site'
  insert <- .reporter = viewer
  update <- exists contractors[principal = viewer, role = 'scaffold']
  online only

table modRequests:
  scaffold: scaffolds
  requester: principal
  detail: text 1..500
  priority: enum('routine', 'urgent') default 'routine'
  status: enum('pending', 'approved', 'rejected', 'withdrawn') default 'pending'
  decidedBy: principal ?
  decidedAt: time ?
  immutable scaffold, requester
  cap 200 by scaffold
  public 'modification requests are visible to everyone on site'
  insert <- .requester = viewer
  update (old, next) <- exists contractors[principal = viewer, role = 'scaffold'] or (old.requester = viewer and old.status = 'pending' and next.status = 'withdrawn')
  online only

query board(c: cursor ?):
  return scaffolds first 100 by .id after c

query inspectionsFor(scaffold: scaffolds, c: cursor ?):
  return inspections where .scaffold = scaffold last 50 by .inspectedAt after c

query defectsFor(scaffold: scaffolds, c: cursor ?):
  return defects where .scaffold = scaffold last 50 by .at after c

query requestsFor(scaffold: scaffolds ?, c: cursor ?):
  return modRequests where (scaffold = null or .scaffold = scaffold) last 50 by .id after c

query audit(scaffold: scaffolds):
  require exists contractors[principal = viewer, role = 'gc'] or exists contractors[principal = viewer, role = 'scaffold'] else NOT_AUDIT_ROLE 'Audit history is available to the general contractor and the scaffolding contractor.'
  return { scaffold: scaffolds[scaffold], inspections: inspections where .scaffold = scaffold last 50 by .inspectedAt, defects: defects where .scaffold = scaffold last 50 by .at, requests: modRequests where .scaffold = scaffold last 50 by .id }

mutation erectScaffold(label: text 1..80, location: text 1..120):
  require exists contractors[principal = viewer, role = 'scaffold'] else NOT_SCAFFOLD_CONTRACTOR 'Only the scaffolding contractor erects scaffolds.'
  return insert scaffolds { label, location, erectedBy: viewer, erectedAt: now }

mutation inspectScaffold(scaffold: scaffolds, notes: text <=500 ?, photo: image <=10000000 ?):
  require exists contractors[principal = viewer, role = 'scaffold'] else NOT_SCAFFOLD_CONTRACTOR 'Only the scaffolding contractor inspects scaffolds.'
  s = scaffolds[scaffold] ! else NOT_FOUND
  valid = now + 7d
  insert inspections { scaffold, inspector: viewer, inspectedAt: now, validUntil: valid, notes: notes, photo: photo }
  update scaffolds[scaffold] { validUntil: valid }
  return null

mutation logDefect(scaffold: scaffolds, description: text 1..500):
  s = scaffolds[scaffold] ! else NOT_FOUND
  return insert defects { scaffold, reporter: viewer, description, at: now }

mutation resolveDefect(defect: defects):
  require exists contractors[principal = viewer, role = 'scaffold'] else NOT_SCAFFOLD_CONTRACTOR 'Only the scaffolding contractor clears defects.'
  d = defects[defect] ! else NOT_FOUND
  update defects[defect] { resolved: true }
  return null

mutation fileRequest(scaffold: scaffolds, detail: text 1..500, priority: enum('routine', 'urgent') ?):
  s = scaffolds[scaffold] ! else NOT_FOUND
  request = insert modRequests { scaffold, requester: viewer, detail, priority: priority ?? 'routine' }
  insert requestEvents { request: request.id, actor: viewer, action: 'filed', at: now }
  return request

mutation decideRequest(request: modRequests, decision: enum('approved', 'rejected')):
  require exists contractors[principal = viewer, role = 'scaffold'] else NOT_SCAFFOLD_CONTRACTOR 'Only the scaffolding contractor approves modifications.'
  r = modRequests[request] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_DECIDED 'This request was already decided.'
  update modRequests[request] { status: decision, decidedBy: viewer, decidedAt: now }
  insert requestEvents { request, actor: viewer, action: decision, at: now }
  return null

-- Only the locally provisioned operator seat can enroll real crew members.
mutation enrollCrew(principal: principal, role: enum('scaffold', 'trade', 'gc')):
  require viewer = 'service:ops' else NOT_OPERATOR 'Only the site operator enrolls crew.'
  return insert contractors { principal, role }

query myRole():
  return contractors[principal = viewer]

-- New events start at v2; historical timestamps are never fabricated.
table requestEvents:
  request: modRequests
  actor: principal
  action: enum('filed', 'approved', 'rejected', 'withdrawn')
  at: time default now
  immutable request, actor, action, at
  public 'modification lifecycle is visible to every trade'
  insert <- .actor = viewer
  online only

query eventsFor(request: modRequests, c: cursor ?):
  return requestEvents where .request = request last 100 by .at after c

mutation withdrawRequest(request: modRequests):
  r = modRequests[request] ! else NOT_FOUND
  require r.requester = viewer else NOT_REQUESTER 'Only the requesting trade can withdraw this request.'
  require r.status = 'pending' else ALREADY_DECIDED 'This request was already decided.'
  update modRequests[request] { status: 'withdrawn', decidedBy: viewer, decidedAt: now }
  insert requestEvents { request, actor: viewer, action: 'withdrawn', at: now }
  return null
