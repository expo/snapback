-- Doula Backup Rotation.
-- A collective of doulas carries private clients. Each client names a backup
-- doula who sees only the due window until the primary marks themselves
-- unavailable, which unlocks the full birth plan for the backup. The
-- coordinator sees the on-call calendar and per-doula client counts but no
-- client details. A client user sees who their backup is and when that access
-- was granted.
use identity
use personas alice, bob, carol, dave, erin

-- Coordinator roster: one row per coordinator (guide recipes roles pattern).
table coordinators:
  principal: principal
  unique principal
  read <- .principal = viewer or exists coordinators[viewer] or viewer = 'service:ops'
  insert <- exists coordinators[viewer] or viewer = 'service:ops'
  delete <- exists coordinators[viewer]
  online only

-- Collective directory + on-call calendar: visible to everyone (doulas need
-- each other's names, clients need their backup's name, coordinator needs the
-- calendar). Only the coordinator flips onCall, via the setOnCall mutation;
-- doulas register their own directory row.
table doulas:
  principal: principal
  displayName: text 1..60
  onCall: bool default false
  unique principal
  public 'the collective directory and on-call calendar are visible to everyone'
  insert <- .principal = viewer or exists coordinators[viewer]
  update <- .principal = viewer or exists coordinators[viewer]
  online only

-- Full private client record. The primary doula always reads it. The backup
-- doula reads it only once the primary has marked themselves unavailable.
-- Nobody else (not the coordinator, not other doulas, not the client user)
-- reads this table.
table clients:
  primaryDoula: principal
  backupDoula: principal
  clientUser: principal ?
  clientName: text 1..80
  contact: text 1..120
  birthPlan: text 1..2000
  dueStart: time
  dueEnd: time
  unavailable: bool default false
  accessGrantedAt: time ?
  read <- .primaryDoula = viewer or (.backupDoula = viewer and .unavailable = true)
  insert <- .primaryDoula = viewer
  update <- .primaryDoula = viewer
  delete <- .primaryDoula = viewer
  immutable primaryDoula
  cap 200 by primaryDoula
  online only

-- Shared per-client card: due window, backup assignment and unlock status.
-- Readable by the primary, the backup (always: this is the due-window view)
-- and the client user (who sees their backup + granted-at here). One row per
-- client; mutations on clients mirror the shared fields here atomically.
table coverage:
  acknowledged: bool default false
  client: clients on delete cascade
  primaryDoula: principal
  backupDoula: principal
  clientUser: principal ?
  dueStart: time
  dueEnd: time
  unavailable: bool default false
  accessGrantedAt: time ?
  read <- .primaryDoula = viewer or .backupDoula = viewer or .clientUser = viewer
  insert <- .primaryDoula = viewer
  update <- .primaryDoula = viewer or .backupDoula = viewer
  delete <- .primaryDoula = viewer
  immutable client, primaryDoula
  unique client
  online only

-- Coordinator counts without details: per-doula client totals readable only
-- by coordinators, even though the source rows are hidden from them.
view clientCounts: count clients by .primaryDoula
  read <- exists coordinators[viewer]

query myClients(c: cursor ?):
  return clients where .primaryDoula = viewer first 100 by .id after c

query backupDue(c: cursor ?):
  return coverage where .backupDoula = viewer first 100 by .id after c

query backupFull(clientId: clients):
  return clients[clientId]

query myBackup(c: cursor ?):
  return coverage where .clientUser = viewer first 10 by .id after c

query roster(c: cursor ?):
  return doulas first 100 by .id after c

query countsByDoula(c: cursor ?):
  require exists coordinators[viewer] else NOT_COORDINATOR
  return clientCounts first 100 by .primaryDoula after c

mutation registerDoula(displayName: text 1..60):
  return insert doulas { principal: viewer, displayName }

mutation addClient(clientName: text 1..80, contact: text 1..120, birthPlan: text 1..2000, backup: doulas, clientUser: principal ?, dueStart: time, dueEnd: time):
  require exists doulas[viewer] else NOT_DOULA 'Only a registered doula carries clients.'
  require dueStart < dueEnd else BAD_WINDOW 'The due window must start before it ends.'
  b = doulas[backup] ! else NOT_FOUND
  c = insert clients { primaryDoula: viewer, backupDoula: b.principal, clientUser, clientName, contact, birthPlan, dueStart, dueEnd }
  insert coverage { client: c.id, primaryDoula: viewer, backupDoula: b.principal, clientUser, dueStart, dueEnd }
  return c

mutation assignBackup(clientId: clients, backup: doulas):
  c = clients[clientId] ! else NOT_FOUND
  require c.primaryDoula = viewer else NOT_PRIMARY
  require c.unavailable = false else COVERAGE_ACTIVE 'Mark available before changing the backup.'
  b = doulas[backup] ! else NOT_FOUND
  update clients[clientId] { backupDoula: b.principal }
  update coverage[c.id] { backupDoula: b.principal, acknowledged: false }
  return null

mutation setUnavailable(clientId: clients, unavailable: bool):
  c = clients[clientId] ! else NOT_FOUND
  require c.primaryDoula = viewer else NOT_PRIMARY
  require c.unavailable != unavailable else NO_CHANGE 'Availability is already set.'
  if unavailable:
    update clients[clientId] { unavailable: true, accessGrantedAt: now }
    update coverage[c.id] { unavailable: true, accessGrantedAt: now, acknowledged: false }
  else:
    update clients[clientId] { unavailable: false }
    update coverage[c.id] { unavailable: false, acknowledged: false }
  return null

mutation updateDetails(clientId: clients, contact: text 1..120, birthPlan: text 1..2000):
  c = clients[clientId] ! else NOT_FOUND
  require c.primaryDoula = viewer else NOT_PRIMARY
  update clients[clientId] { contact, birthPlan }
  return null

mutation setOnCall(doula: doulas, onCall: bool):
  require exists coordinators[viewer] else NOT_COORDINATOR
  update doulas[doula] { onCall }
  return null

-- Only the operator seat (or an existing coordinator) can enrol a coordinator.
mutation grantCoordinator(principal: principal):
  require viewer = 'service:ops' or exists coordinators[viewer] else NOT_COORDINATOR
  return insert coordinators { principal }

-- A receipt contains no client name, contact or plan. The client and both
-- doulas see who acknowledged each grant; coordinators see none of it.
table acknowledgements:
  client: clients on delete cascade
  primaryDoula: principal
  backupDoula: principal
  clientUser: principal ?
  accessGrantedAt: time
  acknowledgedAt: time
  read <- .primaryDoula = viewer or .backupDoula = viewer or .clientUser = viewer
  insert <- .backupDoula = viewer
  cap 100 by client
  immutable client, primaryDoula, backupDoula, clientUser, accessGrantedAt, acknowledgedAt
  online only

query handoffHistory(clientId: clients, c: cursor ?):
  return acknowledgements where .client = clientId first 50 by .id after c

mutation acknowledgeBackup(coverageId: coverage):
  c = coverage[coverageId] ! else NOT_FOUND
  require c.backupDoula = viewer else NOT_BACKUP 'Only the assigned backup can acknowledge.'
  require c.unavailable = true else PLAN_LOCKED 'The primary has not granted access.'
  require c.acknowledged = false else ALREADY_ACKNOWLEDGED 'This handoff is already acknowledged.'
  granted = c.accessGrantedAt ! else PLAN_LOCKED
  update coverage[coverageId] { acknowledged: true }
  return insert acknowledgements { client: c.client, primaryDoula: c.primaryDoula, backupDoula: viewer, clientUser: c.clientUser, accessGrantedAt: granted, acknowledgedAt: now }
