-- Arborist Hazard Tags schema
use personas alice, bob, carol, dave

-- Role rosters, provisioned out of band (seed/fixtures). No app operation writes them.
table arborists:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table board:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table crews:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table residents:
  principal: principal
  lot: text 1..40
  unique principal, lot
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table trees:
  lot: text 1..40
  species: text 1..80
  risk: enum('low', 'moderate', 'high', 'extreme')
  photo: text <=500 ?
  action: text 1..200
  assessedBy: principal
  assessedAt: time
  immutable lot, assessedBy
  read <- exists arborists[viewer] or exists board[viewer] or exists crews[viewer] or exists residents[viewer, .lot]
  insert <- exists arborists[viewer]
  update <- exists arborists[viewer]
  delete <- exists arborists[viewer]
  online only

table jobs:
  tree: trees
  lot: text 1..40
  kind: enum('pruning', 'removal')
  status: enum('approved', 'assigned', 'done') default 'approved'
  risk: enum('low', 'moderate', 'high', 'extreme')
  dueAt: time
  afterPhoto: text <=500 ?
  approvedBy: principal
  approvedAt: time
  completedBy: principal ?
  doneAt: time ?
  immutable tree, lot, approvedBy, approvedAt
  read <- exists arborists[viewer] or exists board[viewer] or exists crews[viewer] or exists residents[viewer, .lot]
  insert <- exists board[viewer] and exists trees[.tree, lot = .lot]
  update <- exists board[viewer] or exists crews[viewer]
  delete <- exists board[viewer]
  online only

-- Staff views
query allTrees(c: cursor ?):
  require exists arborists[viewer] or exists board[viewer] or exists crews[viewer] else NOT_STAFF
  return trees last 50 by .id after c

-- Resident view: only their own lot; lot is an explicit argument so the rule is checkable.
query myTrees(lot: text 1..40, c: cursor ?):
  require exists residents[viewer, lot] else NOT_RESIDENT
  return trees where .lot = lot last 50 by .id after c

-- Crew + board work queue
query workQueue(c: cursor ?):
  require exists crews[viewer] or exists board[viewer] else NOT_CREW
  return jobs last 50 by .dueAt after c

-- Board alert: approved/assigned high-risk jobs past due. Every job is high-risk
-- by construction (approveJob requires it), so no risk filter needed here.
query overdueJobs(c: cursor ?):
  require exists board[viewer] else NOT_BOARD
  return jobs where .status != 'done' and .dueAt < now last 50 by .dueAt after c

-- History for one tree: who knew what and when (assessed/approved/completed by + at).
query jobHistory(tree: trees, c: cursor ?):
  t = trees[tree] ! else NOT_FOUND
  return jobs where .tree = tree last 50 by .id after c

mutation assessTree(lot: text 1..40, species: text 1..80, risk: enum('low', 'moderate', 'high', 'extreme'), photo: text <=500 ?, action: text 1..200):
  require exists arborists[viewer] else NOT_ARBORIST
  return insert trees { lot, species, risk, photo, action, assessedBy: viewer, assessedAt: now }

mutation updateAssessment(tree: trees, risk: enum('low', 'moderate', 'high', 'extreme'), action: text 1..200, photo: text <=500 ?):
  require exists arborists[viewer] else NOT_ARBORIST
  t = trees[tree] ! else NOT_FOUND
  update trees[tree] { risk, action, photo: photo ?? t.photo }
  return null

mutation approveJob(tree: trees, kind: enum('pruning', 'removal'), dueAt: time):
  require exists board[viewer] else NOT_BOARD
  t = trees[tree] ! else NOT_FOUND
  require t.risk = 'high' or t.risk = 'extreme' else RISK_TOO_LOW 'Only high or extreme risk trees get board-approved work.'
  return insert jobs { tree, lot: t.lot, kind, risk: t.risk, dueAt, approvedBy: viewer, approvedAt: now }

mutation assignJob(job: jobs):
  require exists board[viewer] else NOT_BOARD
  j = jobs[job] ! else NOT_FOUND
  require j.status = 'approved' else BAD_STATUS 'Only approved jobs can be assigned.'
  update jobs[job] { status: 'assigned' }
  return null

mutation completeJob(job: jobs, afterPhoto: text <=500 ?):
  require exists crews[viewer] else NOT_CREW
  j = jobs[job] ! else NOT_FOUND
  require j.status != 'done' else ALREADY_DONE 'This job is already done.'
  update jobs[job] { status: 'done', afterPhoto: afterPhoto ?? j.afterPhoto, completedBy: viewer, doneAt: now }
  return null
