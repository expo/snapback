use identity
use personas alice, bob, ruth, board, visitor

table staff:
  principal: principal
  role: enum('researcher', 'board')
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table applications:
  owner: principal
  ownerName: text 2..80
  houseName: text 3..100
  address: text 5..200
  builtYear: int 1600..1940
  latitude: int -90000000..90000000
  longitude: int -180000000..180000000
  research: text 20..4000
  showOwner: bool default false
  status: enum('draft', 'submitted', 'evidence_requested', 'ready_for_board', 'approved', 'rejected', 'withdrawn') default 'draft'
  decisionNote: text <=1000 default ''
  withdrawalReason: text <=1000 default ''
  at: time default now
  immutable owner, ownerName, houseName, address, builtYear, latitude, longitude, research, at
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer and .status = 'draft' and .decisionNote = '' and .withdrawalReason = ''
  update (old, next) <- (old.owner = viewer and next.withdrawalReason = old.withdrawalReason and next.decisionNote = old.decisionNote and ((next.status = old.status) or (old.status = 'draft' and next.status = 'submitted') or (old.status = 'evidence_requested' and next.status = 'submitted'))) or (old.owner = viewer and (old.status = 'draft' or old.status = 'submitted' or old.status = 'evidence_requested') and next.status = 'withdrawn' and next.withdrawalReason != '' and next.decisionNote = old.decisionNote and next.showOwner = old.showOwner) or (exists staff[viewer, role = 'researcher'] and next.withdrawalReason = old.withdrawalReason and next.showOwner = old.showOwner and next.decisionNote = old.decisionNote and (old.status = 'submitted' or old.status = 'evidence_requested') and (next.status = 'evidence_requested' or next.status = 'ready_for_board')) or (exists staff[viewer, role = 'board'] and next.withdrawalReason = old.withdrawalReason and old.status = 'ready_for_board' and (next.status = 'approved' or next.status = 'rejected') and next.showOwner = old.showOwner)
  online only

table evidence:
  application: applications
  label: text 3..120
  kind: enum('deed', 'photo', 'research')
  attachment: file <=10000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png')
  at: time default now
  immutable application, label, kind, attachment, at
  read through .application
  insert <- .application.owner = viewer and (.application.status = 'draft' or .application.status = 'evidence_requested')
  online only

table requests:
  application: applications
  message: text 10..1000
  author: principal
  at: time default now
  immutable application, message, author, at
  read through .application
  insert <- .author = viewer and exists staff[viewer, role = 'researcher'] and (.application.status = 'submitted' or .application.status = 'evidence_requested')
  online only

table tourStops:
  application: applications
  houseName: text 3..100
  address: text 5..200
  builtYear: int 1600..1940
  latitude: int -90000000..90000000
  longitude: int -180000000..180000000
  ownerName: text 2..80 ?
  unique application
  immutable application, houseName, address, builtYear, latitude, longitude
  public 'Approved historic houses form the public walking tour; owner attribution is opt-in.'
  insert <- exists staff[viewer, role = 'board'] and .application.status = 'approved'
  update <- .application.owner = viewer
  online only

query myRole():
  return staff[principal = viewer]
query dashboard(c: cursor ?):
  if exists staff[viewer]:
    return applications last 100 by .at after c
  return applications where .owner = viewer last 100 by .at after c
query applicationDetail(application: applications):
  return applications[application]
query evidenceFor(application: applications, c: cursor ?):
  return evidence where .application = application first 100 by .at after c
query requestsFor(application: applications, c: cursor ?):
  return requests where .application = application last 100 by .at after c
query walkingTour(c: cursor ?):
  return tourStops first 100 by .id after c

mutation createApplication(ownerName: text 2..80, houseName: text 3..100, address: text 5..200, builtYear: int 1600..1940, latitude: int -90000000..90000000, longitude: int -180000000..180000000, research: text 20..4000, showOwner: bool):
  require not exists staff[viewer] else OWNERS_ONLY
  return insert applications { owner: viewer, ownerName, houseName, address, builtYear, latitude, longitude, research, showOwner }
mutation addEvidence(application: applications, label: text 3..120, kind: enum('deed', 'photo', 'research'), attachment: file <=10000000 ('application/pdf', 'text/plain', 'image/jpeg', 'image/png')):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else OWNER_ONLY
  require a.status = 'draft' or a.status = 'evidence_requested' else FILE_LOCKED
  return insert evidence { application, label, kind, attachment }
mutation submitApplication(application: applications):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else OWNER_ONLY
  require a.status = 'draft' or a.status = 'evidence_requested' else NOT_EDITABLE
  update applications[application] { status: 'submitted' }
mutation requestEvidence(application: applications, message: text 10..1000):
  require exists staff[viewer, role = 'researcher'] else RESEARCHER_ONLY
  a = applications[application] ! else NOT_FOUND
  require a.status = 'submitted' or a.status = 'evidence_requested' else NOT_IN_REVIEW
  insert requests { application, message, author: viewer }
  update applications[application] { status: 'evidence_requested' }
mutation sendToBoard(application: applications):
  require exists staff[viewer, role = 'researcher'] else RESEARCHER_ONLY
  a = applications[application] ! else NOT_FOUND
  require a.status = 'submitted' or a.status = 'evidence_requested' else NOT_IN_REVIEW
  update applications[application] { status: 'ready_for_board' }
mutation decideApplication(application: applications, decision: enum('approved', 'rejected'), note: text 10..1000):
  require exists staff[viewer, role = 'board'] else BOARD_ONLY
  a = applications[application] ! else NOT_FOUND
  require a.status = 'ready_for_board' else NOT_READY
  update applications[application] { status: decision, decisionNote: note }
  if decision = 'approved':
    insert tourStops { application, houseName: a.houseName, address: a.address, builtYear: a.builtYear, latitude: a.latitude, longitude: a.longitude, ownerName: a.ownerName if a.showOwner else null }
mutation setAttribution(application: applications, showOwner: bool):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else OWNER_ONLY
  update applications[application] { showOwner }
  if a.status = 'approved':
    update tourStops[application = application] { ownerName: a.ownerName if showOwner else null }

-- Only a locally minted operator seat may provision society staff.
mutation grantStaff(principal: principal, role: enum('researcher', 'board')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert staff { principal, role }

-- A private immutable record of the owner's decision to leave the review queue.
table withdrawals:
  application: applications
  author: principal
  reason: text 10..1000
  at: time default now
  unique application
  immutable application, author, reason, at
  read through .application
  insert <- .application.owner = viewer and .author = viewer and (.application.status = 'draft' or .application.status = 'submitted' or .application.status = 'evidence_requested')
  online only

query withdrawalsFor(application: applications, c: cursor ?):
  return withdrawals where .application = application last 100 by .at after c

mutation withdrawApplication(application: applications, reason: text 10..1000):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else OWNER_ONLY
  require a.status = 'draft' or a.status = 'submitted' or a.status = 'evidence_requested' else WITHDRAWAL_CLOSED
  insert withdrawals { application, author: viewer, reason }
  update applications[application] { status: 'withdrawn', withdrawalReason: reason }
