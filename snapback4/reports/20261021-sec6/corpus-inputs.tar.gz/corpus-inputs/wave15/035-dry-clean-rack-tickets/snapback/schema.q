use personas alice, bob, clerk, manager
effect sendText retry 5 backoff 2s deadline 1d

table staff:
  principal: principal
  role: enum('clerk', 'manager')
  unique principal
  read <- .principal = viewer
  online only

table customers:
  principal: principal
  name: text 1..80
  phone: text 8..20
  unique principal
  read <- .principal = viewer or exists staff[viewer]
  online only

table tickets:
  number: int 1..999999
  owner: principal
  items: text 1..240
  pieces: int 1..100
  rack: text 1..16
  status: enum('received', 'cleaned', 'ready', 'collected', 'donation_pending', 'donated')
  chargeCents: int 0..1000000
  paidCents: int 0..1000000
  receivedAt: time default now
  readyAt: time ?
  reminded: bool default false
  unique number
  immutable number, owner, receivedAt, items, pieces
  read <- .owner = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  update <- .owner = viewer or exists staff[viewer]
  online only

table adjustments:
  ticket: tickets
  owner: principal
  actor: principal ?
  action: text 1..40
  note: text 1..240
  status: text 1..24
  rack: text 1..16
  chargeCents: int 0..1000000
  paidCents: int 0..1000000
  at: time default now
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer or exists staff[viewer]
  online only

table payments:
  ticket: tickets
  owner: principal
  cents: int 1..1000000
  at: time default now
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer
  online only

table texts:
  ticket: tickets
  owner: principal
  kind: enum('ready', 'reminder')
  body: text 1..240
  at: time default now
  unique ticket, kind
  read <- .owner = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  online only

fn audit(ticket: tickets, action: text 1..40, note: text 1..240):
  t = tickets[ticket] ! else NOT_FOUND
  insert adjustments { ticket, owner: t.owner, actor: viewer, action, note, status: t.status, rack: t.rack, chargeCents: t.chargeCents, paidCents: t.paidCents }

query myRole():
  return staff[viewer]

query customerList():
  if exists staff[viewer]:
    return customers first 100 by .id
  return customers where .principal = viewer first 1 by .id

query ticketList(c: cursor ?):
  if exists staff[viewer]:
    return tickets last 50 by .receivedAt after c
  return tickets where .owner = viewer last 50 by .receivedAt after c

query ticketDetail(ticket: tickets):
  return tickets[ticket] ! else NOT_FOUND

query history(ticket: tickets, c: cursor ?):
  t = tickets[ticket] ! else NOT_FOUND
  return adjustments where .ticket = t.id last 50 by .at after c

query paymentHistory(ticket: tickets, c: cursor ?):
  t = tickets[ticket] ! else NOT_FOUND
  return payments where .ticket = t.id last 50 by .at after c

query textHistory(ticket: tickets):
  t = tickets[ticket] ! else NOT_FOUND
  return texts where .ticket = t.id last 10 by .at

query ownerOverview():
  require exists staff[principal = viewer, role = 'manager'] else MANAGER_ONLY
  intake = count(tickets where .receivedAt >= day(now) * 1d)
  charges = sum(tickets, .chargeCents)
  paid = sum(tickets, .paidCents)
  awaitingApproval = count(tickets where .status = 'donation_pending')
  return { intake, outstandingCents: charges - paid, awaitingApproval }

mutation intake(number: int 1..999999, owner: principal, items: text 1..240, pieces: int 1..100, rack: text 1..16, chargeCents: int 0..1000000):
  require exists staff[viewer] else STAFF_ONLY
  require exists customers[principal = owner] else CUSTOMER_NOT_FOUND
  t = insert tickets { number, owner, items, pieces, rack, chargeCents, paidCents: 0, status: 'received', readyAt: null }
  audit(t.id, 'intake', 'Order received at counter')
  return t

mutation advanceStatus(ticket: tickets):
  require exists staff[viewer] else STAFF_ONLY
  t = tickets[ticket] ! else NOT_FOUND
  if t.status = 'received':
    update tickets[t] { status: 'cleaned' }
  else if t.status = 'cleaned':
    update tickets[t] { status: 'ready', readyAt: now }
    c = customers[principal = t.owner] ! else CUSTOMER_NOT_FOUND
    body = 'Your dry cleaning is ready for pickup.'
    insert texts { ticket, owner: t.owner, kind: 'ready', body }
    emit sendText { phone: c.phone, body, ticket, kind: 'ready' } once [ticket, 'ready']
  else if t.status = 'ready' or t.status = 'donation_pending':
    require t.paidCents = t.chargeCents else BALANCE_DUE
    update tickets[t] { status: 'collected' }
  else:
    require false else INVALID_TRANSITION
  audit(ticket, 'status', 'Counter advanced status')
  return tickets[ticket]

mutation moveRack(ticket: tickets, rack: text 1..16, note: text 1..240):
  require exists staff[viewer] else STAFF_ONLY
  t = tickets[ticket] ! else NOT_FOUND
  require t.status != 'collected' and t.status != 'donated' else CLOSED
  update tickets[t] { rack }
  audit(ticket, 'rack', note)
  return tickets[ticket]

mutation adjustCharge(ticket: tickets, chargeCents: int 0..1000000, note: text 1..240):
  require exists staff[principal = viewer, role = 'manager'] else MANAGER_ONLY
  t = tickets[ticket] ! else NOT_FOUND
  require chargeCents >= t.paidCents else BELOW_PAID
  update tickets[t] { chargeCents }
  audit(ticket, 'charge', note)
  return tickets[ticket]

-- Demo capture: replace with a payment provider's verified capture callback before deployment.
mutation pay(ticket: tickets, cents: int 1..1000000):
  t = tickets[ticket] ! else NOT_FOUND
  require t.owner = viewer else OWNER_ONLY
  require cents <= t.chargeCents - t.paidCents else OVERPAYMENT
  p = insert payments { ticket, owner: viewer, cents }
  update tickets[t] { paidCents: t.paidCents + cents }
  audit(ticket, 'payment', 'Demo online payment recorded')
  return p

mutation approveDonation(ticket: tickets, note: text 1..240):
  require exists staff[principal = viewer, role = 'manager'] else MANAGER_ONLY
  t = tickets[ticket] ! else NOT_FOUND
  require t.status = 'donation_pending' else NOT_PENDING
  require t.readyAt != null and t.readyAt <= now - 90d else TOO_EARLY
  update tickets[t] { status: 'donated' }
  audit(ticket, 'donation', note)
  return tickets[ticket]

job ageUnclaimed():
  for t in tickets:
    if t.readyAt != null and (t.status = 'ready' or t.status = 'donation_pending'):
      if t.readyAt <= now - 30d and not t.reminded:
        c = customers[principal = t.owner]
        if c != null:
          body = 'Reminder: your dry cleaning is still awaiting pickup.'
          insert texts { ticket: t.id, owner: t.owner, kind: 'reminder', body }
          emit sendText { phone: c.phone, body, ticket: t.id, kind: 'reminder' } once [t.id, 'reminder']
          update tickets[t] { reminded: true }
          insert adjustments { ticket: t.id, owner: t.owner, actor: null, action: 'reminder', note: '30-day pickup reminder queued', status: t.status, rack: t.rack, chargeCents: t.chargeCents, paidCents: t.paidCents }
      if t.readyAt <= now - 90d and t.status = 'ready':
        update tickets[t] { status: 'donation_pending' }
        insert adjustments { ticket: t.id, owner: t.owner, actor: null, action: 'donation_pending', note: '90 days unclaimed; manager approval required', status: 'donation_pending', rack: t.rack, chargeCents: t.chargeCents, paidCents: t.paidCents }
schedule dailyAging every 1d at 08:00: ageUnclaimed
