use identity
use personas alice, bob, ranger

table rangers:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  immutable principal
  sync to .principal

table summits:
  name: text 1..80
  code: text 3..40
  elevation: int 1..9000
  unique code
  public 'Summit names and posted register codes are public.'
  insert <- viewer = 'service:ops'
  immutable name, code, elevation
  sync public

table entries:
  owner: principal
  summit: summits
  note: text 1..1000
  shared: bool
  at: time
  hidden: bool default false
  moderation: enum('unreviewed', 'hidden') default 'unreviewed'
  unique owner, summit, day(at) else ALREADY_SIGNED 'You already signed this summit today.'
  immutable owner, summit, note, shared, at
  read <- .owner = viewer or exists rangers[viewer]
  insert <- .owner = viewer and .hidden = false
  update (old, next) <- exists rangers[viewer] and next.hidden = true and next.moderation = 'hidden'
  sync

table posts:
  entry: entries
  owner: principal
  summit: summits
  note: text 1..1000
  at: time
  unique entry
  immutable entry, owner, summit, note, at
  public 'Hikers explicitly choose to publish these notes and photos.'
  insert <- .owner = viewer and exists entries[.entry, owner = viewer, shared = true, hidden = false]
  delete <- exists rangers[viewer]
  sync public last 100 by .at

table photos:
  entry: entries
  owner: principal
  shared: bool
  hidden: bool default false
  photo: image <=5000000
  unique entry
  immutable entry, owner, shared, photo
  read <- .owner = viewer or exists rangers[viewer] or (.shared and not .hidden)
  insert <- .owner = viewer and .hidden = false and exists entries[.entry, owner = viewer, shared = .shared]
  update <- exists rangers[viewer]
  online only

table moderationActions:
  entry: entries
  owner: principal
  ranger: principal
  reason: text 10..500
  at: time
  unique entry
  immutable entry, owner, ranger, reason, at
  read <- .owner = viewer or exists rangers[viewer]
  insert <- .ranger = viewer and exists rangers[viewer] and exists entries[.entry, owner = .owner, shared = true, hidden = false]
  online only

view dailyCounts: count entries by .summit, day(.at)
  public 'Daily summit counts include private entries, without their notes or photos.'
  online only
view annualCounts: count entries by .owner, year(.at)
  public 'Yearly climb counts and hiker names form the leaderboard.'
  online only

query summitList():
  return summits first 50 by .name
query publicNotes(summit: summits):
  return posts where .summit = summit last 100 by .at
query summitDays(summit: summits):
  return dailyCounts where .summit = summit last 30 by .day
query mySummits():
  return entries where .owner = viewer last 100 by .at
query leaderboard(yr: int 2000..2100):
  return annualCounts where .year = yr last 100 by .value
query myRank(yr: int 2000..2100):
  n = annualCounts[viewer, yr]
  ahead = count(annualCounts where .year = yr and .value > n)
  return { climbs: n, rank: ahead + 1 }
query entryPhoto(entry: entries):
  return photos[entry = entry]
query rangerEntries():
  require exists rangers[viewer] else RANGER_ONLY 'Only rangers may review the full register.'
  return entries last 100 by .at

mutation signRegister(code: text 3..40, note: text 1..1000, shared: bool, at: time, photo: image <=5000000 ?):
  s = summits[code = code] ! else INVALID_CODE 'Use the code posted at the summit.'
  require at <= now + 5m else FUTURE_VISIT 'The visit time cannot be in the future.'
  e = insert entries { owner: viewer, summit: s.id, note, shared, at }
  if shared:
    insert posts { entry: e, owner: viewer, summit: s.id, note, at }
  if photo != null:
    insert photos { entry: e, owner: viewer, shared, photo }
  return e

mutation hidePost(entry: entries, reason: text 10..500):
  require exists rangers[viewer] else RANGER_ONLY 'Only rangers may hide posts.'
  e = entries[entry] ! else NOT_FOUND
  require e.shared else PRIVATE_ENTRY 'Private entries are already excluded from the public register.'
  require not e.hidden else ALREADY_HIDDEN 'This post already has a moderation record.'
  insert moderationActions { entry, owner: e.owner, ranger: viewer, reason, at: now }
  update entries[entry] { hidden: true, moderation: 'hidden' }
  if exists posts[entry = entry]:
    delete posts[entry = entry]
  if exists photos[entry = entry]:
    update photos[entry = entry] { hidden: true }
  return null

query myRangerSeat():
  return rangers[viewer]

mutation provisionRanger(principal: principal):
  require viewer = 'service:ops' else OPERATOR_ONLY 'Only the operator may provision ranger seats.'
  return insert rangers { principal }

mutation createSummit(name: text 1..80, code: text 3..40, elevation: int 1..9000):
  require viewer = 'service:ops' else OPERATOR_ONLY 'Only the operator may create summit registers.'
  return insert summits { name, code, elevation }

query moderationHistory(entry: entries):
  require exists entries[entry] else NOT_FOUND 'This entry is not available to you.'
  return moderationActions where .entry = entry first 20 by .at
