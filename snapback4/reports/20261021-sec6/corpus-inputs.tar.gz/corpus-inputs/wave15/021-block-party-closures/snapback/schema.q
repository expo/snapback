-- Block Party Street Closures.
-- Residents apply to close their street; neighbors sign submitted
-- applications; city staff approve with barricade requirements and a
-- delivery/pickup schedule; approved closures are public for drivers;
-- organizers track a checklist with an insurance-confirmation deadline.
use identity
use personas alice, bob, carol

table roles:
  principal: principal
  role: enum('city')
  unique principal
  read <- .principal = viewer or exists roles[viewer]
  insert <- exists roles[viewer] or viewer = 'service:ops'
  update <- exists roles[viewer] or viewer = 'service:ops'
  delete <- exists roles[viewer]
  online only

table applications:
  organizer: principal
  title: text 1..80
  street: text 1..80
  blockRange: text 1..80
  partyDate: time
  households: int 1..200
  status: enum('draft', 'submitted', 'approved', 'rejected') default 'draft'
  barricades: int 0..100 ?
  deliveryAt: time ?
  pickupAt: time ?
  insuranceConfirmed: bool default false
  insuranceDeadline: time ?
  note: text <=500 ?
  immutable organizer
  read <- .organizer = viewer or exists roles[viewer] or .status = 'submitted' or .status = 'approved'
  insert <- .organizer = viewer
  update <- .organizer = viewer or exists roles[viewer]
  delete <- .organizer = viewer
  cap 200 by organizer
  online only

table signatures:
  application: applications on delete cascade
  organizer: principal
  signer: principal
  signerName: text 1..80
  address: text 1..120
  at: time default now
  unique application, signer else ALREADY_SIGNED 'You already signed this application.'
  cap 245 by application
  immutable application, organizer, signer
  read <- .signer = viewer or .organizer = viewer or exists roles[viewer]
  insert <- .signer = viewer and .organizer = .application.organizer
  online only

view sigCount: count signatures by .application
  read <- allow

query eventDetails(application: applications):
  return applications[application] { id, title, street, blockRange, partyDate, households, status, signatures: sigCount[.id] }

query progress(application: applications):
  return sigCount[application]

query publicClosures(c: cursor ?):
  return applications where .status = 'approved' first 50 by .partyDate after c { id, title, street, blockRange, partyDate, households, status }

query openPetitions(c: cursor ?):
  return applications where .status = 'submitted' first 50 by .partyDate after c { id, title, street, blockRange, partyDate, households, status, signatures: sigCount[.id] }

query myApplications(c: cursor ?):
  return applications where .organizer = viewer last 20 by .id after c

query reviewQueue(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF 'Only city staff can review applications.'
  return applications where .status = 'submitted' last 50 by .id after c

query checklist(application: applications):
  a = applications[application] ! else NOT_FOUND
  require a.organizer = viewer else NOT_ORGANIZER 'Only the organizer sees this checklist.'
  return applications[application] { id, title, street, blockRange, partyDate, households, status, barricades, deliveryAt, pickupAt, insuranceConfirmed, insuranceDeadline, signatures: sigCount[.id] }

query signaturesFor(application: applications, c: cursor ?):
  a = applications[application] ! else NOT_FOUND
  require a.organizer = viewer or exists roles[viewer] else NOT_ORGANIZER 'Only the organizer or city staff sees signatures.'
  return signatures where .application = application first 100 by .id after c { id, signerName, address, at }

mutation apply(title: text 1..80, street: text 1..80, blockRange: text 1..80, partyDate: time, households: int 1..200):
  require partyDate > now else BAD_DATE 'The party must be in the future.'
  return insert applications { organizer: viewer, title, street, blockRange, partyDate, households }

mutation editDraft(application: applications, title: text 1..80, street: text 1..80, blockRange: text 1..80, partyDate: time, households: int 1..200):
  a = applications[application] ! else NOT_FOUND
  require a.organizer = viewer else NOT_ORGANIZER 'Only the organizer edits this application.'
  require a.status = 'draft' else NOT_DRAFT 'Only drafts can be edited.'
  require partyDate > now else BAD_DATE 'The party must be in the future.'
  update applications[application] { title, street, blockRange, partyDate, households }
  return null

mutation submitApplication(application: applications):
  a = applications[application] ! else NOT_FOUND
  require a.organizer = viewer else NOT_ORGANIZER 'Only the organizer submits this application.'
  require a.status = 'draft' else NOT_DRAFT 'Only drafts can be submitted.'
  update applications[application] { status: 'submitted' }
  return null

mutation sign(application: applications, signerName: text 1..80, address: text 1..120):
  a = applications[application] ! else NOT_FOUND
  require a.status = 'submitted' else NOT_SIGNABLE 'This application is not collecting signatures.'
  require not exists signatures[application, viewer] else ALREADY_SIGNED 'You already signed this application.'
  return insert signatures { application, organizer: a.organizer, signer: viewer, signerName, address }

mutation review(application: applications, approve: bool, barricades: int 0..100 ?, deliveryAt: time ?, pickupAt: time ?, note: text <=500 ?):
  require exists roles[viewer] else NOT_STAFF 'Only city staff can review applications.'
  a = applications[application] ! else NOT_FOUND
  require a.status = 'submitted' else NOT_SUBMITTED 'This application is not awaiting review.'
  require not approve or barricades != null else BAD_REVIEW 'Approving requires a barricade count.'
  require not approve or a.partyDate > now + 7d else TOO_SOON 'The party is too soon to approve.'
  update applications[application] { status: 'approved' if approve else 'rejected', barricades: barricades ?? a.barricades, deliveryAt: deliveryAt ?? a.deliveryAt, pickupAt: pickupAt ?? a.pickupAt, insuranceDeadline: a.partyDate - 7d if approve else a.insuranceDeadline, note: note ?? a.note }
  return null

mutation confirmInsurance(application: applications):
  a = applications[application] ! else NOT_FOUND
  require a.organizer = viewer else NOT_ORGANIZER 'Only the organizer confirms insurance.'
  require a.status = 'approved' else NOT_APPROVED 'Only approved parties confirm insurance.'
  require a.insuranceDeadline = null or now <= a.insuranceDeadline else INSURANCE_LATE 'The insurance deadline has passed.'
  update applications[application] { insuranceConfirmed: true }
  return null

mutation grantCity(who: principal):
  require exists roles[viewer] or viewer = 'service:ops' else NOT_STAFF 'Only city staff can add staff.'
  return upsert roles[principal = who] { principal: who, role: 'city' }

mutation withdraw(application: applications):
  a = applications[application] ! else NOT_FOUND
  require a.organizer = viewer else NOT_ORGANIZER 'Only the organizer withdraws this application.'
  require a.status = 'draft' or a.status = 'submitted' else NOT_WITHDRAWABLE 'Only open applications can be withdrawn.'
  delete applications[application]
  return null
