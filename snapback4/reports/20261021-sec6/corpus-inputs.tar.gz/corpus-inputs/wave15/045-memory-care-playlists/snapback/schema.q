use personas alice, carol, bob, dana

-- The facility provisions residents and staff; clients cannot grant themselves roles.
table staff:
  principal: principal
  role: enum('aide', 'director')
  unique principal
  immutable principal, role
  read <- .principal = viewer
  online only

table residents:
  name: text 1..80
  family: principal
  about: text 1..500
  lastSessionAt: time ?
  immutable family
  read <- .family = viewer or exists staff[viewer]
  update <- exists staff[viewer]
  cap 100
  online only

table playlist:
  resident: residents
  kind: enum('song', 'photo')
  title: text 1..120
  url: text 1..1000 format url
  memory: text 1..1000
  author: principal
  at: time default now
  immutable resident, author, at
  read through .resident
  insert <- .author = viewer and .resident.family = viewer
  cap 100 by resident
  online only

table sessions:
  resident: residents
  aide: principal
  response: enum('engaged', 'calm', 'neutral', 'distressed')
  notes: text 1..1000
  minutes: int 1..120
  at: time default now
  immutable resident, aide, at
  read through .resident
  insert <- .aide = viewer and exists staff[viewer]
  online only

table assignments:
  resident: residents
  week: int
  volunteer: text 1..80
  assignedBy: principal
  unique resident, week
  immutable resident, week
  read through .resident
  insert <- exists staff[principal = viewer, role = 'director'] and .assignedBy = viewer
  update <- exists staff[principal = viewer, role = 'director'] and .assignedBy = viewer
  online only

query myRole():
  return staff[viewer]

query myResidents():
  if exists staff[viewer]:
    return residents first 100 by .name
  return residents where .family = viewer first 100 by .name

query residentPlaylist(resident: residents):
  require exists residents[resident] else RESIDENT_PRIVATE 'This resident is not available to you.'
  return playlist where .resident = resident first 100 by .at

query residentSessions(resident: residents):
  require exists residents[resident] else RESIDENT_PRIVATE 'This resident is not available to you.'
  return sessions where .resident = resident last 100 by .at

query weeklyGaps():
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  week = day(now) - (day(now) + 3) % 7
  return residents where .lastSessionAt = null or .lastSessionAt < week * 1d first 100 by .name { id, name, lastSessionAt, assignment: assignments[.id, week] }

mutation addMemory(resident: residents, kind: enum('song', 'photo'), title: text 1..120, url: text 1..1000 format url, memory: text 1..1000):
  r = residents[resident] ! else RESIDENT_PRIVATE
  require r.family = viewer else FAMILY_ONLY
  return insert playlist { resident, kind, title, url, memory, author: viewer }

mutation recordSession(resident: residents, response: enum('engaged', 'calm', 'neutral', 'distressed'), notes: text 1..1000, minutes: int 1..120):
  require exists staff[viewer] else STAFF_ONLY
  require exists residents[resident] else RESIDENT_PRIVATE
  s = insert sessions { resident, aide: viewer, response, notes, minutes }
  update residents[resident] { lastSessionAt: now }
  return s

mutation assignVolunteer(resident: residents, volunteer: text 1..80):
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  require exists residents[resident] else RESIDENT_PRIVATE
  week = day(now) - (day(now) + 3) % 7
  return upsert assignments[resident, week] { resident, week, volunteer, assignedBy: viewer }
