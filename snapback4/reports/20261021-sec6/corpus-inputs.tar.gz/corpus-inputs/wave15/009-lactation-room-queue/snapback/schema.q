-- Lactation Room Queue.
--
-- Two private rooms. Employees reserve 30-minute slots (aligned to the
-- half hour) or join a live walk-up queue per room. Employees see only
-- their own bookings plus anonymous per-room status; facilities see
-- anonymous usage counts; HR can block a room for cleaning without
-- seeing who booked it. No-show slots are released by a sweeper job.
--
-- Personas are development principals (dev:alice, ...). Role checks
-- compare viewer against the dev principal directly; a production
-- deployment would use a staff roster table + password identity instead.

use personas alice, bob, facilities, hr

table rooms:
  name: text 1..40
  blocked: bool default false
  blockedReason: text <=200 ?
  public 'Room list and blocked status are public.'
  insert <- deny
  update <- viewer = 'dev:hr'
  delete <- deny
  online only

table bookings:
  room: rooms
  holder: principal
  startsAt: time
  endsAt: time
  slot: int
  status: enum('active', 'checked-in', 'released') default 'active'
  immutable room, holder, startsAt, endsAt, slot
  unique room, slot else ALREADY_BOOKED 'That slot is already taken.'
  cap 200 by room
  read <- .holder = viewer
  insert <- .holder = viewer
  update (old, next) <- old.holder = viewer and next.holder = viewer and old.status = 'active' and next.status = 'checked-in'
  delete <- .holder = viewer
  online only

table queueEntries:
  room: rooms
  holder: principal
  joinedAt: time default now
  immutable room, holder, joinedAt
  unique room, holder else ALREADY_QUEUED 'You are already in this queue.'
  cap 20 by room
  read <- .holder = viewer
  insert <- .holder = viewer
  delete <- .holder = viewer
  online only

-- Anonymous aggregates over private rows. These are the only cross-user
-- facts employees and facilities may see; no holder is exposed.
view upcoming: count bookings where .status = 'active' by .room
  read <- allow
  online only

view inUse: count bookings where .status = 'checked-in' by .room
  read <- allow
  online only

view waiting: count queueEntries by .room
  read <- allow
  online only

view totalUses: count bookings by .room
  read <- allow
  online only

query rooms():
  return rooms first 10 by .id

query roomStatus():
  return rooms first 10 by .id { id, name, blocked, blockedReason, upcoming: upcoming[.id], inUse: inUse[.id], waiting: waiting[.id] }

query myBookings():
  return bookings where .holder = viewer last 50 by .startsAt { id, startsAt, endsAt, status, room: rooms[.room] }

query myQueue():
  return queueEntries where .holder = viewer first 20 by .joinedAt { id, joinedAt, room: rooms[.room] }

query usageStats():
  require viewer = 'dev:facilities' else NOT_FACILITIES 'Usage stats are for the facilities team.'
  return rooms first 10 by .id { id, name, total: totalUses[.id], upcoming: upcoming[.id], inUse: inUse[.id], waiting: waiting[.id] }

mutation book(room: rooms, startsAt: time):
  r = rooms[room] ! else NOT_FOUND
  require not r.blocked else ROOM_BLOCKED 'This room is blocked.'
  require startsAt > now else IN_THE_PAST 'Pick a future time.'
  require startsAt < now + 14d else TOO_FAR 'Bookings open 14 days ahead.'
  s = bucket(startsAt, 30m)
  require startsAt = s * 30m else NOT_ALIGNED 'Slots start on the hour or half hour.'
  return insert bookings { room, holder: viewer, startsAt, endsAt: startsAt + 30m, slot: s, status: 'active' }

mutation cancelBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.status = 'active' else BAD_STATE 'Only upcoming bookings can be cancelled.'
  delete bookings[booking]

mutation checkIn(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.status = 'active' else BAD_STATE 'Already checked in or released.'
  require now >= b.startsAt - 5m else TOO_EARLY 'Check-in opens 5 minutes before the slot.'
  require now <= b.startsAt + 5m else TOO_LATE 'This slot was released as a no-show.'
  update bookings[booking] { status: 'checked-in' }

mutation joinQueue(room: rooms):
  r = rooms[room] ! else NOT_FOUND
  require not r.blocked else ROOM_BLOCKED 'This room is blocked.'
  return insert queueEntries { room, holder: viewer }

mutation leaveQueue(entry: queueEntries):
  e = queueEntries[entry] ! else NOT_FOUND
  delete queueEntries[entry]

mutation blockRoom(room: rooms, blocked: bool, reason: text <=200 ?):
  require viewer = 'dev:hr' else NOT_HR 'Only HR can block rooms.'
  r = rooms[room] ! else NOT_FOUND
  update rooms[room] { blocked, blockedReason: reason }
  return null

-- Release slots whose holder never checked in: a few minutes grace after
-- the start, then the slot frees for others. Sweeps back 7 days so one
-- run catches up after missed schedule boundaries.
job releaseNoShows(periodStart: time, periodEnd: time):
  for b in bookings where .startsAt >= periodEnd - 7d and .startsAt < periodEnd - 5m by .id:
    if b.status = 'active':
      update bookings[b.id] { status: 'released' }

schedule releaser every 5m: releaseNoShows
