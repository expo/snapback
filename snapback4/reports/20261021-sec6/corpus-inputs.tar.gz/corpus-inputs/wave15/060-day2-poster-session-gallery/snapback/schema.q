-- Poster Session Gallery.
-- Cast: alice (presenter), bob + carol (judges), dave (organizer).
-- Lifecycle is driven by two organizer-controlled flags on conferences:
-- sessionOpen (posters become public) and awardsReleased (scores/comments
-- become visible to presenters, awards become public). Clocks stay out of
-- read rules; the judging cutoff is enforced as a mutation `require`.
-- Production uses real accounts (password + guests, so the public gallery
-- keeps working for visitors); personas stay for dev/tests only.
use identity
use personas alice, bob, carol, dave

table organizers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- exists organizers[viewer] or viewer = 'service:ops'
  delete <- exists organizers[viewer]
  online only

table conferences:
  title: text 1..120
  sessionOpen: bool default false
  awardsReleased: bool default false
  venue: text 1..120 default 'Main Hall'
  immutable title
  public 'conference identity and phase flags are public'
  insert <- exists organizers[viewer]
  update <- exists organizers[viewer]
  cap 1
  online only

table posters:
  conference: conferences
  presenter: principal
  title: text 1..120
  abstract: text 1..2000
  imageUrl: text 1..500 ?
  immutable conference, presenter
  read <- .presenter = viewer or exists organizers[viewer] or exists assignments[.id, viewer] or exists conferences[.conference, sessionOpen = true]
  insert <- .presenter = viewer
  update <- .presenter = viewer
  delete <- .presenter = viewer
  cap 5 by presenter
  online only

table assignments:
  poster: posters
  judge: principal
  unique poster, judge
  immutable poster, judge
  read <- .judge = viewer or exists organizers[viewer]
  insert <- exists organizers[viewer]
  delete <- exists organizers[viewer]
  online only

table scores:
  poster: posters
  conference: conferences
  judge: principal
  originality: int 1..10
  clarity: int 1..10
  impact: int 1..10
  comment: text <=1000 ?
  unique poster, judge
  immutable poster, conference, judge
  read <- .judge = viewer or exists organizers[viewer] or (exists posters[.poster, presenter = viewer] and exists conferences[id = .conference, awardsReleased = true])
  insert <- .judge = viewer and exists assignments[.poster, viewer] and exists posters[.poster, conference = .conference]
  update <- .judge = viewer and exists assignments[.poster, viewer]
  delete <- .judge = viewer
  online only

table awards:
  poster: posters
  conference: conferences
  place: enum('best-in-show', 'judges-pick', 'audience-choice')
  note: text <=500 ?
  unique poster
  immutable poster, conference
  read <- exists organizers[viewer] or exists conferences[id = .conference, awardsReleased = true]
  insert <- exists organizers[viewer] and exists posters[.poster, conference = .conference]
  delete <- exists organizers[viewer]
  online only

query conferenceState(conf: conferences):
  return conferences[conf]

query conferences(c: cursor ?):
  return conferences last 10 by .id after c

query gallery(conf: conferences, c: cursor ?):
  return posters where .conference = conf last 50 by .id after c

query myPosters(c: cursor ?):
  return posters where .presenter = viewer last 50 by .id after c

query posterDetail(poster: posters):
  return posters[poster]

query myAssignments(c: cursor ?):
  return assignments where .judge = viewer first 50 by .id after c

query posterAssignments(poster: posters, c: cursor ?):
  return assignments where .poster = poster first 50 by .id after c

query scoresForPoster(poster: posters, c: cursor ?):
  return scores where .poster = poster first 50 by .id after c

query awardsList(c: cursor ?):
  return awards last 50 by .id after c

-- Audience Q&A. Anyone signed in (judges, guests, presenters) may ask once
-- the session opens; the presenting author or an organizer answers.
table questions:
  poster: posters
  conference: conferences
  author: principal
  body: text 1..500
  answer: text <=500 ?
  immutable poster, conference, author
  read <- .author = viewer or exists posters[.poster, presenter = viewer] or exists organizers[viewer] or exists conferences[.conference, sessionOpen = true]
  insert <- .author = viewer
  update <- .author = viewer or exists posters[.poster, presenter = viewer] or exists organizers[viewer]
  delete <- .author = viewer or exists organizers[viewer]
  online only

query questionsForPoster(poster: posters, c: cursor ?):
  return questions where .poster = poster first 50 by .id after c

mutation uploadPoster(conf: conferences, title: text 1..120, abstract: text 1..2000, imageUrl: text 1..500 ?):
  c = conferences[conf] ! else NOT_FOUND
  require not c.sessionOpen else SESSION_OPEN 'Uploads closed once the session opens.'
  return insert posters { conference: conf, presenter: viewer, title, abstract, imageUrl }

mutation editPoster(poster: posters, title: text 1..120, abstract: text 1..2000, imageUrl: text 1..500 ?):
  p = posters[poster] ! else NOT_FOUND
  require p.presenter = viewer else NOT_PRESENTER
  update posters[poster] { title, abstract, imageUrl: imageUrl ?? p.imageUrl }
  return null

mutation removePoster(poster: posters):
  p = posters[poster] ! else NOT_FOUND
  require p.presenter = viewer else NOT_PRESENTER
  delete posters[poster]
  return null

mutation assignJudge(poster: posters, judge: principal):
  require exists organizers[viewer] else NOT_ORGANIZER
  p = posters[poster] ! else NOT_FOUND
  return insert assignments { poster: p.id, judge }

mutation unassignJudge(poster: posters, judge: principal):
  require exists organizers[viewer] else NOT_ORGANIZER
  delete assignments[poster, judge]
  return null

mutation submitScore(poster: posters, originality: int 1..10, clarity: int 1..10, impact: int 1..10, comment: text <=1000 ?):
  p = posters[poster] ! else NOT_FOUND
  require exists assignments[poster, viewer] else NOT_ASSIGNED
  require not exists conferences[p.conference, awardsReleased = true] else AWARDS_RELEASED 'Judging is closed.'
  upsert scores[poster, viewer] { poster: p.id, conference: p.conference, judge: viewer, originality, clarity, impact, comment }
  return null

mutation openSession(conf: conferences):
  require exists organizers[viewer] else NOT_ORGANIZER
  c = conferences[conf] ! else NOT_FOUND
  update conferences[conf] { sessionOpen: true }
  return null

mutation releaseAwards(conf: conferences):
  require exists organizers[viewer] else NOT_ORGANIZER
  c = conferences[conf] ! else NOT_FOUND
  require c.sessionOpen else SESSION_CLOSED 'Open the session before releasing awards.'
  update conferences[conf] { awardsReleased: true }
  return null

mutation grantAward(poster: posters, place: enum('best-in-show', 'judges-pick', 'audience-choice'), note: text <=500 ?):
  require exists organizers[viewer] else NOT_ORGANIZER
  p = posters[poster] ! else NOT_FOUND
  return insert awards { poster: p.id, conference: p.conference, place, note }

mutation setVenue(conf: conferences, venue: text 1..120):
  require exists organizers[viewer] else NOT_ORGANIZER
  c = conferences[conf] ! else NOT_FOUND
  update conferences[conf] { venue }
  return null

mutation askQuestion(poster: posters, body: text 1..500):
  p = posters[poster] ! else NOT_FOUND
  require exists conferences[p.conference, sessionOpen = true] else SESSION_CLOSED 'Questions open with the session.'
  return insert questions { poster: p.id, conference: p.conference, author: viewer, body }

mutation answerQuestion(question: questions, answer: text <=500):
  q = questions[question] ! else NOT_FOUND
  require exists posters[q.poster, presenter = viewer] or exists organizers[viewer] else NOT_PRESENTER
  update questions[question] { answer }
  return null

mutation editQuestion(question: questions, body: text 1..500):
  q = questions[question] ! else NOT_FOUND
  require q.author = viewer else NOT_AUTHOR
  update questions[question] { body }
  return null

mutation addOrganizer(who: principal):
  require exists organizers[viewer] else NOT_ORGANIZER
  return insert organizers { principal: who }

-- First-organizer bootstrap: the operator seat provisions the roster, since
-- signup grants no role and addOrganizer needs an existing organizer.
mutation provisionOrganizer(who: principal):
  require viewer = 'service:ops' else NOT_ORGANIZER
  return insert organizers { principal: who }

-- Conferences have no seed door in production; an organizer creates the one
-- conference row (cap 1) through this mutation.
mutation createConference(title: text 1..120):
  require exists organizers[viewer] else NOT_ORGANIZER
  return insert conferences { title }
