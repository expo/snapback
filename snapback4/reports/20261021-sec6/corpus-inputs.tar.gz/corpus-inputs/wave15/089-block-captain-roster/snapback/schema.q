use personas alice, bob, carol, dana, eve

-- Assignment rows are provisioned by the neighborhood program, not by residents.
table blocks:
  name: text 1..80
  eventLabel: text 1..100
  public 'Block names and current preparedness event are neighborhood information.'
  online only

table captains:
  block: blocks
  principal: principal
  role: enum('captain', 'replacement')
  unique block, principal
  immutable block, principal, role
  read <- .principal = viewer
  online only

table coordinators:
  principal: principal
  unique principal
  immutable principal
  read <- .principal = viewer
  online only

-- Optional values contain only what a household chooses to share.
-- Opting out withdraws the whole row from the captain's roster.
table households:
  block: blocks
  owner: principal
  householdName: text 1..80
  address: text 1..140
  contact: text <=120 ?
  support: text <=400 ?
  optedIn: bool
  state: enum('unchecked', 'checked', 'help', 'unreachable') default 'unchecked'
  unique owner
  immutable owner, block
  cap 200 by block
  read <- .owner = viewer or (.optedIn = true and exists captains[.block, viewer])
  insert <- .owner = viewer
  update <- .owner = viewer or (.optedIn = true and exists captains[.block, viewer])
  online only

-- The view grants access to totals without granting access to source rows.
view statusCounts: count households where .optedIn = true by .block, .state
  read <- exists coordinators[viewer] or exists captains[.block, viewer]

query context():
  return { principal: viewer, assignments: captains where .principal = viewer first 20 by .id, coordinator: exists coordinators[viewer] }

query neighborhood():
  return blocks first 30 by .id

query myHousehold():
  return households[owner = viewer]

query roster(block: blocks):
  require exists captains[block, viewer] else CAPTAIN_ONLY 'Only the assigned captain and replacement may view this roster.'
  return households where .block = block and .optedIn = true first 200 by .id

query blockStatus(block: blocks):
  require exists coordinators[viewer] or exists captains[block, viewer] else STATUS_PRIVATE
  return { unchecked: statusCounts[block, 'unchecked'], checked: statusCounts[block, 'checked'], help: statusCounts[block, 'help'], unreachable: statusCounts[block, 'unreachable'] }

mutation shareHousehold(block: blocks, householdName: text 1..80, address: text 1..140, contact: text <=120 ?, support: text <=400 ?, optedIn: bool):
  b = blocks[block] ! else BLOCK_NOT_FOUND
  if exists households[owner = viewer]:
    h = households[owner = viewer] ! else NOT_FOUND
    require h.block = block else BLOCK_FIXED 'Contact the program to move your household to another block.'
    update households[h.id] { householdName, address, contact, support, optedIn }
    return households[h.id]
  return insert households { block, owner: viewer, householdName, address, contact, support, optedIn }

mutation checkHousehold(household: households, state: enum('unchecked', 'checked', 'help', 'unreachable')):
  h = households[household] ! else NOT_FOUND
  require exists captains[h.block, viewer] else CAPTAIN_ONLY
  require h.optedIn else NOT_SHARED
  update households[household] { state }
  return households[household]
