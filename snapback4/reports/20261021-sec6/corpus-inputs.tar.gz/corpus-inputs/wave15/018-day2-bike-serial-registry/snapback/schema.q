use personas alice, bob, officer, visitor
use identity

-- Program membership is provisioned administratively, never by a client operation.
table officers:
  principal: principal
  badge: text 2..30
  unique principal
  immutable principal, badge
  read <- .principal = viewer or viewer = 'service:registry'
  insert <- viewer = 'service:registry'
  online only

table bikes:
  owner: principal
  serial: text 3..40
  marks: text 3..600
  neighborhood: enum('Mitte', 'Kreuzberg', 'Neukolln', 'Pankow', 'Friedrichshain')
  photos: [text 1..500 format url] <=4
  caseReference: text 3..80 default 'Not filed'
  stolen: bool default false
  registeredAt: time default now
  unique serial else SERIAL_REGISTERED 'This serial is already registered.'
  immutable owner, serial, registeredAt
  read <- .owner = viewer or (.stolen = true and exists officers[viewer])
  insert <- .owner = viewer and .stolen = false
  update <- .owner = viewer
  cap 20 by owner
  online only

table contacts:
  bike: bikes
  owner: principal
  name: text 2..80
  email: text 3..120 format email
  phone: text 5..40
  unique bike
  immutable bike, owner
  read <- .owner = viewer or (exists officers[viewer] and exists bikes[.bike, stolen = true])
  insert <- .owner = viewer and exists bikes[.bike, owner = viewer]
  online only

table contactViews:
  bike: bikes
  owner: principal
  officer: principal
  at: time default now
  immutable bike, owner, officer, at
  read <- .owner = viewer or .officer = viewer
  insert <- .officer = viewer and exists officers[viewer] and exists bikes[.bike, stolen = true, owner = .owner]
  online only

-- Private immutable case history. Public lookup never exposes report references.
table caseUpdates:
  bike: bikes
  owner: principal
  reference: text 3..80
  note: text 3..600
  at: time default now
  immutable bike, owner, reference, note, at
  read <- .owner = viewer
  insert <- .owner = viewer and exists bikes[.bike, owner = viewer, stolen = true]
  online only

-- These are intentional anonymous disclosure channels over otherwise private rows.
view registeredSerials: count bikes by .serial
  public 'Only registration existence for an exact serial.'
  online only
view stolenSerials: count bikes where .stolen = true by .serial
  public 'Only the stolen flag for an exact serial.'
  online only
view theftCounts: count bikes where .stolen = true by .neighborhood
  public 'Anonymous counts of currently stolen bikes by neighborhood.'
  online only

query myRole():
  return { officer: exists officers[viewer] }
query myBikes(c: cursor ?):
  return bikes where .owner = viewer last 20 by .registeredAt after c
query serialStatus(serial: text 3..40):
  return { serial, registered: registeredSerials[serial] > 0, stolen: stolenSerials[serial] > 0 }
query neighborhoodStats():
  return [{ neighborhood: 'Mitte', stolen: theftCounts['Mitte'] }, { neighborhood: 'Kreuzberg', stolen: theftCounts['Kreuzberg'] }, { neighborhood: 'Neukolln', stolen: theftCounts['Neukolln'] }, { neighborhood: 'Pankow', stolen: theftCounts['Pankow'] }, { neighborhood: 'Friedrichshain', stolen: theftCounts['Friedrichshain'] }]
query stolenBikes(c: cursor ?):
  require exists officers[viewer] else OFFICER_ONLY 'Program officers only.'
  return bikes where .stolen = true last 50 by .registeredAt after c { id, serial, marks, neighborhood, photos }
query auditLog(c: cursor ?):
  if exists officers[viewer]:
    return contactViews where .officer = viewer last 50 by .at after c
  return contactViews where .owner = viewer last 50 by .at after c

mutation registerBike(serial: text 3..40, marks: text 3..600, neighborhood: enum('Mitte', 'Kreuzberg', 'Neukolln', 'Pankow', 'Friedrichshain'), photos: [text 1..500 format url] <=4, name: text 2..80, email: text 3..120 format email, phone: text 5..40):
  b = insert bikes { owner: viewer, serial, marks, neighborhood, photos }
  insert contacts { bike: b.id, owner: viewer, name, email, phone }
  return b
mutation reportStolen(bike: bikes):
  b = bikes[bike] ! else NOT_FOUND
  require b.owner = viewer else OWNER_ONLY 'Only the owner can report theft.'
  require not b.stolen else ALREADY_STOLEN
  update bikes[bike] { stolen: true }
mutation markRecovered(bike: bikes):
  b = bikes[bike] ! else NOT_FOUND
  require b.owner = viewer else OWNER_ONLY 'Only the owner can mark recovery.'
  require b.stolen else NOT_STOLEN
  update bikes[bike] { stolen: false }
-- This is the only operation returning contacts. Its audit and read commit atomically.
mutation viewOwnerContact(bike: bikes):
  require exists officers[viewer] else OFFICER_ONLY 'Program officers only.'
  b = bikes[bike] ! else NOT_FOUND
  require b.stolen else NOT_STOLEN
  c = contacts[bike = bike] ! else NOT_FOUND
  insert contactViews { bike, owner: b.owner, officer: viewer }
  return { serial: b.serial, name: c.name, email: c.email, phone: c.phone }

query caseHistory(bike: bikes, c: cursor ?):
  b = bikes[bike] ! else NOT_FOUND
  require b.owner = viewer else OWNER_ONLY 'Only the owner can read case updates.'
  return caseUpdates where .bike = bike and .owner = viewer last 50 by .at after c

mutation updateCase(bike: bikes, reference: text 3..80, note: text 3..600):
  b = bikes[bike] ! else NOT_FOUND
  require b.owner = viewer else OWNER_ONLY 'Only the owner can update a case.'
  require b.stolen else NOT_STOLEN 'Report the bike stolen before adding case updates.'
  require reference != 'Not filed' else CASE_REFERENCE_REQUIRED 'Enter the police case reference.'
  update bikes[bike] { caseReference: reference }
  return insert caseUpdates { bike, owner: viewer, reference, note }

-- Only a locally minted operator credential may enroll program officers.
mutation enrollOfficer(principal: principal, badge: text 2..30):
  require viewer = 'service:registry' else OPERATOR_ONLY 'Registry operator only.'
  return insert officers { principal, badge }
