use personas alice, bob, carol, dana, visitor
use identity guests

table releases:
  title: text 5..160
  body: text 20..20000
  embargoAt: time
  stage: enum('draft', 'legal', 'finance', 'executive', 'scheduled') default 'draft'
  revision: int 1.. default 1
  createdAt: time default now
  immutable createdAt
  read <- viewer = 'dev:alice' or viewer = 'dev:bob' and .stage = 'legal' or viewer = 'dev:carol' and .stage = 'finance' or viewer = 'dev:dana' and .stage = 'executive'
  insert <- viewer = 'dev:alice' and .stage = 'draft'
  update (old, next) <- viewer = 'dev:alice' and old.stage = 'draft' and (next.stage = 'draft' or next.stage = 'legal') or viewer = 'dev:bob' and old.stage = 'legal' and (next.stage = 'finance' or next.stage = 'draft') or viewer = 'dev:carol' and old.stage = 'finance' and (next.stage = 'executive' or next.stage = 'draft') or viewer = 'dev:dana' and old.stage = 'executive' and (next.stage = 'scheduled' or next.stage = 'draft')
  online only

table history:
  release: releases
  actor: principal
  action: enum('created', 'edited', 'submitted', 'approved', 'returned')
  stage: text 1..20
  comment: text <=2000
  title: text 5..160
  body: text 20..20000
  embargoAt: time
  revision: int 1..
  at: time default now
  immutable release, actor, action, stage, comment, title, body, embargoAt, revision, at
  read <- viewer = 'dev:alice'
  insert <- .actor = viewer
  online only

table newsroom:
  release: releases
  title: text 5..160
  body: text 20..20000
  embargoAt: time
  revision: int 1..
  unique release
  immutable release, title, body, embargoAt, revision
  public 'Final approved press releases, available at their embargo time.'
  not before .embargoAt
  insert <- viewer = 'dev:dana' and exists releases[.release, stage = 'executive']
  online only

query inbox():
  return releases last 100 by .createdAt
query releaseDetail(release: releases):
  return releases[release]
query changes(release: releases):
  require viewer = 'dev:alice' else LEAD_ONLY
  return history where .release = release first 200 by .at
query publicNews():
  return newsroom last 100 by .embargoAt

mutation createRelease(title: text 5..160, body: text 20..20000, embargoAt: time):
  require viewer = 'dev:alice' else LEAD_ONLY
  require embargoAt > now and embargoAt <= now + 365d else INVALID_EMBARGO 'Choose a future embargo within one year.'
  r = insert releases { title, body, embargoAt }
  insert history { release: r.id, actor: viewer, action: 'created', stage: 'draft', comment: '', title, body, embargoAt, revision: 1 }
  return r

mutation editRelease(release: releases, title: text 5..160, body: text 20..20000, embargoAt: time):
  require viewer = 'dev:alice' else LEAD_ONLY
  r = releases[release] ! else NOT_FOUND
  require r.stage = 'draft' else REVIEW_IN_PROGRESS 'Only a draft can be edited.'
  require embargoAt > now and embargoAt <= now + 365d else INVALID_EMBARGO
  insert history { release, actor: viewer, action: 'edited', stage: 'draft', comment: '', title, body, embargoAt, revision: r.revision + 1 }
  update releases[release] { title, body, embargoAt, revision: r.revision + 1 }

mutation submitRelease(release: releases):
  require viewer = 'dev:alice' else LEAD_ONLY
  r = releases[release] ! else NOT_FOUND
  require r.stage = 'draft' else REVIEW_IN_PROGRESS
  require r.embargoAt > now else INVALID_EMBARGO 'Reschedule the embargo before submitting.'
  insert history { release, actor: viewer, action: 'submitted', stage: 'legal', comment: '', title: r.title, body: r.body, embargoAt: r.embargoAt, revision: r.revision }
  update releases[release] { stage: 'legal' }

mutation approve(release: releases, revision: int 1.., comment: text <=2000):
  r = releases[release] ! else NOT_FOUND
  require r.revision = revision else STALE_REVISION 'The draft changed. Read the latest revision.'
  require viewer = 'dev:bob' and r.stage = 'legal' or viewer = 'dev:carol' and r.stage = 'finance' or viewer = 'dev:dana' and r.stage = 'executive' else NOT_YOUR_TURN
  insert history { release, actor: viewer, action: 'approved', stage: r.stage, comment, title: r.title, body: r.body, embargoAt: r.embargoAt, revision: r.revision }
  if r.stage = 'executive':
    insert newsroom { release, title: r.title, body: r.body, embargoAt: r.embargoAt, revision: r.revision }
    update releases[release] { stage: 'scheduled' }
  else if r.stage = 'legal':
    update releases[release] { stage: 'finance' }
  else:
    update releases[release] { stage: 'executive' }

mutation sendBack(release: releases, revision: int 1.., comment: text 1..2000):
  r = releases[release] ! else NOT_FOUND
  require r.revision = revision else STALE_REVISION 'The draft changed. Read the latest revision.'
  require viewer = 'dev:bob' and r.stage = 'legal' or viewer = 'dev:carol' and r.stage = 'finance' or viewer = 'dev:dana' and r.stage = 'executive' else NOT_YOUR_TURN
  insert history { release, actor: viewer, action: 'returned', stage: r.stage, comment, title: r.title, body: r.body, embargoAt: r.embargoAt, revision: r.revision }
  update releases[release] { stage: 'draft' }
