-- Propane Tank Readings: customers report gauge levels, a daily job
-- estimates run-out dates, dispatchers build routes, drivers confirm fills.
use identity
use personas alice, bob, dispatch, driver

table staff:
  principal: principal
  role: enum('dispatcher', 'driver')
  unique principal
  public 'roster is discoverable so rules can probe it'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

table tanks:
  owner: principal
  address: text 1..120
  capacity: int 50..2000
  level: int 0..100 default 100
  reservePercent: int 5..50 default 20
  runout: time ?
  updatedAt: time default now
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer or exists staff[principal = viewer, role = 'dispatcher']
  update <- .owner = viewer or exists staff[viewer]
  delete <- exists staff[principal = viewer, role = 'dispatcher']
  online only

table readings:
  tank: tanks on delete cascade
  level: int 0..100
  photo: image <=10000000 ?
  at: time default now
  cap 500 by tank
  read <- exists tanks[.tank, owner = viewer] or exists staff[viewer]
  insert <- exists tanks[.tank, owner = viewer]
  update <- deny
  delete <- deny
  online only

table routes:
  driver: principal
  day: int 0..99999999
  name: text 1..80
  read <- .driver = viewer or exists staff[principal = viewer, role = 'dispatcher']
  insert <- exists staff[principal = viewer, role = 'dispatcher']
  update <- exists staff[principal = viewer, role = 'dispatcher']
  delete <- exists staff[principal = viewer, role = 'dispatcher']
  online only

table stops:
  route: routes on delete cascade
  tank: tanks on delete cascade
  address: text 1..120
  done: bool default false
  deliveredAt: time ?
  cap 100 by route
  cap 500 by tank
  read <- exists routes[.route, driver = viewer] or exists staff[principal = viewer, role = 'dispatcher'] or exists tanks[.tank, owner = viewer]
  insert <- exists staff[principal = viewer, role = 'dispatcher']
  update <- exists routes[.route, driver = viewer] or exists staff[principal = viewer, role = 'dispatcher']
  delete <- exists staff[principal = viewer, role = 'dispatcher']
  online only

job estimate(periodStart: time, periodEnd: time):
  for t in tanks:
    if t.runout = null:
      update tanks[t.id] { runout: now + t.level * 1d, updatedAt: now }

schedule estimateDaily every 1d at 03:00: estimate

query myTanks():
  return tanks where .owner = viewer last 50 by .id

query tankReadings(tank: tanks):
  return readings where .tank = tank last 50 by .at

query allTanks():
  if exists staff[principal = viewer, role = 'dispatcher']:
    return tanks last 50 by .id
  return tanks where .owner = viewer last 50 by .id

query myRoute(day: int 0..99999999):
  return routes where .driver = viewer and .day = day last 20 by .id

query allRoutes(day: int 0..99999999):
  if exists staff[principal = viewer, role = 'dispatcher']:
    return routes where .day = day last 50 by .id
  return routes where .driver = viewer and .day = day last 50 by .id

query routeStops(route: routes):
  return stops where .route = route last 100 by .id

query deliveries(tank: tanks):
  return stops where .tank = tank last 50 by .id

mutation reportLevel(tank: tanks, level: int 0..100):
  t = tanks[tank] ! else NOT_FOUND
  require t.owner = viewer else NOT_OWNER
  insert readings { tank, level }
  update tanks[tank] { level, updatedAt: now }
  return tanks[tank]

mutation registerTank(owner: principal, address: text 1..120, capacity: int 50..2000):
  require exists staff[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
  return insert tanks { owner, address, capacity }

mutation createRoute(driver: principal, day: int 0..99999999, name: text 1..80):
  require exists staff[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
  return insert routes { driver, day, name }

mutation addStop(route: routes, tank: tanks):
  require exists staff[principal = viewer, role = 'dispatcher'] else NOT_DISPATCHER
  r = routes[route] ! else NOT_FOUND
  t = tanks[tank] ! else NOT_FOUND
  return insert stops { route, tank, address: t.address }

mutation confirmFill(stop: stops):
  s = stops[stop] ! else NOT_FOUND
  r = routes[s.route]
  require r != null else NOT_FOUND
  require r.driver = viewer or exists staff[principal = viewer, role = 'dispatcher'] else NOT_ALLOWED
  update stops[stop] { done: true, deliveredAt: now }
  update tanks[s.tank] { level: 100, updatedAt: now }
  return stops[stop]

-- Operator-controlled enrollment; signing up never confers a staff role.
mutation enrollStaff(principal: principal, role: enum('dispatcher', 'driver')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal, role }

query myRole():
  if exists staff[principal = viewer, role = 'dispatcher']:
    return 'dispatcher'
  if exists staff[principal = viewer, role = 'driver']:
    return 'driver'
  return 'customer'

mutation registerMyTank(address: text 1..120, capacity: int 50..2000):
  return insert tanks { owner: viewer, address, capacity }

-- A request records a customer decision, separately from an estimated date.
table fillRequests:
  tank: tanks on delete cascade
  owner: principal
  note: text 1..240
  at: time default now
  cap 100 by tank
  read <- .owner = viewer or exists staff[principal = viewer, role = 'dispatcher']
  insert <- .owner = viewer and exists tanks[.tank, owner = viewer]
  update <- deny
  delete <- deny
  online only

query refillRequests(tank: tanks):
  return fillRequests where .tank = tank last 100 by .at

mutation requestRefill(tank: tanks, note: text 1..240):
  t = tanks[tank] ! else NOT_FOUND
  require t.owner = viewer else NOT_OWNER
  require t.level <= t.reservePercent else ABOVE_RESERVE
  return insert fillRequests { tank, owner: viewer, note }

mutation setReserve(tank: tanks, percent: int 5..50):
  t = tanks[tank] ! else NOT_FOUND
  require t.owner = viewer else NOT_OWNER
  update tanks[tank] { reservePercent: percent }
  return tanks[tank]
