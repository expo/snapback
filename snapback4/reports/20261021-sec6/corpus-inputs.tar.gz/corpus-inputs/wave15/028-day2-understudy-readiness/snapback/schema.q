use identity password
use personas alice, bob, manager, director, crew

-- Staff membership is provisioned by the company, never self-assigned.
-- In production the operator seat grants the first rows; managers may add more.
table staff:
  principal: principal
  position: enum('manager', 'director', 'crew', 'assistant')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or exists staff[viewer, position = 'manager']
  online only

-- Roles are company-provisioned: the stage manager (or operator seat) creates them.
table roles:
  title: text 1..80
  principalName: text 1..80
  understudy: principal
  immutable understudy
  read <- .understudy = viewer or exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']
  insert <- viewer = 'service:ops' or exists staff[viewer, position = 'manager']
  online only

-- Scenes are company-provisioned alongside their role; ownership follows the cover.
table scenes:
  role: roles
  owner: principal
  title: text 1..100
  sequence: int 1..99
  ready: bool default false
  managerNote: text <=500 default ''
  unique role, sequence
  immutable role, owner, title, sequence
  read <- .owner = viewer or exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']
  update <- exists staff[viewer, position = 'manager']
  insert <- viewer = 'service:ops' or exists staff[viewer, position = 'manager']
  online only

table rehearsals:
  scene: scenes
  owner: principal
  minutes: int 1..240
  intensity: int 1..5 default 3
  note: text 1..500
  at: time default now
  immutable scene, owner, minutes, intensity, note, at
  read <- .owner = viewer or exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']
  insert <- .owner = viewer and exists scenes[.scene, owner = viewer]
  online only

table alerts:
  role: roles
  understudy: principal
  performanceAt: time
  message: text 1..500
  at: time default now
  immutable role, understudy, performanceAt, message, at
  read <- .understudy = viewer or exists staff[viewer]
  insert <- exists staff[viewer, position = 'manager']
  online only

table performances:
  role: roles
  understudy: principal
  performanceAt: time
  note: text <=500
  unique role, performanceAt
  immutable role, understudy, performanceAt, note
  read <- .understudy = viewer or exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']
  insert <- exists staff[viewer, position = 'manager']
  online only

-- Costume fittings per cover: a callout must never discover an unfitted costume.
table fittings:
  role: roles
  understudy: principal
  fittedAt: time
  note: text <=500
  unique role, fittedAt
  immutable role, understudy, fittedAt, note
  read <- .understudy = viewer or exists staff[viewer]
  insert <- exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'assistant']
  online only

view sceneTotals: count scenes by .role
  read <- exists roles[.role]
view readyTotals: count scenes where .ready = true by .role
  read <- exists roles[.role]
view rehearsalTotals: count rehearsals by .scene
  read <- exists scenes[.scene]

query myPosition():
  return { principal: viewer, staff: staff[viewer] }

query tracks(c: cursor ?):
  if exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']:
    return roles first 50 by .id after c { id, title, principalName, understudy, total: sceneTotals[.id], ready: readyTotals[.id] }
  return roles where .understudy = viewer first 50 by .id after c { id, title, principalName, understudy, total: sceneTotals[.id], ready: readyTotals[.id] }

query sceneList(c: cursor ?):
  if exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']:
    return scenes first 100 by .id after c
  return scenes where .owner = viewer first 100 by .id after c

query rehearsalLog(c: cursor ?):
  if exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']:
    return rehearsals last 100 by .at after c
  return rehearsals where .owner = viewer last 100 by .at after c

query calloutAlerts(c: cursor ?):
  if exists staff[viewer]:
    return alerts last 100 by .at after c
  return alerts where .understudy = viewer last 100 by .at after c

query playedPerformances(c: cursor ?):
  if exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'director'] or exists staff[viewer, position = 'assistant']:
    return performances last 100 by .performanceAt after c
  return performances where .understudy = viewer last 100 by .performanceAt after c

query fittingLog(c: cursor ?):
  if exists staff[viewer]:
    return fittings last 100 by .fittedAt after c
  return fittings where .understudy = viewer last 100 by .fittedAt after c

mutation logRehearsal(scene: scenes, minutes: int 1..240, note: text 1..500, intensity: int 1..5 ?):
  intensityValue = intensity ?? 3
  s = scenes[scene] ! else NOT_FOUND
  require s.owner = viewer else NOT_YOUR_TRACK
  return insert rehearsals { scene, owner: viewer, minutes, intensity: intensityValue, note }

mutation reviewScene(scene: scenes, ready: bool, note: text <=500):
  require exists staff[viewer, position = 'manager'] else MANAGER_ONLY
  s = scenes[scene] ! else NOT_FOUND
  require not ready or (rehearsalTotals[scene] ?? 0) > 0 else REHEARSE_FIRST 'Log a rehearsal before signing off.'
  update scenes[scene] { ready, managerNote: note }
  return scenes[scene]

mutation triggerCallout(role: roles, performanceAt: time, message: text 1..500):
  require exists staff[viewer, position = 'manager'] else MANAGER_ONLY
  r = roles[role] ! else NOT_FOUND
  return insert alerts { role, understudy: r.understudy, performanceAt, message }

mutation recordPerformance(role: roles, performanceAt: time, note: text <=500):
  require exists staff[viewer, position = 'manager'] else MANAGER_ONLY
  r = roles[role] ! else NOT_FOUND
  return insert performances { role, understudy: r.understudy, performanceAt, note }

-- Stage management records a costume fitting for a cover; assistants may file them too.
mutation recordFitting(role: roles, fittedAt: time, note: text <=500):
  require exists staff[viewer, position = 'manager'] or exists staff[viewer, position = 'assistant'] else MANAGER_ONLY
  r = roles[role] ! else NOT_FOUND
  return insert fittings { role, understudy: r.understudy, fittedAt, note }

-- Production bootstrap: the operator seat provisions the first staff row.
-- Signup grants no role; later staff rows go through this same mutation.
mutation bootstrapStaff(seat_position: enum('manager', 'director', 'crew', 'assistant'), seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { position: seat_position, principal: seat_principal }

-- Company provisioning for production: manager or operator seat creates
-- roles and their scenes. Scene ownership follows the role's understudy.
mutation createRole(title: text 1..80, principalName: text 1..80, understudy: principal):
  require viewer = 'service:ops' or exists staff[viewer, position = 'manager'] else MANAGER_ONLY
  return insert roles { title, principalName, understudy }

mutation createScene(role: roles, title: text 1..100, sequence: int 1..99):
  require viewer = 'service:ops' or exists staff[viewer, position = 'manager'] else MANAGER_ONLY
  r = roles[role] ! else NOT_FOUND
  return insert scenes { role, owner: r.understudy, title, sequence }
