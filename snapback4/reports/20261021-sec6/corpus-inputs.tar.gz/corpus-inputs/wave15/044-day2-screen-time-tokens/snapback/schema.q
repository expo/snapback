use identity password
use personas parent, alice, bob

-- Private household: an operator provisions parents; parents enroll children.
table members:
  principal: principal
  role: enum('parent', 'child')
  displayName: text 1..40
  weeklyAllowance: int 0..100 default 10
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops' or exists members[principal = viewer, role = 'parent']
  insert <- viewer = 'service:ops' or exists members[principal = viewer, role = 'parent']
  update <- exists members[principal = viewer, role = 'parent']
  delete <- deny
  online only

-- One row per child per Monday-based week, written by the daily refill job.
-- week = (day(timestamp) - 4) / 7, so week boundaries are Monday 00:00 UTC.
table grants:
  child: principal
  tokens: int 0..100
  week: int
  at: time default now
  unique child, week
  immutable child, week
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
  insert <- deny
  update <- deny
  delete <- deny
  online only

-- A child spending request. Requests within the remaining balance are
-- approved immediately; requests beyond it stay pending for a parent.
table spends:
  child: principal
  tokens: int 1..50
  label: text 1..80
  category: enum('general', 'games', 'video', 'learning') default 'general'
  status: enum('pending', 'approved', 'denied', 'cancelled')
  decidedBy: principal ?
  week: int
  at: time default now
  immutable child, tokens, label, week, at
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
  insert <- .child = viewer
  update (old, next) <- exists members[principal = viewer, role = 'parent'] or (old.child = viewer and old.status = 'pending' and next.status = 'cancelled')
  delete <- deny
  cap 500 by child
  online only

-- Bonus tokens earned for chores. Credited only once a parent confirms.
table earnings:
  child: principal
  tokens: int 1..20
  chore: text 1..80
  status: enum('pending', 'confirmed', 'rejected')
  decidedBy: principal ?
  week: int
  at: time default now
  immutable child, tokens, chore, week, at
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
  insert <- .child = viewer
  update <- exists members[principal = viewer, role = 'parent']
  delete <- deny
  cap 500 by child
  online only

-- Lifetime totals. A group with no rows reads 0. The read rule discloses a
-- total only to its owner or to a parent.
view grantedTotal: sum grants of .tokens by .child
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
view spentTotal: sum spends of .tokens where .status = 'approved' by .child
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
view earnedTotal: sum earnings of .tokens where .status = 'confirmed' by .child
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
view spentByWeek: sum spends of .tokens where .status = 'approved' by .child, .week
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
view earnedByWeek: sum earnings of .tokens where .status = 'confirmed' by .child, .week
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']

-- Monday-based week index for a timestamp: Mondays are days with day % 7 = 4
-- (day 0 was a Thursday), so (day - 4) / 7 counts Mondays. Floor division:
-- all day numbers in practice are positive.
query currentWeek():
  w = day(now)
  return (w - 4) / 7

query myBalance():
  w = day(now)
  week = (w - 4) / 7
  granted = grantedTotal[viewer]
  earned = earnedTotal[viewer]
  spent = spentTotal[viewer]
  return { granted, earned, spent, balance: granted + earned - spent, week, weekSpent: spentByWeek[viewer, week], weekEarned: earnedByWeek[viewer, week] }

query myProfile():
  return members[principal = viewer]

query mySpends(c: cursor ?):
  return spends where .child = viewer last 50 by .id after c

query myEarnings(c: cursor ?):
  return earnings where .child = viewer last 50 by .id after c

query roster(c: cursor ?):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see the household roster.'
  return members last 50 by .id after c

query childUsage(child: principal, week: int):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see another child.'
  return { granted: grantedTotal[child], earned: earnedTotal[child], spent: spentTotal[child], balance: grantedTotal[child] + earnedTotal[child] - spentTotal[child], weekSpent: spentByWeek[child, week], weekEarned: earnedByWeek[child, week] }

query pendingSpends(c: cursor ?):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see pending approvals.'
  return spends where .status = 'pending' first 50 by .id after c

query pendingEarnings(c: cursor ?):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see pending approvals.'
  return earnings where .status = 'pending' first 50 by .id after c

query allSpends(c: cursor ?):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see every approval.'
  return spends last 100 by .id after c

query allEarnings(c: cursor ?):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see every approval.'
  return earnings last 100 by .id after c

mutation addMember(child: principal, displayName: text 1..40, allowance: int 0..100):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can add members.'
  return insert members { principal: child, role: 'child', displayName, weeklyAllowance: allowance }

mutation setAllowance(child: principal, allowance: int 0..100):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can set allowances.'
  m = members[principal = child] ! else NOT_FOUND
  require m.role = 'child' else NOT_A_CHILD 'Allowances apply to children.'
  update members[principal = child] { weeklyAllowance: allowance }
  return null

mutation requestSpend(tokens: int 1..50, label: text 1..80):
  require exists members[principal = viewer, role = 'child'] else NOT_A_CHILD 'Only a child can spend tokens.'
  w = day(now)
  week = (w - 4) / 7
  remaining = grantedTotal[viewer] + earnedTotal[viewer] - spentTotal[viewer]
  status = 'approved' if tokens <= remaining else 'pending'
  return insert spends { child: viewer, tokens, label, status, week }

mutation decideSpend(request: spends, approve: bool):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can approve spending.'
  r = spends[request] ! else NOT_FOUND
  require r.status = 'pending' else NOT_PENDING 'Only a pending request can be decided.'
  update spends[request] { status: 'approved' if approve else 'denied', decidedBy: viewer }
  return null

mutation requestBonus(tokens: int 1..20, chore: text 1..80):
  require exists members[principal = viewer, role = 'child'] else NOT_A_CHILD 'Only a child can claim chore bonuses.'
  w = day(now)
  week = (w - 4) / 7
  return insert earnings { child: viewer, tokens, chore, status: 'pending', week }

mutation decideBonus(bonus: earnings, approve: bool):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can confirm bonuses.'
  e = earnings[bonus] ! else NOT_FOUND
  require e.status = 'pending' else NOT_PENDING 'Only a pending bonus can be decided.'
  update earnings[bonus] { status: 'confirmed' if approve else 'rejected', decidedBy: viewer }
  return null

-- Runs daily; the unique key makes it a no-op except on the first run of each
-- week, so each child gets one grant row per Monday-based week. 07:00 UTC is
-- Monday morning in the US/Europe Sunday night... (Monday 07:00 UTC).
job refill(periodStart: time, periodEnd: time):
  w = day(periodStart)
  week = (w - 4) / 7
  for m in members where .role = 'child' by .id:
    if not exists grants[m.principal, week]:
      insert grants { child: m.principal, tokens: m.weeklyAllowance, week, at: periodStart }

schedule mondayRefill every 1d at 07:00: refill

-- Signup never confers household authority. Mint the seat locally on this store.
mutation provisionParent(account: principal, displayName: text 1..40):
  require viewer = 'service:ops' else NOT_OPERATOR 'Only the operator can provision a parent.'
  return insert members { principal: account, role: 'parent', displayName, weeklyAllowance: 0 }

-- Append-only explanations; children see their own, parents see the household.
table withdrawals:
  request: spends
  child: principal
  reason: text 1..160
  at: time default now
  unique request
  immutable request, child, reason, at
  read <- .child = viewer or exists members[principal = viewer, role = 'parent']
  insert <- .child = viewer
  update <- deny
  delete <- deny
  online only

mutation requestSession(tokens: int 1..50, label: text 1..80, category: enum('general', 'games', 'video', 'learning')):
  require exists members[principal = viewer, role = 'child'] else NOT_A_CHILD 'Only a child can spend tokens.'
  w = day(now)
  week = (w - 4) / 7
  remaining = grantedTotal[viewer] + earnedTotal[viewer] - spentTotal[viewer]
  status = 'approved' if tokens <= remaining else 'pending'
  return insert spends { child: viewer, tokens, label, category, status, week }

mutation withdrawSpend(request: spends, reason: text 1..160):
  r = spends[request] ! else NOT_FOUND
  require r.child = viewer else NOT_OWNER 'Only the requesting child can withdraw.'
  require r.status = 'pending' else NOT_PENDING 'Only a pending request can be withdrawn.'
  update spends[request] { status: 'cancelled', decidedBy: viewer }
  return insert withdrawals { request, child: viewer, reason }

query myWithdrawals(c: cursor ?):
  return withdrawals where .child = viewer last 50 by .id after c

query allWithdrawals(c: cursor ?):
  require exists members[principal = viewer, role = 'parent'] else NOT_PARENT 'Only a parent can see every withdrawal.'
  return withdrawals last 100 by .id after c
