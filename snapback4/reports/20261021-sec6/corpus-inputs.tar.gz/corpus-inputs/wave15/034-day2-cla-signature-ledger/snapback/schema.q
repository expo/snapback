-- Contributor Agreement Ledger.
-- Individuals sign for themselves; a company admin signs a corporate
-- agreement (terms kept private to the admin) and approves covered employees.
-- Maintainers see only coverage (whether covered), never corporate terms.
-- The public company list carries names only. Every signature and
-- revocation appends to eventLog.
use identity
use personas alice, bob, carol

table maintainers:
  principal: principal
  unique principal
  immutable principal
  insert <- viewer = 'service:ops'
  read <- allow
  online only

table individualSigs:
  signer: principal
  signedAt: time default now
  revoked: bool default false
  unique signer
  immutable signer
  read <- .signer = viewer or exists maintainers[principal = viewer]
  insert <- .signer = viewer
  update <- .signer = viewer
  online only

-- Literal default interprets pre-release company rows as agreement version 1.
table companies:
  agreementVersion: int 1.. default 1
  name: text 1..80
  admin: principal
  revoked: bool default false
  unique name
  immutable admin
  read <- allow
  insert <- .admin = viewer
  update <- .admin = viewer
  online only

table companyTerms:
  company: companies
  admin: principal
  terms: text 1..4000
  unique company
  immutable company, admin
  read <- .admin = viewer
  insert <- .admin = viewer and exists companies[.company, admin = viewer]
  update <- .admin = viewer
  online only

table employeeCoverage:
  company: companies
  employee: principal
  approvedAt: time default now
  revoked: bool default false
  unique company, employee
  immutable company, employee
  cap 500 by company
  read <- .employee = viewer or exists companies[.company, admin = viewer] or exists maintainers[principal = viewer]
  insert <- exists companies[.company, admin = viewer]
  update <- exists companies[.company, admin = viewer]
  delete <- exists companies[.company, admin = viewer]
  online only

-- Previous terms stay private to the admin, just like current terms.
-- No updates/deletes: every archived version is immutable.
table agreementRevisions:
  company: companies
  admin: principal
  version: int 1..
  terms: text 1..4000
  archivedAt: time default now
  unique company, version
  immutable company, admin, version, terms, archivedAt
  read <- .admin = viewer
  insert <- .admin = viewer and exists companies[.company, admin = viewer]
  online only

table eventLog:
  kind: enum('individual_signed', 'individual_revoked', 'corporate_signed', 'corporate_revoked', 'employee_approved', 'employee_removed', 'corporate_revised')
  actor: principal
  subject: text 1..120
  at: time default now
  immutable kind, actor, subject
  read <- allow
  insert <- .actor = viewer
  online only

query publicCompanies(c: cursor ?):
  return companies where .revoked = false first 50 by .id after c

query mySignature():
  return individualSigs where .signer = viewer

query myCompanies(c: cursor ?):
  return companies where .admin = viewer first 50 by .id after c

query companyTermsOf(company: companies):
  return companyTerms where .company = company

query companyRoster(company: companies, c: cursor ?):
  return employeeCoverage where .company = company and .revoked = false first 100 by .id after c

query isCovered(contributor: principal):
  individual = exists individualSigs[signer = contributor, revoked = false]
  corporate = exists employeeCoverage[employee = contributor, revoked = false]
  return { individual, corporate, covered: individual or corporate }

query signatureLog(c: cursor ?):
  return eventLog last 50 by .at after c

mutation signIndividual():
  upsert individualSigs[signer = viewer] { signer: viewer, signedAt: now, revoked: false }
  insert eventLog { kind: 'individual_signed', actor: viewer, subject: 'self' }
  return individualSigs[signer = viewer]

mutation revokeIndividual():
  update individualSigs[signer = viewer] { revoked: true }
  insert eventLog { kind: 'individual_revoked', actor: viewer, subject: 'self' }
  return null

mutation createCompany(name: text 1..80, terms: text 1..4000):
  c = insert companies { name, admin: viewer }
  insert companyTerms { company: c.id, admin: viewer, terms }
  insert eventLog { kind: 'corporate_signed', actor: viewer, subject: name }
  return c

mutation approveEmployee(company: companies, employee: principal):
  co = companies[company] ! else NOT_FOUND
  require not co.revoked else COMPANY_REVOKED 'This company agreement was revoked.'
  upsert employeeCoverage[company = company, employee = employee] { company, employee, approvedAt: now, revoked: false }
  insert eventLog { kind: 'employee_approved', actor: viewer, subject: co.name }
  return null

mutation removeEmployee(company: companies, employee: principal):
  co = companies[company] ! else NOT_FOUND
  update employeeCoverage[company = company, employee = employee] { revoked: true }
  insert eventLog { kind: 'employee_removed', actor: viewer, subject: co.name }
  return null

mutation revokeCompany(company: companies):
  co = companies[company] ! else NOT_FOUND
  update companies[company] { revoked: true }
  insert eventLog { kind: 'corporate_revoked', actor: viewer, subject: co.name }
  return null

-- Maintainers are provisioned by an operator, never by public signup.
mutation grantMaintainer(principal: principal):
  return insert maintainers { principal }

query agreementHistory(company: companies, c: cursor ?):
  return agreementRevisions where .company = company and .admin = viewer last 50 by .version after c

mutation reviseAgreement(company: companies, terms: text 1..4000):
  co = companies[company] ! else NOT_FOUND
  require co.admin = viewer else NOT_ADMIN 'Only the company admin can revise its agreement.'
  require not co.revoked else COMPANY_REVOKED 'This company agreement was revoked.'
  current = companyTerms[company = company] ! else NOT_FOUND
  insert agreementRevisions { company, admin: viewer, version: co.agreementVersion, terms: current.terms }
  update companyTerms[current.id] { terms }
  update companies[company] { agreementVersion: co.agreementVersion + 1 }
  insert eventLog { kind: 'corporate_revised', actor: viewer, subject: co.name }
  return companies[company]
