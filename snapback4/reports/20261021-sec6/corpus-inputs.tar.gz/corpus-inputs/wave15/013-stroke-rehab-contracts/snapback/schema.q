use personas alice, bob, carol, dana, eve

-- alice: therapist; bob: patient; carol: family; dana: manager; eve: another patient.
table staff:
  principal: principal
  role: enum('therapist', 'manager')
  unique principal
  read <- .principal = viewer
  online only

table patients:
  patient: principal
  therapist: principal
  family: principal
  name: text 1..80
  unique patient
  immutable patient, therapist, family, name
  read <- .patient = viewer or .therapist = viewer or .family = viewer
  online only

table contracts:
  patient: patients
  weekStart: int
  promise: text 1..500
  state: enum('active', 'reviewed') default 'active'
  unique patient, weekStart
  immutable patient, weekStart, promise
  read through .patient
  insert <- exists patients[.patient, therapist = viewer]
  update <- exists patients[.patient, therapist = viewer]
  online only

table goals:
  contract: contracts
  title: text 1..120
  targetDays: int 1..7
  completedDays: int 0..7 default 0
  immutable contract, title, targetDays
  read through .contract
  insert <- exists patients[.contract.patient, therapist = viewer]
  update <- exists patients[.contract.patient, patient = viewer]
  online only

table acknowledgments:
  contract: contracts
  principal: principal
  at: time default now
  unique contract, principal
  immutable contract, principal, at
  read through .contract
  insert <- .principal = viewer and (exists patients[.contract.patient, patient = viewer] or exists patients[.contract.patient, family = viewer])
  online only

table checkins:
  goal: goals
  dayNumber: int 1..7
  at: time default now
  unique goal, dayNumber
  immutable goal, dayNumber, at
  read through .goal
  insert <- exists patients[.goal.contract.patient, patient = viewer]
  online only

table clinicalNotes:
  contract: contracts
  therapist: principal
  body: text 1..2000
  at: time default now
  unique contract
  immutable contract, therapist, body, at
  read <- .therapist = viewer
  insert <- .therapist = viewer and exists patients[.contract.patient, therapist = viewer]
  online only

view contractCount: count contracts
  read <- exists staff[principal = viewer, role = 'manager']
view reviewedCount: count contracts where .state = 'reviewed'
  read <- exists staff[principal = viewer, role = 'manager']
view exerciseCount: count checkins
  read <- exists staff[principal = viewer, role = 'manager']
view targetCount: sum goals of .targetDays
  read <- exists staff[principal = viewer, role = 'manager']
view goalCount: count goals
  read <- exists staff[principal = viewer, role = 'manager']
view completedGoalCount: count goals where .completedDays >= .targetDays
  read <- exists staff[principal = viewer, role = 'manager']

query myRole():
  return staff[principal = viewer]
query myPatients():
  if exists staff[principal = viewer, role = 'therapist']:
    return patients where .therapist = viewer first 100 by .id
  if exists patients[patient = viewer]:
    return patients where .patient = viewer first 100 by .id
  return patients where .family = viewer first 100 by .id
query weeklyContracts(patient: patients):
  p = patients[patient] ! else NOT_FOUND
  return contracts where .patient = p.id last 52 by .weekStart
query contractGoals(contract: contracts):
  c = contracts[contract] ! else NOT_FOUND
  return goals where .contract = c.id first 10 by .id
query signatures(contract: contracts):
  c = contracts[contract] ! else NOT_FOUND
  return acknowledgments where .contract = c.id first 2 by .id
query exerciseLog(goal: goals):
  g = goals[goal] ! else NOT_FOUND
  return checkins where .goal = g.id first 7 by .dayNumber
query goalProgress(goal: goals):
  g = goals[goal] ! else NOT_FOUND
  return { completed: g.completedDays, target: g.targetDays }
query reviewNote(contract: contracts):
  return clinicalNotes[contract = contract]
query clinicCompletion():
  require exists staff[principal = viewer, role = 'manager'] else MANAGER_ONLY
  return { contracts: contractCount, reviewed: reviewedCount, completedDays: exerciseCount, targetDays: targetCount, goals: goalCount, completedGoals: completedGoalCount }

mutation createContract(patient: patients, weekStart: int, promise: text 1..500, firstGoal: text 1..120, firstTarget: int 1..7, secondGoal: text 1..120, secondTarget: int 1..7):
  p = patients[patient] ! else NOT_FOUND
  require p.therapist = viewer else THERAPIST_ONLY
  require count(contracts where .patient = patient) = 0 else USE_WEEKLY_RENEWAL
  c = insert contracts { patient, weekStart, promise }
  insert goals { contract: c.id, title: firstGoal, targetDays: firstTarget }
  insert goals { contract: c.id, title: secondGoal, targetDays: secondTarget }
  return c
mutation acknowledge(contract: contracts):
  c = contracts[contract] ! else NOT_FOUND
  p = patients[c.patient] ! else NOT_FOUND
  require p.patient = viewer or p.family = viewer else ACKNOWLEDGER_ONLY
  require c.state = 'active' else WEEK_CLOSED
  return insert acknowledgments { contract, principal: viewer } if absent
mutation checkIn(goal: goals, dayNumber: int 1..7):
  g = goals[goal] ! else NOT_FOUND
  c = contracts[g.contract] ! else NOT_FOUND
  p = patients[c.patient] ! else NOT_FOUND
  require p.patient = viewer else PATIENT_ONLY
  require c.state = 'active' else WEEK_CLOSED
  require exists acknowledgments[c.id, p.patient] and exists acknowledgments[c.id, p.family] else ACKNOWLEDGMENTS_REQUIRED
  if exists checkins[goal, dayNumber]:
    return null
  entry = insert checkins { goal, dayNumber }
  update goals[goal] { completedDays: g.completedDays + 1 }
  return entry
mutation reviewWeek(contract: contracts, body: text 1..2000):
  c = contracts[contract] ! else NOT_FOUND
  p = patients[c.patient] ! else NOT_FOUND
  require p.therapist = viewer else THERAPIST_ONLY
  require c.state = 'active' else WEEK_CLOSED
  insert clinicalNotes { contract, therapist: viewer, body }
  update contracts[contract] { state: 'reviewed' }
  return null
mutation renewContract(contract: contracts, promise: text 1..500, firstGoal: text 1..120, firstTarget: int 1..7, secondGoal: text 1..120, secondTarget: int 1..7):
  old = contracts[contract] ! else NOT_FOUND
  p = patients[old.patient] ! else NOT_FOUND
  require p.therapist = viewer else THERAPIST_ONLY
  require old.state = 'reviewed' else REVIEW_REQUIRED
  c = insert contracts { patient: old.patient, weekStart: old.weekStart + 7, promise }
  insert goals { contract: c.id, title: firstGoal, targetDays: firstTarget }
  insert goals { contract: c.id, title: secondGoal, targetDays: secondTarget }
  return c
