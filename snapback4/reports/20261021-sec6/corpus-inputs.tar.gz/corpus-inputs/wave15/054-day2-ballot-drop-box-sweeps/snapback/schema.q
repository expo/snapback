-- Ballot Drop Box Sweeps: two-person chain-of-custody for ballot drop boxes.
-- Staff (alice, bob) empty boxes on rural routes; both team members confirm
-- each sweep from their own phones. The director manages boxes and roles.
-- Observers read the custody log; the public sees last-emptied times only.
use personas alice, bob, director, observer, auditor
use identity

table roles:
  principal: principal
  role: enum('staff', 'director', 'observer', 'auditor')
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'director'] or viewer = 'service:ops'
  insert <- exists roles[viewer, role = 'director'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'director'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'director']
  online only

table boxes:
  name: text 1..80
  location: text 1..200
  lastEmptiedAt: time ?
  needsAttention: bool default false
  createdBy: principal
  immutable name, location, createdBy
  public 'box sites and last-emptied times are public'
  insert <- exists roles[viewer, role = 'director']
  update <- exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'staff']
  delete <- exists roles[viewer, role = 'director']
  sync public last 100 by .id

table sweeps:
  box: boxes on delete restrict
  seal: text 1..40
  containers: int 0..10000
  photo: image <=10000000 ?
  openedBy: principal
  openedAt: time default now
  confirmed: bool default false
  immutable box, seal, containers, photo, openedBy, openedAt
  read <- .openedBy = viewer or exists roles[viewer]
  insert <- .openedBy = viewer and exists roles[viewer, role = 'staff']
  update <- exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'director']
  sync

table confirmations:
  sweep: sweeps on delete cascade
  confirmer: principal
  at: time default now
  unique sweep, confirmer else ALREADY_CONFIRMED
  immutable sweep, confirmer, at
  read <- exists roles[viewer]
  insert <- .confirmer = viewer and exists roles[viewer, role = 'staff']
  sync last 500 by .at, .id

view confirmTotal: count confirmations by sweep
  read <- exists roles[viewer]

table incidents:
  box: boxes on delete restrict
  kind: enum('damaged', 'full', 'tampered', 'other')
  note: text 1..200
  reportedBy: principal
  reportedAt: time default now
  immutable box, kind, note, reportedBy, reportedAt
  read <- exists roles[viewer]
  insert <- .reportedBy = viewer and exists roles[viewer, role = 'staff']
  sync last 500 by .reportedAt, .id

query boxList(c: cursor ?):
  return boxes last 100 by .id after c

query publicStatus(c: cursor ?):
  return boxes last 100 by .id after c { id, name, lastEmptiedAt }

query custodyLog(c: cursor ?):
  return sweeps last 50 by .openedAt, .id after c

query sweepsFor(box: boxes, c: cursor ?):
  return sweeps where .box = box last 50 by .openedAt, .id after c

query confirmsFor(sweep: sweeps, c: cursor ?):
  return confirmations where .sweep = sweep first 10 by .id after c

query incidentsFor(box: boxes, c: cursor ?):
  return incidents where .box = box first 20 by .id after c

query attentionBoxes(c: cursor ?):
  require exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'staff'] else NOT_STAFF
  return boxes where .needsAttention = true last 100 by .id after c

query confirmCount(sweep: sweeps):
  return confirmTotal[sweep]

query sweepStatus(sweep: sweeps):
  return sweeps[sweep] { id, confirmed }

mutation addBox(name: text 1..80, location: text 1..200):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  return insert boxes { name, location, createdBy: viewer }

mutation recordSweep(box: boxes, seal: text 1..40, containers: int 0..10000, photo: image <=10000000 ?):
  b = boxes[box] ! else NOT_FOUND
  require exists roles[viewer, role = 'staff'] else NOT_STAFF
  return insert sweeps { box, seal, containers, photo, openedBy: viewer }

mutation confirmSweep(sweep: sweeps):
  s = sweeps[sweep] ! else NOT_FOUND
  require exists roles[viewer, role = 'staff'] else NOT_STAFF
  require not exists confirmations[sweep, viewer] else ALREADY_CONFIRMED
  insert confirmations { sweep, confirmer: viewer }
  n = confirmTotal[sweep] ?? 0
  if n >= 2:
    update sweeps[sweep] { confirmed: true }
    update boxes[s.box] { lastEmptiedAt: now }
  return null

mutation grantRole(who: principal, role: enum('staff', 'director', 'observer', 'auditor')):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  return upsert roles[who] { role }

mutation provisionRole(who: principal, role: enum('staff', 'director', 'observer', 'auditor')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return upsert roles[who] { role }

mutation reportIncident(box: boxes, kind: enum('damaged', 'full', 'tampered', 'other'), note: text 1..200):
  b = boxes[box] ! else NOT_FOUND
  require exists roles[viewer, role = 'staff'] else NOT_STAFF
  r = insert incidents { box, kind, note, reportedBy: viewer }
  update boxes[b.id] { needsAttention: true }
  return r

mutation clearAttention(box: boxes):
  require exists roles[viewer, role = 'director'] else NOT_DIRECTOR
  b = boxes[box] ! else NOT_FOUND
  return update boxes[b.id] { needsAttention: false }
