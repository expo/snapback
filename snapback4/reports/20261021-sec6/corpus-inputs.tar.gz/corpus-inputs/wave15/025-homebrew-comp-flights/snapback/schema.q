-- Homebrew Competition Flights.
-- Personas: alice (entrant), bob (judge), carol (organizer/steward).
-- Judges see blind entries (code/style, no brewer names). Scores are hidden
-- from other judges until the flight closes, public once released.

use personas alice, bob, carol

table organizers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  online only

table flights:
  name: text 1..60
  closed: bool default false
  released: bool default false
  public 'flight list is public'
  insert <- exists organizers[principal = viewer]
  update <- exists organizers[principal = viewer]
  online only

table assignments:
  flight: flights
  judge: principal
  unique flight, judge
  immutable flight, judge
  read <- allow
  insert <- exists organizers[principal = viewer]
  online only

table entries:
  brewer: principal
  name: text 1..80
  style: text 1..60
  dropoff: text 1..120
  code: text 1..20 ?
  flight: flights ?
  at: time default now
  immutable brewer
  read <- allow
  insert <- .brewer = viewer
  update <- .brewer = viewer or exists organizers[principal = viewer]
  online only

table scores:
  entry: entries
  judge: principal
  score: int 0..50
  notes: text <=500 ?
  at: time default now
  unique entry, judge
  immutable entry, judge
  read <- allow
  insert <- .judge = viewer
  update <- .judge = viewer
  online only

query myEntries():
  return entries where .brewer = viewer last 100 by .id

query flightsList():
  return flights last 100 by .id

query myAssignments():
  return assignments where .judge = viewer first 50 by .id

query assignmentsFor(flight: flights):
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer views judging assignments.'
  return assignments where .flight = flight first 50 by .id

query allEntries():
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer views all entries.'
  return entries last 100 by .id

query flightEntries(flight: flights):
  f = flights[flight] ! else NOT_FOUND
  if f.released:
    return entries where .flight = flight first 100 by .code { id, code, name, style }
  if exists organizers[principal = viewer]:
    return entries where .flight = flight first 100 by .code { id, code, name, style }
  require exists assignments[flight, viewer] else NOT_ASSIGNED 'You are not assigned to judge this flight.'
  return entries where .flight = flight first 100 by .code { id, code, name, style }

query scoresOf(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.flight != null else NOT_CODED 'This entry is not coded into a flight yet.'
  f = flights[e.flight] ! else NOT_FOUND
  if f.released:
    return scores where .entry = entry first 50 by .id
  if exists organizers[principal = viewer]:
    return scores where .entry = entry first 50 by .id
  require f.closed and exists assignments[f.id, viewer] else SCORES_HIDDEN 'Scores stay hidden until the flight closes.'
  return scores where .entry = entry first 50 by .id

query flightScores(flight: flights):
  f = flights[flight] ! else NOT_FOUND
  if f.released:
    return scores where .entry.flight = flight first 200 by .id
  if exists organizers[principal = viewer]:
    return scores where .entry.flight = flight first 200 by .id
  require f.closed and exists assignments[flight, viewer] else SCORES_HIDDEN 'Scores stay hidden until the flight closes.'
  return scores where .entry.flight = flight first 200 by .id

mutation registerEntry(name: text 1..80, style: text 1..60, dropoff: text 1..120):
  row = insert entries { brewer: viewer, name: name, style: style, dropoff: dropoff }
  return { id: row.id }

mutation createFlight(name: text 1..60):
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer creates flights.'
  row = insert flights { name: name }
  return { id: row.id }

mutation assignCode(entry: entries, code: text 1..20, flight: flights):
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer codes entries.'
  e = entries[entry] ! else NOT_FOUND
  f = flights[flight] ! else NOT_FOUND
  update entries[entry] { code: code, flight: flight }
  return { id: e.id }

mutation assignJudge(flight: flights, judge: principal):
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer assigns judges.'
  f = flights[flight] ! else NOT_FOUND
  row = insert assignments { flight: flight, judge: judge }
  return { id: row.id }

mutation closeFlight(flight: flights):
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer closes flights.'
  f = flights[flight] ! else NOT_FOUND
  update flights[flight] { closed: true }
  return { id: f.id }

mutation releaseResults(flight: flights):
  require exists organizers[principal = viewer] else NOT_ORGANIZER 'Only the organizer releases results.'
  f = flights[flight] ! else NOT_FOUND
  require f.closed else FLIGHT_OPEN 'Close the flight before releasing results.'
  update flights[flight] { released: true }
  return { id: f.id }

mutation score(entry: entries, score: int 0..50, notes: text <=500 ?):
  e = entries[entry] ! else NOT_FOUND
  require e.flight != null else NOT_CODED 'This entry is not coded into a flight yet.'
  f = flights[e.flight] ! else NOT_FOUND
  require not f.closed else FLIGHT_CLOSED 'This flight is closed; scores are final.'
  require exists assignments[f.id, viewer] else NOT_ASSIGNED 'You are not assigned to judge this flight.'
  upsert scores[entry = entry, judge = viewer] { entry: entry, judge: viewer, score: score, notes: notes, at: now }
  return { id: entry }
