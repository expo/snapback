-- Esports Roster Lock.
-- Seasons have a lock date; captains add/drop players before the lock.
-- Each added player carries proof of enrollment; a league admin approves
-- the player (status pending -> eligible). After the lock date (or once an
-- admin flips the locked flag) only an admin exception with a written
-- reason can change a roster. Captains read their own team's rows;
-- eligible players are public so anyone can see a locked roster.

use identity
use personas alice, bob, carol

table admins:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  immutable principal
  online only

table seasons:
  name: text 1..80
  lockAt: time
  locked: bool default false
  public 'Seasons and their lock dates are public.'
  insert <- exists admins[principal = viewer]
  update <- exists admins[principal = viewer]
  immutable name, lockAt
  online only

table teams:
  name: text 1..60
  season: seasons
  captain: principal
  public 'The team list is public.'
  insert <- exists admins[principal = viewer]
  update <- exists admins[principal = viewer]
  immutable season
  online only

table entries:
  team: teams
  season: seasons
  captain: principal
  playerName: text 1..60
  proof: text 1..500
  status: enum('pending', 'eligible', 'dropped', 'rejected') default 'pending'
  reason: text 1..280 ?
  proofRevision: int 1..1000 default 1
  createdAt: time default now
  read <- .status = 'eligible' or .captain = viewer or exists admins[principal = viewer]
  insert <- .captain = viewer or exists admins[principal = viewer]
  update <- .captain = viewer or exists admins[principal = viewer]
  immutable team, season, captain, playerName
  cap 20 by team
  online only

query seasonsList(c: cursor ?):
  return seasons first 50 by .id after c

query teamsOf(season: seasons, c: cursor ?):
  return teams where .season = season first 50 by .id after c

query myTeams(c: cursor ?):
  if exists admins[principal = viewer]:
    return teams first 50 by .id after c
  return teams where .captain = viewer first 50 by .id after c

query lockedRoster(season: seasons, c: cursor ?):
  return entries where .season = season and .status = 'eligible' first 100 by .id after c

query myPending(c: cursor ?):
  if exists admins[principal = viewer]:
    return entries where .status = 'pending' first 100 by .id after c
  return entries where .captain = viewer and .status = 'pending' first 100 by .id after c

query entryDetail(entry: entries):
  return entries[entry]

mutation addPlayer(team: teams, playerName: text 1..60, proof: text 1..500):
  t = teams[team] ! else NOT_FOUND
  require t.captain = viewer else NOT_CAPTAIN 'Only this team captain can change its roster.'
  s = seasons[t.season] ! else NOT_FOUND
  require now < s.lockAt and not s.locked else SEASON_LOCKED 'This roster is locked; ask a league admin for an exception.'
  return insert entries { team, season: t.season, captain: t.captain, playerName, proof, status: 'pending' }

mutation approvePlayer(entry: entries):
  require exists admins[principal = viewer] else NOT_ADMIN 'League admins only.'
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'pending' else BAD_STATE 'Only a pending player can be approved.'
  insert enrollmentReviews { entry, captain: e.captain, reviewer: viewer, revision: e.proofRevision, decision: 'approved', reason: 'Enrollment verified.' }
  update entries[entry] { status: 'eligible' }
  return entries[entry]

mutation dropPlayer(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.captain = viewer else NOT_CAPTAIN 'Only this team captain can change its roster.'
  s = seasons[e.season] ! else NOT_FOUND
  require now < s.lockAt and not s.locked else SEASON_LOCKED 'This roster is locked; ask a league admin for an exception.'
  update entries[entry] { status: 'dropped' }
  return entries[entry]

mutation exceptionAdd(team: teams, playerName: text 1..60, proof: text 1..500, reason: text 1..280):
  require exists admins[principal = viewer] else NOT_ADMIN 'League admins only.'
  t = teams[team] ! else NOT_FOUND
  return insert entries { team, season: t.season, captain: t.captain, playerName, proof, status: 'eligible', reason }

mutation exceptionDrop(entry: entries, reason: text 1..280):
  require exists admins[principal = viewer] else NOT_ADMIN 'League admins only.'
  e = entries[entry] ! else NOT_FOUND
  require e.status != 'dropped' else BAD_STATE 'This player is already dropped.'
  update entries[entry] { status: 'dropped', reason }
  return entries[entry]

mutation lockSeason(season: seasons):
  require exists admins[principal = viewer] else NOT_ADMIN 'League admins only.'
  update seasons[season] { locked: true }
  return seasons[season]

-- Only a locally minted operator credential can provision league admins.
mutation grantAdmin(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert admins { principal }

mutation createSeason(name: text 1..80, lockAt: time):
  require exists admins[principal = viewer] else NOT_ADMIN
  return insert seasons { name, lockAt }

mutation createTeam(name: text 1..60, season: seasons, captain: principal):
  require exists admins[principal = viewer] else NOT_ADMIN
  s = seasons[season] ! else NOT_FOUND
  return insert teams { name, season, captain }

-- Review notes are private to the captain and league admins.
table enrollmentReviews:
  entry: entries
  captain: principal
  reviewer: principal
  revision: int 1..1000
  decision: enum('approved', 'rejected')
  reason: text 1..280
  reviewedAt: time default now
  read <- .captain = viewer or exists admins[principal = viewer]
  insert <- exists admins[principal = viewer]
  immutable entry, captain, reviewer, revision, decision, reason, reviewedAt
  online only

query reviewHistory(entry: entries, c: cursor ?):
  return enrollmentReviews where .entry = entry first 100 by .id after c

query rejectedPlayers(c: cursor ?):
  if exists admins[principal = viewer]:
    return entries where .status = 'rejected' first 100 by .id after c
  return entries where .captain = viewer and .status = 'rejected' first 100 by .id after c

mutation rejectPlayer(entry: entries, reason: text 1..280):
  require exists admins[principal = viewer] else NOT_ADMIN 'League admins only.'
  e = entries[entry] ! else NOT_FOUND
  require e.status = 'pending' else BAD_STATE 'Only pending proof can be reviewed.'
  insert enrollmentReviews { entry, captain: e.captain, reviewer: viewer, revision: e.proofRevision, decision: 'rejected', reason }
  update entries[entry] { status: 'rejected', reason }
  return entries[entry]

mutation resubmitProof(entry: entries, proof: text 1..500):
  e = entries[entry] ! else NOT_FOUND
  require e.captain = viewer else NOT_CAPTAIN
  require e.status = 'rejected' else BAD_STATE 'Only rejected proof can be resubmitted.'
  s = seasons[e.season] ! else NOT_FOUND
  require now < s.lockAt and not s.locked else SEASON_LOCKED 'Ask an admin for an exception after lock.'
  require e.proofRevision < 1000 else REVISION_LIMIT
  update entries[entry] { proof, proofRevision: e.proofRevision + 1, status: 'pending' }
  return entries[entry]
