-- PPE Issue Ledger: warehouse PPE issuance with replacement dates, early-replacement approval, stock counts by size, per-worker and per-department visibility.
use identity
use personas alice, bob, carol

-- Roster: one row per privileged user (supervisor / safety manager / stockroom).
table staff:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

-- Each worker's sizes on file.
table workers:
  principal: principal
  name: text 1..40
  department: enum('warehouse', 'packing', 'shipping')
  gloveSize: enum('XS', 'S', 'M', 'L', 'XL')
  bootSize: text 1..6
  unique principal
  read <- .principal = viewer or exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  update <- .principal = viewer or exists staff[principal = viewer]
  delete <- deny
  online only

-- The ledger: one row per issued item.
table issues:
  holder: principal
  department: enum('warehouse', 'packing', 'shipping')
  item: enum('gloves', 'boots', 'glasses', 'vest', 'helmet')
  size: text 1..6
  issuedAt: time default now
  replaceAfter: time
  status: enum('issued', 'requested', 'approved', 'replaced') default 'issued'
  replacementCycle: int default 0
  by byHolder: holder, issuedAt, id
  read <- .holder = viewer or exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  update <- .holder = viewer or exists staff[principal = viewer]
  delete <- deny
  online only

-- Maintained aggregates. Views disclose totals, never rows.
view issueByDept: count issues by .department
  read <- exists staff[principal = viewer]
view openByItemSize: count issues where .status = 'issued' by .item, .size
  read <- exists staff[principal = viewer]

-- Workers read their own ledger.
query myIssues():
  return issues where .holder = viewer last 50 by byHolder

-- One worker's ledger: the worker themself, or a supervisor.
query workerIssues(holder: principal):
  if holder = viewer:
    return issues where .holder = holder last 50 by byHolder
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  return issues where .holder = holder last 50 by byHolder

-- Safety manager: issue totals per department.
query deptTotals():
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  return { warehouse: issueByDept['warehouse'], packing: issueByDept['packing'], shipping: issueByDept['shipping'] }

-- Stockroom: open (not yet replaced) count for one item/size.
query stockLevel(item: enum('gloves', 'boots', 'glasses', 'vest', 'helmet'), size: text 1..6):
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  return openByItemSize[item, size]

-- Supervisor registers a worker (sizes on file).
mutation addWorker(holder: principal, name: text 1..40, department: enum('warehouse', 'packing', 'shipping'), gloveSize: enum('XS', 'S', 'M', 'L', 'XL'), bootSize: text 1..6):
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  return insert workers { principal: holder, name, department, gloveSize, bootSize }

-- Worker keeps their own sizes current.
mutation updateMySizes(gloveSize: enum('XS', 'S', 'M', 'L', 'XL'), bootSize: text 1..6):
  w = workers[principal = viewer] ! else UNKNOWN_WORKER
  update workers[w.id] { gloveSize, bootSize }
  return workers[w.id]

-- Supervisor issues an item to a worker. Department is copied from the worker's file.
mutation issueItem(holder: principal, item: enum('gloves', 'boots', 'glasses', 'vest', 'helmet'), size: text 1..6, replaceAfter: time):
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  w = workers[principal = holder] ! else UNKNOWN_WORKER
  return insert issues { holder, department: w.department, item, size, replaceAfter, issuedAt: now }

-- Worker requests a replacement. Due items (now past replaceAfter) are auto-approved;
-- early ones wait for a supervisor.
mutation requestReplacement(issue: issues):
  r = issues[issue] ! else NOT_FOUND
  require r.holder = viewer or exists staff[principal = viewer] else NOT_YOURS
  require r.status = 'issued' else BAD_STATUS
  if now >= r.replaceAfter:
    update issues[issue] { status: 'approved' }
  else:
    update issues[issue] { status: 'requested' }
  return issues[issue]

-- Supervisor approves an early replacement request.
mutation approveReplacement(issue: issues):
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  r = issues[issue] ! else NOT_FOUND
  require r.status = 'requested' else BAD_STATUS
  update issues[issue] { status: 'approved' }
  return issues[issue]

-- Operators explicitly provision supervisors after account signup.
mutation grantStaff(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal }

query myProfile():
  return workers[principal = viewer]

query workerDirectory():
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  return workers first 100

-- A handover is append-only evidence of an actual replacement, not an approval.
table handovers:
  previous: issues
  replacement: issues
  holder: principal
  handledBy: principal
  reason: text 1..160
  at: time default now
  unique previous
  by byHolder: holder, at, id
  by byIssue: previous, at, id
  read <- .holder = viewer or exists staff[principal = viewer]
  insert <- exists staff[principal = viewer]
  update <- deny
  delete <- deny
  online only

query myHandovers():
  return handovers where .holder = viewer last 50 by byHolder

query issueHandovers(issue: issues):
  return handovers[previous = issue]

mutation fulfillReplacement(issue: issues, reason: text 1..160, replaceAfter: time):
  require exists staff[principal = viewer] else NOT_SUPERVISOR
  r = issues[issue] ! else NOT_FOUND
  require r.status = 'approved' else NOT_APPROVED
  require replaceAfter > now else FUTURE_DATE_REQUIRED
  next = insert issues { holder: r.holder, department: r.department, item: r.item, size: r.size, issuedAt: now, replaceAfter, replacementCycle: r.replacementCycle + 1 }
  update issues[issue] { status: 'replaced' }
  return insert handovers { previous: issue, replacement: next.id, holder: r.holder, handledBy: viewer, reason, at: now }
