-- Burn Permit Days — Quarry backend.
--
-- Rural residents apply for an annual open-burning permit (with a photo of the
-- burn site) which the fire chief approves. Each morning the chief declares
-- whether it is a burn day; permit holders may activate a burn only on a
-- declared day. Dispatchers see a live map of active burns with holder detail;
-- neighbors see an anonymous public version. Unclosed burns expire at sundown
-- (modelled as next UTC midnight).
--
-- Personas: alice + bob (residents), chief (fire chief, privileged),
-- dispatcher (sees identified live map).
use identity
use personas alice, bob, chief, dispatcher

-- Role roster. Seeded via fixtures (system load); only the chief changes it.
table roles:
  principal: principal
  role: enum('chief', 'dispatcher')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops' or exists roles[viewer, role = 'chief']
  insert <- viewer = 'service:ops' or exists roles[viewer, role = 'chief']
  update <- exists roles[viewer, role = 'chief']
  delete <- exists roles[viewer, role = 'chief']
  cap 10
  online only

-- Annual open-burning permits. Residents apply for themselves; only the
-- chief decides after reviewing the site photo.
table permits:
  holder: principal
  address: text 1..200
  photo: image <=5000000 ?
  status: enum('pending', 'approved', 'denied', 'revoked', 'withdrawn') default 'pending'
  revision: int 1..100 default 1
  appliedAt: time default now
  decidedAt: time ?
  decidedBy: principal ?
  immutable holder, address, photo, appliedAt
  read <- .holder = viewer or exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'dispatcher']
  insert <- .holder = viewer
  update (old, next) <- exists roles[viewer, role = 'chief'] or (old.holder = viewer and old.status = 'pending' and next.status = 'withdrawn' and next.revision > old.revision)
  cap 5 by holder
  online only

-- One row per UTC day: whether open burning is allowed that day.
table burnDays:
  day: int
  isBurnDay: bool
  note: text <=200 ?
  declaredBy: principal
  declaredAt: time default now
  unique day
  immutable day
  public 'whether today is a burn day is public'
  insert <- exists roles[viewer, role = 'chief']
  update <- exists roles[viewer, role = 'chief']
  cap 800
  online only

-- Active (and closed, until swept) burns with holder detail.
-- Visible only to the holder, the chief and the dispatcher.
table burns:
  permit: permits
  holder: principal
  area: text 1..120
  location: text 1..200 ?
  lat: int -90000000..90000000 ?
  lon: int -180000000..180000000 ?
  startedAt: time default now
  endsAt: time
  closedAt: time ?
  immutable permit, holder, area, location, lat, lon, startedAt, endsAt
  read <- .holder = viewer or exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'dispatcher']
  insert <- .holder = viewer
  update <- .holder = viewer
  expire at .endsAt
  cap 10 by holder
  online only

-- Anonymous public mirror of active burns. The holder column exists only so
-- the holder can close out (delete) their own sighting; no declared query
-- ever returns it, so neighbors see area + timing without identity.
table publicBurns:
  burn: burns
  holder: principal
  area: text 1..120
  startedAt: time default now
  endsAt: time
  unique burn
  immutable burn, holder, area, startedAt, endsAt
  public 'anonymous active-burn sightings'
  insert <- .holder = viewer
  delete <- .holder = viewer
  expire at .endsAt
  cap 500
  online only

query whoAmI():
  return viewer

query myPermits(c: cursor ?):
  return permits where .holder = viewer last 20 by .appliedAt after c

query reviewQueue(c: cursor ?):
  -- Pending applications visible to the viewer: every pending row for the
  -- chief, only their own for everyone else (table rules scope this).
  return permits where .status = 'pending' first 50 by .appliedAt after c

query burnDayStatus():
  return burnDays[day = day(now)]

query burnCalendar(c: cursor ?):
  return burnDays last 30 by .day after c

query myBurns(c: cursor ?):
  return burns where .holder = viewer last 20 by .startedAt after c

query dispatcherMap(c: cursor ?):
  -- Active burns visible to the viewer: every active burn for the chief and
  -- dispatchers, only their own for everyone else. Privilege to ACT (decide,
  -- declare, close out others) is enforced in mutations, not here.
  return burns where .closedAt = null last 100 by .startedAt after c

query publicMap(c: cursor ?):
  return publicBurns last 100 by .startedAt after c { id, area, startedAt, endsAt }

mutation applyPermit(address: text 1..200, photo: image <=5000000 ?):
  require not exists permits[holder = viewer, status = 'pending'] else ALREADY_PENDING 'You already have a pending application.'
  require not exists permits[holder = viewer, status = 'approved'] else ALREADY_PERMITTED 'You already hold an approved permit.'
  return insert permits { holder: viewer, address, photo, appliedAt: now }

mutation decidePermit(permit: permits, approve: bool):
  p = permits[permit] ! else NOT_FOUND
  require exists roles[viewer, role = 'chief'] else NOT_CHIEF 'Only the fire chief decides permits.'
  require p.status = 'pending' else NOT_PENDING 'This application is already decided.'
  update permits[permit] { status: 'approved' if approve else 'denied', decidedAt: now, decidedBy: viewer, revision: p.revision + 1 }
  return null

mutation declareToday(isBurnDay: bool, note: text <=200 ?):
  require exists roles[viewer, role = 'chief'] else NOT_CHIEF 'Only the fire chief declares burn days.'
  d = day(now)
  upsert burnDays[day = d] { isBurnDay, note, declaredBy: viewer, declaredAt: now }
  return null

mutation startBurn(permit: permits, area: text 1..120, location: text 1..200 ?, lat: int -90000000..90000000 ?, lon: int -180000000..180000000 ?):
  p = permits[permit] ! else NOT_FOUND
  require p.holder = viewer else NOT_YOUR_PERMIT 'This permit belongs to someone else.'
  require p.status = 'approved' else PERMIT_NOT_APPROVED 'Burns need an approved permit.'
  declaration = burnDays[day = day(now)]
  require declaration != null else NO_DECLARATION 'The chief has not declared today yet.'
  require declaration.isBurnDay else NOT_A_BURN_DAY 'Today is not a declared burn day.'
  require not exists burns[holder = viewer, closedAt = null] else ALREADY_BURNING 'Close out your active burn first.'
  endsAt = day(now) * 1d + 1d
  b = insert burns { permit, holder: viewer, area, location, lat, lon, startedAt: now, endsAt }
  insert publicBurns { burn: b, holder: viewer, area, startedAt: now, endsAt }
  return b.id

mutation endBurn(burn: burns):
  b = burns[burn] ! else NOT_FOUND
  require b.holder = viewer else NOT_YOUR_BURN 'This burn belongs to someone else.'
  require b.closedAt = null else ALREADY_CLOSED 'This burn is already closed out.'
  update burns[burn] { closedAt: now }
  sighting = publicBurns[burn = burn]
  if sighting != null:
    delete publicBurns[sighting]
  return null

-- Operators provision the initial chief; sign-up never grants staff privileges.
mutation grantRole(principal: principal, role: enum('chief', 'dispatcher')):
  require viewer = 'service:ops' or exists roles[viewer, role = 'chief'] else NOT_CHIEF 'Only operators and the chief assign staff roles.'
  return insert roles { principal, role }

-- Immutable withdrawal history: visible to the holder and reviewing chief.
table permitEvents:
  permit: permits
  holder: principal
  kind: enum('withdrawn')
  reason: text 1..300
  revision: int 2..100
  recordedAt: time default now
  immutable permit, holder, kind, reason, revision, recordedAt
  read <- .holder = viewer or exists roles[viewer, role = 'chief']
  insert <- .holder = viewer
  cap 100 by holder
  online only

query myPermitEvents(c: cursor ?):
  return permitEvents where .holder = viewer last 100 by .recordedAt after c

mutation withdrawPermit(permit: permits, expectedRevision: int 1..99, reason: text 1..300):
  p = permits[permit] ! else NOT_FOUND
  require p.holder = viewer else NOT_YOUR_PERMIT 'Only the applicant can withdraw.'
  require p.revision = expectedRevision else STALE_PERMIT 'This permit changed. Refresh before withdrawing.'
  require p.status = 'pending' else NOT_PENDING 'Only pending applications can be withdrawn.'
  update permits[permit] { status: 'withdrawn', revision: p.revision + 1 }
  return insert permitEvents { permit, holder: viewer, kind: 'withdrawn', reason, revision: p.revision + 1, recordedAt: now }
