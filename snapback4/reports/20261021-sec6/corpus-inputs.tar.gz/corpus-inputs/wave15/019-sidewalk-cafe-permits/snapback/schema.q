use personas alice, bob, inspector, office, visitor

table staff:
  principal: principal
  role: enum('inspector', 'office')
  unique principal
  read <- .principal = viewer
  insert <- deny
  online only

table applications:
  owner: principal
  restaurant: text 2..100
  address: text 5..160
  latitude: int -90000000..90000000
  longitude: int -180000000..180000000
  permitYear: int 2026..2100
  requestedTables: int 1..30
  opens: int 6..22
  closes: int 7..23
  drawing: file <=4000000 ('application/pdf', 'image/png', 'image/jpeg')
  insurance: file <=4000000 ('application/pdf', 'image/png', 'image/jpeg')
  insuranceUntil: time
  status: enum('submitted', 'approved', 'rejected') default 'submitted'
  changes: text <=1500 default ''
  clearanceCm: int 0..1000 default 0
  allowedTables: int 0..30 default 0
  submittedAt: time default now
  unique owner, permitYear else ALREADY_APPLIED
  immutable owner, permitYear
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer or exists staff[viewer, role = 'inspector']
  online only

table decisions:
  application: applications
  inspector: principal
  verdict: enum('approved', 'rejected')
  clearanceCm: int 0..1000
  allowedTables: int 0..30
  changes: text <=1500
  photos: [image <=4000000] <=4
  at: time default now
  read <- exists staff[viewer, role = 'office'] or exists staff[viewer, role = 'inspector'] or .application.owner = viewer
  insert <- .inspector = viewer and exists staff[viewer, role = 'inspector']
  update <- deny
  delete <- deny
  online only

table permits:
  application: applications
  restaurant: text 2..100
  address: text 5..160
  latitude: int -90000000..90000000
  longitude: int -180000000..180000000
  permitYear: int 2026..2100
  tables: int 1..30
  opens: int 6..22
  closes: int 7..23
  validUntil: time
  unique application
  public 'Approved sidewalk seating locations, table counts and permitted hours'
  insert <- exists staff[viewer, role = 'inspector']
  expire at .validUntil
  online only

query myApplications():
  return applications where .owner = viewer last 100 by .submittedAt { id, restaurant, address, permitYear, requestedTables, opens, closes, drawing, insurance, insuranceUntil, changes, clearanceCm, allowedTables, status: 'lapsed' if .status = 'approved' and (.insuranceUntil <= now or yearStart(.permitYear + 1) <= now) else .status }

query inspectionQueue():
  require exists staff[viewer, role = 'inspector'] else NOT_INSPECTOR
  return applications where .status = 'submitted' first 100 by .submittedAt

query auditTrail():
  require exists staff[viewer, role = 'office'] else NOT_OFFICE
  return decisions last 200 by .at

query publicMap():
  return permits first 200 by .id

query applicationHistory(application: applications):
  a = applications[application] ! else NOT_FOUND
  return decisions where .application = application last 100 by .at

mutation apply(restaurant: text 2..100, address: text 5..160, latitude: int -90000000..90000000, longitude: int -180000000..180000000, permitYear: int 2026..2100, requestedTables: int 1..30, opens: int 6..22, closes: int 7..23, drawing: file <=4000000 ('application/pdf', 'image/png', 'image/jpeg'), insurance: file <=4000000 ('application/pdf', 'image/png', 'image/jpeg'), insuranceUntil: time):
  require not exists staff[viewer] else RESTAURANT_ONLY
  require permitYear = year(now) else CURRENT_YEAR_ONLY
  require opens < closes else BAD_HOURS
  require insuranceUntil > now else INSURANCE_EXPIRED
  return insert applications { owner: viewer, restaurant, address, latitude, longitude, permitYear, requestedTables, opens, closes, drawing, insurance, insuranceUntil }

mutation resubmit(application: applications, drawing: file <=4000000 ('application/pdf', 'image/png', 'image/jpeg'), insurance: file <=4000000 ('application/pdf', 'image/png', 'image/jpeg'), insuranceUntil: time):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else NOT_OWNER
  require a.status = 'rejected' else NOT_REJECTED
  require a.permitYear = year(now) else CURRENT_YEAR_ONLY
  require insuranceUntil > now else INSURANCE_EXPIRED
  update applications[application] { drawing, insurance, insuranceUntil, status: 'submitted', changes: '', submittedAt: now }
  return null

mutation decide(application: applications, approve: bool, clearanceCm: int 0..1000, allowedTables: int 0..30, changes: text <=1500, photos: [image <=4000000] <=4):
  require exists staff[viewer, role = 'inspector'] else NOT_INSPECTOR
  a = applications[application] ! else NOT_FOUND
  require a.status = 'submitted' else ALREADY_DECIDED
  require len(photos) >= 1 else PHOTO_REQUIRED
  if approve:
    require clearanceCm >= 180 else CLEARANCE_TOO_NARROW
    require allowedTables >= 1 and allowedTables <= a.requestedTables else BAD_TABLE_COUNT
    require a.insuranceUntil > now else INSURANCE_EXPIRED
    require a.permitYear = year(now) else PERMIT_YEAR_ENDED
  else:
    require len(changes) >= 5 else CHANGES_REQUIRED
    require allowedTables = 0 else REJECTED_TABLE_COUNT
  verdict = 'approved' if approve else 'rejected'
  update applications[application] { status: verdict, changes, clearanceCm, allowedTables }
  d = insert decisions { application, inspector: viewer, verdict, clearanceCm, allowedTables, changes, photos }
  if approve:
    insert permits { application, restaurant: a.restaurant, address: a.address, latitude: a.latitude, longitude: a.longitude, permitYear: a.permitYear, tables: allowedTables, opens: a.opens, closes: a.closes, validUntil: min(a.insuranceUntil, yearStart(a.permitYear + 1)) }
  return d
