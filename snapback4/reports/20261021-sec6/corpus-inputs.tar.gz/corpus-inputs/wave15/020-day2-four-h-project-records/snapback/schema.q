use identity
use personas alice, bob, paula, leo, erin

table clubs:
  insert <- viewer = 'service:ops'
  name: text 1..80
  deadline: time
  immutable name, deadline
  public 'Club names and fair entry deadlines are public.'
  online only

table members:
  insert <- viewer = 'service:ops'
  principal: principal
  parent: principal
  club: clubs
  name: text 1..80
  unique principal
  immutable principal, parent, club, name
  read <- (
 .principal = viewer or .parent = viewer or exists leaders[principal = viewer, club = .club]
  ) or viewer = 'service:ops'
  online only

table leaders:
  insert <- viewer = 'service:ops'
  principal: principal
  club: clubs
  unique principal
  immutable principal, club
  read <- (
 .principal = viewer
  ) or viewer = 'service:ops'
  online only

table agents:
  insert <- viewer = 'service:ops'
  principal: principal
  unique principal
  read <- (
 .principal = viewer
  ) or viewer = 'service:ops'
  online only

table books:
  owner: principal
  parent: principal
  club: clubs
  youthName: text 1..80
  animal: text 1..60
  species: enum('Beef', 'Sheep', 'Swine', 'Goat', 'Poultry', 'Rabbit', 'Dairy')
  division: enum('Junior', 'Intermediate', 'Senior') default 'Junior'
  projectYear: int 2020..2100
  fairAt: time
  createdAt: time default now
  approved: bool default false
  comment: text <=2000 default ''
  reviewedBy: principal ?
  reviewedAt: time ?
  immutable owner, parent, club, youthName, animal, species, division, projectYear, fairAt, createdAt
  read <- .owner = viewer or .parent = viewer or exists leaders[principal = viewer, club = .club]
  insert <- .owner = viewer and exists members[principal = viewer, parent = .parent, club = .club]
  update <- exists leaders[principal = viewer, club = .club]
  online only

table entries:
  book: books
  recordedAt: time
  weightLb: int 1..3000
  feedCents: int 0..1000000
  note: text <=500
  photo: image <=5000000 ?
  createdAt: time default now
  immutable book, recordedAt, weightLb, feedCents, note, photo, createdAt
  read through .book
  insert <- .book.owner = viewer
  online only

table fairEntries:
  book: books
  club: clubs
  className: text 1..60
  status: enum('requested', 'approved', 'rejected') default 'requested'
  createdAt: time default now
  decidedBy: principal ?
  decidedAt: time ?
  immutable book, club, className, createdAt
  read through .book
  insert <- .book.owner = viewer
  update <- exists leaders[principal = viewer, club = .club]
  online only

view bookCounts: count books by .club
  read <- exists agents[viewer]
view approvedCounts: count books where .approved = true by .club
  read <- exists agents[viewer]

query context():
  return { principal: viewer, member: members[viewer], leader: leaders[viewer], agent: exists agents[viewer], serverNow: now }
query clubList():
  return clubs first 50 by .id
query recordBooks():
  l = leaders[viewer]
  if l != null:
    return books where .club = l.club first 100 by .id
  if exists members[viewer]:
    return books where .owner = viewer last 100 by .createdAt
  return books where .parent = viewer last 100 by .createdAt
query bookDetail(book: books):
  return books[book]
query bookEntries(book: books):
  return entries where .book = book last 200 by .recordedAt
query fairEntriesFor(book: books):
  return fairEntries where .book = book last 50 by .createdAt
query countySummary():
  return clubs first 50 by .id { id, name, deadline, total: bookCounts[.id], completed: approvedCounts[.id] }

mutation createBook(animal: text 1..60, species: enum('Beef', 'Sheep', 'Swine', 'Goat', 'Poultry', 'Rabbit', 'Dairy'), division: enum('Junior', 'Intermediate', 'Senior'), projectYear: int 2020..2100):
  m = members[viewer] ! else YOUTH_ONLY 'Only an enrolled youth can create a book.'
  c = clubs[m.club] ! else NOT_FOUND
  require now < c.deadline else DEADLINE_PASSED 'Fair entry deadline has passed. Record books are locked.'
  return insert books { owner: viewer, parent: m.parent, club: m.club, youthName: m.name, animal, species, division, projectYear, fairAt: c.deadline }
mutation addEntry(book: books, recordedAt: time, weightLb: int 1..3000, feedCents: int 0..1000000, note: text <=500, photo: image <=5000000 ?):
  b = books[book] ! else NOT_FOUND
  require b.owner = viewer else YOUTH_ONLY 'Only the youth who owns this book can add entries.'
  require now < b.fairAt else DEADLINE_PASSED 'Fair entry deadline has passed. Record books are locked.'
  require not b.approved else SIGNED_OFF 'This book is signed off and locked.'
  require recordedAt <= now and recordedAt >= b.createdAt - 366d else BAD_DATE 'Choose an entry date within the project year, no later than today.'
  return insert entries { book, recordedAt, weightLb, feedCents, note, photo }
mutation reviewBook(book: books, comment: text 1..2000, approved: bool):
  b = books[book] ! else NOT_FOUND
  require exists leaders[principal = viewer, club = b.club] else LEADER_ONLY 'Only this club\'s leader can review the book.'
  require now < b.fairAt else DEADLINE_PASSED 'Fair entry deadline has passed. Record books are locked.'
  if approved:
    require exists entries where .book = book else EMPTY_BOOK 'Add at least one project entry before sign-off.'
  update books[book] { comment, approved, reviewedBy: viewer, reviewedAt: now }
  return books[book]
mutation requestFairEntry(book: books, className: text 1..60):
  b = books[book] ! else NOT_FOUND
  require b.owner = viewer else YOUTH_ONLY 'Only the youth who owns this book can request fair entry.'
  require b.approved else NOT_SIGNED_OFF 'Leader sign-off is required before requesting fair entry.'
  require now < b.fairAt else DEADLINE_PASSED 'Fair entry deadline has passed. Record books are locked.'
  return insert fairEntries { book, club: b.club, className }
mutation decideFairEntry(entry: fairEntries, status: enum('approved', 'rejected')):
  f = fairEntries[entry] ! else NOT_FOUND
  require exists leaders[principal = viewer, club = f.club] else LEADER_ONLY 'Only this club\'s leader can decide fair entries.'
  b = books[f.book] ! else NOT_FOUND
  require now < b.fairAt else DEADLINE_PASSED 'Fair entry deadline has passed. Record books are locked.'
  update fairEntries[entry] { status, decidedBy: viewer, decidedAt: now }
  return fairEntries[entry]

mutation bootstrapagents(seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert agents { principal: seat_principal }

mutation bootstrapleaders(seat_club: clubs, seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert leaders { club: seat_club, principal: seat_principal }

mutation bootstrapmembers(seat_club: clubs, seat_name: text <=80, seat_parent: principal, seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert members { club: seat_club, name: seat_name, parent: seat_parent, principal: seat_principal }

mutation provisionClub(name: text 1..80, deadline: time):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert clubs { name, deadline }
