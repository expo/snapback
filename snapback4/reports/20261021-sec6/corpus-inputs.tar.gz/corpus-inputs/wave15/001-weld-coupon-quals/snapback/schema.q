-- Welder Qualification Coupons.
-- Welders test on practice coupons; a certified inspector (quality manager)
-- grades pass/fail with bend + macro-etch photo URLs. A pass qualifies the
-- welder for that process + position for 180 days, while continuity logs keep
-- it meaningful. The foreman assigns jobs only to currently qualified welders.
-- A nightly job flags qualifications expiring within 30 days.
-- Grades are append-only: the full history is the audit trail.

use personas alice, bob, carol, dave

-- Roster: carol = quality manager (also the certified inspector),
-- dave = shop foreman. alice + bob are welders (no staff row).
table staff:
  principal: principal
  role: enum('quality', 'foreman')
  unique principal
  immutable principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table welders:
  principal: principal
  name: text 2..60
  active: bool default true
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[viewer]
  insert <- .principal = viewer or exists staff[viewer]
  update <- .principal = viewer or exists staff[viewer]
  delete <- deny
  cap 500
  online only

table coupons:
  welder: principal
  process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW')
  position: enum('1G', '2G', '3G', '4G', '5G', '6G')
  material: text 2..60
  preparedAt: time default now
  immutable welder, process, position, material, preparedAt
  read <- .welder = viewer or exists staff[viewer]
  insert <- .welder = viewer or exists staff[viewer]
  update <- deny
  delete <- deny
  cap 1000 by welder
  online only

-- Append-only grade history. One row per grading event; the latest row for a
-- coupon is its current grade and every row is kept for the audit trail.
-- `welder` is copied from the coupon so the read rule needs no probe.
table grades:
  coupon: coupons
  welder: principal
  result: enum('pass', 'fail')
  bendPhotoUrl: text <=500 ?
  macroPhotoUrl: text <=500 ?
  note: text <=500 ?
  gradedBy: principal
  gradedAt: time default now
  immutable coupon, welder, result, gradedBy, gradedAt
  read <- .welder = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'quality']
  update <- deny
  delete <- deny
  cap 200 by coupon
  online only

-- Continuity of work, logged by the welder (or staff on their behalf).
table continuity:
  welder: principal
  process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW')
  note: text <=200 ?
  loggedAt: time default now
  immutable welder, process, loggedAt
  read <- .welder = viewer or exists staff[viewer]
  insert <- .welder = viewer or exists staff[viewer]
  update <- deny
  delete <- deny
  cap 2000 by welder
  online only

-- Current qualification per welder + process + position. Written by the
-- gradeCoupon mutation on a pass (expiresAt = now + 180d); the nightly job
-- sets flagged when expiry is within 30 days.
table qualifications:
  welder: principal
  process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW')
  position: enum('1G', '2G', '3G', '4G', '5G', '6G')
  expiresAt: time
  flagged: bool default false
  unique welder, process, position
  immutable welder, process, position
  read <- .welder = viewer or exists staff[viewer]
  insert <- exists staff[principal = viewer, role = 'quality']
  update <- exists staff[principal = viewer, role = 'quality']
  delete <- deny
  online only

table assignments:
  welder: principal
  process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW')
  position: enum('1G', '2G', '3G', '4G', '5G', '6G')
  title: text 1..120
  assignedBy: principal
  assignedAt: time default now
  immutable welder, process, position, title, assignedBy, assignedAt
  read <- .welder = viewer or exists staff[viewer]
  insert <- exists staff[viewer]
  update <- deny
  delete <- deny
  cap 1000 by welder
  online only

query myCoupons(c: cursor ?):
  return coupons where .welder = viewer last 50 by .id after c

query allCoupons(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Only shop staff may list every coupon.'
  return coupons last 50 by .id after c

query couponDetail(coupon: coupons):
  return coupons[coupon]

query gradeHistory(coupon: coupons, c: cursor ?):
  return grades where .coupon = coupon last 50 by .id after c

query myQualifications(c: cursor ?):
  return qualifications where .welder = viewer last 50 by .id after c

query allQualifications(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Only shop staff may list every qualification.'
  return qualifications last 50 by .id after c

query expiring(c: cursor ?):
  if exists staff[viewer]:
    return qualifications where .flagged last 50 by .id after c
  return qualifications where .welder = viewer and .flagged last 50 by .id after c

query myContinuity(c: cursor ?):
  return continuity where .welder = viewer last 50 by .id after c

query myAssignments(c: cursor ?):
  return assignments where .welder = viewer last 50 by .id after c

query allAssignments(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF 'Only shop staff may list every assignment.'
  return assignments last 50 by .id after c

query auditTrail(c: cursor ?):
  s = staff[viewer] ! else NOT_QUALITY 'Only the quality manager may read the audit trail.'
  require s.role = 'quality' else NOT_QUALITY 'Only the quality manager may read the audit trail.'
  return grades last 50 by .id after c

mutation prepareCoupon(process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW'), position: enum('1G', '2G', '3G', '4G', '5G', '6G'), material: text 2..60):
  return insert coupons { welder: viewer, process, position, material }

mutation gradeCoupon(coupon: coupons, result: enum('pass', 'fail'), bendPhotoUrl: text <=500 ?, macroPhotoUrl: text <=500 ?, note: text <=500 ?):
  cp = coupons[coupon] ! else NOT_FOUND
  s = staff[viewer] ! else NOT_INSPECTOR 'Only a certified inspector (quality) may grade coupons.'
  require s.role = 'quality' else NOT_INSPECTOR 'Only a certified inspector (quality) may grade coupons.'
  g = insert grades { coupon, welder: cp.welder, result, bendPhotoUrl, macroPhotoUrl, note, gradedBy: viewer }
  if result = 'pass':
    upsert qualifications[cp.welder, cp.process, cp.position] { welder: cp.welder, process: cp.process, position: cp.position, expiresAt: now + 180d, flagged: false }
  return g

mutation logContinuity(process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW'), note: text <=200 ?):
  return insert continuity { welder: viewer, process, note }

mutation assignJob(welder: principal, process: enum('SMAW', 'GTAW', 'GMAW', 'FCAW'), position: enum('1G', '2G', '3G', '4G', '5G', '6G'), title: text 1..120):
  s = staff[viewer] ! else NOT_FOREMAN 'Only the foreman (or quality manager) may assign jobs.'
  require s.role = 'foreman' or s.role = 'quality' else NOT_FOREMAN 'Only the foreman (or quality manager) may assign jobs.'
  q = qualifications[welder, process, position]
  require q != null else NO_QUALIFICATION 'This welder holds no qualification for that process and position.'
  require q.expiresAt > now else QUALIFICATION_LAPSED 'That qualification has lapsed; re-test the welder.'
  require exists continuity where .welder = welder and .process = process and .loggedAt > now - 180d else NO_CONTINUITY 'No continuity of work logged for that process in the last 180 days.'
  return insert assignments { welder, process, position, title, assignedBy: viewer }

job flagExpiring():
  for q in qualifications:
    if q.expiresAt <= now + 30d and not q.flagged:
      update qualifications[q.id] { flagged: true }

schedule nightly every 1d at 03:00: flagExpiring
