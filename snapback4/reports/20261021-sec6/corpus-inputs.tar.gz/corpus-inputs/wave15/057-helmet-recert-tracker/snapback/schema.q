-- Helmet Recertification Tracker.
-- Personas: alice = equipment manager, bob = coach, carol = athletic director.
use personas alice, bob, carol

-- Role rosters: one row per person, provisioned outside the app (fixtures/seed).
table managers:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table coaches:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table directors:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table helmets:
  serial: text 3..40
  model: text 1..60
  size: enum('S', 'M', 'L', 'XL')
  mfgYear: int 1990..2100
  lastRecert: time
  unique serial
  read <- exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer]
  insert <- exists managers[principal = viewer]
  update <- exists managers[principal = viewer]
  delete <- exists managers[principal = viewer]
  online only

table reconditionings:
  helmet: helmets
  vendor: text 1..80
  costCents: int 0..1000000
  servicedAt: time
  read <- exists managers[principal = viewer] or exists directors[principal = viewer]
  insert <- exists managers[principal = viewer]
  update <- deny
  delete <- deny
  online only

table assignments:
  helmet: helmets
  player: text 1..80
  assignedAt: time default now
  assignedBy: principal
  active: bool default true
  returnedAt: time ?
  read <- exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer]
  insert <- exists managers[principal = viewer] or exists coaches[principal = viewer]
  update <- exists managers[principal = viewer] or exists coaches[principal = viewer]
  delete <- deny
  online only

-- A helmet is flagged when past the 10-year age limit or more than 365 days
-- since its last recertification. Cleared means neither.
query allHelmets():
  require exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer] else NOT_STAFF 'Staff only.'
  return helmets first 100 by .id

query cleared():
  require exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer] else NOT_STAFF 'Staff only.'
  return helmets where .lastRecert >= now - 365d and .mfgYear >= year(now) - 10 first 100 by .id

query flagged():
  require exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer] else NOT_STAFF 'Staff only.'
  return helmets where .lastRecert < now - 365d or .mfgYear < year(now) - 10 first 100 by .id

query helmetAssignments(helmet: helmets):
  require exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer] else NOT_STAFF 'Staff only.'
  h = helmets[helmet] ! else NOT_FOUND
  return assignments where .helmet = helmet last 50 by .assignedAt

query issueHistory():
  require exists managers[principal = viewer] or exists coaches[principal = viewer] or exists directors[principal = viewer] else NOT_STAFF 'Staff only.'
  return assignments last 100 by .assignedAt

query serviceLog(helmet: helmets):
  require exists managers[principal = viewer] or exists directors[principal = viewer] else COST_PRIVATE 'Reconditioning records are for the manager and director.'
  h = helmets[helmet] ! else NOT_FOUND
  return reconditionings where .helmet = helmet last 50 by .servicedAt

query serviceLogAll():
  require exists managers[principal = viewer] or exists directors[principal = viewer] else COST_PRIVATE 'Reconditioning records are for the manager and director.'
  return reconditionings last 200 by .servicedAt

query costSummary(year: int 2000..2100):
  require exists managers[principal = viewer] or exists directors[principal = viewer] else COST_PRIVATE 'Cost summaries are for the manager and director.'
  total = sum(reconditionings where year(.servicedAt) = year, .costCents)
  n = count(reconditionings where year(.servicedAt) = year)
  return { year, total, n }

mutation addHelmet(serial: text 3..40, model: text 1..60, size: enum('S', 'M', 'L', 'XL'), mfgYear: int 1990..2100, lastRecert: time):
  require exists managers[principal = viewer] else NOT_MANAGER 'Only the equipment manager registers helmets.'
  return insert helmets { serial, model, size, mfgYear, lastRecert }

mutation logReconditioning(helmet: helmets, vendor: text 1..80, costCents: int 0..1000000, servicedAt: time):
  require exists managers[principal = viewer] else NOT_MANAGER 'Only the equipment manager logs reconditioning.'
  h = helmets[helmet] ! else NOT_FOUND
  update helmets[helmet] { lastRecert: servicedAt }
  return insert reconditionings { helmet, vendor, costCents, servicedAt }

mutation assignHelmet(helmet: helmets, player: text 1..80):
  require exists coaches[principal = viewer] or exists managers[principal = viewer] else NOT_AUTHORIZED 'Only coaches or the equipment manager issue helmets.'
  h = helmets[helmet] ! else NOT_FOUND
  require h.lastRecert >= now - 365d else RECERT_OVERDUE 'Helmet is overdue for recertification.'
  require h.mfgYear >= year(now) - 10 else TOO_OLD 'Helmet is past its 10-year age limit.'
  require not exists assignments where .helmet = helmet and .active = true else ALREADY_ISSUED 'Helmet is already issued to a player.'
  return insert assignments { helmet, player, assignedAt: now, assignedBy: viewer }

mutation returnHelmet(assignment: assignments):
  require exists coaches[principal = viewer] or exists managers[principal = viewer] else NOT_AUTHORIZED 'Only coaches or the equipment manager take returns.'
  a = assignments[assignment] ! else NOT_FOUND
  require a.active else ALREADY_RETURNED 'This helmet was already returned.'
  update assignments[assignment] { active: false, returnedAt: now }
  return { id: a.id }
