use personas alice, bob, manager, family, outsider

table staff:
  principal: principal
  role: enum('aide', 'manager')
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table residents:
  name: text 1..80
  family: principal
  read <- .family = viewer or exists staff[viewer]
  insert <- deny
  update <- deny
  delete <- deny
  online only

table schedules:
  resident: residents
  drug: text 1..80
  amount: text 1..40
  highRisk: bool
  dueAt: time
  read <- exists staff[viewer]
  insert <- exists staff[viewer, role = 'manager']
  update <- deny
  delete <- deny
  online only

table statuses:
  schedule: schedules
  resident: residents
  family: principal
  residentName: text 1..80
  dueAt: time
  given: bool default false
  unique schedule
  read <- .family = viewer or exists staff[viewer]
  insert <- exists staff[viewer, role = 'manager'] and .family = .resident.family
  update <- exists staff[viewer]
  delete <- deny
  immutable schedule, resident, family, residentName, dueAt
  online only

table doses:
  schedule: schedules
  aide: principal
  givenAt: time
  unique schedule else ALREADY_RECORDED
  read <- exists staff[viewer]
  insert <- exists staff[viewer] and .aide = viewer
  update <- deny
  delete <- deny
  online only

table cosigns:
  dose: doses
  signer: principal
  signedAt: time
  unique dose else ALREADY_COSIGNED
  read <- exists staff[viewer]
  insert <- exists staff[viewer] and .signer = viewer and .signer != .dose.aide
  update <- deny
  delete <- deny
  online only

table corrections:
  dose: doses
  author: principal
  reason: text 5..240
  given: bool
  at: time
  read <- exists staff[viewer]
  insert <- exists staff[viewer, role = 'manager'] and .author = viewer
  update <- deny
  delete <- deny
  online only

query roster():
  return residents first 100 by .name

query familyStatus():
  return statuses where .family = viewer first 100 by .dueAt { id, residentName, dueAt, given }

query passBoard():
  require exists staff[viewer] else NOT_STAFF
  return schedules first 100 by .dueAt { *, asOf: now, residentName: .resident.name, dose: doses[schedule = .id] { *, cosign: cosigns[dose = .id], corrections: corrections[dose = .id] last 20 by .at }, given: statuses[schedule = .id].given }

query audit():
  require exists staff[viewer] else NOT_STAFF
  return corrections last 100 by .at

query exceptions():
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  return schedules where .dueAt < now - 30m and (statuses[schedule = .id].given != true or (doses[schedule = .id].givenAt ?? 0) > .dueAt + 30m) first 100 by .dueAt { id, residentName: .resident.name, drug, dueAt, missed: statuses[schedule = .id].given != true, late: (doses[schedule = .id].givenAt ?? 0) > .dueAt + 30m }

mutation createSchedule(resident: residents, drug: text 1..80, amount: text 1..40, highRisk: bool, dueAt: time):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  require dueAt >= now - 7d and dueAt <= now + 30d else BAD_SCHEDULE_TIME
  r = residents[resident] ! else NOT_FOUND
  s = insert schedules { resident, drug, amount, highRisk, dueAt }
  insert statuses { schedule: s.id, resident, family: r.family, residentName: r.name, dueAt }
  return s

mutation recordDose(schedule: schedules):
  require exists staff[viewer] else NOT_STAFF
  s = schedules[schedule] ! else NOT_FOUND
  require s.dueAt <= now + 30m else TOO_EARLY
  d = insert doses { schedule, aide: viewer, givenAt: now }
  update statuses[schedule = schedule] { given: true }
  return d

mutation cosign(dose: doses):
  require exists staff[viewer] else NOT_STAFF
  d = doses[dose] ! else NOT_FOUND
  require d.aide != viewer else SELF_COSIGN 'A second staff member must co-sign.'
  require d.schedule.highRisk = true else NOT_HIGH_RISK
  require now >= d.givenAt and now <= d.givenAt + 10m else COSIGN_EXPIRED 'The ten-minute co-sign window has closed.'
  require statuses[schedule = d.schedule].given = true else DOSE_CORRECTED
  return insert cosigns { dose, signer: viewer, signedAt: now }

mutation correctDose(dose: doses, given: bool, reason: text 5..240):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  d = doses[dose] ! else NOT_FOUND
  c = insert corrections { dose, author: viewer, given, reason, at: now }
  update statuses[schedule = d.schedule] { given }
  return c
