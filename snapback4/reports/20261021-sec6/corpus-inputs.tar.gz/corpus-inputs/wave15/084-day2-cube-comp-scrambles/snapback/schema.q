-- Cube Competition Scrambles.
-- Personas (dev cast): alice = delegate (privileged), bob = scrambler + judge,
-- carol = competitor. Competitors need no roster row; their identity is viewer.
use identity
use personas alice, bob, carol

table rounds:
  name: text 1..60
  event: text 1..30
  status: enum('hidden', 'open', 'approved', 'paused')
  pauseReason: text <=200 default ''
  insert <- exists staff[principal = viewer, role = 'delegate']
  update <- exists staff[principal = viewer, role = 'delegate']
  delete <- exists staff[principal = viewer, role = 'delegate']
  public 'The competition schedule is public; scramble and time visibility is enforced per query.'
  cap 50
  sync public

table staff:
  principal: principal
  role: enum('delegate', 'scrambler', 'judge')
  unique principal, role
  read <- .principal = viewer
  insert <- viewer = 'service:ops' or exists staff[principal = viewer, role = 'delegate']
  update <- deny
  delete <- exists staff[principal = viewer, role = 'delegate']
  cap 50
  online only

table scrambles:
  round: rounds on delete cascade
  attempt: int 1..5
  moves: text 1..300
  unique round, attempt
  immutable round, attempt
  by byAttempt: attempt, id
  insert <- exists staff[principal = viewer, role = 'delegate']
  update <- exists staff[principal = viewer, role = 'delegate']
  delete <- exists staff[principal = viewer, role = 'delegate']
  public 'Scramble hiding is enforced in scramblesFor; this table has no other read path.'
  cap 10 by round
  online only

table results:
  round: rounds on delete cascade
  competitor: principal
  attempt: int 1..5
  timeMs: int 1..3600000
  penalty: enum('none', 'plus2', 'dnf')
  judge: principal
  enteredAt: time default now
  unique round, competitor, attempt
  immutable round, competitor, attempt
  by byAttempt: attempt, id
  read <- .competitor = viewer or exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  insert <- exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  update <- exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  delete <- exists staff[principal = viewer, role = 'delegate']
  cap 500 by round
  online only

table published:
  round: rounds on delete cascade
  competitor: principal
  attempt: int 1..5
  timeMs: int 1..3600000
  penalty: enum('none', 'plus2', 'dnf')
  unique round, competitor, attempt
  immutable round, competitor, attempt
  by byAttempt: attempt, id
  insert <- exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  update <- exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  delete <- exists staff[principal = viewer, role = 'delegate']
  public 'The public results page; rows appear only via approveRound after delegate approval.'
  cap 500 by round
  sync public

table corrections:
  result: results on delete cascade
  oldTimeMs: int 1..3600000
  newTimeMs: int 1..3600000
  oldPenalty: enum('none', 'plus2', 'dnf')
  newPenalty: enum('none', 'plus2', 'dnf')
  reason: text <=200
  editor: principal
  at: time default now
  immutable result, oldTimeMs, newTimeMs, oldPenalty, newPenalty, reason, editor, at
  by byAt: at, id
  read <- exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  insert <- exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate']
  update <- deny
  delete <- deny
  cap 100 by result
  online only

query roundsList():
  return rounds first 50 by .id

query scramblesFor(round: rounds):
  r = rounds[round] ! else NOT_FOUND
  if r.status = 'open' or r.status = 'approved':
    return scrambles where .round = round first 20 by byAttempt
  require exists staff[principal = viewer, role = 'scrambler'] or exists staff[principal = viewer, role = 'delegate'] else SCRAMBLES_HIDDEN 'Scrambles are hidden until the delegate opens the round.'
  return scrambles where .round = round first 20 by byAttempt

query myResults(round: rounds):
  return results where .round = round and .competitor = viewer first 20 by byAttempt

query roundResults(round: rounds):
  require exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate'] else NOT_STAFF 'Only judges and the delegate see every time in a round.'
  return results where .round = round first 200 by .id

query publishedResults(round: rounds):
  r = rounds[round] ! else NOT_FOUND
  require r.status = 'approved' else NOT_APPROVED 'The public results page appears after the delegate approves this round.'
  return published where .round = round first 200 by byAttempt

query correctionsFor(result: results):
  require exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate'] else NOT_STAFF 'Only judges and the delegate see the correction log.'
  return corrections where .result = result first 50 by byAt

query whoAmI():
  return viewer

mutation createRound(name: text 1..60, event: text 1..30):
  require exists staff[principal = viewer, role = 'delegate'] else NOT_DELEGATE 'Only the delegate manages rounds.'
  return insert rounds { name, event, status: 'hidden' }

mutation uploadScramble(round: rounds, attempt: int 1..5, moves: text 1..300):
  require exists staff[principal = viewer, role = 'delegate'] else NOT_DELEGATE 'Only the delegate uploads scrambles.'
  rd = rounds[round] ! else NOT_FOUND
  return upsert scrambles[round, attempt] { round, attempt, moves }

mutation openRound(round: rounds):
  require exists staff[principal = viewer, role = 'delegate'] else NOT_DELEGATE 'Only the delegate opens rounds.'
  rd = rounds[round] ! else NOT_FOUND
  require rd.status != 'approved' else ROUND_APPROVED 'An approved round cannot be reopened.'
  update rounds[round] { status: 'open', pauseReason: '' }
  return rounds[round]

mutation enterTime(round: rounds, competitor: principal, attempt: int 1..5, timeMs: int 1..3600000, penalty: enum('none', 'plus2', 'dnf')):
  require exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate'] else NOT_JUDGE 'Only judges and the delegate enter times.'
  rd = rounds[round] ! else NOT_FOUND
  require rd.status != 'approved' else ROUND_APPROVED 'This round is approved; correct times with a reason instead.'
  require rd.status != 'paused' else ROUND_PAUSED 'Time entry is paused; wait for the delegate to resume the round.'
  return upsert results[round, competitor, attempt] { round, competitor, attempt, timeMs, penalty, judge: viewer, enteredAt: now }

mutation approveRound(round: rounds):
  require exists staff[principal = viewer, role = 'delegate'] else NOT_DELEGATE 'Only the delegate approves rounds.'
  rd = rounds[round] ! else NOT_FOUND
  require rd.status != 'paused' else ROUND_PAUSED 'Resume the round before approving results.'
  update rounds[round] { status: 'approved' }
  page = results where .round = round first 500 by .id
  for row in page:
    upsert published[row.round, row.competitor, row.attempt] { round: row.round, competitor: row.competitor, attempt: row.attempt, timeMs: row.timeMs, penalty: row.penalty }
  return rounds[round]

mutation correctResult(result: results, timeMs: int 1..3600000, penalty: enum('none', 'plus2', 'dnf'), reason: text <=200):
  require exists staff[principal = viewer, role = 'judge'] or exists staff[principal = viewer, role = 'delegate'] else NOT_JUDGE 'Only judges and the delegate correct times.'
  r = results[result] ! else NOT_FOUND
  rd = rounds[r.round] ! else NOT_FOUND
  require rd.status != 'approved' or reason != '' else NEEDS_REASON 'Changing an approved time requires a reason.'
  update results[result] { timeMs, penalty, judge: viewer, enteredAt: now }
  if rd.status = 'approved':
    upsert published[r.round, r.competitor, r.attempt] { round: r.round, competitor: r.competitor, attempt: r.attempt, timeMs, penalty }
    insert corrections { result, oldTimeMs: r.timeMs, newTimeMs: timeMs, oldPenalty: r.penalty, newPenalty: penalty, reason, editor: viewer, at: now }
  return results[result]

mutation addStaff(member: principal, role: enum('delegate', 'scrambler', 'judge')):
  require exists staff[principal = viewer, role = 'delegate'] else NOT_DELEGATE 'Only the delegate manages staff.'
  return insert staff { principal: member, role }

-- Only a locally minted operator seat can provision the first delegate.
mutation provisionDelegate(member: principal):
  require viewer = 'service:ops' else NOT_OPERATOR 'Only the competition operator provisions delegates.'
  return insert staff { principal: member, role: 'delegate' }

-- Public explanations survive resume; only a delegate may append one.
table pauseEvents:
  round: rounds on delete cascade
  reason: text 1..200
  delegate: principal
  at: time default now
  immutable round, reason, delegate, at
  by byAt: at, id
  public 'Delegates publish pause explanations for all competition visitors.'
  insert <- exists staff[principal = viewer, role = 'delegate']
  update <- deny
  delete <- deny
  cap 100 by round
  online only

query pausesFor(round: rounds):
  return pauseEvents where .round = round first 100 by byAt

mutation pauseRound(round: rounds, reason: text 1..200):
  require exists staff[principal = viewer, role = 'delegate'] else NOT_DELEGATE 'Only the delegate pauses rounds.'
  require reason != '' else NEEDS_REASON 'Explain the pause to competitors.'
  rd = rounds[round] ! else NOT_FOUND
  require rd.status = 'open' else NOT_OPEN 'Only an open round may be paused.'
  insert pauseEvents { round, reason, delegate: viewer, at: now }
  update rounds[round] { status: 'paused', pauseReason: reason }
  return rounds[round]

query myRoles():
  return staff where .principal = viewer first 50 by .id
