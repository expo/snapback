use personas alice, bob, staff

table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table customers:
  owner: principal
  name: text 1..80
  vehicle: text 1..80
  unique owner
  read <- .owner = viewer or exists staff[viewer]
  online only

table racks:
  label: text 1..12
  unique label
  read <- exists staff[viewer]
  online only

table tires:
  customer: customers
  owner: principal
  rack: racks
  label: text 1..80
  season: enum('winter', 'summer')
  treadTenths: int 0..200
  photo: image <=5000000 ?
  storedAt: time default now
  unique rack else RACK_OCCUPIED
  unique customer
  immutable customer, owner
  read <- .owner = viewer or exists staff[viewer]
  insert <- exists staff[viewer] and exists customers[.customer, owner = .owner]
  update <- exists staff[viewer]
  online only

table appointments:
  customer: customers
  owner: principal
  startsAt: time
  note: text <=160
  status: enum('booked', 'pulled', 'completed', 'cancelled') default 'booked'
  immutable customer, owner, startsAt
  read <- .owner = viewer or exists staff[viewer]
  insert <- (.owner = viewer or exists staff[viewer]) and exists customers[.customer, owner = .owner]
  update <- .owner = viewer or exists staff[viewer]
  online only

table fees:
  customer: customers
  owner: principal
  amountCents: int 1..100000
  description: text 1..100
  paid: bool default false
  immutable customer, owner, amountCents, description
  read <- .owner = viewer or exists staff[viewer]
  insert <- exists staff[viewer] and exists customers[.customer, owner = .owner]
  update <- exists staff[viewer]
  online only

table reminders:
  customer: customers
  owner: principal
  season: enum('winter', 'summer')
  cycle: int 2020..2200
  message: text 1..200
  unique customer, season, cycle
  read <- .owner = viewer or exists staff[viewer]
  insert <- exists staff[viewer] and exists customers[.customer, owner = .owner]
  online only

view occupiedSlots: count appointments where .status != 'cancelled' by .startsAt
  read <- allow

query identity():
  return { principal: viewer, isStaff: exists staff[viewer] }
query customerRecords():
  if exists staff[viewer]:
    return customers first 100 by .id
  return customers where .owner = viewer first 100 by .id
query storedSets():
  if exists staff[viewer]:
    return tires first 100 by .id
  return tires where .owner = viewer first 100 by .id
query swaps():
  if exists staff[viewer]:
    return appointments first 100 by .startsAt
  return appointments where .owner = viewer first 100 by .startsAt
query storageFees():
  if exists staff[viewer]:
    return fees first 100 by .id
  return fees where .owner = viewer first 100 by .id
query seasonReminders():
  if exists staff[viewer]:
    return reminders first 100 by .id
  return reminders where .owner = viewer first 100 by .id
query rackOccupancy():
  require exists staff[viewer] else STAFF_ONLY
  return racks first 100 by .label { id, label, set: tires[rack = .id] }
query nextDaySwaps(date: time):
  require exists staff[viewer] else STAFF_ONLY
  return appointments where .startsAt >= date and .startsAt < date + 1d first 100 by .startsAt

mutation bookSwap(customer: customers, startsAt: time, note: text <=160):
  c = customers[customer] ! else CUSTOMER_PRIVATE
  require startsAt > now and startsAt < now + 180d else INVALID_DATE
  require startsAt % 30m = 0 else HALF_HOUR_SLOT
  require occupiedSlots[startsAt] = 0 else SLOT_TAKEN
  return insert appointments { customer, owner: c.owner, startsAt, note }
mutation cancelSwap(appointment: appointments):
  a = appointments[appointment] ! else APPOINTMENT_PRIVATE
  require a.status = 'booked' else CANNOT_CANCEL
  update appointments[appointment] { status: 'cancelled' }
mutation storeSet(customer: customers, rack: racks, label: text 1..80, season: enum('winter', 'summer'), treadTenths: int 0..200):
  require exists staff[viewer] else STAFF_ONLY
  c = customers[customer] ! else NOT_FOUND
  require exists racks[rack] else RACK_NOT_FOUND
  return insert tires { customer, owner: c.owner, rack, label, season, treadTenths }
mutation recordTread(tire: tires, treadTenths: int 0..200, photo: image <=5000000):
  require exists staff[viewer] else STAFF_ONLY
  update tires[tire] { treadTenths, photo }
mutation pullSet(appointment: appointments):
  require exists staff[viewer] else STAFF_ONLY
  a = appointments[appointment] ! else NOT_FOUND
  require a.status = 'booked' else NOT_BOOKED
  require exists tires[customer = a.customer] else NO_STORED_SET
  update appointments[appointment] { status: 'pulled' }
mutation completeSwap(appointment: appointments, label: text 1..80, season: enum('winter', 'summer'), treadTenths: int 0..200, photo: image <=5000000):
  require exists staff[viewer] else STAFF_ONLY
  a = appointments[appointment] ! else NOT_FOUND
  require a.status = 'pulled' else PULL_FIRST
  t = tires[customer = a.customer] ! else NO_STORED_SET
  update tires[t.id] { label, season, treadTenths, photo, storedAt: now }
  update appointments[appointment] { status: 'completed' }
  return insert fees { customer: a.customer, owner: a.owner, amountCents: 6500, description: 'Seasonal tire storage' }
mutation markPaid(fee: fees):
  require exists staff[viewer] else STAFF_ONLY
  update fees[fee] { paid: true }
mutation sendReminder(customer: customers, season: enum('winter', 'summer'), cycle: int 2020..2200):
  require exists staff[viewer] else STAFF_ONLY
  c = customers[customer] ! else NOT_FOUND
  if not exists reminders[customer, season, cycle]:
    insert reminders { customer, owner: c.owner, season, cycle, message: 'Season change: book your tire swap.' }

-- March and September reminders are in-app, one per customer/season/year.
job seasonalReminders():
  for c in customers:
    if month(now) % 12 = 2 or month(now) % 12 = 8:
      season = 'summer' if month(now) % 12 = 2 else 'winter'
      cycle = 1970 + month(now) / 12
      if not exists reminders[c.id, season, cycle]:
        insert reminders { customer: c.id, owner: c.owner, season, cycle, message: 'Season change: book your tire swap.' }
schedule seasonCheck every 1d at 09:00: seasonalReminders
