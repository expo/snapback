use identity
use personas alice, bob, rider, board

table riders:
  insert <- viewer = 'service:ops'
  principal: principal
  unique principal
  immutable principal
  cap 10
  read <- (
 exists riders[viewer]
  ) or viewer = 'service:ops'
  sync

table directors:
  insert <- viewer = 'service:ops'
  principal: principal
  unique principal
  immutable principal
  cap 12
  read <- (
 .principal = viewer
  ) or viewer = 'service:ops'
  sync to .principal

table shareholders:
  insert <- viewer = 'service:ops'
  principal: principal
  name: text 1..60
  shares: int 1..24
  unique principal
  cap 100
  public 'Company shareholder directory; schedules and deliveries remain private.'
  sync

table turns:
  allocatedTo: principal
  owner: principal
  season: int 2020..2100
  round: int 1..100
  gate: text 1..60
  startsAt: time
  minutes: int 30..720
  state: enum('scheduled', 'delivered', 'cancelled') default 'scheduled'
  cancelReason: text <=140 default 'none'
  unique season, round, allocatedTo
  immutable allocatedTo, season, round, gate, startsAt, minutes
  read <- (
 .owner = viewer or exists riders[viewer]
  ) or viewer = 'service:ops'
  insert <- (
 exists riders[viewer]
  ) or viewer = 'service:ops'
  update <- exists riders[viewer]
  sync

table deliveries:
  turn: turns
  owner: principal
  season: int 2020..2100
  minutes: int 1..1440
  flowLpm: int 1..10000
  litres: int 1..14400000
  note: text <=240
  recordedBy: principal
  at: time
  unique turn
  immutable turn, owner, season, minutes, flowLpm, litres, note, recordedBy, at
  read <- .owner = viewer or exists riders[viewer]
  insert <- exists riders[viewer] and .recordedBy = viewer
  sync

table trades:
  offered: turns
  requested: turns ?
  requester: principal
  recipient: principal
  note: text <=240
  state: enum('proposed', 'accepted', 'approved', 'declined') default 'proposed'
  at: time
  immutable offered, requester, recipient, note, at
  read <- .requester = viewer or .recipient = viewer or exists riders[viewer]
  insert <- .requester = viewer and exists turns[.offered, owner = viewer, state = 'scheduled']
  update <- .requester = viewer or .recipient = viewer or exists riders[viewer]
  sync

table bulletins:
  body: text 1..280
  at: time default now
  postedBy: principal
  cap 200
  public 'Canal notices posted by the ditch rider; schedules and deliveries remain private.'
  insert <- exists riders[viewer] and .postedBy = viewer
  sync

view seasonLitres: sum deliveries of .litres by .season, .owner
  read <- exists directors[viewer] or exists riders[viewer]
  online only
view seasonMinutes: sum deliveries of .minutes by .season, .owner
  read <- exists directors[viewer] or exists riders[viewer]
  online only

query myAccount():
  return shareholders[principal = viewer]
query myRole():
  return { rider: exists riders[viewer], board: exists directors[viewer] }
query directory():
  return shareholders first 100 by .name
query schedule(season: int 2020..2100, c: cursor ?):
  if exists riders[viewer]:
    return turns where .season = season first 50 by .startsAt after c
  return turns where .owner = viewer and .season = season first 50 by .startsAt after c
query turnDetail(turn: turns):
  return turns[turn]
query history(season: int 2020..2100, c: cursor ?):
  if exists riders[viewer]:
    return deliveries where .season = season last 50 by .at after c
  return deliveries where .owner = viewer and .season = season last 50 by .at after c
query tradeInbox(c: cursor ?):
  if exists riders[viewer]:
    return trades last 50 by .at after c
  return trades where .requester = viewer or .recipient = viewer last 50 by .at after c
query bulletins(c: cursor ?):
  return bulletins last 20 by .at after c
query seasonReport(season: int 2020..2100):
  require exists directors[viewer] or exists riders[viewer] else BOARD_ONLY 'Season totals are for the board and ditch rider.'
  return shareholders first 100 by .name { name, principal, shares, litres: seasonLitres[season, .principal], minutes: seasonMinutes[season, .principal] }

mutation allocateTurn(holder: principal, season: int 2020..2100, round: int 1..100, gate: text 1..60, startsAt: time):
  require exists riders[viewer] else RIDER_ONLY 'Only the ditch rider can allocate water turns.'
  member = shareholders[principal = holder] ! else NO_SHAREHOLDER
  return insert turns { allocatedTo: holder, owner: holder, season, round, gate, startsAt, minutes: member.shares * 30 }
mutation logDelivery(turn: turns, minutes: int 1..1440, flowLpm: int 1..10000, note: text <=240) predicts:
  require exists riders[viewer] else RIDER_ONLY 'Only the ditch rider can log deliveries.'
  t = turns[turn] ! else NOT_FOUND
  require t.state != 'cancelled' else TURN_CANCELLED 'This turn was cancelled; log a new allocation instead.'
  require t.state = 'scheduled' else ALREADY_DELIVERED 'This turn already has a delivery.'
  delivery = insert deliveries { turn, owner: t.owner, season: t.season, minutes, flowLpm, litres: minutes * flowLpm, note, recordedBy: viewer, at: now }
  update turns[turn] { state: 'delivered' }
  return delivery
mutation proposeTrade(turn: turns, recipient: principal, note: text <=240):
  t = turns[turn] ! else NOT_FOUND
  require t.owner = viewer else NOT_OWNER
  require t.state = 'scheduled' else TURN_CLOSED
  require recipient != viewer else SAME_OWNER
  member = shareholders[principal = recipient] ! else NO_SHAREHOLDER
  return insert trades { offered: turn, requester: viewer, recipient: member.principal, note, at: now }
mutation acceptTrade(trade: trades, turn: turns):
  request = trades[trade] ! else NOT_FOUND
  require request.recipient = viewer else RECIPIENT_ONLY
  require request.state = 'proposed' else TRADE_CLOSED
  t = turns[turn] ! else NOT_FOUND
  require t.owner = viewer else NOT_OWNER
  require t.state = 'scheduled' else TURN_CLOSED
  update trades[trade] { requested: turn, state: 'accepted' }
  return null
mutation decideTrade(trade: trades, approve: bool):
  require exists riders[viewer] else RIDER_ONLY 'Only the ditch rider can approve swaps.'
  request = trades[trade] ! else NOT_FOUND
  require request.state = 'accepted' else TRADE_NOT_ACCEPTED
  if approve:
    a = turns[request.offered] ! else NOT_FOUND
    b = turns[request.requested] ! else NOT_FOUND
    require a.owner = request.requester and b.owner = request.recipient else OWNERSHIP_CHANGED
    require a.state = 'scheduled' and b.state = 'scheduled' else TURN_CLOSED
    require a.season = b.season else SEASON_MISMATCH
    update turns[a] { owner: request.recipient }
    update turns[b] { owner: request.requester }
    update trades[trade] { state: 'approved' }
  else:
    update trades[trade] { state: 'declined' }
  return null
mutation declineTrade(trade: trades):
  request = trades[trade] ! else NOT_FOUND
  require request.requester = viewer or request.recipient = viewer else PARTY_ONLY
  require request.state = 'proposed' or request.state = 'accepted' else TRADE_CLOSED
  update trades[trade] { state: 'declined' }
  return null
mutation cancelTurn(turn: turns, reason: text 1..140):
  require exists riders[viewer] else RIDER_ONLY 'Only the ditch rider can cancel water turns.'
  t = turns[turn] ! else NOT_FOUND
  require t.state = 'scheduled' else TURN_CLOSED 'Only a scheduled turn can be cancelled.'
  update turns[turn] { state: 'cancelled', cancelReason: reason }
  return null
mutation postBulletin(body: text 1..280):
  require exists riders[viewer] else RIDER_ONLY 'Only the ditch rider can post canal notices.'
  return insert bulletins { body, at: now, postedBy: viewer }

mutation bootstrapdirectors(seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert directors { principal: seat_principal }

mutation bootstrapriders(seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert riders { principal: seat_principal }

mutation bootstrapshareholders(seat_name: text <=60, seat_principal: principal, seat_shares: int 1..24):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert shareholders { name: seat_name, principal: seat_principal, shares: seat_shares }

mutation bootstrapturns(seat_allocatedTo: principal, seat_gate: text <=60, seat_minutes: int 30..720, seat_owner: principal, seat_round: int 1..100, seat_season: int 2020..2100, seat_startsAt: time):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert turns { allocatedTo: seat_allocatedTo, gate: seat_gate, minutes: seat_minutes, owner: seat_owner, round: seat_round, season: seat_season, startsAt: seat_startsAt }
