use identity
-- Tour Stop Headcount — backend schema (Quarry)
--
-- Personas: alice = tour guide, bob = passenger, carol = tour office (privileged).
-- Story: a guide counts passengers at each stop of a multi-day coach tour
-- (counts sync to the guide's device for poor signal), a missing passenger at
-- departure becomes an alert row for the guide + office, passengers check in
-- with the tour code and see only their own itinerary, the office sees counts
-- for every active tour, and passenger rows (incl. contact details) expire
-- automatically a month after the tour ends.

use personas alice, bob, carol

-- Roster: one row per staff member. Seeded via fixtures (/seed); the office
-- grants further roles at runtime through addStaff.
table staff:
  principal: principal
  role: enum('guide', 'office')
  unique principal
  read <- (
 .principal = viewer or exists staff[viewer, role = 'office']
  ) or viewer = 'service:ops'
  insert <- (
 exists staff[viewer, role = 'office']
  ) or viewer = 'service:ops'
  update <- exists staff[viewer, role = 'office']
  delete <- exists staff[viewer, role = 'office']
  online only

table tours:
  guide: principal
  name: text 1..80
  code: text 4..12
  startsAt: time
  endsAt: time
  active: bool default true
  unique code
  immutable guide
  read <- .guide = viewer or exists staff[viewer, role = 'office'] or exists passengers[tour = .id, principal = viewer]
  insert <- exists staff[viewer, role = 'office']
  update <- .guide = viewer or exists staff[viewer, role = 'office']
  delete <- exists staff[viewer, role = 'office']
  cap 200
  online only

table stops:
  tour: tours on delete cascade
  guide: principal
  name: text 1..80
  departsAt: time
  seq: int 1..1000
  immutable tour, guide
  read <- .guide = viewer or exists staff[viewer] or exists passengers[tour = .tour, principal = viewer]
  insert <- .guide = viewer or exists staff[viewer, role = 'office']
  update <- .guide = viewer or exists staff[viewer, role = 'office']
  delete <- .guide = viewer or exists staff[viewer, role = 'office']
  cap 100 by tour
  online only

-- Passenger rows expire (and are physically deleted) at purgeAt, which the
-- addPassenger mutation sets to tour end + 30 days. Contact details die
-- with the row; check-ins/alerts keep only an opaque principal, so no
-- reference blocks the sweep.
table passengers:
  tour: tours on delete cascade
  guide: principal
  principal: principal
  name: text 1..80
  contact: text 5..120
  purgeAt: time
  unique tour, principal
  immutable tour, guide, principal
  read <- .principal = viewer or .guide = viewer or exists staff[viewer, role = 'office']
  insert <- .guide = viewer or exists staff[viewer, role = 'office']
  update <- .guide = viewer or exists staff[viewer, role = 'office']
  delete <- .guide = viewer or exists staff[viewer, role = 'office']
  expire at .purgeAt
  cap 60 by tour
  online only

-- The offline table: the guide's counts replicate to their device
-- (owner-or-staff union with a bare sync, per the cheatsheet requests shape).
table counts:
  stop: stops on delete cascade
  tour: tours on delete restrict
  countedBy: principal
  expected: int 0..1000
  present: int 0..1000
  method: enum('visual', 'manifest') default 'visual'
  at: time default now
  immutable stop, tour, countedBy
  read <- .countedBy = viewer or exists staff[viewer]
  insert <- .countedBy = viewer
  update <- .countedBy = viewer
  delete <- .countedBy = viewer or exists staff[viewer, role = 'office']
  cap 200 by stop
  sync

table checkins:
  stop: stops on delete cascade
  tour: tours on delete restrict
  principal: principal
  at: time default now
  immutable stop, tour, principal
  unique stop, principal
  read <- .principal = viewer or exists staff[viewer]
  insert <- .principal = viewer
  delete <- .principal = viewer
  cap 60 by stop
  online only

-- Missing-at-departure alerts, readable by any staff (guide + office).
table alerts:
  stop: stops on delete cascade
  tour: tours on delete restrict
  principal: principal
  message: text 1..280
  at: time default now
  seen: bool default false
  unique stop, principal
  immutable stop, tour, principal
  read <- (
 exists staff[viewer]
  ) or viewer = 'service:ops'
  insert <- (
 exists staff[viewer]
  ) or viewer = 'service:ops'
  update <- exists staff[viewer]
  cap 60 by stop
  online only

-- Office sign-off on a recorded headcount: which count was checked, who
-- verified it, and when. One row per (count, verifier).
table verifications:
  count: counts on delete cascade
  tour: tours on delete restrict
  verifiedBy: principal
  at: time default now
  unique count, verifiedBy
  immutable count, tour, verifiedBy
  read <- exists staff[viewer]
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  cap 10 by count
  online only

-- The office sees every tour; guides/passengers see their own rows through
-- the table rules (hidden rows read as empty, still complete).
query activeTours(c: cursor ?):
  return tours where .active = true last 50 by .id after c

query myTours(c: cursor ?):
  return tours where .guide = viewer last 50 by .id after c

query allTours(c: cursor ?):
  require exists staff[viewer, role = 'office'] else NOT_OFFICE
  return tours last 50 by .id after c

query itinerary(tour: tours, c: cursor ?):
  return stops where .tour = tour first 50 by .seq after c

query tourCounts(tour: tours, c: cursor ?):
  return counts where .tour = tour last 50 by .at after c

query stopCounts(stop: stops, c: cursor ?):
  return counts where .stop = stop last 50 by .at after c

query roster(stop: stops):
  s = stops[stop] ! else NOT_FOUND
  return passengers where .tour = s.tour first 100 by .id

query stopCheckins(stop: stops):
  s = stops[stop] ! else NOT_FOUND
  return checkins where .stop = stop first 100 by .id

query stopAlerts(stop: stops):
  s = stops[stop] ! else NOT_FOUND
  return alerts where .stop = stop first 100 by .id

query myCheckins(c: cursor ?):
  return checkins where .principal = viewer last 50 by .id after c

query countVerifications(count: counts):
  c = counts[count] ! else NOT_FOUND
  return verifications where .count = count first 50 by .id

query myStaff():
  return staff where .principal = viewer first 5 by .id

mutation createTour(guide: principal, name: text 1..80, code: text 4..12, startsAt: time, endsAt: time):
  require exists staff[viewer, role = 'office'] else NOT_OFFICE
  require endsAt > startsAt else BAD_DATES
  return insert tours { guide, name, code, startsAt, endsAt, active: true }

mutation addStop(tour: tours, name: text 1..80, departsAt: time, seq: int 1..1000):
  t = tours[tour] ! else NOT_FOUND
  require t.guide = viewer or exists staff[viewer, role = 'office'] else NOT_GUIDE
  return insert stops { tour, guide: t.guide, name, departsAt, seq }

mutation addPassenger(tour: tours, who: principal, name: text 1..80, contact: text 5..120):
  t = tours[tour] ! else NOT_FOUND
  require t.guide = viewer or exists staff[viewer, role = 'office'] else NOT_GUIDE
  return insert passengers { tour, guide: t.guide, principal: who, name, contact, purgeAt: t.endsAt + 30d }

mutation checkIn(stop: stops, code: text 4..12):
  s = stops[stop] ! else NOT_FOUND
  t = tours[s.tour] ! else NOT_FOUND
  require t.code = code else BAD_CODE
  require exists passengers[tour = s.tour, principal = viewer] else NOT_ON_TOUR
  return insert checkins { stop, tour: s.tour, principal: viewer }

mutation recordCount(stop: stops, expected: int 0..1000, present: int 0..1000, method: enum('visual', 'manifest') ?):
  s = stops[stop] ! else NOT_FOUND
  require s.guide = viewer or exists staff[viewer, role = 'office'] else NOT_GUIDE
  require present <= expected else BAD_COUNT
  return insert counts { stop, tour: s.tour, countedBy: viewer, expected, present, method: method ?? 'visual' }

mutation verifyCount(count: counts):
  c = counts[count] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  return insert verifications { count, tour: c.tour, verifiedBy: viewer }

mutation flagMissing(stop: stops, who: principal, note: text 1..280 ?):
  s = stops[stop] ! else NOT_FOUND
  require s.guide = viewer or exists staff[viewer, role = 'office'] else NOT_GUIDE
  require exists passengers[tour = s.tour, principal = who] else NOT_ON_TOUR
  require not exists checkins[stop = stop, principal = who] else ALREADY_CHECKED_IN
  return insert alerts { stop, tour: s.tour, principal: who, message: note ?? 'Missing at departure' }

mutation ackAlert(alert: alerts):
  a = alerts[alert] ! else NOT_FOUND
  require exists staff[viewer] else NOT_STAFF
  update alerts[alert] { seen: true }
  return null

mutation addStaff(who: principal, role: enum('guide', 'office')):
  require exists staff[viewer, role = 'office'] else NOT_OFFICE
  return upsert staff[who] { principal: who, role }

mutation withdrawPassenger(tour: tours, who: principal):
  t = tours[tour] ! else NOT_FOUND
  require t.guide = viewer or exists staff[viewer, role = 'office'] else NOT_GUIDE
  require exists passengers[tour = tour, principal = who] else NOT_ON_TOUR
  delete passengers[tour = tour, principal = who]
  return null

mutation bootstrapalerts(seat_message: text <=280, seat_principal: principal, seat_stop: stops, seat_tour: tours):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert alerts { message: seat_message, principal: seat_principal, stop: seat_stop, tour: seat_tour }

mutation bootstrapstaff(seat_principal: principal, seat_role: enum('guide', 'office')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal: seat_principal, role: seat_role }
