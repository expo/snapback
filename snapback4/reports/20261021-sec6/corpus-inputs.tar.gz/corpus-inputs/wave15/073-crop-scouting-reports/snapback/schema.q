-- Crop Scouting Reports.
-- Personas: alice + bob are farmers (each sees only their own farms);
-- carol is the agronomist (reads every client's fields, records spots offline);
-- coop is the co-op office (region pest aggregates only, no names/locations).
use personas alice, bob, carol, coop

-- Rosters are seeded (fixtures / /dev/reset); no insert rule by design.
table agronomists:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table coopStaff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table farms:
  owner: principal
  name: text 1..80
  region: text 1..40
  immutable owner
  read <- .owner = viewer or exists agronomists[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  delete <- .owner = viewer
  cap 200
  sync

table fields:
  farm: farms
  owner: principal
  region: text 1..40
  name: text 1..80
  crop: text 1..40
  acres: int 1..100000
  immutable farm, owner, region
  read <- .owner = viewer or exists agronomists[viewer]
  insert <- .owner = viewer and exists farms[.farm, owner = .owner]
  update <- .owner = viewer
  delete <- .owner = viewer
  cap 1000
  sync

table spots:
  field: fields
  owner: principal
  region: text 1..40
  scout: principal
  growthStage: enum('emerged', 'vegetative', 'flowering', 'grain-fill', 'mature')
  pest: text 1..40
  pestCount: int 0..100000
  notes: text <=500 ?
  lat: decimal 6
  lon: decimal 6
  photo: image <=8000000 ?
  at: time default now
  immutable field, owner, region, scout
  read <- .owner = viewer or exists agronomists[viewer]
  insert <- exists agronomists[viewer] and exists fields[.field, owner = .owner]
  update <- exists agronomists[viewer]
  cap 10000
  sync

table recommendations:
  spot: spots
  owner: principal
  region: text 1..40
  author: principal
  text: text 1..500
  product: text 1..80 ?
  approved: bool default false
  at: time default now
  immutable spot, owner, region, author
  read <- .owner = viewer or exists agronomists[viewer]
  insert <- exists agronomists[viewer] and exists spots[.spot, owner = .owner]
  update <- .owner = viewer or exists agronomists[viewer]
  cap 5000
  sync

-- Co-op aggregates: counts and total insects per (region, pest).
-- Group keys carry no farm/field names and no coordinates.
view spotReports: count spots by .region, .pest
  read <- exists coopStaff[viewer]
  online only

view bugsTotal: sum spots of .pestCount by .region, .pest
  read <- exists coopStaff[viewer]
  online only

query myFarms(c: cursor ?):
  if exists agronomists[viewer]:
    return farms last 50 by .id after c
  return farms where .owner = viewer last 50 by .id after c

query fieldsOf(farm: farms, c: cursor ?):
  f = farms[farm] ! else NOT_FOUND
  return fields where .farm = farm last 100 by .id after c

query spotsOf(field: fields, c: cursor ?):
  f = fields[field] ! else NOT_FOUND
  return spots where .field = field last 100 by .at, .id after c

query recsOf(spot: spots, c: cursor ?):
  s = spots[spot] ! else NOT_FOUND
  return recommendations where .spot = spot last 50 by .at, .id after c

query pressureReports(region: text 1..40, c: cursor ?):
  require exists coopStaff[viewer] else NOT_COOP 'Regional pest pressure is co-op only.'
  return spotReports where .region = region last 100 by .pest after c

query pressureBugs(region: text 1..40, c: cursor ?):
  require exists coopStaff[viewer] else NOT_COOP 'Regional pest pressure is co-op only.'
  return bugsTotal where .region = region last 100 by .pest after c

mutation addFarm(name: text 1..80, region: text 1..40):
  return insert farms { owner: viewer, name, region }

mutation addField(farm: farms, name: text 1..80, crop: text 1..40, acres: int 1..100000):
  f = farms[farm] ! else NOT_FOUND
  require f.owner = viewer else NOT_YOUR_FARM 'Only the farm owner adds fields.'
  return insert fields { farm: f.id, owner: viewer, region: f.region, name, crop, acres }

mutation addSpot(field: fields, growthStage: enum('emerged', 'vegetative', 'flowering', 'grain-fill', 'mature'), pest: text 1..40, pestCount: int 0..100000, notes: text <=500 ?, lat: decimal 6, lon: decimal 6, photo: image <=8000000 ?):
  require exists agronomists[viewer] else NOT_AGRONOMIST 'Only an agronomist records scouting spots.'
  f = fields[field] ! else NOT_FOUND
  return insert spots { field: f.id, owner: f.owner, region: f.region, scout: viewer, growthStage, pest, pestCount, notes, lat, lon, photo, at: now }

mutation updateSpotCount(spot: spots, pestCount: int 0..100000):
  require exists agronomists[viewer] else NOT_AGRONOMIST 'Only an agronomist corrects counts.'
  s = spots[spot] ! else NOT_FOUND
  update spots[s] { pestCount }
  return null

mutation proposeRec(spot: spots, text: text 1..500, product: text 1..80 ?):
  require exists agronomists[viewer] else NOT_AGRONOMIST 'Only an agronomist proposes treatments.'
  s = spots[spot] ! else NOT_FOUND
  return insert recommendations { spot: s.id, owner: s.owner, region: s.region, author: viewer, text, product, approved: false, at: now }

mutation decideRec(rec: recommendations, approved: bool):
  r = recommendations[rec] ! else NOT_FOUND
  require r.owner = viewer else NOT_YOURS 'Only the farm owner approves spraying.'
  update recommendations[r] { approved }
  return null
