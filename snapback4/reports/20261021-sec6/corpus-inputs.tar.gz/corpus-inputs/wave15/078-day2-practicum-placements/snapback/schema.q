use identity
-- Tables: schools, staff, coordinators, candidates, evaluations, visits.
-- v2: candidates gain a required term (backfilled 'Fall 2026') and a
-- 'withdrawn' status; visits log supervisor/mentor classroom observations.
-- Personas: alice (coordinator Maple), bob (coordinator Oak), carol (director),
--            dave (mentor), erin (supervisor), frank (candidate).
use personas alice, bob, carol, dave, erin, frank

table schools:
  name: text 1..80
  unique name else DUPLICATE_SCHOOL
  public 'school directory is public'
  insert <- exists staff[principal = viewer, role = 'director']
  online only

table staff:
  principal: principal
  role: enum('director', 'coordinator', 'mentor', 'supervisor')
  unique principal
  read <- (
 .principal = viewer or exists staff[principal = viewer, role = 'director']
  ) or viewer = 'service:ops'
  insert <- (
 exists staff[principal = viewer, role = 'director']
  ) or viewer = 'service:ops'
  update <- exists staff[principal = viewer, role = 'director']
  delete <- exists staff[principal = viewer, role = 'director']
  online only

table coordinators:
  school: schools on delete cascade
  principal: principal
  unique school, principal
  read <- (
 .principal = viewer or exists staff[principal = viewer, role = 'director']
  ) or viewer = 'service:ops'
  insert <- (
 exists staff[principal = viewer, role = 'director']
  ) or viewer = 'service:ops'
  delete <- exists staff[principal = viewer, role = 'director']
  online only

table candidates:
  principal: principal
  name: text 1..80
  subject: text 1..80
  proposedSchool: schools ?
  status: enum('proposed', 'accepted', 'declined', 'withdrawn') default 'proposed'
  term: text 1..40 default 'Fall 2026'
  immutable principal
  read <- .principal = viewer or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'mentor'] or exists staff[principal = viewer, role = 'supervisor'] or exists coordinators[school = .proposedSchool, principal = viewer]
  insert <- exists staff[principal = viewer, role = 'director']
  update (old, next) <- exists staff[principal = viewer, role = 'director'] or exists coordinators[school = old.proposedSchool, principal = viewer]
  online only

table evaluations:
  candidate: candidates on delete cascade
  author: principal
  role: enum('mentor', 'supervisor')
  kind: enum('midterm', 'final')
  score: int 1..5
  comments: text 1..2000
  unique candidate, role, kind
  immutable candidate, author, role, kind
  read <- .author = viewer or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'mentor'] or exists staff[principal = viewer, role = 'supervisor'] or (exists candidates[.candidate, principal = viewer] and exists evaluations[candidate = .candidate, role = 'mentor', kind = .kind] and exists evaluations[candidate = .candidate, role = 'supervisor', kind = .kind])
  insert <- .author = viewer and exists staff[principal = viewer, role = .role]
  update <- .author = viewer
  online only

table visits:
  candidate: candidates on delete cascade
  author: principal
  note: text 1..500
  status: enum('scheduled', 'completed') default 'scheduled'
  immutable candidate, author
  read <- .author = viewer or exists staff[principal = viewer, role = 'director'] or exists staff[principal = viewer, role = 'mentor'] or exists staff[principal = viewer, role = 'supervisor'] or exists candidates[.candidate, principal = viewer]
  insert <- .author = viewer and (exists staff[principal = viewer, role = 'mentor'] or exists staff[principal = viewer, role = 'supervisor'])
  update <- .author = viewer or exists staff[principal = viewer, role = 'director']
  online only

view placedCount: count candidates where .status = 'accepted' by .proposedSchool
  read <- exists staff[principal = viewer, role = 'director']
  online only

query schoolsList(c: cursor ?):
  return schools first 50 by .id after c

query proposals(school: schools, c: cursor ?):
  return candidates where .proposedSchool = school first 50 by .id after c

query myCandidacy(c: cursor ?):
  return candidates where .principal = viewer first 50 by .id after c

query evalsFor(candidate: candidates, c: cursor ?):
  return evaluations where .candidate = candidate first 50 by .id after c

query placementCount(school: schools):
  return { count: placedCount[school] }

query unplaced(c: cursor ?):
  return candidates where .proposedSchool = null first 50 by .id after c

query visitsFor(candidate: candidates, c: cursor ?):
  return visits where .candidate = candidate first 50 by .id after c

mutation addSchool(name: text 1..80):
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  return insert schools { name }

mutation proposeCandidate(who: principal, name: text 1..80, subject: text 1..80, school: schools ?, term: text 1..40 ?):
  require exists staff[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  if school != null:
    require exists schools[school] else NOT_FOUND
  return insert candidates { principal: who, name, subject, proposedSchool: school, term: term ?? 'Fall 2026' }

mutation decideCandidate(candidate: candidates, decision: enum('accepted', 'declined', 'withdrawn')):
  c = candidates[candidate] ! else NOT_FOUND
  require exists coordinators[c.proposedSchool, viewer] or exists staff[principal = viewer, role = 'director'] else NOT_COORDINATOR
  require c.status = 'proposed' else ALREADY_DECIDED
  update candidates[candidate] { status: decision }
  return null

mutation submitEvaluation(candidate: candidates, kind: enum('midterm', 'final'), score: int 1..5, comments: text 1..2000):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'mentor' or s.role = 'supervisor' else NOT_EVALUATOR
  require exists candidates[candidate] else NOT_FOUND
  if s.role = 'mentor':
    upsert evaluations[candidate = candidate, role = 'mentor', kind = kind] { candidate, author: viewer, role: 'mentor', kind, score, comments }
  else:
    upsert evaluations[candidate = candidate, role = 'supervisor', kind = kind] { candidate, author: viewer, role: 'supervisor', kind, score, comments }
  return null

mutation logVisit(candidate: candidates, note: text 1..500):
  require exists staff[principal = viewer, role = 'mentor'] or exists staff[principal = viewer, role = 'supervisor'] else NOT_EVALUATOR
  require exists candidates[candidate] else NOT_FOUND
  return insert visits { candidate, author: viewer, note }

mutation completeVisit(visit: visits):
  v = visits[visit] ! else NOT_FOUND
  require v.author = viewer or exists staff[principal = viewer, role = 'director'] else NOT_AUTHOR
  require v.status = 'scheduled' else ALREADY_DONE
  update visits[visit] { status: 'completed' }
  return null

mutation bootstrapcoordinators(seat_principal: principal, seat_school: schools):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert coordinators { principal: seat_principal, school: seat_school }

mutation bootstrapstaff(seat_principal: principal, seat_role: enum('director', 'coordinator', 'mentor', 'supervisor')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal: seat_principal, role: seat_role }
