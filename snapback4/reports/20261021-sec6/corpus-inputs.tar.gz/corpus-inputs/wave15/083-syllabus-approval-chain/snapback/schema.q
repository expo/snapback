use personas alice, bob, chair, committee, visitor
use identity guests

table roles:
  person: principal
  role: enum('instructor', 'chair', 'committee')
  unique person
  read <- .person = viewer
  online only

table syllabi:
  owner: principal
  course: text 3..20
  title: text 3..120
  term: text 3..40
  dueAt: time
  startsAt: time
  overview: text <=6000 default ''
  outcomes: text <=6000 default ''
  assessment: text <=6000 default ''
  policies: text <=6000 default ''
  stage: enum('draft', 'chair', 'committee', 'approved') default 'draft'
  revision: int 1.. default 1
  approvedRevision: int 0.. default 0
  updatedAt: time default now
  unique owner, course, term
  immutable owner, course, term, dueAt, startsAt
  read <- .owner = viewer or exists roles[viewer, role = 'chair'] or exists roles[viewer, role = 'committee']
  insert <- .owner = viewer and exists roles[viewer, role = 'instructor']
  update <- .owner = viewer or exists roles[viewer, role = 'chair'] or exists roles[viewer, role = 'committee']
  online only

table comments:
  syllabus: syllabi on delete cascade
  author: principal
  section: enum('overview', 'outcomes', 'assessment', 'policies')
  body: text 1..2000
  at: time default now
  immutable syllabus, author, section, body, at
  read through .syllabus
  insert <- .author = viewer and (exists roles[viewer, role = 'chair'] or exists roles[viewer, role = 'committee'])
  online only

table publications:
  syllabus: syllabi
  course: text 3..20
  title: text 3..120
  term: text 3..40
  startsAt: time
  overview: text 1..6000
  outcomes: text 1..6000
  assessment: text 1..6000
  policies: text 1..6000
  revision: int 1..
  active: bool default true
  unique syllabus
  -- Public current snapshots are hidden until term start.
  read <- .active = true
  not before .startsAt
  insert <- exists roles[viewer, role = 'committee']
  update <- exists roles[viewer, role = 'committee'] or exists syllabi[.syllabus, owner = viewer]
  online only

query workspace():
  if exists roles[viewer, role = 'chair'] or exists roles[viewer, role = 'committee']:
    return syllabi first 100 by .dueAt
  return syllabi where .owner = viewer first 100 by .dueAt

query myRole():
  return roles[viewer]

query detail(syllabus: syllabi):
  return syllabi[syllabus]

query sectionComments(syllabus: syllabi):
  return comments where .syllabus = syllabus first 100 by .at

query checklist(syllabus: syllabi):
  s = syllabi[syllabus] ! else NOT_FOUND
  return { overview: s.overview != '', outcomes: s.outcomes != '', assessment: s.assessment != '', policies: s.policies != '', changed: s.approvedRevision > 0 and s.revision != s.approvedRevision, late: now > s.dueAt and s.stage != 'approved' }

query catalog():
  return publications where .active = true first 100 by .course

mutation createSyllabus(course: text 3..20, title: text 3..120, term: text 3..40, dueAt: time, startsAt: time):
  require exists roles[viewer, role = 'instructor'] else INSTRUCTOR_ONLY
  require dueAt <= startsAt else BAD_DATES 'Submission deadline must be on or before term starts.'
  return insert syllabi { owner: viewer, course, title, term, dueAt, startsAt }

mutation saveSections(syllabus: syllabi, overview: text <=6000, outcomes: text <=6000, assessment: text <=6000, policies: text <=6000):
  s = syllabi[syllabus] ! else NOT_FOUND
  require s.owner = viewer else OWNER_ONLY
  if s.approvedRevision > 0:
    update publications[syllabus] { active: false }
  update syllabi[syllabus] { overview, outcomes, assessment, policies, stage: 'draft', revision: s.revision + 1, updatedAt: now }

mutation submit(syllabus: syllabi):
  s = syllabi[syllabus] ! else NOT_FOUND
  require s.owner = viewer else OWNER_ONLY
  require s.stage = 'draft' else WRONG_STAGE
  require s.overview != '' and s.outcomes != '' and s.assessment != '' and s.policies != '' else MISSING_SECTIONS 'Complete all four required sections before submitting.'
  update syllabi[syllabus] { stage: 'chair', updatedAt: now }

mutation chairDecision(syllabus: syllabi, approve: bool):
  require exists roles[viewer, role = 'chair'] else CHAIR_ONLY
  s = syllabi[syllabus] ! else NOT_FOUND
  require s.stage = 'chair' else WRONG_STAGE
  update syllabi[syllabus] { stage: 'committee' if approve else 'draft', updatedAt: now }

mutation committeeDecision(syllabus: syllabi, approve: bool):
  require exists roles[viewer, role = 'committee'] else COMMITTEE_ONLY
  s = syllabi[syllabus] ! else NOT_FOUND
  require s.stage = 'committee' else WRONG_STAGE
  if approve:
    upsert publications[syllabus] { syllabus, course: s.course, title: s.title, term: s.term, startsAt: s.startsAt, overview: s.overview, outcomes: s.outcomes, assessment: s.assessment, policies: s.policies, revision: s.revision, active: true }
    update syllabi[syllabus] { stage: 'approved', approvedRevision: s.revision, updatedAt: now }
  else:
    update syllabi[syllabus] { stage: 'draft', updatedAt: now }

mutation comment(syllabus: syllabi, section: enum('overview', 'outcomes', 'assessment', 'policies'), body: text 1..2000):
  require exists roles[viewer, role = 'chair'] or exists roles[viewer, role = 'committee'] else APPROVER_ONLY
  s = syllabi[syllabus] ! else NOT_FOUND
  return insert comments { syllabus, author: viewer, section, body }
