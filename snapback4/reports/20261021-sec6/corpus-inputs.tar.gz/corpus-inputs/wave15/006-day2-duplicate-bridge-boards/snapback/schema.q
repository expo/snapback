use identity
use personas alice, bob, director, visitor

-- Roles and session setup are provisioned by the club, not member-editable.
-- In production the operator seat (service:ops) enrolls the first director;
-- directors then run session setup through the mutations below. Guests may
-- read the public results page; only signed-in accounts write.
table directors:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or exists directors[viewer]
  online only

table sessions:
  title: text 1..100
  year: int 2020..2100
  status: enum('open', 'closed')
  appeals: enum('allowed', 'barred') default 'allowed'
  public 'session schedule and publication status'
  insert <- viewer = 'service:ops' or exists directors[viewer]
  update <- exists directors[viewer]
  online only

table pairs:
  name: text 1..80
  member: principal ?
  public 'pair names on the club results sheet'
  insert <- viewer = 'service:ops' or exists directors[viewer]
  online only

table tables:
  session: sessions
  number: int 1..20
  scorer: principal
  ns: pairs
  ew: pairs
  unique session, number
  unique session, scorer
  cap 20 by session
  public 'table assignments contain no hands or scores'
  insert <- viewer = 'service:ops' or exists directors[viewer]
  online only

table boards:
  session: sessions
  number: int 1..36
  dealer: enum('N', 'E', 'S', 'W')
  vulnerability: enum('None', 'NS', 'EW', 'Both')
  unique session, number
  cap 36 by session
  public 'board numbers, dealer and vulnerability are public'
  insert <- viewer = 'service:ops' or exists directors[viewer]
  online only

table deals:
  board: boards
  north: text 1..100
  east: text 1..100
  south: text 1..100
  west: text 1..100
  unique board
  read <- exists directors[viewer] or exists results[board = .board, scorer = viewer]
  insert <- viewer = 'service:ops' or exists directors[viewer]
  online only

table results:
  session: sessions
  board: boards
  table: tables
  scorer: principal
  contract: text 2..20
  score: int -7600..7600
  at: time default now
  cap 36 by session, table
  cap 20 by board
  cap 720 by session
  unique board, table else ALREADY_PLAYED
  unique board, scorer else ALREADY_PLAYED
  immutable session, board, table, scorer, at
  read <- exists directors[viewer] or exists results[board = .board, scorer = viewer]
  insert <- .scorer = viewer and .table.scorer = viewer and .table.session = .session and .board.session = .session and .session.status = 'open'
  update <- exists directors[viewer] and .session.status = 'open'
  online only

table corrections:
  result: results
  board: boards
  session: sessions
  oldScore: int -7600..7600
  newScore: int -7600..7600
  oldContract: text 2..20
  newContract: text 2..20
  reason: text 5..300
  actor: principal
  at: time default now
  read <- exists directors[viewer] or exists results[board = .board, scorer = viewer]
  insert <- exists directors[viewer] and .actor = viewer
  online only

-- A scorer who believes a posted result is wrong appeals it in-app instead of
-- lobbying the director off-app. The dispute, reason and ruling stay in the
-- audit trail, and the session cannot close while an appeal is open.
table appeals:
  session: sessions
  board: boards
  result: results
  appellant: principal
  reason: text 5..300
  status: enum('open', 'upheld', 'rejected') default 'open'
  ruling: text 1..300 ?
  at: time default now
  cap 3 by result
  cap 20 by session
  read <- .appellant = viewer or exists directors[viewer] or exists results[board = .board, scorer = viewer]
  insert <- .appellant = viewer
  update <- exists directors[viewer]
  online only

table standings:
  session: sessions
  pair: pairs
  points: int 0..
  possible: int 0..
  unique session, pair
  public 'published final matchpoint results'
  insert <- exists directors[viewer]
  online only

table awards:
  session: sessions
  member: principal
  year: int 2020..2100
  points: int 0..
  possible: int 0..
  unique session, member
  read <- .member = viewer
  insert <- exists directors[viewer]
  online only

view yearPoints: sum awards of .points by .member, .year
  read <- .member = viewer
view yearPossible: sum awards of .possible by .member, .year
  read <- .member = viewer
view yearSessions: count awards by .member, .year
  read <- .member = viewer

query lobby():
  return sessions last 20 by .id

query sessionTables(session: sessions):
  return tables where .session = session first 20 by .number { *, nsName: .ns.name, ewName: .ew.name }

query boardList(session: sessions):
  return boards where .session = session first 36 by .number { *, mine: results[board = .id, scorer = viewer] }

query boardDeal(board: boards):
  return deals[board = board]

query boardResults(board: boards):
  return results where .board = board first 20 by .table { *, tableNumber: .table.number }

query correctionLog(board: boards):
  return corrections where .board = board last 100 by .at

query appealList(session: sessions):
  return appeals where .session = session last 20 by .at

query publicResults(session: sessions):
  return standings where .session = session last 40 by .points { *, name: .pair.name }

query myYear(year: int 2020..2100):
  return { points: yearPoints[viewer, year], possible: yearPossible[viewer, year], sessions: yearSessions[viewer, year] }

query myRole():
  return { principal: viewer, director: exists directors[viewer] }

-- Club setup: the operator seat enrolls the first director, then directors
-- (or the seat) provision sessions, pairs, boards with their deals, and table
-- assignments. Every write still passes its table's own insert rule.
mutation provisionDirector(principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert directors { principal }

mutation createSession(title: text 1..100, year: int 2020..2100):
  require viewer = 'service:ops' or exists directors[viewer] else DIRECTOR_ONLY
  return insert sessions { title, year, status: 'open' }

mutation registerPair(name: text 1..80, member: principal ?):
  require viewer = 'service:ops' or exists directors[viewer] else DIRECTOR_ONLY
  return insert pairs { name, member }

mutation scheduleBoard(session: sessions, number: int 1..36, dealer: text 1..3, vulnerability: text 1..4, north: text 1..100, east: text 1..100, south: text 1..100, west: text 1..100):
  require viewer = 'service:ops' or exists directors[viewer] else DIRECTOR_ONLY
  s = sessions[session] ! else NOT_FOUND
  b = insert boards { session: s.id, number, dealer, vulnerability }
  insert deals { board: b.id, north, east, south, west }
  return b

mutation seatTable(session: sessions, number: int 1..20, scorer: principal, ns: pairs, ew: pairs):
  require viewer = 'service:ops' or exists directors[viewer] else DIRECTOR_ONLY
  s = sessions[session] ! else NOT_FOUND
  n = pairs[ns] ! else NOT_FOUND
  e = pairs[ew] ! else NOT_FOUND
  return insert tables { session: s.id, number, scorer, ns: n.id, ew: e.id }

mutation submitResult(board: boards, table: tables, contract: text 2..20, score: int -7600..7600):
  b = boards[board] ! else NOT_FOUND
  t = tables[table] ! else NOT_FOUND
  require t.scorer = viewer else NOT_YOUR_TABLE 'Only the assigned scorer may submit.'
  require t.session = b.session else WRONG_SESSION
  s = sessions[b.session] ! else NOT_FOUND
  require s.status = 'open' else SESSION_CLOSED
  require not exists results[board = board, scorer = viewer] else ALREADY_PLAYED 'Ask the director to correct an existing result.'
  return insert results { session: b.session, board, table, scorer: viewer, contract, score }

mutation correctResult(result: results, contract: text 2..20, score: int -7600..7600, reason: text 5..300):
  require exists directors[viewer] else DIRECTOR_ONLY
  r = results[result] ! else NOT_FOUND
  s = sessions[r.session] ! else NOT_FOUND
  require s.status = 'open' else SESSION_CLOSED
  insert corrections { result, board: r.board, session: r.session, oldScore: r.score, newScore: score, oldContract: r.contract, newContract: contract, reason, actor: viewer }
  update results[result] { score, contract }
  return results[result]

mutation setAppealPolicy(session: sessions, appeals: text 1..7):
  require exists directors[viewer] else DIRECTOR_ONLY
  require appeals = 'allowed' or appeals = 'barred' else BAD_POLICY 'Appeals policy must be allowed or barred.'
  update sessions[session] { appeals }
  return sessions[session]

mutation appealResult(result: results, reason: text 5..300):
  r = results[result] ! else NOT_FOUND
  s = sessions[r.session] ! else NOT_FOUND
  require s.status = 'open' else SESSION_CLOSED
  require s.appeals = 'allowed' else APPEALS_BARRED 'This session does not allow appeals.'
  require exists tables[session = r.session, scorer = viewer] else NOT_YOUR_SESSION 'Only a scorer in this session may appeal.'
  return insert appeals { session: r.session, board: r.board, result, appellant: viewer, reason }

mutation resolveAppeal(appeal: appeals, upheld: bool, ruling: text 5..300):
  require exists directors[viewer] else DIRECTOR_ONLY
  a = appeals[appeal] ! else NOT_FOUND
  s = sessions[a.session] ! else NOT_FOUND
  require s.status = 'open' else SESSION_CLOSED
  require a.status = 'open' else ALREADY_DECIDED 'This appeal already has a ruling.'
  if upheld:
    update appeals[appeal] { status: 'upheld', ruling }
  else:
    update appeals[appeal] { status: 'rejected', ruling }
  return appeals[appeal]

-- Each lower NS score earns 2 matchpoints; a tie earns 1 (excluding self).
-- EW receives the complementary score. All scheduled table/board results are required.
mutation closeSession(session: sessions): server
  require exists directors[viewer] else DIRECTOR_ONLY
  s = sessions[session] ! else NOT_FOUND
  require s.status = 'open' else SESSION_CLOSED
  boardCount = count(boards where .session = session)
  tableCount = count(tables where .session = session)
  require boardCount > 0 and tableCount > 1 else EMPTY_SESSION
  require count(results where .session = session) = boardCount * tableCount else MISSING_RESULTS 'Every table must submit every board before closing.'
  require count(appeals where .session = session and .status = 'open') = 0 else OPEN_APPEALS 'Resolve every open appeal before closing.'
  possible = boardCount * 2 * (tableCount - 1)
  for t in tables where .session = session:
    nsPoints = 0
    for r in results where .session = session and .table = t.id:
      lower = count(results where .board = r.board and .score < r.score)
      tied = count(results where .board = r.board and .score = r.score)
      nsPoints = nsPoints + 2 * lower + tied - 1
    insert standings { session, pair: t.ns, points: nsPoints, possible }
    insert standings { session, pair: t.ew, points: possible - nsPoints, possible }
    nsMember = t.ns.member
    ewMember = t.ew.member
    if nsMember != null:
      insert awards { session, member: nsMember, year: s.year, points: nsPoints, possible }
    if ewMember != null:
      insert awards { session, member: ewMember, year: s.year, points: possible - nsPoints, possible }
  update sessions[session] { status: 'closed' }
  return { published: true }
