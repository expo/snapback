-- Audio Description Review.
-- Personas: alice (writer), bob + dave (reviewers), carol (editor, privileged).
-- A writer drafts description cues timed to gaps in dialogue. The editor
-- assigns reviewers; reviewers comment and sign off. Approval needs two
-- sign-offs. Approved scripts are publicly readable (player page).

use personas alice, bob, carol, dave

-- Fixed roster: exactly one row per editor. No insert rule -> roster is
-- fixture-seeded and immutable through the API.
table editors:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table scripts:
  title: text 1..120
  show: text 1..120
  status: enum('draft', 'in_review', 'approved') default 'draft'
  writer: principal
  immutable writer
  read <- .writer = viewer or .status = 'approved' or exists editors[viewer] or exists assignments[script = .id, reviewer = viewer]
  insert <- .writer = viewer and .status = 'draft'
  update <- .writer = viewer or exists editors[viewer]
  delete <- .writer = viewer
  cap 200 by writer
  online only

-- Which reviewers may see and review a script. Only the editor assigns.
table assignments:
  script: scripts on delete cascade
  reviewer: principal
  unique script, reviewer
  immutable script, reviewer
  read <- .reviewer = viewer or exists editors[viewer] or exists scripts[.script, writer = viewer]
  insert <- exists editors[viewer]
  delete <- exists editors[viewer]
  cap 20 by script
  online only

-- Timed description lines. Locked once the script is approved.
table cues:
  script: scripts on delete cascade
  startMs: int 0..3600000
  endMs: int 0..3600000
  text: text 1..500
  immutable script
  read <- exists scripts[.script, writer = viewer] or exists assignments[script = .script, reviewer = viewer] or exists editors[viewer] or exists scripts[.script, status = 'approved']
  insert <- exists scripts[.script, writer = viewer] or exists editors[viewer]
  update <- exists scripts[.script, writer = viewer] or exists editors[viewer]
  delete <- exists scripts[.script, writer = viewer] or exists editors[viewer]
  cap 23 by script
  online only

-- Review feedback on a cue. `script` is denormalized (immutable) so the read
-- rule stays one hop. The editor resolves; authors may edit their own body.
table comments:
  script: scripts on delete cascade
  cue: cues on delete cascade
  author: principal
  body: text 1..500
  resolved: bool default false
  immutable script, cue, author
  read <- .author = viewer or exists scripts[.script, writer = viewer] or exists assignments[script = .script, reviewer = viewer] or exists editors[viewer] or exists scripts[.script, status = 'approved']
  insert <- .author = viewer
  update <- .author = viewer or exists editors[viewer]
  delete <- .author = viewer or exists editors[viewer]
  cap 23 by cue
  cap 23 by script
  online only

-- One row per reviewer sign-off. Only an assigned reviewer signs.
table signoffs:
  script: scripts on delete cascade
  reviewer: principal
  at: time default now
  unique script, reviewer
  immutable script, reviewer
  read <- .reviewer = viewer or exists scripts[.script, writer = viewer] or exists editors[viewer]
  insert <- .reviewer = viewer and exists assignments[.script, viewer]
  delete <- .reviewer = viewer or exists editors[viewer]
  cap 20 by script
  online only

view signoffCount: count signoffs by .script
  read <- allow
  online only

query myScripts(c: cursor ?):
  return scripts where .writer = viewer last 20 by .id after c

query myAssignments(c: cursor ?):
  return assignments where .reviewer = viewer first 50 by .id after c { id, script }

query allScripts(c: cursor ?):
  require exists editors[viewer] else NOT_EDITOR
  return scripts last 50 by .id after c

query publishedScripts(c: cursor ?):
  return scripts where .status = 'approved' first 50 by .id after c

query scriptDetail(script: scripts):
  return scripts[script]

query cuesOf(script: scripts, c: cursor ?):
  return cues where .script = script first 100 by .startMs after c

query commentsOf(cue: cues, c: cursor ?):
  return comments where .cue = cue first 100 by .id after c

query allComments(script: scripts, c: cursor ?):
  require exists editors[viewer] or exists scripts[script, writer = viewer] else NOT_ALLOWED
  return comments where .script = script first 100 by .id after c

query signoffsOf(script: scripts, c: cursor ?):
  return signoffs where .script = script first 20 by .id after c

query signoffCountOf(script: scripts):
  return signoffCount[script]

mutation createScript(title: text 1..120, show: text 1..120):
  return insert scripts { writer: viewer, title, show, status: 'draft' }

mutation submitForReview(script: scripts):
  s = scripts[script] ! else NOT_FOUND
  require s.writer = viewer else NOT_OWNER
  require s.status = 'draft' else BAD_STATUS 'Only drafts can be submitted for review.'
  update scripts[script] { status: 'in_review' }
  return scripts[script]

mutation assignReviewer(script: scripts, reviewer: principal):
  require exists editors[viewer] else NOT_EDITOR
  s = scripts[script] ! else NOT_FOUND
  return insert assignments { script, reviewer }

mutation addCue(script: scripts, startMs: int 0..3600000, endMs: int 0..3600000, text: text 1..500):
  s = scripts[script] ! else NOT_FOUND
  require s.writer = viewer or exists editors[viewer] else NOT_ALLOWED
  require s.status != 'approved' else LOCKED 'Approved scripts are locked.'
  require endMs > startMs else BAD_RANGE 'The cue end must be after its start.'
  return insert cues { script, startMs, endMs, text }

mutation editCue(cue: cues, text: text 1..500):
  cu = cues[cue] ! else NOT_FOUND
  require exists scripts[cu.script, writer = viewer] or exists editors[viewer] else NOT_ALLOWED
  update cues[cue] { text }
  return cues[cue]

mutation postComment(script: scripts, cue: cues, body: text 1..500):
  s = scripts[script] ! else NOT_FOUND
  cu = cues[cue] ! else NOT_FOUND
  require cu.script = script else MISMATCH 'That cue is not on this script.'
  require exists assignments[script, viewer] or exists scripts[script, writer = viewer] or exists editors[viewer] else NOT_ALLOWED
  return insert comments { script, cue, author: viewer, body }

mutation resolveComment(comment: comments, resolved: bool):
  require exists editors[viewer] else NOT_EDITOR
  update comments[comment] { resolved }
  return comments[comment]

mutation signoff(script: scripts):
  s = scripts[script] ! else NOT_FOUND
  require exists assignments[script, viewer] else NOT_ASSIGNED
  return insert signoffs { script, reviewer: viewer }

mutation approve(script: scripts):
  require exists editors[viewer] else NOT_EDITOR
  s = scripts[script] ! else NOT_FOUND
  require s.status = 'in_review' else BAD_STATUS 'Only scripts in review can be approved.'
  n = signoffCount[script]
  require n >= 2 else NEED_TWO_SIGNOFFS 'At least two reviewer sign-offs are required.'
  update scripts[script] { status: 'approved' }
  return scripts[script]
