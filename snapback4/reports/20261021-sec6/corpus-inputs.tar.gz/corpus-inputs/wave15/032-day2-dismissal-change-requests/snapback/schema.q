use identity
use personas alice, bob, olivia, tess, dan

-- Production rosters are provisioned through the trusted operator seat and office.
table office:
  principal: principal
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only
table teachers:
  principal: principal
  classroom: text 1..30
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- exists office[viewer] or viewer = 'service:ops'
  online only
table drivers:
  principal: principal
  route: text 1..30
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- exists office[viewer] or viewer = 'service:ops'
  online only
table families:
  principal: principal
  label: text 1..60
  unique principal
  insert <- exists office[viewer] or viewer = 'service:ops'
  public 'School family directory: display names for choosing the receiving family.'
  online only
table schoolDays:
  label: text 10..10
  startsAt: time
  cutoffAt: time
  endsAt: time
  unique label
  insert <- exists office[viewer]
  public 'School calendar boundaries and the 1:30 p.m. cutoff, in Europe/Berlin.'
  online only
table children:
  name: text 1..60
  parent: principal
  classroom: text 1..30
  usualMode: enum('bus', 'car', 'walk')
  route: text <=30
  immutable parent, classroom, usualMode, route, name
  read <- .parent = viewer or exists office[viewer]
  insert <- exists office[viewer]
  online only
table requests:
  child: children
  owner: principal
  studentName: text 1..60
  classroom: text 1..30
  originalRoute: text <=30
  schoolDay: schoolDays
  method: enum('car', 'walk', 'family')
  instructions: text 1..240
  receivingFamily: principal ?
  officeStatus: enum('pending', 'approved', 'rejected')
  familyStatus: enum('not_needed', 'pending', 'confirmed', 'declined')
  at: time
  unique child, schoolDay else ALREADY_REQUESTED 'A request already exists for this child today. Contact the office.'
  immutable child, owner, studentName, classroom, originalRoute, schoolDay, method, instructions, receivingFamily, at
  read <- .owner = viewer or .receivingFamily = viewer or exists office[viewer]
  insert <- .owner = viewer and exists children[.child, parent = viewer]
  update <- .receivingFamily = viewer or exists office[viewer]
  online only
-- These projections deliberately omit parent messages and other family details.
-- Expiry enforces today's-only access even for direct reads outside the UI.
table teacherChanges:
  request: requests
  studentName: text 1..60
  classroom: text 1..30
  method: enum('car', 'walk', 'family')
  instructions: text 1..240
  endsAt: time
  reviewStatus: enum('pending', 'acknowledged') default 'pending'
  unique request
  immutable request, studentName, classroom, method, instructions, endsAt
  read <- exists teachers[principal = viewer, classroom = .classroom]
  insert <- exists requests[.request, officeStatus = 'approved', familyStatus = 'not_needed'] or exists requests[.request, officeStatus = 'approved', familyStatus = 'confirmed']
  update <- exists teachers[principal = viewer, classroom = .classroom]
  expire at .endsAt
  online only
table busRemovals:
  request: requests
  studentName: text 1..60
  route: text 1..30
  endsAt: time
  unique request
  immutable request, studentName, route, endsAt
  read <- exists drivers[principal = viewer, route = .route]
  insert <- exists requests[.request, officeStatus = 'approved', familyStatus = 'not_needed'] or exists requests[.request, officeStatus = 'approved', familyStatus = 'confirmed']
  expire at .endsAt
  online only
table audit:
  request: requests
  actor: principal
  action: enum('submitted', 'office_approved', 'office_rejected', 'family_confirmed', 'family_declined', 'teacher_acknowledged')
  at: time default now
  read <- exists office[viewer]
  insert <- .actor = viewer
  online only

fn publish(requestId: requests):
  r = requests[requestId] ! else NOT_FOUND
  if r.officeStatus = 'approved' and (r.familyStatus = 'not_needed' or r.familyStatus = 'confirmed'):
    d = schoolDays[r.schoolDay] ! else DAY_NOT_FOUND
    insert teacherChanges { request: r.id, studentName: r.studentName, classroom: r.classroom, method: r.method, instructions: r.instructions, endsAt: d.endsAt } if absent
    if r.originalRoute != '':
      insert busRemovals { request: r.id, studentName: r.studentName, route: r.originalRoute, endsAt: d.endsAt } if absent

query calendar():
  return schoolDays where .startsAt <= now and .endsAt > now first 1 by .startsAt
query myChildren():
  return children where .parent = viewer first 50 by .id
query familyDirectory():
  return families first 100 by .label
query myRequests():
  return requests where .owner = viewer last 100 by .at
query familyInbox():
  return requests where .receivingFamily = viewer and .familyStatus = 'pending' last 100 by .at
query officeRequests():
  if not exists office[viewer]:
    return []
  return requests last 100 by .at
query teacherToday():
  t = teachers[viewer]
  if t = null:
    return []
  return teacherChanges where .classroom = t.classroom first 100 by .studentName
query busToday():
  d = drivers[viewer]
  if d = null:
    return []
  return busRemovals where .route = d.route first 100 by .studentName
query auditLog():
  if not exists office[viewer]:
    return []
  return audit last 100 by .at

mutation submit(childId: children, schoolDay: schoolDays, method: enum('car', 'walk', 'family'), instructions: text 1..240, receivingFamily: principal ?): server
  c = children[childId] ! else CHILD_NOT_FOUND
  require c.parent = viewer else NOT_PARENT
  d = schoolDays[schoolDay] ! else DAY_NOT_FOUND
  require now >= d.startsAt and now < d.endsAt else NOT_TODAY 'Changes apply only to the current school day.'
  require method = 'family' or receivingFamily = null else UNEXPECTED_FAMILY
  if method = 'family':
    require receivingFamily != null and receivingFamily != viewer else CHOOSE_OTHER_FAMILY
    require exists families[principal = receivingFamily] else FAMILY_NOT_FOUND
  r = insert requests { child: c.id, owner: viewer, studentName: c.name, classroom: c.classroom, originalRoute: c.route if c.usualMode = 'bus' else '', schoolDay, method, instructions, receivingFamily, officeStatus: 'pending' if now > d.cutoffAt else 'approved', familyStatus: 'pending' if method = 'family' else 'not_needed', at: now }
  insert audit { request: r.id, actor: viewer, action: 'submitted' }
  publish(r.id)
  return r

mutation officeDecision(requestId: requests, approve: bool): server
  require exists office[viewer] else OFFICE_ONLY 'Only the front office may decide late requests.'
  r = requests[requestId] ! else NOT_FOUND
  d = schoolDays[r.schoolDay] ! else DAY_NOT_FOUND
  require now < d.endsAt else DAY_ENDED
  require r.officeStatus = 'pending' else ALREADY_DECIDED
  update requests[r.id] { officeStatus: 'approved' if approve else 'rejected' }
  insert audit { request: r.id, actor: viewer, action: 'office_approved' if approve else 'office_rejected' }
  publish(r.id)
  return requests[r.id]

mutation familyDecision(requestId: requests, confirm: bool): server
  r = requests[requestId] ! else NOT_FOUND
  require r.receivingFamily = viewer else RECEIVING_FAMILY_ONLY
  d = schoolDays[r.schoolDay] ! else DAY_NOT_FOUND
  require now < d.endsAt else DAY_ENDED
  require r.familyStatus = 'pending' else ALREADY_DECIDED
  update requests[r.id] { familyStatus: 'confirmed' if confirm else 'declined' }
  insert audit { request: r.id, actor: viewer, action: 'family_confirmed' if confirm else 'family_declined' }
  publish(r.id)
  return requests[r.id]

-- A password signup never grants a school role. Only a locally minted seat
-- can appoint the first office user. The office maintains trusted school data.
mutation grantOffice(principal: principal): server
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert office { principal }

mutation enrollTeacher(principal: principal, classroom: text 1..30): server
  require exists office[viewer] or viewer = 'service:ops' else OFFICE_ONLY
  return insert teachers { principal, classroom }

mutation enrollDriver(principal: principal, route: text 1..30): server
  require exists office[viewer] or viewer = 'service:ops' else OFFICE_ONLY
  return insert drivers { principal, route }

mutation registerFamily(principal: principal, label: text 1..60): server
  require exists office[viewer] or viewer = 'service:ops' else OFFICE_ONLY
  return insert families { principal, label }

mutation enrollChild(name: text 1..60, parent: principal, classroom: text 1..30, usualMode: enum('bus', 'car', 'walk'), route: text <=30): server
  require exists office[viewer] else OFFICE_ONLY
  require exists families[principal = parent] else FAMILY_NOT_FOUND
  return insert children { name, parent, classroom, usualMode, route }

mutation configureDay(label: text 10..10, startsAt: time, cutoffAt: time, endsAt: time): server
  require exists office[viewer] else OFFICE_ONLY
  require startsAt < cutoffAt and cutoffAt < endsAt else INVALID_DAY
  return insert schoolDays { label, startsAt, cutoffAt, endsAt }

query myRoles():
  return { isOffice: exists office[viewer], teacher: teachers[viewer], driver: drivers[viewer], family: families[viewer] }

-- A review receipt is durable even after today's staff projection expires.
-- It records awareness; it does not add another gate to dismissal approval.
table acknowledgements:
  request: requests
  actor: principal
  studentName: text 1..60
  classroom: text 1..30
  at: time default now
  unique request
  immutable request, actor, studentName, classroom, at
  read <- .actor = viewer or exists office[viewer]
  insert <- .actor = viewer and exists teachers[principal = viewer, classroom = .classroom]
  online only

query reviewReceipts():
  return acknowledgements last 100 by .at

mutation acknowledge(requestId: requests): server
  c = teacherChanges[request = requestId] ! else CHANGE_NOT_FOUND
  require exists teachers[principal = viewer, classroom = c.classroom] else TEACHER_ONLY
  require now < c.endsAt else DAY_ENDED
  require c.reviewStatus = 'pending' else ALREADY_ACKNOWLEDGED 'This dismissal plan has already been reviewed.'
  update teacherChanges[c.id] { reviewStatus: 'acknowledged' }
  receipt = insert acknowledgements { request: c.request, actor: viewer, studentName: c.studentName, classroom: c.classroom }
  insert audit { request: c.request, actor: viewer, action: 'teacher_acknowledged' }
  return receipt
