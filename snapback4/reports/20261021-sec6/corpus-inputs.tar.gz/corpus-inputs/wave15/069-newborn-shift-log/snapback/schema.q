use personas alice, bob, nurse

-- One roster for the whole family. Nurses are members (they read/write the
-- log and the feeding plan) but the parent role gates photos/notes/summaries.
table members:
  principal: principal
  role: enum('parent', 'nurse')
  unique principal
  read <- .principal = viewer
  online only

-- The shared live log. Every row is stamped with its author (.author).
table entries:
  kind: enum('feed', 'diaper', 'sleep')
  diaper: enum('wet', 'dirty', 'both') ?
  amountMl: int 0..500 ?
  sleepMinutes: int 0..1440 ?
  note: text <=280 ?
  at: time default now
  author: principal
  immutable author, kind
  read <- exists members[viewer]
  insert <- .author = viewer and exists members[viewer]
  update <- .author = viewer
  delete <- .author = viewer
  cap 5000
  sync

-- The feeding plan: everyone on the night shift reads it, only parents edit.
table plans:
  title: text 1..80
  body: text 1..2000
  updatedBy: principal
  updatedAt: time default now
  read <- exists members[viewer]
  insert <- .updatedBy = viewer and exists members[viewer, role = 'parent']
  update <- exists members[viewer, role = 'parent']
  delete <- exists members[viewer, role = 'parent']
  cap 20
  sync

-- Family photos: parents only. Online only so a nurse device never holds them.
table photos:
  caption: text 1..120
  photo: image <=5000000 ?
  author: principal
  at: time default now
  immutable author
  read <- exists members[viewer, role = 'parent']
  insert <- .author = viewer and exists members[viewer, role = 'parent']
  update <- .author = viewer
  delete <- .author = viewer
  cap 500
  online only

-- Family notes: parents only.
table notes:
  text: text 1..2000
  author: principal
  at: time default now
  immutable author
  read <- exists members[viewer, role = 'parent']
  insert <- .author = viewer and exists members[viewer, role = 'parent']
  update <- .author = viewer
  delete <- .author = viewer
  cap 1000
  online only

-- Printable weekly summaries shared with the pediatrician: parents only.
table summaries:
  weekStart: time
  recipient: text 5..120 format email
  body: text 1..4000
  createdBy: principal
  at: time default now
  immutable createdBy
  read <- exists members[viewer, role = 'parent']
  insert <- .createdBy = viewer and exists members[viewer, role = 'parent']
  delete <- .createdBy = viewer
  cap 200
  online only

query recentLog(c: cursor ?):
  return entries last 50 by .at after c

query feedsSince(since: time):
  return entries where .kind = 'feed' and .at >= since first 200 by .at

query diapersSince(since: time):
  return entries where .kind = 'diaper' and .at >= since first 200 by .at

query sleepSince(since: time):
  return entries where .kind = 'sleep' and .at >= since first 200 by .at

query feedingPlan():
  return plans first 10 by .id

query familyPhotos(c: cursor ?):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return photos last 50 by .at after c

query familyNotes(c: cursor ?):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return notes last 50 by .at after c

query weekEntries(start: time, end: time):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return entries where .at >= start and .at < end first 500 by .at

query sharedSummaries(c: cursor ?):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return summaries last 20 by .at after c

mutation logFeed(amountMl: int 0..500 ?, note: text <=280 ?, at: time ?):
  return insert entries { kind: 'feed', author: viewer, amountMl, note, at: at ?? now }

mutation logDiaper(diaper: enum('wet', 'dirty', 'both'), note: text <=280 ?, at: time ?):
  return insert entries { kind: 'diaper', author: viewer, diaper, note, at: at ?? now }

mutation logSleep(sleepMinutes: int 0..1440 ?, note: text <=280 ?, at: time ?):
  return insert entries { kind: 'sleep', author: viewer, sleepMinutes, note, at: at ?? now }

mutation editEntry(entry: entries, note: text <=280 ?):
  e = entries[entry] ! else NOT_FOUND
  update entries[entry] { note }
  return null

mutation removeEntry(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  delete entries[entry]
  return null

mutation savePlan(title: text 1..80, body: text 1..2000):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return insert plans { title, body, updatedBy: viewer, updatedAt: now }

mutation updatePlan(plan: plans, title: text 1..80, body: text 1..2000):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  update plans[plan] { title, body, updatedBy: viewer, updatedAt: now }
  return null

mutation addPhoto(caption: text 1..120, photo: image <=5000000 ?):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return insert photos { caption, photo, author: viewer, at: now }

mutation addNote(text: text 1..2000):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return insert notes { text, author: viewer, at: now }

mutation shareSummary(weekStart: time, recipient: text 5..120 format email, body: text 1..4000):
  require exists members[viewer, role = 'parent'] else NOT_PARENT
  return insert summaries { weekStart, recipient, body, createdBy: viewer, at: now }
