use identity
use personas alice, bob, cara, manager, coach, visitor

table staff:
  person: principal
  role: enum('manager', 'coach')
  unique person
  read <- .person = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table seasons:
  title: text 1..80
  deadline: time
  seed: int 1..1000000
  allocated: bool default false
  cap 1
  public 'Season dates and the committed draw seed are public.'
  insert <- viewer = 'service:ops'
  update <- exists staff[person = viewer, role = 'manager']
  online only

table players:
  season: seasons
  person: principal
  name: text 1..60
  seniority: int 0..20
  drawKey: int 1..1000000
  unique season, person
  unique season, drawKey
  cap 30 by season
  immutable season, person, name, seniority, drawKey
  public 'Club membership and seniority are visible; number preferences are separate.'
  insert <- viewer = 'service:ops'
  online only

table requests:
  season: seasons
  owner: principal
  first: int 1..99
  second: int 1..99
  third: int 1..99
  kitSize: enum('XS', 'S', 'M', 'L', 'XL', 'XXL') default 'M'
  unique season, owner
  cap 30 by season
  immutable season, owner
  read <- (.owner = viewer or exists staff[person = viewer, role = 'manager']) or viewer = 'service:ops'
  insert <- (.owner = viewer and exists players[.season, viewer]) or viewer = 'service:ops'
  update <- .owner = viewer
  online only

table roster:
  season: seasons
  owner: principal
  name: text 1..60
  number: int 1..99 ?
  unique season, owner
  unique season, number
  cap 30 by season
  immutable season, owner, name
  public 'Final jersey numbers are the public team roster.'
  insert <- exists staff[person = viewer, role = 'manager']
  update <- exists staff[person = viewer, role = 'coach']
  online only

table retiredNumbers:
  season: seasons
  number: int 1..99
  reason: text 1..80
  unique season, number
  cap 20 by season
  immutable season, number
  public 'Retired numbers honour club history and are never assigned.'
  insert <- exists staff[person = viewer, role = 'manager'] or viewer = 'service:ops'
  online only
table trades:
  season: seasons
  proposer: principal
  partner: principal
  a: roster
  b: roster
  aNumber: int 1..99
  bNumber: int 1..99
  status: enum('pending', 'approved', 'rejected', 'withdrawn') default 'pending'
  cap 100 by season
  immutable season, proposer, partner, a, b, aNumber, bNumber
  read <- .proposer = viewer or .partner = viewer or exists staff[person = viewer, role = 'coach']
  insert <- .proposer = viewer
  update <- exists staff[person = viewer, role = 'coach'] or .proposer = viewer
  online only

fn draw(key: int, seed: int):
  return ((key + seed) * 48271) % 2147483647

fn allocate(s: seasons):
  seasonRow = seasons[s] ! else NOT_FOUND
  require now >= seasonRow.deadline else DEADLINE_OPEN
  require not seasonRow.allocated else ALREADY_ALLOCATED
  ranked = players[] where .season = s { id, person, name, priority: (20 - .seniority) * 2147483647 + draw(.drawKey, seasonRow.seed) }
  ordered = sort(ranked, 'priority')
  for place in range(0, count(ordered)):
    p = at(ordered, place)
    if p != null:
      r = requests[s, p.person]
      chosen = 0
      if r != null:
        if not exists roster[season = s, number = r.first] and not exists retiredNumbers[season = s, number = r.first]:
          chosen = r.first
        else if not exists roster[season = s, number = r.second] and not exists retiredNumbers[season = s, number = r.second]:
          chosen = r.second
        else if not exists roster[season = s, number = r.third] and not exists retiredNumbers[season = s, number = r.third]:
          chosen = r.third
      if chosen = 0:
        for n in range(1, 100):
          if chosen = 0 and not exists roster[season = s, number = n] and not exists retiredNumbers[season = s, number = n]:
            chosen = n
      insert roster { season: s, owner: p.person, name: p.name, number: chosen }
  update seasons[s] { allocated: true }
  return null

job allocateDue():
  for s in seasons:
    if not s.allocated and now >= s.deadline:
      allocate(s.id)
schedule deadlineSweep every 1m: allocateDue

query seasonInfo():
  return seasons first 1 by .id
query members(season: seasons):
  return players where .season = season first 30 by .name
query myRequest(season: seasons):
  return requests[season, viewer]
query ordering(season: seasons):
  require exists staff[person = viewer, role = 'manager'] else MANAGER_ONLY
  return requests where .season = season first 30 by .owner { id, owner, first, second, third, kitSize, player: players[season, .owner] }
query retiredList(season: seasons):
  return retiredNumbers where .season = season first 20 by .number
query publicRoster(season: seasons):
  return roster where .season = season first 30 by .number
query myRole():
  return staff[person = viewer]
query tradeList(season: seasons):
  if exists staff[person = viewer, role = 'coach']:
    return trades where .season = season first 100 by .id
  return trades where .season = season and .proposer = viewer first 100 by .id

mutation saveRequest(season: seasons, first: int 1..99, second: int 1..99, third: int 1..99, kitSize: enum('XS', 'S', 'M', 'L', 'XL', 'XXL')):
  s = seasons[season] ! else NOT_FOUND
  require exists players[season, viewer] else PLAYER_ONLY
  require now < s.deadline and not s.allocated else REQUESTS_CLOSED
  require first != second and first != third and second != third else DISTINCT_NUMBERS
  return upsert requests[season, viewer] { season, owner: viewer, first, second, third, kitSize }
mutation retireNumber(season: seasons, number: int 1..99, reason: text 1..80):
  require viewer = 'service:ops' or exists staff[person = viewer, role = 'manager'] else MANAGER_ONLY
  s = seasons[season] ! else NOT_FOUND
  require not exists roster[season = s.id, number = number] else NUMBER_TAKEN
  return insert retiredNumbers { season: s.id, number, reason }
mutation withdrawTrade(trade: trades):
  t = trades[trade] ! else NOT_FOUND
  require t.proposer = viewer else NOT_YOUR_TRADE
  require t.status = 'pending' else TRADE_DECIDED
  update trades[trade] { status: 'withdrawn' }
  return { ok: true }
mutation assignNow(season: seasons): server
  require exists staff[person = viewer, role = 'manager'] else MANAGER_ONLY
  return allocate(season)
mutation proposeTrade(season: seasons, partner: principal):
  require exists seasons[season] else NOT_FOUND
  a = roster[season, viewer] ! else NO_JERSEY
  b = roster[season, partner] ! else NO_PARTNER
  require viewer != partner else DIFFERENT_PLAYERS
  require a.number != null and b.number != null else NO_JERSEY
  require not exists trades where .season = season and .proposer = viewer and .status = 'pending' else TRADE_PENDING
  return insert trades { season, proposer: viewer, partner, a: a.id, b: b.id, aNumber: a.number, bNumber: b.number }
mutation decideTrade(trade: trades, approve: bool):
  require exists staff[person = viewer, role = 'coach'] else COACH_ONLY
  t = trades[trade] ! else NOT_FOUND
  require t.status = 'pending' else TRADE_DECIDED
  if approve:
    a = roster[t.a] ! else NOT_FOUND
    b = roster[t.b] ! else NOT_FOUND
    require a.number = t.aNumber and b.number = t.bNumber else STALE_TRADE
    update roster[t.a] { number: null }
    update roster[t.b] { number: t.aNumber }
    update roster[t.a] { number: t.bNumber }
  update trades[trade] { status: 'approved' if approve else 'rejected' }
  return { ok: true }
mutation provisionSeason(title: text 1..80, deadline: time, seed: int 1..1000000):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert seasons { title, deadline, seed }
mutation enrollPlayer(season: seasons, person: principal, name: text 1..60, seniority: int 0..20, drawKey: int 1..1000000):
  require viewer = 'service:ops' else NOT_OPERATOR
  s = seasons[season] ! else NOT_FOUND
  return insert players { season: s.id, person, name, seniority, drawKey }
mutation grantStaff(person: principal, role: enum('manager', 'coach')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { person, role }
