use personas alice, bob, clerk, attendant, towco, otherTow, visitor
use identity

table staff:
  principal: principal
  role: enum('clerk', 'attendant', 'company')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops' or exists staff[viewer, role = 'clerk']
  insert <- viewer = 'service:ops'
  online only

table vehicles:
  plate: text 2..12
  description: text 2..100
  owner: principal
  company: principal
  towedAt: time
  releasedAt: time ?
  unique plate
  immutable plate, description, owner, company, towedAt
  read <- .owner = viewer or .company = viewer or exists staff[viewer, role = 'clerk']
  insert <- exists staff[viewer, role = 'clerk']
  update <- .owner = viewer or exists staff[viewer, role = 'clerk'] or exists staff[viewer, role = 'attendant']
  online only

table documents:
  vehicle: vehicles
  owner: principal
  registration: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')
  identity: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')
  status: enum('pending', 'approved', 'rejected', 'withdrawn')
  submissionVersion: int 1.. default 1
  note: text <=300
  submittedAt: time
  reviewedAt: time ?
  unique vehicle
  immutable vehicle, owner
  read <- .owner = viewer or exists staff[viewer, role = 'clerk']
  insert <- .owner = viewer and exists vehicles[.vehicle, owner = viewer, releasedAt = null]
  update <- .owner = viewer or exists staff[viewer, role = 'clerk']
  online only

table requestEvents:
  vehicle: vehicles
  owner: principal
  actor: principal
  action: enum('submitted', 'withdrawn')
  submissionVersion: int 1..
  reason: text 1..300
  createdAt: time
  immutable vehicle, owner, actor, action, submissionVersion, reason, createdAt
  read <- .owner = viewer or exists staff[viewer, role = 'clerk']
  insert <- .owner = viewer and .actor = viewer and exists vehicles[.vehicle, owner = viewer]
  online only

table releaseQueue:
  vehicle: vehicles
  plate: text 2..12
  description: text 2..100
  owner: principal
  towedAt: time
  approvedAt: time
  expiresAt: time
  unique vehicle
  expire at .expiresAt
  read <- exists staff[viewer, role = 'attendant'] or exists staff[viewer, role = 'clerk']
  insert <- exists staff[viewer, role = 'clerk']
  update <- exists staff[viewer, role = 'clerk']
  delete <- exists staff[viewer, role = 'clerk'] or exists staff[viewer, role = 'attendant']
  online only

table presence:
  plate: text 2..12
  inLot: bool
  unique plate
  public 'Only plate presence is public; no owner, documents or tow details.'
  insert <- exists staff[viewer, role = 'clerk']
  update <- exists staff[viewer, role = 'attendant']
  online only

table releases:
  vehicle: vehicles
  plate: text 2..12
  releasedAt: time
  attendant: principal
  storageDays: int 1..
  unique vehicle
  read <- exists staff[viewer, role = 'clerk']
  insert <- .attendant = viewer and exists staff[viewer, role = 'attendant']
  online only

query role():
  return staff[principal = viewer] { role }

mutation grantStaff(principal: principal, role: enum('clerk', 'attendant', 'company')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert staff { principal, role }

mutation intakeVehicle(plate: text 2..12, description: text 2..100, owner: principal, company: principal):
  require exists staff[viewer, role = 'clerk'] else CLERK_ONLY
  require exists staff[company, role = 'company'] else COMPANY_REQUIRED
  v = insert vehicles { plate, description, owner, company, towedAt: now, releasedAt: null }
  insert presence { plate, inLot: true }
  return v

query inventory():
  if exists staff[viewer, role = 'clerk']:
    return vehicles first 100 by .id { id, plate, description, owner, company, towedAt, releasedAt, storageDays: ((.releasedAt ?? now) - .towedAt) / 1d + 1 }
  if exists staff[viewer, role = 'company']:
    return vehicles where .company = viewer first 100 by .id { id, plate, description, towedAt, releasedAt, storageDays: ((.releasedAt ?? now) - .towedAt) / 1d + 1 }
  return vehicles where .owner = viewer first 100 by .id { id, plate, description, towedAt, releasedAt, storageDays: ((.releasedAt ?? now) - .towedAt) / 1d + 1 }

query requests():
  if exists staff[viewer, role = 'clerk']:
    return documents first 100 by .submittedAt
  return documents where .owner = viewer first 100 by .submittedAt

query requestHistory(vehicle: vehicles):
  return requestEvents where .vehicle = vehicle first 100 by .createdAt

query todayReleases():
  return releaseQueue first 100 by .approvedAt { id, vehicle, plate, description, approvedAt, storageDays: (now - .towedAt) / 1d + 1 }

query releaseLog():
  return releases last 100 by .releasedAt

query lookup(plate: text 2..12):
  return presence[plate = plate] { inLot }

mutation submitDocuments(vehicle: vehicles, registration: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png'), identity: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  v = vehicles[vehicle] ! else NOT_FOUND
  require v.owner = viewer else OWNER_ONLY
  require v.releasedAt = null else ALREADY_RELEASED
  d = documents[vehicle = vehicle]
  require d = null or d.status = 'rejected' or d.status = 'withdrawn' else ALREADY_SUBMITTED
  if d != null:
    updated = update documents[d.id] { registration, identity, status: 'pending', note: '', submittedAt: now, reviewedAt: null, submissionVersion: d.submissionVersion + 1 }
    insert requestEvents { vehicle, owner: viewer, actor: viewer, action: 'submitted', submissionVersion: d.submissionVersion + 1, reason: 'Replacement documents submitted', createdAt: now }
    return updated
  newDocument = insert documents { vehicle, owner: viewer, registration, identity, status: 'pending', note: '', submittedAt: now, reviewedAt: null, submissionVersion: 1 }
  insert requestEvents { vehicle, owner: viewer, actor: viewer, action: 'submitted', submissionVersion: 1, reason: 'Documents submitted', createdAt: now }
  return newDocument

mutation withdrawRequest(vehicle: vehicles, reason: text 1..300):
  v = vehicles[vehicle] ! else NOT_FOUND
  require v.owner = viewer else OWNER_ONLY
  require v.releasedAt = null else ALREADY_RELEASED
  d = documents[vehicle = vehicle] ! else DOCUMENTS_REQUIRED
  require d.status = 'pending' else PENDING_ONLY
  update documents[d.id] { status: 'withdrawn', note: reason }
  return insert requestEvents { vehicle, owner: viewer, actor: viewer, action: 'withdrawn', submissionVersion: d.submissionVersion, reason, createdAt: now }

mutation reviewDocuments(vehicle: vehicles, decision: enum('approved', 'rejected'), note: text <=300):
  require exists staff[viewer, role = 'clerk'] else CLERK_ONLY
  v = vehicles[vehicle] ! else NOT_FOUND
  require v.releasedAt = null else ALREADY_RELEASED
  d = documents[vehicle = vehicle] ! else DOCUMENTS_REQUIRED
  require d.status != 'withdrawn' else REQUEST_WITHDRAWN
  require decision = 'approved' or note != '' else REJECTION_REASON_REQUIRED
  update documents[d.id] { status: decision, note, reviewedAt: now }
  if decision = 'approved':
    upsert releaseQueue[vehicle = vehicle] { vehicle, plate: v.plate, description: v.description, owner: v.owner, towedAt: v.towedAt, approvedAt: now, expiresAt: (day(now) + 1) * 1d }
  else:
    if exists releaseQueue[vehicle = vehicle]:
      delete releaseQueue[vehicle = vehicle]
  return null

mutation releaseVehicle(vehicle: vehicles):
  require exists staff[viewer, role = 'attendant'] else ATTENDANT_ONLY
  q = releaseQueue[vehicle = vehicle] ! else NOT_APPROVED_TODAY
  require day(q.approvedAt) = day(now) else NOT_APPROVED_TODAY
  update vehicles[vehicle] { releasedAt: now }
  update presence[plate = q.plate] { inLot: false }
  insert releases { vehicle, plate: q.plate, releasedAt: now, attendant: viewer, storageDays: (now - q.towedAt) / 1d + 1 }
  delete releaseQueue[q.id]
  return null
