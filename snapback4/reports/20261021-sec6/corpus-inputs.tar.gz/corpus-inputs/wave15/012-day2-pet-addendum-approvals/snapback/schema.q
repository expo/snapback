use identity
use personas alice, bob, manager, maintenance, landlord, outsider

table buildings:
  name: text 1..80
  public 'Building names are a directory.'
  insert <- viewer = 'service:ops'
  online only

table residents:
  principal: principal
  building: buildings
  unit: text 1..12
  unique principal
  immutable principal, building, unit
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table staff:
  principal: principal
  building: buildings
  role: enum('manager', 'maintenance', 'landlord')
  unique principal, building
  immutable principal, building, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table applications:
  owner: principal
  building: buildings
  unit: text 1..12
  name: text 1..60
  species: enum('dog', 'cat', 'other')
  notes: text <=500
  photo: image <=5000000
  expiresAt: time
  status: enum('pending', 'approved', 'denied', 'withdrawn') default 'pending'
  withdrawalReason: text <=500 default ''
  decisionReason: text <=500 ?
  at: time default now
  immutable owner, building, unit, name, species, notes, photo, at
  read <- .owner = viewer or exists staff[viewer, .building, role = 'manager'] or exists staff[viewer, .building, role = 'landlord']
  insert <- .owner = viewer and exists residents[viewer, building = .building, unit = .unit]
  update <- .owner = viewer or exists staff[viewer, .building, role = 'manager']
  cap 10 by owner
  online only

table vaccinations:
  application: applications
  owner: principal
  building: buildings
  record: file <=10000000 ('application/pdf', 'image/jpeg', 'image/png')
  expiresAt: time
  unique application
  immutable application, owner, building
  read <- .owner = viewer or exists staff[viewer, .building, role = 'manager'] or exists staff[viewer, .building, role = 'landlord']
  insert <- .owner = viewer and exists applications[.application, owner = viewer, building = .building]
  update <- .owner = viewer
  expire at .expiresAt
  online only

table approvedPets:
  application: applications
  owner: principal
  building: buildings
  unit: text 1..12
  name: text 1..60
  species: enum('dog', 'cat', 'other')
  expiresAt: time
  unique application
  immutable application, owner, building, unit, name, species
  read <- .owner = viewer or exists staff[viewer, .building]
  insert <- exists staff[viewer, .building, role = 'manager']
  update <- .owner = viewer
  delete <- .owner = viewer
  online only

table decisions:
  application: applications
  building: buildings
  actor: principal
  decision: enum('approved', 'denied')
  reason: text 1..500
  at: time default now
  immutable application, building, actor, decision, reason, at
  read <- exists staff[viewer, .building, role = 'manager'] or exists staff[viewer, .building, role = 'landlord']
  insert <- .actor = viewer and exists staff[viewer, .building, role = 'manager']
  online only

table reminders:
  application: applications
  owner: principal
  dueAt: time
  resolved: bool default false
  at: time default now
  unique application, dueAt
  immutable application, owner, dueAt, at
  read <- .owner = viewer
  update <- .owner = viewer
  online only

view petCounts: count approvedPets by .building
  read <- exists staff[viewer, .building, role = 'landlord']

query context():
  return { resident: residents[principal = viewer], roles: staff where .principal = viewer first 50 by .id, buildings: buildings first 50 by .id }
query myApplications():
  return applications where .owner = viewer last 50 by .at
query reviewQueue(building: buildings):
  return applications where .building = building last 100 by .at
query vaccination(application: applications):
  return vaccinations[application = application]
query petDirectory(building: buildings):
  return approvedPets where .building = building first 100 by .unit
query decisionAudit(building: buildings):
  return decisions where .building = building last 100 by .at
query buildingCounts():
  return buildings first 50 by .id { id, name, approved: petCounts[.id] }
query myReminders():
  return reminders where .owner = viewer and .resolved = false last 50 by .at

mutation apply(name: text 1..60, species: enum('dog', 'cat', 'other'), notes: text <=500, photo: image <=5000000, record: file <=10000000 ('application/pdf', 'image/jpeg', 'image/png'), expiresAt: time):
  r = residents[principal = viewer] ! else NOT_RESIDENT
  require expiresAt > now and expiresAt <= now + 3 * 365d else BAD_EXPIRY 'Choose a future expiry within three years.'
  a = insert applications { owner: viewer, building: r.building, unit: r.unit, name, species, notes, photo, expiresAt }
  insert vaccinations { application: a.id, owner: viewer, building: r.building, record, expiresAt }
  return a

mutation decide(application: applications, decision: enum('approved', 'denied'), reason: text 1..500):
  a = applications[application] ! else NOT_FOUND
  require exists staff[viewer, a.building, role = 'manager'] else NOT_MANAGER
  require a.status = 'pending' else ALREADY_DECIDED
  if decision = 'approved':
    require a.expiresAt > now and exists vaccinations[application = application] else VACCINATION_EXPIRED
    insert approvedPets { application, owner: a.owner, building: a.building, unit: a.unit, name: a.name, species: a.species, expiresAt: a.expiresAt }
  update applications[application] { status: decision, decisionReason: reason }
  return insert decisions { application, building: a.building, actor: viewer, decision, reason }

mutation renew(application: applications, record: file <=10000000 ('application/pdf', 'image/jpeg', 'image/png'), expiresAt: time):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else NOT_OWNER
  require a.status = 'pending' or a.status = 'approved' else APPLICATION_CLOSED
  require expiresAt > now and expiresAt > a.expiresAt and expiresAt <= now + 3 * 365d else BAD_EXPIRY
  upsert vaccinations[application = application] { application, owner: viewer, building: a.building, record, expiresAt }
  update applications[application] { expiresAt }
  if exists approvedPets[application = application]:
    update approvedPets[application = application] { expiresAt }
  if exists reminders[application, a.expiresAt]:
    update reminders[application, a.expiresAt] { resolved: true }
  return null

job remindRenewals(periodStart: time, periodEnd: time):
  for a in applications:
    if a.status = 'approved' and a.expiresAt <= periodEnd + 30d:
      if not exists reminders[a.id, a.expiresAt]:
        insert reminders { application: a.id, owner: a.owner, dueAt: a.expiresAt }
schedule renewalDaily every 1d at 08:00: remindRenewals

mutation provisionBuilding(name: text 1..80):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert buildings { name }

mutation enrollResident(principal: principal, building: buildings, unit: text 1..12):
  require viewer = 'service:ops' else NOT_OPERATOR
  b = buildings[building] ! else BUILDING_NOT_FOUND
  return insert residents { principal, building: b.id, unit }

mutation grantStaff(principal: principal, building: buildings, role: enum('manager', 'maintenance', 'landlord')):
  require viewer = 'service:ops' else NOT_OPERATOR
  b = buildings[building] ! else BUILDING_NOT_FOUND
  return insert staff { principal, building: b.id, role }

table withdrawals:
  application: applications
  owner: principal
  building: buildings
  reason: text 1..500
  at: time default now
  unique application
  immutable application, owner, building, reason, at
  read <- .owner = viewer or exists staff[viewer, .building, role = 'manager'] or exists staff[viewer, .building, role = 'landlord']
  insert <- .owner = viewer and exists applications[.application, owner = viewer]
  online only

query withdrawalAudit(building: buildings):
  return withdrawals where .building = building last 100 by .at

mutation withdraw(application: applications, reason: text 1..500):
  a = applications[application] ! else NOT_FOUND
  require a.owner = viewer else NOT_OWNER
  require a.status = 'pending' or a.status = 'approved' else APPLICATION_CLOSED
  if exists approvedPets[application = application]:
    delete approvedPets[application = application]
  if exists reminders[application, a.expiresAt]:
    update reminders[application, a.expiresAt] { resolved: true }
  update applications[application] { status: 'withdrawn', withdrawalReason: reason }
  return insert withdrawals { application, owner: viewer, building: a.building, reason }
