use personas alice, bob, cara, dana, teacher, tech, head

table staff:
  principal: principal
  role: enum('teacher', 'technician', 'head')
  unique principal
  read <- .principal = viewer
  online only

table courses:
  name: text 1..60
  unique name
  public 'Course names are not personal data.'
  online only

table items:
  name: text 1..60
  unitCostCents: int 1..100000
  unique name
  public 'Glassware catalog and replacement prices are shared.'
  online only

table benches:
  label: text 1..40
  course: courses
  year: int 2020..2100
  term: text 1..30
  studentA: principal
  studentB: principal
  unique label, term
  read <- .studentA = viewer or .studentB = viewer or exists staff[principal = viewer, role = 'teacher']
  insert <- exists staff[principal = viewer, role = 'teacher']
  immutable label, course, year, term, studentA, studentB
  online only

table allowances:
  student: principal
  term: text 1..30
  allowanceCents: int 0..100000
  unique student, term
  read <- .student = viewer or exists staff[principal = viewer, role = 'teacher']
  insert <- exists staff[principal = viewer, role = 'teacher']
  immutable student, term, allowanceCents
  online only

table equipment:
  bench: benches
  item: items
  issued: int 1..100
  returned: int 0..100 default 0
  lost: int 0..100 default 0
  unique bench, item
  read through .bench
  insert <- exists staff[principal = viewer, role = 'teacher']
  update <- exists staff[principal = viewer, role = 'teacher']
  immutable bench, item
  online only

table incidents:
  bench: benches
  item: items
  course: courses
  year: int 2020..2100
  term: text 1..30
  studentA: principal
  studentB: principal
  kind: enum('broken', 'missing')
  quantity: int 1..100
  costCents: int 1..10000000
  chargeA: int 0..10000000
  chargeB: int 0..10000000
  photo: image <=5000000 ?
  note: text 1..240
  at: time default now
  read <- exists staff[principal = viewer, role = 'teacher']
  insert <- exists staff[principal = viewer, role = 'teacher']
  online only

view chargedA: sum incidents of .chargeA by .studentA, .term
  read <- .studentA = viewer or exists staff[principal = viewer, role = 'teacher']
view chargedB: sum incidents of .chargeB by .studentB, .term
  read <- .studentB = viewer or exists staff[principal = viewer, role = 'teacher']
view brokenStock: sum incidents of .quantity where .kind = 'broken' by .item
  read <- exists staff[principal = viewer, role = 'technician'] or exists staff[principal = viewer, role = 'teacher']
view missingStock: sum incidents of .quantity where .kind = 'missing' by .item
  read <- exists staff[principal = viewer, role = 'technician'] or exists staff[principal = viewer, role = 'teacher']
view annualCost: sum incidents of .costCents by .course, .year
  read <- exists staff[principal = viewer, role = 'head']
view annualBroken: sum incidents of .quantity where .kind = 'broken' by .course, .year
  read <- exists staff[principal = viewer, role = 'head']
view annualMissing: sum incidents of .quantity where .kind = 'missing' by .course, .year
  read <- exists staff[principal = viewer, role = 'head']

query identity():
  return { principal: viewer, seat: staff[principal = viewer] }
query catalog():
  return items first 100 by .name
query courseList():
  return courses first 50 by .name
query benchList():
  if exists staff[principal = viewer, role = 'teacher']:
    return benches first 100 by .label
  return benches where .studentA = viewer or .studentB = viewer first 100 by .label
query equipmentFor(bench: benches):
  b = benches[bench] ! else BENCH_PRIVATE
  return equipment where .bench = b.id first 100 by .id
query termAllowances(term: text 1..30):
  if exists staff[principal = viewer, role = 'teacher']:
    return allowances where .term = term first 100 by .student { id, student, allowanceCents, usedCents: (chargedA[.student, .term] ?? 0) + (chargedB[.student, .term] ?? 0), feeFlag: (chargedA[.student, .term] ?? 0) + (chargedB[.student, .term] ?? 0) > .allowanceCents }
  return allowances where .student = viewer and .term = term first 100 by .student { id, student, allowanceCents, usedCents: (chargedA[.student, .term] ?? 0) + (chargedB[.student, .term] ?? 0), feeFlag: (chargedA[.student, .term] ?? 0) + (chargedB[.student, .term] ?? 0) > .allowanceCents }
query benchIncidents(bench: benches):
  require exists staff[principal = viewer, role = 'teacher'] else TEACHER_ONLY
  return incidents where .bench = bench last 100 by .at
query replenishment():
  require exists staff[principal = viewer, role = 'technician'] or exists staff[principal = viewer, role = 'teacher'] else STOCKROOM_ONLY
  return items first 100 by .name { id, name, unitCostCents, broken: brokenStock[.id], missing: missingStock[.id] }
query yearlyTotals(year: int 2020..2100):
  require exists staff[principal = viewer, role = 'head'] else HEAD_ONLY
  return courses first 50 by .name { id, name, costCents: annualCost[.id, year], broken: annualBroken[.id, year], missing: annualMissing[.id, year] }

mutation assignBench(label: text 1..40, course: courses, year: int 2020..2100, term: text 1..30, studentA: principal, studentB: principal, allowanceCents: int 0..100000):
  require exists staff[principal = viewer, role = 'teacher'] else TEACHER_ONLY
  c = courses[course] ! else COURSE_NOT_FOUND
  require studentA != studentB else TWO_STUDENTS 'Choose two different students.'
  insert allowances { student: studentA, term, allowanceCents } if absent
  insert allowances { student: studentB, term, allowanceCents } if absent
  return insert benches { label, course, year, term, studentA, studentB }
mutation checkout(bench: benches, item: items, quantity: int 1..100):
  require exists staff[principal = viewer, role = 'teacher'] else TEACHER_ONLY
  b = benches[bench] ! else BENCH_PRIVATE
  i = items[item] ! else ITEM_NOT_FOUND
  e = equipment[bench, item]
  if e != null:
    require e.issued + quantity <= 100 else BENCH_CAPACITY 'At most 100 pieces of each item per bench.'
    update equipment[e.id] { issued: e.issued + quantity }
    return e.id
  row = insert equipment { bench: b.id, item, issued: quantity }
  return row.id
mutation returnGlassware(equipmentId: equipment, quantity: int 1..100):
  require exists staff[principal = viewer, role = 'teacher'] else TEACHER_ONLY
  e = equipment[equipmentId] ! else NOT_FOUND
  require quantity <= e.issued - e.returned - e.lost else TOO_MANY 'Return cannot exceed outstanding glassware.'
  update equipment[e.id] { returned: e.returned + quantity }
  return e.id
mutation logLoss(equipmentId: equipment, kind: enum('broken', 'missing'), quantity: int 1..100, photo: image <=5000000 ?, note: text 1..240):
  require exists staff[principal = viewer, role = 'teacher'] else TEACHER_ONLY
  require kind = 'missing' or photo != null else PHOTO_REQUIRED 'Attach a photo of broken glassware.'
  e = equipment[equipmentId] ! else NOT_FOUND
  b = benches[e.bench] ! else NOT_FOUND
  i = items[e.item] ! else NOT_FOUND
  require quantity <= e.issued - e.returned - e.lost else TOO_MANY 'Loss cannot exceed outstanding glassware.'
  costCents = i.unitCostCents * quantity
  row = insert incidents { bench: b.id, item: i.id, course: b.course, year: b.year, term: b.term, studentA: b.studentA, studentB: b.studentB, kind, quantity, costCents, chargeA: costCents / 2, chargeB: costCents - costCents / 2, photo, note }
  update equipment[e.id] { lost: e.lost + quantity }
  return row
