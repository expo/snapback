use personas alice, bob, director
use identity guests

table directors:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table cars:
  owner: principal
  name: text 1..40
  driverName: text 1..50
  transponder: text 3..20
  class: enum('Touring', 'Buggy', 'Truck')
  hideName: bool default false
  unique transponder
  immutable owner, transponder, class
  read <- .owner = viewer or exists directors[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer
  cap 10 by owner
  online only

table heats:
  title: text 1..60
  class: enum('Touring', 'Buggy', 'Truck')
  season: int 2020..2100
  status: enum('planned', 'running', 'stopped') default 'planned'
  marshal: principal ?
  public 'Heat schedules and marshal assignments are club information.'
  insert <- exists directors[viewer]
  update <- exists directors[viewer]
  immutable class, season
  online only

table entries:
  heat: heats
  car: cars
  carName: text 1..40
  driverLabel: text 1..50
  season: int 2020..2100
  class: enum('Touring', 'Buggy', 'Truck')
  lapCount: int 0.. default 0
  totalMs: int 0.. default 0
  bestMs: int 1.. default 3600000
  disqualified: bool default false
  note: text <=200 default ''
  unique heat, car
  immutable heat, car, season, class
  public 'Live positions show car labels and privacy-safe driver aliases.'
  insert <- exists cars[id = .car, owner = viewer] or exists directors[viewer]
  update <- exists cars[id = .car, owner = viewer] or exists directors[viewer]
  cap 24 by heat
  cap 500 by car
  online only

table laps:
  entry: entries
  number: int 1..
  milliseconds: int 1000..600000
  at: time default now
  unique entry, number
  public 'Transponder lap times are public sporting results.'
  insert <- exists directors[viewer]
  immutable entry, number, milliseconds, at
  online only

table results:
  car: cars
  season: int 2020..2100
  class: enum('Touring', 'Buggy', 'Truck')
  carName: text 1..40
  driverLabel: text 1..50
  bestMs: int 1000..600000
  unique car, season
  public 'Season best laps publish only the driver-approved label.'
  insert <- exists directors[viewer]
  update <- exists directors[viewer] or exists cars[id = .car, owner = viewer]
  delete <- exists directors[viewer]
  immutable car, season, class
  cap 81 by car
  online only

query myCars():
  return cars where .owner = viewer first 10 by .id
query directorCars():
  require exists directors[viewer] else DIRECTOR_ONLY
  return cars first 200 by .id
query myRole():
  return exists directors[viewer]
query heatList():
  return heats last 50 by .id
query positionBoard(heat: heats):
  return entries where .heat = heat first 24 by .id
query lapHistory(entry: entries):
  return laps where .entry = entry last 100 by .number
query seasonBoard(season: int 2020..2100, class: enum('Touring', 'Buggy', 'Truck')):
  return results where .season = season and .class = class first 100 by .bestMs

mutation registerCar(name: text 1..40, driverName: text 1..50, transponder: text 3..20, class: enum('Touring', 'Buggy', 'Truck')):
  return insert cars { owner: viewer, name, driverName, transponder, class }

mutation setPrivacy(car: cars, hideName: bool):
  c = cars[car] ! else NOT_FOUND
  require c.owner = viewer else OWNER_ONLY
  update cars[car] { hideName }
  label = 'Anonymous driver' if hideName else c.driverName
  for e in entries where .car = car:
    update entries[e.id] { driverLabel: label }
  for r in results where .car = car:
    update results[r.id] { driverLabel: label }
  return null

mutation createHeat(title: text 1..60, class: enum('Touring', 'Buggy', 'Truck'), season: int 2020..2100):
  require exists directors[viewer] else DIRECTOR_ONLY
  return insert heats { title, class, season }

mutation assignMarshal(heat: heats, marshal: principal):
  require exists directors[viewer] else DIRECTOR_ONLY
  h = heats[heat] ! else NOT_FOUND
  require h.status != 'stopped' else HEAT_FINISHED
  update heats[heat] { marshal }
  return null

mutation enterHeat(heat: heats, car: cars):
  h = heats[heat] ! else NOT_FOUND
  c = cars[car] ! else NOT_FOUND
  require c.owner = viewer or exists directors[viewer] else OWNER_ONLY
  require h.status = 'planned' else REGISTRATION_CLOSED
  require c.class = h.class else CLASS_MISMATCH
  return insert entries { heat, car, carName: c.name, driverLabel: 'Anonymous driver' if c.hideName else c.driverName, season: h.season, class: h.class }

mutation startHeat(heat: heats):
  require exists directors[viewer] else DIRECTOR_ONLY
  h = heats[heat] ! else NOT_FOUND
  require h.status = 'planned' else INVALID_TRANSITION
  require h.marshal != null else MARSHAL_REQUIRED
  update heats[heat] { status: 'running' }
  return null

mutation stopHeat(heat: heats):
  require exists directors[viewer] else DIRECTOR_ONLY
  h = heats[heat] ! else NOT_FOUND
  require h.status = 'running' else INVALID_TRANSITION
  update heats[heat] { status: 'stopped' }
  return null

mutation recordLap(heat: heats, transponder: text 3..20, milliseconds: int 1000..600000):
  require exists directors[viewer] else DIRECTOR_ONLY
  h = heats[heat] ! else NOT_FOUND
  require h.status = 'running' else HEAT_NOT_RUNNING
  c = cars[transponder = transponder] ! else UNKNOWN_TRANSPONDER
  e = entries[heat, c.id] ! else NOT_ENTERED
  require not e.disqualified else DISQUALIFIED
  lap = insert laps { entry: e.id, number: e.lapCount + 1, milliseconds }
  update entries[e.id] { lapCount: e.lapCount + 1, totalMs: e.totalMs + milliseconds, bestMs: milliseconds if milliseconds < e.bestMs else e.bestMs }
  r = results[c.id, h.season]
  if r = null or milliseconds < r.bestMs:
    upsert results[c.id, h.season] { car: c.id, season: h.season, class: c.class, carName: c.name, driverLabel: 'Anonymous driver' if c.hideName else c.driverName, bestMs: milliseconds }
  return lap

mutation disqualify(entry: entries, note: text 1..200):
  require exists directors[viewer] else DIRECTOR_ONLY
  e = entries[entry] ! else NOT_FOUND
  update entries[entry] { disqualified: true, note }
  if exists results[e.car, e.season]:
    delete results[e.car, e.season]
  for best in entries where .car = e.car and .season = e.season and .disqualified = false and .lapCount > 0 first 1 by .bestMs:
    insert results { car: e.car, season: e.season, class: e.class, carName: best.carName, driverLabel: best.driverLabel, bestMs: best.bestMs }
  return null
