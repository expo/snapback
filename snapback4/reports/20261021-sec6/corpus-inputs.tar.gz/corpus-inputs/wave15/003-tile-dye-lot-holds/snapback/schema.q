use personas alice, bob, manager

table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table projects:
  owner: principal
  name: text 1..80
  immutable owner
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = viewer
  online only

table lots:
  code: text 1..40
  tile: text 1..100
  totalSqft: int 1..100000
  lowAt: int 0..10000
  unique code
  read <- exists staff[viewer] or exists lotHolders[.id, viewer]
  insert <- exists staff[viewer]
  online only

table holds:
  project: projects
  owner: principal
  lot: lots
  sqft: int 1..100000
  expiresAt: time
  unique project else PROJECT_ALREADY_HELD 'A project can hold only one dye lot.'
  immutable project, owner, lot, sqft
  read <- .owner = viewer or exists staff[viewer]
  insert <- .owner = .project.owner and (.owner = viewer or exists staff[viewer])
  update <- exists staff[viewer]
  delete <- .owner = viewer or exists staff[viewer]
  expire at .expiresAt
  online only

view lotHolders: count holds by .lot, .owner
  read <- .owner = viewer or exists staff[viewer]

view reserved: sum holds of .sqft by .lot
  read <- exists staff[viewer] or exists lotHolders[.lot, viewer]

table notices:
  hold: holds on delete cascade
  owner: principal
  message: text 1..200
  at: time
  unique hold
  immutable hold, owner, message, at
  read <- .owner = viewer or exists staff[viewer]
  online only

query myProjects():
  if exists staff[viewer]:
    return projects first 100 by .id
  return projects where .owner = viewer first 100 by .id

query myHolds():
  if exists staff[viewer]:
    return holds first 100 by .id { id, project, owner, lot: lots[.lot], sqft, expiresAt }
  return holds where .owner = viewer first 100 by .id { id, project, owner, lot: lots[.lot], sqft, expiresAt }

query inventory():
  require exists staff[viewer] else MANAGER_ONLY
  return lots first 100 by .id { id, code, tile, totalSqft, lowAt, remaining: .totalSqft - reserved[.id] }

query myNotices():
  if exists staff[viewer]:
    return notices last 100 by .at
  return notices where .owner = viewer last 100 by .at

mutation createProject(name: text 1..80):
  return insert projects { owner: viewer, name }

mutation addLot(code: text 1..40, tile: text 1..100, totalSqft: int 1..100000, lowAt: int 0..10000):
  require exists staff[viewer] else MANAGER_ONLY
  require lowAt <= totalSqft else BAD_THRESHOLD
  return insert lots { code, tile, totalSqft, lowAt }

mutation placeHold(project: projects, lot: lots, sqft: int 1..100000):
  p = projects[project] ! else PROJECT_NOT_FOUND
  -- Insert first grants the owner access to this lot inside the transaction.
  -- A capacity refusal rolls the entire transaction back, including this row.
  h = insert holds { project, owner: p.owner, lot, sqft, expiresAt: now + 14d }
  l = lots[lot] ! else LOT_NOT_FOUND
  used = reserved[lot]
  require used != null else STOCK_UNAVAILABLE
  require used <= l.totalSqft else INSUFFICIENT_STOCK 'This dye lot does not have enough available square footage.'
  return h

mutation releaseHold(hold: holds):
  delete holds[hold]

mutation extendHold(hold: holds, days: int 1..30):
  require exists staff[viewer] else MANAGER_ONLY
  h = holds[hold] ! else HOLD_NOT_FOUND
  update holds[hold] { expiresAt: h.expiresAt + days * 1d }

job lowStock():
  for h in holds:
    l = lots[h.lot] ! else LOT_NOT_FOUND
    if l.totalSqft - reserved[h.lot] <= l.lowAt:
      if not exists notices[h.id]:
        insert notices { hold: h.id, owner: h.owner, message: 'Your held dye lot is nearly exhausted. Contact the showroom before increasing your order.', at: now }

schedule stockAlerts every 1m: lowStock

query heldLot(lot: lots):
  return lots[lot]
