use identity password
-- Daycare Milk Bottles.
--
-- Parents register bottles of breast milk dropped off at daycare (expressed
-- date + a photo of the label). Room staff see only bottles for children in
-- their own room. A background job flags bottles that pass their safe-use
-- window (72h after expression) as discarded. Each feeding records which
-- staff member gave it and which bottle was used. Parents see their own
-- child's bottles and feeding log; the director sees discarded counts
-- per room.
--
-- Cast (dev personas):
--   alice  - parent of Mia (room sunflowers)
--   bob    - staff in room sunflowers
--   carol  - staff in room bluebirds (another room: must NOT see sunflowers)
--   diana  - director (sees discard counts per room)

use personas alice, bob, carol, diana

-- The director roster. Seeded as the system (fixtures / /dev/reset seed);
-- nobody can self-appoint.
table directors:
  principal: principal
  unique principal
  immutable principal
  read <- (
 .principal = viewer
  ) or viewer = 'service:ops'
  insert <- (
 deny
  ) or viewer = 'service:ops'
  update <- deny
  delete <- deny
  online only

-- Room staff roster. Only the director manages it.
table staff:
  principal: principal
  room: enum('sunflowers', 'bluebirds')
  unique principal, room
  immutable principal, room
  read <- (
 .principal = viewer or exists directors[viewer]
  ) or viewer = 'service:ops'
  insert <- (
 exists directors[viewer]
  ) or viewer = 'service:ops'
  update <- exists directors[viewer]
  delete <- exists directors[viewer]
  online only

-- Enrolled children. Only the director enrolls.
table children:
  name: text 1..80
  room: enum('sunflowers', 'bluebirds')
  parent: principal
  immutable room, parent
  read <- .parent = viewer or exists staff[viewer, .room] or exists directors[viewer]
  insert <- exists directors[viewer]
  update <- exists directors[viewer]
  delete <- exists directors[viewer]
  online only

-- Bottles of expressed milk. `room` is copied from the child at
-- registration (immutable) so staff scoping and the director's per-room
-- counts never depend on a hop.
table bottles:
  child: children
  room: enum('sunflowers', 'bluebirds')
  expressedAt: time
  photo: image <=5000000 ?
  volumeMl: int 1..500 default 120
  droppedAt: time default now
  status: enum('stored', 'used', 'discarded') default 'stored'
  immutable child, room, expressedAt, photo
  read <- exists children[.child, parent = viewer] or exists staff[viewer, .room] or exists directors[viewer]
  insert <- exists children[.child, parent = viewer]
  update <- exists staff[viewer, .room] or exists directors[viewer]
  delete <- deny
  online only

-- Staff incident reports on a bottle (spill, spoilage, label problem).
-- Parents see reports on their own child's bottles, room staff their room,
-- the director everything.
table incidents:
  bottle: bottles on delete restrict
  child: children
  room: enum('sunflowers', 'bluebirds')
  reportedBy: principal
  kind: enum('spill', 'spoilage', 'label')
  detail: text 1..280 ?
  reportedAt: time default now
  immutable bottle, child, room, reportedBy, kind
  read <- exists children[.child, parent = viewer] or exists staff[viewer, .room] or exists directors[viewer]
  insert <- exists staff[viewer, .room]
  update <- deny
  delete <- deny
  online only

-- Feeding log: which staff member gave which bottle.
table feedings:
  bottle: bottles on delete restrict
  child: children
  room: enum('sunflowers', 'bluebirds')
  fedBy: principal
  fedAt: time default now
  amountMl: int 1..500 ?
  immutable bottle, child, room, fedBy
  read <- exists children[.child, parent = viewer] or exists staff[viewer, .room] or exists directors[viewer]
  insert <- exists staff[viewer, .room]
  update <- deny
  delete <- deny
  online only

-- Maintained per-room count of discarded bottles, for the director.
view discardedByRoom: count bottles where .status = 'discarded' by .room
  read <- exists directors[viewer]

-- A bottle passes its safe-use window 72h after expression. The sweep
-- covers bottles whose deadline falls inside the schedule period, so a
-- rerun of the same period writes nothing new.
job flagExpired(periodStart: time, periodEnd: time):
  for b in bottles where .expressedAt >= periodStart - 72h and .expressedAt < periodEnd - 72h by .expressedAt:
    if b.status = 'stored':
      update bottles[b.id] { status: 'discarded' }

schedule flagExpiredHourly every 1h: flagExpired

query whoAmI():
  return viewer

-- Read queries carry no `require` guards: the tables' read rules decide
-- visibility, so an unauthorized caller gets a complete empty page (and
-- every query stays green for every persona) while never seeing a hidden
-- row. Mutations below carry the explicit refusal codes.
query childBottles(child: children, c: cursor ?):
  return bottles where .child = child last 50 by .droppedAt after c

-- Bottles currently in a room. Staff see only their own room; anyone
-- else gets an empty page.
query roomBottles(room: enum('sunflowers', 'bluebirds'), c: cursor ?):
  return bottles where .room = room last 50 by .droppedAt after c

-- A child's feeding log: the parent sees their own child, room staff see
-- their room, the director sees everything.
query childFeedings(child: children, c: cursor ?):
  return feedings where .child = child last 50 by .fedAt after c

-- Incident reports on a child's bottles. Same audience as the feeding log.
query childIncidents(child: children, c: cursor ?):
  return incidents where .child = child last 50 by .reportedAt after c

-- Discarded bottle counts per room. Only the director's read rule on the
-- view admits rows; anyone else gets a complete empty page.
query discardCounts(c: cursor ?):
  return discardedByRoom last 10 by .room after c

-- A parent registers a bottle for their own child. Every registered
-- bottle carries a photo of its label and the millilitres of milk in it.
mutation registerBottle(child: children, expressedAt: time, photo: image <=5000000 ?, volumeMl: int 1..500):
  kid = children[child] ! else NOT_FOUND
  require kid.parent = viewer else NOT_YOUR_CHILD 'Only the child\'s parent can register a bottle.'
  require photo != null else PHOTO_REQUIRED 'A photo of the bottle label is required.'
  require expressedAt <= now else EXPRESSED_IN_FUTURE 'The expressed date cannot be in the future.'
  require expressedAt >= now - 30d else TOO_OLD 'A bottle expressed more than 30 days ago cannot be dropped off.'
  return insert bottles { child, room: kid.room, expressedAt, photo, volumeMl }

-- Room staff record giving a bottle to a child. The bottle is consumed.
-- The recorded amount cannot exceed what the bottle holds.
mutation recordFeeding(bottle: bottles, amountMl: int 1..500 ?):
  b = bottles[bottle] ! else NOT_FOUND
  require exists staff[viewer, b.room] else NOT_ROOM_STAFF 'Only staff of the bottle\'s room can feed it.'
  require b.status = 'stored' else BOTTLE_UNAVAILABLE 'Only a stored bottle can be fed.'
  require amountMl = null or amountMl <= b.volumeMl else TOO_MUCH 'Cannot feed more milk than the bottle holds.'
  update bottles[bottle] { status: 'used' }
  return insert feedings { bottle, child: b.child, room: b.room, fedBy: viewer }

-- Room staff file an incident report on a bottle (spill, spoilage, label
-- problem). The bottle itself is untouched; discarding stays separate.
mutation reportIncident(bottle: bottles, kind: enum('spill', 'spoilage', 'label'), detail: text 1..280 ?):
  b = bottles[bottle] ! else NOT_FOUND
  require exists staff[viewer, b.room] else NOT_ROOM_STAFF 'Only staff of the bottle\'s room can report an incident.'
  return insert incidents { bottle, child: b.child, room: b.room, reportedBy: viewer, kind, detail }

-- Room staff discard a bottle by hand (spoilage, recall, ...). The
-- background job handles the safe-use window on its own.
mutation discardBottle(bottle: bottles):
  b = bottles[bottle] ! else NOT_FOUND
  require exists staff[viewer, b.room] else NOT_ROOM_STAFF 'Only staff of the bottle\'s room can discard it.'
  require b.status = 'stored' else BOTTLE_UNAVAILABLE 'Only a stored bottle can be discarded.'
  update bottles[bottle] { status: 'discarded' }

-- The director enrolls a child (production write path for the children
-- table; in dev this is seeded). The parent is a real account principal.
mutation enrollChild(name: text 1..80, room: enum('sunflowers', 'bluebirds'), parent: principal):
  require exists directors[viewer] else NOT_DIRECTOR 'Only the director can enroll a child.'
  return insert children { name, room, parent }

-- The director adds room staff (production write path beyond the first
-- seat-bootstrapped row).
mutation addStaff(principal: principal, room: enum('sunflowers', 'bluebirds')):
  require exists directors[viewer] else NOT_DIRECTOR 'Only the director can add staff.'
  return insert staff { principal, room }

mutation bootstrapdirectors(seat_principal: principal):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert directors { principal: seat_principal }

mutation bootstrapstaff(seat_principal: principal, seat_room: enum('sunflowers', 'bluebirds')):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert staff { principal: seat_principal, room: seat_room }
