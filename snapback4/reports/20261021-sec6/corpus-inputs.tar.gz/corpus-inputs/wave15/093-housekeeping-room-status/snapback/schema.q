use personas alice, bob, sara, dana, morgan

table staff:
  principal: principal
  name: text 1..60
  role: enum('housekeeper', 'supervisor', 'frontdesk', 'manager')
  unique principal
  read <- exists staff[viewer]
  online only

table rooms:
  number: text 1..8
  floor: int 1..12
  kind: enum('Queen', 'King', 'Twin', 'Suite')
  status: enum('dirty', 'cleaning', 'inspected', 'ready') default 'dirty'
  rush: bool default false
  cleaner: principal ?
  startedAt: time ?
  activeCleaning: cleanings ?
  unique number
  immutable number, floor, kind
  read <- exists staff[viewer]
  insert <- exists staff[viewer, role = 'manager']
  update <- exists staff[viewer]
  online only

table cleanings:
  room: rooms
  cleaner: principal
  startedAt: time
  finishedAt: time ?
  durationMs: int 0.. default 0
  immutable room, cleaner, startedAt
  read <- exists staff[viewer]
  insert <- .cleaner = viewer and exists staff[viewer, role = 'housekeeper']
  update <- .cleaner = viewer and exists staff[viewer, role = 'housekeeper']
  online only

table inspections:
  room: rooms
  inspector: principal
  photo: image <=5000000
  linen: bool
  bathroom: bool
  amenities: bool
  at: time default now
  read <- exists staff[viewer]
  insert <- .inspector = viewer and exists staff[viewer, role = 'supervisor'] and .linen = true and .bathroom = true and .amenities = true
  online only

table maintenance:
  room: rooms
  reporter: principal
  detail: text 3..500
  priority: enum('normal', 'urgent')
  resolved: bool default false
  at: time default now
  immutable room, reporter, detail, priority, at
  read <- exists staff[viewer]
  insert <- .reporter = viewer and exists staff[viewer]
  update <- exists staff[viewer, role = 'supervisor'] or exists staff[viewer, role = 'manager']
  online only

query team():
  require exists staff[viewer] else STAFF_ONLY
  return staff first 50 by .name

query me():
  return staff[viewer]

query board():
  require exists staff[viewer] else STAFF_ONLY
  return rooms first 200 by .number

query cleaningHistory():
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY
  return cleanings last 200 by .startedAt

query cleaningStats(cleaner: principal):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY
  n = count(cleanings where .cleaner = cleaner and .finishedAt != null)
  total = sum(cleanings where .cleaner = cleaner and .finishedAt != null, .durationMs)
  return { count: n, totalMs: total, averageMs: total / n if n > 0 else 0 }

query inspectionHistory():
  require exists staff[viewer] else STAFF_ONLY
  return inspections last 100 by .at

query maintenanceQueue():
  require exists staff[viewer] else STAFF_ONLY
  return maintenance last 200 by .at

mutation addRoom(number: text 1..8, floor: int 1..12, kind: enum('Queen', 'King', 'Twin', 'Suite')):
  require exists staff[viewer, role = 'manager'] else MANAGER_ONLY
  return insert rooms { number, floor, kind }

mutation claim(room: rooms):
  require exists staff[viewer, role = 'housekeeper'] else HOUSEKEEPER_ONLY
  r = rooms[room] ! else NOT_FOUND
  require r.status = 'dirty' else ROOM_UNAVAILABLE 'This room has already been claimed.'
  c = insert cleanings { room, cleaner: viewer, startedAt: now }
  update rooms[room] { status: 'cleaning', cleaner: viewer, startedAt: now, activeCleaning: c.id }

mutation finish(room: rooms):
  require exists staff[viewer, role = 'housekeeper'] else HOUSEKEEPER_ONLY
  r = rooms[room] ! else NOT_FOUND
  require r.status = 'cleaning' and r.cleaner = viewer else NOT_YOUR_ROOM
  require r.activeCleaning != null else NO_CLEANING
  c = cleanings[r.activeCleaning] ! else NOT_FOUND
  update cleanings[c] { finishedAt: now, durationMs: now - c.startedAt }
  update rooms[room] { status: 'inspected' }

mutation inspect(room: rooms, photo: image <=5000000, linen: bool, bathroom: bool, amenities: bool):
  require exists staff[viewer, role = 'supervisor'] else SUPERVISOR_ONLY
  r = rooms[room] ! else NOT_FOUND
  require r.status = 'inspected' else NOT_AWAITING_INSPECTION
  require linen and bathroom and amenities else CHECKLIST_INCOMPLETE
  require count(maintenance where .room = room and .resolved = false) = 0 else MAINTENANCE_OPEN 'Resolve maintenance issues before releasing this room.'
  insert inspections { room, inspector: viewer, photo, linen, bathroom, amenities }
  update rooms[room] { status: 'ready', rush: false }

mutation requestRush(room: rooms):
  require exists staff[viewer, role = 'frontdesk'] else FRONTDESK_ONLY
  r = rooms[room] ! else NOT_FOUND
  require r.status != 'ready' else ALREADY_READY
  update rooms[room] { rush: true }

mutation reportIssue(room: rooms, detail: text 3..500, priority: enum('normal', 'urgent')):
  require exists staff[viewer] else STAFF_ONLY
  r = rooms[room] ! else NOT_FOUND
  return insert maintenance { room, reporter: viewer, detail, priority }

mutation resolveIssue(issue: maintenance):
  require exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'supervisor'] else SUPERVISOR_ONLY
  update maintenance[issue] { resolved: true }
