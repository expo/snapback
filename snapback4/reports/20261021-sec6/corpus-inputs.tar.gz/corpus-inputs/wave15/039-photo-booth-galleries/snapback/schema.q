use personas company, alice, bob, guest
use identity

table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- viewer = 'service:ops'
  online only

table events:
  host: principal
  title: text 3..100
  eventAt: time
  expiresAt: time
  immutable host, eventAt
  read <- .host = viewer or exists staff[viewer] or exists visitors[.id, viewer]
  insert <- exists staff[viewer]
  update <- exists staff[viewer]
  expire at .expiresAt
  online only

table galleryLinks:
  event: events on delete keep
  secret: text 32..100
  unique event
  unique secret
  immutable event, secret
  read <- exists events[.event]
  insert <- exists staff[viewer]
  online only

table visitors:
  event: events on delete keep
  principal: principal
  unique event, principal
  immutable event, principal
  read <- .principal = viewer
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table photos:
  event: events on delete keep
  caption: text 1..100
  preview: image <=2000000
  hidden: bool default false
  immutable event, preview, caption
  read <- exists events[.event] and (exists events[.event, host = viewer] or exists staff[viewer] or (.hidden = false and exists visitors[.event, viewer]))
  insert <- exists staff[viewer]
  update <- exists events[.event, host = viewer]
  online only

table originals:
  photo: photos on delete keep
  event: events on delete keep
  strip: file <=15000000 ('image/png', 'image/jpeg')
  unique photo
  immutable photo, event, strip
  read <- exists events[.event] and (exists events[.event, host = viewer] or exists staff[viewer] or (exists photos[.photo, hidden = false] and exists downloads[.photo, viewer]))
  insert <- exists staff[viewer] and .event = .photo.event
  online only

table stripLinks:
  photo: photos on delete keep
  event: events on delete keep
  secret: text 32..100
  unique secret
  immutable photo, event, secret
  read <- exists events[.event]
  insert <- exists staff[viewer] and .event = .photo.event
  online only

table downloads:
  photo: photos on delete keep
  event: events on delete keep
  principal: principal
  unique photo, principal
  immutable photo, event, principal
  read <- .principal = viewer
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table payments:
  event: events on delete keep
  host: principal
  status: enum('requested', 'paid') default 'requested'
  receipt: text 3..120 ?
  requestedAt: time default now
  unique receipt
  immutable event, host, requestedAt
  read <- .host = viewer or exists staff[viewer]
  insert <- .host = viewer and exists events[.event, host = viewer] and .status = 'requested'
  update <- exists staff[viewer]
  online only

query myEvents():
  return events where .host = viewer first 100 by .expiresAt
query companyEvents():
  require exists staff[viewer] else COMPANY_ONLY
  return events first 100 by .expiresAt
query expiringEvents():
  require exists staff[viewer] else COMPANY_ONLY
  return events where .expiresAt > now and .expiresAt <= now + 7d first 100 by .expiresAt
query gallery(event: events):
  return events[event]
query galleryPhotos(event: events, hidden: bool):
  e = events[event] ! else NOT_FOUND
  if hidden:
    require e.host = viewer or exists staff[viewer] else HOST_ONLY
  return photos where .event = event and .hidden = hidden first 200 by .id
query original(photo: photos):
  return originals[photo = photo]
query paymentRequests():
  if exists staff[viewer]:
    return payments first 100 by .requestedAt
  return payments where .host = viewer first 100 by .requestedAt
query galleryLink(event: events):
  e = events[event] ! else NOT_FOUND
  require e.host = viewer or exists staff[viewer] else HOST_ONLY
  return galleryLinks[event = event] { secret }

mutation createEvent(host: principal, title: text 3..100, eventAt: time, secret: text 32..100):
  require exists staff[viewer] else COMPANY_ONLY
  require eventAt >= now - 29d and eventAt <= now + 365d else BAD_EVENT_DATE
  e = insert events { host, title, eventAt, expiresAt: eventAt + 30d }
  insert galleryLinks { event: e.id, secret }
  return e
mutation enterGallery(secret: text 32..100):
  link = galleryLinks[secret = secret] ! else BAD_GALLERY_CODE
  upsert visitors[event = link.event, principal = viewer] { event: link.event, principal: viewer }
  return link.event
mutation uploadStrip(event: events, caption: text 1..100, preview: image <=2000000, strip: file <=15000000 ('image/png', 'image/jpeg'), secret: text 32..100):
  require exists staff[viewer] else COMPANY_ONLY
  e = events[event] ! else NOT_FOUND
  p = insert photos { event: e.id, caption, preview }
  insert originals { photo: p.id, event: e.id, strip }
  insert stripLinks { photo: p.id, event: e.id, secret }
  return p
mutation setHidden(photo: photos, hidden: bool):
  p = photos[photo] ! else NOT_FOUND
  require exists events[p.event, host = viewer] else HOST_ONLY
  update photos[photo] { hidden }
mutation unlockStrip(secret: text 32..100):
  link = stripLinks[secret = secret] ! else BAD_STRIP_CODE
  require exists visitors[link.event, viewer] else ENTER_GALLERY_FIRST
  p = photos[link.photo] ! else PHOTO_UNAVAILABLE
  require not p.hidden else PHOTO_UNAVAILABLE
  if not exists downloads[p.id, viewer]:
    insert downloads { photo: p.id, event: p.event, principal: viewer }
  return p.id
mutation requestExtension(event: events):
  e = events[event] ! else NOT_FOUND
  require e.host = viewer else HOST_ONLY
  return insert payments { event: e.id, host: viewer }
mutation confirmPayment(payment: payments, receipt: text 3..120):
  require exists staff[viewer] else COMPANY_ONLY
  p = payments[payment] ! else NOT_FOUND
  require p.status = 'requested' else ALREADY_PAID
  e = events[p.event] ! else NOT_FOUND
  update payments[payment] { status: 'paid', receipt }
  update events[e.id] { expiresAt: e.expiresAt + 30d }

-- Access ends immediately at the event deadline; dependent bytes and grants
-- are reclaimed by resumable sweeps without bounding event attendance.
job cleanupExpired():
  for r in originals:
    if not exists events[r.event]:
      delete originals[r.id]
  for r in stripLinks:
    if not exists events[r.event]:
      delete stripLinks[r.id]
  for r in downloads:
    if not exists events[r.event]:
      delete downloads[r.id]
  for r in photos:
    if not exists events[r.event]:
      delete photos[r.id]
  for r in galleryLinks:
    if not exists events[r.event]:
      delete galleryLinks[r.id]
  for r in visitors:
    if not exists events[r.event]:
      delete visitors[r.id]
  for r in payments:
    if not exists events[r.event]:
      delete payments[r.id]
schedule reclaim every 1m: cleanupExpired

mutation provisionCompany(principal: principal):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert staff { principal }
