use personas alice, bob, carol, dave, emma, finn, grace, hank, moderator

table moderators:
  principal: principal
  unique principal
  read <- .principal = viewer
  insert <- deny
  online only

table profiles:
  principal: principal
  name: text 2..24
  hidden: bool default false
  unique principal
  immutable principal
  public 'Player display names and ranking preference.'
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table passages:
  title: text 2..60
  body: text 40..300
  public 'Everyone races the same curated passage.'
  insert <- deny
  online only

table races:
  host: principal
  title: text 3..60
  passage: passages
  status: enum('waiting', 'racing', 'finished') default 'waiting'
  createdAt: time
  startsAt: time ?
  endsAt: time ?
  season: int
  immutable host, passage, createdAt, season
  public 'Open race rooms and results.'
  insert <- .host = viewer
  update <- .host = viewer or exists entries[.id, viewer]
  online only

table entries:
  race: races
  player: principal
  position: int 0..300 default 0
  attempts: int 0..2000 default 0
  mistakes: int 0..2000 default 0
  finishedAt: time ?
  unique race, player
  immutable race, player
  cap 8 by race
  public 'Live race progress; hidden players remain visible inside a race.'
  insert <- .player = viewer
  update <- .player = viewer
  online only

table results:
  race: races
  player: principal
  wpm: int 0..240
  accuracy: int 0..100
  place: int 1..8
  delta: int -84..84
  at: time
  season: int
  unique race, player
  immutable race, player, wpm, accuracy, place, delta, at, season
  read <- .player = viewer or exists profiles[principal = .player, hidden = false] or exists moderators[viewer]
  insert <- exists entries[.race, .player]
  update <- .player = viewer
  delete <- exists moderators[viewer]
  online only

view ratingChanges: sum results of .delta by .player, .season
  read <- .player = viewer or exists profiles[principal = .player, hidden = false] or exists moderators[viewer]
  online only

query me():
  p = profiles[principal = viewer]
  return { profile: p, rating: 1000 + (ratingChanges[viewer, month(now)] ?? 0), season: month(now), moderator: exists moderators[viewer] }
query passageList():
  return passages first 20 by .id
query lobby():
  return races last 30 by .createdAt { *, players: count(entries[race = .id]) }
query raceScreen(race: races):
  r = races[race] ! else NOT_FOUND
  return { race: r, passage: passages[r.passage], entries: entries where .race = race first 8 by .id { *, name: profiles[principal = .player].name }, results: results where .race = race first 8 by .place, serverNow: now }
query leaderboard(weekly: bool):
  if weekly:
    return results where exists profiles[principal = .player, hidden = false] and .at >= (day(now) - (day(now) + 3) % 7) * 1d last 20 by .wpm { *, name: profiles[principal = .player].name }
  return results where exists profiles[principal = .player, hidden = false] last 20 by .wpm { *, name: profiles[principal = .player].name }
query seasonLadder():
  return ratingChanges where exists profiles[principal = .player, hidden = false] and .season = month(now) last 20 by .value { player, value: .value + 1000, name: profiles[principal = .player].name }
query myResults():
  return results where .player = viewer last 30 by .at

mutation saveProfile(name: text 2..24, hidden: bool): server
  upsert profiles[principal = viewer] { principal: viewer, name, hidden }
  return null
mutation createRace(title: text 3..60, passage: passages): server
  require exists profiles[principal = viewer] else PROFILE_REQUIRED
  require exists passages[passage] else NOT_FOUND
  r = insert races { host: viewer, title, passage, createdAt: now, season: month(now) }
  insert entries { race: r.id, player: viewer }
  return r
mutation joinRace(race: races): server
  require exists profiles[principal = viewer] else PROFILE_REQUIRED
  r = races[race] ! else NOT_FOUND
  require r.status = 'waiting' else RACE_STARTED
  require not exists entries[race, viewer] else ALREADY_JOINED
  require count(entries where .race = race) < 8 else RACE_FULL
  return insert entries { race, player: viewer }
mutation startRace(race: races): server
  r = races[race] ! else NOT_FOUND
  require r.host = viewer else HOST_ONLY
  require r.status = 'waiting' else RACE_STARTED
  require count(entries where .race = race) >= 2 else NEED_OPPONENT
  update races[race] { status: 'racing', startsAt: now + 3s, endsAt: now + 123s }
  return null
mutation typeKeys(race: races, keys: text 1..80): server
  r = races[race] ! else NOT_FOUND
  e = entries[race, viewer] ! else NOT_RACER
  require r.status = 'racing' and r.startsAt != null and r.endsAt != null else NOT_RACING
  require now >= r.startsAt else COUNTDOWN
  require now < r.endsAt else TIME_UP
  require e.finishedAt = null else ALREADY_FINISHED
  require e.attempts + len(keys) <= 2000 else TOO_MANY_KEYS
  require now - r.startsAt >= (e.attempts + len(keys)) * 50 else TOO_FAST 'Maximum accepted typing rate is 240 WPM.'
  p = passages[r.passage] ! else NOT_FOUND
  pos = e.position
  mistakes = e.mistakes
  for i in range(0, len(keys)):
    require pos < len(p.body) else EXTRA_KEYS
    if slice(keys, i, i + 1) = slice(p.body, pos, pos + 1):
      pos = pos + 1
    else:
      mistakes = mistakes + 1
  update entries[e] { position: pos, attempts: e.attempts + len(keys), mistakes, finishedAt: now if pos = len(p.body) else null }
  return null
mutation settleRace(race: races): server
  r = races[race] ! else NOT_FOUND
  require exists entries[race, viewer] else NOT_RACER
  require r.status = 'racing' and r.startsAt != null and r.endsAt != null else NOT_RACING
  racers = entries where .race = race
  require now >= r.endsAt or count(entries where .race = race and .finishedAt = null) = 0 else STILL_RACING
  for e in racers:
    wins = 0
    losses = 0
    for other in racers:
      if e.position > other.position or (e.position = other.position and e.finishedAt != null and (other.finishedAt = null or e.finishedAt < other.finishedAt)):
        wins = wins + 1
      if e.position < other.position or (e.position = other.position and other.finishedAt != null and (e.finishedAt = null or other.finishedAt < e.finishedAt)):
        losses = losses + 1
    elapsed = max(1, (e.finishedAt ?? r.endsAt) - r.startsAt)
    speed = min(240, e.position * 12000 / elapsed)
    accuracy = e.position * 100 / max(1, e.attempts)
    delta = (wins - losses) * 12
    insert results { race, player: e.player, wpm: speed, accuracy, place: losses + 1, delta, at: now, season: r.season }
  update races[race] { status: 'finished' }
  return null
mutation removeResult(result: results): server
  require exists moderators[viewer] else MODERATOR_ONLY
  r = results[result] ! else NOT_FOUND
  delete results[r]
  return null
