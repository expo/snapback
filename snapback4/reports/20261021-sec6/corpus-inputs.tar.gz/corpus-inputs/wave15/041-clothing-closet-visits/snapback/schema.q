use personas alice, bob, volunteer, coordinator, donor
use identity guests

table staff:
  principal: principal
  role: enum('volunteer', 'coordinator')
  unique principal
  read <- .principal = viewer
  online only

table households:
  number: int 1000..9999
  owner: principal
  members: int 1..8
  neededSize: enum('Baby', 'Kids', 'XS', 'S', 'M', 'L', 'XL', '2XL+')
  unique number
  unique owner
  immutable number, owner, members, neededSize
  read <- .owner = viewer or exists staff[principal = viewer, role = 'volunteer']
  online only

table visits:
  household: households
  owner: principal
  number: int 1000..9999
  members: int 1..8
  neededSize: enum('Baby', 'Kids', 'XS', 'S', 'M', 'L', 'XL', '2XL+')
  month: int
  at: time
  items: int 0..48 default 0
  unique household, month
  immutable household, owner, number, members, neededSize, month, at
  read <- .owner = viewer or exists staff[principal = viewer, role = 'volunteer']
  insert <- exists staff[principal = viewer, role = 'volunteer'] and exists households[.household, owner = .owner, number = .number, members = .members, neededSize = .neededSize] and .items = 0
  update <- exists staff[principal = viewer, role = 'volunteer']
  online only

view donationCounts: count visits by .month, .neededSize
  public 'Anonymous monthly size demand guides public donation requests.'
  disclosure reviewed 'Only month, clothing size and household counts are released.'
  online only
view householdCounts: count visits by .month, .members, .neededSize
  read <- exists staff[principal = viewer, role = 'coordinator']
  disclosure reviewed 'The coordinator sees anonymous counts by household and clothing sizes.'
  online only

query myHousehold():
  return households[owner = viewer] { number, members, neededSize }
query myHistory():
  return visits where .owner = viewer last 24 by .at { id, number, month, at, items, allowance: .members * 6 }
query lookup(number: int 1000..9999):
  require exists staff[principal = viewer, role = 'volunteer'] else VOLUNTEER_ONLY
  h = households[number = number] ! else HOUSEHOLD_NOT_FOUND
  v = visits[h.id, month(now)] { id, items }
  return { household: h.id, number: h.number, members: h.members, neededSize: h.neededSize, allowance: h.members * 6, visit: v, remaining: h.members * 6 - (v.items ?? 0) }
query currentVisits():
  require exists staff[principal = viewer, role = 'volunteer'] else VOLUNTEER_ONLY
  return visits where .month = month(now) last 100 by .at { id, number, members, items, remaining: .members * 6 - .items, at }
query donationNeeds():
  return donationCounts where .month = month(now) last 8 by .value { size: .neededSize, households: .value }
query anonymousSummary():
  require exists staff[principal = viewer, role = 'coordinator'] else COORDINATOR_ONLY
  return householdCounts where .month = month(now) last 64 by .value { members, size: .neededSize, households: .value }
query currentMonth():
  return month(now)

mutation checkIn(number: int 1000..9999):
  require exists staff[principal = viewer, role = 'volunteer'] else VOLUNTEER_ONLY
  h = households[number = number] ! else HOUSEHOLD_NOT_FOUND
  require not exists visits[h.id, month(now)] else ALREADY_VISITED 'This household has already checked in this month.'
  v = insert visits { household: h.id, owner: h.owner, number: h.number, members: h.members, neededSize: h.neededSize, month: month(now), at: now, items: 0 }
  return { id: v.id, number: v.number, items: v.items }
mutation addItems(visit: visits, quantity: int 1..48):
  require exists staff[principal = viewer, role = 'volunteer'] else VOLUNTEER_ONLY
  v = visits[visit] ! else VISIT_NOT_FOUND
  require v.month = month(now) else MONTH_CLOSED 'Only the current month can be changed.'
  require v.items + quantity <= v.members * 6 else MONTHLY_LIMIT 'That would exceed the household monthly allowance.'
  update visits[visit] { items: v.items + quantity }
  return { items: v.items + quantity, remaining: v.members * 6 - v.items - quantity }
