use identity
use personas alice, bob, carol

table studies:
  owner: principal
  coauthor: principal
  title: text 3..160
  sealedAt: time ?
  sealed: bool default false
  releaseAt: time
  published: bool default false
  withdrawn: bool default false
  immutable owner, coauthor
  read <- .owner = viewer or .coauthor = viewer or .sealed = true
  insert <- .owner = viewer and .sealedAt = null and .sealed = false and .published = false and .withdrawn = false
  update (old, next) <- old.owner = viewer and (old.sealedAt = null or (next.title = old.title and next.sealedAt = old.sealedAt and next.sealed = old.sealed and next.releaseAt = old.releaseAt)) and (old.published = false or next.published = true) and (old.withdrawn = false or next.withdrawn = true)
  online only

table plans:
  study: studies
  owner: principal
  hypotheses: text 10..8000
  analysis: text 10..12000
  unique study
  immutable study, owner
  read <- .owner = viewer or exists studies[.study, coauthor = viewer] or exists releases[study = .study] or exists reviewGrants[.study, viewer]
  insert <- .owner = viewer and exists studies[.study, owner = viewer, sealedAt = null]
  update <- .owner = viewer and exists studies[.study, sealedAt = null]
  online only

table releases:
  study: studies
  opensAt: time
  unique study
  immutable study
  not before .opensAt
  public 'the release marker opens the sealed plan on the chosen date'
  insert <- exists studies[.study, owner = viewer]
  update <- exists studies[.study, owner = viewer]
  online only

table addenda:
  study: studies
  author: principal
  body: text 10..6000
  at: time default now
  immutable study, author, body, at
  read <- exists studies[.study, owner = viewer] or exists studies[.study, coauthor = viewer] or exists releases[study = .study] or exists reviewGrants[.study, viewer]
  insert <- .author = viewer and exists studies[.study, owner = viewer, withdrawn = false] and not exists studies[.study, sealedAt = null]
  online only

table links:
  study: studies
  secret: text 32..100
  expiresAt: time
  unique secret
  immutable study, secret, expiresAt
  expire at .expiresAt
  read <- allow
  insert <- exists studies[.study, owner = viewer, withdrawn = false] and not exists studies[.study, sealedAt = null]
  online only

table reviewGrants:
  study: studies
  principal: principal
  link: links
  expiresAt: time
  unique study, principal
  immutable study, principal
  expire at .expiresAt
  read <- .principal = viewer
  insert <- .principal = viewer and exists links[.link, study = .study, expiresAt = .expiresAt]
  update <- .principal = viewer and exists links[.link, study = .study, expiresAt = .expiresAt]
  online only

table withdrawals:
  study: studies
  author: principal
  reason: text 10..1000
  at: time default now
  unique study
  immutable study, author, reason, at
  public 'withdrawal reasons are part of the public sealed-study record'
  insert <- .author = viewer and exists studies[.study, owner = viewer, sealed = true, withdrawn = false]
  online only

query withdrawal(study: studies):
  return withdrawals[study = study]

query registry():
  return studies where .sealed = true last 100 by .sealedAt { id, title, sealedAt, releaseAt, published, owner, withdrawn }
query myStudies():
  return studies where .owner = viewer last 100 by .id
query study(study: studies):
  return studies[study]
query plan(study: studies):
  return plans[study = study]
query amendments(study: studies):
  return addenda where .study = study first 100 by .at

mutation createStudy(title: text 3..160, coauthor: principal, releaseAt: time, hypotheses: text 10..8000, analysis: text 10..12000):
  require releaseAt > now and releaseAt <= now + 1825d else BAD_RELEASE_DATE
  s = insert studies { owner: viewer, coauthor, title, releaseAt }
  insert plans { study: s.id, owner: viewer, hypotheses, analysis }
  return s
mutation editDraft(study: studies, title: text 3..160, hypotheses: text 10..8000, analysis: text 10..12000):
  s = studies[study] ! else NOT_FOUND
  require s.owner = viewer else NOT_AUTHOR
  require s.sealedAt = null else SEALED 'Sealed plans cannot be edited. Add a dated addendum.'
  update studies[study] { title }
  update plans[study = study] { hypotheses, analysis }
mutation seal(study: studies):
  s = studies[study] ! else NOT_FOUND
  require s.owner = viewer else NOT_AUTHOR
  require s.sealedAt = null else ALREADY_SEALED
  require s.releaseAt > now else BAD_RELEASE_DATE
  update studies[study] { sealedAt: now, sealed: true }
  insert releases { study, opensAt: s.releaseAt }
mutation addAddendum(study: studies, body: text 10..6000):
  s = studies[study] ! else NOT_FOUND
  require s.owner = viewer else NOT_AUTHOR
  require s.sealedAt != null else NOT_SEALED
  require s.withdrawn = false else WITHDRAWN
  return insert addenda { study, author: viewer, body }
mutation inviteReviewer(study: studies, secret: text 32..100, expiresAt: time):
  s = studies[study] ! else NOT_FOUND
  require s.owner = viewer else NOT_AUTHOR
  require s.sealedAt != null else NOT_SEALED
  require s.withdrawn = false else WITHDRAWN
  require expiresAt > now and expiresAt <= now + 7d else BAD_EXPIRY
  insert links { study, secret, expiresAt }
mutation claimReview(secret: text 32..100):
  l = links[secret = secret] ! else BAD_LINK 'This review link is invalid or expired.'
  upsert reviewGrants[study = l.study, principal = viewer] { study: l.study, principal: viewer, link: l.id, expiresAt: l.expiresAt }
  return l.study
mutation markPublished(study: studies):
  s = studies[study] ! else NOT_FOUND
  require s.owner = viewer else NOT_AUTHOR
  require s.sealedAt != null else NOT_SEALED
  update studies[study] { published: true }
  update releases[study = study] { opensAt: now }

mutation withdrawStudy(study: studies, reason: text 10..1000):
  s = studies[study] ! else NOT_FOUND
  require s.owner = viewer else NOT_AUTHOR
  require s.sealed = true else NOT_SEALED
  require s.withdrawn = false else ALREADY_WITHDRAWN
  w = insert withdrawals { study, author: viewer, reason }
  update studies[study] { withdrawn: true }
  return w
