use personas alice, bob, librarian

table staff:
  principal: principal
  unique principal
  read <- .principal = viewer
  online only

table titles:
  name: text 1..120
  author: text 1..100
  questions: text 1..2000
  public 'Library catalogue and discussion questions'
  online only

table kits:
  title: titles
  label: text 1..40
  state: enum('available', 'out', 'repair')
  public 'Kit inventory is visible to club leaders'
  update <- exists staff[viewer]
  online only

table windows:
  kit: kits
  startsAt: time
  endsAt: time
  active: bool default true
  public 'Anonymous occupied dates prevent double booking'
  insert <- allow
  update <- allow
  immutable kit, startsAt, endsAt
  cap 500 by kit
  online only

table reservations:
  leader: principal
  club: text 1..80
  kit: kits
  window: windows
  startsAt: time
  dueAt: time
  state: enum('reserved', 'out', 'closed', 'cancelled') default 'reserved'
  returned: int 0..10 default 0
  fineCents: int 0..15000 default 0
  unique window
  immutable leader, kit, window, startsAt, dueAt, club
  read <- .leader = viewer or exists staff[viewer]
  insert <- .leader = viewer
  update <- .leader = viewer or exists staff[viewer]
  cap 500 by leader
  online only

table waiting:
  title: titles
  leader: principal
  club: text 1..80
  joinedAt: time default now
  unique title, leader
  immutable title, leader, club, joinedAt
  read <- .leader = viewer or exists staff[viewer]
  insert <- .leader = viewer
  delete <- .leader = viewer
  cap 100 by title
  online only

query role():
  return { principal: viewer, librarian: exists staff[viewer] }
query catalogue(c: cursor ?):
  return titles first 50 by .name after c
query inventory(c: cursor ?):
  return kits first 50 by .label after c
query occupied(kit: kits, c: cursor ?):
  return windows where .kit = kit and .active = true first 50 by .startsAt after c
query myReservations(c: cursor ?):
  return reservations where .leader = viewer last 50 by .startsAt after c { id, club, kit, startsAt, dueAt, state, returned, fineCents, overdue: .state = 'out' and .dueAt < now }
query myWaiting(c: cursor ?):
  return waiting where .leader = viewer first 50 by .joinedAt after c
query libraryLoans(c: cursor ?):
  require exists staff[viewer] else STAFF_ONLY
  return reservations last 100 by .startsAt after c { id, leader, club, kit, startsAt, dueAt, state, returned, fineCents, overdue: .state = 'out' and .dueAt < now }
query titleWaiting(title: titles, c: cursor ?):
  require exists staff[viewer] else STAFF_ONLY
  return waiting where .title = title first 100 by .joinedAt after c

mutation reserve(kit: kits, startsAt: time, club: text 1..80):
  k = kits[kit] ! else NOT_FOUND
  require k.state != 'repair' else KIT_REPAIR
  require startsAt >= day(now) * 1d else PAST_DATE
  endsAt = startsAt + 42d
  require not exists windows where .kit = kit and .active = true and .startsAt < endsAt and .endsAt > startsAt else DATE_CONFLICT 'This kit is already reserved for those dates.'
  w = insert windows { kit, startsAt, endsAt }
  return insert reservations { leader: viewer, club, kit, window: w.id, startsAt, dueAt: endsAt }
mutation cancel(reservation: reservations):
  r = reservations[reservation] ! else NOT_FOUND
  require r.leader = viewer else NOT_OWNER
  require r.state = 'reserved' else NOT_RESERVED
  update windows[r.window] { active: false }
  update reservations[reservation] { state: 'cancelled' }
mutation checkout(reservation: reservations):
  require exists staff[viewer] else STAFF_ONLY
  r = reservations[reservation] ! else NOT_FOUND
  k = kits[r.kit] ! else NOT_FOUND
  require r.state = 'reserved' else NOT_RESERVED
  require r.startsAt <= now and r.dueAt > now else NOT_IN_LOAN_WINDOW
  require k.state = 'available' else KIT_UNAVAILABLE
  update kits[r.kit] { state: 'out' }
  update reservations[reservation] { state: 'out' }
mutation recordReturn(reservation: reservations, copies: int 0..10, finish: bool):
  require exists staff[viewer] else STAFF_ONLY
  r = reservations[reservation] ! else NOT_FOUND
  require r.state = 'out' else NOT_OUT
  require copies >= r.returned else RETURN_COUNT_DECREASE
  if finish:
    update reservations[reservation] { returned: copies, state: 'closed', fineCents: (10 - copies) * 1500 }
    update windows[r.window] { active: false }
    update kits[r.kit] { state: 'available' }
    return null
  else:
    update reservations[reservation] { returned: copies }
    return null
mutation setKitState(kit: kits, state: enum('available', 'repair')):
  require exists staff[viewer] else STAFF_ONLY
  k = kits[kit] ! else NOT_FOUND
  require k.state != 'out' else KIT_OUT
  update kits[kit] { state }
mutation joinWaiting(title: titles, club: text 1..80):
  require exists titles[title] else NOT_FOUND
  require not exists waiting[title, viewer] else ALREADY_WAITING
  return insert waiting { title, leader: viewer, club }
mutation leaveWaiting(entry: waiting):
  w = waiting[entry] ! else NOT_FOUND
  require w.leader = viewer else NOT_OWNER
  delete waiting[entry]
