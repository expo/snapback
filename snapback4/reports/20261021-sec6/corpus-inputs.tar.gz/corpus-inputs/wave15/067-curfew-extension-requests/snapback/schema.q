use personas alice, bob, carol

table families:
  name: text 1..60
  read <- exists members[principal = viewer, family = .id]
  insert <- deny
  update <- deny
  delete <- deny
  online only

table members:
  principal: principal
  family: families
  role: enum('teen', 'parent')
  name: text 1..40
  unique principal
  read <- .principal = viewer
  insert <- deny
  update <- deny
  delete <- deny
  online only

table requests:
  family: families
  teen: principal
  place: text 1..80
  companions: text 1..120
  standardAt: time
  returnAt: time
  monthNumber: int
  at: time default now
  unique family, day(standardAt) else NIGHT_ALREADY_REQUESTED
  immutable family, teen, place, companions, standardAt, returnAt, monthNumber, at
  read <- exists members[principal = viewer, family = .family]
  insert <- .teen = viewer and exists members[principal = viewer, family = .family, role = 'teen']
  update <- deny
  delete <- deny
  cap 3 by family, monthNumber
  online only

table decisions:
  request: requests
  family: families
  parent: principal
  approved: bool
  note: text <=160
  checkAt: time
  at: time default now
  unique request
  read <- exists members[principal = viewer, family = .family]
  insert <- .parent = viewer and exists members[principal = viewer, family = .family, role = 'parent'] and exists requests[.request, family = .family]
  update <- deny
  delete <- deny
  online only

table checkins:
  request: requests
  family: families
  teen: principal
  message: text 1..160
  at: time default now
  unique request
  read <- exists members[principal = viewer, family = .family]
  insert <- .teen = viewer and exists requests[.request, teen = viewer, family = .family]
  update <- deny
  delete <- deny
  online only

view monthlyUsed: count requests by .family, .monthNumber
  read <- exists members[principal = viewer, family = .family]

query home():
  m = members[principal = viewer] ! else NOT_MEMBER
  f = families[m.family] ! else NOT_FOUND
  return { name: m.name, role: m.role, family: f.name, used: monthlyUsed[m.family, month(now)] ?? 0, limit: 3, serverNow: now }

query history(c: cursor ?):
  m = members[principal = viewer] ! else NOT_MEMBER
  return requests where .family = m.family last 50 by .at after c { id, teen, place, companions, standardAt, returnAt, at, decision: decisions[request = .id], checkin: checkins[request = .id] }

mutation ask(place: text 1..80, companions: text 1..120, standardAt: time, returnAt: time):
  m = members[principal = viewer] ! else NOT_MEMBER
  require m.role = 'teen' else TEEN_ONLY
  require standardAt > now and standardAt <= now + 31d else BAD_NIGHT
  require standardAt % 1d = 22h else CURFEW_AT_22_UTC
  require returnAt > standardAt and returnAt <= standardAt + 3h else BAD_EXTENSION
  require (monthlyUsed[m.family, month(standardAt)] ?? 0) < 3 else MONTHLY_LIMIT
  return insert requests { family: m.family, teen: viewer, place, companions, standardAt, returnAt, monthNumber: month(standardAt) }

mutation decide(request: requests, approved: bool, note: text <=160, checkAt: time):
  m = members[principal = viewer] ! else NOT_MEMBER
  require m.role = 'parent' else PARENT_ONLY
  r = requests[request] ! else NOT_FOUND
  require r.family = m.family else FAMILY_ONLY
  require now < r.standardAt else TOO_LATE
  require not exists decisions[request = request] else ALREADY_DECIDED
  require checkAt >= r.standardAt - 30m and checkAt <= r.returnAt else BAD_CHECKIN_TIME
  return insert decisions { request, family: r.family, parent: viewer, approved, note, checkAt }

mutation checkIn(request: requests, message: text 1..160):
  r = requests[request] ! else NOT_FOUND
  require r.teen = viewer else TEEN_ONLY
  d = decisions[request = request] ! else NOT_APPROVED
  require d.approved else NOT_APPROVED
  require now >= d.checkAt else TOO_EARLY
  require now <= r.returnAt + 6h else CHECKIN_CLOSED
  require not exists checkins[request = request] else ALREADY_CHECKED_IN
  return insert checkins { request, family: r.family, teen: viewer, message }
