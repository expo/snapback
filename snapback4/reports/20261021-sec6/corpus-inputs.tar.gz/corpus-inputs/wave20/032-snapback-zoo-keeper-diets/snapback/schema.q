-- Zoo Keeper Diets.
-- Keepers log feedings, weights and behavior notes (with photos) and propose
-- diet changes. Vets and the curator see veterinary treatment notes and
-- breeding plans; keepers and volunteers do not. Volunteers see only the
-- animals on their assigned route. The keeper board shows refused feedings
-- live; animals unfed for 48h are flagged to the vet. Only the curator
-- approves (or rejects) a diet change, with the reason recorded.
use identity password

table staff:
  principal: principal
  role: enum('keeper', 'vet', 'curator', 'volunteer')
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

table animals:
  name: text 1..80
  species: text 1..80
  diet: text 1..500
  enrichment: text 1..500
  vetNotes: text <=2000 ?
  breeding: text <=2000 ?
  read (vetNotes, breeding) <- exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator']
  photo: image <=10000000 ?
  lastFedAt: time default 0
  read <- exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] or exists assignments[viewer, .id]
  insert <- exists staff[viewer, role = 'curator']
  update <- exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator']
  online only

table assignments:
  volunteer: principal
  animal: animals
  unique volunteer, animal
  immutable volunteer, animal
  read <- .volunteer = viewer or exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator']
  insert <- exists staff[viewer, role = 'curator']
  update <- exists staff[viewer, role = 'curator']
  delete <- exists staff[viewer, role = 'curator']
  online only

table feedings:
  animal: animals
  keeper: principal
  at: time default now
  accepted: bool default true
  note: text <=500 ?
  photo: image <=5000000 ?
  immutable animal, keeper, at
  read through .animal
  insert <- .keeper = viewer and (exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'])
  online only

table weights:
  animal: animals
  keeper: principal
  at: time default now
  grams: int 1..1000000000
  immutable animal, keeper, at
  read through .animal
  insert <- .keeper = viewer and (exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'])
  online only

table behaviors:
  animal: animals
  keeper: principal
  at: time default now
  note: text 1..1000
  photo: image <=5000000 ?
  immutable animal, keeper, at
  read through .animal
  insert <- .keeper = viewer and (exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'])
  online only

table dietChanges:
  animal: animals
  proposedBy: principal
  proposedDiet: text 1..500
  proposalNote: text <=500 ?
  status: enum('pending', 'approved', 'rejected') default 'pending'
  decisionReason: text <=500 ?
  decidedBy: principal ?
  decidedAt: time ?
  immutable animal, proposedBy, proposedDiet
  read through .animal
  insert <- .proposedBy = viewer and (exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'curator'])
  update <- exists staff[viewer, role = 'curator']
  online only

query myRole():
  return staff[principal = viewer]

query staffList(c: cursor ?):
  require exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_STAFF
  return staff first 50 by .id after c

query animalsList(c: cursor ?):
  return animals last 50 by .id after c

query animalDetail(animal: animals):
  return animals[animal]

query feedingsFor(animal: animals, c: cursor ?):
  a = animals[animal] ! else NOT_FOUND
  return feedings where .animal = a.id last 50 by .at after c

query weightsFor(animal: animals, c: cursor ?):
  a = animals[animal] ! else NOT_FOUND
  return weights where .animal = a.id last 50 by .at after c

query behaviorsFor(animal: animals, c: cursor ?):
  a = animals[animal] ! else NOT_FOUND
  return behaviors where .animal = a.id last 50 by .at after c

query dietChangesFor(animal: animals, c: cursor ?):
  a = animals[animal] ! else NOT_FOUND
  return dietChanges where .animal = a.id last 50 by .id after c

query recentRefusals(c: cursor ?):
  require exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_STAFF
  return feedings where not .accepted last 50 by .at after c

query flaggedAnimals(c: cursor ?):
  require exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_VET_STAFF
  return animals where .lastFedAt < now - 48h first 50 by .id after c

query myRoute(c: cursor ?):
  return assignments where .volunteer = viewer first 50 by .id after c { id, animal: animals[.animal] }

mutation provision(principal: principal, role: enum('keeper', 'vet', 'curator', 'volunteer')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert staff[principal = principal] { principal, role }

mutation addAnimal(name: text 1..80, species: text 1..80, diet: text 1..500, enrichment: text 1..500, vetNotes: text <=2000 ?, breeding: text <=2000 ?):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  return insert animals { name, species, diet, enrichment, vetNotes, breeding }

mutation updateAnimal(animal: animals, name: text 1..80, species: text 1..80, diet: text 1..500, enrichment: text 1..500):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  a = animals[animal] ! else NOT_FOUND
  update animals[a.id] { name, species, diet, enrichment }
  return null

mutation updateVetNotes(animal: animals, vetNotes: text <=2000, breeding: text <=2000):
  require exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_VET_STAFF
  a = animals[animal] ! else NOT_FOUND
  update animals[a.id] { vetNotes, breeding }
  return null

mutation setAnimalPhoto(animal: animals, photo: image <=10000000):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  a = animals[animal] ! else NOT_FOUND
  update animals[a.id] { photo }
  return null

mutation logFeeding(animal: animals, accepted: bool, note: text <=500 ?, photo: image <=5000000 ?, fedAt: time ?):
  require exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_STAFF
  a = animals[animal] ! else NOT_FOUND
  fed = fedAt ?? now
  insert feedings { animal: a.id, keeper: viewer, at: fed, accepted, note, photo }
  if fed > (a.lastFedAt ?? 0):
    update animals[a.id] { lastFedAt: fed }
  return null

mutation logWeight(animal: animals, grams: int 1..1000000000, weighedAt: time ?):
  require exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_STAFF
  a = animals[animal] ! else NOT_FOUND
  return insert weights { animal: a.id, keeper: viewer, at: weighedAt ?? now, grams }

mutation logBehavior(animal: animals, note: text 1..1000, photo: image <=5000000 ?, observedAt: time ?):
  require exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'vet'] or exists staff[viewer, role = 'curator'] else NOT_STAFF
  a = animals[animal] ! else NOT_FOUND
  return insert behaviors { animal: a.id, keeper: viewer, at: observedAt ?? now, note, photo }

mutation proposeDietChange(animal: animals, proposedDiet: text 1..500, note: text <=500 ?):
  require exists staff[viewer, role = 'keeper'] or exists staff[viewer, role = 'curator'] else NOT_KEEPER
  a = animals[animal] ! else NOT_FOUND
  return insert dietChanges { animal: a.id, proposedBy: viewer, proposedDiet, proposalNote: note }

mutation approveDietChange(change: dietChanges, reason: text 1..500):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  c = dietChanges[change] ! else NOT_FOUND
  require c.status = 'pending' else ALREADY_DECIDED
  update dietChanges[c.id] { status: 'approved', decisionReason: reason, decidedBy: viewer, decidedAt: now }
  update animals[c.animal] { diet: c.proposedDiet }
  return null

mutation rejectDietChange(change: dietChanges, reason: text 1..500):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  c = dietChanges[change] ! else NOT_FOUND
  require c.status = 'pending' else ALREADY_DECIDED
  update dietChanges[c.id] { status: 'rejected', decisionReason: reason, decidedBy: viewer, decidedAt: now }
  return null

mutation assignRoute(animal: animals, who: principal):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  a = animals[animal] ! else NOT_FOUND
  return upsert assignments[volunteer = who, animal = a.id] { volunteer: who, animal: a.id }

mutation unassignRoute(animal: animals, who: principal):
  require exists staff[viewer, role = 'curator'] else NOT_CURATOR
  a = animals[animal] ! else NOT_FOUND
  g = assignments[who, a.id] ! else NOT_FOUND
  delete assignments[g.id]
  return null

-- Privacy and authority intent from the spec.
-- Keepers see husbandry but not treatment or breeding plans.
invariant animals.vetNotes read only exists staff[principal = viewer, role = 'vet'] or exists staff[principal = viewer, role = 'curator']
invariant animals.breeding read only exists staff[principal = viewer, role = 'vet'] or exists staff[principal = viewer, role = 'curator']
-- Only the curator approves a diet change.
invariant dietChanges.approveDietChange only exists staff[principal = viewer, role = 'curator']
invariant dietChanges.rejectDietChange only exists staff[principal = viewer, role = 'curator']
