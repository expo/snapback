use identity password

-- Roles are provisioned only by the local store operator. Signup grants nothing.
table roles:
  principal: principal
  role: enum('manager', 'inspector', 'cleaner', 'painter', 'landlord', 'tenant')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('manager', 'inspector', 'cleaner', 'painter', 'landlord', 'tenant')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

query landlords():
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return roles where .role = 'landlord' first 100 by .principal { principal }

table turnovers:
  address: text 5..200
  lockbox: text 3..30
  landlord: principal
  moveOut: time
  inspectionDue: time
  depositDue: time
  createdBy: principal
  createdAt: time
  immutable landlord, moveOut, inspectionDue, depositDue, createdBy, createdAt
  read <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'cleaner'] or exists roles[viewer, role = 'painter'] or .landlord = viewer
  insert <- exists roles[viewer, role = 'manager'] and .createdBy = viewer
  online only

-- Financial records have a separate lifecycle and narrower read/write authority.
table finances:
  turnover: turnovers
  tenantName: text 2..100
  forwarding: text 5..300
  deposit: int 0..1000000
  deduction: int 0..1000000 default 0
  reason: text <=1000 default ''
  approved: bool default false
  approvedBy: principal ?
  approvedAt: time ?
  sentAt: time ?
  notice: text <=2000 default ''
  unique turnover
  immutable turnover, tenantName, forwarding, deposit
  read <- exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager']
  online only

invariant finances.forwarding read only exists roles[viewer, role = 'manager']
invariant finances.deduction read only exists roles[viewer, role = 'manager']
invariant finances.update only exists roles[viewer, role = 'manager']

table tasks:
  turnover: turnovers
  title: text 2..160
  trade: enum('cleaner', 'painter')
  done: bool default false
  completedBy: principal ?
  completedAt: time ?
  immutable turnover, title, trade
  read <- exists turnovers[.turnover, landlord = viewer] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'cleaner'] or exists roles[viewer, role = 'painter']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'cleaner'] and .trade = 'cleaner' or exists roles[viewer, role = 'painter'] and .trade = 'painter'
  online only

table inspections:
  turnover: turnovers
  inspector: principal
  at: time
  notes: text 2..2000
  photos: [image <=5000000] 1..8
  unique turnover
  immutable turnover, inspector, at, notes, photos
  read <- exists turnovers[.turnover, landlord = viewer] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'cleaner'] or exists roles[viewer, role = 'painter']
  insert <- exists roles[viewer, role = 'inspector'] and .inspector = viewer
  online only

query board(c: cursor ?):
  require exists roles[viewer] else NO_ROLE
  require not exists roles[viewer, role = 'tenant'] else NO_ACCESS
  if exists roles[viewer, role = 'landlord']:
    return turnovers where .landlord = viewer last 50 by .id after c
  return turnovers last 50 by .id after c

query turnoverById(turnover: turnovers):
  return turnovers[turnover]

query tasksFor(turnover: turnovers):
  require exists turnovers[turnover] else NOT_FOUND
  return tasks where .turnover = turnover first 100 by .id

query inspectionFor(turnover: turnovers):
  require exists turnovers[turnover] else NOT_FOUND
  return inspections[turnover = turnover]

query financeFor(turnover: turnovers):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return finances[turnover = turnover]

mutation createTurnover(address: text 5..200, lockbox: text 3..30, landlord: principal, moveOut: time, tenantName: text 2..100, forwarding: text 5..300, deposit: int 0..1000000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require exists roles[landlord, role = 'landlord'] else NOT_LANDLORD
  require moveOut >= now - 365d and moveOut <= now + 365d else BAD_MOVE_OUT
  t = insert turnovers { address, lockbox, landlord, moveOut, inspectionDue: moveOut + 3d, depositDue: moveOut + 21d, createdBy: viewer, createdAt: now }
  insert finances { turnover: t.id, tenantName, forwarding, deposit }
  return t

mutation addTask(turnover: turnovers, title: text 2..160, trade: enum('cleaner', 'painter')):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require exists turnovers[turnover] else NOT_FOUND
  return insert tasks { turnover, title, trade }

mutation setTaskDone(task: tasks, done: bool):
  t = tasks[task] ! else NOT_FOUND
  require exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'cleaner'] and t.trade = 'cleaner' or exists roles[viewer, role = 'painter'] and t.trade = 'painter' else WRONG_TRADE
  return update tasks[task] { done, completedBy: viewer if done else null, completedAt: now if done else null }

mutation submitInspection(turnover: turnovers, notes: text 2..2000, photos: [image <=5000000] 1..8):
  require exists roles[viewer, role = 'inspector'] else NOT_INSPECTOR
  t = turnovers[turnover] ! else NOT_FOUND
  require now >= t.moveOut else BEFORE_MOVE_OUT
  require now <= t.inspectionDue else INSPECTION_OVERDUE
  require not exists inspections[turnover = turnover] else ALREADY_INSPECTED
  return insert inspections { turnover, inspector: viewer, at: now, notes, photos }

mutation approveDeduction(turnover: turnovers, deduction: int 0..1000000, reason: text 2..1000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  t = turnovers[turnover] ! else NOT_FOUND
  f = finances[turnover = turnover] ! else NOT_FOUND
  require now >= t.moveOut else BEFORE_MOVE_OUT
  require now <= t.depositDue else DEPOSIT_OVERDUE
  require not f.approved else ALREADY_APPROVED
  require deduction <= f.deposit else EXCEEDS_DEPOSIT
  return update finances[f.id] { deduction, reason, approved: true, approvedBy: viewer, approvedAt: now }

mutation sendDecision(turnover: turnovers):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  t = turnovers[turnover] ! else NOT_FOUND
  f = finances[turnover = turnover] ! else NOT_FOUND
  require now >= t.moveOut else BEFORE_MOVE_OUT
  require now <= t.depositDue else DEPOSIT_OVERDUE
  require f.approved else APPROVAL_REQUIRED
  require f.sentAt = null else ALREADY_SENT
  return update finances[f.id] { sentAt: now, notice: 'Deposit decision for ' + f.tenantName + '. Delivery address: ' + f.forwarding + '. Reason: ' + f.reason }
