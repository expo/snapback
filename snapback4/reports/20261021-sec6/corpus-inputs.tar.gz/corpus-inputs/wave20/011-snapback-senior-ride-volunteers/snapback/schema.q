use identity password

table roles:
  principal: principal
  role: enum('coordinator', 'driver', 'rider', 'director')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or (.role = 'rider' and exists roles[viewer, role = 'coordinator'])
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('coordinator', 'driver', 'rider', 'director')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query me():
  return roles[viewer]

query riders():
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  return roles where .role = 'rider' first 200 by .id

table rides:
  rider: principal
  pickup: text 5..240
  destination: text 3..160
  appointmentAt: time
  requestedAt: time
  status: enum('pending', 'open', 'claimed')
  driver: principal ?
  approvedBy: principal ?
  immutable rider, pickup, destination, appointmentAt, requestedAt
  read <- exists roles[viewer, role = 'coordinator'] or (.status = 'pending' and exists roles[viewer, role = 'director']) or (.rider = viewer and exists roles[viewer, role = 'rider']) or (exists roles[viewer, role = 'driver'] and (.status = 'open' or .driver = viewer))
  insert <- exists roles[viewer, role = 'coordinator']
  update <- exists roles[viewer, role = 'director'] or exists roles[viewer, role = 'driver']
  online only

table privateDetails:
  ride: rides
  phone: text 7..30
  emergencyContact: text 5..200
  medicalReason: text 3..500
  unique ride
  immutable ride, phone, emergencyContact, medicalReason
  read <- exists roles[viewer, role = 'coordinator']
  insert <- exists roles[viewer, role = 'coordinator']
  online only

invariant privateDetails.read only exists roles[viewer, role = 'coordinator']
invariant privateDetails.phone read only exists roles[viewer, role = 'coordinator']
invariant privateDetails.emergencyContact read only exists roles[viewer, role = 'coordinator']
invariant privateDetails.medicalReason read only exists roles[viewer, role = 'coordinator']
invariant roles.role write only viewer = 'service:operator'

fn saveRide(rider: principal, pickup: text 5..240, destination: text 3..160, appointmentAt: time, phone: text 7..30, emergencyContact: text 5..200, medicalReason: text 3..500, late: bool):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  require exists roles[rider, role = 'rider'] else INVALID_RIDER
  require appointmentAt <= now + 365d else TOO_FAR 'Appointments must be within one year.'
  if late:
    require appointmentAt < now + 72h else NOT_LATE
    require appointmentAt >= now - 14d else TOO_OLD 'Retrospective exceptions must be within 14 days.'
  else:
    require appointmentAt >= now + 72h else ADVANCE_NOTICE 'At least 72 hours notice is required; send a late request for director approval.'
  ride = insert rides { rider, pickup, destination, appointmentAt, requestedAt: now, status: 'pending' if late else 'open', driver: null, approvedBy: null }
  insert privateDetails { ride: ride.id, phone, emergencyContact, medicalReason }
  return { id: ride.id }

mutation createRide(rider: principal, pickup: text 5..240, destination: text 3..160, appointmentAt: time, phone: text 7..30, emergencyContact: text 5..200, medicalReason: text 3..500):
  return saveRide(rider, pickup, destination, appointmentAt, phone, emergencyContact, medicalReason, false)

mutation requestLate(rider: principal, pickup: text 5..240, destination: text 3..160, appointmentAt: time, phone: text 7..30, emergencyContact: text 5..200, medicalReason: text 3..500):
  return saveRide(rider, pickup, destination, appointmentAt, phone, emergencyContact, medicalReason, true)

query listRides():
  return rides last 200 by .id

query ride(ride: rides):
  return rides[ride]

query privateRide(ride: rides):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  return privateDetails[ride]

mutation approveLate(ride: rides):
  require exists roles[viewer, role = 'director'] else DIRECTOR_ONLY
  row = rides[ride] ! else NOT_FOUND
  require row.status = 'pending' else NOT_PENDING
  update rides[ride] { status: 'open', approvedBy: viewer }
  return { id: ride }

mutation claimRide(ride: rides):
  require exists roles[viewer, role = 'driver'] else DRIVER_ONLY
  row = rides[ride] ! else NOT_FOUND
  require row.status = 'open' else NOT_OPEN
  update rides[ride] { status: 'claimed', driver: viewer } if .status = 'open'
  return { id: ride }

table mileageLogs:
  ride: rides
  driver: principal
  photo: image <=5000000
  miles: int 1..2000
  submittedAt: time
  unique ride
  immutable ride, driver, photo, miles, submittedAt
  read <- (.driver = viewer and exists roles[viewer, role = 'driver']) or exists roles[viewer, role = 'coordinator']
  insert <- .driver = viewer and exists roles[viewer, role = 'driver'] and exists rides[id = .ride, driver = viewer, status = 'claimed']
  online only

query mileage(ride: rides):
  return mileageLogs[ride]

mutation submitMileage(ride: rides, photo: image <=5000000, miles: int 1..2000):
  require exists roles[viewer, role = 'driver'] else DRIVER_ONLY
  row = rides[ride] ! else NOT_FOUND
  require row.driver = viewer and row.status = 'claimed' else NOT_ASSIGNED
  require now >= row.appointmentAt else RIDE_NOT_FINISHED
  require now <= row.appointmentAt + 14d else DEADLINE_PASSED 'Mileage photos are due within 14 days after the appointment.'
  return insert mileageLogs { ride, driver: viewer, photo, miles, submittedAt: now }
