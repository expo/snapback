use identity password

-- Roles are assigned by the filesystem operator, never by signup.
table roles:
  principal: principal
  role: enum('owner', 'office', 'technician', 'homeowner')
  displayName: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'office'] or exists roles[viewer, role = 'owner'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('owner', 'office', 'technician', 'homeowner'), displayName: text 1..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, displayName }

query myRole():
  return roles[viewer]

query directory(c: cursor ?):
  require exists roles[viewer, role = 'office'] or exists roles[viewer, role = 'owner'] else OFFICE_OR_OWNER_ONLY
  return roles first 100 by .id after c

table pools:
  name: text 1..100
  address: text 1..240
  homeowner: principal
  technician: principal
  routeOrder: int 1..100
  gateCode: text <=40
  equipment: text 1..1000
  repairLimitCents: int 0..1000000
  rateCents: int 0..1000000 read <- exists roles[viewer, role = 'office']
  officeNotes: text <=2000 read <- exists roles[viewer, role = 'office']
  lastServiceAt: time ?
  createdAt: time default now
  immutable homeowner, repairLimitCents, createdAt
  read <- exists roles[viewer, role = 'office'] or exists roles[viewer, role = 'owner'] or (.technician = viewer and exists roles[viewer, role = 'technician']) or (.homeowner = viewer and exists roles[viewer, role = 'homeowner'])
  insert <- exists roles[viewer, role = 'office']
  update <- exists roles[viewer, role = 'office'] or (.technician = viewer and exists roles[viewer, role = 'technician'])
  online only

invariant pools.rateCents read only exists roles[viewer, role = 'office']
invariant pools.officeNotes read only exists roles[viewer, role = 'office']
invariant pools.createPool only exists roles[viewer, role = 'office']

mutation createPool(name: text 1..100, address: text 1..240, homeowner: principal, technician: principal, routeOrder: int 1..100, gateCode: text <=40, equipment: text 1..1000, repairLimitCents: int 0..1000000, rateCents: int 0..1000000, officeNotes: text <=2000, lastServiceAt: time ?):
  require exists roles[viewer, role = 'office'] else OFFICE_ONLY
  require exists roles[homeowner, role = 'homeowner'] else NOT_HOMEOWNER
  require exists roles[technician, role = 'technician'] else NOT_TECHNICIAN
  require lastServiceAt = null or lastServiceAt <= now else FUTURE_VISIT
  return insert pools { name, address, homeowner, technician, routeOrder, gateCode, equipment, repairLimitCents, rateCents, officeNotes, lastServiceAt }

mutation updateOfficeDetails(pool: pools, rateCents: int 0..1000000, officeNotes: text <=2000):
  require exists roles[viewer, role = 'office'] else OFFICE_ONLY
  update pools[pool] { rateCents, officeNotes }

mutation assignTechnician(pool: pools, technician: principal, routeOrder: int 1..100):
  require exists roles[viewer, role = 'office'] else OFFICE_ONLY
  require exists roles[technician, role = 'technician'] else NOT_TECHNICIAN
  update pools[pool] { technician, routeOrder }

query routeBoard(c: cursor ?):
  return pools first 100 by .id after c { id, name, address, homeowner, technician, routeOrder, lastServiceAt, overdue: .lastServiceAt = null or .lastServiceAt + 8d <= now }

query poolDetail(pool: pools):
  return pools[pool]

table visits:
  pool: pools
  technician: principal
  at: time default now
  ph: int 0..140
  chlorine: int 0..500
  chemicals: text 1..1000
  photo: image <=5000000
  immutable pool, technician, at, ph, chlorine, chemicals, photo
  read <- exists roles[viewer, role = 'office'] or exists roles[viewer, role = 'owner'] or (exists pools[.pool, technician = viewer] and exists roles[viewer, role = 'technician']) or (exists pools[.pool, homeowner = viewer] and exists roles[viewer, role = 'homeowner'])
  insert <- .technician = viewer and .pool.technician = viewer and exists roles[viewer, role = 'technician']
  online only

invariant visits.completeStop only exists roles[viewer, role = 'technician']

mutation completeStop(pool: pools, ph: int 0..140, chlorine: int 0..500, chemicals: text 1..1000, photo: image <=5000000):
  require exists roles[viewer, role = 'technician'] else TECHNICIAN_ONLY
  p = pools[pool] ! else NOT_FOUND
  require p.technician = viewer else NOT_FOUND
  v = insert visits { pool, technician: viewer, ph, chlorine, chemicals, photo }
  update pools[pool] { lastServiceAt: now }
  return v

query serviceHistory(pool: pools, c: cursor ?):
  p = pools[pool] ! else NOT_FOUND
  return visits where .pool = p.id last 50 by .at after c

table payments:
  pool: pools
  amountCents: int 1..10000000
  memo: text 1..240
  at: time default now
  recordedBy: principal
  immutable pool, amountCents, memo, at, recordedBy
  read <- exists roles[viewer, role = 'office']
  insert <- exists roles[viewer, role = 'office'] and .recordedBy = viewer
  online only

invariant payments.read only exists roles[viewer, role = 'office']

query paymentHistory(pool: pools, c: cursor ?):
  require exists roles[viewer, role = 'office'] else OFFICE_ONLY
  return payments where .pool = pool last 50 by .at after c

mutation recordPayment(pool: pools, amountCents: int 1..10000000, memo: text 1..240):
  require exists roles[viewer, role = 'office'] else OFFICE_ONLY
  p = pools[pool] ! else NOT_FOUND
  return insert payments { pool: p.id, amountCents, memo, recordedBy: viewer }

table repairs:
  pool: pools
  requestedBy: principal
  description: text 1..1000
  amountCents: int 1..10000000
  limitCents: int 0..1000000
  at: time default now
  status: enum('pending', 'approved') default 'pending'
  homeownerApproval: text <=500
  approvedBy: principal ?
  approvedAt: time ?
  immutable pool, requestedBy, description, amountCents, limitCents, at
  read <- exists roles[viewer, role = 'office'] or exists roles[viewer, role = 'owner'] or (exists pools[.pool, technician = viewer] and exists roles[viewer, role = 'technician']) or (exists pools[.pool, homeowner = viewer] and exists roles[viewer, role = 'homeowner'])
  insert <- exists roles[viewer, role = 'technician'] and .pool.technician = viewer and .requestedBy = viewer and .status = 'pending'
  update <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'office']
  online only

mutation requestRepair(pool: pools, description: text 1..1000, amountCents: int 1..10000000):
  require exists roles[viewer, role = 'technician'] else TECHNICIAN_ONLY
  p = pools[pool] ! else NOT_FOUND
  return insert repairs { pool: p.id, requestedBy: viewer, description, amountCents, limitCents: p.repairLimitCents, homeownerApproval: '', approvedBy: null, approvedAt: null }

mutation approveRepair(repair: repairs, homeownerApproval: text 5..500):
  require exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'office'] else OFFICE_OR_OWNER_ONLY
  r = repairs[repair] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_APPROVED
  require r.amountCents <= r.limitCents or exists roles[viewer, role = 'owner'] else OWNER_REQUIRED
  update repairs[repair] { status: 'approved', homeownerApproval, approvedBy: viewer, approvedAt: now }

query repairHistory(pool: pools, c: cursor ?):
  p = pools[pool] ! else NOT_FOUND
  return repairs where .pool = p.id last 50 by .at after c
