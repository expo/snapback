-- Sailmaker Repair Orders.
-- Roles: clerk (intake), owner (boat owner), maker (sailmaker),
-- rigger, loftowner. Provisioned by the local operator; no self-signup.
use identity password

table roles:
  principal: principal
  role: enum('clerk','owner','maker','rigger','loftowner')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table boats:
  owner: principal
  name: text 1..80
  rig: text 1..40 ?
  cap 50 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker'] or exists assignments[boat = .id, rigger = viewer]
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  update <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  online only

table assignments:
  boat: boats
  rigger: principal
  unique boat, rigger
  immutable boat, rigger
  cap 10 by boat
  read <- .rigger = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  update <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  delete <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  online only

table sails:
  boat: boats
  owner: principal
  damage: text 1..500
  photos: [image <=5000000] 1..4
  status: enum('intake','cutting','patching','stitching','ready','pickup-notice','collected') default 'intake'
  pickupNoticeAt: time ?
  collectedAt: time ?
  storageFeeCents: int 0..100000000 default 0
  replacementApproved: bool default false
  replacementReason: text 1..500 ?
  customerAgreed: bool default false
  immutable boat, owner, damage, photos
  cap 200 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  update <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker']
  online only

table estimates:
  sail: sails
  owner: principal
  amountCents: int 1..100000000
  createdAt: time default now
  decision: enum('pending','approved','rejected') default 'pending'
  decidedAt: time ?
  immutable sail, owner, amountCents, createdAt
  cap 50 by sail
  read <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  insert <- exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  update <- .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
  online only

-- Spec privacy intent, stated independently from the rules.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or viewer = 'service:operator'
invariant boats.read only .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker'] or exists assignments[boat = .id, rigger = viewer]
invariant assignments.read only .rigger = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
invariant sails.photos read only .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker']
invariant estimates.read only .owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']
invariant sails.replacementApproved write only exists roles[viewer, role = 'loftowner']
invariant sails.replacementReason write only exists roles[viewer, role = 'loftowner']

mutation provision(principal: principal, role: enum('clerk','owner','maker','rigger','loftowner')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation createBoat(owner: principal, name: text 1..80, rig: text 1..40 ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  require exists roles[owner, role = 'owner'] else NOT_OWNER_ROLE
  return insert boats { owner, name, rig }

mutation logSail(boat: boats, damage: text 1..500, photos: [image <=5000000] 1..4):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  b = boats[boat] ! else NOT_FOUND
  return insert sails { boat, owner: b.owner, damage, photos }

mutation updateSailStatus(sail: sails, status: enum('cutting','patching','stitching','ready')):
  require exists roles[viewer, role = 'maker'] or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_BOARD
  s = sails[sail] ! else NOT_FOUND
  require s.status != 'collected' else ALREADY_COLLECTED
  require s.status != 'pickup-notice' else PICKUP_SENT
  update sails[sail] { status, pickupNoticeAt: s.pickupNoticeAt, collectedAt: s.collectedAt, storageFeeCents: s.storageFeeCents, replacementApproved: s.replacementApproved, replacementReason: s.replacementReason, customerAgreed: s.customerAgreed }
  return null

mutation createEstimate(sail: sails, amountCents: int 1..100000000):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  s = sails[sail] ! else NOT_FOUND
  return insert estimates { sail, owner: s.owner, amountCents }

mutation approveEstimate(estimate: estimates, approve: bool):
  e = estimates[estimate] ! else NOT_FOUND
  require e.owner = viewer else NOT_OWNER
  require e.decision = 'pending' else ALREADY_DECIDED
  require now <= e.createdAt + 14d else ESTIMATE_EXPIRED
  update estimates[estimate] { decision: 'approved' if approve else 'rejected', decidedAt: now }
  return null

mutation sendPickupNotice(sail: sails):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  s = sails[sail] ! else NOT_FOUND
  require s.pickupNoticeAt = null else ALREADY_NOTICED
  require s.status = 'ready' else NOT_READY
  update sails[sail] { status: 'pickup-notice', pickupNoticeAt: now, collectedAt: s.collectedAt, storageFeeCents: s.storageFeeCents, replacementApproved: s.replacementApproved, replacementReason: s.replacementReason, customerAgreed: s.customerAgreed }
  return null

mutation collectSail(sail: sails):
  s = sails[sail] ! else NOT_FOUND
  require s.owner = viewer or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_ALLOWED
  require s.pickupNoticeAt != null else NO_PICKUP_NOTICE
  require s.status != 'collected' else ALREADY_COLLECTED
  noticed = s.pickupNoticeAt ?? now
  raw = (now - noticed) / 1d - 60
  late = raw if raw > 0 else 0
  update sails[sail] { status: 'collected', collectedAt: now, storageFeeCents: late * 500, pickupNoticeAt: s.pickupNoticeAt, replacementApproved: s.replacementApproved, replacementReason: s.replacementReason, customerAgreed: s.customerAgreed }
  return null

mutation approveReplacement(sail: sails, reason: text 1..500, customerAgreed: bool):
  require exists roles[viewer, role = 'loftowner'] else NOT_LOFTOWNER
  require customerAgreed else NEEDS_AGREEMENT
  s = sails[sail] ! else NOT_FOUND
  update sails[sail] { replacementApproved: true, replacementReason: reason, customerAgreed: true, pickupNoticeAt: s.pickupNoticeAt, collectedAt: s.collectedAt, storageFeeCents: s.storageFeeCents }
  return null

mutation assignRigger(boat: boats, rigger: principal):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  b = boats[boat] ! else NOT_FOUND
  require exists roles[rigger, role = 'rigger'] else NOT_RIGGER
  return upsert assignments[boat, rigger] { boat, rigger }

query myRole():
  return roles[viewer]

query ownerDirectory(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  return roles where .role = 'owner' last 50 by .id after c { id, principal }

query riggerDirectory(c: cursor ?):
  require exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_STAFF
  return roles where .role = 'rigger' last 50 by .id after c { id, principal }

query myBoats(c: cursor ?):
  if exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker']:
    return boats last 50 by .id after c
  return boats where .owner = viewer last 50 by .id after c

query riggerBoats(c: cursor ?):
  require exists roles[viewer, role = 'rigger'] or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_RIGGER
  return assignments where .rigger = viewer last 50 by .id after c { id, boat: boats[.boat] }

query assignmentsForBoat(boat: boats, c: cursor ?):
  return assignments where .boat = boat last 50 by .id after c

query mySails(c: cursor ?):
  if exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] or exists roles[viewer, role = 'maker']:
    return sails last 50 by .id after c
  return sails where .owner = viewer last 50 by .id after c

query loftBoard(c: cursor ?):
  require exists roles[viewer, role = 'maker'] or exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner'] else NOT_BOARD
  return sails where .status = 'cutting' or .status = 'patching' or .status = 'stitching' last 50 by .id after c

query sailDetail(sail: sails):
  return sails[sail]

query boatDetail(boat: boats):
  return boats[boat]

query myEstimates(c: cursor ?):
  if exists roles[viewer, role = 'clerk'] or exists roles[viewer, role = 'loftowner']:
    return estimates last 50 by .id after c
  return estimates where .owner = viewer last 50 by .id after c

query estimatesForSail(sail: sails, c: cursor ?):
  return estimates where .sail = sail last 20 by .id after c

query estimateDetail(estimate: estimates):
  return estimates[estimate]

query storageDue(sail: sails):
  s = sails[sail] ! else NOT_FOUND
  noticed = s.pickupNoticeAt ?? now
  raw = (now - noticed) / 1d - 60
  late = raw if raw > 0 else 0
  return { sail: s.id, hasNotice: s.pickupNoticeAt != null, daysLate: late, feeCents: late * 500, accruing: late > 0 }
