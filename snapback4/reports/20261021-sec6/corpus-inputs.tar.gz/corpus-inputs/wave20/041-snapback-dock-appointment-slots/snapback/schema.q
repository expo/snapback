-- Dock Appointment Slots.
-- Roles: carrier, dock_worker, dock_lead, manager (warehouse manager).
-- A carrier books appointments, uploads the bill of lading + seal photo on
-- arrival. Arriving more than 30 minutes after start loses the slot unless the
-- manager accepted the late truck; the carrier must then rebook. A trailer
-- still unloading more than four hours after unloading began shows up in the
-- overdue query (the dock-lead flag). Only the manager may accept a late
-- truck or refuse a load with a broken seal, recording the reason.
use identity password

table roles:
  principal: principal
  role: enum('carrier', 'dock_worker', 'dock_lead', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

table appointments:
  carrier: principal
  door: text 1..20 ?
  startAt: time
  endAt: time ?
  status: enum('booked', 'arrived', 'unloading', 'done', 'expired', 'refused', 'cancelled') default 'booked'
  arrivedAt: time ?
  unloadingBeganAt: time ?
  completedAt: time ?
  bol: image <=10000000 ?
  sealPhoto: image <=10000000 ?
  lateAccepted: bool default false
  refusalReason: text 1..500 ?
  note: text 1..500 ?
  createdAt: time default now
  immutable carrier, startAt
  cap 500 by carrier
  read <- .carrier = viewer or exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager']
  insert <- .carrier = viewer
  update <- .carrier = viewer or exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager']
  online only

-- Privacy intent: a carrier reads only their own appointments; dock staff
-- (worker, lead, manager) read the whole board. Documents inherit the row.
invariant appointments.read only .carrier = viewer or exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager']
invariant appointments.bol read only .carrier = viewer or exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager']
invariant appointments.sealPhoto read only .carrier = viewer or exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager']
-- Only the warehouse manager accepts a late truck or refuses a load.
invariant appointments.acceptLate only exists roles[principal = viewer, role = 'manager']
invariant appointments.refuseLoad only exists roles[principal = viewer, role = 'manager']
invariant appointments.refusalReason update only exists roles[principal = viewer, role = 'manager']

mutation provision(principal: principal, role: enum('carrier', 'dock_worker', 'dock_lead', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

query myAppointments(c: cursor ?):
  return appointments where .carrier = viewer last 50 by .startAt after c

query doorBoard(c: cursor ?):
  require exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
  return appointments last 100 by .startAt after c

-- Trailers still at a door more than four hours after unloading began.
query overdueTrailers(c: cursor ?):
  require exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
  return appointments where .status = 'unloading' and .unloadingBeganAt < now - 4h last 100 by .unloadingBeganAt after c

mutation book(door: text 1..20 ?, startAt: time, endAt: time ?, note: text 1..500 ?):
  require exists roles[principal = viewer, role = 'carrier'] else NOT_CARRIER
  require startAt >= now - 7d and startAt <= now + 30d else BAD_WINDOW
  require endAt = null or endAt > startAt else BAD_WINDOW
  return insert appointments { carrier: viewer, door, startAt, endAt, note }

-- A carrier whose slot was lost (or refused) books a fresh one from it.
mutation rebook(old: appointments, startAt: time, endAt: time ?):
  require exists roles[principal = viewer, role = 'carrier'] else NOT_CARRIER
  prev = appointments[old] ! else NOT_FOUND
  require prev.carrier = viewer else NOT_OWNER
  require prev.status = 'expired' or prev.status = 'refused' or prev.status = 'cancelled' else BAD_STATUS
  require startAt >= now - 7d and startAt <= now + 30d else BAD_WINDOW
  require endAt = null or endAt > startAt else BAD_WINDOW
  return insert appointments { carrier: viewer, startAt, endAt }

mutation cancel(id: appointments):
  require exists roles[principal = viewer, role = 'carrier'] else NOT_CARRIER
  a = appointments[id] ! else NOT_FOUND
  require a.carrier = viewer else NOT_OWNER
  require a.status = 'booked' else BAD_STATUS
  update appointments[id] { status: 'cancelled' }
  return null

-- Arrival with both required documents. More than 30 minutes late loses the
-- slot unless the manager already accepted the late truck.
mutation arrive(id: appointments, bol: image <=10000000, sealPhoto: image <=10000000):
  require exists roles[principal = viewer, role = 'carrier'] else NOT_CARRIER
  a = appointments[id] ! else NOT_FOUND
  require a.carrier = viewer else NOT_OWNER
  require a.status = 'booked' else BAD_STATUS
  require a.lateAccepted or now <= a.startAt + 30m else LATE_SLOT_LOST 'Arrived more than 30 minutes late; the slot is lost. Rebook.'
  update appointments[id] { arrivedAt: now, bol, sealPhoto, status: 'arrived' }
  return null

mutation beginUnloading(id: appointments, door: text 1..20):
  require exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
  a = appointments[id] ! else NOT_FOUND
  require a.status = 'arrived' else BAD_STATUS
  update appointments[id] { status: 'unloading', unloadingBeganAt: now, door }
  return null

mutation completeUnloading(id: appointments):
  require exists roles[principal = viewer, role = 'dock_worker'] or exists roles[principal = viewer, role = 'dock_lead'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
  a = appointments[id] ! else NOT_FOUND
  require a.status = 'unloading' else BAD_STATUS
  update appointments[id] { status: 'done', completedAt: now }
  return null

mutation acceptLate(id: appointments):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  a = appointments[id] ! else NOT_FOUND
  require a.status = 'booked' else BAD_STATUS
  update appointments[id] { lateAccepted: true }
  return null

mutation refuseLoad(id: appointments, reason: text 1..500):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  a = appointments[id] ! else NOT_FOUND
  require a.status = 'arrived' or a.status = 'unloading' else BAD_STATUS
  update appointments[id] { status: 'refused', refusalReason: reason }
  return null

-- Booked slots left unarrived past the 30-minute grace window lose the slot.
job expireLate(periodStart: time, periodEnd: time):
  for a in appointments by .id:
    if a.status = 'booked' and a.startAt >= periodEnd - 8d and a.startAt < periodEnd - 30m and not a.lateAccepted:
      update appointments[a.id] { status: 'expired' }

schedule expiry every 5m: expireLate
