use identity password

table roles:
  principal: principal
  role: enum('manager', 'crew', 'inspector', 'buyer')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('manager', 'crew', 'inspector', 'buyer')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

query buyers(c: cursor ?):
  require exists roles[viewer, role = 'manager'] else FORBIDDEN
  return roles where .role = 'buyer' first 100 by .id after c

table leases:
  name: text 1..80
  state: enum('open', 'closed')
  reason: text <=500
  changedBy: principal
  changedAt: time
  unique name
  read <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'inspector']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'inspector']
  online only

table batches:
  code: text 1..80
  recallReason: text <=500 ?
  recalledBy: principal ?
  recalledAt: time ?
  unique code
  immutable code
  read <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew']
  insert <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew']
  update <- exists roles[viewer, role = 'manager']
  online only

table bags:
  tag: text 1..80
  batch: text 1..80
  lease: leases
  leaseName: text 1..80
  photo: image <=5000000
  harvestedBy: principal
  harvestedAt: time
  deadline: time
  chilledAt: time ?
  buyer: principal ?
  soldAt: time ?
  retainUntil: time ?
  flagged: bool default false
  discardReason: text <=500 ?
  discardedBy: principal ?
  discardedAt: time ?
  recallReason: text <=500 ?
  recalledBy: principal ?
  recalledAt: time ?
  unique tag
  cap 200 by batch
  immutable tag, batch, lease, leaseName, photo, harvestedBy, harvestedAt, deadline
  read <- .buyer = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'inspector']
  insert <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew']
  expire at .retainUntil
  online only

query leaseBoard(c: cursor ?):
  require exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'inspector'] else FORBIDDEN
  return leases first 100 by .id after c

query bagBoard(c: cursor ?):
  require exists roles[viewer] else FORBIDDEN
  r = roles[viewer] ! else FORBIDDEN
  if r.role = 'buyer':
    return bags where .buyer = viewer last 100 by .id after c { *, overdue: .chilledAt = null and now >= .deadline }
  return bags last 100 by .id after c { *, overdue: .chilledAt = null and now >= .deadline }

query bagDetail(bag: bags):
  require exists roles[viewer] else FORBIDDEN
  return bags[bag] { *, overdue: .chilledAt = null and now >= .deadline }

mutation createLease(name: text 1..80):
  require exists roles[viewer, role = 'manager'] else FORBIDDEN
  return insert leases { name, state: 'open', reason: '', changedBy: viewer, changedAt: now }

mutation closeLease(lease: leases, reason: enum('heavy rain', 'bad lab result')):
  require exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'inspector'] else FORBIDDEN
  a = leases[lease] ! else NOT_FOUND
  update leases[lease] { state: 'closed', reason, changedBy: viewer, changedAt: now }

mutation reopenLease(lease: leases):
  require exists roles[viewer, role = 'inspector'] else FORBIDDEN
  a = leases[lease] ! else NOT_FOUND
  require a.state = 'closed' else ALREADY_OPEN
  update leases[lease] { state: 'open', reason: '', changedBy: viewer, changedAt: now }

mutation harvest(tag: text 1..80, batch: text 1..80, lease: leases, photo: image <=5000000):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else FORBIDDEN
  a = leases[lease] ! else NOT_FOUND
  require a.state = 'open' else LEASE_CLOSED
  if not exists batches[batch]:
    insert batches { code: batch }
  lot = batches[batch] ! else NOT_FOUND
  require lot.recallReason = null else BATCH_RECALLED
  return insert bags { tag, batch, lease, leaseName: a.name, photo, harvestedBy: viewer, harvestedAt: now, deadline: now + 5h }

mutation refrigerate(bag: bags):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'manager'] else FORBIDDEN
  b = bags[bag] ! else NOT_FOUND
  require b.chilledAt = null else ALREADY_CHILLED
  require now < b.deadline else COLD_CHAIN_EXPIRED
  require b.discardReason = null and b.recallReason = null else UNSAFE
  update bags[bag] { chilledAt: now }

mutation sell(bag: bags, buyer: principal):
  require exists roles[viewer, role = 'manager'] else FORBIDDEN
  b = bags[bag] ! else NOT_FOUND
  require exists roles[buyer, role = 'buyer'] else NOT_BUYER
  require b.buyer = null else ALREADY_SOLD
  require b.chilledAt != null and b.chilledAt < b.deadline else NOT_REFRIGERATED
  require b.discardReason = null and b.recallReason = null else UNSAFE
  update bags[bag] { buyer, soldAt: now, retainUntil: now + 90d }

mutation discard(bag: bags, reason: text 1..500):
  require exists roles[viewer, role = 'manager'] else FORBIDDEN
  b = bags[bag] ! else NOT_FOUND
  require b.discardReason = null else ALREADY_DISCARDED
  update bags[bag] { discardReason: reason, discardedBy: viewer, discardedAt: now }

mutation recallBatch(batch: text 1..80, reason: text 1..500):
  require exists roles[viewer, role = 'manager'] else FORBIDDEN
  lot = batches[batch] ! else NOT_FOUND
  require lot.recallReason = null else ALREADY_RECALLED
  members = bags where .batch = batch first 200 by .id
  for b in members:
    require b.recallReason = null else ALREADY_RECALLED
    update bags[b.id] { recallReason: reason, recalledBy: viewer, recalledAt: now }
  update batches[batch] { recallReason: reason, recalledBy: viewer, recalledAt: now }

job flagLate(periodStart: time, periodEnd: time):
  for b in bags:
    if b.deadline <= now and b.chilledAt = null and b.flagged = false:
      update bags[b.id] { flagged: true }

schedule coldChain every 1m: flagLate
