use identity password

table roles:
  principal: principal
  role: enum('vet', 'owner', 'hand')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table handDirectory:
  principal: principal
  name: text 1..100
  unique principal
  immutable principal
  read <- exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'vet'] or .principal = viewer
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table herds:
  owner: principal
  name: text 1..80
  immutable owner
  read <- .owner = viewer or exists roles[viewer, role = 'vet'] or exists hands[.id, viewer]
  insert <- .owner = viewer and exists roles[viewer, role = 'owner']
  online only

table hands:
  herd: herds
  principal: principal
  unique herd, principal
  immutable herd, principal
  read <- .principal = viewer or exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet']
  insert <- exists herds[.herd, owner = viewer] and exists roles[.principal, role = 'hand']
  online only

table treatments:
  herd: herds
  earTag: text 1..30
  drug: text 1..100
  dose: text 1..80
  label: image <=5000000
  lastDose: time
  withdrawalHours: int 1..1440
  endsAt: time
  chargeCents: int 0..10000000 read <- exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet']
  notes: text <=4000 read <- exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet']
  vet: principal
  releasedAt: time ?
  immutable herd, earTag, drug, dose, label, withdrawalHours, vet
  read <- exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet'] or exists hands[.herd, viewer]
  insert <- exists roles[viewer, role = 'vet'] and .vet = viewer
  update <- exists roles[viewer, role = 'vet'] or exists herds[.herd, owner = viewer] or exists hands[.herd, viewer]
  online only

table tests:
  treatment: treatments
  herd: herds
  vet: principal
  result: text 3..1000
  previousEnd: time
  newEnd: time
  at: time
  immutable treatment, herd, vet, result, previousEnd, newEnd, at
  read <- exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet']
  insert <- exists roles[viewer, role = 'vet'] and .vet = viewer
  online only

mutation provision(principal: principal, role: enum('vet', 'owner', 'hand')):
  require viewer = 'service:operator' else NOT_OPERATOR
  upsert roles[principal] { principal, role }
  if role = 'hand':
    upsert handDirectory[principal] { principal, name: 'Farm hand' }

query myRole():
  return roles[viewer]
query availableHands():
  require exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'vet'] else NOT_OWNER
  return handDirectory first 100 by .id
query myHerds():
  return herds first 100 by .id
mutation createHerd(name: text 1..80):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return insert herds { owner: viewer, name }
mutation assignHand(herd: herds, principal: principal):
  h = herds[herd] ! else NOT_FOUND
  require h.owner = viewer else NOT_OWNER
  require exists handDirectory[principal] else NOT_HAND
  return insert hands { herd, principal } if absent
query herdHands(herd: herds):
  require exists herds[herd] else NOT_FOUND
  return hands where .herd = herd first 100 by .id
query board(herd: herds, c: cursor ?):
  require exists herds[herd] else NOT_FOUND
  return treatments where .herd = herd last 100 by .id after c
query treatmentDetail(treatment: treatments):
  return treatments[treatment]
query testHistory(treatment: treatments):
  t = treatments[treatment] ! else NOT_FOUND
  require exists roles[viewer, role = 'vet'] or exists herds[t.herd, owner = viewer] else PRIVATE
  return tests where .treatment = treatment first 100 by .id
mutation recordTreatment(herd: herds, earTag: text 1..30, drug: text 1..100, dose: text 1..80, label: image <=5000000, lastDose: time, withdrawalHours: int 1..1440, chargeCents: int 0..10000000, notes: text <=4000):
  require exists roles[viewer, role = 'vet'] else NOT_VET
  require exists herds[herd] else NOT_FOUND
  require lastDose <= now and lastDose >= now - 60d else INVALID_DOSE_TIME
  return insert treatments { herd, earTag, drug, dose, label, lastDose, withdrawalHours, endsAt: lastDose + withdrawalHours * 1h, chargeCents, notes, vet: viewer }
mutation addDose(treatment: treatments, lastDose: time):
  require exists roles[viewer, role = 'vet'] else NOT_VET
  t = treatments[treatment] ! else NOT_FOUND
  require lastDose >= t.lastDose and lastDose <= now else INVALID_DOSE_TIME
  return update treatments[treatment] { lastDose, endsAt: lastDose + t.withdrawalHours * 1h, releasedAt: null }
mutation shortenWithdrawal(treatment: treatments, endsAt: time, result: text 3..1000):
  require exists roles[viewer, role = 'vet'] else NOT_VET
  t = treatments[treatment] ! else NOT_FOUND
  require t.endsAt > now else ALREADY_ENDED
  require endsAt >= now and endsAt >= t.lastDose and endsAt < t.endsAt else INVALID_END
  insert tests { treatment, herd: t.herd, vet: viewer, result, previousEnd: t.endsAt, newEnd: endsAt, at: now }
  return update treatments[treatment] { endsAt, releasedAt: null }
mutation releaseMilk(treatment: treatments):
  t = treatments[treatment] ! else NOT_FOUND
  require now >= t.endsAt else MILK_WITHHELD
  require not exists treatments[herd = t.herd, earTag = t.earTag, endsAt > now] else MILK_WITHHELD
  return update treatments[treatment] { releasedAt: now }

-- Independent product intent for static auditing, in addition to table rules.
invariant roles.provision only viewer = 'service:operator'
invariant treatments.recordTreatment only exists roles[viewer, role = 'vet']
invariant treatments.addDose only exists roles[viewer, role = 'vet']
invariant treatments.shortenWithdrawal only exists roles[viewer, role = 'vet']
invariant treatments.chargeCents read only exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet']
invariant treatments.notes read only exists herds[.herd, owner = viewer] or exists roles[viewer, role = 'vet']
