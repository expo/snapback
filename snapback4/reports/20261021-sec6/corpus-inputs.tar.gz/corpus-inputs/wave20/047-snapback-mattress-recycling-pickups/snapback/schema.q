use identity password

-- Roles are granted by the local program operator, never by signup.
table roles:
  principal: principal
  role: enum('resident', 'retailer', 'driver', 'manager')
  store: text 1..80 ?
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('resident', 'retailer', 'driver', 'manager'), store: text 1..80 ?):
  require viewer = 'service:operator' else NOT_OPERATOR
  require (role = 'retailer' and store != null) or (role != 'retailer' and store = null) else STORE_REQUIRED
  return upsert roles[principal] { principal, role, store }

query myRole():
  return roles[viewer]

query drivers():
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  return roles where .role = 'driver' first 100 by .id

table pickups:
  owner: principal
  store: text 1..80 ?
  label: text 1..100
  address: text 5..240
  mattress: enum('twin', 'full', 'queen', 'king')
  requestedAt: time default now
  scheduledAt: time ?
  driver: principal ?
  state: enum('requested', 'scheduled', 'collected', 'arrived', 'processed', 'refused') default 'requested'
  photo: image <=5000000 ?
  bedbugs: bool default false
  collectedAt: time ?
  arrivedAt: time ?
  wrappedAt: time ?
  processedAt: time ?
  contaminated: bool default false
  pickupFlag: bool default false
  processingFlag: bool default false
  immutable owner, store, label, address, mattress, requestedAt
  read <- .owner = viewer or .driver = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'retailer', store = .store]
  insert <- .owner = viewer and (exists roles[viewer, role = 'resident'] or exists roles[viewer, role = 'retailer', store = .store])
  update <- .driver = viewer or exists roles[viewer, role = 'manager']
  online only

shape pickupCard = { *, pickupOverdue: .pickupFlag or (.state = 'scheduled' and .collectedAt = null and now > .requestedAt + 7d), processingOverdue: .processingFlag or (.bedbugs and .arrivedAt != null and .processedAt = null and .state != 'refused' and now > .arrivedAt + 24h) }

query listPickups(c: cursor ?):
  r = roles[viewer] ! else NO_ROLE
  if r.role = 'resident':
    return pickups where .owner = viewer first 100 by .id after c pickupCard
  if r.role = 'retailer':
    return pickups where .store = r.store first 100 by .id after c pickupCard
  if r.role = 'driver':
    return pickups where .driver = viewer first 100 by .id after c pickupCard
  return pickups first 100 by .id after c pickupCard

query pickup(pickup: pickups):
  require exists roles[viewer] else NO_ROLE
  return pickups[pickup] pickupCard

mutation requestPickup(label: text 1..100, address: text 5..240, mattress: enum('twin', 'full', 'queen', 'king')):
  r = roles[viewer] ! else NO_ROLE
  require r.role = 'resident' or r.role = 'retailer' else REQUESTER_ONLY
  return insert pickups { owner: viewer, store: r.store, label, address, mattress }

mutation schedulePickup(pickup: pickups, driver: principal, scheduledAt: time):
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  p = pickups[pickup] ! else NOT_FOUND
  require p.state = 'requested' or p.state = 'scheduled' else BAD_STATE
  require exists roles[driver, role = 'driver'] else DRIVER_REQUIRED
  require scheduledAt >= now and scheduledAt <= now + 7d else BAD_SCHEDULE
  return update pickups[pickup] { driver, scheduledAt, state: 'scheduled' }

mutation collectPickup(pickup: pickups, photo: image <=5000000, bedbugs: bool):
  require exists roles[viewer, role = 'driver'] else DRIVER_ONLY
  p = pickups[pickup] ! else NOT_FOUND
  require p.driver = viewer else YOUR_ROUTE_ONLY
  require p.state = 'scheduled' else BAD_STATE
  return update pickups[pickup] { photo, bedbugs, collectedAt: now, state: 'collected', pickupFlag: p.pickupFlag or now > p.requestedAt + 7d }

mutation arrivePickup(pickup: pickups):
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  p = pickups[pickup] ! else NOT_FOUND
  require p.state = 'collected' else BAD_STATE
  return update pickups[pickup] { arrivedAt: now, state: 'arrived' }

mutation wrapPickup(pickup: pickups):
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  p = pickups[pickup] ! else NOT_FOUND
  require p.state = 'arrived' and p.wrappedAt = null else BAD_STATE
  require not p.bedbugs or (p.arrivedAt != null and now <= p.arrivedAt + 24h) else PROCESSING_DEADLINE
  return update pickups[pickup] { wrappedAt: now }

mutation processPickup(pickup: pickups):
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  p = pickups[pickup] ! else NOT_FOUND
  require p.state = 'arrived' else BAD_STATE
  require not p.bedbugs or p.wrappedAt != null else WRAP_REQUIRED
  require not p.bedbugs or (p.arrivedAt != null and now <= p.arrivedAt + 24h) else PROCESSING_DEADLINE
  update pickups[pickup] { processedAt: now, state: 'processed' }
  return insert receipts { pickup, owner: p.owner, store: p.store, label: p.label, processedAt: now, manager: viewer }

table receipts:
  pickup: pickups
  owner: principal
  store: text 1..80 ?
  label: text 1..100
  processedAt: time
  manager: principal
  unique pickup
  immutable pickup, owner, store, label, processedAt, manager
  read <- .owner = viewer or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'retailer', store = .store]
  insert <- exists roles[viewer, role = 'manager']
  online only

query listReceipts(c: cursor ?):
  r = roles[viewer] ! else NO_ROLE
  if r.role = 'manager':
    return receipts first 100 by .id after c
  if r.role = 'retailer':
    return receipts where .store = r.store first 100 by .id after c
  return receipts where .owner = viewer first 100 by .id after c

query receipt(receipt: receipts):
  require exists roles[viewer] else NO_ROLE
  return receipts[receipt]

table decisions:
  pickup: pickups
  store: text 1..80 ?
  actor: principal
  kind: enum('refused', 'contaminated')
  reason: text 5..500
  at: time default now
  immutable pickup, store, actor, kind, reason, at
  read <- exists pickups[.pickup, owner = viewer] or exists pickups[.pickup, driver = viewer] or exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'retailer', store = .store]
  insert <- exists roles[viewer, role = 'manager'] and .actor = viewer and .store = .pickup.store
  online only

query decisions(pickup: pickups, c: cursor ?):
  require exists roles[viewer] else NO_ROLE
  return decisions where .pickup = pickup first 100 by .id after c

mutation decideLoad(pickup: pickups, kind: enum('refused', 'contaminated'), reason: text 5..500):
  require exists roles[viewer, role = 'manager'] else MANAGER_ONLY
  p = pickups[pickup] ! else NOT_FOUND
  require p.state = 'collected' or p.state = 'arrived' else BAD_STATE
  if kind = 'refused':
    update pickups[pickup] { state: 'refused' }
  else:
    require not p.contaminated else ALREADY_CONTAMINATED
    update pickups[pickup] { contaminated: true }
  return insert decisions { pickup, store: p.store, actor: viewer, kind, reason }

job flagDeadlines():
  for p in pickups:
    if p.state = 'scheduled' and p.collectedAt = null and now > p.requestedAt + 7d and not p.pickupFlag:
      update pickups[p.id] { pickupFlag: true }
    if p.bedbugs and p.arrivedAt != null and p.processedAt = null and p.state != 'refused' and now > p.arrivedAt + 24h and not p.processingFlag:
      update pickups[p.id] { processingFlag: true }
schedule deadlineSweep every 1m: flagDeadlines
