-- Coop Board Applications: a housing cooperative reviews purchase applications.
-- Roles: applicant, board_member, agent (managing agent), president (board president).
-- Board members see household/employment/references/interview notes but never
-- bank statements, tax returns or the credit report (managing agent only).
-- Applicants see only their own application. Incomplete applications lapse
-- 21 days after submission. Only the president may approve or reject, with vote recorded.
use identity password

table roles:
  principal: principal
  role: enum('applicant', 'board_member', 'agent', 'president')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('applicant', 'board_member', 'agent', 'president')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[viewer]

table applications:
  applicant: principal
  household: text 1..2000
  employment: text 1..2000
  referencesText: text 1..2000 ?
  interviewNotes: text <=2000 ?
  bankStatement: text <=5000 ? read <- .applicant = viewer or exists roles[principal = viewer, role = 'agent']
  taxReturn: text <=5000 ? read <- .applicant = viewer or exists roles[principal = viewer, role = 'agent']
  creditReport: text <=5000 ? read <- .applicant = viewer or exists roles[principal = viewer, role = 'agent']
  status: enum('incomplete', 'complete', 'approved', 'rejected', 'lapsed')
  submittedAt: time
  lapsesAt: time
  immutable applicant, submittedAt, lapsesAt
  cap 100 by applicant
  read <- .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
  insert <- exists roles[principal = viewer, role = 'applicant'] and .applicant = viewer
  update <- .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
  online only

table interviews:
  application: applications
  applicant: principal
  scheduledAt: time
  location: text 1..200
  notes: text <=2000 ?
  immutable application, applicant
  cap 20 by application
  read <- .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
  insert <- exists roles[principal = viewer, role = 'agent']
  update <- exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'president']
  online only

table decisions:
  application: applications
  applicant: principal
  decision: enum('approved', 'rejected')
  vote: text 1..20
  decidedBy: principal
  decidedAt: time
  unique application
  immutable application, applicant, decision, vote, decidedBy, decidedAt
  read <- .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
  insert <- exists roles[principal = viewer, role = 'president']
  online only

query myApplications(c: cursor ?):
  return applications where .applicant = viewer first 50 by .id after c

query application(app: applications):
  return applications[app]

query allApplications(c: cursor ?):
  require exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president'] else NOT_AUTHORIZED
  return applications first 50 by .id after c

query myInterviews(c: cursor ?):
  return interviews where .applicant = viewer first 50 by .scheduledAt after c

query upcomingInterviews(c: cursor ?):
  require exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president'] else NOT_AUTHORIZED
  return interviews first 50 by .scheduledAt after c

query appInterviews(app: applications, c: cursor ?):
  return interviews where .application = app first 50 by .scheduledAt after c

query decisionFor(app: applications):
  return decisions[app]

query allDecisions(c: cursor ?):
  require exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president'] else NOT_AUTHORIZED
  return decisions first 50 by .decidedAt after c

mutation submitApplication(household: text 1..2000, employment: text 1..2000):
  require exists roles[principal = viewer, role = 'applicant'] else NOT_APPLICANT
  return insert applications { applicant: viewer, household, employment, status: 'incomplete', submittedAt: now, lapsesAt: now + 21d }

mutation updateHousehold(app: applications, household: text 1..2000, employment: text 1..2000):
  require exists roles[principal = viewer, role = 'applicant'] else NOT_APPLICANT
  a = applications[app] ! else NOT_FOUND
  require a.applicant = viewer else NOT_OWNER
  require a.status = 'incomplete' else NOT_INCOMPLETE
  require now <= a.lapsesAt else LAPSED 'This application has lapsed.'
  update applications[app] { household, employment }
  return null

mutation uploadFinancials(app: applications, bankStatement: text <=5000 ?, taxReturn: text <=5000 ?):
  require exists roles[principal = viewer, role = 'applicant'] else NOT_APPLICANT
  a = applications[app] ! else NOT_FOUND
  require a.applicant = viewer else NOT_OWNER
  require a.status = 'incomplete' else NOT_INCOMPLETE
  require now <= a.lapsesAt else LAPSED 'This application has lapsed.'
  update applications[app] { bankStatement: bankStatement ?? a.bankStatement, taxReturn: taxReturn ?? a.taxReturn }
  return null

mutation uploadReferences(app: applications, referencesText: text 1..2000):
  require exists roles[principal = viewer, role = 'applicant'] else NOT_APPLICANT
  a = applications[app] ! else NOT_FOUND
  require a.applicant = viewer else NOT_OWNER
  require a.status = 'incomplete' else NOT_INCOMPLETE
  require now <= a.lapsesAt else LAPSED 'This application has lapsed.'
  update applications[app] { referencesText }
  return null

mutation fileCreditReport(app: applications, creditReport: text <=5000):
  require exists roles[principal = viewer, role = 'agent'] else NOT_AGENT
  a = applications[app] ! else NOT_FOUND
  require a.status = 'incomplete' or a.status = 'complete' else NOT_ACTIVE
  update applications[app] { creditReport }
  return null

mutation markComplete(app: applications):
  require exists roles[principal = viewer, role = 'applicant'] else NOT_APPLICANT
  a = applications[app] ! else NOT_FOUND
  require a.applicant = viewer else NOT_OWNER
  require a.status = 'incomplete' else NOT_INCOMPLETE
  require now <= a.lapsesAt else LAPSED 'This application has lapsed.'
  require a.bankStatement != null and a.taxReturn != null and a.referencesText != null else STILL_INCOMPLETE 'Upload bank statement, tax return and references first.'
  update applications[app] { status: 'complete' }
  return null

mutation scheduleInterview(app: applications, scheduledAt: time, location: text 1..200):
  require exists roles[principal = viewer, role = 'agent'] else NOT_AGENT
  a = applications[app] ! else NOT_FOUND
  require a.status = 'complete' else NOT_READY
  require scheduledAt > now else BAD_TIME 'Interviews must be scheduled in the future.'
  return insert interviews { application: app, applicant: a.applicant, scheduledAt, location }

mutation rescheduleInterview(iv: interviews, scheduledAt: time):
  require exists roles[principal = viewer, role = 'agent'] else NOT_AGENT
  i = interviews[iv] ! else NOT_FOUND
  require scheduledAt > now else BAD_TIME 'Interviews must be scheduled in the future.'
  update interviews[iv] { scheduledAt }
  return null

mutation addInterviewNotes(app: applications, notes: text <=2000):
  require exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'president'] else NOT_BOARD
  a = applications[app] ! else NOT_FOUND
  update applications[app] { interviewNotes: notes }
  return null

mutation decide(app: applications, decision: enum('approved', 'rejected'), vote: text 1..20):
  require exists roles[principal = viewer, role = 'president'] else NOT_PRESIDENT
  a = applications[app] ! else NOT_FOUND
  require a.status = 'complete' else NOT_READY
  insert decisions { application: app, applicant: a.applicant, decision, vote, decidedBy: viewer, decidedAt: now }
  if decision = 'approved':
    update applications[app] { status: 'approved' }
  else:
    update applications[app] { status: 'rejected' }
  return null

job lapseExpired(periodStart: time, periodEnd: time):
  for a in applications where .submittedAt >= periodEnd - 30d and .submittedAt < periodEnd - 21d by .submittedAt:
    if a.status = 'incomplete':
      update applications[a.id] { status: 'lapsed' }

schedule lapseDaily every 1d at 03:00: lapseExpired

-- Privacy intent from the spec. Board members see household, employment,
-- references and interview notes, but never bank statements, tax returns or
-- the credit report, which only the managing agent (and the owning applicant) sees.
invariant applications.read only .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
invariant applications.bankStatement read only .applicant = viewer or exists roles[principal = viewer, role = 'agent']
invariant applications.taxReturn read only .applicant = viewer or exists roles[principal = viewer, role = 'agent']
invariant applications.creditReport read only .applicant = viewer or exists roles[principal = viewer, role = 'agent']
invariant applications.insert only exists roles[principal = viewer, role = 'applicant'] and .applicant = viewer
invariant interviews.read only .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
invariant interviews.insert only exists roles[principal = viewer, role = 'agent']
invariant decisions.read only .applicant = viewer or exists roles[principal = viewer, role = 'board_member'] or exists roles[principal = viewer, role = 'agent'] or exists roles[principal = viewer, role = 'president']
invariant decisions.insert only exists roles[principal = viewer, role = 'president']
