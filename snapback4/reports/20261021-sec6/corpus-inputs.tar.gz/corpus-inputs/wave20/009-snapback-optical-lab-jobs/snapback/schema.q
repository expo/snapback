use identity password

table roster:
  principal: principal
  role: enum('shop_staff', 'lab_technician', 'lab_manager')
  shop: text <=40
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('shop_staff', 'lab_technician', 'lab_manager'), shop: text <=40):
  require viewer = 'service:operator' else NOT_OPERATOR
  require (role = 'shop_staff' and len(shop) > 0) or (role != 'shop_staff' and shop = '') else INVALID_SHOP
  return upsert roster[principal] { principal, role, shop }

query myRole():
  r = roster[principal = viewer] ! else NOT_ENROLLED
  return r

table jobs:
  shop: text 1..40
  reference: text 1..80
  submittedBy: principal
  arrivedAt: time default now
  stage: enum('arrived', 'surfacing', 'coating', 'edging', 'finished') default 'arrived'
  lens: enum('single_vision', 'bifocal', 'progressive')
  rightSphere: int -2000..2000
  leftSphere: int -2000..2000
  rightCylinder: int -600..600
  leftCylinder: int -600..600
  rightAxis: int 0..180
  leftAxis: int 0..180
  pd: int 400..800
  height: int 0..500
  frame: text 1..100
  traceName: text 1..100
  traceText: text 1..200000
  broken: bool default false
  remakeCount: int 0.. default 0
  immutable shop, reference, submittedBy, arrivedAt, lens, rightSphere, leftSphere, rightCylinder, leftCylinder, rightAxis, leftAxis, pd, height, frame, traceName, traceText
  read <- exists roster[principal = viewer, role = 'lab_technician'] or exists roster[principal = viewer, role = 'lab_manager'] or exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
  insert <- .submittedBy = viewer and exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
  update <- exists roster[principal = viewer, role = 'lab_technician'] or exists roster[principal = viewer, role = 'lab_manager']
  online only

table patients:
  job: jobs
  shop: text 1..40
  name: text 1..100
  phone: text 5..30
  insurance: text 1..100
  unique job
  immutable job, shop, name, phone, insurance
  read <- exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
  insert <- exists roster[principal = viewer, role = 'shop_staff', shop = .shop] and exists jobs[.job, shop = .shop, submittedBy = viewer]
  online only

table breakages:
  job: jobs
  reason: text 3..500
  reportedBy: principal
  reportedAt: time default now
  approvalReason: text 3..500 ?
  approvedBy: principal ?
  approvedAt: time ?
  immutable job, reason, reportedBy, reportedAt
  read <- exists roster[principal = viewer, role = 'lab_technician'] or exists roster[principal = viewer, role = 'lab_manager'] or exists roster[principal = viewer, role = 'shop_staff', shop = .job.shop]
  insert <- .reportedBy = viewer and (exists roster[principal = viewer, role = 'lab_technician'] or exists roster[principal = viewer, role = 'lab_manager'])
  update <- exists roster[principal = viewer, role = 'lab_manager']
  online only

mutation createJob(reference: text 1..80, lens: enum('single_vision', 'bifocal', 'progressive'), rightSphere: int -2000..2000, leftSphere: int -2000..2000, rightCylinder: int -600..600, leftCylinder: int -600..600, rightAxis: int 0..180, leftAxis: int 0..180, pd: int 400..800, height: int 0..500, frame: text 1..100, traceName: text 1..100, traceText: text 1..200000, name: text 1..100, phone: text 5..30, insurance: text 1..100):
  r = roster[principal = viewer] ! else NOT_ENROLLED
  require r.role = 'shop_staff' else NOT_SHOP_STAFF
  j = insert jobs { shop: r.shop, submittedBy: viewer, reference, lens, rightSphere, leftSphere, rightCylinder, leftCylinder, rightAxis, leftAxis, pd, height, frame, traceName, traceText }
  insert patients { job: j.id, shop: r.shop, name, phone, insurance }
  return j

query listJobs(c: cursor ?):
  require exists roster[principal = viewer] else NOT_ENROLLED
  return jobs last 100 by .arrivedAt after c { id, shop, reference, arrivedAt, stage, lens, frame, broken, remakeCount }

query jobDetail(job: jobs):
  require exists roster[principal = viewer] else NOT_ENROLLED
  j = jobs[job] ! else NOT_FOUND
  return { job: j, breakages: breakages where .job = job last 100 by .reportedAt }

query patientDetail(job: jobs):
  r = roster[principal = viewer] ! else NOT_ENROLLED
  require r.role = 'shop_staff' else PATIENT_PRIVATE
  j = jobs[job] ! else NOT_FOUND
  require j.shop = r.shop else PATIENT_PRIVATE
  return patients[job = job]

mutation advanceStage(job: jobs, expected: enum('arrived', 'surfacing', 'coating', 'edging')):
  require exists roster[principal = viewer, role = 'lab_technician'] or exists roster[principal = viewer, role = 'lab_manager'] else NOT_LAB
  j = jobs[job] ! else NOT_FOUND
  require not j.broken else BREAKAGE_PENDING
  require j.stage = expected else STALE_STAGE
  nextStage = 'surfacing' if expected = 'arrived' else 'coating' if expected = 'surfacing' else 'edging' if expected = 'coating' else 'finished'
  return update jobs[job] { stage: nextStage }

mutation reportBreakage(job: jobs, reason: text 3..500):
  require exists roster[principal = viewer, role = 'lab_technician'] or exists roster[principal = viewer, role = 'lab_manager'] else NOT_LAB
  j = jobs[job] ! else NOT_FOUND
  require j.stage != 'finished' else ALREADY_FINISHED
  require not j.broken else BREAKAGE_PENDING
  b = insert breakages { job, reason, reportedBy: viewer }
  update jobs[job] { broken: true }
  return b

mutation approveRemake(breakage: breakages, reason: text 3..500):
  require exists roster[principal = viewer, role = 'lab_manager'] else NOT_MANAGER
  b = breakages[breakage] ! else NOT_FOUND
  require b.approvedAt = null else ALREADY_APPROVED
  j = jobs[b.job] ! else NOT_FOUND
  require j.broken else NO_BREAKAGE
  update breakages[breakage] { approvalReason: reason, approvedBy: viewer, approvedAt: now }
  return update jobs[b.job] { broken: false, stage: 'arrived', remakeCount: j.remakeCount + 1 }

query overdueJobs(c: cursor ?):
  require exists roster[principal = viewer, role = 'lab_manager'] else NOT_MANAGER
  return jobs where .stage != 'finished' and .arrivedAt <= now - 7d first 100 by .arrivedAt after c { id, shop, reference, arrivedAt, stage }

-- Patient identity is exclusively for staff of the sending shop.
invariant patients.read only exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
invariant patients.name read only exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
invariant patients.phone read only exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
invariant patients.insurance read only exists roster[principal = viewer, role = 'shop_staff', shop = .shop]
invariant roster.role write only viewer = 'service:operator'
invariant breakages.approvalReason update only exists roster[principal = viewer, role = 'lab_manager']
invariant jobs.approveRemake only exists roster[principal = viewer, role = 'lab_manager']
