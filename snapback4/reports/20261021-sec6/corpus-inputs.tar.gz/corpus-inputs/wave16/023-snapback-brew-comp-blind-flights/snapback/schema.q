use identity password

table roles:
  principal: principal
  role: enum('brewer', 'steward', 'judge', 'organizer')
  unique principal
  immutable principal, role
  read <- .principal = viewer or exists roles[principal = viewer, role = 'organizer'] or exists roles[principal = viewer, role = 'steward'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table competitions:
  title: text 1..100
  publishAt: time
  immutable title, publishAt
  read <- exists roles[principal = viewer]
  insert <- exists roles[principal = viewer, role = 'organizer']
  cap 20
  online only

table flights:
  competition: competitions
  title: text 1..60
  style: enum('IPA', 'Stout', 'Lager', 'Saison')
  immutable competition, title, style
  read <- exists roles[principal = viewer, role = 'steward'] or exists roles[principal = viewer, role = 'organizer'] or exists assignments[flight = .id, judge = viewer]
  insert <- exists roles[principal = viewer, role = 'steward']
  cap 100 by competition
  online only

table assignments:
  flight: flights
  judge: principal
  unique flight, judge
  immutable flight, judge
  read <- .judge = viewer or exists roles[principal = viewer, role = 'steward'] or exists roles[principal = viewer, role = 'organizer']
  insert <- exists roles[principal = viewer, role = 'steward'] and exists roles[principal = .judge, role = 'judge']
  cap 8 by flight
  online only

table samples:
  competition: competitions
  style: enum('IPA', 'Stout', 'Lager', 'Saison')
  number: int 100000..999999
  flight: flights ?
  disqualified: bool default false
  unique competition, number
  immutable competition, number
  read <- exists entries[sample = .id, owner = viewer] or exists roles[principal = viewer, role = 'steward'] or exists roles[principal = viewer, role = 'organizer'] or exists assignments[flight = .flight, judge = viewer]
  insert <- exists roles[principal = viewer, role = 'brewer']
  update <- exists roles[principal = viewer, role = 'steward'] or exists roles[principal = viewer, role = 'organizer']
  cap 500 by competition
  online only

table entries:
  competition: competitions
  sample: samples
  owner: principal
  name: text 1..100
  unique sample
  immutable competition, sample, owner, name
  read <- .owner = viewer or exists roles[principal = viewer, role = 'organizer']
  insert <- .owner = viewer and exists roles[principal = viewer, role = 'brewer']
  cap 20 by owner
  online only

table scores:
  sample: samples
  judge: principal
  aroma: int 0..12
  appearance: int 0..3
  flavor: int 0..20
  mouthfeel: int 0..5
  overall: int 0..10
  notes: text 1..4000
  photo: image <=5000000 ?
  unique sample, judge
  immutable sample, judge, aroma, appearance, flavor, mouthfeel, overall, notes, photo
  read <- .judge = viewer or exists roles[principal = viewer, role = 'organizer'] or exists publications[sample = .sample, owner = viewer]
  insert <- .judge = viewer and exists roles[principal = viewer, role = 'judge'] and exists assignments[flight = .sample.flight, judge = viewer]
  online only

table publications:
  sample: samples
  owner: principal
  unique sample, owner
  immutable sample, owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'organizer']
  online only

mutation provisionRole(principal: principal, role: enum('brewer', 'steward', 'judge', 'organizer')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert roles { principal, role }
query me():
  return roles[principal = viewer]
query competitionsList():
  return competitions first 20 by .id
query roster():
  require exists roles[principal = viewer, role = 'steward'] or exists roles[principal = viewer, role = 'organizer'] else STAFF_ONLY
  return roles first 100 by .id
mutation createCompetition(title: text 1..100, publishAt: time):
  require exists roles[principal = viewer, role = 'organizer'] else ORGANIZER_ONLY
  require publishAt > now else FUTURE_DATE_REQUIRED
  return insert competitions { title, publishAt }
mutation submitEntry(competition: competitions, name: text 1..100, style: enum('IPA', 'Stout', 'Lager', 'Saison'), number: int 100000..999999):
  require exists roles[principal = viewer, role = 'brewer'] else BREWER_ONLY
  c = competitions[competition] ! else NOT_FOUND
  require now < c.publishAt else COMPETITION_CLOSED
  s = insert samples { competition, style, number, flight: null }
  return insert entries { competition, sample: s.id, owner: viewer, name }
query myEntries():
  return entries where .owner = viewer first 20 by .id
query entryDetail(entry: entries):
  return entries[entry]
query allEntries():
  require exists roles[principal = viewer, role = 'organizer'] else ORGANIZER_ONLY
  return entries first 500 by .id
query samplesList(competition: competitions):
  require exists roles[principal = viewer, role = 'steward'] or exists roles[principal = viewer, role = 'organizer'] else STAFF_ONLY
  return samples where .competition = competition first 500 by .id
query sampleDetail(sample: samples):
  return samples[sample]
mutation createFlight(competition: competitions, title: text 1..60, style: enum('IPA', 'Stout', 'Lager', 'Saison')):
  require exists roles[principal = viewer, role = 'steward'] else STEWARD_ONLY
  c = competitions[competition] ! else NOT_FOUND
  require now < c.publishAt else COMPETITION_CLOSED
  return insert flights { competition, title, style }
mutation assignJudge(flight: flights, judge: principal):
  require exists roles[principal = viewer, role = 'steward'] else STEWARD_ONLY
  f = flights[flight] ! else NOT_FOUND
  c = competitions[f.competition] ! else NOT_FOUND
  require now < c.publishAt else COMPETITION_CLOSED
  return insert assignments { flight, judge }
mutation groupSample(sample: samples, flight: flights):
  require exists roles[principal = viewer, role = 'steward'] else STEWARD_ONLY
  s = samples[sample] ! else NOT_FOUND
  f = flights[flight] ! else NOT_FOUND
  c = competitions[s.competition] ! else NOT_FOUND
  require now < c.publishAt else COMPETITION_CLOSED
  require s.flight = null else ALREADY_GROUPED
  require not s.disqualified else DISQUALIFIED
  require f.competition = s.competition and f.style = s.style else STYLE_MISMATCH
  update samples[sample] { flight }
query flightsList():
  return flights first 100 by .id
query flightSamples(flight: flights):
  require exists flights[flight] else FLIGHT_PRIVATE
  return samples where .flight = flight first 100 by .id
query assignmentsList():
  return assignments first 100 by .id
mutation moveStyle(sample: samples, style: enum('IPA', 'Stout', 'Lager', 'Saison')):
  require exists roles[principal = viewer, role = 'organizer'] else ORGANIZER_ONLY
  s = samples[sample] ! else NOT_FOUND
  c = competitions[s.competition] ! else NOT_FOUND
  require now < c.publishAt else COMPETITION_CLOSED
  require s.flight = null else ALREADY_GROUPED
  update samples[sample] { style }
mutation disqualify(sample: samples):
  require exists roles[principal = viewer, role = 'organizer'] else ORGANIZER_ONLY
  s = samples[sample] ! else NOT_FOUND
  c = competitions[s.competition] ! else NOT_FOUND
  require now < c.publishAt else COMPETITION_CLOSED
  update samples[sample] { disqualified: true }
mutation scoreEntry(sample: samples, aroma: int 0..12, appearance: int 0..3, flavor: int 0..20, mouthfeel: int 0..5, overall: int 0..10, notes: text 1..4000, photo: image <=5000000 ?):
  require exists roles[principal = viewer, role = 'judge'] else JUDGE_ONLY
  s = samples[sample] ! else NOT_FOUND
  c = competitions[s.competition] ! else NOT_FOUND
  require now < c.publishAt else JUDGING_CLOSED
  require not s.disqualified else DISQUALIFIED
  return insert scores { sample, judge: viewer, aroma, appearance, flavor, mouthfeel, overall, notes, photo }
query scoreSheets(sample: samples):
  return scores where .sample = sample first 8 by .id
query scoreDetail(score: scores):
  return scores[score]
query myPublications():
  return publications where .owner = viewer first 20 by .id
job publishResults():
  for e in entries:
    c = competitions[e.competition] ! else NOT_FOUND
    if now >= c.publishAt:
      insert publications { sample: e.sample, owner: e.owner } if absent
schedule publication every 1m: publishResults
