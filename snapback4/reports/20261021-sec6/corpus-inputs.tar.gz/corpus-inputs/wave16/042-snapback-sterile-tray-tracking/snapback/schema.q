-- Sterile Tray Tracking: surgical instrument trays through cleaning,
-- sterilization and storage. Roles: technician (works trays at their own
-- station), or_staff (sees ready trays per scheduled case), supervisor
-- (recalls a whole sterilizer load). Real password identity; no personas.
use identity password

-- Private handle per account. Owner-only: another user's record stays hidden.
table profiles:
  principal: principal
  handle: text 3..20 format handle
  unique principal
  unique handle
  read <- .principal = viewer
  insert <- .principal = viewer
  update <- .principal = viewer
  immutable principal
  cap 1 by principal
  online only

-- Department roster. Station pins a technician to their station; other roles
-- leave it null. First rows are provisioned by the operator seat (deploy
-- recipe); afterwards only a supervisor changes the roster.
table roles:
  principal: principal
  role: enum('technician', 'or_staff', 'supervisor')
  station: text 1..40 ?
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  insert <- exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  online only

-- One sterilizer run. Trays name the load they were sterilized in; a recall
-- flips the flag and every tray of the load to 'recalled'.
table loads:
  code: text 1..20
  sterilizer: text 1..40
  recalled: bool default false
  createdBy: principal
  createdAt: time default now
  unique code
  immutable code, createdBy, createdAt
  read <- exists roles[viewer] or viewer = 'service:ops'
  insert <- exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  online only

-- An instrument tray. Lifecycle: dirty -> cleaning -> sterile -> stored.
-- Sterilization records the load, the indicator photo and the 30-day expiry.
-- Expired or recalled trays go back through reprocessTray, never directly.
table trays:
  name: text 1..80
  trayType: text 1..80
  status: enum('dirty', 'cleaning', 'sterile', 'stored', 'recalled') default 'dirty'
  station: text 1..40
  load: loads ?
  sterilizedAt: time ?
  expiresAt: time ?
  indicator: image <=5000000 ?
  updatedAt: time default now
  immutable station
  cap 500 by load
  read <- exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'technician', station = .station] or (exists roles[viewer, role = 'or_staff'] and (.status = 'sterile' or .status = 'stored'))
  insert <- exists roles[viewer, role = 'technician', station = .station]
  update <- exists roles[viewer, role = 'supervisor'] or exists roles[viewer, role = 'technician', station = .station]
  online only

-- A scheduled OR case needing one tray type. Created by OR staff (or the
-- supervisor); every roster member reads the schedule.
table cases:
  title: text 1..120
  trayType: text 1..80
  scheduledAt: time
  createdBy: principal
  immutable createdBy
  read <- exists roles[viewer] or viewer = 'service:ops'
  insert <- exists roles[viewer, role = 'or_staff'] or exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  update <- .createdBy = viewer or exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  delete <- .createdBy = viewer or exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops'
  online only

query myRole():
  return roles[principal = viewer]

query myProfile():
  return profiles[principal = viewer]

query profileFor(owner: principal):
  require owner = viewer else PROFILE_PRIVATE
  return profiles[principal = owner]

-- A technician's own station board.
query stationTrays(c: cursor ?):
  r = roles[viewer] ! else NOT_TECHNICIAN
  require r.role = 'technician' else NOT_TECHNICIAN
  require r.station != null else NO_STATION
  return trays where .station = r.station last 50 by .id after c

-- Supervisor-only full board.
query allTrays(c: cursor ?):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  return trays last 50 by .id after c

-- Trays ready for a case: sterile or stored, unexpired. Recalled trays carry
-- status 'recalled', so they never match.
query readyTrays(trayType: text 1..80, c: cursor ?):
  require exists roles[viewer, role = 'or_staff'] or exists roles[viewer, role = 'supervisor'] else NOT_AUTHORIZED
  return trays where .trayType = trayType and (.status = 'sterile' or .status = 'stored') and .expiresAt > now last 50 by .id after c

query upcomingCases(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return cases where .scheduledAt >= now first 50 by .scheduledAt after c

query loadsList(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return loads last 50 by .id after c

mutation saveProfile(handle: text 3..20 format handle):
  return upsert profiles[viewer] { principal: viewer, handle }

-- Roster changes: supervisor, or the operator seat for the first rows.
mutation grantRole(who: principal, role: enum('technician', 'or_staff', 'supervisor'), station: text 1..40 ?):
  require exists roles[viewer, role = 'supervisor'] or viewer = 'service:ops' else NOT_SUPERVISOR
  require role != 'technician' or station != null else STATION_REQUIRED
  return upsert roles[who] { principal: who, role, station }

mutation createTray(name: text 1..80, trayType: text 1..80):
  r = roles[viewer] ! else NOT_TECHNICIAN
  require r.role = 'technician' else NOT_TECHNICIAN
  require r.station != null else NO_STATION
  return insert trays { name, trayType, status: 'dirty', station: r.station, updatedAt: now }

mutation createLoad(code: text 1..20, sterilizer: text 1..40):
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'supervisor'] else NOT_AUTHORIZED
  return insert loads { code, sterilizer, recalled: false, createdBy: viewer, createdAt: now }

mutation startCleaning(tray: trays):
  r = roles[viewer] ! else NOT_TECHNICIAN
  require r.role = 'technician' else NOT_TECHNICIAN
  t = trays[tray] ! else NOT_FOUND
  require t.status = 'dirty' else BAD_STATUS
  update trays[tray] { status: 'cleaning', updatedAt: now }
  return null

mutation markSterile(tray: trays, load: loads, indicator: image <=5000000):
  r = roles[viewer] ! else NOT_TECHNICIAN
  require r.role = 'technician' else NOT_TECHNICIAN
  t = trays[tray] ! else NOT_FOUND
  l = loads[load] ! else NOT_FOUND
  require not l.recalled else LOAD_RECALLED
  require t.status = 'cleaning' else BAD_STATUS
  update trays[tray] { status: 'sterile', load, indicator, sterilizedAt: now, expiresAt: now + 30d, updatedAt: now }
  return null

mutation moveToStorage(tray: trays):
  r = roles[viewer] ! else NOT_TECHNICIAN
  require r.role = 'technician' else NOT_TECHNICIAN
  t = trays[tray] ! else NOT_FOUND
  require t.status = 'sterile' else BAD_STATUS
  require t.expiresAt != null else EXPIRED
  require t.expiresAt > now else EXPIRED
  update trays[tray] { status: 'stored', updatedAt: now }
  return null

-- Expired or recalled trays re-enter the cycle as dirty.
mutation reprocessTray(tray: trays):
  r = roles[viewer] ! else NOT_TECHNICIAN
  require r.role = 'technician' else NOT_TECHNICIAN
  t = trays[tray] ! else NOT_FOUND
  require t.status = 'recalled' or (t.expiresAt != null and t.expiresAt <= now) else NOT_DUE
  update trays[tray] { status: 'dirty', load: null, sterilizedAt: null, expiresAt: null, indicator: null, updatedAt: now }
  return null

-- Supervisor-only: a whole sterilizer load becomes unusable at once.
mutation recallLoad(load: loads):
  require exists roles[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  l = loads[load] ! else NOT_FOUND
  update loads[load] { recalled: true }
  for t in trays where .load = load by .id:
    update trays[t.id] { status: 'recalled', updatedAt: now }
  return null

mutation scheduleCase(title: text 1..120, trayType: text 1..80, scheduledAt: time):
  require exists roles[viewer, role = 'or_staff'] or exists roles[viewer, role = 'supervisor'] else NOT_AUTHORIZED
  require scheduledAt > now else IN_THE_PAST
  return insert cases { title, trayType, scheduledAt, createdBy: viewer }
