use identity password

-- Operator-provisioned production roster. Signup alone grants no role.
table crew:
  principal: principal
  name: text 1..60
  role: enum('director', 'producer', 'department_head', 'post_supervisor', 'agent')
  department: text 1..40
  client: text 1..80
  unique principal
  immutable principal, name, role, department, client
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table days:
  title: text 1..100
  shootingDate: text 10..10
  released: bool default false
  locked: bool default false
  creator: principal
  immutable title, shootingDate, creator
  read <- exists crew[principal = viewer]
  insert <- exists crew[principal = viewer, role = 'post_supervisor'] and .creator = viewer and .released = false and .locked = false
  update <- exists crew[principal = viewer, role = 'post_supervisor']
  cap 1000
  online only

table clips:
  day: days
  title: text 1..120
  client: text 1..80
  media: video <=50000000
  uploader: principal
  at: time default now
  immutable day, title, client, media, uploader, at
  read <- exists crew[principal = viewer, role = 'director'] or exists crew[principal = viewer, role = 'producer'] or exists crew[principal = viewer, role = 'post_supervisor'] or (.day.released = true and (exists crew[principal = viewer, role = 'department_head'] or exists crew[principal = viewer, role = 'agent', client = .client]))
  insert <- exists crew[principal = viewer, role = 'post_supervisor'] and .uploader = viewer and .day.locked = false
  delete <- exists crew[principal = viewer, role = 'producer']
  cap 200 by day
  online only

table notes:
  clip: clips on delete cascade
  author: principal
  authorName: text 1..60
  body: text 1..2000
  timeMs: int 0..3600000
  at: time default now
  immutable clip, author, authorName, body, timeMs, at
  read through .clip
  insert <- .author = viewer and .clip.day.locked = false and (exists crew[principal = viewer, role = 'director'] or exists crew[principal = viewer, role = 'producer'] or (exists crew[principal = viewer, role = 'department_head'] and .clip.day.released = true))
  cap 400 by clip
  online only

mutation provisionCrew(principal: principal, name: text 1..60, role: enum('director', 'producer', 'department_head', 'post_supervisor', 'agent'), department: text 1..40, client: text 1..80):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert crew { principal, name, role, department, client }

query me():
  return crew[principal = viewer]
query crewMember(principal: principal):
  require principal = viewer or viewer = 'service:ops' else PRIVATE_ROSTER
  return crew[principal = principal]
query listDays():
  return days last 1000 by .id
query listClips(day: days):
  return clips where .day = day last 200 by .at
query getClip(clip: clips):
  return clips[clip]
query listNotes(clip: clips):
  require exists clips[clip] else CLIP_NOT_FOUND
  return notes where .clip = clip first 400 by .timeMs

mutation createDay(title: text 1..100, shootingDate: text 10..10):
  require exists crew[principal = viewer, role = 'post_supervisor'] else SUPERVISOR_ONLY
  return insert days { title, shootingDate, creator: viewer }
mutation releaseDay(day: days):
  require exists crew[principal = viewer, role = 'post_supervisor'] else SUPERVISOR_ONLY
  d = days[day] ! else DAY_NOT_FOUND
  require not d.locked else DAY_LOCKED
  require not d.released else ALREADY_RELEASED
  update days[day] { released: true }
mutation lockDay(day: days):
  require exists crew[principal = viewer, role = 'post_supervisor'] else SUPERVISOR_ONLY
  d = days[day] ! else DAY_NOT_FOUND
  require d.released else NOT_RELEASED
  require not d.locked else DAY_LOCKED
  update days[day] { locked: true }
mutation uploadClip(day: days, title: text 1..120, client: text 1..80, media: video <=50000000):
  require exists crew[principal = viewer, role = 'post_supervisor'] else SUPERVISOR_ONLY
  d = days[day] ! else DAY_NOT_FOUND
  require not d.locked else DAY_LOCKED
  return insert clips { day, title, client, media, uploader: viewer }
mutation addNote(clip: clips, body: text 1..2000, timeMs: int 0..3600000):
  person = crew[principal = viewer] ! else CREW_ONLY
  require person.role = 'director' or person.role = 'producer' or person.role = 'department_head' else REVIEWER_ONLY
  c = clips[clip] ! else CLIP_NOT_FOUND
  d = days[c.day] ! else DAY_NOT_FOUND
  require not d.locked else DAY_LOCKED
  duration = c.media.duration
  require duration != null else DURATION_UNKNOWN
  require timeMs <= duration else TIMECODE_OUT_OF_RANGE
  return insert notes { clip, body, timeMs, author: viewer, authorName: person.name }
mutation deleteClip(clip: clips):
  require exists crew[principal = viewer, role = 'producer'] else PRODUCER_ONLY
  delete clips[clip]
