-- Cycle Count Tasks.
-- Daily bin count tasks. Counters count blind (no system quantity in their
-- reads); a count differing by more than 5% automatically creates a recount
-- task for a different counter. Leads watch live progress; only the inventory
-- controller generates tasks and approves adjustments (photo required when the
-- adjustment value exceeds $100).
use identity password

table roles:
  principal: principal
  role: enum('counter', 'lead', 'controller')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'controller'] or exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
  insert <- exists roles[viewer, role = 'controller'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'controller'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'controller'] or viewer = 'service:ops'
  online only

table tasks:
  assignee: principal
  bin: text 1..40
  dayNumber: int
  systemQty: int 0..1000000
  unitValue: int 0..100000000
  countedQty: int 0..1000000 ?
  status: enum('open', 'counted', 'adjusted') default 'open'
  needsRecount: bool default false
  isRecount: bool default false
  recountOf: tasks ?
  recountAssignee: principal ?
  adjustmentQty: int 0..1000000 ?
  adjustedAt: time ?
  adjustedBy: principal ?
  photo: image <=10000000 ?
  immutable assignee, bin, dayNumber, systemQty, unitValue, isRecount, recountOf, recountAssignee
  cap 500 by assignee
  read <- .assignee = viewer or exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller']
  insert <- exists roles[viewer, role = 'controller'] or exists tasks[.recountOf, assignee = viewer]
  update <- .assignee = viewer or exists roles[viewer, role = 'controller']
  online only

view openCount: count tasks where .status = 'open'
  read <- exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller']
  online only
view countedCount: count tasks where .status = 'counted'
  read <- exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller']
  online only
view adjustedCount: count tasks where .status = 'adjusted'
  read <- exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller']
  online only
view totalCount: count tasks
  read <- exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller']
  online only

query whoAmI():
  return viewer

query myRole():
  return roles[principal = viewer]

-- A counter's own tasks, blinded: no system quantity, unit value, recount
-- flag or backup-counter identity.
query myTasks(c: cursor ?):
  return tasks where .assignee = viewer first 100 by .id after c { id, bin, dayNumber, status, countedQty, assignee, isRecount, recountOf, adjustmentQty, adjustedAt, adjustedBy, photo }

query allTasks(c: cursor ?):
  require exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller'] else NOT_PRIVILEGED
  return tasks first 100 by .id after c

query progress():
  require exists roles[viewer, role = 'lead'] or exists roles[viewer, role = 'controller'] else NOT_PRIVILEGED
  return { open: openCount, counted: countedCount, adjusted: adjustedCount, total: totalCount }

mutation grantRole(who: principal, role: enum('counter', 'lead', 'controller')):
  require exists roles[viewer, role = 'controller'] or viewer = 'service:ops' else NOT_CONTROLLER
  return upsert roles[who] { role }

mutation generateTask(bin: text 1..40, systemQty: int 0..1000000, unitValue: int 0..100000000, assignee: principal, recountAssignee: principal):
  require exists roles[viewer, role = 'controller'] else NOT_CONTROLLER
  require assignee != recountAssignee else SAME_COUNTER
  require exists roles[assignee, role = 'counter'] else NOT_A_COUNTER
  require exists roles[recountAssignee, role = 'counter'] else NOT_A_COUNTER
  return insert tasks { bin, systemQty, unitValue, assignee, recountAssignee, dayNumber: day(now) }

mutation submitCount(task: tasks, countedQty: int 0..1000000):
  t = tasks[task] ! else NOT_FOUND
  require t.assignee = viewer else NOT_YOURS
  require t.status = 'open' else ALREADY_COUNTED
  require t.dayNumber = day(now) else STALE_TASK
  diff = countedQty - t.systemQty
  abs = 0 - diff if diff < 0 else diff
  needs = abs * 20 > t.systemQty
  update tasks[task] { countedQty, status: 'counted', needsRecount: needs }
  if needs and not t.isRecount:
    require t.recountAssignee != null else NO_RECOUNTER
    insert tasks { bin: t.bin, systemQty: t.systemQty, unitValue: t.unitValue, dayNumber: t.dayNumber, assignee: t.recountAssignee, status: 'open', isRecount: true, recountOf: task }
  return null

mutation approveAdjustment(task: tasks, adjustmentQty: int 0..1000000, photo: image <=10000000 ?):
  t = tasks[task] ! else NOT_FOUND
  require exists roles[viewer, role = 'controller'] else NOT_CONTROLLER
  require not t.isRecount else NOT_ORIGINAL
  require t.status = 'counted' else NOT_COUNTED
  require t.countedQty != null else NOT_COUNTED
  gap = adjustmentQty - t.systemQty
  absGap = 0 - gap if gap < 0 else gap
  value = absGap * t.unitValue
  require photo != null or value <= 10000 else PHOTO_REQUIRED
  update tasks[task] { adjustmentQty, photo, status: 'adjusted', adjustedAt: now, adjustedBy: viewer }
  return null
