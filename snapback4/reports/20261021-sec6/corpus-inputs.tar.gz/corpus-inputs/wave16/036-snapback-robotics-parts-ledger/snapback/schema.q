-- Robotics Parts Ledger: students request parts, mentors approve under $100,
-- the head coach approves $100+, treasurer/coach watch the live budget.
use identity password

-- One roster row per team member. Students/mentors self-join; head coach and
-- treasurer seats need the team code (handed out offline, like a join code).
table roster:
  principal: principal
  role: enum('student', 'mentor', 'headcoach', 'treasurer')
  subteam: text 1..20
  unique principal
  immutable principal
  cap 500
  read <- .principal = viewer or exists roster[viewer, role = 'headcoach']
  insert <- .principal = viewer or exists roster[viewer, role = 'headcoach']
  update <- .principal = viewer or exists roster[viewer, role = 'headcoach']
  delete <- deny
  online only

-- Shared parts inventory: every team member reads, mentors/coach write.
table parts:
  name: text 1..80
  qty: int 0..1000000
  note: text <=280 ?
  adder: principal
  at: time default now
  immutable adder, at
  cap 1000
  read <- exists roster[viewer]
  insert <- exists roster[viewer, role = 'mentor'] or exists roster[viewer, role = 'headcoach']
  update <- exists roster[viewer, role = 'mentor'] or exists roster[viewer, role = 'headcoach']
  delete <- deny
  online only

-- Purchase requests. Amount is in cents; 10000 = $100.
table requests:
  student: principal
  subteam: text 1..20
  title: text 1..120
  link: text <=2048 format url
  photo: image <=5000000 ?
  amount: int 1..10000000
  status: enum('pending', 'approved', 'denied', 'lapsed') default 'pending'
  createdAt: time default now
  decidedBy: principal ?
  decidedAt: time ?
  immutable student, subteam, title, link, photo, amount, createdAt
  cap 5000
  read <- .student = viewer or exists roster[viewer, role = 'headcoach'] or exists roster[viewer, role = 'mentor', subteam = .subteam] or (.status = 'approved' and exists roster[viewer, role = 'treasurer'])
  insert <- .student = viewer
  update <- exists roster[viewer, role = 'mentor'] or exists roster[viewer, role = 'headcoach']
  delete <- deny
  online only

-- Single-row funds record (name = 'main'); balance is computed live.
table funds:
  name: text 1..20
  total: int 0..100000000000
  unique name
  read <- exists roster[viewer, role = 'headcoach'] or exists roster[viewer, role = 'treasurer']
  insert <- exists roster[viewer, role = 'headcoach'] or exists roster[viewer, role = 'treasurer']
  update <- exists roster[viewer, role = 'headcoach'] or exists roster[viewer, role = 'treasurer']
  delete <- deny
  online only

-- Unapproved requests lapse 5 days after submission.
job lapseOverdue(periodStart: time, periodEnd: time):
  for r in requests by .id:
    if r.status = 'pending' and r.createdAt + 5d <= now:
      update requests[r.id] { status: 'lapsed' }
schedule lapseDaily every 1d at 00:00: lapseOverdue

query myRole():
  return roster[principal = viewer]

query inventory(c: cursor ?):
  require exists roster[principal = viewer] else NOT_MEMBER
  return parts last 50 by .id after c

query myRequests(c: cursor ?):
  return requests where .student = viewer last 50 by .id after c

query teamRequests(c: cursor ?):
  me = roster[principal = viewer] ! else NOT_MEMBER
  if me.role = 'headcoach':
    return requests last 50 by .id after c
  if me.role = 'treasurer':
    return requests where .status = 'approved' last 50 by .id after c
  if me.role = 'mentor':
    return requests where .subteam = me.subteam last 50 by .id after c
  return requests where .student = viewer last 50 by .id after c

query budgetBalance():
  require exists roster[principal = viewer, role = 'headcoach'] or exists roster[principal = viewer, role = 'treasurer'] else NOT_PRIVILEGED
  f = funds[name = 'main']
  total = f.total if f != null else 0
  spent = sum(requests where .status = 'approved', .amount)
  return { total: total, spent: spent, balance: total - spent }

mutation joinAs(role: text <=20, subteam: text 1..20, code: text <=64 ?):
  require role = 'student' or role = 'mentor' or role = 'headcoach' or role = 'treasurer' else BAD_ROLE
  require not exists roster[principal = viewer] else ALREADY_JOINED
  if role = 'student':
    return insert roster { principal: viewer, role: 'student', subteam }
  else:
    if role = 'mentor':
      return insert roster { principal: viewer, role: 'mentor', subteam }
    else:
      if role = 'headcoach':
        require code = 'go-rovers-2026' else BAD_CODE
        return insert roster { principal: viewer, role: 'headcoach', subteam }
      else:
        require role = 'treasurer' else BAD_ROLE
        require code = 'go-rovers-2026' else BAD_CODE
        return insert roster { principal: viewer, role: 'treasurer', subteam }

mutation promote(who: principal, role: text <=20, subteam: text 1..20):
  me = roster[principal = viewer] ! else NO_ROLE
  require me.role = 'headcoach' else NOT_COACH
  require role = 'student' or role = 'mentor' or role = 'headcoach' or role = 'treasurer' else BAD_ROLE
  target = roster[principal = who] ! else NOT_FOUND
  if role = 'student':
    update roster[target.id] { role: 'student', subteam }
  else:
    if role = 'mentor':
      update roster[target.id] { role: 'mentor', subteam }
    else:
      if role = 'headcoach':
        update roster[target.id] { role: 'headcoach', subteam }
      else:
        require role = 'treasurer' else BAD_ROLE
        update roster[target.id] { role: 'treasurer', subteam }
  return null

mutation submitRequest(title: text 1..120, link: text <=2048 format url, photo: image <=5000000 ?, amount: int 1..10000000):
  me = roster[principal = viewer] ! else NO_ROLE
  require me.role = 'student' else ONLY_STUDENTS
  return insert requests { student: viewer, subteam: me.subteam, title, link, photo, amount }

mutation approveRequest(id: requests):
  r = requests[id] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_DECIDED
  require r.createdAt + 5d > now else REQUEST_LAPSED
  me = roster[principal = viewer] ! else NO_ROLE
  if r.amount < 10000:
    require me.role = 'headcoach' or (me.role = 'mentor' and me.subteam = r.subteam) else NOT_AUTHORIZED
  else:
    require me.role = 'headcoach' else NEEDS_HEAD_COACH
  update requests[id] { status: 'approved', decidedBy: viewer, decidedAt: now }
  return null

mutation denyRequest(id: requests):
  r = requests[id] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_DECIDED
  require r.createdAt + 5d > now else REQUEST_LAPSED
  me = roster[principal = viewer] ! else NO_ROLE
  if r.amount < 10000:
    require me.role = 'headcoach' or (me.role = 'mentor' and me.subteam = r.subteam) else NOT_AUTHORIZED
  else:
    require me.role = 'headcoach' else NEEDS_HEAD_COACH
  update requests[id] { status: 'denied', decidedBy: viewer, decidedAt: now }
  return null

mutation addPart(name: text 1..80, qty: int 0..1000000, note: text <=280 ?):
  me = roster[principal = viewer] ! else NO_ROLE
  require me.role = 'mentor' or me.role = 'headcoach' else NOT_PRIVILEGED
  return insert parts { name, qty, note, adder: viewer }

mutation setStock(part: parts, qty: int 0..1000000):
  me = roster[principal = viewer] ! else NO_ROLE
  require me.role = 'mentor' or me.role = 'headcoach' else NOT_PRIVILEGED
  p = parts[part] ! else NOT_FOUND
  update parts[part] { qty }
  return null

mutation setFunds(total: int 0..100000000000):
  me = roster[principal = viewer] ! else NO_ROLE
  require me.role = 'headcoach' or me.role = 'treasurer' else NOT_PRIVILEGED
  upsert funds[name = 'main'] { name: 'main', total }
  return null
