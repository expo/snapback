use identity password

-- Operator enrollment is the only authority that may assign a role.
table roles:
  principal: principal
  role: enum('diver', 'crew', 'divemaster', 'captain', 'owner')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- viewer = 'service:ops'
  online only

fn isCrew():
  return exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
fn seesCards():
  return exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'owner']

table people:
  principal: principal
  name: text 1..60
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- .principal = viewer
  online only

table trips:
  title: text 1..80
  state: enum('open', 'ended') default 'open'
  startedAt: time default now
  endedAt: time ?
  endedBy: principal ?
  reason: text 5..300 ?
  immutable title, startedAt
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  online only

table pairs:
  trip: trips
  diverA: principal
  diverB: principal
  nameA: text 1..60
  nameB: text 1..60
  enteredAt: time
  plannedMinutes: int 1..180
  surfaceAt: time
  overdueAt: time
  exitedAt: time ?
  state: enum('water', 'overdue', 'out') default 'water'
  recordedBy: principal
  immutable trip, diverA, diverB, nameA, nameB, enteredAt, plannedMinutes, surfaceAt, overdueAt, recordedBy
  read <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  insert <- exists roles[viewer, role = 'divemaster']
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  online only

table logs:
  pair: pairs
  trip: trips
  diver: principal
  buddyName: text 1..60
  enteredAt: time
  plannedMinutes: int 1..180
  surfaceAt: time
  overdueAt: time
  exitedAt: time ?
  state: enum('water', 'overdue', 'out') default 'water'
  unique pair, diver
  immutable pair, trip, diver, buddyName, enteredAt, plannedMinutes, surfaceAt, overdueAt
  read <- .diver = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  insert <- exists roles[viewer, role = 'divemaster']
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  online only

-- A short-lived readable marker gives queries an exact nextExpiry deadline.
table waterWindows:
  pair: pairs
  diverA: principal
  diverB: principal
  until: time
  unique pair
  immutable pair, diverA, diverB, until
  read <- .diverA = viewer or .diverB = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'captain']
  insert <- exists roles[viewer, role = 'divemaster']
  expire at .until
  online only

table cards:
  pair: pairs
  diver: principal
  diverName: text 1..60
  photo: image <=5000000
  recordedAt: time default now
  recordedBy: principal
  unique pair, diver
  immutable pair, diver, diverName, photo, recordedAt, recordedBy
  read <- exists roles[viewer, role = 'divemaster'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'divemaster']
  online only

mutation enroll(principal: principal, role: enum('diver', 'crew', 'divemaster', 'captain', 'owner'), name: text 1..60):
  require viewer = 'service:ops' else OPERATOR_ONLY
  upsert roles[principal] { principal, role }
  upsert people[principal] { principal, name }

query me():
  return { person: people[viewer], role: roles[viewer] }
query directory(c: cursor ?):
  require isCrew() else CREW_ONLY
  return people first 100 by .id after c
query listTrips(c: cursor ?):
  return trips last 100 by .startedAt after c
query roster(trip: trips, c: cursor ?):
  require isCrew() else CREW_ONLY
  return pairs where .trip = trip last 100 by .enteredAt after c { *, state: 'overdue' if .state != 'out' and not exists waterWindows[pair = .id] else .state }
query myLogs(c: cursor ?):
  return logs where .diver = viewer last 100 by .enteredAt after c { *, state: 'overdue' if .state != 'out' and not exists waterWindows[pair = .pair] else .state }
query logById(log: logs):
  return logs[log] { *, state: 'overdue' if .state != 'out' and not exists waterWindows[pair = .pair] else .state }
query certificationCards(c: cursor ?):
  require seesCards() else CARDS_PRIVATE
  return cards last 100 by .recordedAt after c
query cardById(card: cards):
  require seesCards() else CARDS_PRIVATE
  return cards[card]

mutation rename(name: text 1..60):
  require len(trim(name)) > 0 else NAME_REQUIRED
  update people[viewer] { name: trim(name) }
mutation createTrip(title: text 1..80):
  require isCrew() else CREW_ONLY
  require len(trim(title)) > 0 else TITLE_REQUIRED
  require not exists trips where .state = 'open' else TRIP_ALREADY_OPEN
  return insert trips { title: trim(title) }
mutation enterPair(trip: trips, diverA: principal, diverB: principal, plannedMinutes: int 1..180):
  require exists roles[viewer, role = 'divemaster'] else DIVEMASTER_ONLY
  t = trips[trip] ! else NOT_FOUND
  require t.state = 'open' else TRIP_ENDED
  require diverA != diverB else TWO_DIVERS_REQUIRED
  a = people[diverA] ! else DIVER_NOT_FOUND
  b = people[diverB] ! else DIVER_NOT_FOUND
  require not exists pairs where .state != 'out' and (.diverA = diverA or .diverB = diverA or .diverA = diverB or .diverB = diverB) else ALREADY_IN_WATER
  p = insert pairs { trip, diverA, diverB, nameA: a.name, nameB: b.name, enteredAt: now, plannedMinutes, surfaceAt: now + plannedMinutes * 1m, overdueAt: now + plannedMinutes * 1m + 10m, recordedBy: viewer }
  insert waterWindows { pair: p.id, diverA, diverB, until: p.overdueAt }
  insert logs { pair: p.id, trip, diver: diverA, buddyName: b.name, enteredAt: now, plannedMinutes, surfaceAt: p.surfaceAt, overdueAt: p.overdueAt }
  insert logs { pair: p.id, trip, diver: diverB, buddyName: a.name, enteredAt: now, plannedMinutes, surfaceAt: p.surfaceAt, overdueAt: p.overdueAt }
  return p
mutation exitPair(pair: pairs):
  require isCrew() else CREW_ONLY
  p = pairs[pair] ! else NOT_FOUND
  require p.state != 'out' else ALREADY_OUT
  -- A captain override closes the trip but returning divers must still be recovered.
  update pairs[pair] { state: 'out', exitedAt: now }
  update logs[pair, p.diverA] { state: 'out', exitedAt: now }
  update logs[pair, p.diverB] { state: 'out', exitedAt: now }
mutation recordCard(pair: pairs, diver: principal, photo: image <=5000000):
  require exists roles[viewer, role = 'divemaster'] else DIVEMASTER_ONLY
  p = pairs[pair] ! else NOT_FOUND
  t = trips[p.trip] ! else NOT_FOUND
  require t.state = 'open' else TRIP_ENDED
  require p.diverA = diver or p.diverB = diver else NOT_IN_PAIR
  return insert cards { pair, diver, diverName: p.nameA if p.diverA = diver else p.nameB, photo, recordedBy: viewer }
mutation endTrip(trip: trips, reason: text 5..300 ?):
  require isCrew() else CREW_ONLY
  t = trips[trip] ! else NOT_FOUND
  require t.state = 'open' else TRIP_ENDED
  if reason != null:
    require len(trim(reason)) >= 5 else REASON_REQUIRED
  if exists pairs where .state != 'out':
    require exists roles[viewer, role = 'captain'] else CAPTAIN_REQUIRED
    require reason != null else REASON_REQUIRED
  update trips[trip] { state: 'ended', endedAt: now, endedBy: viewer, reason: trim(reason) if reason != null else null }

-- Deadline reads re-evaluate on every connected client at the exact instant;
-- the sweep durably records the same state for later readers.
job markOverdue():
  for p in pairs:
    if p.state = 'water' and now >= p.overdueAt:
      update pairs[p.id] { state: 'overdue' }
      update logs[p.id, p.diverA] { state: 'overdue' }
      update logs[p.id, p.diverB] { state: 'overdue' }
schedule overdueSweep every 1m: markOverdue
