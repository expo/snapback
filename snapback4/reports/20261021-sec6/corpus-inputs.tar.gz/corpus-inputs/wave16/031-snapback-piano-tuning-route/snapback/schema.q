use identity password

-- Account roles are provisioned by the operator, never selected at sign-in.
table accounts:
  principal: principal
  name: text 2..80
  role: enum('customer', 'tuner', 'dispatcher', 'owner')
  unique principal
  immutable principal, role
  read <- .principal = viewer or exists accounts[principal = viewer, role = 'dispatcher'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or .principal = viewer and .role = 'customer'
  online only

table bookings:
  customer: principal
  customerName: text 2..80
  address: text 8..240
  piano: text 2..120
  startsAt: time
  endsAt: time
  tuner: principal ?
  state: enum('booked', 'cancelled', 'completed') default 'booked'
  revision: int default 0
  createdAt: time default now
  immutable customer, customerName, createdAt
  read <- .customer = viewer or exists accounts[principal = viewer, role = 'dispatcher']
  insert <- .customer = viewer and exists accounts[principal = viewer, role = 'customer']
  update <- .customer = viewer or exists accounts[principal = viewer, role = 'dispatcher'] or exists accounts[principal = viewer, role = 'tuner']
  cap 500 by customer
  online only

-- Publications never change. A changed source invalidates any old publication.
table routeStops:
  booking: bookings on delete keep
  customer: principal
  customerName: text 2..80
  address: text 8..240
  piano: text 2..120
  tuner: principal
  startsAt: time
  endsAt: time
  revision: int
  opensAt: time
  expiresAt: time
  by byOpening: opensAt
  by byExpiry: expiresAt
  immutable booking, customer, customerName, address, piano, tuner, startsAt, endsAt, revision, opensAt, expiresAt
  not before .opensAt
  expire at .expiresAt
  read <- .tuner = viewer and exists accounts[principal = viewer, role = 'tuner'] and exists bookings[.booking, tuner = .tuner, startsAt = .startsAt, endsAt = .endsAt, address = .address, piano = .piano, revision = .revision] and not exists bookings[.booking, state = 'cancelled']
  insert <- exists accounts[principal = viewer, role = 'dispatcher'] or exists bookings[.booking, customer = viewer]
  online only

table visits:
  booking: bookings on delete keep
  stop: routeStops on delete keep
  customer: principal
  tuner: principal
  piano: text 2..120
  pitchBefore: int 350..480
  pitchAfter: int 400..480
  notes: text 5..2000
  photo: image <=5000000
  completedAt: time default now
  unique booking
  immutable booking, stop, customer, tuner, piano, pitchBefore, pitchAfter, notes, photo, completedAt
  read <- .customer = viewer or exists accounts[principal = viewer, role = 'dispatcher'] or exists routeStops[.stop, tuner = viewer]
  insert <- .tuner = viewer and exists routeStops[.stop, tuner = viewer]
  online only

table charges:
  visit: visits on delete keep
  tuner: principal
  tunerName: text 2..80 default 'Tuner'
  cents: int 0..1000000
  completedAt: time
  unique visit
  immutable visit, tuner, tunerName, cents, completedAt
  read <- exists accounts[principal = viewer, role = 'owner']
  insert <- .tuner = viewer and exists visits[.visit, tuner = viewer]
  online only

fn publishRoute(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  if b.tuner != null and b.state = 'booked':
    insert routeStops { booking, customer: b.customer, customerName: b.customerName, address: b.address, piano: b.piano, tuner: b.tuner, startsAt: b.startsAt, endsAt: b.endsAt, revision: b.revision, opensAt: day(b.startsAt) * 1d, expiresAt: (day(b.startsAt) + 1) * 1d }

query me():
  return accounts[principal = viewer]
query serverTime():
  return { now: now, day: day(now) }
query myBookings(c: cursor ?):
  require exists accounts[principal = viewer, role = 'customer'] else CUSTOMER_ONLY
  return bookings where .customer = viewer last 50 by .startsAt after c
query booking(booking: bookings):
  return bookings[booking]
query dispatchBookings(c: cursor ?):
  require exists accounts[principal = viewer, role = 'dispatcher'] else DISPATCHER_ONLY
  return bookings first 100 by .startsAt after c
query tuners(c: cursor ?):
  require exists accounts[principal = viewer, role = 'dispatcher'] else DISPATCHER_ONLY
  return accounts where .role = 'tuner' first 50 by .id after c { principal, name }
query myRoute(c: cursor ?):
  require exists accounts[principal = viewer, role = 'tuner'] else TUNER_ONLY
  return routeStops where .tuner = viewer first 100 by .startsAt after c { *, report: visits[booking = .booking] }
query routeStop(stop: routeStops):
  return routeStops[stop]
query myHistory(c: cursor ?):
  require exists accounts[principal = viewer, role = 'customer'] else CUSTOMER_ONLY
  return visits where .customer = viewer last 50 by .completedAt after c
query visit(visit: visits):
  return visits[visit]
query revenue(c: cursor ?):
  require exists accounts[principal = viewer, role = 'owner'] else OWNER_ONLY
  return charges last 100 by .completedAt after c

mutation enrollCustomer(name: text 2..80):
  require not exists accounts[principal = viewer] else ALREADY_ENROLLED
  return insert accounts { principal: viewer, name, role: 'customer' }
mutation provisionAccount(principal: principal, name: text 2..80, role: enum('customer', 'tuner', 'dispatcher', 'owner')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert accounts { principal, name, role }
mutation book(address: text 8..240, piano: text 2..120, startsAt: time, endsAt: time):
  a = accounts[principal = viewer] ! else ENROLL_FIRST
  require a.role = 'customer' else CUSTOMER_ONLY
  require startsAt > now + 24h else TOO_SOON 'Choose a window more than 24 hours ahead.'
  require startsAt <= now + 180d else TOO_FAR
  require endsAt > startsAt and endsAt <= startsAt + 4h and day(endsAt - 1) = day(startsAt) else BAD_WINDOW 'A window must be within one UTC day and at most four hours.'
  return insert bookings { customer: viewer, customerName: a.name, address, piano, startsAt, endsAt, tuner: null }
mutation changeBooking(booking: bookings, address: text 8..240, piano: text 2..120, startsAt: time, endsAt: time):
  b = bookings[booking] ! else NOT_FOUND
  dispatcher = exists accounts[principal = viewer, role = 'dispatcher']
  require dispatcher or b.customer = viewer else FORBIDDEN
  require b.state = 'booked' else FINALIZED
  require dispatcher or now < b.startsAt - 24h else BOOKING_LOCKED 'Within 24 hours, contact the dispatcher.'
  require startsAt > now and startsAt <= now + 180d else BAD_DATE
  require dispatcher or startsAt > now + 24h else TOO_SOON
  require endsAt > startsAt and endsAt <= startsAt + 4h and day(endsAt - 1) = day(startsAt) else BAD_WINDOW
  update bookings[booking] { address, piano, startsAt, endsAt, revision: b.revision + 1 }
  publishRoute(booking)
  return bookings[booking]
mutation cancelBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  dispatcher = exists accounts[principal = viewer, role = 'dispatcher']
  require dispatcher or b.customer = viewer else FORBIDDEN
  require b.state = 'booked' else FINALIZED
  require dispatcher or now < b.startsAt - 24h else BOOKING_LOCKED
  update bookings[booking] { state: 'cancelled' }
  return bookings[booking]
mutation assignTuner(booking: bookings, tuner: principal):
  require exists accounts[principal = viewer, role = 'dispatcher'] else DISPATCHER_ONLY
  require exists accounts[principal = tuner, role = 'tuner'] else NOT_A_TUNER
  b = bookings[booking] ! else NOT_FOUND
  require b.state = 'booked' else FINALIZED
  require b.endsAt > now else WINDOW_PASSED
  update bookings[booking] { tuner, revision: b.revision + 1 }
  publishRoute(booking)
  return bookings[booking]
mutation recordVisit(stop: routeStops, cents: int 0..1000000, pitchBefore: int 350..480, pitchAfter: int 400..480, notes: text 5..2000, photo: image <=5000000):
  a = accounts[principal = viewer] ! else TUNER_ONLY
  require a.role = 'tuner' else TUNER_ONLY
  s = routeStops[stop] ! else NOT_FOUND
  require s.tuner = viewer else FORBIDDEN
  require day(now) = day(s.startsAt) else VISIT_DAY_ONLY
  v = insert visits { booking: s.booking, stop, customer: s.customer, tuner: viewer, piano: s.piano, pitchBefore, pitchAfter, notes, photo }
  insert charges { visit: v.id, tuner: viewer, tunerName: a.name, cents, completedAt: now }
  -- The tuner cannot read the private booking; use a blind update by its known key.
  update bookings[s.booking] { state: 'completed' }
  return v
