use identity password

-- Who is who: one row per person, managed by the hall director.
-- floor/room locate residents (room) and RAs (floor); the director uses floor 0.
table roster:
  principal: principal
  role: enum('resident', 'ra', 'director')
  floor: int 0..10 ?
  room: text 1..10 ?
  unique principal
  read <- .principal = viewer or exists roster[principal = viewer, role = 'director']
  insert <- exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops'
  update <- exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops'
  delete <- exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops'
  online only

-- The room directory: which floor each room is on.
table rooms:
  room: text 1..10
  floor: int 1..10
  unique room
  public 'The room directory is public so residents can pick a room to report.'
  insert <- exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops'
  update <- exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops'
  delete <- exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops'
  online only

-- Noise reports. The reporter stays anonymous: reported residents never read
-- this table, they only see the warnings table (which carries no reporter).
table reports:
  reporter: principal
  room: text 1..10
  floor: int 1..10
  detail: text 1..500
  at: time default now
  status: enum('open', 'escalated', 'warned') default 'open'
  warning: text 1..500 ?
  immutable reporter, room, floor, at
  read <- .reporter = viewer or exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'ra', floor = .floor]
  insert <- .reporter = viewer
  update <- exists roster[principal = viewer, role = 'director']
  online only

-- Formal warnings from the hall director. Readable by the director, the
-- floor RA, and the residents of the warned room (no reporter attached).
table warnings:
  room: text 1..10
  floor: int 1..10
  text: text 1..500
  at: time default now
  director: principal
  immutable room, floor, at, director
  read <- exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'ra', floor = .floor] or exists roster[principal = viewer, room = .room]
  insert <- exists roster[principal = viewer, role = 'director']
  online only

query myRole():
  return roster[principal = viewer]

query roomDirectory(c: cursor ?):
  return rooms first 100 by .room after c

query myReports(c: cursor ?):
  return reports where .reporter = viewer last 50 by .at after c

query floorReports(floor: int 1..10, c: cursor ?):
  require exists roster[principal = viewer, role = 'ra', floor = floor] or exists roster[principal = viewer, role = 'director'] else NOT_FLOOR_RA
  return reports where .floor = floor last 100 by .at after c

query escalatedReports(c: cursor ?):
  require exists roster[principal = viewer, role = 'director'] else NOT_DIRECTOR
  return reports where .status = 'escalated' last 100 by .at after c

query myWarnings(c: cursor ?):
  me = roster[principal = viewer] ! else NO_PROFILE
  require me.role = 'resident' else NOT_RESIDENT
  return warnings where .room = me.room and .floor = me.floor last 50 by .at after c

query floorWarnings(floor: int 1..10, c: cursor ?):
  require exists roster[principal = viewer, role = 'ra', floor = floor] or exists roster[principal = viewer, role = 'director'] else NOT_FLOOR_RA
  return warnings where .floor = floor last 100 by .at after c

mutation grantRole(who: principal, role: enum('resident', 'ra', 'director'), floor: int 0..10 ?, room: text 1..10 ?):
  require exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops' else NOT_DIRECTOR
  return upsert roster[who] { role, floor, room }

mutation addRoom(room: text 1..10, floor: int 1..10):
  require exists roster[principal = viewer, role = 'director'] or viewer = 'service:ops' else NOT_DIRECTOR
  return upsert rooms[room] { floor }

mutation fileReport(targetRoom: text 1..10, detail: text 1..500):
  require exists roster[principal = viewer, role = 'resident'] else NOT_RESIDENT
  r = rooms[room = targetRoom] ! else UNKNOWN_ROOM
  h = hour(now) % 24
  require h >= 22 or h < 8 else QUIET_HOURS 'Noise reports are accepted between 10 pm and 8 am UTC.'
  return insert reports { reporter: viewer, room: targetRoom, floor: r.floor, detail }

mutation issueWarning(report: reports, text: text 1..500):
  require exists roster[principal = viewer, role = 'director'] else NOT_DIRECTOR
  r = reports[report] ! else NOT_FOUND
  require r.status != 'warned' else ALREADY_WARNED
  update reports[report] { status: 'warned', warning: text }
  return insert warnings { room: r.room, floor: r.floor, text, director: viewer }

job escalateRooms(periodStart: time, periodEnd: time):
  for r in reports by .id:
    if r.status = 'open':
      n = count(reports where .room = r.room and .at >= periodEnd - 7d and .at < periodEnd)
      if n >= 3 and r.at >= periodEnd - 7d:
        update reports[r.id] { status: 'escalated' }

schedule floorSweep every 1h: escalateRooms
