use identity password

table roles:
  principal: principal
  role: enum('volunteer', 'coordinator')
  unique principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- viewer = 'service:ops'
  online only

table accounts:
  principal: principal
  name: text 2..80
  suspended: bool default false
  unique principal
  immutable principal, name
  read <- .principal = viewer or exists roles[viewer] or viewer = 'service:ops'
  insert <- .principal = viewer
  update <- exists roles[viewer]
  online only

table tools:
  name: text 2..80
  category: enum('hand', 'garden', 'power')
  depositCents: int 500..10000
  state: enum('available', 'loaned', 'damaged') default 'available'
  immutable name, category, depositCents
  public 'The catalog contains availability, never borrower identity.'
  insert <- exists roles[viewer, role = 'coordinator'] or viewer = 'service:ops'
  update <- exists roles[viewer]
  online only

table loans:
  tool: tools
  borrower: principal
  checkedOutBy: principal
  checkedInBy: principal ?
  dueAt: time
  outAt: time default now
  returnedAt: time ?
  outPhoto: image <=5000000
  inPhoto: image <=5000000 ?
  depositCents: int 500..10000
  depositState: enum('held', 'refunded', 'forfeited', 'charged') default 'held'
  refundCents: int 0..10000 default 0
  chargeCents: int 0..10000 default 0
  damageNote: text <=500 ?
  immutable tool, borrower, checkedOutBy, dueAt, outAt, outPhoto, depositCents
  read <- .borrower = viewer or exists roles[viewer]
  insert <- exists roles[viewer]
  update <- exists roles[viewer]
  online only

query me():
  return accounts[principal = viewer]
query myRole():
  return roles[principal = viewer]
query catalog(c: cursor ?):
  return tools first 100 by .id after c
query members(c: cursor ?):
  require exists roles[viewer] else STAFF_ONLY
  return accounts first 100 by .id after c
query accountFor(who: principal):
  require who = viewer or exists roles[viewer] else PRIVATE
  return accounts[principal = who]
query myLoans(c: cursor ?):
  return loans where .borrower = viewer last 100 by .id after c
query staffLoans(c: cursor ?):
  require exists roles[viewer] else STAFF_ONLY
  return loans last 100 by .id after c
query loanDetail(loan: loans):
  return loans[loan]

mutation register(name: text 2..80):
  require not exists accounts[principal = viewer] else ALREADY_REGISTERED
  return insert accounts { principal: viewer, name }
mutation provisionRole(who: principal, role: enum('volunteer', 'coordinator')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return upsert roles[principal = who] { principal: who, role }
mutation addTool(name: text 2..80, category: enum('hand', 'garden', 'power')):
  require exists roles[viewer, role = 'coordinator'] or viewer = 'service:ops' else COORDINATOR_ONLY
  return insert tools { name, category, depositCents: 500 if category = 'hand' else 2000 if category = 'garden' else 5000 }
mutation checkout(tool: tools, borrower: principal, days: int 1..7, paidCents: int 0..10000, photo: image <=5000000):
  require exists roles[viewer] else STAFF_ONLY
  a = accounts[principal = borrower] ! else MEMBER_NOT_FOUND
  require not a.suspended else SUSPENDED
  require not exists loans where .borrower = borrower and .returnedAt = null and .dueAt + 3d < now else OVERDUE_ACCOUNT
  t = tools[tool] ! else NOT_FOUND
  require t.state = 'available' else UNAVAILABLE
  require paidCents = t.depositCents else DEPOSIT_REQUIRED
  l = insert loans { tool, borrower, checkedOutBy: viewer, dueAt: now + days * 1d, outPhoto: photo, depositCents: t.depositCents }
  update tools[tool] { state: 'loaned' }
  return l
mutation checkin(loan: loans, photo: image <=5000000):
  require exists roles[viewer] else STAFF_ONLY
  l = loans[loan] ! else NOT_FOUND
  require l.returnedAt = null else ALREADY_RETURNED
  if l.dueAt + 3d < now and l.depositState = 'held':
    update loans[loan] { depositState: 'forfeited' }
    update accounts[principal = l.borrower] { suspended: true }
  else:
    if l.depositState = 'held':
      update loans[loan] { depositState: 'refunded', refundCents: l.depositCents }
  update loans[loan] { returnedAt: now, checkedInBy: viewer, inPhoto: photo }
  update tools[l.tool] { state: 'available' }
mutation markDamaged(loan: loans, photo: image <=5000000, note: text 5..500, chargeCents: int 0..10000):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  l = loans[loan] ! else NOT_FOUND
  require l.returnedAt = null else ALREADY_RETURNED
  require chargeCents <= l.depositCents else CHARGE_EXCEEDS_DEPOSIT
  if l.depositState = 'forfeited' or l.dueAt + 3d < now:
    require chargeCents = 0 else DEPOSIT_FORFEITED
    update loans[loan] { depositState: 'forfeited', damageNote: note }
    update accounts[principal = l.borrower] { suspended: true }
  else:
    update loans[loan] { depositState: 'charged', chargeCents, refundCents: l.depositCents - chargeCents, damageNote: note }
  update loans[loan] { returnedAt: now, checkedInBy: viewer, inPhoto: photo }
  update tools[l.tool] { state: 'damaged' }
mutation restore(who: principal):
  require exists roles[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  a = accounts[principal = who] ! else MEMBER_NOT_FOUND
  require a.suspended else NOT_SUSPENDED
  require not exists loans where .borrower = who and .returnedAt = null and .dueAt + 3d < now else OVERDUE_OUTSTANDING
  update accounts[principal = who] { suspended: false }

job forfeitOverdue():
  for l in loans:
    if l.returnedAt = null and l.depositState = 'held' and l.dueAt + 3d < now:
      update loans[l.id] { depositState: 'forfeited' }
      update accounts[principal = l.borrower] { suspended: true }
schedule overdueSweep every 1m: forfeitOverdue
