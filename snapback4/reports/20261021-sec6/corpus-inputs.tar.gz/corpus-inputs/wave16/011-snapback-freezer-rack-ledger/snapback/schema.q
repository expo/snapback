-- Freezer Rack Ledger.
-- Roles: researcher, manager (roster in `users`). Researchers belong to a
-- group; box positions are visible to every registered user, box contents
-- (description + label photo) only to the box's group and managers.
-- Only managers move boxes between groups or mark freezers failed.
-- A checkout older than 20 minutes shows up in `overdueAlerts` for the box
-- owner and managers. Boxes in failed freezers show up in `relocationList`
-- for everyone on call (every registered user).

use identity password

table users:
  principal: principal
  role: enum('researcher', 'manager')
  groupName: text 1..40 ?
  unique principal
  read <- .principal = viewer or exists users[principal = viewer, role = 'manager'] or viewer = 'service:ops'
  insert <- .principal = viewer or viewer = 'service:ops'
  update <- exists users[principal = viewer, role = 'manager'] or viewer = 'service:ops'
  delete <- deny
  immutable principal
  cap 1 by principal
  online only

table freezers:
  name: text 1..60
  failed: bool default false
  unique name
  read <- exists users[viewer]
  insert <- exists users[principal = viewer, role = 'manager']
  update <- exists users[principal = viewer, role = 'manager']
  delete <- deny
  online only

table boxes:
  freezer: freezers
  rack: text 1..40
  position: text 1..40
  groupName: text 1..40
  owner: principal
  checkedOutBy: principal ?
  checkedOutAt: time ?
  unique freezer, rack, position
  read <- exists users[viewer]
  insert <- exists users[viewer]
  update <- exists users[viewer]
  delete <- deny
  cap 2000
  online only

table contents:
  box: boxes
  groupName: text 1..40
  description: text 1..1000
  labelPhoto: image <=5000000 ?
  unique box
  read <- exists users[principal = viewer, role = 'manager'] or exists users[principal = viewer, groupName = .groupName]
  insert <- exists users[viewer] and exists boxes[.box, groupName = .groupName]
  update <- exists users[principal = viewer, role = 'manager'] or exists users[principal = viewer, groupName = .groupName]
  delete <- deny
  immutable box
  cap 2000
  online only

query whoAmI():
  return viewer

query me():
  return users[viewer]

query freezers(c: cursor ?):
  return freezers first 50 by .id after c

-- Positions of all boxes: no private fields live on `boxes`, so every
-- registered user may read every row here.
query boxPositions(c: cursor ?):
  return boxes first 100 by .id after c

query myGroupBoxes(c: cursor ?):
  me = users[viewer] ! else NOT_REGISTERED
  if me.role = 'manager':
    return boxes first 100 by .id after c
  return boxes where .groupName = me.groupName first 100 by .id after c

-- Contents of one box: hidden as missing outside the box's group.
query boxDetails(box: boxes):
  return contents[box]

query groupContents(c: cursor ?):
  me = users[viewer] ! else NOT_REGISTERED
  if me.role = 'manager':
    return contents first 100 by .id after c
  return contents where .groupName = me.groupName first 100 by .id after c

-- Checked out for more than 20 minutes: the owner and managers are alerted.
query overdueAlerts(c: cursor ?):
  if exists users[principal = viewer, role = 'manager']:
    return boxes where .checkedOutAt != null and .checkedOutAt < now - 20m first 100 by .checkedOutAt after c
  return boxes where .owner = viewer and .checkedOutAt != null and .checkedOutAt < now - 20m first 100 by .checkedOutAt after c

-- Emergency relocation: boxes sitting in a failed freezer, live for
-- everyone on call (every registered user).
query relocationList(c: cursor ?):
  return boxes where .freezer.failed = true first 100 by .id after c

mutation register(groupName: text 1..40):
  require not exists users[viewer] else ALREADY_REGISTERED 'This account already has a roster row.'
  return insert users { principal: viewer, role: 'researcher', groupName }

mutation grantManager(who: principal):
  require exists users[principal = viewer, role = 'manager'] or viewer = 'service:ops' else NOT_MANAGER 'Only the lab manager can grant the manager role.'
  u = users[who]
  if u != null:
    update users[who] { role: 'manager' }
  else:
    insert users { principal: who, role: 'manager' }
  return null

mutation addFreezer(name: text 1..60):
  require exists users[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the lab manager can add a freezer.'
  return insert freezers { name }

mutation addBox(freezer: freezers, rack: text 1..40, position: text 1..40, groupName: text 1..40, description: text 1..1000, photo: image <=5000000 ?):
  me = users[viewer] ! else NOT_REGISTERED
  if me.role != 'manager':
    require groupName = me.groupName else CROSS_GROUP 'Researchers create boxes for their own group only.'
  f = freezers[freezer] ! else NOT_FOUND
  require not f.failed else FREEZER_FAILED 'Cannot add a box to a failed freezer.'
  b = insert boxes { freezer, rack, position, groupName, owner: viewer }
  insert contents { box: b.id, groupName, description, labelPhoto: photo }
  return b.id

mutation moveBox(box: boxes, groupName: text 1..40):
  require exists users[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the lab manager can move a box between groups.'
  b = boxes[box] ! else NOT_FOUND
  update boxes[box] { groupName }
  c = contents[box]
  if c != null:
    update contents[c.id] { groupName }
  return null

mutation checkout(box: boxes, photo: image <=5000000 ?):
  me = users[viewer] ! else NOT_REGISTERED
  b = boxes[box] ! else NOT_FOUND
  require b.checkedOutAt = null else ALREADY_OUT 'This box is already checked out.'
  if photo != null:
    c = contents[box]
    require c != null else PHOTO_PRIVATE 'Only the owning group or the lab manager may attach a label photo.'
    update contents[c.id] { labelPhoto: photo }
  update boxes[box] { checkedOutBy: viewer, checkedOutAt: now }
  return null

mutation checkin(box: boxes, photo: image <=5000000 ?):
  me = users[viewer] ! else NOT_REGISTERED
  b = boxes[box] ! else NOT_FOUND
  require b.checkedOutAt != null else NOT_OUT 'This box is not checked out.'
  require b.checkedOutBy = viewer or b.owner = viewer or me.role = 'manager' else NOT_YOURS 'Only the researcher who checked it out, its owner, or the lab manager can check it in.'
  if photo != null:
    c = contents[box]
    require c != null else PHOTO_PRIVATE 'Only the owning group or the lab manager may attach a label photo.'
    update contents[c.id] { labelPhoto: photo }
  update boxes[box] { checkedOutBy: null, checkedOutAt: null }
  return null

mutation markFreezerFailed(freezer: freezers, failed: bool):
  require exists users[principal = viewer, role = 'manager'] else NOT_MANAGER 'Only the lab manager can mark a freezer failed.'
  f = freezers[freezer] ! else NOT_FOUND
  update freezers[freezer] { failed }
  return null
