use identity password

table staff:
  principal: principal
  name: text 2..80
  role: enum('clinic', 'courier', 'lab', 'supervisor')
  unique principal
  immutable principal, name, role
  read <- allow
  insert <- viewer = 'service:operator'
  online only

table bags:
  clinic: principal
  courier: principal
  label: text 1..60
  specimens: int 1..100
  routeAt: time
  createdAt: time default now
  status: enum('ready', 'in_transit', 'received', 'rejected') default 'ready'
  pickedAt: time ?
  pickupSignature: text 2..80 ?
  pickupBy: principal ?
  dueAt: time ?
  receivedAt: time ?
  receiptSignature: text 2..80 ?
  receivedBy: principal ?
  temperaturePhoto: image <=5000000 ?
  rejectedAt: time ?
  rejectedBy: principal ?
  rejectionReason: text 5..500 ?
  overdue: bool default false
  immutable clinic, courier, label, specimens, routeAt, createdAt
  read <- .clinic = viewer or exists courierGrants[.id, viewer] or exists staff[viewer, role = 'lab'] or exists staff[viewer, role = 'supervisor']
  insert <- .clinic = viewer and exists staff[viewer, role = 'clinic'] and .status = 'ready'
  update <- .courier = viewer or exists staff[viewer, role = 'lab'] or exists staff[viewer, role = 'supervisor']
  online only

table courierGrants:
  bag: bags
  courier: principal
  opensAt: time
  endsAt: time
  unique bag, courier
  immutable bag, courier, opensAt, endsAt
  read <- .courier = viewer
  insert <- created bags[.bag, clinic = viewer, courier = .courier]
  not before .opensAt
  expire at .endsAt
  online only

table alerts:
  bag: bags
  clinic: principal
  message: text 1..200
  at: time default now
  unique bag
  insert <- exists staff[viewer, role = 'lab'] or exists staff[viewer, role = 'supervisor']
  immutable bag, clinic, message, at
  read <- .clinic = viewer or exists staff[viewer, role = 'lab'] or exists staff[viewer, role = 'supervisor']
  online only

query me():
  return staff[principal = viewer]

query couriers():
  require exists staff[viewer] else NOT_STAFF
  return staff where .role = 'courier' first 100 by .id

query board(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF
  return bags last 50 by .createdAt after c

query bag(bag: bags):
  require exists staff[viewer] else NOT_STAFF
  return bags[bag]

query clinicAlerts(c: cursor ?):
  require exists staff[viewer] else NOT_STAFF
  return alerts last 50 by .at after c

mutation provision(principal: principal, name: text 2..80, role: enum('clinic', 'courier', 'lab', 'supervisor')):
  require viewer = 'service:operator' else FORBIDDEN
  return insert staff { principal, name, role }

mutation createBag(label: text 1..60, specimens: int 1..100, courier: principal, routeAt: time):
  require exists staff[viewer, role = 'clinic'] else CLINIC_ONLY
  require exists staff[principal = courier, role = 'courier'] else NOT_COURIER
  require routeAt = day(routeAt) * 1d else INVALID_ROUTE_DAY
  require day(routeAt) >= day(now) and day(routeAt) <= day(now) + 7 else INVALID_ROUTE_DAY
  b = insert bags { clinic: viewer, courier, label, specimens, routeAt }
  insert courierGrants { bag: b.id, courier, opensAt: routeAt, endsAt: routeAt + 1d }
  return b

mutation pickup(bag: bags, signature: text 2..80):
  require exists staff[viewer, role = 'courier'] else COURIER_ONLY
  b = bags[bag] ! else NOT_FOUND
  require b.courier = viewer else FORBIDDEN
  require day(b.routeAt) = day(now) else ROUTE_CLOSED
  require b.status = 'ready' else INVALID_STATE
  update bags[bag] { status: 'in_transit', pickedAt: now, pickupSignature: signature, pickupBy: viewer, dueAt: now + 4h }
  return bags[bag]

mutation receive(bag: bags, signature: text 2..80, photo: image <=5000000):
  require exists staff[viewer, role = 'lab'] or exists staff[viewer, role = 'supervisor'] else LAB_ONLY
  b = bags[bag] ! else NOT_FOUND
  require b.status = 'in_transit' else INVALID_STATE
  require b.dueAt != null else INVALID_STATE
  update bags[bag] { status: 'received', receivedAt: now, receiptSignature: signature, receivedBy: viewer, temperaturePhoto: photo, overdue: b.overdue or now > b.dueAt }
  if now > b.dueAt:
    insert alerts { bag, clinic: b.clinic, message: 'Bag exceeded the four-hour pickup-to-receipt deadline.' } if absent
  return bags[bag]

mutation reject(bag: bags, reason: text 5..500):
  require exists staff[viewer, role = 'supervisor'] else SUPERVISOR_ONLY
  b = bags[bag] ! else NOT_FOUND
  require b.status = 'received' else INVALID_STATE
  update bags[bag] { status: 'rejected', rejectedAt: now, rejectedBy: viewer, rejectionReason: reason }
  return bags[bag]

job flagOverdue():
  for b in bags:
    if b.dueAt != null and b.status = 'in_transit' and b.dueAt < now and not b.overdue:
      update bags[b.id] { overdue: true }
      insert alerts { bag: b.id, clinic: b.clinic, message: 'Bag exceeded the four-hour pickup-to-receipt deadline.' } if absent

schedule deadlineSweep every 1m: flagOverdue
