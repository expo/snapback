use identity password

table staff:
  principal: principal
  role: enum('technician', 'pharmacist', 'pharmacist_in_charge')
  name: text 1..80
  unique principal
  immutable principal, role, name
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table preparations:
  technician: principal
  compound: text 1..120
  ingredients: text 1..2000
  photo: image <=5000000
  preparedAt: time
  expiresAt: time
  status: enum('awaiting', 'verified', 'discarded')
  verifiedBy: principal ?
  resolvedAt: time ?
  immutable technician, compound, ingredients, photo, preparedAt, expiresAt
  read <- .technician = viewer or exists staff[principal = viewer, role = 'pharmacist'] or exists staff[principal = viewer, role = 'pharmacist_in_charge']
  insert <- .technician = viewer and exists staff[principal = viewer, role = 'technician']
  update (old, next) <- old.status = 'awaiting' and (exists staff[principal = viewer, role = 'pharmacist'] or exists staff[principal = viewer, role = 'pharmacist_in_charge'] or (old.technician = viewer and next.status = 'discarded'))
  online only

table patients:
  preparation: preparations
  name: text 1..120
  unique preparation
  immutable preparation, name
  read <- exists staff[principal = viewer, role = 'pharmacist'] or exists staff[principal = viewer, role = 'pharmacist_in_charge']
  insert <- exists staff[principal = viewer, role = 'pharmacist'] or exists staff[principal = viewer, role = 'pharmacist_in_charge']
  online only

table overrides:
  preparation: preparations
  actor: principal
  reason: text 10..500
  at: time
  originalDeadline: time
  unique preparation
  immutable preparation, actor, reason, at, originalDeadline
  read <- exists staff[principal = viewer, role = 'pharmacist'] or exists staff[principal = viewer, role = 'pharmacist_in_charge']
  insert <- .actor = viewer and exists staff[principal = viewer, role = 'pharmacist_in_charge']
  online only

mutation provisionStaff(principal: principal, role: enum('technician', 'pharmacist', 'pharmacist_in_charge'), name: text 1..80):
  require viewer = 'service:ops' else FORBIDDEN
  return insert staff { principal, role, name }

query me():
  return staff[principal = viewer]

query board(c: cursor ?):
  s = staff[principal = viewer] ! else NOT_STAFF
  if s.role = 'technician':
    return preparations where .technician = viewer last 50 by .preparedAt after c
  return preparations last 50 by .preparedAt after c

query preparation(preparation: preparations):
  return preparations[preparation]

query patient(preparation: preparations):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role != 'technician' else FORBIDDEN
  return patients[preparation = preparation]

query audit(c: cursor ?):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role != 'technician' else FORBIDDEN
  return overrides last 50 by .at after c

mutation prepare(compound: text 1..120, ingredients: text 1..2000, photo: image <=5000000):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'technician' else FORBIDDEN
  return insert preparations { technician: viewer, compound, ingredients, photo, preparedAt: now, expiresAt: now + 2h, status: 'awaiting', verifiedBy: null, resolvedAt: null }

mutation verify(preparation: preparations, patientName: text 1..120):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role != 'technician' else FORBIDDEN
  p = preparations[preparation] ! else NOT_FOUND
  require p.technician != viewer else DIFFERENT_PERSON
  require p.status = 'awaiting' else ALREADY_RESOLVED
  require now < p.expiresAt else EXPIRED 'Expired preparation must be discarded or overridden by the pharmacist in charge.'
  insert patients { preparation, name: patientName }
  update preparations[preparation] { status: 'verified', verifiedBy: viewer, resolvedAt: now }
  return preparations[preparation]

mutation overrideExpired(preparation: preparations, patientName: text 1..120, reason: text 10..500):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'pharmacist_in_charge' else FORBIDDEN
  p = preparations[preparation] ! else NOT_FOUND
  require p.technician != viewer else DIFFERENT_PERSON
  require p.status = 'awaiting' else ALREADY_RESOLVED
  require now >= p.expiresAt else NOT_EXPIRED
  insert overrides { preparation, actor: viewer, reason, at: now, originalDeadline: p.expiresAt }
  insert patients { preparation, name: patientName }
  update preparations[preparation] { status: 'verified', verifiedBy: viewer, resolvedAt: now }
  return preparations[preparation]

mutation discard(preparation: preparations):
  s = staff[principal = viewer] ! else NOT_STAFF
  p = preparations[preparation] ! else NOT_FOUND
  require p.status = 'awaiting' else ALREADY_RESOLVED
  require now >= p.expiresAt else NOT_EXPIRED
  update preparations[preparation] { status: 'discarded', verifiedBy: null, resolvedAt: now }
  return preparations[preparation]
