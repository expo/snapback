-- Route Setting Rotation: a climbing gym strips and resets one wall section
-- each week. Setters log routes (grade, color, photo); climbers log ascents
-- and suggest grades. Routes retire automatically six weeks after being set
-- unless the head setter extends them. Only the head setter can regrade a
-- route or close a section for setting.
use identity password

-- Roster: one row per member. Readable by everyone signed in so role probes
-- in programs see the whole roster; writes only happen through the
-- enrollment mutations below.
table gymRoles:
  principal: principal
  role: enum('climber', 'setter', 'head_setter')
  unique principal
  read <- allow
  insert <- .principal = viewer or exists gymRoles[viewer, role = 'head_setter']
  update <- .principal = viewer or exists gymRoles[viewer, role = 'head_setter']
  delete <- exists gymRoles[viewer, role = 'head_setter']
  online only

-- Bootstrap: the single first head setter claims this seat. Whole-table
-- cap 1 means only the first claim ever succeeds; every later head setter
-- is granted by an existing one through grantRole.
table headClaim:
  holder: principal
  cap 1
  read <- allow
  insert <- .holder = viewer
  online only

table sections:
  name: text 1..40
  closed: bool default false
  unique name
  public 'wall sections are visible to everyone signed in'
  insert <- exists gymRoles[viewer, role = 'head_setter']
  update <- exists gymRoles[viewer, role = 'head_setter']
  delete <- exists gymRoles[viewer, role = 'head_setter']
  online only

table routes:
  section: sections
  setter: principal
  grade: text 1..10
  color: text 1..30
  photo: image <=10000000
  setAt: time default now
  expiresAt: time
  immutable section, setter, setAt
  public 'current routes are visible to everyone signed in'
  insert <- .setter = viewer and (exists gymRoles[viewer, role = 'setter'] or exists gymRoles[viewer, role = 'head_setter'])
  update <- exists gymRoles[viewer, role = 'head_setter']
  delete <- exists gymRoles[viewer, role = 'head_setter']
  expire at .expiresAt
  online only

-- A climber's logbook: private to its owner. Cascades with its route, so a
-- retired route leaves the logbook showing only current routes.
table ascents:
  route: routes on delete cascade
  climber: principal
  at: time default now
  cap 300 by route
  immutable route, climber
  read <- .climber = viewer
  insert <- .climber = viewer
  online only

-- Grade suggestions: readable by their author, by the setter of the route,
-- and by the head setter. Cascades with its route.
table suggestions:
  route: routes on delete cascade
  author: principal
  routeSetter: principal
  cap 100 by route
  grade: text 1..10
  comment: text 1..280 ?
  at: time default now
  immutable route, author, routeSetter
  read <- .author = viewer or .routeSetter = viewer or exists gymRoles[viewer, role = 'head_setter']
  insert <- .author = viewer and .routeSetter = .route.setter
  online only

query whoAmI():
  return viewer

query myRole():
  return gymRoles[principal = viewer]

query roster(c: cursor ?):
  require exists gymRoles[viewer, role = 'head_setter'] else NOT_HEAD 'Only the head setter sees the roster.'
  return gymRoles last 100 by .id after c

query sectionsList(c: cursor ?):
  return sections first 50 by .id after c

query currentRoutes(c: cursor ?):
  return routes last 50 by .setAt after c { id, grade, color, photo, setter, setAt, expiresAt, section: sections[.section] }

query myRoutes(c: cursor ?):
  return routes where .setter = viewer last 50 by .setAt after c { id, grade, color, photo, setter, setAt, expiresAt, section: sections[.section] }

query myLogbook(c: cursor ?):
  return ascents where .climber = viewer last 50 by .at after c { id, at, route: routes[.route] }

query mySuggestions(c: cursor ?):
  return suggestions where .author = viewer last 50 by .at after c

query routeSuggestions(route: routes, c: cursor ?):
  r = routes[route] ! else NOT_FOUND
  require r.setter = viewer or exists gymRoles[viewer, role = 'head_setter'] else NOT_YOUR_ROUTE 'Only the setter of this route or the head setter may read its suggestions.'
  return suggestions where .route = route last 50 by .at after c

mutation claimClimber():
  require not exists gymRoles[viewer] else HAS_ROLE 'You already have a role.'
  return upsert gymRoles[viewer] { role: 'climber' }

mutation bootstrapHead():
  insert headClaim { holder: viewer }
  return upsert gymRoles[viewer] { role: 'head_setter' }

mutation grantRole(who: principal, role: enum('climber', 'setter', 'head_setter')):
  require exists gymRoles[viewer, role = 'head_setter'] else NOT_HEAD 'Only the head setter assigns roles.'
  return upsert gymRoles[who] { role }

mutation addSection(name: text 1..40):
  require exists gymRoles[viewer, role = 'head_setter'] else NOT_HEAD 'Only the head setter manages sections.'
  return insert sections { name }

mutation closeSection(section: sections, closed: bool):
  require exists gymRoles[viewer, role = 'head_setter'] else NOT_HEAD 'Only the head setter closes a section.'
  s = sections[section] ! else NOT_FOUND
  update sections[section] { closed }
  return null

mutation logRoute(section: sections, grade: text 1..10, color: text 1..30, photo: image <=10000000):
  require exists gymRoles[viewer, role = 'setter'] or exists gymRoles[viewer, role = 'head_setter'] else NOT_SETTER 'Only setters log routes.'
  s = sections[section] ! else NOT_FOUND
  return insert routes { section, setter: viewer, grade, color, photo, expiresAt: now + 42d }

mutation regrade(route: routes, grade: text 1..10):
  require exists gymRoles[viewer, role = 'head_setter'] else NOT_HEAD 'Only the head setter regrades a route.'
  r = routes[route] ! else NOT_FOUND
  update routes[route] { grade }
  return null

mutation extendRoute(route: routes, weeks: int 1..12):
  require exists gymRoles[viewer, role = 'head_setter'] else NOT_HEAD 'Only the head setter extends a route.'
  r = routes[route] ! else NOT_FOUND
  update routes[route] { expiresAt: now + weeks * 7d }
  return null

mutation logAscent(route: routes):
  r = routes[route] ! else NOT_FOUND
  s = sections[r.section] ! else NOT_FOUND
  require not s.closed else SECTION_CLOSED 'This section is closed for setting.'
  return insert ascents { route, climber: viewer }

mutation suggestGrade(route: routes, grade: text 1..10, comment: text 1..280 ?):
  r = routes[route] ! else NOT_FOUND
  return insert suggestions { route, author: viewer, routeSetter: r.setter, grade, comment }
