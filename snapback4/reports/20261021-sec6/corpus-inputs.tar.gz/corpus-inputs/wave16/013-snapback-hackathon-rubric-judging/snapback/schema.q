-- Hackathon Rubric Judging.
-- Roles: team, judge, organizer, head. Password accounts (real auth).
-- Teams own one submission each; judges score only assigned submissions;
-- organizers/head see live totals; head alone reassigns/disqualifies/publishes.
use identity password

table roles:
  principal: principal
  role: enum('team', 'judge', 'organizer', 'head')
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'organizer']
  insert <- exists roles[viewer, role = 'head'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'head']
  delete <- exists roles[viewer, role = 'head']
  online only

table contests:
  title: text 3..80
  submissionDeadline: time
  judgingCloses: time
  cap 1
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'head'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'head']
  online only

table submissions:
  owner: principal
  title: text 3..80
  description: text 1..500
  videoUrl: text 1..500
  repoUrl: text 1..500
  disqualified: bool default false
  dqReason: text <=300 ?
  updatedAt: time default now
  immutable owner
  cap 1 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head'] or exists assignments[submission = .id, judge = viewer]
  insert <- .owner = viewer and exists roles[viewer, role = 'team']
  update <- .owner = viewer or exists roles[viewer, role = 'head']
  online only

table assignments:
  submission: submissions
  judge: principal
  immutable submission, judge
  unique submission, judge
  read <- .judge = viewer or exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head']
  insert <- exists roles[viewer, role = 'head']
  delete <- exists roles[viewer, role = 'head']
  online only

table scores:
  submission: submissions
  judge: principal
  owner: principal
  innovation: int 1..10
  execution: int 1..10
  presentation: int 1..10
  total: int 3..30
  comment: text <=500 ?
  unique submission, judge
  immutable submission, judge, owner
  cap 50 by submission
  read <- .judge = viewer or exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head']
  insert <- .judge = viewer
  update <- .judge = viewer
  online only

table publishedScores:
  submission: submissions
  judge: principal
  owner: principal
  innovation: int 1..10
  execution: int 1..10
  presentation: int 1..10
  total: int 3..30
  comment: text <=500 ?
  unique submission, judge
  immutable submission, judge, owner, innovation, execution, presentation, total, comment
  read <- .owner = viewer or .judge = viewer or exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head']
  insert <- exists roles[viewer, role = 'head']
  online only

view scoreCount: count scores by .submission
  read <- exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head']
view scoreTotal: sum scores of .total by .submission
  read <- exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head']

query whoAmI():
  return viewer

query myRole():
  return roles[principal = viewer]

query contestState():
  return contests first 1 by .id

query visibleSubmissions(c: cursor ?):
  return submissions last 50 by .id after c

query mySubmissions(c: cursor ?):
  return submissions where .owner = viewer last 20 by .id after c

query myAssignments(c: cursor ?):
  require exists roles[viewer, role = 'judge'] else NOT_JUDGE
  return assignments where .judge = viewer first 50 by .id after c

query allAssignments(c: cursor ?):
  require exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head'] else NOT_STAFF
  return assignments last 50 by .id after c

query allRoles(c: cursor ?):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  return roles last 50 by .id after c

query myScore(sub: submissions):
  return scores[submission = sub, judge = viewer]

query allScores(sub: submissions):
  require exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head'] else NOT_STAFF
  return scores where .submission = sub first 50 by .id

query totalsFor(sub: submissions):
  require exists roles[viewer, role = 'organizer'] or exists roles[viewer, role = 'head'] else NOT_STAFF
  return { n: scoreCount[sub], total: scoreTotal[sub] }

query myPublished(c: cursor ?):
  return publishedScores where .owner = viewer first 50 by .id after c

query visiblePublished(sub: submissions, c: cursor ?):
  return publishedScores where .submission = sub and (.owner = viewer or .judge = viewer) first 50 by .id after c

mutation assignRole(who: principal, role: enum('team', 'judge', 'organizer', 'head')):
  require exists roles[viewer, role = 'head'] or viewer = 'service:ops' else NOT_HEAD
  return upsert roles[who] { role }

mutation initContest(title: text 3..80, submissionDeadline: time, judgingCloses: time):
  require exists roles[viewer, role = 'head'] or viewer = 'service:ops' else NOT_HEAD
  return insert contests { title, submissionDeadline, judgingCloses }

mutation updateContest(contest: contests, submissionDeadline: time, judgingCloses: time):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  update contests[contest] { submissionDeadline, judgingCloses }
  return null

mutation createSubmission(contest: contests, title: text 3..80, description: text 1..500, videoUrl: text 1..500, repoUrl: text 1..500):
  require exists roles[viewer, role = 'team'] else NOT_TEAM
  c = contests[contest] ! else NOT_FOUND
  require now <= c.submissionDeadline else SUBMISSIONS_CLOSED
  return insert submissions { owner: viewer, title, description, videoUrl, repoUrl }

mutation updateSubmission(sub: submissions, title: text 3..80, description: text 1..500, videoUrl: text 1..500, repoUrl: text 1..500, contest: contests):
  row = submissions[sub] ! else NOT_FOUND
  require row.owner = viewer else NOT_OWNER
  require not row.disqualified else DISQUALIFIED
  c = contests[contest] ! else NOT_FOUND
  require now <= c.submissionDeadline else SUBMISSIONS_CLOSED
  update submissions[sub] { title, description, videoUrl, repoUrl, updatedAt: now }
  return null

mutation assignJudge(sub: submissions, j: principal):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  require exists roles[j, role = 'judge'] else NOT_JUDGE
  s = submissions[sub] ! else NOT_FOUND
  require not s.disqualified else DISQUALIFIED
  return insert assignments { submission: sub, judge: j } if absent

mutation unassignJudge(sub: submissions, j: principal):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  if exists assignments[submission = sub, judge = j]:
    delete assignments[submission = sub, judge = j]
  return null

mutation submitScore(contest: contests, sub: submissions, innovation: int 1..10, execution: int 1..10, presentation: int 1..10, comment: text <=500 ?):
  require exists roles[viewer, role = 'judge'] else NOT_JUDGE
  require exists assignments[submission = sub, judge = viewer] else NOT_ASSIGNED
  c = contests[contest] ! else NOT_FOUND
  require now <= c.judgingCloses else JUDGING_CLOSED
  s = submissions[sub] ! else NOT_FOUND
  require not s.disqualified else DISQUALIFIED
  row = scores[sub, viewer]
  if row = null:
    return insert scores { submission: sub, judge: viewer, owner: s.owner, innovation, execution, presentation, total: innovation + execution + presentation, comment }
  update scores[row] { innovation, execution, presentation, total: innovation + execution + presentation, comment: comment ?? row.comment }
  return null

mutation disqualify(sub: submissions, reason: text 1..300):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  update submissions[sub] { disqualified: true, dqReason: reason }
  return null

mutation publishSubmission(sub: submissions):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  s = submissions[sub] ! else NOT_FOUND
  page = scores where .submission = sub first 100 by .id
  for row in page:
    insert publishedScores { submission: sub, judge: row.judge, owner: row.owner, innovation: row.innovation, execution: row.execution, presentation: row.presentation, total: row.total, comment: row.comment } if absent
  return null
