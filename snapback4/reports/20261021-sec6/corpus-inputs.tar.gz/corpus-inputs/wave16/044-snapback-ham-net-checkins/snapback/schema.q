-- Ham Radio Net Check-ins.
-- Roles: member (listens, checks in, reviews logs), net_control (logs
-- check-ins during nets they are scheduled for), coordinator (schedules nets,
-- manages roles, the only role that reads emergency contact details).
-- Nets run a scheduled hour [startsAt, endsAt); a job closes them
-- automatically. Check-in logging is further gated to the open window in the
-- mutations, because rules cannot vary with time.
use identity password

table club_roles:
  principal: principal
  role: enum('member', 'net_control', 'coordinator')
  unique principal
  read <- exists club_roles[viewer]
  insert <- exists club_roles[viewer, role = 'coordinator'] or viewer = 'service:ops'
  update <- exists club_roles[viewer, role = 'coordinator']
  delete <- exists club_roles[viewer, role = 'coordinator']
  cap 100
  online only

table nets:
  title: text 1..80
  startsAt: time
  endsAt: time
  controller: principal
  open: bool default true
  immutable startsAt, endsAt, controller
  read <- exists club_roles[viewer]
  insert <- exists club_roles[viewer, role = 'coordinator']
  update <- exists club_roles[viewer, role = 'coordinator'] or .controller = viewer
  cap 500
  online only

table checkins:
  net: nets on delete cascade
  station: principal
  callSign: text 3..12
  traffic: text <=280 ?
  at: time default now
  immutable net, station, callSign, at
  read <- exists club_roles[viewer]
  insert <- exists club_roles[viewer, role = 'net_control'] and exists nets[.net, controller = viewer]
  delete <- exists club_roles[viewer, role = 'net_control'] and exists nets[.net, controller = viewer]
  cap 500 by net
  online only

table emergency_regs:
  station: principal
  callSign: text 3..12
  phone: text 3..30
  email: text 3..120
  unique station
  immutable station
  read <- .station = viewer or exists club_roles[viewer, role = 'coordinator']
  insert <- .station = viewer and exists club_roles[viewer]
  update <- .station = viewer or exists club_roles[viewer, role = 'coordinator']
  delete <- .station = viewer or exists club_roles[viewer, role = 'coordinator']
  cap 1000
  online only

query myRole():
  require exists club_roles[viewer] else NOT_MEMBER
  return club_roles where .principal = viewer first 5 by .id

query netsList(c: cursor ?):
  require exists club_roles[viewer] else NOT_MEMBER
  return nets last 50 by .startsAt after c

query netLog(net: nets, c: cursor ?):
  require exists club_roles[viewer] else NOT_MEMBER
  return checkins where .net = net first 200 by .at after c

query myCheckins(c: cursor ?):
  require exists club_roles[viewer] else NOT_MEMBER
  return checkins where .station = viewer last 50 by .at after c

query emergencyList(c: cursor ?):
  require exists club_roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
  return emergency_regs first 100 by .id after c

query myEmergency():
  require exists club_roles[viewer] else NOT_MEMBER
  return emergency_regs where .station = viewer first 5 by .id

mutation createNet(title: text 1..80, startsAt: time, controller: principal):
  require exists club_roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
  require exists club_roles[controller, role = 'net_control'] else NOT_OPERATOR
  return insert nets { title, startsAt, endsAt: startsAt + 1h, controller, open: true }

mutation closeNet(net: nets):
  n = nets[net] ! else NOT_FOUND
  require exists club_roles[viewer, role = 'coordinator'] or n.controller = viewer else NOT_IN_CHARGE
  update nets[net] { open: false }
  return null

mutation logCheckin(net: nets, station: principal, callSign: text 3..12, traffic: text <=280 ?):
  n = nets[net] ! else NOT_FOUND
  require exists club_roles[viewer, role = 'net_control'] else NOT_NET_CONTROL
  require n.controller = viewer else NOT_YOUR_NET
  require n.open else NET_CLOSED
  require now >= n.startsAt else NET_NOT_STARTED
  require now < n.endsAt else NET_ENDED
  require exists club_roles[station] else NOT_MEMBER
  return insert checkins { net, station, callSign, traffic, at: now }

mutation removeCheckin(checkin: checkins):
  c = checkins[checkin] ! else NOT_FOUND
  n = nets[c.net] ! else NOT_FOUND
  require exists club_roles[viewer, role = 'net_control'] else NOT_NET_CONTROL
  require n.controller = viewer else NOT_YOUR_NET
  require n.open else NET_CLOSED
  require now >= n.startsAt and now < n.endsAt else NET_ENDED
  delete checkins[checkin]
  return null

mutation registerEmergency(callSign: text 3..12, phone: text 3..30, email: text 3..120):
  require exists club_roles[viewer] else NOT_MEMBER
  return upsert emergency_regs[station = viewer] { station: viewer, callSign, phone, email }

mutation setRole(who: principal, role: enum('member', 'net_control', 'coordinator')):
  require exists club_roles[viewer, role = 'coordinator'] else NOT_COORDINATOR
  return upsert club_roles[who] { role }

job closeEndedNets(periodStart: time, periodEnd: time):
  for n in nets where .endsAt >= periodEnd - 7d and .endsAt < periodEnd by .endsAt:
    if n.open:
      update nets[n.id] { open: false }

schedule closer every 1m: closeEndedNets
