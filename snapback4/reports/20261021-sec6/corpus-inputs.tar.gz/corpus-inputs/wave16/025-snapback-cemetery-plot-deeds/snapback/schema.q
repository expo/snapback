use identity

table accounts:
  principal: principal
  name: text 1..80
  role: enum('public', 'family', 'holder', 'sexton', 'commission')
  unique principal
  immutable principal, role
  read <- .principal = viewer or exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or (.principal = viewer and .role = 'family')
  online only

table plots:
  section: text 1..30
  code: text 1..30
  state: enum('available', 'reserved', 'deeded') default 'available'
  holder: principal ?
  reserver: principal ?
  expiresAt: time ?
  heir: text 1..120 ?
  scan: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png') ?
  unique section, code
  immutable section, code
  read <- .holder = viewer or .reserver = viewer or exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission'] or (.state = 'available' and (exists accounts[viewer, role = 'family'] or exists accounts[viewer, role = 'holder']))
  insert <- exists accounts[viewer, role = 'commission']
  update <- .holder = viewer or .reserver = viewer or exists accounts[viewer, role = 'commission'] or exists accounts[viewer, role = 'family'] or exists accounts[viewer, role = 'holder']
  online only

table transfers:
  plot: plots
  previous: principal ?
  successor: principal
  officer: principal
  at: time
  reason: text 1..300
  immutable plot, previous, successor, officer, at, reason
  read <- exists accounts[viewer, role = 'commission'] or exists accounts[viewer, role = 'sexton']
  insert <- exists accounts[viewer, role = 'commission'] and .officer = viewer
  online only

table burials:
  plot: plots
  name: text 1..120
  scheduledAt: time
  sexton: principal
  completed: bool default false
  immutable plot, name, sexton, scheduledAt
  read <- exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission']
  insert <- exists accounts[viewer, role = 'sexton'] and .sexton = viewer
  update <- exists accounts[viewer, role = 'sexton']
  online only

table interments:
  name: text 1..120
  section: text 1..30
  plotCode: text 1..30
  interredAt: time
  burial: burials
  unique burial
  immutable name, section, plotCode, interredAt, burial
  search name
  public 'Only the memorial name, location, and interment date are public.'
  insert <- exists accounts[viewer, role = 'sexton']
  online only

query me():
  return accounts[principal = viewer]
query account(principal: principal):
  return accounts[principal = principal]
query directory(c: cursor ?):
  require exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission'] else STAFF_ONLY
  return accounts first 100 by .id after c
query plot(plot: plots):
  return plots[plot]
query myPlots(c: cursor ?):
  return plots where .holder = viewer or .reserver = viewer first 100 by .id after c
query available(c: cursor ?):
  require exists accounts[viewer, role = 'family'] or exists accounts[viewer, role = 'holder'] else FAMILY_ONLY
  return plots where .state = 'available' first 100 by .id after c
query inventory(c: cursor ?):
  require exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission'] else STAFF_ONLY
  return plots first 100 by .id after c
query history(plot: plots, c: cursor ?):
  require exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission'] else STAFF_ONLY
  return transfers where .plot = plot first 100 by .at after c
query burialSchedule(c: cursor ?):
  require exists accounts[viewer, role = 'sexton'] or exists accounts[viewer, role = 'commission'] else STAFF_ONLY
  return burials first 100 by .scheduledAt after c
query searchInterments(name: text <=120, section: text <=30, c: cursor ?):
  return interments matching name where section = '' or .section = section first 100 by .id after c { id, name, section, plotCode, interredAt }

mutation enroll(name: text 1..80):
  require not exists accounts[principal = viewer] else ALREADY_ENROLLED
  return insert accounts { principal: viewer, name, role: 'family' }
mutation provision(principal: principal, name: text 1..80, role: enum('public', 'family', 'holder', 'sexton', 'commission')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert accounts { principal, name, role }
mutation addPlot(section: text 1..30, code: text 1..30):
  require exists accounts[viewer, role = 'commission'] else COMMISSION_ONLY
  return insert plots { section, code }
mutation reserve(plot: plots):
  require exists accounts[viewer, role = 'family'] or exists accounts[viewer, role = 'holder'] else FAMILY_ONLY
  p = plots[plot] ! else NOT_FOUND
  require p.state = 'available' else UNAVAILABLE
  update plots[plot] { state: 'reserved', reserver: viewer, expiresAt: now + 30d }
mutation recordPayment(plot: plots):
  require exists accounts[viewer, role = 'commission'] else COMMISSION_ONLY
  p = plots[plot] ! else NOT_FOUND
  require p.state = 'reserved' else NOT_RESERVED
  require p.expiresAt != null and p.expiresAt > now else RESERVATION_EXPIRED
  require p.reserver != null else NOT_RESERVED
  insert transfers { plot, previous: null, successor: p.reserver, officer: viewer, at: now, reason: 'Initial deed issued after payment' }
  update plots[plot] { state: 'deeded', holder: p.reserver, reserver: null, expiresAt: null }
mutation nameHeir(plot: plots, heir: text 1..120):
  p = plots[plot] ! else NOT_FOUND
  require p.holder = viewer and p.state = 'deeded' else HOLDER_ONLY
  update plots[plot] { heir }
mutation attachDeed(plot: plots, scan: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  p = plots[plot] ! else NOT_FOUND
  require p.state = 'deeded' else NOT_DEEDED
  require p.holder = viewer or exists accounts[viewer, role = 'commission'] else HOLDER_ONLY
  update plots[plot] { scan }
mutation transferDeed(plot: plots, successor: principal, reason: text 1..300):
  require exists accounts[viewer, role = 'commission'] else COMMISSION_ONLY
  p = plots[plot] ! else NOT_FOUND
  require p.state = 'deeded' else NOT_DEEDED
  a = accounts[principal = successor] ! else UNKNOWN_HOLDER
  require a.role = 'family' or a.role = 'holder' else NOT_FAMILY
  require successor != p.holder else SAME_HOLDER
  insert transfers { plot, previous: p.holder, successor, officer: viewer, at: now, reason }
  update plots[plot] { holder: successor, heir: null }
mutation scheduleBurial(plot: plots, name: text 1..120, scheduledAt: time):
  require exists accounts[viewer, role = 'sexton'] else SEXTON_ONLY
  p = plots[plot] ! else NOT_FOUND
  require p.state = 'deeded' else NOT_DEEDED
  require scheduledAt > now else FUTURE_REQUIRED
  return insert burials { plot, name, scheduledAt, sexton: viewer }
mutation completeBurial(burial: burials):
  require exists accounts[viewer, role = 'sexton'] else SEXTON_ONLY
  b = burials[burial] ! else NOT_FOUND
  require not b.completed else ALREADY_COMPLETED
  require b.scheduledAt <= now else TOO_EARLY
  p = plots[b.plot] ! else NOT_FOUND
  insert interments { name: b.name, section: p.section, plotCode: p.code, interredAt: now, burial }
  update burials[burial] { completed: true }

job lapseReservations():
  for p in plots:
    if p.state = 'reserved' and p.expiresAt != null and p.expiresAt <= now:
      update plots[p.id] { state: 'available', reserver: null, expiresAt: null }
schedule hourlyLapse every 1h: lapseReservations
