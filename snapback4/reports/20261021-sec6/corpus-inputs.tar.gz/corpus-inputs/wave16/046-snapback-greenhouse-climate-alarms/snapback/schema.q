use identity password

-- Roles are provisioned by an operator service seat, never self-selected.
table staff:
  principal: principal
  role: enum('grower', 'headGrower', 'owner', 'sensor')
  onDuty: bool default false
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- .principal = viewer and .role = 'grower'
  online only

table zones:
  name: text 1..80
  minTemp: int -30..60
  maxTemp: int -30..60
  minHumidity: int 0..100
  maxHumidity: int 0..100
  read <- exists staff[principal = viewer, role = 'headGrower'] or exists assignments[.id, viewer]
  insert <- exists staff[principal = viewer, role = 'headGrower']
  update <- exists staff[principal = viewer, role = 'headGrower']
  online only

table assignments:
  zone: zones
  principal: principal
  unique zone, principal
  immutable zone, principal
  read <- .principal = viewer or exists staff[principal = viewer, role = 'headGrower']
  insert <- exists staff[principal = viewer, role = 'headGrower'] and (exists staff[principal = .principal, role = 'grower'] or exists staff[principal = .principal, role = 'sensor'])
  delete <- exists staff[principal = viewer, role = 'headGrower']
  online only

table readings:
  zone: zones
  author: principal
  source: enum('grower', 'sensor')
  temperature: int -30..60
  humidity: int 0..100
  at: time
  monthNumber: int
  photo: image <=5000000 ?
  immutable zone, author, source, temperature, humidity, at, monthNumber
  read <- exists staff[principal = viewer, role = 'headGrower'] or exists assignments[.zone, viewer]
  insert <- .author = viewer and exists assignments[.zone, viewer] and (exists staff[principal = viewer, role = 'grower'] or exists staff[principal = viewer, role = 'sensor'])
  update <- .author = viewer and exists assignments[.zone, viewer] and exists staff[principal = viewer, role = 'grower']
  online only

table alarms:
  zone: zones
  reading: readings
  raisedAt: time
  deadline: time
  monthNumber: int
  acknowledgedBy: principal ?
  acknowledgedAt: time ?
  escalated: bool default false
  immutable zone, reading, raisedAt, deadline, monthNumber
  read <- exists staff[principal = viewer, role = 'headGrower'] or (exists assignments[.zone, viewer] and exists staff[principal = viewer, role = 'grower', onDuty = true])
  insert <- exists assignments[.zone, viewer] and (exists staff[principal = viewer, role = 'grower'] or exists staff[principal = viewer, role = 'sensor'])
  update <- exists staff[principal = viewer, role = 'headGrower'] or (exists assignments[.zone, viewer] and exists staff[principal = viewer, role = 'grower', onDuty = true])
  online only

view monthlyReadings: count readings by .monthNumber
  read <- exists staff[principal = viewer, role = 'owner'] or exists staff[principal = viewer, role = 'headGrower']
  online only
view monthlyTemperatures: sum readings of .temperature by .monthNumber
  read <- exists staff[principal = viewer, role = 'owner'] or exists staff[principal = viewer, role = 'headGrower']
  online only
view monthlyHumidity: sum readings of .humidity by .monthNumber
  read <- exists staff[principal = viewer, role = 'owner'] or exists staff[principal = viewer, role = 'headGrower']
  online only
view monthlyAlarms: count alarms by .monthNumber
  read <- exists staff[principal = viewer, role = 'owner'] or exists staff[principal = viewer, role = 'headGrower']
  online only
view monthlyEscalations: count alarms where .escalated = true by .monthNumber
  read <- exists staff[principal = viewer, role = 'owner'] or exists staff[principal = viewer, role = 'headGrower']
  online only

query me():
  return staff[principal = viewer]
query profile(principal: principal):
  require principal = viewer else PRIVATE_PROFILE
  return staff[principal = principal]
mutation provision(principal: principal, role: enum('grower', 'headGrower', 'owner', 'sensor')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert staff { principal, role, onDuty: false }
mutation setDuty(onDuty: bool):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'grower' else GROWER_ONLY
  update staff[s.id] { onDuty }
query zoneList(c: cursor ?):
  return zones first 100 by .id after c
query zoneDetail(zone: zones):
  return zones[zone]
mutation createZone(name: text 1..80, minTemp: int -30..60, maxTemp: int -30..60, minHumidity: int 0..100, maxHumidity: int 0..100):
  require minTemp < maxTemp and minHumidity < maxHumidity else INVALID_RANGE
  return insert zones { name, minTemp, maxTemp, minHumidity, maxHumidity }
mutation setRanges(zone: zones, minTemp: int -30..60, maxTemp: int -30..60, minHumidity: int 0..100, maxHumidity: int 0..100):
  require minTemp < maxTemp and minHumidity < maxHumidity else INVALID_RANGE
  update zones[zone] { minTemp, maxTemp, minHumidity, maxHumidity }
query zoneAssignments(zone: zones, c: cursor ?):
  return assignments where .zone = zone first 100 by .id after c
mutation assign(zone: zones, principal: principal):
  z = zones[zone] ! else NOT_FOUND
  return insert assignments { zone, principal }
mutation unassign(assignment: assignments):
  delete assignments[assignment]
query history(zone: zones, c: cursor ?):
  return readings where .zone = zone last 100 by .at after c
query readingDetail(reading: readings):
  return readings[reading]
mutation recordReading(zone: zones, temperature: int -30..60, humidity: int 0..100):
  z = zones[zone] ! else NOT_FOUND
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'grower' or s.role = 'sensor' else RECORDER_ONLY
  r = insert readings { zone, author: viewer, source: 'sensor' if s.role = 'sensor' else 'grower', temperature, humidity, at: now, monthNumber: month(now), photo: null }
  if temperature < z.minTemp or temperature > z.maxTemp or humidity < z.minHumidity or humidity > z.maxHumidity:
    insert alarms { zone, reading: r.id, raisedAt: now, deadline: now + 10m, monthNumber: month(now), acknowledgedBy: null, acknowledgedAt: null, escalated: false }
  return r
mutation attachPhoto(reading: readings, photo: image <=5000000):
  r = readings[reading] ! else NOT_FOUND
  require r.author = viewer else OWN_READING_ONLY
  update readings[reading] { photo }
query liveAlarms(zone: zones, c: cursor ?):
  return alarms where .zone = zone last 100 by .raisedAt after c
query alarmDetail(alarm: alarms):
  return alarms[alarm]
mutation acknowledge(alarm: alarms):
  a = alarms[alarm] ! else NOT_FOUND
  require a.acknowledgedAt = null else ALREADY_ACKNOWLEDGED
  update alarms[alarm] { acknowledgedBy: viewer, acknowledgedAt: now, escalated: a.escalated or now >= a.deadline }
query monthlySummary(monthNumber: int):
  s = staff[principal = viewer] ! else NOT_STAFF
  require s.role = 'owner' or s.role = 'headGrower' else SUMMARY_ONLY
  return { monthNumber, readings: monthlyReadings[monthNumber], temperatureTotal: monthlyTemperatures[monthNumber], humidityTotal: monthlyHumidity[monthNumber], alarms: monthlyAlarms[monthNumber], escalations: monthlyEscalations[monthNumber] }
job escalate():
  for a in alarms:
    if a.acknowledgedAt = null and not a.escalated and now >= a.deadline:
      update alarms[a.id] { escalated: true }
schedule escalationSweep every 1m: escalate
