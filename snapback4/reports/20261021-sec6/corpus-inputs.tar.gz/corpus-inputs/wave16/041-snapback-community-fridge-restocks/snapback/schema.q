-- Community Fridge Restocks.
--
-- Roles: network coordinator, volunteer, host, public. The roster is the
-- `roles` table (one row per user). The first coordinator is provisioned by
-- the operator through `service:ops` (or dev `/seed`); afterwards
-- coordinators manage the roster with `grantRole` / `removeVolunteer`.
-- Guests (no account) see exactly what signed-in public users see.
use identity
use personas coord1, coord2, vol1, vol2, host1, host2, pub1, pub2

-- One row per user. Coordinator rows are managed by coordinators only.
table roles:
  principal: principal
  role: enum('coordinator', 'volunteer', 'host', 'public')
  handle: text 3..40
  unique principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'coordinator']
  insert <- exists roles[principal = viewer, role = 'coordinator'] or viewer = 'service:ops'
  update <- deny
  delete <- exists roles[principal = viewer, role = 'coordinator'] or viewer = 'service:ops'
  online only

-- A fridge. Everybody can read rows for open fridges (that is the public
-- directory); closed fridges are visible only to their host, volunteers
-- and the coordinator.
table fridges:
  name: text 1..80
  location: text 1..200
  open: bool default true
  hostOwner: principal ?
  immutable name
  cap 50
  read <- .open = true or .hostOwner = viewer or exists roles[principal = viewer, role = 'volunteer'] or exists roles[principal = viewer, role = 'coordinator']
  insert <- exists roles[principal = viewer, role = 'coordinator']
  update (old, next) <- exists roles[principal = viewer, role = 'coordinator'] or (old.hostOwner = viewer and next.hostOwner = old.hostOwner and next.location = old.location)
  delete <- exists roles[principal = viewer, role = 'coordinator']
  online only

-- One restock log per volunteer visit. The photo is required: a drop is a
-- witnessed visit. Drops are immutable history (only cascades delete them).
table drops:
  fridge: fridges on delete restrict
  volunteer: principal
  photo: image <=8000000
  note: text <=280 ?
  at: time default now
  immutable fridge, volunteer
  cap 100 by fridge
  read <- exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'volunteer'] or exists fridges[.fridge, hostOwner = viewer]
  insert <- .volunteer = viewer and exists roles[principal = viewer, role = 'volunteer'] and exists fridges[.fridge, open = true]
  update <- deny
  delete <- exists roles[principal = viewer, role = 'coordinator']
  online only

-- Items belonging to a drop. `fridge` is copied from the drop at insert and
-- verified, so per-fridge stock can be aggregated without a join.
table items:
  drop: drops on delete restrict
  fridge: fridges on delete restrict
  name: text 1..60
  qty: int 1..1000
  useBy: time ?
  immutable drop, fridge
  cap 500 by fridge
  cap 100 by drop
  read <- exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'volunteer'] or exists fridges[.fridge, hostOwner = viewer]
  insert <- (exists roles[principal = viewer, role = 'volunteer'] and exists drops[.drop, volunteer = viewer, fridge = .fridge] and exists fridges[.fridge, open = true]) or (exists roles[principal = viewer, role = 'coordinator'] and exists drops[.drop, fridge = .fridge])
  update <- exists roles[principal = viewer, role = 'coordinator'] or exists drops[.drop, volunteer = viewer]
  delete <- exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'volunteer']
  online only

-- Exact per-fridge totals. Publicly readable as a number source, but only
-- exposed through queries: the public query buckets it, the staff query
-- returns it exactly. Views are only reachable through declared queries.
view stockTotals: sum items of .qty by .fridge
  read <- allow
  online only

-- The public directory: open fridges with roughly-how-stocked buckets.
-- No exact counts, no closed fridges, no logs. Callable by anyone,
-- including guests.
query publicDirectory():
  return fridges where .open = true first 50 by .name { id, name, location, stock: stockLevel(stockTotals[.id] ?? 0) }

-- Live stock across all fridges, exact. Volunteers and coordinators only.
query stockLevels():
  require exists roles[principal = viewer, role = 'volunteer'] or exists roles[principal = viewer, role = 'coordinator'] else NOT_VOLUNTEER
  return fridges first 50 by .name { id, name, location, open, hostOwner, stock: stockTotals[.id] ?? 0 }

-- Logs for one fridge. Staff see any fridge; a host sees only their own.
query fridgeDrops(fridge: fridges, c: cursor ?):
  f = fridges[fridge] ! else NOT_FOUND
  require exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'volunteer'] or f.hostOwner = viewer else NOT_HOST
  return drops where .fridge = fridge last 50 by .at after c { id, volunteer, note, at, photo }

-- Items of one drop. Same audience as the logs.
query dropItems(drop: drops, c: cursor ?):
  d = drops[drop] ! else NOT_FOUND
  require exists roles[principal = viewer, role = 'coordinator'] or exists roles[principal = viewer, role = 'volunteer'] or exists fridges[d.fridge, hostOwner = viewer] else NOT_HOST
  return items where .drop = drop first 100 by .id after c

-- Items past their use-by date: flagged for removal on the next visit.
-- Staff see the whole network (or one fridge); a host sees only their own
-- fridge. Items without a use-by date are never flagged.
query flaggedItems(fridge: fridges ?, c: cursor ?):
  if fridge = null:
    require exists roles[principal = viewer, role = 'volunteer'] or exists roles[principal = viewer, role = 'coordinator'] else NOT_VOLUNTEER
    return items where .useBy != null and .useBy < now first 50 by .useBy after c
  f = fridges[fridge] ! else NOT_FOUND
  require exists roles[principal = viewer, role = 'volunteer'] or exists roles[principal = viewer, role = 'coordinator'] or f.hostOwner = viewer else NOT_HOST
  return items where .fridge = fridge and .useBy != null and .useBy < now first 50 by .useBy after c

-- The signed-in user's own fridge(s). Hosts see their fridge open or
-- closed; everyone else sees nothing here.
query myFridges():
  return fridges where .hostOwner = viewer first 20 by .name

-- The signed-in user's role row (null for guests and unroled users).
query myRole():
  return roles[principal = viewer]

-- The full roster, for the coordinator's manage screen. Refused otherwise.
query roster():
  require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  return roles first 100 by .handle

fn stockLevel(total: int):
  return 'empty' if total <= 0 else 'low' if total < 10 else 'medium' if total < 30 else 'high'

mutation addFridge(name: text 1..80, location: text 1..200, hostOwner: principal ?):
  require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  return insert fridges { name, location, hostOwner }

-- Only the coordinator can remove a fridge. Children are deleted
-- explicitly first (the stock view forbids cascade onto items).
mutation removeFridge(fridge: fridges):
  require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  f = fridges[fridge] ! else NOT_FOUND
  itemPage = items where .fridge = fridge first 500 by .id
  for row in itemPage:
    delete items[row]
  dropPage = drops where .fridge = fridge first 100 by .id
  for row in dropPage:
    delete drops[row]
  delete fridges[f.id]
  return null

-- The coordinator assigns a fridge's host. Hosts cannot reassign.
mutation assignHost(fridge: fridges, hostOwner: principal ?):
  require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  f = fridges[fridge] ! else NOT_FOUND
  update fridges[f.id] { hostOwner }
  return null

-- A host marks their own fridge open/closed; the coordinator any fridge.
mutation setFridgeOpen(fridge: fridges, open: bool):
  f = fridges[fridge] ! else NOT_FOUND
  require exists roles[principal = viewer, role = 'coordinator'] or f.hostOwner = viewer else NOT_HOST
  update fridges[f.id] { open }
  return null

-- A volunteer logs a drop (photo required) at an open fridge.
mutation logDrop(fridge: fridges, photo: image <=8000000, note: text <=280 ?):
  require exists roles[principal = viewer, role = 'volunteer'] else NOT_VOLUNTEER
  f = fridges[fridge] ! else NOT_FOUND
  require f.open else FRIDGE_CLOSED
  return insert drops { fridge: f.id, volunteer: viewer, photo, note }

-- The volunteer who logged the drop lists its items (or the coordinator).
-- Perishables carry a use-by date; anything else leaves it null.
mutation addItem(drop: drops, name: text 1..60, qty: int 1..1000, useBy: time ?):
  d = drops[drop] ! else NOT_FOUND
  require d.volunteer = viewer or exists roles[principal = viewer, role = 'coordinator'] else NOT_OWNER
  return insert items { drop: d.id, fridge: d.fridge, name, qty, useBy }

-- Removing expired food: only items past their use-by date, only by
-- volunteers or the coordinator. Anything else refuses NOT_EXPIRED, so the
-- time window is enforced, not just checked in the UI.
mutation removeExpiredItem(item: items):
  require exists roles[principal = viewer, role = 'volunteer'] or exists roles[principal = viewer, role = 'coordinator'] else NOT_VOLUNTEER
  i = items[item] ! else NOT_FOUND
  require i.useBy != null and i.useBy < now else NOT_EXPIRED
  delete items[i.id]
  return null

-- The coordinator (and only the coordinator) grants roles.
mutation grantRole(who: principal, role: enum('coordinator', 'volunteer', 'host', 'public'), handle: text 3..40):
  require exists roles[principal = viewer, role = 'coordinator'] or viewer = 'service:ops' else NOT_COORDINATOR
  return insert roles { principal: who, role, handle }

-- Only the network coordinator can remove a volunteer (or host/public
-- role). Coordinator rows are never removed through this operation.
mutation removeVolunteer(who: principal):
  require exists roles[principal = viewer, role = 'coordinator'] else NOT_COORDINATOR
  r = roles[principal = who] ! else NOT_FOUND
  require r.role != 'coordinator' else CANNOT_REMOVE_COORDINATOR
  delete roles[r.id]
  return null
