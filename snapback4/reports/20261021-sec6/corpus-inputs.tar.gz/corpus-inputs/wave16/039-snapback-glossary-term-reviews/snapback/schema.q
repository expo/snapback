use identity password

-- Roles and assignments are provisioned only by the agency's private operator seat.
table seats:
  principal: principal
  role: enum('translator', 'reviewer', 'client', 'manager')
  language: enum('de', 'fr') ?
  unique principal
  immutable principal, role, language
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table clients:
  name: text 1..100
  immutable name
  read <- exists memberships[.id, viewer] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  cap 100
  online only

table memberships:
  client: clients
  principal: principal
  unique client, principal
  immutable client, principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  cap 100 by principal
  online only

table terms:
  client: clients
  language: enum('de', 'fr')
  source: text 1..120
  translation: text 1..160
  usageNote: text 1..1200
  proposer: principal
  state: enum('pending', 'approved', 'rejected', 'retired') default 'pending'
  proposedAt: time default now
  reviewer: principal ?
  reviewNote: text <=600 ?
  decidedAt: time ?
  retiredBy: principal ?
  retiredAt: time ?
  immutable client, language, source, translation, usageNote, proposer, proposedAt
  read <- exists memberships[.client, viewer] and (exists seats[principal = viewer, role = 'translator'] or exists seats[principal = viewer, role = 'manager'] or exists seats[principal = viewer, role = 'reviewer', language = .language] or (.state = 'approved' and exists seats[principal = viewer, role = 'client']))
  insert <- .proposer = viewer and .state = 'pending' and exists memberships[.client, viewer] and exists seats[principal = viewer, role = 'translator']
  update <- exists memberships[.client, viewer] and (exists seats[principal = viewer, role = 'reviewer', language = .language] or exists seats[principal = viewer, role = 'manager'])
  cap 2000 by client
  online only

table documents:
  client: clients
  title: text 1..120
  document: file <=5000000 ('application/pdf', 'text/plain')
  uploader: principal
  uploadedAt: time default now
  immutable client, title, document, uploader, uploadedAt
  read <- exists memberships[.client, viewer]
  insert <- .uploader = viewer and exists memberships[.client, viewer] and (exists seats[principal = viewer, role = 'translator'] or exists seats[principal = viewer, role = 'reviewer'] or exists seats[principal = viewer, role = 'manager'])
  cap 100 by client
  online only

mutation provisionSeat(principal: principal, role: enum('translator', 'reviewer', 'client', 'manager'), language: enum('de', 'fr') ?):
  require viewer = 'service:ops' else OPERATOR_ONLY
  require (role = 'reviewer' and language != null) or (role != 'reviewer' and language = null) else BAD_LANGUAGE
  return insert seats { principal, role, language }

mutation createClient(name: text 1..100):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert clients { name }

mutation assignClient(client: clients, principal: principal):
  require viewer = 'service:ops' else OPERATOR_ONLY
  c = clients[client] ! else NOT_FOUND
  s = seats[principal = principal] ! else NOT_FOUND
  return insert memberships { client, principal }

query me():
  return seats[principal = viewer]

query myClients(c: cursor ?):
  return clients first 100 by .id after c

query glossary(client: clients, c: cursor ?):
  require exists memberships[client, viewer] else CLIENT_PRIVATE
  return terms where .client = client and .state = 'approved' last 100 by .proposedAt after c

query proposals(client: clients, c: cursor ?):
  s = seats[principal = viewer] ! else NO_ROLE
  require s.role != 'client' else READ_ONLY
  require exists memberships[client, viewer] else CLIENT_PRIVATE
  return terms where .client = client last 100 by .proposedAt after c

query reviewQueue(client: clients, c: cursor ?):
  s = seats[principal = viewer] ! else NO_ROLE
  require s.role = 'reviewer' else REVIEWER_ONLY
  require exists memberships[client, viewer] else CLIENT_PRIVATE
  return terms where .client = client and .language = s.language and .state = 'pending' first 100 by .proposedAt after c

query term(term: terms):
  return terms[term]

query usableTerm(term: terms):
  t = terms[term] ! else NOT_FOUND
  require t.state = 'approved' else NOT_APPROVED
  return t

mutation propose(client: clients, language: enum('de', 'fr'), source: text 1..120, translation: text 1..160, usageNote: text 1..1200):
  s = seats[principal = viewer] ! else NO_ROLE
  require s.role = 'translator' else TRANSLATOR_ONLY
  require exists memberships[client, viewer] else CLIENT_PRIVATE
  c = clients[client] ! else NOT_FOUND
  return insert terms { client, language, source, translation, usageNote, proposer: viewer }

mutation review(term: terms, decision: enum('approved', 'rejected'), note: text 1..600):
  s = seats[principal = viewer] ! else NO_ROLE
  require s.role = 'reviewer' else REVIEWER_ONLY
  t = terms[term] ! else NOT_FOUND
  require t.language = s.language else WRONG_LANGUAGE
  require t.state = 'pending' else ALREADY_DECIDED
  update terms[term] { state: decision, reviewer: viewer, reviewNote: note, decidedAt: now }

mutation retire(term: terms):
  s = seats[principal = viewer] ! else NO_ROLE
  require s.role = 'manager' else MANAGER_ONLY
  t = terms[term] ! else NOT_FOUND
  require t.state = 'approved' else NOT_APPROVED
  update terms[term] { state: 'retired', retiredBy: viewer, retiredAt: now }

query clientDocuments(client: clients, c: cursor ?):
  require exists memberships[client, viewer] else CLIENT_PRIVATE
  return documents where .client = client last 100 by .uploadedAt after c

query document(document: documents):
  return documents[document]

mutation addDocument(client: clients, title: text 1..120, document: file <=5000000 ('application/pdf', 'text/plain')):
  s = seats[principal = viewer] ! else NO_ROLE
  require s.role != 'client' else READ_ONLY
  require exists memberships[client, viewer] else CLIENT_PRIVATE
  c = clients[client] ! else NOT_FOUND
  return insert documents { client, title, document, uploader: viewer }
