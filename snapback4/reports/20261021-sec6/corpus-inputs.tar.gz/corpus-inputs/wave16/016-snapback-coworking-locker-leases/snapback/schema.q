use identity password

table roles:
  principal: principal
  role: enum('front_desk', 'community_manager')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- deny
  online only

table lockers:
  label: text 2..8
  zone: enum('North', 'South')
  size: enum('Standard', 'Large')
  occupied: bool default false
  unique label
  read <- allow
  insert <- viewer = 'service:ops'
  update <- allow
  online only

table leases:
  owner: principal
  locker: lockers
  startedAt: time
  endAt: time
  releaseAt: time
  accessCode: int 10000000..99999999
  feeCents: int 0..1000000
  status: enum('active', 'expired', 'evicted') default 'active'
  endedAt: time ?
  evictionReason: text 5..500 ?
  evictionActor: principal ?
  waiverReason: text 5..500 ?
  waiverActor: principal ?
  immutable owner, locker, startedAt
  read <- .owner = viewer or exists roles[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer or exists roles[viewer]
  online only

table memberSlots:
  owner: principal
  active: bool
  unique owner
  immutable owner
  read <- .owner = viewer or exists roles[viewer]
  insert <- .owner = viewer
  update <- .owner = viewer or exists roles[viewer]
  online only

table contents:
  lease: leases
  staff: principal
  note: text 5..1000
  photo: image <=5000000
  at: time default now
  unique lease
  immutable lease, staff, note, photo, at
  read <- exists roles[viewer]
  insert <- exists roles[viewer] and .staff = viewer
  online only

fn nextMonth(t: time):
  m = month(t)
  offset = day(t) - day(monthStart(m))
  daysNext = day(monthStart(m + 2)) - day(monthStart(m + 1))
  return monthStart(m + 1) + min(offset, daysNext - 1) * 1d

query me():
  r = roles[principal = viewer]
  return { principal: viewer, role: r.role if r != null else 'member', now: now }

query floorPlan():
  return lockers first 100 by .label { id, label, zone, size, occupied }

query myLeases(c: cursor ?):
  return leases where .owner = viewer last 30 by .startedAt after c

query leaseDetail(lease: leases):
  return leases[lease] ! else NOT_FOUND

query staffLeases(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return leases last 30 by .startedAt after c

query contentsLog(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return contents last 30 by .at after c

mutation provisionRole(principal: principal, role: enum('front_desk', 'community_manager')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert roles { principal, role }

mutation provisionLocker(label: text 2..8, zone: enum('North', 'South'), size: enum('Standard', 'Large')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert lockers { label, zone, size }

mutation requestLocker(locker: lockers, accessCode: int 10000000..99999999):
  require not exists roles[viewer] else MEMBERS_ONLY
  l = lockers[locker] ! else NOT_FOUND
  require not l.occupied else LOCKER_TAKEN
  s = memberSlots[owner = viewer]
  require s = null or not s.active else ALREADY_LEASING
  endAt = nextMonth(day(now) * 1d)
  lease = insert leases { owner: viewer, locker, startedAt: now, endAt, releaseAt: endAt + 6h, accessCode, feeCents: 2500 }
  upsert memberSlots[owner = viewer] { owner: viewer, active: true }
  update lockers[locker] { occupied: true }
  return lease

mutation renewLease(lease: leases):
  l = leases[lease] ! else NOT_FOUND
  require l.owner = viewer else NOT_OWNER
  require l.status = 'active' else LEASE_CLOSED
  require now < l.endAt else RENEWAL_CLOSED
  endAt = nextMonth(l.endAt)
  update leases[lease] { endAt, releaseAt: endAt + 6h, feeCents: l.feeCents + 2500 }

mutation resetCode(lease: leases, accessCode: int 10000000..99999999):
  require exists roles[viewer] else NOT_STAFF
  l = leases[lease] ! else NOT_FOUND
  require l.status = 'active' and now < l.releaseAt else LEASE_CLOSED
  require accessCode != l.accessCode else CODE_UNCHANGED
  update leases[lease] { accessCode }

mutation waiveFee(lease: leases, reason: text 5..500):
  require exists roles[viewer, role = 'community_manager'] else MANAGER_ONLY
  require len(trim(reason)) >= 5 else REASON_REQUIRED
  l = leases[lease] ! else NOT_FOUND
  require l.feeCents > 0 else NO_FEE
  update leases[lease] { feeCents: 0, waiverReason: trim(reason), waiverActor: viewer }

mutation evictEarly(lease: leases, reason: text 5..500):
  require exists roles[viewer, role = 'community_manager'] else MANAGER_ONLY
  require len(trim(reason)) >= 5 else REASON_REQUIRED
  l = leases[lease] ! else NOT_FOUND
  require l.status = 'active' and now < l.endAt else LEASE_CLOSED
  update leases[lease] { status: 'evicted', endedAt: now, evictionReason: trim(reason), evictionActor: viewer }
  update lockers[l.locker] { occupied: false }
  update memberSlots[owner = l.owner] { active: false }

mutation logContents(lease: leases, note: text 5..1000, photo: image <=5000000):
  require exists roles[viewer] else NOT_STAFF
  require len(trim(note)) >= 5 else CONTENTS_REQUIRED
  l = leases[lease] ! else NOT_FOUND
  require l.status != 'active' else NOT_RELEASED
  return insert contents { lease, staff: viewer, note: trim(note), photo }

job releaseExpired(periodStart: time, periodEnd: time):
  for l in leases:
    if l.status = 'active' and l.releaseAt <= periodEnd:
      update leases[l.id] { status: 'expired', endedAt: periodEnd }
      update lockers[l.locker] { occupied: false }
      update memberSlots[owner = l.owner] { active: false }

schedule morningRelease every 1d at 06:00: releaseExpired
