use identity password

-- School calendar is UTC (Iceland). All deadlines are server checked.
table accounts:
  principal: principal
  role: enum('parent', 'driver', 'office', 'coordinator', 'principal')
  school: text 1..60
  name: text 1..80
  unique principal
  read <- .principal = viewer or viewer = 'service:provisioner'
  insert <- viewer = 'service:provisioner'
  online only

table routes:
  school: text 1..60
  name: text 1..60
  driver: principal
  read <- exists accounts[viewer] or viewer = 'service:provisioner'
  insert <- viewer = 'service:provisioner'
  online only

table children:
  name: text 1..80
  parent: principal
  school: text 1..60
  route: routes
  immutable name, parent, school
  read <- .parent = viewer or viewer = 'service:provisioner' or exists accounts[viewer, role = 'coordinator'] or exists accounts[viewer, role = 'office', school = .school]
  insert <- viewer = 'service:provisioner'
  update <- exists accounts[viewer, role = 'coordinator']
  online only

table requests:
  child: children
  parent: principal
  school: text 1..60
  route: routes
  rideDay: int 0..
  reason: text 1..240
  submittedAt: time default now
  unique child, rideDay
  immutable child, parent, school, rideDay, submittedAt
  read <- .parent = viewer or exists accounts[viewer, role = 'coordinator'] or exists accounts[viewer, role = 'office', school = .school]
  insert <- .parent = viewer and exists accounts[viewer, role = 'parent'] and exists children[.child, parent = viewer, school = .school]
  update <- .parent = viewer and exists accounts[viewer, role = 'parent']
  online only

table rides:
  child: children
  childName: text 1..80
  parent: principal
  school: text 1..60
  route: routes
  driver: principal
  rideDay: int 0..
  state: enum('waiting', 'boarded', 'dropped off') default 'waiting'
  changedAt: time default now
  unique child, rideDay
  immutable child, childName, parent, school, rideDay
  read <- .parent = viewer or .driver = viewer or exists accounts[viewer, role = 'coordinator'] or exists accounts[viewer, role = 'office', school = .school]
  insert <- .parent = viewer or exists accounts[viewer, role = 'coordinator']
  update <- .parent = viewer or .driver = viewer or exists accounts[viewer, role = 'coordinator']
  online only

table incidents:
  school: text 1..60
  route: routes
  note: text 1..500
  photo: image <=5000000
  at: time default now
  read <- exists accounts[viewer, role = 'coordinator'] or exists accounts[viewer, role = 'principal', school = .school]
  insert <- exists accounts[viewer, role = 'coordinator']
  online only

mutation provisionAccount(principal: principal, role: enum('parent', 'driver', 'office', 'coordinator', 'principal'), school: text 1..60, name: text 1..80):
  require viewer = 'service:provisioner' else FORBIDDEN
  return insert accounts { principal, role, school, name }
mutation provisionRoute(school: text 1..60, name: text 1..60, driver: principal):
  require viewer = 'service:provisioner' else FORBIDDEN
  require exists accounts[driver, role = 'driver'] else NOT_DRIVER
  return insert routes { school, name, driver }
mutation provisionChild(name: text 1..80, parent: principal, route: routes):
  require viewer = 'service:provisioner' else FORBIDDEN
  r = routes[route] ! else NOT_FOUND
  require exists accounts[parent, role = 'parent', school = r.school] else NOT_PARENT
  return insert children { name, parent, route, school: r.school }

query me():
  return accounts[viewer]
query calendar():
  return { today: day(now), serverTime: now, noon: day(now) * 1d + 12h }
query routeList(c: cursor ?):
  return routes first 100 by .id after c
query childList(c: cursor ?):
  a = accounts[viewer] ! else FORBIDDEN
  if a.role = 'coordinator':
    return children first 100 by .id after c
  if a.role = 'office':
    return children where .school = a.school first 100 by .id after c
  return children where .parent = viewer first 100 by .id after c
query childById(child: children):
  return children[child]
query requestList(c: cursor ?):
  a = accounts[viewer] ! else FORBIDDEN
  if a.role = 'coordinator':
    return requests last 100 by .submittedAt after c
  if a.role = 'office':
    return requests where .school = a.school last 100 by .submittedAt after c
  return requests where .parent = viewer last 100 by .submittedAt after c
query requestById(request: requests):
  return requests[request]
query roster(rideDay: int 0.., c: cursor ?):
  a = accounts[viewer] ! else FORBIDDEN
  if a.role = 'coordinator':
    return rides where .rideDay = rideDay first 100 by .id after c
  if a.role = 'office':
    return rides where .school = a.school and .rideDay = rideDay first 100 by .id after c
  if a.role = 'driver':
    return rides where .driver = viewer and .rideDay = rideDay first 100 by .id after c
  return rides where .parent = viewer and .rideDay = rideDay first 100 by .id after c
query rideById(ride: rides):
  return rides[ride]
query incidentList(c: cursor ?):
  a = accounts[viewer] ! else FORBIDDEN
  if a.role = 'coordinator':
    return incidents last 100 by .at after c
  return incidents where .school = a.school last 100 by .at after c
query incidentById(incident: incidents):
  return incidents[incident]

mutation requestChange(child: children, route: routes, rideDay: int 0.., reason: text 1..240):
  a = accounts[viewer] ! else FORBIDDEN
  require a.role = 'parent' else FORBIDDEN
  ch = children[child] ! else NOT_FOUND
  require ch.parent = viewer else FORBIDDEN
  r = routes[route] ! else NOT_FOUND
  require r.school = ch.school else WRONG_SCHOOL
  require rideDay >= day(now) and rideDay <= day(now) + 14 else BAD_DAY
  require now < rideDay * 1d + 12h else DEADLINE 'Changes close at noon UTC for that afternoon.'
  existing = rides[child, rideDay]
  require existing = null or existing.state = 'waiting' else RIDE_STARTED
  req = upsert requests[child, rideDay] { child, parent: viewer, school: ch.school, route, rideDay, reason }
  upsert rides[child, rideDay] { child, childName: ch.name, parent: viewer, school: ch.school, route, driver: r.driver, rideDay, changedAt: now }
  return req

mutation publishRoster(child: children, rideDay: int 0..):
  require exists accounts[viewer, role = 'coordinator'] else FORBIDDEN
  require rideDay >= day(now) and rideDay <= day(now) + 14 else BAD_DAY
  ch = children[child] ! else NOT_FOUND
  req = requests[ch.id, rideDay]
  selected = req.route if req != null else ch.route
  r = routes[selected] ! else NOT_FOUND
  old = rides[ch.id, rideDay]
  if old = null or old.state = 'waiting':
    upsert rides[ch.id, rideDay] { child: ch.id, childName: ch.name, parent: ch.parent, school: ch.school, route: r.id, driver: r.driver, rideDay, changedAt: now }
  return null

mutation setPermanent(child: children, route: routes):
  require exists accounts[viewer, role = 'coordinator'] else FORBIDDEN
  ch = children[child] ! else NOT_FOUND
  r = routes[route] ! else NOT_FOUND
  require r.school = ch.school else WRONG_SCHOOL
  update children[child] { route }
  return null

mutation markRide(ride: rides, state: enum('boarded', 'dropped off')):
  require exists accounts[viewer, role = 'driver'] else FORBIDDEN
  trip = rides[ride] ! else NOT_FOUND
  require trip.driver = viewer else FORBIDDEN
  require trip.rideDay = day(now) else WRONG_DAY
  require (trip.state = 'waiting' and state = 'boarded') or (trip.state = 'boarded' and state = 'dropped off') else BAD_TRANSITION
  update rides[ride] { state, changedAt: now }
  return null

mutation reportIncident(route: routes, note: text 1..500, photo: image <=5000000):
  require exists accounts[viewer, role = 'coordinator'] else FORBIDDEN
  r = routes[route] ! else NOT_FOUND
  return insert incidents { school: r.school, route, note, photo }
