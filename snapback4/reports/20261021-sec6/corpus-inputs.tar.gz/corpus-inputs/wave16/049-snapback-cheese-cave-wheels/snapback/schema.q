use identity password

table roster:
  principal: principal
  name: text 1..80
  role: enum('head', 'staff', 'sales', 'buyer')
  cave: enum('north', 'south')
  unique principal
  immutable principal, name, role, cave
  read <- .principal = viewer or exists roster[principal = viewer, role = 'head']
  insert <- viewer = 'service:provisioner'
  online only

table buyers:
  principal: principal
  name: text 1..80
  unique principal
  immutable principal, name
  read <- .principal = viewer or exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'sales']
  insert <- viewer = 'service:provisioner'
  online only

table wheels:
  label: text 1..80
  cave: enum('north', 'south')
  grams: int 100..50000
  startedAt: time
  releaseAt: time
  turnHours: int 1..168
  lastTurnAt: time
  state: enum('aging', 'released', 'rejected')
  immutable label, cave, grams, startedAt, turnHours
  read <- exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'staff', cave = .cave]
  insert <- exists roster[principal = viewer, role = 'head']
  update <- exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'staff', cave = .cave]
  online only

table history:
  wheel: wheels
  actor: principal ?
  kind: enum('created', 'turned', 'brushed', 'photo', 'extended', 'rejected', 'released')
  reason: text 1..500
  at: time
  immutable wheel, actor, kind, reason, at
  read <- exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'staff', cave = .wheel.cave]
  insert <- .actor = viewer and (exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'staff', cave = .wheel.cave])
  online only

table photos:
  wheel: wheels
  actor: principal
  week: int 0..
  at: time
  photo: image <=5000000
  unique wheel, week else WEEKLY_PHOTO_EXISTS
  immutable wheel, actor, week, at, photo
  read <- exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'staff', cave = .wheel.cave]
  insert <- .actor = viewer and (exists roster[principal = viewer, role = 'head'] or exists roster[principal = viewer, role = 'staff', cave = .wheel.cave])
  online only

table released:
  wheel: wheels
  label: text 1..80
  grams: int 100..50000
  releasedAt: time
  buyer: principal ?
  unique wheel
  immutable wheel, label, grams, releasedAt
  read <- .buyer = viewer or exists roster[principal = viewer, role = 'sales'] or exists roster[principal = viewer, role = 'head']
  update <- exists roster[principal = viewer, role = 'sales'] or exists roster[principal = viewer, role = 'head']
  delete <- exists roster[principal = viewer, role = 'head']
  online only

mutation provision(principal: principal, name: text 1..80, role: enum('head', 'staff', 'sales', 'buyer'), cave: enum('north', 'south')):
  require viewer = 'service:provisioner' else FORBIDDEN
  insert roster { principal, name, role, cave }
  if role = 'buyer':
    insert buyers { principal, name }
  return null

query me():
  return roster[principal = viewer]

query wheelList():
  return wheels first 200 by .id { id, label, cave, grams, startedAt, releaseAt, turnHours, lastTurnAt, state, overdue: .state = 'aging' and now < .releaseAt and now > .lastTurnAt + .turnHours * 1h, photoDue: .state = 'aging' and not exists photos[.id, (now - .startedAt) / 7d] }

query wheelDetail(wheel: wheels):
  return wheels[wheel]

query wheelHistory(wheel: wheels):
  require exists wheels[wheel] else NOT_FOUND
  return history where .wheel = wheel last 200 by .at

query wheelPhotos(wheel: wheels):
  require exists wheels[wheel] else NOT_FOUND
  return photos where .wheel = wheel last 100 by .at

query catalog():
  return released first 200 by .id

query releaseDetail(wheel: wheels):
  return released[wheel = wheel]

query buyerDirectory():
  return buyers first 200 by .id

mutation createWheel(label: text 1..80, cave: enum('north', 'south'), grams: int 100..50000, agingDays: int 1..730, turnHours: int 1..168, startedAt: time ?):
  require exists roster[principal = viewer, role = 'head'] else FORBIDDEN
  entered = startedAt ?? now
  require entered <= now and entered >= now - 730d else INVALID_START_DATE
  w = insert wheels { label, cave, grams, startedAt: entered, releaseAt: entered + agingDays * 1d, turnHours, lastTurnAt: entered, state: 'aging' }
  insert history { wheel: w.id, actor: viewer, kind: 'created', reason: 'Wheel entered the cave', at: now }
  return w

mutation recordCare(wheel: wheels, kind: enum('turned', 'brushed')):
  w = wheels[wheel] ! else NOT_FOUND
  require w.state = 'aging' and now < w.releaseAt else AGING_FINISHED
  if kind = 'turned':
    update wheels[wheel] { lastTurnAt: now }
  return insert history { wheel, actor: viewer, kind, reason: 'Routine cave care', at: now }

mutation recordPhoto(wheel: wheels, photo: image <=5000000):
  w = wheels[wheel] ! else NOT_FOUND
  require w.state = 'aging' and now < w.releaseAt else AGING_FINISHED
  insert photos { wheel, actor: viewer, week: (now - w.startedAt) / 7d, at: now, photo }
  return insert history { wheel, actor: viewer, kind: 'photo', reason: 'Weekly rind photograph', at: now }

mutation extendAging(wheel: wheels, days: int 1..365, reason: text 1..500):
  require exists roster[principal = viewer, role = 'head'] else FORBIDDEN
  w = wheels[wheel] ! else NOT_FOUND
  require w.state = 'aging' and now < w.releaseAt else AGING_FINISHED
  update wheels[wheel] { releaseAt: w.releaseAt + days * 1d }
  return insert history { wheel, actor: viewer, kind: 'extended', reason, at: now }

mutation rejectWheel(wheel: wheels, reason: text 1..500):
  require exists roster[principal = viewer, role = 'head'] else FORBIDDEN
  w = wheels[wheel] ! else NOT_FOUND
  require w.state != 'rejected' else ALREADY_REJECTED
  update wheels[wheel] { state: 'rejected' }
  if exists released[wheel = wheel]:
    delete released[wheel = wheel]
  return insert history { wheel, actor: viewer, kind: 'rejected', reason, at: now }

mutation reserveWheel(wheel: wheels, buyer: principal):
  require exists roster[principal = viewer, role = 'sales'] or exists roster[principal = viewer, role = 'head'] else FORBIDDEN
  r = released[wheel = wheel] ! else NOT_RELEASED
  require r.buyer = null else ALREADY_RESERVED
  require exists buyers[principal = buyer] else NOT_BUYER
  update released[r.id] { buyer }
  return null

job ageWheels():
  for w in wheels:
    if w.state = 'aging' and w.releaseAt <= now:
      update wheels[w.id] { state: 'released' }
      insert released { wheel: w.id, label: w.label, grams: w.grams, releasedAt: w.releaseAt, buyer: null }
      insert history { wheel: w.id, actor: null, kind: 'released', reason: 'Aging complete; automatically released', at: now }
schedule aging every 1m: ageWheels
