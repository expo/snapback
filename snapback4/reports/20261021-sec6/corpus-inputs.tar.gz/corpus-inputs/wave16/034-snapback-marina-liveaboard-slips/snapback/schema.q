-- Marina Liveaboard Slips.
-- Roles: slip_holder (own slip/bills/documents/applications only),
-- dockhand (slip map + occupancy, log arrival/departure),
-- harbormaster (manage slips, bills, approve/revoke liveaboard with reason).
-- Auth: real password accounts only; no personas/dev cast.

use identity password

table roles:
  principal: principal
  role: enum('slip_holder', 'dockhand', 'harbormaster')
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'harbormaster']
  insert <- exists roles[viewer, role = 'harbormaster'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'harbormaster'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'harbormaster'] or viewer = 'service:ops'
  online only

table slips:
  slipNumber: text 1..20
  dock: text 1..40
  liveaboardEligible: bool
  holder: principal ?
  occupied: bool default false
  liveaboardActive: bool default false
  unique slipNumber
  immutable slipNumber
  cap 500
  read <- .holder = viewer or exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster']
  insert <- exists roles[viewer, role = 'harbormaster']
  update <- exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster']
  delete <- exists roles[viewer, role = 'harbormaster']
  online only

table applications:
  applicant: principal
  slip: slips
  insurance: file <=5000000
  pumpout: file <=5000000
  insuranceExpiresAt: time
  status: enum('pending', 'approved', 'revoked', 'expired') default 'pending'
  reason: text 1..500 ?
  createdAt: time default now
  unique slip, applicant else ALREADY_APPLIED
  immutable applicant, slip, insurance, pumpout, insuranceExpiresAt
  cap 20 by applicant
  read <- .applicant = viewer or exists roles[viewer, role = 'harbormaster']
  insert <- .applicant = viewer
  update <- .applicant = viewer or exists roles[viewer, role = 'harbormaster']
  online only

table bills:
  slip: slips
  owner: principal
  amount: money USD
  dueAt: time
  paid: bool default false
  createdAt: time default now
  immutable slip, owner, amount, dueAt, createdAt
  cap 500 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'harbormaster']
  insert <- exists roles[viewer, role = 'harbormaster']
  update <- .owner = viewer or exists roles[viewer, role = 'harbormaster']
  online only

table documents:
  owner: principal
  title: text 1..120
  attachment: file <=10000000
  uploadedAt: time default now
  immutable owner, uploadedAt
  cap 100 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'harbormaster']
  insert <- .owner = viewer
  delete <- .owner = viewer or exists roles[viewer, role = 'harbormaster']
  online only

table movements:
  slip: slips
  event: enum('arrival', 'departure')
  at: time default now
  loggedBy: principal
  immutable slip, event, at, loggedBy
  cap 2000 by slip
  read <- .loggedBy = viewer or exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster']
  insert <- exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster']
  online only

query myRole():
  return roles[principal = viewer]

query mySlip(c: cursor ?):
  return slips where .holder = viewer last 20 by .id after c

query slipMap(c: cursor ?):
  require exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster'] else NOT_DOCKHAND
  return slips last 50 by .id after c

query myBills(c: cursor ?):
  return bills where .owner = viewer last 50 by .dueAt after c

query myDocuments(c: cursor ?):
  return documents where .owner = viewer last 50 by .uploadedAt after c

query myApplications(c: cursor ?):
  return applications where .applicant = viewer last 50 by .createdAt after c

query allApplications(c: cursor ?):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  return applications last 50 by .createdAt after c

query allBills(c: cursor ?):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  return bills last 50 by .dueAt after c

query movementsFor(slip: slips, c: cursor ?):
  require exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster'] else NOT_DOCKHAND
  return movements where .slip = slip last 50 by .at after c

mutation grantRole(who: principal, role: enum('slip_holder', 'dockhand', 'harbormaster')):
  require exists roles[viewer, role = 'harbormaster'] or viewer = 'service:ops' else NOT_HARBORMASTER
  return upsert roles[who] { role }

mutation addSlip(slipNumber: text 1..20, dock: text 1..40, liveaboardEligible: bool):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  return insert slips { slipNumber, dock, liveaboardEligible, occupied: false, liveaboardActive: false }

mutation assignSlip(slip: slips, holder: principal):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  s = slips[slip] ! else NOT_FOUND
  update slips[slip] { holder }
  return null

mutation applyLiveaboard(slip: slips, insurance: file <=5000000, pumpout: file <=5000000, insuranceExpiresAt: time):
  require insuranceExpiresAt > now else EXPIRED_INSURANCE
  s = slips[slip] ! else NOT_FOUND
  require s.holder = viewer else NOT_YOUR_SLIP
  require s.liveaboardEligible else NOT_LIVEABOARD_SLIP
  require not exists applications[slip, viewer] else ALREADY_APPLIED
  return insert applications { applicant: viewer, slip, insurance, pumpout, insuranceExpiresAt }

mutation approveLiveaboard(application: applications):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  a = applications[application] ! else NOT_FOUND
  require a.status = 'pending' else NOT_PENDING
  require a.insuranceExpiresAt > now else INSURANCE_EXPIRED
  update applications[application] { status: 'approved' }
  update slips[a.slip] { liveaboardActive: true }
  return null

mutation revokeLiveaboard(application: applications, reason: text 1..500):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  a = applications[application] ! else NOT_FOUND
  require a.status = 'approved' else NOT_APPROVED
  update applications[application] { status: 'revoked', reason }
  update slips[a.slip] { liveaboardActive: false }
  return null

mutation logArrival(slip: slips):
  require exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster'] else NOT_DOCKHAND
  s = slips[slip] ! else NOT_FOUND
  require not s.occupied else ALREADY_OCCUPIED
  insert movements { slip, event: 'arrival', loggedBy: viewer }
  update slips[slip] { occupied: true }
  return null

mutation logDeparture(slip: slips):
  require exists roles[viewer, role = 'dockhand'] or exists roles[viewer, role = 'harbormaster'] else NOT_DOCKHAND
  s = slips[slip] ! else NOT_FOUND
  require s.occupied else NOT_OCCUPIED
  insert movements { slip, event: 'departure', loggedBy: viewer }
  update slips[slip] { occupied: false }
  return null

mutation createBill(slip: slips, owner: principal, amount: money USD, dueAt: time):
  require exists roles[viewer, role = 'harbormaster'] else NOT_HARBORMASTER
  s = slips[slip] ! else NOT_FOUND
  require s.holder = owner else NOT_HOLDER
  require dueAt > now else BAD_DUE_DATE
  return insert bills { slip, owner, amount, dueAt }

mutation payBill(bill: bills):
  b = bills[bill] ! else NOT_FOUND
  require not b.paid else ALREADY_PAID
  update bills[bill] { paid: true }
  return null

mutation placeDocument(title: text 1..120, attachment: file <=10000000):
  return insert documents { owner: viewer, title, attachment }

mutation deleteDocument(document: documents):
  delete documents[document]
  return null

job lapseExpired(periodStart: time, periodEnd: time):
  for a in applications where .insuranceExpiresAt < periodEnd by .insuranceExpiresAt:
    if a.status = 'approved':
      update applications[a.id] { status: 'expired' }
      update slips[a.slip] { liveaboardActive: false }

schedule lapseCheck every 1m: lapseExpired
