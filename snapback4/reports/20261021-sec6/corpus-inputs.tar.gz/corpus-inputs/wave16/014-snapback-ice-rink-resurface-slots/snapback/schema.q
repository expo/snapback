use identity password

table accounts:
  principal: principal
  name: text 1..80
  role: enum('club_manager', 'coach', 'public', 'rink_operator', 'facility_manager')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:provision'
  insert <- viewer = 'service:provision' or (.principal = viewer and .role = 'public')
  update <- viewer = 'service:provision'
  online only

table bookings:
  owner: principal
  title: text 1..100
  kind: enum('club', 'lesson', 'public', 'maintenance')
  startsAt: time
  endsAt: time
  expiresAt: time ?
  paid: bool default false
  immutable owner, title, kind, startsAt, endsAt
  read <- .owner = viewer or (exists accounts[viewer, role = 'facility_manager'] and (.kind = 'maintenance' or .kind = 'public'))
  insert <- .owner = viewer and ((.kind = 'club' and exists accounts[viewer, role = 'club_manager']) or (.kind = 'lesson' and exists accounts[viewer, role = 'coach']) or ((.kind = 'public' or .kind = 'maintenance') and exists accounts[viewer, role = 'facility_manager']))
  update <- .owner = viewer
  delete <- .owner = viewer or (exists accounts[viewer, role = 'facility_manager'] and (.kind = 'maintenance' or .kind = 'public'))
  expire at .expiresAt
  online only

table occupancy:
  booking: bookings on delete cascade
  owner: principal
  tick: int
  expiresAt: time ?
  unique tick
  immutable booking, owner, tick
  read <- .owner = viewer
  insert <- .owner = viewer and .booking.owner = viewer
  update <- .owner = viewer
  cap 100 by booking
  expire at .expiresAt
  online only
view occupied: count occupancy by .tick
  read <- allow

table invoices:
  booking: bookings on delete cascade
  owner: principal
  amountCents: int 1..1000000
  paid: bool default false
  expiresAt: time ?
  unique booking
  immutable booking, owner, amountCents
  read <- .owner = viewer
  insert <- .owner = viewer and .booking.owner = viewer
  update <- .owner = viewer
  expire at .expiresAt
  online only

table students:
  booking: bookings on delete cascade
  owner: principal
  name: text 1..80
  contact: text 3..120
  immutable booking, owner
  read <- .owner = viewer
  insert <- .owner = viewer and .booking.owner = viewer and .booking.kind = 'lesson'
  delete <- .owner = viewer
  cap 30 by booking
  online only

table publicSessions:
  booking: bookings on delete cascade
  title: text 1..100
  startsAt: time
  endsAt: time
  closesAt: time
  unique booking
  immutable booking, title, startsAt, endsAt, closesAt
  public 'Only published open public skating sessions; no renter or student details.'
  insert <- exists accounts[viewer, role = 'facility_manager'] and .booking.owner = viewer and .booking.kind = 'public'
  expire at .closesAt
  online only

table resurfaces:
  operator: principal
  at: time
  northMm: int 20..80
  centreMm: int 20..80
  southMm: int 20..80
  notes: text 1..500
  immutable operator, at, northMm, centreMm, southMm, notes
  read <- .operator = viewer or exists accounts[viewer, role = 'facility_manager']
  insert <- .operator = viewer and exists accounts[viewer, role = 'rink_operator']
  online only

mutation provision(principal: principal, name: text 1..80, role: enum('club_manager', 'coach', 'public', 'rink_operator', 'facility_manager')):
  require viewer = 'service:provision' else PROVISIONER_ONLY
  return upsert accounts[principal = principal] { principal, name, role }

mutation join(name: text 1..80):
  require not exists accounts[viewer] else ALREADY_ENROLLED
  return insert accounts { principal: viewer, name, role: 'public' }

query me():
  return accounts[viewer]

fn reserve(title: text 1..100, kind: enum('club', 'lesson', 'public', 'maintenance'), startsAt: time, endsAt: time, expiresAt: time ?):
  require startsAt % 15m = 0 and endsAt % 15m = 0 else QUARTER_HOUR 'Use 15-minute boundaries in UTC.'
  require startsAt > now and startsAt <= now + 365d else BAD_START 'Choose a future date within a year.'
  require endsAt > startsAt and endsAt <= startsAt + 24h else BAD_DURATION
  firstTick = startsAt / 15m
  lastTick = endsAt / 15m
  for t in range(firstTick, lastTick + 1):
    require occupied[t] = 0 else ICE_BUSY 'Ice is occupied, including its 15-minute resurfacing gap.'
  b = insert bookings { owner: viewer, title, kind, startsAt, endsAt, expiresAt, paid: expiresAt = null }
  for t in range(firstTick, lastTick + 1):
    insert occupancy { booking: b.id, owner: viewer, tick: t, expiresAt }
  return b

mutation bookIce(title: text 1..100, startsAt: time, endsAt: time): server
  require exists accounts[viewer, role = 'club_manager'] or exists accounts[viewer, role = 'coach'] else RENTER_ONLY
  require startsAt > now + 72h else PAYMENT_DEADLINE 'Unpaid bookings must be made more than 72 hours ahead.'
  require endsAt >= startsAt + 30m and endsAt <= startsAt + 4h else BAD_DURATION 'Rentals last 30 minutes to four hours.'
  kind = 'club' if exists accounts[viewer, role = 'club_manager'] else 'lesson'
  b = reserve(title, kind, startsAt, endsAt, startsAt - 72h)
  insert invoices { booking: b.id, owner: viewer, amountCents: (endsAt - startsAt) / 15m * 3000, expiresAt: b.expiresAt }
  return b

mutation publishSession(title: text 1..100, startsAt: time, endsAt: time): server
  require exists accounts[viewer, role = 'facility_manager'] else FACILITY_ONLY
  require endsAt >= startsAt + 30m and endsAt <= startsAt + 4h else BAD_DURATION
  b = reserve(title, 'public', startsAt, endsAt, null)
  insert publicSessions { booking: b.id, title, startsAt, endsAt, closesAt: startsAt }
  return b

mutation blockMaintenance(title: text 1..100, startsAt: time, endsAt: time): server
  require exists accounts[viewer, role = 'facility_manager'] else FACILITY_ONLY
  return reserve(title, 'maintenance', startsAt, endsAt, null)

query myBookings(c: cursor ?):
  require exists accounts[viewer] else ENROL_FIRST
  return bookings where .owner = viewer first 100 by .startsAt after c

query booking(booking: bookings):
  return bookings[booking] ! else NOT_FOUND

query maintenance(c: cursor ?):
  require exists accounts[viewer, role = 'facility_manager'] else FACILITY_ONLY
  return bookings where .kind = 'maintenance' first 100 by .startsAt after c

mutation cancelBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.startsAt > now else STARTED 'Started bookings cannot be cancelled.'
  delete bookings[booking]
  return null

query myInvoices(c: cursor ?):
  require exists accounts[viewer, role = 'club_manager'] or exists accounts[viewer, role = 'coach'] else RENTER_ONLY
  return invoices where .owner = viewer first 100 by .id after c

query invoice(invoice: invoices):
  return invoices[invoice] ! else NOT_FOUND

mutation payInvoice(invoice: invoices): server
  require exists accounts[viewer, role = 'club_manager'] or exists accounts[viewer, role = 'coach'] else RENTER_ONLY
  i = invoices[invoice] ! else NOT_FOUND
  b = bookings[i.booking] ! else NOT_FOUND
  require b.owner = viewer else OWNER_ONLY
  require not i.paid else ALREADY_PAID
  require b.startsAt > now + 72h else PAYMENT_DEADLINE
  cells = occupancy where .owner = viewer and .booking = b.id first 100 by .id
  for cell in cells:
    update occupancy[cell.id] { expiresAt: null }
  update bookings[b.id] { expiresAt: null, paid: true }
  update invoices[invoice] { expiresAt: null, paid: true }
  return null

query roster(booking: bookings, c: cursor ?):
  require exists accounts[viewer, role = 'coach'] else COACH_ONLY
  b = bookings[booking] ! else NOT_FOUND
  require b.owner = viewer and b.kind = 'lesson' else OWNER_ONLY
  return students where .owner = viewer and .booking = booking first 30 by .id after c

mutation addStudent(booking: bookings, name: text 1..80, contact: text 3..120):
  require exists accounts[viewer, role = 'coach'] else COACH_ONLY
  b = bookings[booking] ! else NOT_FOUND
  require b.owner = viewer and b.kind = 'lesson' else OWNER_ONLY
  require b.startsAt > now else STARTED
  return insert students { booking, owner: viewer, name, contact }

mutation removeStudent(student: students):
  require exists accounts[viewer, role = 'coach'] else COACH_ONLY
  s = students[student] ! else NOT_FOUND
  b = bookings[s.booking] ! else NOT_FOUND
  require b.owner = viewer and b.startsAt > now else STARTED
  delete students[student]
  return null

query openSessions(c: cursor ?):
  return publicSessions where .startsAt > now first 100 by .startsAt after c { id, title, startsAt, endsAt }

mutation logResurface(northMm: int 20..80, centreMm: int 20..80, southMm: int 20..80, notes: text 1..500):
  require exists accounts[viewer, role = 'rink_operator'] else OPERATOR_ONLY
  return insert resurfaces { operator: viewer, at: now, northMm, centreMm, southMm, notes }

query resurfaceLogs(c: cursor ?):
  require exists accounts[viewer, role = 'rink_operator'] or exists accounts[viewer, role = 'facility_manager'] else STAFF_ONLY
  if exists accounts[viewer, role = 'facility_manager']:
    return resurfaces last 100 by .at after c
  return resurfaces where .operator = viewer last 100 by .at after c

query resurface(log: resurfaces):
  return resurfaces[log] ! else NOT_FOUND
