use identity password

-- Only a local operator service seat can enroll staff. Signup grants no staff rights.
table people:
  principal: principal
  name: text 2..60
  role: enum('client', 'guide', 'operations')
  firstDay: time ?
  unique principal
  immutable principal, role, name
  read <- .principal = viewer or exists people[viewer, role = 'operations'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops' or (.principal = viewer and .role = 'client')
  update <- .principal = viewer
  online only

table courses:
  title: text 3..100
  startsAt: time
  endsAt: time
  lead: principal
  status: enum('scheduled', 'cancelled') default 'scheduled'
  weatherReason: text <=300 default ''
  immutable title, startsAt, endsAt, lead
  read <- allow
  insert <- exists people[viewer, role = 'operations']
  update <- exists people[viewer, role = 'operations']
  online only

table bookings:
  course: courses
  client: principal
  clientName: text 2..60
  guide: principal
  at: time default now
  unique course, client else ALREADY_BOOKED
  immutable course, client, clientName, guide, at
  read <- .client = viewer or .guide = viewer or exists people[viewer, role = 'operations']
  insert <- .client = viewer and exists courses[.course, lead = .guide]
  cap 24 by course
  online only

-- A booking establishes exactly which guide may read this client's private forms.
table medicalAccess:
  owner: principal
  guide: principal
  course: courses
  unique owner, guide
  immutable owner, guide
  read <- .owner = viewer or .guide = viewer
  insert <- .owner = viewer and exists courses[.course, lead = .guide] and exists bookings[.course, .owner]
  update <- .owner = viewer and exists courses[.course, lead = .guide] and exists bookings[.course, .owner]
  online only

table documents:
  owner: principal
  kind: enum('waiver', 'medical')
  scan: file <=5000000 ('application/pdf')
  notes: text <=2000
  signed: bool
  at: time default now
  unique owner, kind
  immutable owner, kind, at
  read <- .owner = viewer or exists medicalAccess[.owner, viewer]
  insert <- .owner = viewer
  online only

table ropeTeams:
  course: courses
  name: text 2..60
  dueAt: time
  checkedAt: time ?
  immutable course, name, dueAt
  read <- exists courses[.course, lead = viewer] or exists placements[.id, viewer] or exists people[viewer, role = 'operations']
  insert <- exists courses[.course, lead = viewer]
  update <- exists courses[.course, lead = viewer]
  cap 12 by course
  online only

table placements:
  team: ropeTeams
  course: courses
  client: principal
  clientName: text 2..60
  unique course, client else ALREADY_ON_ROPE
  unique team, client
  immutable team, course, client, clientName
  read <- .client = viewer or exists placements[.team, viewer] or exists courses[.course, lead = viewer] or exists people[viewer, role = 'operations']
  insert <- exists courses[.course, lead = viewer] and exists ropeTeams[.team, course = .course]
  cap 6 by team
  online only

-- A readable timer owns the timed alert. Clearing the timer atomically
-- cascades its alert even before that alert's disclosure boundary.
table radioTimers:
  team: ropeTeams
  course: courses
  unique team
  immutable team, course
  read <- exists courses[.course, lead = viewer] or exists people[viewer, role = 'operations']
  insert <- exists courses[.course, lead = viewer]
  delete <- exists courses[.course, lead = viewer] or exists people[viewer, role = 'operations']
  cap 12 by course
  online only

-- Timed disclosure publishes one alert to all guides at exactly dueAt + 30m.
-- No medical data or client identity enters the company-wide alert board.
table alerts:
  timer: radioTimers on delete cascade
  team: ropeTeams
  courseName: text 3..100
  teamName: text 2..60
  dueAt: time
  opensAt: time
  unique team
  immutable timer, team, courseName, teamName, dueAt, opensAt
  by byOpening: opensAt
  not before .opensAt
  read <- exists people[viewer, role = 'guide']
  insert <- exists ropeTeams[.team] and exists radioTimers[.timer, team = .team]
  cap 1 by timer
  online only

mutation enroll(principal: principal, name: text 2..60, role: enum('client', 'guide', 'operations')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert people { principal, name, role, firstDay: null }

mutation registerClient(name: text 2..60):
  return insert people { principal: viewer, name, role: 'client', firstDay: null }

query me():
  return people[principal = viewer]

query directory(c: cursor ?):
  require exists people[viewer, role = 'operations'] else OPERATIONS_ONLY
  return people first 100 by .id after c { principal, name, role }

query courseList(c: cursor ?):
  return courses first 100 by .startsAt after c

query bookingList(c: cursor ?):
  return bookings first 100 by .id after c

query bookingById(booking: bookings):
  return bookings[booking]

query documentFor(owner: principal, kind: enum('waiver', 'medical')):
  require owner = viewer or exists medicalAccess[owner, viewer] else DOCUMENT_PRIVATE
  return documents[owner, kind]

query teamList(course: courses, c: cursor ?):
  return ropeTeams where .course = course first 30 by .id after c

query teamById(team: ropeTeams):
  return ropeTeams[team]

query teamMembers(team: ropeTeams, c: cursor ?):
  require exists ropeTeams[team] else TEAM_PRIVATE
  return placements where .team = team first 6 by .id after c

query alertList(c: cursor ?):
  require exists people[viewer, role = 'guide'] else GUIDES_ONLY
  return alerts first 100 by .dueAt after c

mutation createCourse(title: text 3..100, startsAt: time, endsAt: time, lead: principal):
  require exists people[viewer, role = 'operations'] else OPERATIONS_ONLY
  require exists people[lead, role = 'guide'] else NOT_A_GUIDE
  require startsAt > now and endsAt > startsAt and endsAt <= startsAt + 12h else BAD_COURSE_TIME
  return insert courses { title, startsAt, endsAt, lead }

mutation book(course: courses):
  p = people[viewer] ! else REGISTER_FIRST
  require p.role = 'client' else CLIENTS_ONLY
  c = courses[course] ! else NOT_FOUND
  require c.status = 'scheduled' else COURSE_CANCELLED
  require now < c.startsAt else COURSE_STARTED
  b = insert bookings { course, client: viewer, clientName: p.name, guide: c.lead }
  upsert medicalAccess[viewer, c.lead] { owner: viewer, guide: c.lead, course }
  if p.firstDay = null or c.startsAt < p.firstDay:
    update people[p.id] { firstDay: c.startsAt }
  return b

mutation uploadDocument(kind: enum('waiver', 'medical'), scan: file <=5000000 ('application/pdf'), notes: text <=2000, signed: bool):
  p = people[viewer] ! else REGISTER_FIRST
  require p.role = 'client' else CLIENTS_ONLY
  require p.firstDay = null or now < p.firstDay else FIRST_DAY_STARTED
  require signed else SIGNATURE_REQUIRED
  return insert documents { owner: viewer, kind, scan, notes, signed, at: now }

mutation createTeam(course: courses, name: text 2..60, dueAt: time):
  require exists people[viewer, role = 'guide'] else GUIDES_ONLY
  c = courses[course] ! else NOT_FOUND
  require c.lead = viewer else NOT_COURSE_GUIDE
  require c.status = 'scheduled' else COURSE_CANCELLED
  require now < c.endsAt else COURSE_ENDED
  require dueAt >= c.startsAt and dueAt <= c.endsAt and dueAt > now else BAD_CHECKIN_TIME
  t = insert ropeTeams { course, name, dueAt, checkedAt: null }
  timer = insert radioTimers { team: t.id, course }
  insert alerts { timer: timer.id, team: t.id, courseName: c.title, teamName: name, dueAt, opensAt: dueAt + 30m }
  return t

mutation placeClient(team: ropeTeams, client: principal):
  require exists people[viewer, role = 'guide'] else GUIDES_ONLY
  t = ropeTeams[team] ! else TEAM_PRIVATE
  c = courses[t.course] ! else NOT_FOUND
  require c.lead = viewer else NOT_COURSE_GUIDE
  require c.status = 'scheduled' else COURSE_CANCELLED
  require now < c.endsAt else COURSE_ENDED
  b = bookings[t.course, client] ! else NOT_BOOKED
  w = documents[client, 'waiver'] ! else WAIVER_REQUIRED
  m = documents[client, 'medical'] ! else MEDICAL_REQUIRED
  require w.signed and m.signed and w.at < c.startsAt and m.at < c.startsAt else DOCUMENTS_LATE
  return insert placements { team, course: t.course, client, clientName: b.clientName }

mutation radioCheckin(team: ropeTeams):
  require exists people[viewer, role = 'guide'] else GUIDES_ONLY
  t = ropeTeams[team] ! else TEAM_PRIVATE
  c = courses[t.course] ! else NOT_FOUND
  require c.lead = viewer else NOT_COURSE_GUIDE
  require c.status = 'scheduled' else COURSE_CANCELLED
  require now >= c.startsAt else COURSE_NOT_STARTED
  update ropeTeams[team] { checkedAt: now }
  if exists radioTimers[team]:
    delete radioTimers[team]
  return null

mutation cancelForWeather(course: courses, reason: text 5..300):
  require exists people[viewer, role = 'operations'] else OPERATIONS_ONLY
  c = courses[course] ! else NOT_FOUND
  require c.status = 'scheduled' else ALREADY_CANCELLED
  require now < c.endsAt else COURSE_ENDED
  update courses[course] { status: 'cancelled', weatherReason: reason }
  for timer in radioTimers where .course = course:
    delete radioTimers[timer.id]
  return null
