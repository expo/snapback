-- Orchard Spray Re-entry.
-- Roles: applicator, picker, manager, crew_lead, inspector.
-- Real auth: `use identity password`. Personas exist only for local
-- dev/test fixtures; every authorization rule is principal-based so it
-- holds identically for password sessions.
use identity password
use personas t_applicator, t_picker, t_manager, t_lead, t_inspector

-- One roster row per registered user. The first manager is seeded as the
-- system (fixtures / POST /seed on dev, service seat in production);
-- after that managers assign every other role through `grant`.
table roles:
  principal: principal
  role: enum('applicator', 'picker', 'manager', 'crew_lead', 'inspector')
  unique principal
  read <- exists roles[viewer]
  insert <- .principal = viewer or exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager']
  delete <- deny
  online only

-- Private profile: only its owner may read or write it.
table profiles:
  principal: principal
  displayName: text 1..80
  unique principal
  read <- .principal = viewer
  insert <- .principal = viewer or exists roles[viewer, role = 'manager']
  update <- .principal = viewer or exists roles[viewer, role = 'manager']
  delete <- deny
  online only

-- Pesticide catalogue. Only the manager curates it; every registered
-- role may read it (applicators log against it, others see REI data).
table products:
  name: text 1..80
  reiHours: int 1..120
  allowsEarlyEntry: bool
  unique name
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'manager']
  update <- deny
  delete <- deny
  online only

-- Orchard blocks. closedUntil is maintained by logSpray (extend) and
-- shorten (recompute); a block is open when closedUntil <= now, so it
-- reopens on its own with no sweep job.
table blocks:
  name: text 1..80
  closedUntil: time default now
  unique name
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'applicator']
  delete <- deny
  online only

-- One spray record per application. Readable by every registered role
-- (pickers see closures, leads assign, inspectors audit read-only);
-- only applicators log, only managers shorten via earlyEndsAt.
table applications:
  block: blocks
  product: products
  appliedBy: principal
  rate: text 1..60
  labelPhoto: image <=5000000 ?
  appliedAt: time
  reiEndsAt: time
  earlyEndsAt: time ?
  immutable block, product, appliedBy, rate, labelPhoto, appliedAt, reiEndsAt
  cap 500 by block
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'applicator']
  update <- exists roles[viewer, role = 'manager']
  delete <- deny
  online only

-- Picker assignments to blocks. Only crew leads assign, only pickers
-- are assigned, and only to currently open blocks.
table assignments:
  block: blocks
  picker: principal
  assignedBy: principal
  at: time default now
  immutable block, picker, assignedBy
  cap 500 by block
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'crew_lead']
  update <- deny
  delete <- deny
  online only

query whoAmI():
  return viewer

query myRole():
  return roles[principal = viewer]

query myProfile():
  return profiles[principal = viewer]

query profileFor(owner: principal):
  require owner = viewer else PROFILE_PRIVATE
  return profiles[principal = owner]

query roster(c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return roles first 100 by .id after c { principal, role }

query blockList(c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return blocks first 100 by .id after c { id, name, closedUntil }

query productList(c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return products first 100 by .id after c { id, name, reiHours, allowsEarlyEntry }

query applicationsFor(block: blocks, c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return applications where .block = block last 50 by .appliedAt after c { id, block, product, appliedBy, rate, labelPhoto, appliedAt, reiEndsAt, earlyEndsAt }

query assignmentsFor(block: blocks, c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return assignments where .block = block last 50 by .at after c { id, block, picker, assignedBy, at }

query myAssignments(c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return assignments where .picker = viewer last 50 by .at after c { id, block, picker, assignedBy, at }

-- Self-registration for every role except manager (the type itself
-- refuses a manager claim with E_INPUT); managers are granted.
mutation register(displayName: text 1..80, role: enum('applicator', 'picker', 'crew_lead', 'inspector')):
  require not exists roles[principal = viewer] else ALREADY_REGISTERED
  upsert profiles[principal = viewer] { principal: viewer, displayName }
  return insert roles { principal: viewer, role }

mutation grant(who: principal, role: enum('applicator', 'picker', 'manager', 'crew_lead', 'inspector'), displayName: text 1..80):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  upsert profiles[principal = who] { principal: who, displayName }
  return upsert roles[who] { principal: who, role }

mutation addProduct(name: text 1..80, reiHours: int 1..120, allowsEarlyEntry: bool):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return insert products { name, reiHours, allowsEarlyEntry }

mutation addBlock(name: text 1..80):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return insert blocks { name, closedUntil: now }

mutation logSpray(block: blocks, product: products, rate: text 1..60, labelPhoto: image <=5000000 ?, appliedAt: time ?):
  require exists roles[viewer, role = 'applicator'] else NOT_APPLICATOR
  b = blocks[block] ! else NOT_FOUND
  p = products[product] ! else NOT_FOUND
  at = appliedAt ?? now
  require at <= now + 1h else BAD_TIME
  require at >= now - 30d else BAD_TIME
  reiEnd = at + p.reiHours * 1h
  appRow = insert applications { block, product, appliedBy: viewer, rate, labelPhoto, appliedAt: at, reiEndsAt: reiEnd, earlyEndsAt: null }
  newClosed = reiEnd if reiEnd > b.closedUntil else b.closedUntil
  update blocks[block] { closedUntil: newClosed }
  return appRow

mutation shorten(application: applications, newEndsAt: time):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  a = applications[application] ! else NOT_FOUND
  p = products[a.product] ! else NOT_FOUND
  require p.allowsEarlyEntry else NO_EARLY_ENTRY
  current = a.earlyEndsAt ?? a.reiEndsAt
  require newEndsAt >= a.appliedAt else BAD_TIME
  require newEndsAt < current else NOT_SHORTER
  update applications[application] { earlyEndsAt: newEndsAt }
  latest = a.appliedAt
  for other in applications where .block = a.block:
    e = other.earlyEndsAt ?? other.reiEndsAt
    if e > latest:
      latest = e
  update blocks[a.block] { closedUntil: latest }
  return null

mutation assign(block: blocks, picker: principal):
  require exists roles[viewer, role = 'crew_lead'] else NOT_LEAD
  pr = roles[picker] ! else UNKNOWN_PICKER
  require pr.role = 'picker' else NOT_A_PICKER
  b = blocks[block] ! else NOT_FOUND
  require b.closedUntil <= now else BLOCK_CLOSED
  return insert assignments { block, picker, assignedBy: viewer }
