-- Podcast Guest Releases.
-- Guests sign appearance releases per episode; an episode cannot be scheduled
-- to publish until every guest has a signed release; unanswered requests older
-- than seven days are flagged for the producer by a daily job; only the legal
-- role can void a release, which pulls the episode's publish date.
use identity password

-- Roster: one row per enrolled user. Producers manage it; everyone reads
-- their own row. The first producer claims via bootstrapProducer while the
-- roster is empty; afterwards grantRole (producer-only) assigns roles.
table roles:
  principal: principal
  role: enum('guest', 'host', 'producer', 'legal')
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
  insert <- exists roles[viewer, role = 'producer'] or not exists roles[viewer]
  update <- exists roles[viewer, role = 'producer']
  delete <- exists roles[viewer, role = 'producer']
  online only

-- Enrolled users introduce themselves so a producer can find and grant them.
table profiles:
  principal: principal
  displayName: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table shows:
  title: text 1..120
  host: principal
  immutable host
  read <- .host = viewer or exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
  insert <- exists roles[viewer, role = 'producer']
  update <- exists roles[viewer, role = 'producer']
  delete <- exists roles[viewer, role = 'producer']
  online only

table episodes:
  show: shows
  title: text 1..120
  publishAt: time ?
  createdAt: time default now
  immutable show
  read <- exists shows[.show, host = viewer] or exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal'] or exists bookings[episode = .id, guest = viewer]
  insert <- exists roles[viewer, role = 'producer']
  update <- exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
  delete <- exists roles[viewer, role = 'producer']
  cap 200 by show
  online only

-- Booking a guest onto an episode. The guest reads their own bookings.
table bookings:
  episode: episodes
  guest: principal
  bookedAt: time default now
  unique episode, guest
  immutable episode, guest
  read <- .guest = viewer or exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
  insert <- exists roles[viewer, role = 'producer']
  delete <- exists roles[viewer, role = 'producer']
  cap 20 by episode
  online only

-- One release request per (episode, guest). bookGuest opens it as pending;
-- the guest signs it; legal may void it (pulling the publish date).
table releases:
  episode: episodes
  guest: principal
  status: enum('pending', 'signed', 'void') default 'pending'
  requestedAt: time default now
  signedAt: time ?
  remindedAt: time ?
  document: text 1..2000 ?
  note: text 1..280 ?
  unique episode, guest
  immutable episode, guest, requestedAt
  read <- .guest = viewer or exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
  insert <- exists roles[viewer, role = 'producer']
  update <- .guest = viewer or exists roles[viewer, role = 'legal']
  cap 20 by episode
  online only

view guestCount: count bookings by .episode
  read <- exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
view signedCount: count releases where .status = 'signed' by .episode
  read <- exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']
view roleCount: count roles
  read <- allow

query whoAmI():
  return viewer

query myRole():
  return roles[viewer]

query allRoles(c: cursor ?):
  require exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal'] else NOT_PRODUCER
  return roles last 100 by .id after c

query myProfile():
  return profiles[principal = viewer]

query allProfiles(c: cursor ?):
  require exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal'] else NOT_PRODUCER
  return profiles last 100 by .id after c

-- Shows visible to the caller: everything for producer/legal, own shows for
-- hosts, nothing for guests (complete empty page).
query showsList(c: cursor ?):
  if exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']:
    return shows last 50 by .id after c
  return shows where .host = viewer last 50 by .id after c

-- Episodes of one show. The show lookup refuses NOT_FOUND when the caller
-- cannot read the show, so hosts and producers use this; guests use
-- myBookings plus episodeDetail.
query episodesOfShow(show: shows, c: cursor ?):
  s = shows[show] ! else NOT_FOUND
  return episodes where .show = show last 50 by .id after c

-- Everything for producer/legal; guests see nothing here (their path is
-- myBookings + episodeDetail), which keeps the page complete per audience.
query myEpisodes(c: cursor ?):
  if exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal']:
    return episodes last 50 by .id after c
  -- Guests and hosts do not get a global episode feed here (guests use
  -- myBookings plus episodeDetail, hosts use episodesOfShow per own show);
  -- titles are at least one character, so this page is complete and empty.
  return episodes where .title = '' last 50 by .id after c

query episodeDetail(episode: episodes):
  return episodes[episode]

query myBookings(c: cursor ?):
  return bookings where .guest = viewer last 50 by .id after c

query bookingsOf(episode: episodes, c: cursor ?):
  require exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal'] else NOT_PRODUCER
  e = episodes[episode] ! else NOT_FOUND
  return bookings where .episode = episode last 50 by .id after c

query myReleases(c: cursor ?):
  return releases where .guest = viewer last 50 by .id after c

query releasesOf(episode: episodes, c: cursor ?):
  require exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal'] else NOT_PRODUCER
  e = episodes[episode] ! else NOT_FOUND
  return releases where .episode = episode last 50 by .id after c

query releaseDetail(release: releases):
  return releases[release]

-- Release requests unanswered for seven days: the producer's reminder feed.
query overdueReleases(c: cursor ?):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  return releases where .status = 'pending' and .requestedAt <= now - 7d last 50 by .requestedAt after c

query episodeReadiness(episode: episodes):
  require exists roles[viewer, role = 'producer'] or exists roles[viewer, role = 'legal'] else NOT_PRODUCER
  e = episodes[episode] ! else NOT_FOUND
  return { guests: guestCount[episode], signed: signedCount[episode] }

-- First claim: while the roster is empty, anyone may claim the first
-- producer seat. Afterwards grantRole assigns every other seat.
mutation bootstrapProducer():
  require roleCount = 0 else ALREADY_BOOTSTRAPPED
  require not exists roles[viewer] else HAS_ROLE
  return insert roles { principal: viewer, role: 'producer' }

mutation grantRole(who: principal, role: enum('guest', 'host', 'producer', 'legal')):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  return upsert roles[who] { principal: who, role }

mutation saveProfile(displayName: text 1..80):
  return upsert profiles[viewer] { principal: viewer, displayName }

mutation createShow(title: text 1..120, host: principal):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  require exists roles[host, role = 'host'] else NOT_A_HOST
  return insert shows { title, host }

mutation createEpisode(show: shows, title: text 1..120):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  s = shows[show] ! else NOT_FOUND
  return insert episodes { show, title, publishAt: null }

-- Books a guest and opens their release request. requestedAt is normally now;
-- a producer may backdate it when recording a request sent earlier.
mutation bookGuest(episode: episodes, guest: principal, requestedAt: time ?):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  e = episodes[episode] ! else NOT_FOUND
  require e.publishAt = null else ALREADY_SCHEDULED 'Unschedule the episode before adding guests.'
  require exists roles[guest, role = 'guest'] else NOT_A_GUEST
  require not exists bookings[episode, guest] else ALREADY_BOOKED
  at = requestedAt ?? now
  require at <= now else BAD_TIME 'The request date cannot be in the future.'
  insert bookings { episode, guest }
  return insert releases { episode, guest, requestedAt: at }

-- The booked guest uploads their signed appearance release. A voided release
-- may be re-signed after legal clears it with the guest.
mutation signRelease(release: releases, document: text 1..2000):
  r = releases[release] ! else NOT_FOUND
  require r.guest = viewer else NOT_YOUR_RELEASE
  require r.status = 'pending' or r.status = 'void' else ALREADY_SIGNED
  update releases[release] { status: 'signed', signedAt: now, document }
  return null

-- Scheduling needs every booked guest holding a signed release, and a future
-- date. An episode with no guests needs no releases.
mutation schedulePublish(episode: episodes, publishAt: time):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  e = episodes[episode] ! else NOT_FOUND
  require publishAt > now else IN_PAST 'The publish date must be in the future.'
  require (signedCount[episode] ?? 0) = (guestCount[episode] ?? 0) else UNSIGNED_RELEASES 'Every guest needs a signed release first.'
  update episodes[episode] { publishAt }
  return null

mutation unschedule(episode: episodes):
  require exists roles[viewer, role = 'producer'] else NOT_PRODUCER
  e = episodes[episode] ! else NOT_FOUND
  update episodes[episode] { publishAt: null }
  return null

-- Only legal can void. Voiding pulls the episode's publish date; the guest
-- may then sign a fresh release and the producer may schedule again.
mutation voidRelease(release: releases, reason: text 1..280):
  require exists roles[viewer, role = 'legal'] else NOT_LEGAL
  r = releases[release] ! else NOT_FOUND
  require r.status != 'void' else ALREADY_VOID
  update releases[release] { status: 'void', note: reason }
  update episodes[r.episode] { publishAt: null }
  return null

-- Flags release requests unanswered for seven days so the producer's
-- overdueReleases feed can show they have been reminded.
job flagOverdue(periodStart: time, periodEnd: time):
  for r in releases where .requestedAt < periodEnd by .requestedAt:
    if r.status = 'pending' and r.requestedAt + 7d <= periodEnd:
      if r.remindedAt = null:
        update releases[r.id] { remindedAt: periodEnd }

schedule overdueSweep every 1d at 08:00: flagOverdue
