use identity password

table roles:
  principal: principal
  role: enum('guest', 'housekeeping', 'staff', 'duty_manager')
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table claims:
  owner: principal
  description: text 10..1000
  location: text 1..100
  lostOn: time
  filedAt: time
  status: enum('open', 'matched', 'returned', 'expired') default 'open'
  immutable owner, description, location, lostOn, filedAt
  read <- .owner = viewer or exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager']
  insert <- .owner = viewer and not exists roles[viewer, role = 'housekeeping'] and not exists roles[viewer, role = 'staff'] and not exists roles[viewer, role = 'duty_manager']
  update <- exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager']
  online only

table items:
  description: text 3..300
  location: text 1..100
  photo: image <=5000000
  finder: principal
  foundAt: time
  loggedAt: time
  valuable: bool
  status: enum('stored', 'matched', 'approved', 'released', 'donation') default 'stored'
  claim: claims ?
  approvedBy: principal ?
  releasedBy: principal ?
  releasedAt: time ?
  immutable description, location, photo, finder, foundAt, loggedAt, valuable
  read <- exists roles[viewer, role = 'duty_manager'] or (not .valuable and exists roles[viewer, role = 'staff'])
  insert <- .finder = viewer and (exists roles[viewer, role = 'housekeeping'] or exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'])
  update <- exists roles[viewer, role = 'duty_manager'] or (not .valuable and exists roles[viewer, role = 'staff'])
  online only

mutation provisionRole(principal: principal, role: enum('guest', 'housekeeping', 'staff', 'duty_manager')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert roles { principal, role }

query me():
  return { principal: viewer, role: roles[principal = viewer] }

query myClaims(c: cursor ?):
  return claims where .owner = viewer last 50 by .filedAt after c

query claimDetail(claim: claims):
  return claims[claim]

query claimQueue(c: cursor ?):
  require exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'] else STAFF_ONLY
  return claims last 50 by .filedAt after c

query inventory(c: cursor ?):
  require exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'] else STAFF_ONLY
  return items where .valuable = false last 50 by .loggedAt after c

query valuables(c: cursor ?):
  require exists roles[viewer, role = 'duty_manager'] else MANAGER_ONLY
  return items where .valuable = true last 50 by .loggedAt after c

query itemDetail(item: items):
  return items[item]

query donations(c: cursor ?):
  require exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'] else STAFF_ONLY
  return items where .status = 'donation' last 50 by .loggedAt after c

mutation fileClaim(description: text 10..1000, location: text 1..100, lostOn: time):
  require not exists roles[viewer, role = 'housekeeping'] and not exists roles[viewer, role = 'staff'] and not exists roles[viewer, role = 'duty_manager'] else GUEST_ONLY
  require lostOn <= now and lostOn >= now - 365d else INVALID_DATE
  return insert claims { owner: viewer, description, location, lostOn, filedAt: now }

mutation logItem(description: text 3..300, location: text 1..100, photo: image <=5000000, foundAt: time, valuable: bool):
  require exists roles[viewer, role = 'housekeeping'] or exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'] else EMPLOYEE_ONLY
  require foundAt <= now and foundAt >= now - 365d else INVALID_DATE
  insert items { description, location, photo, finder: viewer, foundAt, loggedAt: now, valuable, status: 'donation' if foundAt <= now - 90d else 'stored' }
  return null

mutation matchClaim(item: items, claim: claims):
  require exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'] else STAFF_ONLY
  i = items[item] ! else NOT_FOUND
  c = claims[claim] ! else NOT_FOUND
  require i.foundAt > now - 90d else EXPIRED
  require i.status = 'stored' and c.status = 'open' else ALREADY_MATCHED
  update items[item] { claim, status: 'matched' }
  update claims[claim] { status: 'matched' }
  return null

mutation approveRelease(item: items):
  require exists roles[viewer, role = 'duty_manager'] else MANAGER_ONLY
  i = items[item] ! else NOT_FOUND
  require i.foundAt > now - 90d else EXPIRED
  require i.valuable and i.status = 'matched' else NOT_AWAITING_APPROVAL
  update items[item] { status: 'approved', approvedBy: viewer }
  return null

mutation releaseItem(item: items):
  require exists roles[viewer, role = 'staff'] or exists roles[viewer, role = 'duty_manager'] else STAFF_ONLY
  i = items[item] ! else NOT_FOUND
  require i.foundAt > now - 90d else EXPIRED
  require (not i.valuable and i.status = 'matched') or (i.valuable and i.status = 'approved') else APPROVAL_OR_MATCH_REQUIRED
  require i.claim != null else NO_CLAIM
  update items[item] { status: 'released', releasedBy: viewer, releasedAt: now }
  update claims[i.claim] { status: 'returned' }
  return null

job listDonations():
  for i in items:
    if i.status != 'released' and i.status != 'donation' and i.foundAt <= now - 90d:
      update items[i.id] { status: 'donation' }
      if i.claim != null:
        update claims[i.claim] { status: 'expired' }
schedule donationSweep every 1m: listDonations
