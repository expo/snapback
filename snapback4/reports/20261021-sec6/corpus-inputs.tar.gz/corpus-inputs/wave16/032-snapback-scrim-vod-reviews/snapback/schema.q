use identity password

-- Fixed organization's two squads. Roster enrollment is an operator-only task.
table roles:
  principal: principal
  role: enum('player', 'coach', 'analyst')
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  cap 1000
  online only

table memberships:
  principal: principal
  team: enum('Aurora', 'Nova')
  unique principal, team
  immutable principal, team
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  cap 2000
  online only

table recordings:
  team: enum('Aurora', 'Nova')
  uploader: principal
  title: text 1..120
  clip: video <=64000000
  durationMs: int 1..3600000
  uploadedAt: time
  expiresAt: time ?
  immutable team, uploader, title, clip, durationMs, uploadedAt
  read <- exists memberships[viewer, .team] or exists roles[viewer, role = 'analyst']
  insert <- .uploader = viewer and exists memberships[viewer, .team] and (exists roles[viewer, role = 'player'] or exists roles[viewer, role = 'coach'])
  update <- exists roles[viewer, role = 'coach'] and exists memberships[viewer, .team]
  expire at .expiresAt
  cap 5000
  online only

table notes:
  recording: recordings on delete cascade
  team: enum('Aurora', 'Nova')
  author: principal
  atMs: int 0..3600000
  body: text 1..2000
  staffOnly: bool
  createdAt: time
  immutable recording, team, author, atMs, body, staffOnly, createdAt
  read <- exists recordings[.recording, team = .team] and (exists memberships[viewer, .team] or exists roles[viewer, role = 'analyst']) and (.staffOnly = false or (exists roles[viewer, role = 'coach'] and exists memberships[viewer, .team]))
  insert <- exists recordings[.recording, team = .team] and .author = viewer and exists roles[viewer, role = 'coach'] and exists memberships[viewer, .team]
  cap 1000 by recording
  online only

table reviews:
  recording: recordings on delete cascade
  team: enum('Aurora', 'Nova')
  host: principal
  positionMs: int 0..3600000
  active: bool
  revision: int 1..
  changedAt: time
  unique recording
  immutable recording, team
  read <- exists recordings[.recording, team = .team] and (exists memberships[viewer, .team] or exists roles[viewer, role = 'analyst'])
  insert <- exists recordings[.recording, team = .team] and .host = viewer and exists roles[viewer, role = 'coach'] and exists memberships[viewer, .team]
  update <- .host = viewer and exists roles[viewer, role = 'coach'] and exists memberships[viewer, .team]
  cap 5000
  online only

query myRole():
  return roles[principal = viewer]
query myTeams():
  return memberships where .principal = viewer first 10 by .id
query listRecordings():
  return recordings last 100 by .uploadedAt
query recordingById(recording: recordings):
  return recordings[recording]
query recordingNotes(recording: recordings):
  r = recordings[recording] ! else NOT_FOUND
  if exists roles[viewer, role = 'coach']:
    return notes where .recording = recording and .team = r.team first 1000 by .atMs
  return notes where .recording = recording and .team = r.team and .staffOnly = false first 1000 by .atMs
query noteById(note: notes):
  return notes[note]
query liveReview(recording: recordings):
  r = recordings[recording] ! else NOT_FOUND
  return reviews[recording = recording]

mutation provision(principal: principal, role: enum('player', 'coach', 'analyst'), team: enum('Aurora', 'Nova') ?):
  require viewer = 'service:ops' else OPERATOR_ONLY
  insert roles { principal, role }
  if team != null:
    insert memberships { principal, team }
mutation uploadRecording(team: enum('Aurora', 'Nova'), title: text 1..120, clip: video <=64000000):
  require clip.duration != null else DURATION_UNKNOWN
  return insert recordings { team, uploader: viewer, title, clip, durationMs: clip.duration, uploadedAt: now, expiresAt: now + 60d }
mutation setPinned(recording: recordings, pinned: bool):
  r = recordings[recording] ! else NOT_FOUND
  require exists roles[viewer, role = 'coach'] and exists memberships[viewer, r.team] else COACH_ONLY
  update recordings[recording] { expiresAt: null if pinned else r.uploadedAt + 60d }
mutation addNote(recording: recordings, atMs: int 0..3600000, body: text 1..2000, staffOnly: bool):
  r = recordings[recording] ! else NOT_FOUND
  require atMs <= r.durationMs else OUTSIDE_RECORDING
  return insert notes { recording, team: r.team, author: viewer, atMs, body, staffOnly, createdAt: now }
mutation startReview(recording: recordings):
  r = recordings[recording] ! else NOT_FOUND
  if exists reviews[recording = recording]:
    s = reviews[recording = recording] ! else NOT_FOUND
    require s.host = viewer else OTHER_HOST
    update reviews[s.id] { active: true, positionMs: 0, revision: s.revision + 1, changedAt: now }
  else:
    insert reviews { recording, team: r.team, host: viewer, positionMs: 0, active: true, revision: 1, changedAt: now }
mutation scrub(recording: recordings, positionMs: int 0..3600000):
  r = recordings[recording] ! else NOT_FOUND
  s = reviews[recording = recording] ! else NOT_FOUND
  require s.active else REVIEW_ENDED
  require s.host = viewer else HOST_ONLY
  require positionMs <= r.durationMs else OUTSIDE_RECORDING
  update reviews[s.id] { positionMs, revision: s.revision + 1, changedAt: now }
mutation endReview(recording: recordings):
  r = recordings[recording] ! else NOT_FOUND
  s = reviews[recording = recording] ! else NOT_FOUND
  require s.host = viewer else HOST_ONLY
  require s.active else REVIEW_ENDED
  update reviews[s.id] { active: false, revision: s.revision + 1, changedAt: now }
