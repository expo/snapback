use identity password

table roles:
  principal: principal
  role: enum('researcher', 'staff', 'curator', 'donor')
  unique principal
  immutable principal, role
  read <- .principal = viewer
  insert <- viewer = 'service:provisioner' or (.principal = viewer and .role = 'researcher')
  online only

table boxes:
  code: text 1..30
  title: text 1..120
  restricted: bool
  unique code
  immutable code, title, restricted
  read <- exists roles[viewer]
  insert <- exists roles[viewer, role = 'curator']
  online only

table donorFiles:
  donor: principal
  title: text 1..120
  document: file <=5000000 ('application/pdf')
  immutable donor, title, document
  read <- exists roles[viewer, role = 'curator']
  insert <- exists roles[viewer, role = 'curator'] and exists roles[principal = .donor, role = 'donor']
  online only

table requests:
  researcher: principal
  box: boxes
  visitDay: int 20000..40000
  status: enum('pending', 'approved', 'rejected')
  viewed: bool default false
  reproduction: bool default false
  pulled: bool default false
  at: time default now
  unique researcher, visitDay, box
  cap 5 by researcher, visitDay
  immutable researcher, box, visitDay, at
  read <- .researcher = viewer or exists roles[viewer, role = 'curator']
  insert <- .researcher = viewer and exists roles[viewer, role = 'researcher']
  update <- exists roles[viewer, role = 'curator'] or exists roles[viewer, role = 'staff']
  online only

table pulls:
  request: requests
  researcher: principal
  boxCode: text 1..30
  boxTitle: text 1..120
  visitDay: int
  opensAt: time
  endsAt: time
  unique request
  immutable request, researcher, boxCode, boxTitle, visitDay, opensAt, endsAt
  read <- exists roles[viewer, role = 'staff']
  not before .opensAt
  expire at .endsAt
  online only

table photos:
  request: requests
  researcher: principal
  caption: text 1..160
  photo: image <=5000000
  at: time default now
  immutable request, researcher, caption, photo, at
  read <- .researcher = viewer or exists roles[viewer, role = 'curator']
  insert <- .researcher = viewer and exists requests[.request, researcher = viewer, viewed = true, reproduction = true]
  online only

query me():
  return { principal: viewer, role: roles[viewer], now: now }
query catalogue(c: cursor ?):
  require exists roles[viewer] else NOT_REGISTERED
  return boxes first 50 by .code after c
query myRequests(c: cursor ?):
  require exists roles[viewer, role = 'researcher'] else NOT_RESEARCHER
  return requests where .researcher = viewer last 50 by .at after c
query requestDetail(request: requests):
  return requests[request]
query curatorRequests(c: cursor ?):
  require exists roles[viewer, role = 'curator'] else NOT_CURATOR
  return requests last 50 by .at after c
query pullList(c: cursor ?):
  require exists roles[viewer, role = 'staff'] else NOT_STAFF
  return pulls where .visitDay = day(now) first 50 by .boxCode after c
query requestPhotos(request: requests, c: cursor ?):
  r = requests[request] ! else NOT_FOUND
  return photos where .request = r.id last 50 by .at after c
query restrictedFiles(c: cursor ?):
  require exists roles[viewer, role = 'curator'] else NOT_CURATOR
  return donorFiles first 50 by .id after c
query restrictedFile(file: donorFiles):
  return donorFiles[file]

mutation register():
  require not exists roles[viewer] else ALREADY_REGISTERED
  return insert roles { principal: viewer, role: 'researcher' }
mutation provision(principal: principal, role: enum('researcher', 'staff', 'curator', 'donor')):
  require viewer = 'service:provisioner' else NOT_PROVISIONER
  return insert roles { principal, role }
mutation addBox(code: text 1..30, title: text 1..120, restricted: bool):
  require exists roles[viewer, role = 'curator'] else NOT_CURATOR
  return insert boxes { code, title, restricted }
mutation addDonorFile(donor: principal, title: text 1..120, document: file <=5000000 ('application/pdf')):
  require exists roles[viewer, role = 'curator'] else NOT_CURATOR
  return insert donorFiles { donor, title, document }
mutation requestBox(box: boxes, visitDay: int 20000..40000):
  require exists roles[viewer, role = 'researcher'] else NOT_RESEARCHER
  require now < visitDay * 1d - 12h else REQUESTS_CLOSED 'Requests close at noon UTC the day before.'
  require visitDay <= day(now) + 365 else TOO_FAR
  b = boxes[box] ! else NOT_FOUND
  return insert requests { researcher: viewer, box, visitDay, status: 'pending' if b.restricted else 'approved' }
mutation decideRequest(request: requests, approve: bool):
  require exists roles[viewer, role = 'curator'] else NOT_CURATOR
  r = requests[request] ! else NOT_FOUND
  require r.status = 'pending' else ALREADY_DECIDED
  require now < r.visitDay * 1d + 8h else PULL_WINDOW_PASSED
  update requests[r.id] { status: 'approved' if approve else 'rejected' }
  return null
mutation markViewed(pull: pulls):
  require exists roles[viewer, role = 'staff'] else NOT_STAFF
  p = pulls[pull] ! else NOT_FOUND
  require day(now) = p.visitDay and now >= p.visitDay * 1d + 9h and now < p.visitDay * 1d + 17h else ROOM_CLOSED
  update requests[p.request] { viewed: true }
  return null
mutation clearReproduction(request: requests):
  require exists roles[viewer, role = 'curator'] else NOT_CURATOR
  r = requests[request] ! else NOT_FOUND
  require r.viewed else NOT_VIEWED
  update requests[r.id] { reproduction: true }
  return null
mutation uploadPhoto(request: requests, caption: text 1..160, photo: image <=5000000):
  require exists roles[viewer, role = 'researcher'] else NOT_RESEARCHER
  r = requests[request] ! else NOT_FOUND
  require r.researcher = viewer else NOT_OWNER
  require r.viewed and r.reproduction else NOT_CLEARED 'The curator must clear reproduction after your visit.'
  return insert photos { request, researcher: viewer, caption, photo }

job morningPull(periodStart: time, periodEnd: time):
  for r in requests:
    if r.visitDay = day(now) and now >= r.visitDay * 1d + 8h and not r.pulled and r.status = 'approved':
      b = boxes[r.box] ! else NOT_FOUND
      insert pulls { request: r.id, researcher: r.researcher, boxCode: b.code, boxTitle: b.title, visitDay: r.visitDay, opensAt: r.visitDay * 1d + 8h, endsAt: (r.visitDay + 1) * 1d } if absent
      update requests[r.id] { pulled: true }
schedule dailyPull every 1d at 08:00: morningPull
