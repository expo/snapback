use identity password

-- Only a trusted local operator can enroll staff or certify an interpreter.
table roster:
  principal: principal
  role: enum('clerk', 'interpreter', 'coordinator')
  name: text 1..80
  unique principal
  immutable principal, role, name
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table certifications:
  principal: principal
  language: enum('Spanish', 'Arabic', 'Mandarin', 'French', 'ASL')
  unique principal, language
  immutable principal, language
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table hearings:
  clerk: principal
  caseNumber: text 3..40
  language: enum('Spanish', 'Arabic', 'Mandarin', 'French', 'ASL')
  courtroom: text 1..40
  startsAt: time
  endsAt: time
  interpreter: principal ?
  immutable clerk, caseNumber, language, courtroom, startsAt, endsAt
  read <- exists roster[viewer]
  insert <- .clerk = viewer and exists roster[viewer, role = 'clerk'] and .interpreter = null
  update (old, next) <- old.interpreter = null and next.interpreter = viewer and exists roster[viewer, role = 'interpreter'] and exists certifications[viewer, old.language]
  online only

-- No party-name column exists on an interpreter-readable row.
table parties:
  hearing: hearings
  partyNames: text 1..300
  unique hearing
  immutable hearing, partyNames
  read <- exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'coordinator']
  insert <- exists roster[viewer, role = 'clerk'] and .hearing.clerk = viewer
  online only

table escalations:
  hearing: hearings
  at: time
  unique hearing
  immutable hearing, at
  read <- exists roster[viewer, role = 'coordinator']
  insert <- exists roster[viewer, role = 'clerk'] and .hearing.clerk = viewer
  online only

table timesheets:
  hearing: hearings
  owner: principal
  signedBy: text 1..80
  minutes: int 1..1440
  document: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg')
  submittedAt: time
  approvedBy: principal ?
  approvedAt: time ?
  unique hearing else ALREADY_SUBMITTED
  immutable hearing, owner, signedBy, minutes, document, submittedAt
  read <- .owner = viewer or exists roster[viewer, role = 'coordinator']
  insert <- .owner = viewer and .hearing.interpreter = viewer and exists roster[viewer, role = 'interpreter'] and .approvedBy = null and .approvedAt = null
  update (old, next) <- old.approvedAt = null and next.approvedBy = viewer and exists roster[viewer, role = 'coordinator']
  online only

query myAccount():
  return roster[viewer]

query myCertifications():
  require exists roster[viewer] else NOT_ENROLLED
  return certifications where .principal = viewer first 10 by .id

query hearingBoard(c: cursor ?):
  require exists roster[viewer] else NOT_ENROLLED
  return hearings last 100 by .startsAt after c

query hearingDetails(hearing: hearings):
  require exists roster[viewer] else NOT_ENROLLED
  return hearings[hearing]

query partyDetails(hearing: hearings):
  require exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'coordinator'] else PARTY_NAMES_PRIVATE
  return parties[hearing = hearing]

query escalationQueue(c: cursor ?):
  require exists roster[viewer, role = 'coordinator'] else NOT_COORDINATOR
  return escalations where .hearing.interpreter = null first 100 by .at after c { id, at, hearing: hearings[.hearing], parties: parties[hearing = .hearing] }

query myTimesheets(c: cursor ?):
  require exists roster[viewer, role = 'interpreter'] else NOT_INTERPRETER
  return timesheets where .owner = viewer last 100 by .submittedAt after c

query paymentQueue(c: cursor ?):
  require exists roster[viewer, role = 'coordinator'] else NOT_COORDINATOR
  return timesheets last 100 by .submittedAt after c

query timesheetDetails(sheet: timesheets):
  require exists roster[viewer] else NOT_ENROLLED
  return timesheets[sheet]

mutation enroll(principal: principal, role: enum('clerk', 'interpreter', 'coordinator'), name: text 1..80):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert roster { principal, role, name }

mutation certify(principal: principal, language: enum('Spanish', 'Arabic', 'Mandarin', 'French', 'ASL')):
  require viewer = 'service:ops' else NOT_OPERATOR
  require exists roster[principal, role = 'interpreter'] else NOT_INTERPRETER
  return insert certifications { principal, language }

mutation postHearing(caseNumber: text 3..40, language: enum('Spanish', 'Arabic', 'Mandarin', 'French', 'ASL'), courtroom: text 1..40, startsAt: time, endsAt: time, partyNames: text 1..300):
  require exists roster[viewer, role = 'clerk'] else NOT_CLERK
  require startsAt > now else HEARING_STARTED
  require startsAt <= now + 365d else TOO_FAR_AHEAD
  require endsAt > startsAt and endsAt <= startsAt + 12h else BAD_END_TIME
  h = insert hearings { clerk: viewer, caseNumber, language, courtroom, startsAt, endsAt }
  insert parties { hearing: h.id, partyNames }
  if startsAt <= now + 48h:
    insert escalations { hearing: h.id, at: now }
  return h

mutation claimHearing(hearing: hearings):
  require exists roster[viewer, role = 'interpreter'] else NOT_INTERPRETER
  h = hearings[hearing] ! else NOT_FOUND
  require h.startsAt > now else HEARING_STARTED
  require h.interpreter = null else ALREADY_CLAIMED
  require exists certifications[viewer, h.language] else NOT_CERTIFIED
  update hearings[hearing] { interpreter: viewer }
  return hearings[hearing]

mutation submitTimesheet(hearing: hearings, signedBy: text 1..80, minutes: int 1..1440, document: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg')):
  require exists roster[viewer, role = 'interpreter'] else NOT_INTERPRETER
  h = hearings[hearing] ! else NOT_FOUND
  require h.interpreter = viewer else NOT_ASSIGNED
  require now >= h.endsAt else HEARING_NOT_FINISHED
  return insert timesheets { hearing, owner: viewer, signedBy, minutes, document, submittedAt: now }

mutation approvePayment(sheet: timesheets):
  require exists roster[viewer, role = 'coordinator'] else NOT_COORDINATOR
  t = timesheets[sheet] ! else NOT_FOUND
  require t.approvedAt = null else ALREADY_APPROVED
  update timesheets[sheet] { approvedBy: viewer, approvedAt: now }
  return timesheets[sheet]

job escalateUnclaimed(periodStart: time, periodEnd: time):
  for h in hearings where .startsAt <= periodEnd + 48h by .startsAt:
    if h.interpreter = null and not exists escalations[hearing = h.id]:
      insert escalations { hearing: h.id, at: periodEnd }

schedule escalationSweep every 1m: escalateUnclaimed
