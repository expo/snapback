use identity password

table profiles:
  principal: principal
  name: text 1..80
  role: enum('planner', 'couple', 'vendor', 'venue')
  unique principal
  immutable principal, role, name
  read <- allow
  insert <- .principal = viewer
  cap 1 by principal
  online only

table weddings:
  planner: principal
  title: text 1..120
  startsAt: time
  location: text 1..200
  immutable planner, startsAt, title, location
  read <- .planner = viewer or exists invitations[.id, viewer]
  insert <- .planner = viewer and exists profiles[principal = viewer, role = 'planner']
  cap 100 by planner
  online only

table invitations:
  wedding: weddings
  principal: principal
  role: enum('couple', 'vendor', 'venue')
  unique wedding, principal
  immutable wedding, principal, role
  read <- .principal = viewer or .wedding.planner = viewer
  insert <- .wedding.planner = viewer and exists profiles[principal = .principal, role = .role]
  cap 100 by wedding
  online only

table loadRules:
  wedding: weddings
  body: text 1..4000
  unique wedding
  immutable wedding
  read <- .wedding.planner = viewer or exists invitations[.wedding, viewer]
  insert <- .wedding.planner = viewer
  update <- .wedding.planner = viewer or exists invitations[.wedding, viewer, role = 'venue']
  online only

table items:
  wedding: weddings
  vendor: principal
  title: text 1..160
  at: time
  deadline: time
  confirmed: bool default false
  confirmedAt: time ?
  done: bool default false
  doneAt: time ?
  overdue: bool default false
  immutable wedding, vendor, title, at, deadline
  read <- .wedding.planner = viewer or exists invitations[.wedding, viewer, role = 'couple'] or .vendor = viewer
  insert <- .wedding.planner = viewer and exists invitations[.wedding, .vendor, role = 'vendor']
  update <- .vendor = viewer
  cap 300 by wedding
  online only

table contracts:
  item: items
  wedding: weddings
  amountCents: int 0..100000000
  unique item
  immutable item, wedding, amountCents
  read <- .wedding.planner = viewer
  insert <- .wedding.planner = viewer and .item.wedding = .wedding
  online only

table certificates:
  wedding: weddings
  vendor: principal
  document: file <=5000000 ('application/pdf')
  uploadedAt: time
  immutable wedding, vendor, document, uploadedAt
  read <- .wedding.planner = viewer or exists invitations[.wedding, viewer, role = 'venue']
  insert <- .vendor = viewer and exists invitations[.wedding, viewer, role = 'vendor']
  cap 100 by wedding
  online only

query me():
  return profiles[principal = viewer]
query directory():
  return profiles first 200 by .id
query myWeddings():
  return weddings first 100 by .id
query weddingDetail(wedding: weddings):
  return weddings[wedding]
query invited(wedding: weddings):
  return invitations where .wedding = wedding first 100 by .id
query rulesFor(wedding: weddings):
  return loadRules[wedding = wedding]
query timeline(wedding: weddings):
  return items where .wedding = wedding first 300 by .at
query itemDetail(item: items):
  return items[item]
query amounts(wedding: weddings):
  return contracts where .wedding = wedding first 300 by .id
query insurance(wedding: weddings):
  return certificates where .wedding = wedding first 100 by .id
query alerts(wedding: weddings):
  return items where .wedding = wedding and .overdue = true and .confirmed = false first 300 by .id

mutation registerProfile(name: text 1..80, role: enum('planner', 'couple', 'vendor', 'venue')):
  return insert profiles { principal: viewer, name, role }
mutation createWedding(title: text 1..120, startsAt: time, location: text 1..200, rules: text 1..4000):
  require startsAt > now else WEDDING_IN_PAST
  w = insert weddings { planner: viewer, title, startsAt, location }
  insert loadRules { wedding: w.id, body: rules }
  return w
mutation invite(wedding: weddings, principal: principal, role: enum('couple', 'vendor', 'venue')):
  w = weddings[wedding] ! else NOT_FOUND
  require w.planner = viewer else PLANNER_ONLY
  return insert invitations { wedding, principal, role }
mutation addItem(wedding: weddings, vendor: principal, title: text 1..160, at: time, amountCents: int 0..100000000):
  w = weddings[wedding] ! else NOT_FOUND
  require w.planner = viewer else PLANNER_ONLY
  require now < w.startsAt else WEDDING_STARTED
  require day(at) = day(w.startsAt) else WRONG_DAY
  i = insert items { wedding, vendor, title, at, deadline: w.startsAt - 7d }
  insert contracts { item: i.id, wedding, amountCents }
  return i
mutation setLoadRules(wedding: weddings, body: text 1..4000):
  update loadRules[wedding = wedding] { body }
mutation confirmItem(item: items):
  i = items[item] ! else NOT_FOUND
  require i.vendor = viewer else ASSIGNED_VENDOR_ONLY
  w = weddings[i.wedding] ! else NOT_FOUND
  require now < w.startsAt else CONFIRMATION_CLOSED
  require not i.confirmed else ALREADY_CONFIRMED
  update items[item] { confirmed: true, confirmedAt: now }
mutation completeItem(item: items):
  i = items[item] ! else NOT_FOUND
  require i.vendor = viewer else ASSIGNED_VENDOR_ONLY
  w = weddings[i.wedding] ! else NOT_FOUND
  require day(now) = day(w.startsAt) else WEDDING_DAY_ONLY
  require not i.done else ALREADY_DONE
  update items[item] { done: true, doneAt: now }
mutation uploadCertificate(wedding: weddings, document: file <=5000000 ('application/pdf')):
  w = weddings[wedding] ! else NOT_FOUND
  insert certificates { wedding, vendor: viewer, document, uploadedAt: now }
  return null

job flagUnconfirmed():
  for i in items:
    if not i.confirmed and not i.overdue and now >= i.deadline:
      update items[i.id] { overdue: true }
schedule checkConfirmations every 1m: flagUnconfirmed
