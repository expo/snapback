use identity password

-- Assignment is managed by a private operator seat, never by account signup.
table members:
  principal: principal
  name: text 1..60
  role: enum('crew', 'supervisor', 'director')
  rigCode: text 3..24 ?
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table rigs:
  code: text 3..24
  label: text 1..60
  activeCheckout: checkouts ?
  activeLabel: text <=80 default ''
  state: enum('checking', 'in_service') default 'checking'
  signedCount: int 0..2 default 0
  sealHold: bool default false
  unique code
  immutable code
  read <- exists members[principal = viewer, role = 'crew', rigCode = .code] or exists members[principal = viewer, role = 'supervisor'] or exists members[principal = viewer, role = 'director'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- exists members[principal = viewer, role = 'crew', rigCode = .code] or exists members[principal = viewer, role = 'director']
  online only

table sealSettings:
  rigCode: text 3..24
  expectedSeal: text 3..32
  unique rigCode
  immutable rigCode
  read <- exists members[principal = viewer, role = 'crew', rigCode = .rigCode] or exists members[principal = viewer, role = 'director']
  insert <- viewer = 'service:ops'
  update <- exists members[principal = viewer, role = 'director']
  online only

table checkouts:
  rigCode: text 3..24
  shift: text 1..80
  createdBy: principal
  createdAt: time default now
  morphine: int 0..40
  epinephrine: int 0..40
  oxygenPsi: int 0..3000
  equipmentReady: bool
  observedSeal: text 3..32
  sealIntact: bool
  sealPhoto: image <=5000000
  firstSigner: principal ?
  firstSignedAt: time ?
  secondSigner: principal ?
  secondSignedAt: time ?
  immutable rigCode, shift, createdBy, createdAt, morphine, epinephrine, oxygenPsi, equipmentReady, observedSeal, sealIntact, sealPhoto
  read <- exists members[principal = viewer, role = 'crew', rigCode = .rigCode] or exists members[principal = viewer, role = 'director']
  insert <- .createdBy = viewer and exists members[principal = viewer, role = 'crew', rigCode = .rigCode]
  update <- exists members[principal = viewer, role = 'crew', rigCode = .rigCode]
  online only

-- Minimal operational notification; no seal numbers, photos or clearance log.
table alerts:
  rigCode: text 3..24
  checkout: checkouts
  at: time default now
  immutable rigCode, checkout, at
  read <- exists members[principal = viewer, role = 'supervisor']
  insert <- exists members[principal = viewer, role = 'crew', rigCode = .rigCode]
  online only

-- The whole audit row (including clearance) is medical-director-only.
table discrepancies:
  rigCode: text 3..24
  checkout: checkouts
  expectedSeal: text 3..32
  observedSeal: text 3..32
  broken: bool
  reportedBy: principal
  reportedAt: time default now
  cleared: bool default false
  clearedBy: principal ?
  clearedAt: time ?
  clearanceNote: text 10..500 ?
  replacementSeal: text 3..32 ?
  immutable rigCode, checkout, expectedSeal, observedSeal, broken, reportedBy, reportedAt
  read <- exists members[principal = viewer, role = 'director']
  insert <- .reportedBy = viewer and exists members[principal = viewer, role = 'crew', rigCode = .rigCode]
  update <- exists members[principal = viewer, role = 'director']
  online only

view openIssues: count discrepancies where .cleared = false by .rigCode
  read <- exists members[principal = viewer, role = 'director']

mutation provisionMember(principal: principal, name: text 1..60, role: enum('crew', 'supervisor', 'director'), rigCode: text 3..24 ?):
  require viewer = 'service:ops' else OPERATOR_ONLY
  require (role = 'crew' and rigCode != null) or (role != 'crew' and rigCode = null) else ASSIGNMENT_REQUIRED
  return insert members { principal, name, role, rigCode }

mutation provisionRig(code: text 3..24, label: text 1..60, expectedSeal: text 3..32):
  require viewer = 'service:ops' else OPERATOR_ONLY
  r = insert rigs { code, label }
  insert sealSettings { rigCode: code, expectedSeal }
  return r

query me():
  return members[principal = viewer]

query stationStatus():
  m = members[principal = viewer] ! else NOT_ENROLLED
  if m.role = 'crew':
    return rigs where .code = m.rigCode first 100 by .code
  return rigs first 100 by .code

query rigSettings(rigCode: text 3..24):
  return sealSettings[rigCode = rigCode] ! else NOT_FOUND

query checkoutHistory(rigCode: text 3..24, c: cursor ?):
  m = members[principal = viewer] ! else NOT_ENROLLED
  require m.role = 'director' or (m.role = 'crew' and m.rigCode = rigCode) else PRIVATE_CHECKOUT
  return checkouts where .rigCode = rigCode last 30 by .createdAt after c

query checkoutDetail(checkout: checkouts):
  return checkouts[checkout] ! else NOT_FOUND

query supervisorAlerts(c: cursor ?):
  require exists members[principal = viewer, role = 'supervisor'] else SUPERVISOR_ONLY
  return alerts last 100 by .at after c

query discrepancyLog(c: cursor ?):
  require exists members[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  return discrepancies last 100 by .reportedAt after c

query discrepancyDetail(discrepancy: discrepancies):
  require exists members[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  d = discrepancies[discrepancy] ! else NOT_FOUND
  return { event: d, checkout: checkouts[d.checkout] }

mutation createCheckout(rigCode: text 3..24, shift: text 1..80, morphine: int 0..40, epinephrine: int 0..40, oxygenPsi: int 0..3000, equipmentReady: bool, observedSeal: text 3..32, sealIntact: bool, sealPhoto: image <=5000000):
  require exists members[principal = viewer, role = 'crew', rigCode = rigCode] else CREW_ASSIGNED_ONLY
  r = rigs[code = rigCode] ! else NOT_FOUND
  s = sealSettings[rigCode = rigCode] ! else NOT_FOUND
  require len(trim(shift)) >= 1 else SHIFT_REQUIRED
  require len(trim(observedSeal)) >= 3 else SEAL_REQUIRED
  c = insert checkouts { rigCode, shift, createdBy: viewer, morphine, epinephrine, oxygenPsi, equipmentReady, observedSeal, sealIntact, sealPhoto }
  update rigs[r.id] { activeCheckout: c.id, activeLabel: shift, signedCount: 0, state: 'checking' }
  if not sealIntact or observedSeal != s.expectedSeal:
    insert discrepancies { rigCode, checkout: c.id, expectedSeal: s.expectedSeal, observedSeal, broken: not sealIntact, reportedBy: viewer }
    insert alerts { rigCode, checkout: c.id }
    update rigs[r.id] { sealHold: true }
  return c

mutation signCheckout(checkout: checkouts):
  c = checkouts[checkout] ! else NOT_FOUND
  require exists members[principal = viewer, role = 'crew', rigCode = c.rigCode] else CREW_ASSIGNED_ONLY
  r = rigs[code = c.rigCode] ! else NOT_FOUND
  require r.activeCheckout = checkout else CHECKOUT_SUPERSEDED
  require c.firstSigner != viewer and c.secondSigner != viewer else ALREADY_SIGNED
  require c.secondSigner = null else TWO_SIGNATURES_PRESENT
  if c.firstSigner = null:
    update checkouts[checkout] { firstSigner: viewer, firstSignedAt: now }
    update rigs[r.id] { signedCount: 1 }
  else:
    update checkouts[checkout] { secondSigner: viewer, secondSignedAt: now }
    update rigs[r.id] { signedCount: 2 }
  return checkouts[checkout]

mutation markInService(checkout: checkouts):
  c = checkouts[checkout] ! else NOT_FOUND
  require exists members[principal = viewer, role = 'crew', rigCode = c.rigCode] else CREW_ASSIGNED_ONLY
  r = rigs[code = c.rigCode] ! else NOT_FOUND
  require r.activeCheckout = checkout else CHECKOUT_SUPERSEDED
  require c.firstSigner != null and c.secondSigner != null else TWO_SIGNATURES_REQUIRED
  require c.firstSigner != c.secondSigner else DISTINCT_SIGNATURES_REQUIRED
  require not r.sealHold else SEAL_HOLD
  require c.equipmentReady and c.oxygenPsi >= 500 else EQUIPMENT_NOT_READY
  update rigs[r.id] { state: 'in_service' }
  return rigs[r.id]

mutation clearDiscrepancy(discrepancy: discrepancies, note: text 10..500, replacementSeal: text 3..32):
  require exists members[principal = viewer, role = 'director'] else DIRECTOR_ONLY
  require len(trim(note)) >= 10 else CLEARANCE_NOTE_REQUIRED
  require len(trim(replacementSeal)) >= 3 else SEAL_REQUIRED
  d = discrepancies[discrepancy] ! else NOT_FOUND
  require not d.cleared else ALREADY_CLEARED
  update discrepancies[discrepancy] { cleared: true, clearedBy: viewer, clearedAt: now, clearanceNote: note, replacementSeal }
  s = sealSettings[rigCode = d.rigCode] ! else NOT_FOUND
  update sealSettings[s.id] { expectedSeal: replacementSeal }
  r = rigs[code = d.rigCode] ! else NOT_FOUND
  remaining = openIssues[d.rigCode]
  require remaining != null else COUNT_UNAVAILABLE
  update rigs[r.id] { sealHold: remaining > 0 }
  return discrepancies[discrepancy]
