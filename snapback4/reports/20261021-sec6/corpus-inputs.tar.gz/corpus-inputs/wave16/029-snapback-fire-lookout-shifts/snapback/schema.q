use identity password

-- Roles are provisioned by a local operator seat, never by signup.
table staff:
  principal: principal
  name: text 1..60
  role: enum('seasonal', 'volunteer', 'dispatcher', 'officer')
  tower: towers ?
  unique principal
  immutable principal, role, tower, name
  read <- .principal = viewer or exists staff[principal = viewer, role = 'dispatcher'] or exists staff[principal = viewer, role = 'officer'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table towers:
  name: text 1..60
  latitude: int -90000000..90000000
  longitude: int -180000000..180000000
  immutable name, latitude, longitude
  read <- exists staff[principal = viewer] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table shifts:
  lookout: principal
  tower: towers
  startsAt: time
  endsAt: time
  immutable lookout, tower, startsAt, endsAt
  read <- .lookout = viewer or exists staff[principal = viewer, role = 'dispatcher'] or exists staff[principal = viewer, role = 'officer']
  insert <- exists staff[principal = viewer, role = 'dispatcher'] or exists staff[principal = viewer, role = 'officer']
  online only

table sightings:
  reporter: principal
  tower: towers
  bearing: int 0..359
  notes: text 1..1000
  photo: image <=5000000
  reportedAt: time
  status: enum('open', 'false-alarm') default 'open'
  closedBy: principal ?
  closedAt: time ?
  resolution: text 1..500 ?
  immutable reporter, tower, bearing, notes, photo, reportedAt
  read <- exists staff[principal = viewer, tower = .tower] or exists staff[principal = viewer, role = 'dispatcher'] or exists staff[principal = viewer, role = 'officer']
  insert <- .reporter = viewer and (exists staff[principal = viewer, role = 'seasonal', tower = .tower] or exists staff[principal = viewer, role = 'volunteer', tower = .tower])
  update <- exists staff[principal = viewer, role = 'officer']
  online only

mutation provisionStaff(principal: principal, name: text 1..60, role: enum('seasonal', 'volunteer', 'dispatcher', 'officer'), tower: towers ?):
  require viewer = 'service:ops' else OPERATOR_ONLY
  if role = 'seasonal' or role = 'volunteer':
    require tower != null else TOWER_REQUIRED
    t = towers[tower] ! else NOT_FOUND
  else:
    require tower = null else NO_TOWER
  return insert staff { principal, name, role, tower }

mutation provisionTower(name: text 1..60, latitude: int -90000000..90000000, longitude: int -180000000..180000000):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return insert towers { name, latitude, longitude }

mutation assignShift(lookout: principal, tower: towers, startsAt: time, endsAt: time):
  me = staff[principal = viewer] ! else NOT_STAFF
  require me.role = 'dispatcher' or me.role = 'officer' else DISPATCH_ONLY
  person = staff[principal = lookout] ! else NOT_FOUND
  require person.role = 'seasonal' or person.role = 'volunteer' else NOT_LOOKOUT
  t = towers[tower] ! else NOT_FOUND
  require person.tower = tower else WRONG_TOWER
  require endsAt > startsAt and endsAt <= startsAt + 24h else INVALID_SHIFT
  return insert shifts { lookout, tower, startsAt, endsAt }

mutation reportSmoke(bearing: int 0..359, notes: text 1..1000, photo: image <=5000000):
  me = staff[principal = viewer] ! else NOT_STAFF
  require me.role = 'seasonal' or me.role = 'volunteer' else LOOKOUT_ONLY
  require me.tower != null else TOWER_REQUIRED
  return insert sightings { reporter: viewer, tower: me.tower, bearing, notes, photo, reportedAt: now }

mutation closeFalseAlarm(sighting: sightings, resolution: text 1..500):
  me = staff[principal = viewer] ! else NOT_STAFF
  require me.role = 'officer' else OFFICER_ONLY
  s = sightings[sighting] ! else NOT_FOUND
  require s.status = 'open' else ALREADY_CLOSED
  return update sightings[sighting] { status: 'false-alarm', closedBy: viewer, closedAt: now, resolution }

query me():
  return staff[principal = viewer]
query roster(c: cursor ?):
  me = staff[principal = viewer] ! else NOT_STAFF
  require me.role = 'dispatcher' or me.role = 'officer' else DISPATCH_ONLY
  return staff first 100 by .id after c
query towers(c: cursor ?):
  return towers first 100 by .id after c
query shifts(c: cursor ?):
  me = staff[principal = viewer] ! else NOT_STAFF
  if me.role = 'dispatcher' or me.role = 'officer':
    return shifts last 100 by .startsAt after c
  return shifts where .lookout = viewer last 100 by .startsAt after c
query shift(shift: shifts):
  return shifts[shift]
query sightings(c: cursor ?):
  me = staff[principal = viewer] ! else NOT_STAFF
  if me.role = 'dispatcher' or me.role = 'officer':
    return sightings last 100 by .reportedAt after c
  return sightings where .tower = me.tower last 100 by .reportedAt after c
query sighting(sighting: sightings):
  return sightings[sighting]
-- Derived on each live read, using report timestamps, so historical links persist.
query crossReferences(sighting: sightings, c: cursor ?):
  me = staff[principal = viewer] ! else NOT_STAFF
  require me.role = 'dispatcher' or me.role = 'officer' else DISPATCH_ONLY
  s = sightings[sighting] ! else NOT_FOUND
  return sightings where .tower != s.tower and .reportedAt >= s.reportedAt - 15m and .reportedAt <= s.reportedAt + 15m first 100 by .reportedAt after c
