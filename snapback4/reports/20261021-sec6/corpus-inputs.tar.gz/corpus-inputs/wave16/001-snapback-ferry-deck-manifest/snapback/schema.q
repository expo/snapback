use identity password

table roles:
  principal: principal
  role: enum('driver', 'purser', 'deckhand', 'captain', 'operations_manager')
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table sailings:
  name: text 2..80
  departure: time
  cutoff: time
  spaces: int 1..100
  weightLimit: int 1000..200000
  baseWeightLimit: int 1000..200000
  immutable name, departure, cutoff, spaces, baseWeightLimit
  read <- allow
  insert <- exists roles[principal = viewer, role = 'operations_manager']
  update <- exists roles[principal = viewer, role = 'captain']
  online only

table bookings:
  sailing: sailings
  driver: principal
  plate: text 2..16
  length: int 100..2000
  weight: int 100..30000
  state: enum('booked', 'standby', 'checked_in', 'released')
  ready: bool default false
  lane: int 1..3 ?
  at: time default now
  unique sailing, driver else ALREADY_BOOKED
  cap 100 by sailing
  immutable sailing, driver, plate, length, weight, at
  read <- .driver = viewer or exists roles[principal = viewer, role = 'purser'] or exists roles[principal = viewer, role = 'deckhand'] or exists roles[principal = viewer, role = 'captain'] or exists roles[principal = viewer, role = 'operations_manager']
  insert <- .driver = viewer
  update <- exists roles[principal = viewer, role = 'purser']
  online only

table holds:
  sailing: sailings
  booking: bookings
  driver: principal
  length: int 100..2000
  weight: int 100..30000
  until: time ?
  unique booking
  cap 100 by sailing
  immutable sailing, booking, driver, length, weight
  read <- .driver = viewer or exists roles[principal = viewer, role = 'purser'] or exists roles[principal = viewer, role = 'captain'] or exists roles[principal = viewer, role = 'operations_manager']
  insert <- .driver = viewer
  update <- exists roles[principal = viewer, role = 'purser']
  expire at .until
  online only

table photos:
  booking: bookings
  driver: principal
  photo: image <=5000000
  unique booking
  immutable booking, driver, photo
  read <- .driver = viewer or exists roles[principal = viewer, role = 'purser'] or exists roles[principal = viewer, role = 'captain'] or exists roles[principal = viewer, role = 'operations_manager']
  insert <- exists roles[principal = viewer, role = 'purser']
  online only

table overrides:
  sailing: sailings
  captain: principal
  previousLimit: int
  newLimit: int
  reason: text 10..500
  at: time default now
  immutable sailing, captain, previousLimit, newLimit, reason, at
  read <- exists roles[principal = viewer, role = 'captain'] or exists roles[principal = viewer, role = 'operations_manager']
  insert <- .captain = viewer and exists roles[principal = viewer, role = 'captain']
  online only

view occupied: count holds by .sailing
  read <- allow
  online only
view lengthUsed: sum holds of .length by .sailing
  read <- allow
  online only
view weightUsed: sum holds of .weight by .sailing
  read <- allow
  online only

view laneLength: sum bookings of .length where .state = 'checked_in' by .sailing, .lane
  read <- exists roles[principal = viewer, role = 'purser']
  online only

fn role(): roles[principal = viewer].role ?? 'driver'
fn office(): role() = 'purser' or role() = 'captain' or role() = 'operations_manager'
fn fits(s: sailings, length: int, weight: int):
  return occupied[s.id] < s.spaces and lengthUsed[s.id] + length <= 6000 and weightUsed[s.id] + weight <= s.weightLimit
shape bookingCard = { *, effectiveState: 'released' if .state = 'booked' and (sailings[.sailing].cutoff ?? 0) <= now else .state, photo: photos[booking = .id].photo }

query me():
  return { principal: viewer, role: role(), now }
query timetable(c: cursor ?):
  return sailings first 30 by .departure after c
query myBookings(c: cursor ?):
  return bookings where .driver = viewer last 30 by .at after c bookingCard
query booking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.driver = viewer or office() else FORBIDDEN
  return b bookingCard
query manifest(sailing: sailings):
  require office() else FORBIDDEN
  return bookings where .sailing = sailing first 100 by .at bookingCard
query nextPlan():
  require role() = 'deckhand' or office() else FORBIDDEN
  s = first(sailings where .departure > now first 1 by .departure)
  if s = null:
    return { sailing: null, vehicles: [] }
  return { sailing: s, vehicles: bookings where .sailing = s.id and .state = 'checked_in' first 100 by .at { id, plate, length, weight, lane } }
query overrideHistory(c: cursor ?):
  require role() = 'captain' or role() = 'operations_manager' else FORBIDDEN
  return overrides last 30 by .at after c

mutation grantRole(principal: principal, role: enum('driver', 'purser', 'deckhand', 'captain', 'operations_manager')):
  require viewer = 'service:ops' else FORBIDDEN
  return insert roles { principal, role }
mutation createSailing(name: text 2..80, departure: time, spaces: int 1..100, weightLimit: int 1000..200000):
  require role() = 'operations_manager' else FORBIDDEN
  require departure > now + 30m else TOO_SOON
  require departure % 60000 = 0 else MINUTE_REQUIRED
  return insert sailings { name, departure, cutoff: departure - 30m, spaces, weightLimit, baseWeightLimit: weightLimit }
mutation book(sailing: sailings, plate: text 2..16, length: int 100..2000, weight: int 100..30000):
  require role() = 'driver' else FORBIDDEN
  s = sailings[sailing] ! else NOT_FOUND
  require now < s.cutoff else BOOKING_CLOSED
  require fits(s, length, weight) else FULL
  b = insert bookings { sailing, driver: viewer, plate, length, weight, state: 'booked' }
  insert holds { sailing, booking: b.id, driver: viewer, length, weight, until: s.cutoff }
  return b
mutation joinStandby(sailing: sailings, plate: text 2..16, length: int 100..2000, weight: int 100..30000):
  require role() = 'driver' else FORBIDDEN
  s = sailings[sailing] ! else NOT_FOUND
  require now < s.departure else DEPARTED
  return insert bookings { sailing, driver: viewer, plate, length, weight, state: 'standby' }
mutation checkIn(booking: bookings, photo: image <=5000000 ?):
  require role() = 'purser' else FORBIDDEN
  b = bookings[booking] ! else NOT_FOUND
  s = sailings[b.sailing] ! else NOT_FOUND
  require now < s.departure else DEPARTED
  require b.state = 'booked' or b.state = 'standby' else INVALID_STATE
  require not b.ready else ALREADY_CHECKED_IN
  require b.state = 'standby' or now < s.cutoff else CHECKIN_CLOSED
  require (b.length <= 600 and b.weight <= 3500) or photo != null else PHOTO_REQUIRED
  if photo != null:
    insert photos { booking, driver: b.driver, photo }
  if b.state = 'booked':
    update holds[booking = booking] { until: null }
    update bookings[booking] { state: 'checked_in', ready: true }
  else:
    update bookings[booking] { ready: true }
mutation assignLane(booking: bookings, lane: int 1..3):
  require role() = 'purser' else FORBIDDEN
  b = bookings[booking] ! else NOT_FOUND
  s = sailings[b.sailing] ! else NOT_FOUND
  require now < s.departure else DEPARTED
  require b.state = 'checked_in' else NOT_CHECKED_IN
  used = (laneLength[b.sailing, lane] ?? 0) - (b.length if b.lane = lane else 0)
  require used + b.length <= 2000 else LANE_FULL
  require weightUsed[b.sailing] <= s.weightLimit else OVERWEIGHT
  update bookings[booking] { lane }
mutation overrideWeight(sailing: sailings, weightLimit: int 1000..200000, reason: text 10..500):
  require role() = 'captain' else FORBIDDEN
  s = sailings[sailing] ! else NOT_FOUND
  require now < s.departure else DEPARTED
  require len(trim(reason)) >= 10 else REASON_REQUIRED
  require weightLimit >= weightUsed[sailing] else BELOW_LOAD
  insert overrides { sailing, captain: viewer, previousLimit: s.weightLimit, newLimit: weightLimit, reason: trim(reason) }
  update sailings[sailing] { weightLimit }

job releaseStandby():
  for s in sailings:
    if now >= s.cutoff and now < s.departure:
      for b in bookings where .sailing = s.id:
        if b.state = 'booked':
          update bookings[b.id] { state: 'released' }
      for b in bookings where .sailing = s.id by .at:
        if b.state = 'standby' and b.ready and fits(s, b.length, b.weight):
          insert holds { sailing: s.id, booking: b.id, driver: b.driver, length: b.length, weight: b.weight, until: null }
          update bookings[b.id] { state: 'checked_in' }
schedule cutoffSweep every 1m: releaseStandby
