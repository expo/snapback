use identity password

-- Roles and enrollment are provisioned by a private operator service, never by signup.
table roles:
  principal: principal
  role: enum('participant', 'nurse', 'investigator', 'data_manager')
  unique principal
  immutable principal, role
  read <- .principal = viewer or viewer = 'service:provision'
  insert <- viewer = 'service:provision'
  online only

table participants:
  owner: principal
  nurse: principal
  code: text 3..20
  name: text 1..80
  enrolledDay: int
  unique owner
  unique code
  immutable owner, nurse, code, name, enrolledDay
  read <- .owner = viewer or .nurse = viewer or exists roles[viewer, role = 'data_manager'] or viewer = 'service:provision'
  insert <- viewer = 'service:provision'
  online only

table entries:
  participant: participants
  code: text 3..20
  diaryDay: int
  severity: int 0..10
  fatigue: int 0..10
  nausea: bool
  revision: int 1..
  savedAt: time
  unique participant, diaryDay
  immutable participant, code, diaryDay
  read <- .participant.owner = viewer or .participant.nurse = viewer or exists roles[viewer, role = 'investigator'] or exists roles[viewer, role = 'data_manager']
  insert <- .participant.owner = viewer
  update <- .participant.owner = viewer
  online only

table unlocks:
  participant: participants
  diaryDay: int
  reason: text 8..500
  manager: principal
  grantedAt: time
  used: bool
  unique participant, diaryDay
  immutable participant, diaryDay
  read <- .participant.owner = viewer or exists roles[viewer, role = 'data_manager']
  insert <- exists roles[viewer, role = 'data_manager']
  update <- .participant.owner = viewer or exists roles[viewer, role = 'data_manager']
  online only

table audits:
  participant: participants
  code: text 3..20
  diaryDay: int
  event: enum('unlock', 'correction')
  actor: principal
  reason: text 8..500
  at: time
  oldSeverity: int 0..10 ?
  oldFatigue: int 0..10 ?
  oldNausea: bool ?
  severity: int 0..10 ?
  fatigue: int 0..10 ?
  nausea: bool ?
  revision: int 0..
  read <- exists roles[viewer, role = 'data_manager']
  insert <- .actor = viewer
  online only

query me():
  return { identity: roles[principal = viewer], today: day(now) }
query myEnrollment():
  require exists roles[viewer, role = 'participant'] else ROLE_REQUIRED
  return participants[owner = viewer]
-- Check every completed day since enrollment so a later check-in cannot erase
-- an earlier consecutive gap. Caller-visible entries are exactly this nurse's
-- assignments, or the manager's complete study data.
fn missedTwoDays(participant: participants, enrolledDay: int):
  for d in range(enrolledDay, day(now) - 1):
    if not exists entries[participant, d] and not exists entries[participant, d + 1]:
      return true
  return false
query participantList(c: cursor ?):
  require exists roles[viewer, role = 'nurse'] or exists roles[viewer, role = 'data_manager'] else ROLE_REQUIRED
  return participants first 100 by .id after c { id, code, name, enrolledDay, missedTwo: missedTwoDays(.id, .enrolledDay) }
query diary(participant: participants ?, c: cursor ?):
  r = roles[principal = viewer] ! else ROLE_REQUIRED
  if r.role = 'participant':
    p = participants[owner = viewer] ! else NOT_ENROLLED
    require participant = null or participant = p.id else PRIVATE_DIARY
    return entries where .participant = p.id last 100 by .savedAt after c { id, code, diaryDay, severity, fatigue, nausea, revision, savedAt }
  if r.role = 'nurse':
    require participant != null else CHOOSE_PARTICIPANT
    p = participants[participant] ! else NOT_FOUND
    require p.nurse = viewer else PRIVATE_DIARY
    return entries where .participant = p.id last 100 by .savedAt after c { id, code, diaryDay, severity, fatigue, nausea, revision, savedAt }
  return entries last 100 by .savedAt after c { id, code, diaryDay, severity, fatigue, nausea, revision, savedAt }
query entryFor(entry: entries):
  require exists roles[principal = viewer] else ROLE_REQUIRED
  return entries[entry] { id, code, diaryDay, severity, fatigue, nausea, revision, savedAt }
query myUnlocks(c: cursor ?):
  require exists roles[viewer, role = 'participant'] or exists roles[viewer, role = 'data_manager'] else ROLE_REQUIRED
  if exists roles[viewer, role = 'participant']:
    p = participants[owner = viewer] ! else NOT_ENROLLED
    return unlocks where .participant = p.id first 100 by .id after c
  return unlocks first 100 by .id after c
query auditTrail(c: cursor ?):
  require exists roles[viewer, role = 'data_manager'] else ROLE_REQUIRED
  return audits last 100 by .at after c

mutation provisionRole(principal: principal, role: enum('participant', 'nurse', 'investigator', 'data_manager')):
  require viewer = 'service:provision' else OPERATOR_ONLY
  return insert roles { principal, role }
mutation enroll(owner: principal, nurse: principal, code: text 3..20, name: text 1..80):
  require viewer = 'service:provision' else OPERATOR_ONLY
  require exists roles[owner, role = 'participant'] else PARTICIPANT_REQUIRED
  require exists roles[nurse, role = 'nurse'] else NURSE_REQUIRED
  return insert participants { owner, nurse, code, name, enrolledDay: day(now) }
mutation saveDay(diaryDay: int, severity: int 0..10, fatigue: int 0..10, nausea: bool, reason: text <=500):
  require exists roles[viewer, role = 'participant'] else ROLE_REQUIRED
  p = participants[owner = viewer] ! else NOT_ENROLLED
  require diaryDay >= p.enrolledDay else BEFORE_ENROLLMENT
  require diaryDay <= day(now) else FUTURE_DAY
  old = entries[p.id, diaryDay]
  if old != null:
    require count(trim(reason)) >= 8 else CORRECTION_REASON_REQUIRED
  if diaryDay < day(now) - 1:
    u = unlocks[p.id, diaryDay] ! else DAY_LOCKED
    require not u.used else DAY_LOCKED
    require count(trim(reason)) >= 8 else CORRECTION_REASON_REQUIRED
    update unlocks[u.id] { used: true }
  revision = 1
  if old != null:
    revision = old.revision + 1
  if old != null:
    update entries[old.id] { severity, fatigue, nausea, revision, savedAt: now }
  else:
    insert entries { participant: p.id, code: p.code, diaryDay, severity, fatigue, nausea, revision, savedAt: now }
  if old != null or diaryDay < day(now) - 1:
    insert audits { participant: p.id, code: p.code, diaryDay, event: 'correction', actor: viewer, reason, at: now, oldSeverity: old.severity if old != null else null, oldFatigue: old.fatigue if old != null else null, oldNausea: old.nausea if old != null else null, severity, fatigue, nausea, revision }
  return entries[p.id, diaryDay] { id, code, diaryDay, severity, fatigue, nausea, revision, savedAt }
mutation unlockDay(participant: participants, diaryDay: int, reason: text 8..500):
  require exists roles[viewer, role = 'data_manager'] else ROLE_REQUIRED
  require count(trim(reason)) >= 8 else REASON_REQUIRED
  p = participants[participant] ! else NOT_FOUND
  require diaryDay >= p.enrolledDay else BEFORE_ENROLLMENT
  require diaryDay < day(now) - 1 else NOT_LOCKED_DAY
  upsert unlocks[participant, diaryDay] { participant, diaryDay, reason, manager: viewer, grantedAt: now, used: false }
  insert audits { participant, code: p.code, diaryDay, event: 'unlock', actor: viewer, reason, at: now, oldSeverity: null, oldFatigue: null, oldNausea: null, severity: null, fatigue: null, nausea: null, revision: 0 }
  return null
