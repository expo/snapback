-- Harvest Bin Tickets.
-- Picking crews log filled bins; the weighmaster issues weigh tickets
-- (block + weight + scale photo). Growers read only their own blocks'
-- tickets; the winemaker reads everything with live tonnage per block.
-- Blocks over contract are flagged and later bins are held for the
-- winemaker's release/reject decision. Only the vineyard manager corrects
-- tickets, and each correction preserves the original values.
use identity password
use personas alice, bob, carol, dave, erin, frank, grace, heidi, ivan, judy

-- One row per user: crew | weighmaster | grower | winemaker | manager.
-- The first manager is enrolled by the service:ops seat (production
-- bootstrap); afterwards managers grant roles. See guide deploy.
table roles:
  principal: principal
  role: enum('crew', 'weighmaster', 'grower', 'winemaker', 'manager')
  unique principal
  cap 500
  read <- .principal = viewer or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'manager'] or viewer = 'service:ops'
  update <- exists roles[viewer, role = 'manager'] or viewer = 'service:ops'
  delete <- exists roles[viewer, role = 'manager']
  online only

-- Discoverable handle directory so a manager can find growers' principals.
table directory:
  principal: principal
  handle: text 3..20
  unique principal
  unique handle
  cap 500
  public 'handles are discoverable so managers can assign blocks and roles'
  insert <- .principal = viewer
  update <- .principal = viewer
  delete <- deny
  online only

-- Vineyard blocks. The grower column owns the privacy boundary for growers;
-- all staff roles read every block so crews can log and the weighmaster
-- can weigh. Only the manager creates blocks or moves the contract.
table blocks:
  name: text 3..60
  contractedKg: int 100..1000000
  grower: principal
  cap 200
  immutable grower
  read <- .grower = viewer or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'weighmaster'] or exists roles[viewer, role = 'winemaker'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'manager']
  update <- exists roles[viewer, role = 'manager']
  delete <- deny
  online only

-- Bin fills logged by the picking crew, awaiting weighing.
table fills:
  block: blocks
  grower: principal
  author: principal
  bins: int 1..100
  at: time default now
  cap 5000 by block
  immutable block, grower, author, bins, at
  read <- .author = viewer or .grower = viewer or exists roles[viewer, role = 'weighmaster'] or exists roles[viewer, role = 'winemaker'] or exists roles[viewer, role = 'manager']
  insert <- .author = viewer
  update <- deny
  delete <- deny
  online only

-- Weigh tickets. Growers read only their blocks' tickets; weighmaster,
-- winemaker and manager read all. Crew members read none (conservative:
-- the spec grants ticket reads only to growers and the winemaker, plus
-- the staff who issue and correct them).
-- status: open (counts) | held (over-contract, awaiting winemaker) |
-- released (held then accepted, counts) | rejected (held then refused).
table tickets:
  block: blocks
  grower: principal
  weightKg: int 1..10000
  photo: image <=5000000 ?
  status: enum('open', 'held', 'released', 'rejected') default 'open'
  issuedBy: principal
  at: time default now
  cap 5000 by block
  immutable block, grower, issuedBy, at
  read <- .grower = viewer or exists roles[viewer, role = 'weighmaster'] or exists roles[viewer, role = 'winemaker'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'weighmaster']
  update <- exists roles[viewer, role = 'manager'] or exists roles[viewer, role = 'winemaker']
  delete <- deny
  online only

-- Immutable correction history: the ticket's original values plus who
-- corrected, when, and why. Only managers write; ticket readers read.
-- The ticket's photo never changes, so the original photo needs no copy:
-- it stays on the ticket. History keeps the originals of what can change.
table corrections:
  ticket: tickets
  block: blocks
  grower: principal
  weightKg: int 1..10000
  status: enum('open', 'held', 'released', 'rejected')
  manager: principal
  note: text 1..280
  at: time default now
  cap 200 by ticket
  immutable ticket, block, grower, weightKg, status, manager, note, at
  read <- .grower = viewer or exists roles[viewer, role = 'weighmaster'] or exists roles[viewer, role = 'winemaker'] or exists roles[viewer, role = 'manager']
  insert <- exists roles[viewer, role = 'manager']
  update <- deny
  delete <- deny
  online only

query myRole():
  return roles[principal = viewer]

query myHandle():
  return directory[principal = viewer]

query directory(c: cursor ?):
  return directory first 50 by .handle after c

query blocks(c: cursor ?):
  if exists roles[viewer, role = 'grower']:
    return blocks where .grower = viewer first 50 by .id after c
  return blocks first 50 by .id after c

query tickets(c: cursor ?):
  if exists roles[viewer, role = 'grower']:
    return tickets where .grower = viewer last 100 by .id after c
  require exists roles[viewer, role = 'weighmaster'] or exists roles[viewer, role = 'winemaker'] or exists roles[viewer, role = 'manager'] else NOT_TICKET_STAFF
  return tickets last 100 by .id after c

query ticketsFor(block: blocks, c: cursor ?):
  b = blocks[block] ! else NOT_FOUND
  return tickets where .block = block last 100 by .id after c

query fillsFor(block: blocks, c: cursor ?):
  b = blocks[block] ! else NOT_FOUND
  if exists roles[viewer, role = 'crew']:
    return fills where .block = block and .author = viewer last 100 by .id after c
  return fills where .block = block last 100 by .id after c

query holds(c: cursor ?):
  require exists roles[viewer, role = 'winemaker'] else NOT_WINEMAKER
  return tickets where .status = 'held' last 100 by .id after c

query correctionsFor(ticket: tickets, c: cursor ?):
  t = tickets[ticket] ! else NOT_FOUND
  return corrections where .ticket = ticket last 100 by .id after c

-- Live tonnage: open + released tickets count; held and rejected do not.
-- over is the over-contract flag for the block.
query tonnage(block: blocks):
  b = blocks[block] ! else NOT_FOUND
  if exists roles[viewer, role = 'grower']:
    total = sum(tickets where .block = block and .grower = viewer and (.status = 'open' or .status = 'released'), .weightKg)
    return { total, contracted: b.contractedKg, over: total > b.contractedKg }
  require exists roles[viewer, role = 'weighmaster'] or exists roles[viewer, role = 'winemaker'] or exists roles[viewer, role = 'manager'] else NOT_TONNAGE_STAFF
  total = sum(tickets where .block = block and (.status = 'open' or .status = 'released'), .weightKg)
  return { total, contracted: b.contractedKg, over: total > b.contractedKg }

mutation saveHandle(handle: text 3..20):
  return upsert directory[viewer] { handle }

mutation grantRole(who: principal, role: enum('crew', 'weighmaster', 'grower', 'winemaker', 'manager')):
  require exists roles[viewer, role = 'manager'] or viewer = 'service:ops' else NOT_MANAGER
  return upsert roles[who] { role }

mutation createBlock(name: text 3..60, contractedKg: int 100..1000000, grower: principal):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return insert blocks { name, contractedKg, grower }

mutation setContract(block: blocks, contractedKg: int 100..1000000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  b = blocks[block] ! else NOT_FOUND
  update blocks[block] { contractedKg }
  return null

mutation logFill(block: blocks, bins: int 1..100):
  require exists roles[viewer, role = 'crew'] else NOT_CREW
  b = blocks[block] ! else NOT_FOUND
  return insert fills { author: viewer, block, grower: b.grower, bins }

mutation issueTicket(block: blocks, weightKg: int 1..10000, photo: image <=5000000 ?):
  require exists roles[viewer, role = 'weighmaster'] else NOT_WEIGHMASTER
  require photo != null else PHOTO_REQUIRED
  b = blocks[block] ! else NOT_FOUND
  total = sum(tickets where .block = block and (.status = 'open' or .status = 'released'), .weightKg)
  over = total > b.contractedKg
  return insert tickets { block, grower: b.grower, weightKg, photo, status: 'held' if over else 'open', issuedBy: viewer }

-- Only the recorded weight is correctable; block, photo, issuer and time
-- are immutable facts of the weighing event. The original weight and
-- photo are preserved on the corrections row.
mutation correctTicket(ticket: tickets, weightKg: int 1..10000, note: text 1..280):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  t = tickets[ticket] ! else NOT_FOUND
  require t.status != 'rejected' else TICKET_REJECTED
  insert corrections { ticket, block: t.block, grower: t.grower, weightKg: t.weightKg, status: t.status, manager: viewer, note }
  update tickets[ticket] { weightKg }
  return null

mutation decideHeld(ticket: tickets, release: bool):
  require exists roles[viewer, role = 'winemaker'] else NOT_WINEMAKER
  t = tickets[ticket] ! else NOT_FOUND
  require t.status = 'held' else NOT_HELD
  update tickets[ticket] { status: 'released' if release else 'rejected' }
  return null
