-- Fly Rail Cue Locks.
-- Roles: technical_director, stage_manager, fly_operator,
-- production_manager, visiting_crew. Roster in crew_roles.
-- Auth: real password accounts (use identity password). No personas.
-- All tables online only: crew tablets are online; live queries show
-- lockouts in real time with no device replica weight.
use identity password

table crew_roles:
  principal: principal
  role: enum('technical_director', 'stage_manager', 'fly_operator', 'production_manager', 'visiting_crew')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:ops' or exists crew_roles[viewer]
  insert <- viewer = 'service:ops' or exists crew_roles[viewer, role = 'technical_director']
  update <- viewer = 'service:ops' or exists crew_roles[viewer, role = 'technical_director']
  delete <- viewer = 'service:ops' or exists crew_roles[viewer, role = 'technical_director']
  cap 50
  online only

table shows:
  title: text 1..120
  showDate: time
  isCurrent: bool default false
  createdBy: principal
  immutable createdBy
  read <- exists crew_roles[viewer]
  insert <- exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director']
  update <- exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director']
  delete <- deny
  cap 200
  online only

table line_sets:
  name: text 1..80
  description: text <=500
  createdBy: principal
  immutable createdBy
  read <- exists crew_roles[viewer]
  insert <- exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director']
  update <- exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director']
  delete <- deny
  cap 100
  online only

table lockouts:
  lineSet: line_sets
  reason: text 1..280
  lockedBy: principal
  lockedAt: time default now
  active: bool default true
  clearedAt: time ?
  clearedBy: principal ?
  immutable lineSet, lockedBy, lockedAt, reason
  -- Live on every crew tablet: the whole roster reads every lockout.
  read <- exists crew_roles[viewer]
  insert <- exists crew_roles[viewer, role = 'fly_operator'] or exists crew_roles[viewer, role = 'technical_director']
  -- Clearable only by the operator who locked it or the TD (mutation
  -- checks which; the rule admits exactly those two lanes).
  update <- .lockedBy = viewer or exists crew_roles[viewer, role = 'technical_director']
  delete <- deny
  cap 1000
  online only

table cues:
  show: shows
  lineSet: line_sets
  number: int 1..500
  title: text 1..120
  description: text <=500
  status: enum('pending', 'called', 'done') default 'pending'
  calledAt: time ?
  doneBy: principal ?
  doneAt: time ?
  createdBy: principal
  immutable show, lineSet, createdBy
  -- Visiting crew see only the current show's cues: current-show rows are
  -- readable roster-wide; older shows stay readable to staff lanes only.
  -- The leading roster probe names the caller, so signed-in users with no
  -- role row read nothing.
  read <- exists crew_roles[viewer] and (.show.isCurrent = true or exists crew_roles[viewer, role = 'technical_director'] or exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'fly_operator'] or exists crew_roles[viewer, role = 'production_manager'])
  insert <- exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director']
  update <- exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] or exists crew_roles[viewer, role = 'fly_operator']
  delete <- deny
  cap 1000 by show
  online only

table incident_reports:
  show: shows
  title: text 1..120
  body: text 1..2000
  photo: image <=10000000 ?
  reportedBy: principal
  at: time default now
  immutable show, reportedBy, at
  -- Visible only to the technical director and production manager. The
  -- photo asset inherits this row's read rule when served.
  read <- exists crew_roles[viewer, role = 'technical_director'] or exists crew_roles[viewer, role = 'production_manager']
  insert <- exists crew_roles[viewer, role = 'fly_operator'] or exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] or exists crew_roles[viewer, role = 'production_manager']
  update <- deny
  delete <- deny
  cap 500 by show
  online only

query myRole():
  return crew_roles[principal = viewer]

query showsList(c: cursor ?):
  -- Visiting crew see only the current show; other lanes see the season.
  if exists crew_roles[viewer, role = 'visiting_crew']:
    return shows where .isCurrent = true first 50 by .id after c
  return shows last 50 by .id after c

query currentShow():
  return shows where .isCurrent = true first 1 by .id

query lineSetList(c: cursor ?):
  return line_sets last 100 by .id after c

query cuesForShow(show: shows, c: cursor ?):
  s = shows[show] ! else NOT_FOUND
  if exists crew_roles[viewer, role = 'visiting_crew']:
    require s.isCurrent else NOT_CURRENT_SHOW
  return cues where .show = show first 200 by .number after c

query lockoutList(c: cursor ?):
  return lockouts last 200 by .id after c

query incidentsForShow(show: shows, c: cursor ?):
  require exists crew_roles[viewer, role = 'technical_director'] or exists crew_roles[viewer, role = 'production_manager'] else NOT_PRIVILEGED
  return incident_reports where .show = show last 100 by .id after c

mutation grantRole(who: principal, role: enum('technical_director', 'stage_manager', 'fly_operator', 'production_manager', 'visiting_crew')):
  require exists crew_roles[viewer, role = 'technical_director'] or viewer = 'service:ops' else NOT_TD
  return upsert crew_roles[who] { principal: who, role }

mutation addShow(title: text 1..120, showDate: time):
  require exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_SM
  return insert shows { title, showDate, isCurrent: false, createdBy: viewer }

mutation setCurrentShow(show: shows):
  require exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_SM
  s = shows[show] ! else NOT_FOUND
  update shows[show] { isCurrent: true }
  return null

mutation clearCurrentShow(show: shows):
  require exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_SM
  s = shows[show] ! else NOT_FOUND
  update shows[show] { isCurrent: false }
  return null

mutation addLineSet(name: text 1..80, description: text <=500):
  require exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_SM
  return insert line_sets { name, description, createdBy: viewer }

mutation publishCue(show: shows, lineSet: line_sets, number: int 1..500, title: text 1..120, description: text <=500):
  require exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_SM
  s = shows[show] ! else NOT_FOUND
  ls = line_sets[lineSet] ! else NOT_FOUND
  return insert cues { show, lineSet, number, title, description, status: 'pending', createdBy: viewer }

mutation callCue(cue: cues):
  require exists crew_roles[viewer, role = 'stage_manager'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_SM
  cu = cues[cue] ! else NOT_FOUND
  require cu.status = 'pending' else CUE_NOT_PENDING
  update cues[cue] { status: 'called', calledAt: now }
  return null

mutation markCueDone(cue: cues):
  require exists crew_roles[viewer, role = 'fly_operator'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_OPERATOR
  cu = cues[cue] ! else NOT_FOUND
  require cu.status = 'called' else CUE_NOT_CALLED
  update cues[cue] { status: 'done', doneBy: viewer, doneAt: now }
  return null

mutation lockLineSet(lineSet: line_sets, reason: text 1..280):
  require exists crew_roles[viewer, role = 'fly_operator'] or exists crew_roles[viewer, role = 'technical_director'] else NOT_OPERATOR
  ls = line_sets[lineSet] ! else NOT_FOUND
  return insert lockouts { lineSet, reason, lockedBy: viewer, lockedAt: now, active: true }

mutation clearLockout(lockout: lockouts):
  l = lockouts[lockout] ! else NOT_FOUND
  require l.active else ALREADY_CLEARED
  require l.lockedBy = viewer or exists crew_roles[viewer, role = 'technical_director'] else NOT_YOUR_LOCKOUT
  update lockouts[lockout] { active: false, clearedAt: now, clearedBy: viewer }
  return null

mutation fileIncident(show: shows, title: text 1..120, body: text 1..2000):
  require exists crew_roles[viewer] else NOT_CREW
  require not exists crew_roles[viewer, role = 'visiting_crew'] else NOT_VISITING
  s = shows[show] ! else NOT_FOUND
  return insert incident_reports { show, title, body, reportedBy: viewer, at: now }

mutation fileIncidentPhoto(show: shows, title: text 1..120, body: text 1..2000, photo: image <=10000000):
  require exists crew_roles[viewer] else NOT_CREW
  require not exists crew_roles[viewer, role = 'visiting_crew'] else NOT_VISITING
  s = shows[show] ! else NOT_FOUND
  return insert incident_reports { show, title, body, photo, reportedBy: viewer, at: now }
