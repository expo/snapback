use identity password

table people:
  principal: principal
  name: text 1..80
  role: enum('artist', 'panelist', 'director', 'owner')
  unique principal
  immutable principal
  read <- .principal = viewer or exists people[principal = viewer, role = 'director'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table walls:
  title: text 1..100
  address: text 1..180
  description: text 1..1000
  owner: principal
  immutable owner
  read <- allow
  insert <- exists people[principal = viewer, role = 'director']
  online only

table applications:
  wall: walls
  artist: principal
  title: text 1..100
  statement: text 1..2000
  sketch: file <=5000000 ('image/png', 'image/jpeg', 'application/pdf')
  startsAt: time
  endsAt: time
  submittedAt: time default now
  reviewClosed: bool default false
  status: enum('submitted', 'approved', 'rejected', 'permitted', 'started', 'expired') default 'submitted'
  approvedAt: time ?
  deadline: time ?
  decidedBy: principal ?
  permitNumber: text 1..80 ?
  issuedBy: principal ?
  startedAt: time ?
  immutable wall, artist, title, statement, sketch, startsAt, endsAt, submittedAt
  read <- .artist = viewer or .wall.owner = viewer or exists people[principal = viewer, role = 'panelist'] or exists people[principal = viewer, role = 'director']
  insert <- .artist = viewer and exists people[principal = viewer, role = 'artist'] and .status = 'submitted' and .reviewClosed = false
  update <- .artist = viewer or exists people[principal = viewer, role = 'director']
  online only

table scores:
  application: applications
  panelist: principal
  value: int 1..10
  comment: text 1..1000
  unique application, panelist
  immutable application, panelist
  read <- .panelist = viewer or (.application.reviewClosed = true and (exists people[principal = viewer, role = 'panelist'] or exists people[principal = viewer, role = 'director']))
  insert <- .panelist = viewer and exists people[principal = viewer, role = 'panelist'] and .application.reviewClosed = false
  update <- .panelist = viewer and exists people[principal = viewer, role = 'panelist'] and .application.reviewClosed = false
  online only

mutation provision(principal: principal, name: text 1..80, role: enum('artist', 'panelist', 'director', 'owner')):
  require viewer = 'service:ops' else FORBIDDEN
  return insert people { principal, name, role }

query me():
  return people[principal = viewer]

query owners(c: cursor ?):
  require exists people[principal = viewer, role = 'director'] else FORBIDDEN
  return people where .role = 'owner' first 100 by .id after c

query listWalls(c: cursor ?):
  return walls first 50 by .id after c

query wallById(wall: walls):
  return walls[wall]

mutation createWall(title: text 1..100, address: text 1..180, description: text 1..1000, owner: principal):
  require exists people[principal = viewer, role = 'director'] else FORBIDDEN
  require exists people[principal = owner, role = 'owner'] else OWNER_REQUIRED
  return insert walls { title, address, description, owner }

query listApplications(c: cursor ?):
  return applications last 50 by .id after c

query applicationById(application: applications):
  return applications[application]

query applicationScores(application: applications, c: cursor ?):
  a = applications[application] ! else NOT_FOUND
  require exists people[principal = viewer, role = 'panelist'] or exists people[principal = viewer, role = 'director'] else FORBIDDEN
  return scores where .application = application first 50 by .id after c

query scoreById(score: scores):
  return scores[score]

query reservations(wall: walls, c: cursor ?):
  require exists walls[wall] else NOT_FOUND
  return applications where .wall = wall and (.status = 'started' or ((.status = 'approved' or .status = 'permitted') and (.deadline ?? 0) > now)) first 50 by .id after c { id, wall, artist, title, startsAt, endsAt, status, deadline }

mutation apply(wall: walls, title: text 1..100, statement: text 1..2000, sketch: file <=5000000 ('image/png', 'image/jpeg', 'application/pdf'), startsAt: time, endsAt: time):
  require exists people[principal = viewer, role = 'artist'] else FORBIDDEN
  require exists walls[wall] else NOT_FOUND
  require startsAt > now and startsAt <= now + 180d else BAD_START
  require endsAt > startsAt and endsAt <= startsAt + 90d else BAD_END
  return insert applications { wall, artist: viewer, title, statement, sketch, startsAt, endsAt }

mutation scoreApplication(application: applications, value: int 1..10, comment: text 1..1000):
  require exists people[principal = viewer, role = 'panelist'] else FORBIDDEN
  a = applications[application] ! else NOT_FOUND
  require not a.reviewClosed and a.status = 'submitted' else REVIEW_CLOSED
  upsert scores[application = application, panelist = viewer] { application, panelist: viewer, value, comment }
  return null

mutation closeReview(application: applications):
  require exists people[principal = viewer, role = 'director'] else FORBIDDEN
  a = applications[application] ! else NOT_FOUND
  require not a.reviewClosed and a.status = 'submitted' else REVIEW_CLOSED
  update applications[application] { reviewClosed: true }
  return null

mutation decide(application: applications, decision: enum('approved', 'rejected')):
  require exists people[principal = viewer, role = 'director'] else FORBIDDEN
  a = applications[application] ! else NOT_FOUND
  require a.reviewClosed and a.status = 'submitted' else REVIEW_NOT_READY
  if decision = 'approved':
    require a.startsAt > now else DATE_PASSED
    require count(applications where .wall = a.wall and .id != application and .startsAt < a.endsAt and .endsAt > a.startsAt and (.status = 'started' or ((.status = 'approved' or .status = 'permitted') and (.deadline ?? 0) > now))) = 0 else WALL_RESERVED
    update applications[application] { status: 'approved', approvedAt: now, deadline: now + 30d, decidedBy: viewer }
  else:
    update applications[application] { status: 'rejected', decidedBy: viewer }
  return null

mutation issuePermit(application: applications, permitNumber: text 1..80):
  require exists people[principal = viewer, role = 'director'] else FORBIDDEN
  a = applications[application] ! else NOT_FOUND
  require a.status = 'approved' else NOT_APPROVED
  require (a.deadline ?? 0) > now and a.endsAt > now else RESERVATION_EXPIRED
  update applications[application] { status: 'permitted', permitNumber, issuedBy: viewer }
  return null

mutation startMural(application: applications):
  require exists people[principal = viewer, role = 'artist'] else FORBIDDEN
  a = applications[application] ! else NOT_FOUND
  require a.artist = viewer else FORBIDDEN
  require a.status = 'permitted' else PERMIT_REQUIRED
  require now >= a.startsAt and now < a.endsAt else OUTSIDE_DATES
  require (a.deadline ?? 0) > now else RESERVATION_EXPIRED
  update applications[application] { status: 'started', startedAt: now }
  return null

job expireReservations():
  for a in applications:
    if (a.status = 'approved' or a.status = 'permitted') and (a.deadline ?? 0) <= now:
      update applications[a.id] { status: 'expired' }

schedule expiry every 1m: expireReservations
