-- Chimney Sweep Reports.
-- Roles: homeowner, sweep, landlord, master (master sweep).
-- A chimney service sends sweeps to homes; each sweep files an inspection
-- report with camera photos and a pass / repair / do-not-use rating.
-- Do-not-use ratings appear live on the office board (sweeps + master).
-- Repair quotes expire 30 days after issue (expire at .expiresAt).
-- Homeowners see only their own chimneys and reports; sweeps see only their
-- assigned jobs and addresses; landlords see reports for their rental units
-- but never tenants' contact details (contact lives on chimneys, which
-- landlords cannot read). Only the master sweep can change a rating after it
-- is filed, recording the reason in amendments and keeping originalRating.
use identity password

table roles:
  principal: principal
  role: enum('homeowner', 'sweep', 'landlord', 'master')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'master'] or viewer = 'service:operator'
  insert <- (.principal = viewer and (.role = 'homeowner' or .role = 'landlord')) or exists roles[viewer, role = 'master'] or viewer = 'service:operator' or (.principal = viewer and .role = 'master' and exists office[1, master = viewer])
  update <- exists roles[viewer, role = 'master'] or viewer = 'service:operator'
  delete <- exists roles[viewer, role = 'master'] or viewer = 'service:operator'
  online only

-- One row claims the office: whoever inserts slot 1 first becomes master.
table office:
  slot: int
  master: principal
  unique slot else OFFICE_TAKEN 'The office already has a master sweep.'
  read <- .master = viewer or exists roles[viewer, role = 'master']
  insert <- .master = viewer
  update <- deny
  delete <- deny
  online only

table chimneys:
  owner: principal
  address: text 1..200
  tenantName: text 1..120 ?
  tenantPhone: text 1..40 ?
  tenantEmail: text 1..120 ?
  createdAt: time default now
  immutable owner
  read <- .owner = viewer or exists roles[viewer, role = 'master'] or exists assignments[chimney = .id, sweep = viewer]
  insert <- exists roles[viewer, role = 'master']
  update <- .owner = viewer or exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'master']
  cap 1000
  online only

table assignments:
  chimney: chimneys on delete cascade
  sweep: principal
  scheduledAt: time
  status: enum('open', 'done') default 'open'
  unique chimney, sweep else ALREADY_ASSIGNED 'This sweep is already assigned to this chimney.'
  immutable chimney, sweep
  read <- .sweep = viewer or exists roles[viewer, role = 'master'] or exists chimneys[.chimney, owner = viewer]
  insert <- exists roles[viewer, role = 'master']
  update <- exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'master']
  cap 20 by chimney
  cap 2000
  online only

table rentalUnits:
  chimney: chimneys on delete cascade
  landlord: principal
  label: text 1..80
  unique chimney else ALREADY_A_UNIT 'This chimney is already registered as a rental unit.'
  immutable chimney
  read <- .landlord = viewer or exists roles[viewer, role = 'master'] or exists assignments[chimney = .chimney, sweep = viewer]
  insert <- exists roles[viewer, role = 'master']
  update <- exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'master']
  cap 1000
  online only

table reports:
  chimney: chimneys on delete cascade
  author: principal
  homeowner: principal
  landlord: principal
  rating: enum('pass', 'repair', 'do-not-use')
  originalRating: enum('pass', 'repair', 'do-not-use')
  photos: [image <=5000000] 1..4
  notes: text 1..1000 ?
  inspectedAt: time default now
  immutable chimney, author, homeowner, landlord, originalRating, photos, inspectedAt
  read <- .homeowner = viewer or .landlord = viewer or .author = viewer or exists roles[viewer, role = 'master'] or exists assignments[chimney = .chimney, sweep = viewer] or (exists roles[viewer, role = 'sweep'] and .rating = 'do-not-use')
  insert <- .author = viewer and (exists assignments[chimney = .chimney, sweep = viewer] or exists roles[viewer, role = 'master'])
  update <- exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'master']
  cap 200 by chimney
  cap 5000
  online only

table amendments:
  report: reports on delete cascade
  chimney: chimneys on delete cascade
  homeowner: principal
  landlord: principal
  author: principal
  oldRating: enum('pass', 'repair', 'do-not-use')
  newRating: enum('pass', 'repair', 'do-not-use')
  reason: text 1..500
  amendedBy: principal
  at: time default now
  immutable report, chimney, homeowner, landlord, author, oldRating, newRating, reason, amendedBy, at
  read <- .homeowner = viewer or .landlord = viewer or .author = viewer or exists roles[viewer, role = 'master'] or exists assignments[chimney = .chimney, sweep = viewer] or (exists roles[viewer, role = 'sweep'] and .newRating = 'do-not-use')
  insert <- exists roles[viewer, role = 'master'] and .homeowner = .report.homeowner and .landlord = .report.landlord and .author = .report.author and .chimney = .report.chimney
  update <- deny
  delete <- deny
  cap 20 by report
  cap 20 by chimney
  cap 5000
  online only

table quotes:
  report: reports on delete cascade
  chimney: chimneys on delete cascade
  homeowner: principal
  landlord: principal
  amount: money USD
  issuedAt: time default now
  expiresAt: time
  decision: enum('pending', 'accepted', 'declined') default 'pending'
  immutable report, chimney, homeowner, landlord, amount, issuedAt, expiresAt
  read <- .homeowner = viewer or .landlord = viewer or exists roles[viewer, role = 'master']
  insert <- exists roles[viewer, role = 'master']
  update <- .homeowner = viewer or exists roles[viewer, role = 'master']
  delete <- exists roles[viewer, role = 'master']
  expire at .expiresAt
  cap 20 by report
  cap 20 by chimney
  cap 5000
  online only

-- Independent privacy intent (guide security).
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'master'] or viewer = 'service:operator'
invariant chimneys.read only .owner = viewer or exists roles[viewer, role = 'master'] or exists assignments[chimney = .id, sweep = viewer]
invariant reports.read only .homeowner = viewer or .landlord = viewer or .author = viewer or exists roles[viewer, role = 'master'] or exists assignments[chimney = .chimney, sweep = viewer] or (exists roles[viewer, role = 'sweep'] and .rating = 'do-not-use')
invariant quotes.read only .homeowner = viewer or .landlord = viewer or exists roles[viewer, role = 'master']

query whoAmI():
  return viewer

query myRole():
  return roles[viewer]

query myChimneys(c: cursor ?):
  return chimneys where .owner = viewer last 50 by .id after c

query allChimneys(c: cursor ?):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  return chimneys last 50 by .id after c

query myJobs(c: cursor ?):
  return assignments where .sweep = viewer last 50 by .id after c { id, scheduledAt, status, home: chimneys[.chimney] }

query chimneyJobs(chimney: chimneys, c: cursor ?):
  c0 = chimneys[chimney] ! else NOT_FOUND
  return assignments where .chimney = chimney last 50 by .id after c

query myUnits(c: cursor ?):
  return rentalUnits where .landlord = viewer last 50 by .id after c

query myReports(c: cursor ?):
  return reports where .homeowner = viewer last 50 by .inspectedAt after c

query unitReports(c: cursor ?):
  return reports where .landlord = viewer last 50 by .inspectedAt after c

query chimneyReports(chimney: chimneys, c: cursor ?):
  c0 = chimneys[chimney] ! else NOT_FOUND
  return reports where .chimney = chimney last 50 by .inspectedAt after c

query reportDetail(report: reports):
  return reports[report]

query amendmentsFor(report: reports, c: cursor ?):
  r = reports[report] ! else NOT_FOUND
  return amendments where .report = report first 50 by .at after c

query officeBoard(c: cursor ?):
  require exists roles[viewer, role = 'master'] or exists roles[viewer, role = 'sweep'] else NOT_OFFICE
  return reports where .rating = 'do-not-use' last 50 by .inspectedAt after c

query myQuotes(c: cursor ?):
  return quotes where .homeowner = viewer last 50 by .issuedAt after c

query landlordQuotes(c: cursor ?):
  return quotes where .landlord = viewer last 50 by .issuedAt after c

query quotesFor(report: reports, c: cursor ?):
  r = reports[report] ! else NOT_FOUND
  return quotes where .report = report last 20 by .issuedAt after c

mutation register(role: enum('homeowner', 'landlord')):
  return upsert roles[viewer] { principal: viewer, role }

mutation claimMaster():
  insert office { slot: 1, master: viewer }
  return insert roles { principal: viewer, role: 'master' }

mutation provision(principal: principal, role: enum('homeowner', 'sweep', 'landlord', 'master')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation grantRole(who: principal, role: enum('homeowner', 'sweep', 'landlord', 'master')):
  require exists roles[viewer, role = 'master'] or viewer = 'service:operator' else NOT_MASTER
  return upsert roles[who] { principal: who, role }

mutation addChimney(owner: principal, address: text 1..200, tenantName: text 1..120 ?, tenantPhone: text 1..40 ?, tenantEmail: text 1..120 ?):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  return insert chimneys { owner, address, tenantName, tenantPhone, tenantEmail }

mutation updateContact(chimney: chimneys, tenantName: text 1..120 ?, tenantPhone: text 1..40 ?, tenantEmail: text 1..120 ?):
  c = chimneys[chimney] ! else NOT_FOUND
  require c.owner = viewer or exists roles[viewer, role = 'master'] else NOT_OWNER
  update chimneys[chimney] { tenantName: tenantName ?? c.tenantName, tenantPhone: tenantPhone ?? c.tenantPhone, tenantEmail: tenantEmail ?? c.tenantEmail }
  return null

mutation assignJob(chimney: chimneys, sweep: principal, scheduledAt: time):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  require exists roles[sweep, role = 'sweep'] else NOT_A_SWEEP
  c = chimneys[chimney] ! else NOT_FOUND
  return insert assignments { chimney, sweep, scheduledAt, status: 'open' }

mutation updateJob(assignment: assignments, scheduledAt: time ?, status: enum('open', 'done') ?):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  a = assignments[assignment] ! else NOT_FOUND
  update assignments[assignment] { scheduledAt: scheduledAt ?? a.scheduledAt, status: status ?? a.status }
  return null

mutation linkUnit(chimney: chimneys, landlord: principal, label: text 1..80):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  require exists roles[landlord, role = 'landlord'] else NOT_A_LANDLORD
  c = chimneys[chimney] ! else NOT_FOUND
  return upsert rentalUnits[chimney] { chimney, landlord, label }

mutation fileReport(chimney: chimneys, rating: enum('pass', 'repair', 'do-not-use'), photos: [image <=5000000] 1..4, notes: text 1..1000 ?):
  c = chimneys[chimney] ! else NOT_FOUND
  require exists assignments[chimney = chimney, sweep = viewer] or exists roles[viewer, role = 'master'] else NOT_ASSIGNED
  u = rentalUnits[chimney]
  return insert reports { chimney, author: viewer, homeowner: c.owner, landlord: u.landlord if u != null else c.owner, rating, originalRating: rating, photos, notes }

mutation amendRating(report: reports, rating: enum('pass', 'repair', 'do-not-use'), reason: text 1..500):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  r = reports[report] ! else NOT_FOUND
  require r.rating != rating else SAME_RATING
  insert amendments { report, chimney: r.chimney, homeowner: r.homeowner, landlord: r.landlord, author: r.author, oldRating: r.rating, newRating: rating, reason, amendedBy: viewer }
  update reports[report] { rating }
  return null

mutation issueQuote(report: reports, amount: money USD):
  require exists roles[viewer, role = 'master'] else NOT_MASTER
  r = reports[report] ! else NOT_FOUND
  require r.rating = 'repair' else NOT_REPAIR
  return insert quotes { report, chimney: r.chimney, homeowner: r.homeowner, landlord: r.landlord, amount, expiresAt: now + 30d }

mutation answerQuote(quote: quotes, accept: bool):
  q = quotes[quote]
  require q != null else NOT_FOUND
  require q.homeowner = viewer else NOT_OWNER
  require q.expiresAt > now else QUOTE_EXPIRED
  require q.decision = 'pending' else ALREADY_ANSWERED
  update quotes[quote] { decision: 'accepted' if accept else 'declined' }
  return null
