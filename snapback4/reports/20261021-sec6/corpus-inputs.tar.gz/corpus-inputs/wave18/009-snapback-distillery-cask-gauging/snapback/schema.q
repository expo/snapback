-- Distillery Cask Gauging.
-- Roles: warehouse_staff (gauges, moves), warehouse_lead (overdue flag,
-- bottling/sale status), excise_officer (read-only gauge history),
-- master_distiller (losses, prices, grants), cask_owner (own casks only).
-- Real authentication: email + password accounts (no personas).
use identity password

-- Roster: one row per person. First master_distiller is enrolled with the
-- service:ops seat; afterwards only a master_distiller can grant roles.
table staffRoles:
  principal: principal
  role: enum('warehouse_staff', 'warehouse_lead', 'excise_officer', 'master_distiller', 'cask_owner')
  unique principal
  read <- .principal = viewer or exists staffRoles[viewer, role = 'master_distiller']
  insert <- exists staffRoles[viewer, role = 'master_distiller'] or viewer = 'service:ops'
  update <- exists staffRoles[viewer, role = 'master_distiller'] or viewer = 'service:ops'
  delete <- exists staffRoles[viewer, role = 'master_distiller'] or viewer = 'service:ops'
  cap 100
  online only

-- A cask in the bonded warehouse. Sale price lives in caskPrices (hidden
-- from warehouse staff, lead and excise); everything here is visible to the
-- owner and to warehouse/excise/master roles.
table casks:
  caskNo: text 4..24
  spirit: text 1..60
  location: text 1..40
  owner: principal
  status: enum('active', 'bottled', 'sold') default 'active'
  fillDate: time
  lastGaugedAt: time
  unique caskNo else CASK_EXISTS 'This cask number is already registered.'
  immutable caskNo, owner, fillDate
  read <- .owner = viewer or exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'excise_officer'] or exists staffRoles[viewer, role = 'master_distiller']
  insert <- exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller']
  update <- exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller']
  cap 1000
  online only

-- A filling or regauge observation: proof plus an optional hydrometer photo.
-- History is immutable: no update or delete rule.
table gauges:
  cask: casks
  owner: principal
  proof: int 1..250
  photo: image <=5000000 ?
  note: text <=280 ?
  gaugedAt: time default now
  gaugedBy: principal
  immutable cask, owner, gaugedBy, gaugedAt
  read <- .owner = viewer or exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'excise_officer'] or exists staffRoles[viewer, role = 'master_distiller']
  insert <- .gaugedBy = viewer and exists casks[.cask, owner = .owner] and (exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'])
  cap 200 by cask
  online only

-- Loss beyond normal evaporation. Only the master distiller records it;
-- the reason stays in the cask's history (readable by owner + staff roles).
table losses:
  cask: casks
  owner: principal
  mlLost: int 1..200000
  reason: text 1..500
  recordedAt: time default now
  recordedBy: principal
  immutable cask, owner, recordedBy, recordedAt
  read <- .owner = viewer or exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'excise_officer'] or exists staffRoles[viewer, role = 'master_distiller']
  insert <- .recordedBy = viewer and exists casks[.cask, owner = .owner] and (exists staffRoles[viewer, role = 'master_distiller'])
  cap 50 by cask
  online only

-- What a cask sold (or is offered) for. Visible only to the master
-- distiller and the owning owner: never to warehouse staff/lead or excise.
table caskPrices:
  cask: casks
  owner: principal
  price: money USD
  unique cask
  immutable cask, owner
  read <- .owner = viewer or exists staffRoles[viewer, role = 'master_distiller']
  insert <- exists casks[.cask, owner = .owner] and (exists staffRoles[viewer, role = 'master_distiller'])
  update <- exists staffRoles[viewer, role = 'master_distiller']
  cap 1000
  online only

query whoAmI():
  return viewer

query myRole():
  return staffRoles[principal = viewer]

-- Every cask for warehouse/excise/master roles; only their own for owners
-- (one scope: the read rule filters per caller, complete for both).
query caskList(c: cursor ?):
  return casks last 50 by .id after c

query caskDetail(target: casks):
  return casks[target]

query gaugeHistory(target: casks, c: cursor ?):
  anchor = casks[target] ! else NOT_FOUND
  return gauges where .cask = target last 50 by .id after c

query lossHistory(target: casks, c: cursor ?):
  anchor = casks[target] ! else NOT_FOUND
  return losses where .cask = target last 50 by .id after c

query caskPrice(target: casks):
  return caskPrices[cask = target]

-- Live warehouse map: positions of casks, no sale prices (prices live in
-- caskPrices, which staff cannot read). Warehouse team only.
query warehouseMap(c: cursor ?):
  require exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'] else NOT_WAREHOUSE
  return casks first 100 by .location after c

-- Casks due for regauging (six months after the last gauge), flagged to the
-- warehouse lead (and the master distiller).
query overdueCasks(c: cursor ?):
  require exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'] else NOT_LEAD
  return casks where .status = 'active' and .lastGaugedAt < now - 182d first 100 by .lastGaugedAt after c

-- Fill a cask: creates the cask plus its filling gauge atomically.
mutation fillCask(caskNo: text 4..24, spirit: text 1..60, location: text 1..40, owner: principal, proof: int 1..250, photo: image <=5000000 ?, gaugedAt: time ?):
  require exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'] else NOT_WAREHOUSE
  at = gaugedAt ?? now
  require at <= now else FUTURE_GAUGE 'The gauge time cannot be in the future.'
  c = insert casks { caskNo, spirit, location, owner, fillDate: at, lastGaugedAt: at }
  insert gauges { cask: c.id, owner, proof, photo, gaugedAt: at, gaugedBy: viewer }
  return c.id

-- Regauge a cask: appends a gauge and advances the cask's gauge clock.
mutation recordGauge(target: casks, proof: int 1..250, photo: image <=5000000 ?, note: text <=280 ?, gaugedAt: time ?):
  c = casks[target] ! else NOT_FOUND
  require exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'] else NOT_WAREHOUSE
  require c.status = 'active' else CASK_CLOSED 'This cask is bottled or sold; it cannot be regauged.'
  at = gaugedAt ?? now
  require at <= now else FUTURE_GAUGE 'The gauge time cannot be in the future.'
  require at >= c.fillDate else BEFORE_FILL 'The gauge predates the filling.'
  insert gauges { cask: target, owner: c.owner, proof, photo, note, gaugedAt: at, gaugedBy: viewer }
  update casks[target] { lastGaugedAt: at if at > c.lastGaugedAt else c.lastGaugedAt }
  return null

-- Exceptional loss beyond evaporation. Master distiller only.
mutation recordLoss(target: casks, mlLost: int 1..200000, reason: text 1..500, gaugedAt: time ?):
  c = casks[target] ! else NOT_FOUND
  require exists staffRoles[viewer, role = 'master_distiller'] else NOT_MASTER
  require c.status = 'active' else CASK_CLOSED 'This cask is bottled or sold; no loss can be recorded.'
  at = gaugedAt ?? now
  require at <= now else FUTURE_GAUGE 'The loss time cannot be in the future.'
  require at >= c.fillDate else BEFORE_FILL 'The loss predates the filling.'
  insert losses { cask: target, owner: c.owner, mlLost, reason, recordedAt: at, recordedBy: viewer }
  update casks[target] { lastGaugedAt: at if at > c.lastGaugedAt else c.lastGaugedAt }
  return null

-- Move a cask on the warehouse map.
mutation moveCask(target: casks, location: text 1..40):
  c = casks[target] ! else NOT_FOUND
  require exists staffRoles[viewer, role = 'warehouse_staff'] or exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'] else NOT_WAREHOUSE
  update casks[target] { location }
  return null

-- Bottle or sell a cask. Lead or master only.
mutation setStatus(target: casks, status: enum('active', 'bottled', 'sold')):
  c = casks[target] ! else NOT_FOUND
  require exists staffRoles[viewer, role = 'warehouse_lead'] or exists staffRoles[viewer, role = 'master_distiller'] else NOT_LEAD
  update casks[target] { status }
  return null

-- Set a cask's sale price. Master distiller only.
mutation setPrice(target: casks, price: money USD):
  c = casks[target] ! else NOT_FOUND
  require exists staffRoles[viewer, role = 'master_distiller'] else NOT_MASTER
  upsert caskPrices[target] { cask: target, owner: c.owner, price }
  return null

-- Grant (or change) a user's role. Master distiller only; the service:ops
-- seat enrolls the first master.
mutation grantRole(who: principal, role: enum('warehouse_staff', 'warehouse_lead', 'excise_officer', 'master_distiller', 'cask_owner')):
  require exists staffRoles[viewer, role = 'master_distiller'] or viewer = 'service:ops' else NOT_MASTER
  return upsert staffRoles[who] { principal: who, role }
