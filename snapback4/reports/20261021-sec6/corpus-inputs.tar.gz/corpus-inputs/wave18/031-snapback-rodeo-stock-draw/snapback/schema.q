-- Rodeo Stock Draw: rough-stock riders are matched to bulls/broncs per
-- performance. Entries close 48h before the performance; a scheduled job
-- draws assignments automatically. Two judges score each ride blind: a score
-- row is readable by anyone besides its author and the secretary only once
-- the completed `results` row for that ride exists. The arena scoreboard
-- reads those published results live. Medical releases and health papers
-- live in restricted side tables. Rerides flow judge-request -> secretary
-- grant, preserving the judges' reason.

use identity password

table roles:
  principal: principal
  role: enum('secretary', 'judge', 'rider', 'contractor')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[principal = viewer, role = 'secretary']
  insert <- viewer = 'service:operator' or exists roles[principal = viewer, role = 'secretary']
  update <- viewer = 'service:operator' or exists roles[principal = viewer, role = 'secretary']
  delete <- deny
  online only

table handles:
  principal: principal
  handle: text 3..20 format handle
  unique principal
  unique handle
  immutable principal
  public 'rider names are shown on the public arena scoreboard'
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

table performances:
  name: text 3..80
  startsAt: time
  closeAt: time
  drawn: bool default false
  closedEarly: bool default false
  createdBy: principal
  immutable startsAt, closeAt
  by byStartsAt: startsAt
  public 'the performance schedule is public'
  insert <- exists roles[principal = viewer, role = 'secretary']
  update <- exists roles[principal = viewer, role = 'secretary']
  online only

table entries:
  performance: performances
  rider: principal
  event: enum('bull', 'bronc')
  at: time default now
  unique performance, rider else ALREADY_ENTERED 'You are already entered in this performance.'
  immutable performance, rider, event
  by byPerformance: performance
  read <- .rider = viewer or exists roles[principal = viewer, role = 'secretary']
  insert <- .rider = viewer
  delete <- .rider = viewer
  online only

table animals:
  contractor: principal
  name: text 1..60
  kind: enum('bull', 'bronc')
  photo: image <=10000000
  at: time default now
  immutable contractor
  public 'animal names and photos identify them in the arena'
  insert <- .contractor = viewer
  update <- .contractor = viewer
  online only

table healthPapers:
  animal: animals
  doc: file <=8000000
  at: time default now
  unique animal
  immutable animal
  read <- exists roles[principal = viewer, role = 'secretary'] or exists animals[.animal, contractor = viewer]
  insert <- exists animals[.animal, contractor = viewer]
  update <- exists animals[.animal, contractor = viewer]
  online only

table medical:
  rider: principal
  doc: file <=8000000
  at: time default now
  unique rider
  immutable rider
  read <- .rider = viewer or exists roles[principal = viewer, role = 'secretary']
  insert <- .rider = viewer
  update <- .rider = viewer
  online only

table rides:
  performance: performances
  rider: principal
  animal: animals
  at: time default now
  unique performance, rider else ALREADY_DRAWN 'This entry already has a draw.'
  unique performance, animal else ANIMAL_DRAWN 'This animal is already drawn.'
  immutable performance, rider, animal
  by byPerformance: performance
  read <- .rider = viewer or exists roles[principal = viewer, role = 'secretary'] or exists roles[principal = viewer, role = 'judge'] or exists animals[.animal, contractor = viewer]
  insert <- deny
  update <- deny
  delete <- deny
  online only

table scores:
  ride: rides
  judge: principal
  points: int 0..100
  at: time default now
  unique ride, judge else ALREADY_SCORED 'You already scored this ride.'
  immutable ride, judge, points
  read <- .judge = viewer or exists roles[principal = viewer, role = 'secretary'] or exists results[ride = .ride]
  insert <- .judge = viewer and exists roles[principal = viewer, role = 'judge']
  update <- deny
  delete <- deny
  online only

table results:
  ride: rides
  performance: performances
  rider: principal
  animal: animals
  total: int 0..200
  at: time default now
  unique ride
  immutable ride, performance, rider, animal, total
  by byPerformance: performance
  public 'completed scores are the public arena scoreboard'
  insert <- exists roles[principal = viewer, role = 'judge']
  update <- deny
  delete <- deny
  online only

-- Maintained aggregates over scores. They are readable so the scoreRide
-- program can detect completion with point reads (no scans); no client
-- query exposes them, so partial sums never reach any screen. The public
-- scoreboard reads only completed `results` rows.
view rideScoreCount: count scores by .ride
  read <- exists roles[principal = viewer, role = 'judge']
view rideScoreTotal: sum scores of .points by .ride
  read <- exists roles[principal = viewer, role = 'judge']

table rerideRequests:
  ride: rides
  judge: principal
  reason: text 1..500
  at: time default now
  unique ride else ALREADY_REQUESTED 'A reride was already requested for this ride.'
  immutable ride, judge, reason
  read <- exists roles[principal = viewer, role = 'judge'] or exists roles[principal = viewer, role = 'secretary']
  insert <- .judge = viewer
  online only

table rerides:
  ride: rides
  reason: text 1..500
  grantedBy: principal
  at: time default now
  unique ride else ALREADY_GRANTED 'A reride was already granted for this ride.'
  immutable ride, reason, grantedBy
  read <- exists roles[principal = viewer, role = 'judge'] or exists roles[principal = viewer, role = 'secretary'] or exists rides[.ride, rider = viewer]
  insert <- exists roles[principal = viewer, role = 'secretary']
  online only

-- Operator + secretary role administration. The operator seat provisions
-- roles for staging/production; the secretary administers the roster.
mutation provision(principal: principal, role: enum('secretary', 'judge', 'rider', 'contractor')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation grantRole(who: principal, role: enum('secretary', 'judge', 'rider', 'contractor')):
  require exists roles[principal = viewer, role = 'secretary'] or viewer = 'service:operator' else NOT_SECRETARY
  return upsert roles[who] { principal: who, role }

mutation saveHandle(handle: text 3..20 format handle):
  return upsert handles[viewer] { principal: viewer, handle }

mutation createPerformance(name: text 3..80, startsAt: time):
  require exists roles[principal = viewer, role = 'secretary'] else NOT_SECRETARY
  require startsAt > now else BAD_START 'The performance must start in the future.'
  return insert performances { name, startsAt, closeAt: startsAt - 48h, createdBy: viewer }

-- The secretary may close entries early (a sold-out performance); the
-- automatic 48h close still applies to every performance by default.
mutation closeEntries(performance: performances):
  require exists roles[principal = viewer, role = 'secretary'] else NOT_SECRETARY
  p = performances[performance] ! else NOT_FOUND
  require now < p.closeAt else ENTRIES_CLOSED 'Entries are already closed.'
  require not p.closedEarly else ENTRIES_CLOSED 'Entries are already closed.'
  update performances[performance] { closedEarly: true }

mutation enter(performance: performances, event: enum('bull', 'bronc')):
  require exists roles[principal = viewer, role = 'rider'] else NOT_RIDER
  p = performances[performance] ! else NOT_FOUND
  require now < p.closeAt and not p.closedEarly else ENTRIES_CLOSED 'Entries are closed for this performance.'
  require exists medical[viewer] else NO_MEDICAL 'File a medical release before entering.'
  return insert entries { performance, rider: viewer, event }

mutation withdraw(entry: entries):
  e = entries[entry] ! else NOT_FOUND
  require e.rider = viewer else NOT_OWNER
  p = performances[e.performance] ! else NOT_FOUND
  require now < p.closeAt and not p.closedEarly else ENTRIES_CLOSED 'Entries are closed; withdrawals are final.'
  delete entries[entry]

mutation registerAnimal(name: text 1..60, kind: enum('bull', 'bronc'), photo: image <=10000000, papers: file <=8000000):
  require exists roles[principal = viewer, role = 'contractor'] else NOT_CONTRACTOR
  a = insert animals { contractor: viewer, name, kind, photo }
  insert healthPapers { animal: a.id, doc: papers }
  return a

mutation uploadMedical(doc: file <=8000000):
  require exists roles[principal = viewer, role = 'rider'] else NOT_RIDER
  return upsert medical[viewer] { rider: viewer, doc }

mutation scoreRide(ride: rides, points: int 0..100):
  require exists roles[principal = viewer, role = 'judge'] else NOT_JUDGE
  r = rides[ride] ! else NOT_FOUND
  require not exists results[ride = ride] else SCORED_CLOSED 'Both scores are in; this ride is final.'
  insert scores { ride, judge: viewer, points }
  n = rideScoreCount[ride] ?? 0
  if n = 2:
    t = rideScoreTotal[ride] ?? points
    insert results { ride, performance: r.performance, rider: r.rider, animal: r.animal, total: t, at: now } if absent
  return null

mutation requestReride(ride: rides, reason: text 1..500):
  require exists roles[principal = viewer, role = 'judge'] else NOT_JUDGE
  r = rides[ride] ! else NOT_FOUND
  require exists results[ride = ride] else NOT_COMPLETE 'A reride needs a completed score first.'
  return insert rerideRequests { ride, judge: viewer, reason }

mutation grantReride(request: rerideRequests):
  require exists roles[principal = viewer, role = 'secretary'] else NOT_SECRETARY
  q = rerideRequests[request] ! else NOT_FOUND
  require not exists rerides[q.ride] else ALREADY_GRANTED 'A reride was already granted for this ride.'
  return insert rerides { ride: q.ride, reason: q.reason, grantedBy: viewer }

query whoAmI():
  return viewer

query myRole():
  return roles[viewer]

query performances(c: cursor ?):
  return performances where .startsAt >= now - 2d first 50 by .startsAt after c { id, name, startsAt, closeAt, drawn }

query myEntries(c: cursor ?):
  return entries where .rider = viewer first 50 by .id after c { id, performance: performances[.performance], event }

query performanceEntries(performance: performances, c: cursor ?):
  require exists roles[principal = viewer, role = 'secretary'] else NOT_SECRETARY
  return entries where .performance = performance first 100 by .id after c

query animals(c: cursor ?):
  return animals first 100 by .id after c

query myAnimals(c: cursor ?):
  return animals where .contractor = viewer first 100 by .id after c

query animalPapers(animal: animals):
  a = animals[animal] ! else NOT_FOUND
  require a.contractor = viewer or exists roles[principal = viewer, role = 'secretary'] else NOT_ALLOWED
  return healthPapers[animal]

query myMedical():
  return medical[viewer]

query myHandle():
  return handles[viewer]

query medicalFor(rider: principal):
  require exists roles[principal = viewer, role = 'secretary'] else NOT_SECRETARY
  return medical[rider]

query myDraws(c: cursor ?):
  return rides where .rider = viewer first 50 by .id after c { id, performance: performances[.performance], animal: animals[.animal], result: results[.id] }

query rideScores(ride: rides):
  r = rides[ride] ! else NOT_FOUND
  require r.rider = viewer or exists roles[principal = viewer, role = 'judge'] or exists roles[principal = viewer, role = 'secretary'] or exists animals[r.animal, contractor = viewer] else NOT_ALLOWED
  return scores where .ride = ride first 4 by .id

query scoreboard(performance: performances, c: cursor ?):
  return results where .performance = performance first 100 by .id after c { id, rider: handles[.rider], animal: animals[.animal], total }

query judgeQueue(c: cursor ?):
  require exists roles[principal = viewer, role = 'judge'] else NOT_JUDGE
  return rides where not exists scores[.id, viewer] first 50 by .id after c { id, performance: performances[.performance], animal: animals[.animal] }

query allRides(performance: performances, c: cursor ?):
  require exists roles[principal = viewer, role = 'secretary'] else NOT_SECRETARY
  return rides where .performance = performance first 100 by .id after c { id, animal: animals[.animal] }

query animalDraws(animal: animals, c: cursor ?):
  a = animals[animal] ! else NOT_FOUND
  require a.contractor = viewer or exists roles[principal = viewer, role = 'secretary'] else NOT_ALLOWED
  return rides where .animal = animal first 50 by .id after c

query rerideRequests(c: cursor ?):
  require exists roles[principal = viewer, role = 'judge'] or exists roles[principal = viewer, role = 'secretary'] else NOT_ALLOWED
  return rerideRequests first 50 by .id after c

query rerideFor(ride: rides):
  r = rides[ride] ! else NOT_FOUND
  require r.rider = viewer or exists roles[principal = viewer, role = 'judge'] or exists roles[principal = viewer, role = 'secretary'] else NOT_ALLOWED
  return rerides[ride]

-- The automatic draw: every minute, close out performances whose entry
-- window ended in the last 7 days and assign each entry an animal of the
-- entered event, falling back to any unassigned animal. Reruns are safe:
-- drawn flags and unique keys make each performance settle exactly once.
job runDraw(periodStart: time, periodEnd: time):
  for p in performances:
    if not p.drawn and (p.closeAt < periodEnd or p.closedEarly):
      for e in entries where .performance = p.id by .id:
        if not exists rides[p.id, e.rider]:
          page = animals where .kind = e.event and not exists rides[performance = p.id, animal = .id] first 1 by .id
          for a in page:
            insert rides { performance: p.id, rider: e.rider, animal: a.id } if absent
          if not exists rides[p.id, e.rider]:
            rest = animals where not exists rides[performance = p.id, animal = .id] first 1 by .id
            for a in rest:
              insert rides { performance: p.id, rider: e.rider, animal: a.id } if absent
      update performances[p.id] { drawn: true }

schedule drawRunner every 1m: runDraw
