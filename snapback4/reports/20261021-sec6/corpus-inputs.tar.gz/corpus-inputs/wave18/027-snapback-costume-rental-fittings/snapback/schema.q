-- Costume Rental Fittings.
-- A costume rental house lends costumes to schools and theatre groups.
-- Roles: rental manager, wardrobe staff, renter contact, costume lead.
-- Performers are records (measurements), not login roles.

use identity password

-- Privileged roster: wardrobe staff and the rental manager.
-- Seeded only by the local operator seat (staging/production path).
table roles:
  principal: principal
  role: enum('manager', 'staff')
  unique principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

-- Discoverable handles so a manager can staff organisations.
table profiles:
  principal: principal
  handle: text 3..20 format handle
  unique principal
  unique handle
  immutable principal
  cap 1 by principal
  public 'handles are discoverable so a manager can staff organisations'
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

-- A renter organisation (a school or theatre group).
table orgs:
  name: text 1..80
  contact: principal
  lead: principal
  cap 200
  read <- .contact = viewer or .lead = viewer or exists roles[viewer]
  insert <- exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  update <- exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
  online only

-- The costume catalogue. Names and fees are public; only staff manage it.
table costumes:
  name: text 1..80
  size: text 1..20
  deposit: int 0..1000000
  dailyFee: int 0..100000
  cap 2000
  public 'the catalogue is public so renters can browse'
  insert <- exists roles[viewer]
  update <- exists roles[viewer]
  online only

-- A rental order for one production. Due back 7 days after closing.
table rentals:
  org: orgs on delete restrict
  production: text 1..120
  closingAt: time
  createdBy: principal
  createdAt: time default now
  immutable org, createdBy, createdAt
  cap 500 by org
  read <- exists orgs[.org, contact = viewer] or exists orgs[.org, lead = viewer] or exists roles[viewer]
  insert <- exists orgs[.org, contact = viewer] or exists orgs[.org, lead = viewer] or exists roles[viewer]
  update <- exists roles[viewer, role = 'manager']
  online only

-- One costume on a rental. Photos at checkout and return, deposit snapshot.
table rentalItems:
  rental: rentals on delete restrict
  costume: costumes on delete restrict
  checkoutPhoto: image <=5000000
  checkoutAt: time default now
  checkoutBy: principal
  deposit: int 0..1000000
  dailyFee: int 0..100000
  returnPhoto: image <=5000000 ?
  returnedAt: time ?
  returned: bool default false
  lateDays: int 0..100000 default 0
  lateFee: int 0..100000000 default 0
  kept: int 0..1000000 default 0
  damageReason: text 1..500 ?
  damagePhoto: image <=5000000 ?
  immutable rental, costume, checkoutPhoto, checkoutAt, checkoutBy, deposit, dailyFee
  cap 100 by rental
  read through .rental
  insert <- .rental.org.contact = viewer or .rental.org.lead = viewer or exists roles[viewer]
  update <- .rental.org.contact = viewer or .rental.org.lead = viewer or exists roles[viewer]
  online only

-- Live occupancy over private rental rows: anyone may see how many are out,
-- never who holds them.
view activeReservations: count rentalItems where not .returned by .costume
  read <- allow

-- Performers belong to an organisation. Measurements are visible only to
-- wardrobe staff and that organisation's costume lead.
table performers:
  org: orgs on delete cascade
  name: text 1..80
  measurements: text 1..500
  unique org, name
  cap 500 by org
  read <- .org.lead = viewer or exists roles[viewer, role = 'staff']
  insert <- .org.lead = viewer or exists roles[viewer, role = 'staff']
  update <- .org.lead = viewer or exists roles[viewer, role = 'staff']
  online only

-- Fitting notes on a rental: the rental's own readers.
table fittingNotes:
  rental: rentals on delete cascade
  author: principal
  body: text 1..1000
  at: time default now
  immutable rental, author, at
  cap 500 by rental
  read through .rental
  insert <- .rental.org.contact = viewer or .rental.org.lead = viewer or exists roles[viewer]
  online only

-- Independent privacy intent (guide security).
invariant roles.read only .principal = viewer or viewer = 'service:operator'
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
invariant roles.delete only viewer = 'service:operator'
invariant orgs.read only .contact = viewer or .lead = viewer or exists roles[viewer]
invariant orgs.insert only exists roles[viewer, role = 'manager'] or viewer = 'service:operator'
invariant rentals.read only .org.contact = viewer or .org.lead = viewer or exists roles[viewer]
invariant rentalItems.read only .rental.org.contact = viewer or .rental.org.lead = viewer or exists roles[viewer]
invariant performers.read only .org.lead = viewer or exists roles[viewer, role = 'staff']
invariant performers.insert only .org.lead = viewer or exists roles[viewer, role = 'staff']
invariant fittingNotes.read only .rental.org.contact = viewer or .rental.org.lead = viewer or exists roles[viewer]

query myRole():
  return roles[viewer]

query myProfile():
  return profiles[principal = viewer]

query allProfiles(c: cursor ?):
  require exists roles[viewer] else NOT_STAFF
  return profiles first 50 by .id after c

query myOrgs(c: cursor ?):
  if exists roles[viewer]:
    return orgs last 50 by .id after c
  return orgs where .contact = viewer or .lead = viewer last 50 by .id after c

query catalog(c: cursor ?):
  return costumes first 100 by .id after c { id, name, size, deposit, dailyFee, reserved: activeReservations[.id] ?? 0 }

query rentalsOf(org: orgs, c: cursor ?):
  o = orgs[org] ! else NOT_FOUND
  return rentals where .org = org last 50 by .id after c

query itemsOf(rental: rentals):
  r = rentals[rental] ! else NOT_FOUND
  return rentalItems where .rental = rental first 100 by .id

query notesOf(rental: rentals):
  r = rentals[rental] ! else NOT_FOUND
  return fittingNotes where .rental = rental first 100 by .id

query performersOf(org: orgs):
  o = orgs[org] ! else NOT_FOUND
  return performers where .org = org first 100 by .id

mutation saveProfile(handle: text 3..20 format handle):
  return upsert profiles[principal = viewer] { principal: viewer, handle }

mutation provision(principal: principal, role: enum('manager', 'staff')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

mutation createOrg(name: text 1..80, contact: principal, lead: principal):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return insert orgs { name, contact, lead }

mutation addCostume(name: text 1..80, size: text 1..20, deposit: int 0..1000000, dailyFee: int 0..100000):
  require exists roles[viewer] else NOT_STAFF
  return insert costumes { name, size, deposit, dailyFee }

mutation updateCostume(costume: costumes, name: text 1..80, size: text 1..20, deposit: int 0..1000000, dailyFee: int 0..100000):
  require exists roles[viewer] else NOT_STAFF
  c = costumes[costume] ! else NOT_FOUND
  update costumes[costume] { name, size, deposit, dailyFee }
  return null

mutation createRental(org: orgs, production: text 1..120, closingAt: time):
  o = orgs[org] ! else NOT_FOUND
  require o.contact = viewer or o.lead = viewer or exists roles[viewer] else NOT_MEMBER
  return insert rentals { org, production, closingAt, createdBy: viewer }

mutation setClosing(rental: rentals, closingAt: time):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  r = rentals[rental] ! else NOT_FOUND
  update rentals[rental] { closingAt }
  return null

mutation checkout(rental: rentals, costume: costumes, photo: image <=5000000):
  r = rentals[rental] ! else NOT_FOUND
  c = costumes[costume] ! else NOT_FOUND
  require now <= r.closingAt + 7d else CHECKOUT_CLOSED 'Checkout closes at the due date, seven days after closing.'
  require (activeReservations[costume] ?? 0) = 0 else ALREADY_RESERVED 'This costume is already out on another rental.'
  return insert rentalItems { rental, costume, checkoutPhoto: photo, checkoutBy: viewer, deposit: c.deposit, dailyFee: c.dailyFee }

mutation recordReturn(item: rentalItems, photo: image <=5000000):
  i = rentalItems[item] ! else NOT_FOUND
  require not i.returned else ALREADY_RETURNED
  r = rentals[i.rental] ! else NOT_FOUND
  due = r.closingAt + 7d
  days = day(now) - day(due)
  late = days if days > 0 else 0
  update rentalItems[item] { returnPhoto: photo, returnedAt: now, returned: true, lateDays: late, lateFee: late * i.dailyFee }
  return null

mutation assessDamage(item: rentalItems, kept: int 1..1000000, reason: text 1..500, photo: image <=5000000):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER 'Only the rental manager can keep part of a deposit.'
  i = rentalItems[item] ! else NOT_FOUND
  require i.returned else NOT_RETURNED 'Assess damage after the costume is returned.'
  require kept <= i.deposit else OVER_DEPOSIT 'Cannot keep more than the deposit.'
  update rentalItems[item] { kept, damageReason: reason, damagePhoto: photo }
  return null

mutation upsertPerformer(org: orgs, name: text 1..80, measurements: text 1..500):
  o = orgs[org] ! else NOT_FOUND
  require o.lead = viewer or exists roles[viewer, role = 'staff'] else NOT_ALLOWED 'Only wardrobe staff or the costume lead may record measurements.'
  return upsert performers[org, name] { org, name, measurements }

mutation addFittingNote(rental: rentals, body: text 1..1000):
  r = rentals[rental] ! else NOT_FOUND
  return insert fittingNotes { rental, author: viewer, body }
