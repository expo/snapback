-- Calendar has occupancy only. Every studio account may read it.
invariant calendar.read only exists roles[viewer]
invariant sessions.read only .band = viewer or .engineer = viewer or exists roles[viewer, role = 'manager']
invariant rates.read only .band = viewer or exists roles[viewer, role = 'manager']
invariant notes.read only .engineer = viewer
invariant files.read only .band = viewer or .engineer = viewer or exists roles[viewer, role = 'manager']
invariant deposits.read only .band = viewer or exists roles[viewer, role = 'manager']
invariant refunds.read only .band = viewer or exists roles[viewer, role = 'manager']
invariant refunds.insert only .manager = viewer and exists roles[viewer, role = 'manager']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
