-- Cobbler Repair Tickets.
--
-- Roles: customer, bench (cobblers), counter (counter staff), owner.
-- A ticket is written by counter/owner staff for a customer's pair, with
-- photos of the sole and upper and the agreed repair + price. Bench staff
-- move it through the bench stages; counter records collection. Ready pairs
-- uncollected 60 days after the pickup notice are swept to abandoned/for sale.
-- Only the owner can reprice after work starts, with a recorded reason, and
-- the price only changes once the customer approves.
use identity password

table roles:
  principal: principal
  role: enum('customer', 'bench', 'counter', 'owner')
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'counter']
  insert <- .principal = viewer or exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'owner']
  online only

table profiles:
  principal: principal
  displayName: text 1..80
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
  insert <- .principal = viewer
  update <- .principal = viewer
  online only

-- Customer phone numbers live apart from tickets/profiles so bench readers
-- never receive them. Only the customer, counter staff and the owner read.
table customerPhones:
  customer: principal
  phone: text 1..20
  unique customer
  read <- .customer = viewer or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
  insert <- .customer = viewer
  update <- .customer = viewer
  online only

-- Singleton bootstrap seat: the first owner claim inserts seat 1; every
-- later claim sees the clash and is refused. Further owners come from grantRole.
table ownerSeats:
  seat: int
  holder: principal
  unique seat
  public 'the bootstrap seat is visible so anyone can see it is taken'
  insert <- .holder = viewer
  online only

table tickets:
  customer: principal
  createdBy: principal
  shoe: text 1..120
  repair: text 1..500
  solePhoto: image <=10000000
  upperPhoto: image <=10000000
  price: money USD
  status: enum('received', 'in_repair', 'ready', 'collected', 'abandoned') default 'received'
  pickupNoticeAt: time ?
  forSale: bool default false
  pendingPrice: money USD ?
  repriceReason: text <=500 ?
  repriceApproved: bool default false
  createdAt: time default now
  immutable customer, createdBy
  read <- .customer = viewer or exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
  insert <- exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
  update <- exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner'] or .customer = viewer
  online only

-- Sign-up: a fresh account becomes a customer.
mutation register(displayName: text 1..80, phone: text 1..20):
  require not exists roles[viewer] else ALREADY_REGISTERED 'This account already has a role.'
  insert roles { principal: viewer, role: 'customer' }
  insert profiles { principal: viewer, displayName }
  insert customerPhones { customer: viewer, phone }
  return null

mutation setMyPhone(phone: text 1..20):
  require exists roles[viewer, role = 'customer'] else NOT_CUSTOMER
  upsert customerPhones[viewer] { customer: viewer, phone }
  return null

-- First owner only; later owners are granted by an owner.
mutation bootstrapOwner(displayName: text 1..80):
  require not exists roles[viewer] else ALREADY_REGISTERED 'This account already has a role.'
  seat = insert ownerSeats { seat: 1, holder: viewer } if absent
  require seat != null else OWNER_EXISTS 'An owner already exists.'
  insert roles { principal: viewer, role: 'owner' }
  insert profiles { principal: viewer, displayName }
  return null

mutation grantRole(who: principal, role: enum('customer', 'bench', 'counter', 'owner')):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  upsert roles[who] { role }
  return null

mutation createTicket(customer: principal, shoe: text 1..120, repair: text 1..500, solePhoto: image <=10000000, upperPhoto: image <=10000000, price: money USD):
  require exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner'] else NOT_COUNTER
  c = profiles[customer] ! else UNKNOWN_CUSTOMER
  return insert tickets { customer, createdBy: viewer, shoe, repair, solePhoto, upperPhoto, price }

mutation startRepair(ticket: tickets):
  t = tickets[ticket] ! else NOT_FOUND
  require exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'owner'] else NOT_BENCH
  require t.status = 'received' else BAD_STATUS 'Ticket is not waiting at intake.'
  update tickets[ticket] { status: 'in_repair' }
  return null

mutation markReady(ticket: tickets):
  t = tickets[ticket] ! else NOT_FOUND
  require exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'owner'] else NOT_BENCH
  require t.status = 'in_repair' else BAD_STATUS 'Ticket is not on the bench.'
  update tickets[ticket] { status: 'ready', pickupNoticeAt: now }
  return null

mutation collectTicket(ticket: tickets):
  t = tickets[ticket] ! else NOT_FOUND
  require exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner'] else NOT_COUNTER
  require t.status = 'ready' else NOT_READY 'Ticket is not ready for pickup.'
  require t.pickupNoticeAt != null and t.pickupNoticeAt >= now - 60d else TOO_LATE 'Past the 60-day pickup window.'
  update tickets[ticket] { status: 'collected' }
  return null

-- Only the owner reprices after work starts, with a recorded reason. The
-- price itself only moves when the customer approves (approveReprice).
mutation proposeReprice(ticket: tickets, newPrice: money USD, reason: text 3..500):
  t = tickets[ticket] ! else NOT_FOUND
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  require t.status != 'received' else WORK_NOT_STARTED 'Work has not started.'
  update tickets[ticket] { pendingPrice: newPrice, repriceReason: reason, repriceApproved: false }
  return null

mutation approveReprice(ticket: tickets):
  t = tickets[ticket] ! else NOT_FOUND
  require t.customer = viewer else NOT_CUSTOMER
  require t.pendingPrice != null else NO_PROPOSAL 'No reprice proposal is waiting.'
  update tickets[ticket] { price: t.pendingPrice, pendingPrice: null, repriceApproved: true }
  return null

job sweepAbandoned(periodStart: time, periodEnd: time):
  for t in tickets:
    if t.status = 'ready' and t.pickupNoticeAt != null and t.pickupNoticeAt < periodEnd - 60d:
      update tickets[t.id] { status: 'abandoned', forSale: true }

schedule abandonSweepDaily every 1d at 08:00: sweepAbandoned

query whoAmI():
  return viewer

query myRole():
  return roles[viewer]

query myTickets(c: cursor ?):
  return tickets where .customer = viewer last 50 by .id after c

query staffTickets(c: cursor ?):
  require exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return tickets last 50 by .id after c

query ticketDetail(ticket: tickets):
  return tickets[ticket]

query saleTickets(c: cursor ?):
  require exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return tickets where .forSale = true last 50 by .id after c

query myPhone():
  return customerPhones[viewer]

query customerPhone(customer: principal):
  return customerPhones[customer]

query listProfiles(c: cursor ?):
  require exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner'] else NOT_STAFF
  return profiles last 100 by .id after c

query rosterList(c: cursor ?):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return roles last 100 by .id after c

-- Independent privacy intent; guide security states unproved paths.
invariant tickets.read only .customer = viewer or exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
invariant customerPhones.read only .customer = viewer or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
invariant tickets.price write only exists roles[viewer, role = 'owner'] or .customer = viewer
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'owner'] or exists roles[viewer, role = 'counter']
invariant profiles.read only .principal = viewer or exists roles[viewer, role = 'bench'] or exists roles[viewer, role = 'counter'] or exists roles[viewer, role = 'owner']
invariant ownerSeats.read only allow
