use identity password

table roles:
  principal: principal
  role: enum('student', 'coach', 'rigger', 'head_rigger', 'director')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or (.role = 'student' and exists roles[principal = viewer, role = 'coach'])
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('student', 'coach', 'rigger', 'head_rigger', 'director')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

fn staff():
  return exists roles[principal = viewer, role = 'coach'] or exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger'] or exists roles[principal = viewer, role = 'director']
fn rigging():
  return exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger']

query myRole():
  return roles[principal = viewer]
query students():
  require exists roles[principal = viewer, role = 'coach'] else NOT_COACH
  return roles where .role = 'student' first 100 by .id

table points:
  name: text 1..80
  apparatus: text 1..80
  state: enum('pending', 'passed', 'failed', 'expired')
  inspectedAt: time ?
  dueAt: time
  ratingKg: int 0..5000
  unique name
  read <- exists roles[principal = viewer, role = 'coach'] or exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger'] or exists roles[principal = viewer, role = 'director']
  insert <- exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger']
  update <- exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger']
  online only

table inspections:
  point: points
  inspector: principal
  at: time
  outcome: enum('passed', 'failed')
  ratingKg: int 1..5000
  photo: image <=5000000
  notes: text 1..2000
  immutable point, inspector, at, outcome, ratingKg, photo, notes
  read <- exists roles[principal = viewer, role = 'coach'] or exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger'] or exists roles[principal = viewer, role = 'director']
  insert <- .inspector = viewer and (exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger'])
  online only

table returns:
  point: points
  rigger: principal
  at: time
  reason: text 3..2000
  parts: text 3..2000
  immutable point, rigger, at, reason, parts
  read <- exists roles[principal = viewer, role = 'coach'] or exists roles[principal = viewer, role = 'rigger'] or exists roles[principal = viewer, role = 'head_rigger'] or exists roles[principal = viewer, role = 'director']
  insert <- .rigger = viewer and exists roles[principal = viewer, role = 'head_rigger']
  online only

query board():
  require staff() else STAFF_ONLY
  return points first 200 by .id
query pointHistory(point: points):
  require staff() else STAFF_ONLY
  return { inspections: inspections where .point = point last 100 by .at, returns: returns where .point = point last 100 by .at }
mutation createPoint(name: text 1..80, apparatus: text 1..80):
  require rigging() else NOT_RIGGER
  return insert points { name, apparatus, state: 'pending', dueAt: now, ratingKg: 0 }
mutation inspect(point: points, outcome: enum('passed', 'failed'), ratingKg: int 1..5000, photo: image <=5000000, notes: text 1..2000):
  require rigging() else NOT_RIGGER
  p = points[point] ! else NOT_FOUND
  require p.state != 'failed' or outcome = 'failed' else HEAD_RIGGER_RETURN_REQUIRED
  insert inspections { point, inspector: viewer, at: now, outcome, ratingKg, photo, notes }
  update points[point] { state: outcome, inspectedAt: now, dueAt: now + 30d, ratingKg }
mutation returnToService(point: points, reason: text 3..2000, parts: text 3..2000, ratingKg: int 1..5000, photo: image <=5000000):
  require exists roles[principal = viewer, role = 'head_rigger'] else NOT_HEAD_RIGGER
  p = points[point] ! else NOT_FOUND
  require p.state = 'failed' else NOT_FAILED
  insert returns { point, rigger: viewer, at: now, reason, parts }
  insert inspections { point, inspector: viewer, at: now, outcome: 'passed', ratingKg, photo, notes: reason }
  update points[point] { state: 'passed', inspectedAt: now, dueAt: now + 30d, ratingKg }

job lockExpired(periodStart: time, periodEnd: time):
  for p in points:
    if p.state = 'passed' and p.dueAt <= now:
      update points[p.id] { state: 'expired' }
schedule lockSweep every 1m: lockExpired

table bookings:
  student: principal
  coach: principal
  point: points
  apparatus: text 1..80
  title: text 1..100
  startsAt: time
  loadKg: int 1..5000
  immutable student, coach, point, apparatus, title, startsAt, loadKg
  read <- .student = viewer or .coach = viewer
  insert <- .coach = viewer and exists roles[principal = viewer, role = 'coach'] and exists roles[principal = .student, role = 'student']
  online only

table progress:
  booking: bookings
  student: principal
  coach: principal
  body: text 1..2000
  at: time
  immutable booking, student, coach, body, at
  read <- .student = viewer or .coach = viewer
  insert <- .coach = viewer and exists roles[principal = viewer, role = 'coach']
  online only
query myBookings():
  return bookings first 200 by .startsAt
query bookingFor(booking: bookings):
  return bookings[booking]
query myProgress():
  return progress last 200 by .at
mutation book(point: points, student: principal, title: text 1..100, startsAt: time, loadKg: int 1..5000):
  require exists roles[principal = viewer, role = 'coach'] else NOT_COACH
  require exists roles[principal = student, role = 'student'] else NOT_STUDENT
  p = points[point] ! else NOT_FOUND
  require p.state = 'passed' and p.dueAt > now else POINT_LOCKED
  require startsAt >= now and startsAt < p.dueAt else OUTSIDE_INSPECTION_WINDOW
  require loadKg <= p.ratingKg else LOAD_EXCEEDED
  return insert bookings { student, coach: viewer, point, apparatus: p.apparatus, title, startsAt, loadKg }
mutation addProgress(booking: bookings, body: text 1..2000):
  require exists roles[principal = viewer, role = 'coach'] else NOT_COACH
  b = bookings[booking] ! else NOT_FOUND
  require b.coach = viewer else NOT_YOUR_BOOKING
  return insert progress { booking, student: b.student, coach: viewer, body, at: now }

table incidents:
  author: principal
  fall: bool
  title: text 1..100
  details: text 1..4000
  at: time
  immutable author, fall, title, details, at
  read <- exists roles[principal = viewer, role = 'head_rigger'] or exists roles[principal = viewer, role = 'director'] or (.author = viewer and .fall = false)
  insert <- .author = viewer and exists roles[principal = viewer]
  online only
query myIncidents():
  return incidents last 200 by .at
query incidentFor(incident: incidents):
  return incidents[incident]
mutation reportIncident(fall: bool, title: text 1..100, details: text 1..4000):
  require exists roles[principal = viewer] else NO_ROLE
  insert incidents { author: viewer, fall, title, details, at: now }
  return { submitted: true }

invariant roles.role write only viewer = 'service:operator'
invariant bookings.read only .student = viewer or .coach = viewer
invariant progress.read only .student = viewer or .coach = viewer
invariant incidents.read only exists roles[principal = viewer, role = 'head_rigger'] or exists roles[principal = viewer, role = 'director'] or (.author = viewer and .fall = false)
invariant returns.insert only exists roles[principal = viewer, role = 'head_rigger']
