use identity password

-- Roles: one row per user. Users self-claim a role once at signup;
-- only officers can change a role afterwards.
table roles:
  principal: principal
  role: enum('owner', 'pumper', 'inspector', 'officer')
  unique principal
  read <- .principal = viewer
  insert <- .principal = viewer or exists roles[viewer, role = 'officer']
  update (old, next) <- exists roles[viewer, role = 'officer']
  delete <- deny
  online only

-- A septic property. dueAt is the next pumpout deadline: set at
-- registration (created + 3 years), moved by each pumpout report
-- (serviced + 3 years) and by officer extensions (max of the two).
table properties:
  owner: principal
  address: text 1..200
  createdAt: time default now
  lastServicedAt: time ?
  dueAt: time
  immutable owner, address, createdAt
  cap 200 by owner
  read <- .owner = viewer or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
  insert <- .owner = viewer
  update (old, next) <- old.owner = viewer or exists roles[viewer, role = 'officer'] or exists roles[viewer, role = 'pumper']
  delete <- .owner = viewer
  online only

-- One pumpout report filed by a licensed pumper, with a photo.
table reports:
  property: properties
  pumper: principal
  servicedAt: time
  photo: image <=10000000
  notes: text <=500 ?
  filedAt: time default now
  immutable property, pumper, servicedAt, photo
  cap 500 by property
  read <- .pumper = viewer or .property.owner = viewer or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
  insert <- .pumper = viewer
  update <- deny
  delete <- deny
  online only

-- Deadline extensions: officer only, recorded with a reason.
table extensions:
  property: properties
  grantedBy: principal
  reason: text 1..500
  extendedUntil: time
  grantedAt: time default now
  immutable property, grantedBy, reason, extendedUntil
  cap 50 by property
  read <- .property.owner = viewer or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
  insert <- exists roles[viewer, role = 'officer']
  update <- deny
  delete <- deny
  online only

-- Reminder rows written by the daily sweep job (system only).
table reminders:
  property: properties
  owner: principal
  dueAt: time
  kind: enum('due-soon', 'overdue')
  createdAt: time default now
  unique property, kind, dueAt
  immutable property, owner, dueAt, kind
  read <- .owner = viewer or exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer']
  insert <- deny
  update <- deny
  delete <- deny
  online only

query myRole():
  return roles[principal = viewer]

query myProperties(c: cursor ?):
  return properties where .owner = viewer last 50 by .dueAt after c

query allProperties(c: cursor ?):
  require exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer'] else NOT_INSPECTOR
  return properties last 50 by .dueAt after c

query overdueProperties(c: cursor ?):
  require exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer'] else NOT_INSPECTOR
  return properties where .dueAt < now first 50 by .dueAt after c

query dueSoonProperties(c: cursor ?):
  require exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer'] else NOT_INSPECTOR
  return properties where .dueAt >= now and .dueAt < now + 60d first 50 by .dueAt after c

query myReports(c: cursor ?):
  return reports where .pumper = viewer last 50 by .filedAt after c

query reportsOf(property: properties, c: cursor ?):
  return reports where .property = property last 50 by .servicedAt after c

query extensionsOf(property: properties, c: cursor ?):
  return extensions where .property = property last 50 by .grantedAt after c

query feed(c: cursor ?):
  require exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer'] else NOT_INSPECTOR
  return reports last 50 by .filedAt after c

query myReminders(c: cursor ?):
  return reminders where .owner = viewer last 50 by .dueAt after c

query allReminders(c: cursor ?):
  require exists roles[viewer, role = 'inspector'] or exists roles[viewer, role = 'officer'] else NOT_INSPECTOR
  return reminders last 50 by .dueAt after c

mutation claimRole(role: enum('owner', 'pumper', 'inspector', 'officer')):
  return insert roles { principal: viewer, role }

mutation grantRole(who: principal, role: enum('owner', 'pumper', 'inspector', 'officer')):
  require exists roles[viewer, role = 'officer'] else NOT_OFFICER
  return upsert roles[who] { role }

mutation addProperty(address: text 1..200):
  require exists roles[viewer, role = 'owner'] else NOT_OWNER
  return insert properties { owner: viewer, address, dueAt: now + 1095d }

mutation fileReport(property: properties, servicedAt: time, photo: image <=10000000, notes: text <=500 ?):
  require exists roles[viewer, role = 'pumper'] else NOT_PUMPER
  require servicedAt <= now else FUTURE_SERVICE
  update properties[property] { lastServicedAt: servicedAt, dueAt: servicedAt + 1095d }
  return insert reports { property, pumper: viewer, servicedAt, photo, notes }

mutation grantExtension(property: properties, extendedUntil: time, reason: text 1..500):
  require exists roles[viewer, role = 'officer'] else NOT_OFFICER
  require extendedUntil > now else BAD_EXTENSION
  p = properties[property] ! else NOT_FOUND
  due = p.dueAt if p.dueAt > extendedUntil else extendedUntil
  update properties[property] { dueAt: due }
  return insert extensions { property, grantedBy: viewer, reason, extendedUntil }

job sweepReminders(periodStart: time, periodEnd: time):
  for p in properties:
    if p.dueAt >= periodEnd + 59d and p.dueAt < periodEnd + 61d:
      if not exists reminders[p.id, 'due-soon', p.dueAt]:
        insert reminders { property: p.id, owner: p.owner, dueAt: p.dueAt, kind: 'due-soon' }
  for p in properties:
    if p.dueAt >= periodStart and p.dueAt < periodEnd:
      if not exists reminders[p.id, 'overdue', p.dueAt]:
        insert reminders { property: p.id, owner: p.owner, dueAt: p.dueAt, kind: 'overdue' }

schedule dailyReminders every 1d at 08:00: sweepReminders
