use identity password

table roles:
  principal: principal
  role: enum('volunteer', 'handler', 'head')
  label: text 1..100
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'head'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table assignments:
  bird: birds
  principal: principal
  active: bool default true
  unique bird, principal
  read <- (.principal = viewer and exists roles[viewer, role = 'volunteer']) or exists roles[viewer, role = 'head']
  insert <- exists roles[viewer, role = 'head']
  update <- exists roles[viewer, role = 'head']
  immutable bird, principal
  online only

table birds:
  name: text 1..80
  species: text 1..80
  minWeight: int 50..20000
  maxWeight: int 50..20000
  grams: int 1..20000 ?
  weighedAt: time ?
  grounded: bool default false
  lastFlownAt: time ?
  read <- exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'handler'] or (exists roles[viewer, role = 'volunteer'] and exists assignments[.id, viewer, active = true])
  insert <- exists roles[viewer, role = 'head']
  update <- exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'handler'] or (exists roles[viewer, role = 'volunteer'] and exists assignments[.id, viewer, active = true])
  online only

table weighings:
  bird: birds
  author: principal
  grams: int 1..20000
  food: int 0..2000
  photo: image <=5000000
  at: time default now
  read <- exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'handler'] or (exists roles[viewer, role = 'volunteer'] and exists assignments[.bird, viewer, active = true])
  insert <- .author = viewer and (exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'handler'] or (exists roles[viewer, role = 'volunteer'] and exists assignments[.bird, viewer, active = true]))
  online only

table flights:
  bird: birds
  author: principal
  at: time default now
  read <- exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'handler'] or (exists roles[viewer, role = 'volunteer'] and exists assignments[.bird, viewer, active = true])
  insert <- .author = viewer and (exists roles[viewer, role = 'head'] or exists roles[viewer, role = 'handler'] or (exists roles[viewer, role = 'volunteer'] and exists assignments[.bird, viewer, active = true]))
  online only

table clearances:
  bird: birds
  author: principal
  reason: text 5..1000
  at: time default now
  read <- exists roles[viewer, role = 'head']
  insert <- exists roles[viewer, role = 'head'] and .author = viewer
  online only

table veterinary:
  bird: birds
  author: principal
  body: text 1..4000
  at: time default now
  read <- exists roles[viewer, role = 'head']
  insert <- exists roles[viewer, role = 'head'] and .author = viewer
  online only

mutation provision(principal: principal, role: enum('volunteer', 'handler', 'head'), label: text 1..100):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, label }

query me():
  return roles[viewer]

query roster():
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  return roles first 100 by .id

query board(c: cursor ?):
  require exists roles[viewer] else NO_ROLE
  return birds first 100 by .id after c

query bird(bird: birds):
  require exists roles[viewer] else NO_ROLE
  return birds[bird]

query history(bird: birds):
  b = birds[bird] ! else NOT_FOUND
  return { weighings: weighings where .bird = b.id last 100 by .at, flights: flights where .bird = b.id last 100 by .at }

query privateNotes(bird: birds):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  return { notes: veterinary where .bird = bird last 100 by .at, clearances: clearances where .bird = bird last 100 by .at }

query birdAssignments(bird: birds):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  return assignments where .bird = bird and .active first 100 by .id

mutation createBird(name: text 1..80, species: text 1..80, minWeight: int 50..20000, maxWeight: int 50..20000):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  require minWeight < maxWeight else BAD_RANGE
  return insert birds { name, species, minWeight, maxWeight }

mutation assign(bird: birds, principal: principal):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  b = birds[bird] ! else NOT_FOUND
  require exists roles[principal, role = 'volunteer'] else NOT_VOLUNTEER
  return upsert assignments[b.id, principal] { bird: b.id, principal, active: true }

mutation unassign(bird: birds, principal: principal):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  update assignments[bird, principal] { active: false }

mutation weigh(bird: birds, grams: int 1..20000, food: int 0..2000, photo: image <=5000000):
  require exists roles[viewer] else NO_ROLE
  b = birds[bird] ! else NOT_FOUND
  w = insert weighings { bird, author: viewer, grams, food, photo }
  update birds[bird] { grams, weighedAt: now, grounded: b.grounded or grams < b.minWeight }
  return w

mutation fly(bird: birds):
  require exists roles[viewer] else NO_ROLE
  b = birds[bird] ! else NOT_FOUND
  require not b.grounded else GROUNDED 'Head falconer clearance is required.'
  require b.weighedAt != null else NEED_WEIGHING
  require b.weighedAt >= now - 3h else STALE_WEIGHT 'Weigh this bird again before flying.'
  require (b.grams ?? 0) >= b.minWeight and (b.grams ?? 0) <= b.maxWeight else OUTSIDE_RANGE
  f = insert flights { bird, author: viewer }
  update birds[bird] { lastFlownAt: now }
  return f

mutation setRange(bird: birds, minWeight: int 50..20000, maxWeight: int 50..20000):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  require minWeight < maxWeight else BAD_RANGE
  b = birds[bird] ! else NOT_FOUND
  update birds[bird] { minWeight, maxWeight, grounded: b.grounded or (b.grams != null and b.grams < minWeight) }

mutation clearGrounding(bird: birds, reason: text 5..1000):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  b = birds[bird] ! else NOT_FOUND
  require b.grounded else NOT_GROUNDED
  require (b.grams ?? 0) >= b.minWeight else STILL_UNDERWEIGHT
  insert clearances { bird, author: viewer, reason }
  update birds[bird] { grounded: false }

mutation addVetNote(bird: birds, body: text 1..4000):
  require exists roles[viewer, role = 'head'] else NOT_HEAD
  b = birds[bird] ! else NOT_FOUND
  return insert veterinary { bird: b.id, author: viewer, body }

invariant veterinary.read only exists roles[viewer, role = 'head']
invariant veterinary.insert only exists roles[viewer, role = 'head']
invariant clearances.read only exists roles[viewer, role = 'head']
invariant birds.minWeight write only exists roles[viewer, role = 'head']
invariant birds.maxWeight write only exists roles[viewer, role = 'head']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
