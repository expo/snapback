use identity password

table roles:
  principal: principal
  role: enum('rider', 'guide', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[principal = viewer, role = 'manager']
  insert <- viewer = 'service:operator' or (.principal = viewer and .role = 'rider')
  update <- viewer = 'service:operator'
  online only

table riderProfiles:
  owner: principal
  name: text 1..80
  weight: int 30..140
  signature: text 2..100
  waiver: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg')
  signedAt: time
  unique owner
  immutable owner
  read <- .owner = viewer
  insert <- .owner = viewer and exists roles[principal = viewer, role = 'rider']
  update <- .owner = viewer and exists roles[principal = viewer, role = 'rider']
  online only

table tours:
  title: text 1..100
  guide: principal
  startsAt: time
  capacity: int 1..30
  lines: int 1..8
  priceCents: int 100..50000
  booked: int 0..30 default 0
  cancelled: bool default false
  reason: text <=500 default ''
  cancelledBy: principal ?
  refundedAt: time ?
  immutable title, guide, startsAt, capacity, lines, priceCents
  read <- allow
  insert <- exists roles[principal = viewer, role = 'manager']
  update <- exists roles[principal = viewer, role = 'manager'] or exists roles[principal = viewer, role = 'rider']
  online only

table harnesses:
  serial: text 1..50
  manufacturedAt: time
  expiresAt: time
  uses: int 0..500 default 0
  retired: bool default false
  unique serial
  immutable serial, manufacturedAt, expiresAt
  read <- exists roles[principal = viewer, role = 'guide'] or exists roles[principal = viewer, role = 'manager']
  insert <- exists roles[principal = viewer, role = 'manager']
  update <- exists roles[principal = viewer, role = 'guide'] or exists roles[principal = viewer, role = 'manager']
  online only

table inspections:
  harness: harnesses
  inspector: principal
  photo: image <=5000000
  notes: text 1..500
  passed: bool
  at: time default now
  immutable harness, inspector, photo, notes, passed, at
  read <- exists roles[principal = viewer, role = 'guide'] or exists roles[principal = viewer, role = 'manager']
  insert <- .inspector = viewer and exists roles[principal = viewer, role = 'guide']
  online only

table bookings:
  tour: tours
  owner: principal
  guide: principal
  name: text 1..80
  weight: int 30..140
  signedAt: time
  paidCents: int 100..50000
  harness: harnesses ?
  clearedLine: int 0..8 default 0
  at: time default now
  unique tour, owner
  immutable tour, owner, guide, name, weight, signedAt, paidCents, at
  read <- .owner = viewer or .guide = viewer or exists roles[principal = viewer, role = 'manager']
  insert <- .owner = viewer and exists roles[principal = viewer, role = 'rider']
  update <- .guide = viewer and exists roles[principal = viewer, role = 'guide']
  online only

table refunds:
  tour: tours
  owner: principal
  amountCents: int 100..50000
  reason: text 10..500
  actor: principal
  at: time default now
  unique tour, owner
  immutable tour, owner, amountCents, reason, actor, at
  read <- .owner = viewer or exists roles[principal = viewer, role = 'manager']
  insert <- exists roles[principal = viewer, role = 'manager']
  online only

mutation enrollRider():
  existing = roles[principal = viewer]
  if existing != null:
    require existing.role = 'rider' else ALREADY_STAFF
    return existing
  return insert roles { principal: viewer, role: 'rider' }

mutation provision(principal: principal, role: enum('rider', 'guide', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }

query myRole():
  return roles[principal = viewer]

query staff():
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  return roles where .role = 'guide' first 100 by .id

mutation saveRider(name: text 1..80, weight: int 30..140, signature: text 2..100, waiver: file <=5000000 ('application/pdf', 'image/png', 'image/jpeg')):
  require exists roles[principal = viewer, role = 'rider'] else NOT_RIDER
  return upsert riderProfiles[owner = viewer] { owner: viewer, name, weight, signature, waiver, signedAt: now }

query myProfile():
  return riderProfiles[owner = viewer]

mutation createTour(title: text 1..100, guide: principal, startsAt: time, capacity: int 1..30, lines: int 1..8, priceCents: int 100..50000):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  require exists roles[principal = guide, role = 'guide'] else NOT_GUIDE
  require startsAt > now + 30m else TOO_SOON
  return insert tours { title, guide, startsAt, capacity, lines, priceCents }

query listTours():
  return tours first 200 by .id

mutation createHarness(serial: text 1..50, manufacturedAt: time):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  require manufacturedAt <= now and manufacturedAt > now - 36500d else BAD_DATE
  expiry = monthStart(month(manufacturedAt) + 60) + (manufacturedAt - monthStart(month(manufacturedAt)))
  return insert harnesses { serial, manufacturedAt, expiresAt: expiry, retired: expiry <= now }

query listHarnesses():
  require exists roles[principal = viewer, role = 'guide'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
  return harnesses first 200 by .id { id, serial, manufacturedAt, expiresAt, uses, retired: .retired or .uses >= 500 or .expiresAt <= now }

mutation inspect(harness: harnesses, photo: image <=5000000, notes: text 1..500, passed: bool):
  require exists roles[principal = viewer, role = 'guide'] else NOT_GUIDE
  h = harnesses[harness] ! else NOT_FOUND
  return insert inspections { harness, inspector: viewer, photo, notes, passed }

query inspectionsFor(harness: harnesses):
  require exists roles[principal = viewer, role = 'guide'] or exists roles[principal = viewer, role = 'manager'] else NOT_STAFF
  return inspections where .harness = harness last 100 by .id

mutation book(tour: tours):
  require exists roles[principal = viewer, role = 'rider'] else NOT_RIDER
  t = tours[tour] ! else NOT_FOUND
  require not t.cancelled else CANCELLED
  require now < t.startsAt - 30m else BOOKING_CLOSED
  p = riderProfiles[owner = viewer] ! else WAIVER_REQUIRED
  require t.booked < t.capacity else FULL
  update tours[tour] { booked: t.booked + 1 }
  return insert bookings { tour, owner: viewer, guide: t.guide, name: p.name, weight: p.weight, signedAt: p.signedAt, paidCents: t.priceCents }

query myBookings():
  return bookings where .owner = viewer first 200 by .id { id, tour, name, weight, harness, clearedLine, paidCents, refunded: tours[.tour].cancelled, refundReason: tours[.tour].reason, refund: refunds[.tour, viewer] }

query bookingById(booking: bookings):
  return bookings[booking]

query tourBoard(tour: tours):
  t = tours[tour] ! else NOT_FOUND
  require t.guide = viewer or exists roles[principal = viewer, role = 'manager'] else NOT_ASSIGNED
  return bookings where .tour = tour first 30 by .id

mutation fitHarness(booking: bookings, harness: harnesses):
  b = bookings[booking] ! else NOT_FOUND
  require b.guide = viewer and exists roles[principal = viewer, role = 'guide'] else NOT_ASSIGNED
  t = tours[b.tour] ! else NOT_FOUND
  require not t.cancelled else CANCELLED
  require now < t.startsAt + 1d else TOUR_ENDED
  require b.harness = null else ALREADY_FITTED
  h = harnesses[harness] ! else NOT_FOUND
  require not h.retired and h.uses < 500 and now < h.expiresAt else RETIRED
  i = inspections where .harness = harness last 1 by .id
  require count(i) = 1 else INSPECTION_REQUIRED
  for inspection in i:
    require inspection.passed and inspection.at >= now - 1d else INSPECTION_REQUIRED
  update harnesses[harness] { uses: h.uses + 1, retired: h.uses + 1 >= 500 }
  update bookings[booking] { harness }
  return bookings[booking]

mutation clearLine(booking: bookings, line: int 1..8):
  b = bookings[booking] ! else NOT_FOUND
  require b.guide = viewer and exists roles[principal = viewer, role = 'guide'] else NOT_ASSIGNED
  t = tours[b.tour] ! else NOT_FOUND
  require not t.cancelled else CANCELLED
  require now < t.startsAt + 1d else TOUR_ENDED
  require b.harness != null else HARNESS_REQUIRED
  require line = b.clearedLine + 1 and line <= t.lines else LINE_ORDER
  update bookings[booking] { clearedLine: line }
  return bookings[booking]

mutation cancelWeather(tour: tours, reason: text 10..500):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  t = tours[tour] ! else NOT_FOUND
  require not t.cancelled else ALREADY_CANCELLED
  for b in bookings where .tour = tour first 30 by .id:
    insert refunds { tour, owner: b.owner, amountCents: b.paidCents, reason, actor: viewer }
  update tours[tour] { cancelled: true, reason, cancelledBy: viewer, refundedAt: now }
  return tours[tour]

job retireHarnesses():
  for h in harnesses:
    if not h.retired and (h.uses >= 500 or h.expiresAt <= now):
      update harnesses[h.id] { retired: true }
schedule retirementSweep every 1m: retireHarnesses
