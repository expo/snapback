invariant orders.read only .farmer = viewer or .vet = viewer or exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager']
invariant deliveries.read only .farmer = viewer or exists people[principal = viewer, role = 'qualityManager']
invariant batches.read only exists people[principal = viewer, role = 'mixer'] or exists people[principal = viewer, role = 'qualityManager']
invariant people.insert only viewer = 'service:ops'
invariant orders.insert only .vet = viewer and exists people[principal = viewer, role = 'veterinarian']
invariant orders.update only .farmer = viewer
