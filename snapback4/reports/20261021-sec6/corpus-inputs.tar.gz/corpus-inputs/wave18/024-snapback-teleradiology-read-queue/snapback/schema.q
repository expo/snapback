use identity password

table accounts:
  person: principal
  email: text 3..160
  role: enum('hospital', 'physician', 'radiologist', 'lead', 'billing', 'director')
  hospital: text 1..60
  unique person
  immutable person, email, role, hospital
  read <- .person = viewer or exists accounts[person = viewer, role = 'director'] or viewer = 'service:setup'
  insert <- viewer = 'service:setup'
  online only

table privileges:
  person: principal
  hospital: text 1..60
  unique person, hospital
  immutable person, hospital
  read <- .person = viewer or exists accounts[person = viewer, role = 'director'] or viewer = 'service:setup'
  insert <- viewer = 'service:setup'
  online only

table onCall:
  hospital: text 1..60
  person: principal
  unique hospital
  read <- viewer = 'service:setup'
  insert <- viewer = 'service:setup'
  update <- viewer = 'service:setup'
  online only

table studies:
  hospital: text 1..60
  accession: text 1..80
  code: text 1..20
  physician: text 1..120
  notes: text 1..4000
  scan: image <=10000000
  urgency: enum('routine', 'urgent')
  uploadedAt: time
  dueAt: time
  uploader: principal
  status: enum('waiting', 'claimed', 'signed')
  assignee: principal ?
  immutable hospital, accession, code, physician, notes, scan, urgency, uploadedAt, dueAt, uploader
  read <- exists accounts[person = viewer, role = 'director'] or exists privileges[viewer, .hospital] or exists accounts[person = viewer, hospital = .hospital, role = 'hospital'] or exists accounts[person = viewer, hospital = .hospital, role = 'physician']
  insert <- .uploader = viewer and (exists accounts[person = viewer, hospital = .hospital, role = 'hospital'] or exists accounts[person = viewer, hospital = .hospital, role = 'physician'])
  update <- exists accounts[person = viewer, role = 'director'] or exists privileges[viewer, .hospital]
  online only

table billingCodes:
  study: studies
  hospital: text 1..60
  code: text 1..20
  immutable study, hospital, code
  read <- exists accounts[person = viewer, role = 'billing']
  insert <- created studies[.study]
  online only

table reports:
  study: studies
  hospital: text 1..60
  body: text 1..12000
  signer: principal
  signedAt: time
  unique study
  immutable study, hospital, body, signer, signedAt
  read <- exists accounts[person = viewer, role = 'director'] or exists privileges[viewer, .hospital] or exists accounts[person = viewer, hospital = .hospital, role = 'hospital'] or exists accounts[person = viewer, hospital = .hospital, role = 'physician']
  insert <- .signer = viewer and exists privileges[viewer, .hospital]
  online only

table amendments:
  study: studies
  hospital: text 1..60
  body: text 1..12000
  reason: text 1..1000
  actor: principal
  at: time
  immutable study, hospital, body, reason, actor, at
  read <- exists accounts[person = viewer, role = 'director'] or exists privileges[viewer, .hospital] or exists accounts[person = viewer, hospital = .hospital, role = 'hospital'] or exists accounts[person = viewer, hospital = .hospital, role = 'physician']
  insert <- .actor = viewer and exists accounts[person = viewer, role = 'director']
  online only

table assignments:
  study: studies
  hospital: text 1..60
  previous: principal
  next: principal
  reason: text 1..1000
  actor: principal
  at: time
  immutable study, hospital, previous, next, reason, actor, at
  read <- exists accounts[person = viewer, role = 'director'] or exists privileges[viewer, .hospital]
  insert <- .actor = viewer and exists accounts[person = viewer, role = 'director']
  online only

table escalations:
  study: studies
  recipient: principal
  at: time
  unique study
  immutable study, recipient, at
  read <- .recipient = viewer or exists accounts[person = viewer, role = 'director']
  online only

mutation provision(person: principal, email: text 3..160, role: enum('hospital', 'physician', 'radiologist', 'lead', 'billing', 'director'), hospital: text 1..60):
  require viewer = 'service:setup' else FORBIDDEN
  insert accounts { person, email, role, hospital }
  if role = 'radiologist' or role = 'lead':
    insert privileges { person, hospital }
  if role = 'lead':
    upsert onCall[hospital] { hospital, person }

query me():
  return accounts[person = viewer]

query directory():
  require exists accounts[person = viewer, role = 'director'] else FORBIDDEN
  return accounts first 100 by .id

query queue(c: cursor ?):
  return studies last 50 by .uploadedAt after c

query study(study: studies):
  return studies[study]

query billing(c: cursor ?):
  require exists accounts[person = viewer, role = 'billing'] else FORBIDDEN
  return billingCodes last 50 by .id after c

query report(study: studies):
  return { original: reports[study], amendments: amendments where .study = study first 100 by .id, assignments: assignments where .study = study first 100 by .id }

query alerts():
  return escalations last 50 by .at

mutation uploadStudy(accession: text 1..80, code: text 1..20, physician: text 1..120, notes: text 1..4000, scan: image <=10000000, urgency: enum('routine', 'urgent')):
  a = accounts[person = viewer] ! else FORBIDDEN
  require a.role = 'hospital' or a.role = 'physician' else FORBIDDEN
  s = insert studies { hospital: a.hospital, accession, code, physician, notes, scan, urgency, uploadedAt: now, dueAt: now + 30m, uploader: viewer, status: 'waiting', assignee: null }
  insert billingCodes { study: s.id, hospital: a.hospital, code }
  return s

mutation claim(study: studies):
  s = studies[study] ! else NOT_FOUND
  require exists privileges[viewer, s.hospital] else FORBIDDEN
  require s.status = 'waiting' else ALREADY_CLAIMED
  return update studies[study] { status: 'claimed', assignee: viewer }

mutation sign(study: studies, body: text 1..12000):
  s = studies[study] ! else NOT_FOUND
  require exists privileges[viewer, s.hospital] else FORBIDDEN
  require s.status = 'claimed' and s.assignee = viewer else NOT_ASSIGNED
  insert reports { study, hospital: s.hospital, body, signer: viewer, signedAt: now }
  return update studies[study] { status: 'signed' }

mutation reassign(study: studies, next: principal, reason: text 1..1000):
  require exists accounts[person = viewer, role = 'director'] else FORBIDDEN
  s = studies[study] ! else NOT_FOUND
  require s.status = 'claimed' and s.assignee != null else NOT_CLAIMED
  require exists privileges[next, s.hospital] else NOT_PRIVILEGED
  insert assignments { study, hospital: s.hospital, previous: s.assignee, next, reason, actor: viewer, at: now }
  return update studies[study] { assignee: next }

mutation amend(study: studies, body: text 1..12000, reason: text 1..1000):
  require exists accounts[person = viewer, role = 'director'] else FORBIDDEN
  s = studies[study] ! else NOT_FOUND
  require s.status = 'signed' else NOT_SIGNED
  return insert amendments { study, hospital: s.hospital, body, reason, actor: viewer, at: now }

job escalate():
  for s in studies by .uploadedAt:
    if s.urgency = 'urgent' and s.status != 'signed' and s.dueAt <= now:
      lead = onCall[s.hospital]
      if lead != null and not exists escalations[study = s.id]:
        insert escalations { study: s.id, recipient: lead.person, at: now }
schedule urgentWatch every 1m: escalate
