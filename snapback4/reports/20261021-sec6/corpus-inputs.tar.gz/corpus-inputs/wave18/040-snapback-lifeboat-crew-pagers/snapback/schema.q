use identity password

-- Only the local trusted operator provisions station membership. Signup alone
-- creates an unprivileged account, never a role.
table members:
  principal: principal
  name: text 2..60
  role: enum('crew', 'coxswain', 'coordinator', 'manager')
  unique principal
  immutable principal, role, name
  read <- .principal = viewer or exists members[viewer, role = 'coxswain'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  online only

table qualifications:
  principal: principal
  assessedAt: time ?
  assessor: principal ?
  unique principal
  immutable principal
  read <- .principal = viewer or exists members[viewer, role = 'coxswain']
  insert <- viewer = 'service:ops'
  update <- exists members[viewer, role = 'coxswain']
  online only

table station:
  key: text 1..20
  activeCall: calls ?
  unique key
  immutable key
  read <- exists members[viewer] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- exists members[viewer, role = 'coordinator']
  online only

table calls:
  title: text 3..100
  location: text 3..140
  capacity: int 1..12
  status: enum('paging', 'launched') default 'paging'
  pagedAt: time default now
  coordinator: principal
  launchedAt: time ?
  shortReason: text 10..500 ?
  approvedBy: principal ?
  approvedAt: time ?
  immutable title, location, capacity, pagedAt, coordinator
  read <- exists members[viewer] and exists station[key = 'main', activeCall = .id]
  insert <- exists members[viewer, role = 'coordinator'] and .coordinator = viewer
  update <- exists members[viewer, role = 'coordinator'] or exists members[viewer, role = 'manager']
  online only

table seats:
  call: calls
  principal: principal
  name: text 2..60
  arrivedAt: time default now
  qualifiedUntil: time
  unique call, principal else ALREADY_ARRIVED
  cap 12 by call
  immutable call, principal, name, arrivedAt, qualifiedUntil
  expire at .qualifiedUntil
  delete <- exists members[viewer, role = 'coxswain']
  read <- exists members[viewer] and exists station[key = 'main', activeCall = .call]
  insert <- .principal = viewer and (exists members[viewer, role = 'crew'] or exists members[viewer, role = 'coxswain'])
  online only

-- All casualty payload and media live in a separate, narrowly readable home.
table casualties:
  call: calls
  details: text 3..2000
  updatedBy: principal
  updatedAt: time default now
  unique call
  immutable call
  read <- exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
  insert <- exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
  update <- exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
  online only

table photos:
  call: calls
  photo: image <=5000000
  caption: text 3..140
  addedBy: principal
  at: time default now
  cap 8 by call
  immutable call, photo, caption, addedBy, at
  read <- exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
  insert <- exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
  online only

invariant qualifications.read only .principal = viewer or exists members[viewer, role = 'coxswain']
invariant qualifications.update only exists members[viewer, role = 'coxswain']
invariant members.insert only viewer = 'service:ops'
invariant casualties.read only exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
invariant photos.read only exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager']
invariant calls.authorizeShortCrew only exists members[viewer, role = 'manager']

fn expiry(t: time):
  target = month(t) + 24
  dayInMonth = day(t) - day(monthStart(month(t)))
  lastDay = (monthStart(target + 1) - monthStart(target)) / 1d - 1
  return monthStart(target) + min(dayInMonth, lastDay) * 1d + t % 1d

fn optionalExpiry(t: time ?):
  if t = null:
    return null
  return expiry(t)

fn current(call: calls):
  require exists members[viewer] else NOT_ENROLLED
  require exists station[key = 'main', activeCall = call] else NOT_CURRENT
  return calls[call] ! else NOT_CURRENT

mutation enroll(principal: principal, name: text 2..60, role: enum('crew', 'coxswain', 'coordinator', 'manager')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  require not exists members[principal] else ALREADY_ENROLLED
  insert members { principal, name, role }
  insert qualifications { principal }
  if not exists station[key = 'main']:
    insert station { key: 'main' }
  return null

query myRecord():
  m = members[viewer] ! else NOT_ENROLLED
  q = qualifications[viewer] ! else NOT_ENROLLED
  return { principal: viewer, name: m.name, role: m.role, assessedAt: q.assessedAt, expiresAt: expiry(q.assessedAt) if q.assessedAt != null else null, serverNow: now }

query recordFor(principal: principal):
  require principal = viewer or exists members[viewer, role = 'coxswain'] else RECORD_PRIVATE
  m = members[principal] ! else NOT_FOUND
  q = qualifications[principal] ! else NOT_FOUND
  return { principal, name: m.name, role: m.role, assessedAt: q.assessedAt, expiresAt: expiry(q.assessedAt) if q.assessedAt != null else null }

query qualificationRoster(c: cursor ?):
  require exists members[viewer, role = 'coxswain'] else COXSWAIN_ONLY
  return members after c first 100 by .id { principal, name, role, assessedAt: qualifications[.principal].assessedAt, expiresAt: optionalExpiry(qualifications[.principal].assessedAt) }

mutation assess(principal: principal, assessedAt: time):
  require exists members[viewer, role = 'coxswain'] else COXSWAIN_ONLY
  require assessedAt >= 0 and assessedAt <= now else BAD_ASSESSMENT_DATE
  require exists members[principal] else NOT_FOUND
  s = station[key = 'main'] ! else NOT_ENROLLED
  if s.activeCall != null:
    if exists seats[s.activeCall, principal]:
      delete seats[s.activeCall, principal]
  update qualifications[principal] { assessedAt, assessor: viewer }
  return null

query currentCall():
  require exists members[viewer] else NOT_ENROLLED
  s = station[key = 'main'] ! else NOT_ENROLLED
  if s.activeCall = null:
    return null
  return calls[s.activeCall]

query callBoard(call: calls):
  c = current(call)
  return { call: c, seats: seats where .call = call first 12 by .arrivedAt { id, principal, name, arrivedAt }, serverNow: now }

query casualtyRecord(call: calls):
  require exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager'] else CASUALTY_PRIVATE
  c = current(call)
  return { record: casualties[call], photos: photos where .call = call first 8 by .at }

mutation pageCrew(title: text 3..100, location: text 3..140, capacity: int 1..12):
  require exists members[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  s = station[key = 'main'] ! else NOT_ENROLLED
  if s.activeCall != null:
    previous = calls[s.activeCall] ! else NOT_CURRENT
    require previous.status = 'launched' else CALL_IN_PROGRESS
  c = insert calls { title, location, capacity, coordinator: viewer }
  update station[key = 'main'] { activeCall: c.id }
  return c.id

mutation arrive(call: calls):
  m = members[viewer] ! else NOT_ENROLLED
  require m.role = 'crew' or m.role = 'coxswain' else CREW_ONLY
  c = current(call)
  require c.status = 'paging' else ALREADY_LAUNCHED
  q = qualifications[viewer] ! else NOT_QUALIFIED
  require q.assessedAt != null else NOT_QUALIFIED
  require expiry(q.assessedAt) > now else QUALIFICATION_EXPIRED
  require not exists seats[call, viewer] else ALREADY_ARRIVED
  require count(seats where .call = call) < c.capacity else BOAT_FULL
  return insert seats { call, principal: viewer, name: m.name, qualifiedUntil: expiry(q.assessedAt) }

mutation saveCasualty(call: calls, details: text 3..2000):
  require exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager'] else CASUALTY_PRIVATE
  c = current(call)
  require c.status = 'paging' else ALREADY_LAUNCHED
  upsert casualties[call] { call, details, updatedBy: viewer, updatedAt: now }
  return null

mutation addPhoto(call: calls, photo: image <=5000000, caption: text 3..140):
  require exists members[viewer, role = 'coxswain'] or exists members[viewer, role = 'manager'] else CASUALTY_PRIVATE
  c = current(call)
  require c.status = 'paging' else ALREADY_LAUNCHED
  return insert photos { call, photo, caption, addedBy: viewer }

mutation authorizeShortCrew(call: calls, reason: text 10..500):
  require exists members[viewer, role = 'manager'] else MANAGER_ONLY
  c = current(call)
  require c.status = 'paging' else ALREADY_LAUNCHED
  require c.approvedBy = null else ALREADY_AUTHORIZED
  update calls[call] { shortReason: reason, approvedBy: viewer, approvedAt: now }
  return null

mutation launch(call: calls):
  require exists members[viewer, role = 'coordinator'] else COORDINATOR_ONLY
  c = current(call)
  require c.status = 'paging' else ALREADY_LAUNCHED
  -- Seats expire with their qualification. Reassessment releases a held seat.
  valid = count(seats where .call = call)
  require valid >= c.capacity or c.approvedBy != null else SHORT_CREW_NOT_AUTHORIZED
  update calls[call] { status: 'launched', launchedAt: now }
  return null
