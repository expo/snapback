-- Substation Switching Orders.
-- Roles: switchman, crew, operator, contractor, supervisor.
-- Password identity only: no personas, no guests. The roster is provisioned
-- by the local operator seat (service:operator); see mutation enroll.
use identity password

table roster:
  principal: principal
  role: enum('switchman', 'crew', 'operator', 'contractor', 'supervisor')
  area: text 1..40
  unique principal
  read <- .principal = viewer or exists roster[viewer, role = 'supervisor'] or exists roster[viewer, role = 'operator']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  delete <- viewer = 'service:operator'
  online only

table equipment:
  name: text 1..80
  area: text 1..40
  kind: text 1..40 ?
  immutable name, area
  read <- exists roster[viewer] and (not exists roster[viewer, role = 'contractor'] or exists roster[viewer, area = .area])
  insert <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  update <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  delete <- exists roster[viewer, role = 'supervisor']
  online only

table clearances:
  title: text 1..120
  equipment: equipment
  area: text 1..40
  createdBy: principal
  grantedAt: time default now
  expiresAt: time
  nextSeq: int default 1
  immutable equipment, area, createdBy, grantedAt
  read <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] or exists clearanceMembers[.id, viewer] or (exists roster[viewer, role = 'contractor'] and exists roster[viewer, area = .area])
  insert <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  update <- exists roster[viewer, role = 'switchman'] or exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  online only

table clearanceMembers:
  clearance: clearances
  principal: principal
  unique clearance, principal
  immutable clearance, principal
  read <- .principal = viewer or exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] or exists clearanceMembers[.clearance, viewer]
  insert <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  delete <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  online only

table steps:
  clearance: clearances
  seq: int 1..1000
  title: text 1..200
  state: enum('pending', 'confirmed', 'skipped') default 'pending'
  photo: image <=10000000 ?
  confirmedBy: principal ?
  confirmedAt: time ?
  approvedBy: principal ?
  approvalReason: text 1..500 ?
  unique clearance, seq else SEQ_TAKEN
  immutable clearance
  cap 500 by clearance
  read through .clearance
  insert <- exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor']
  update <- exists roster[viewer, role = 'switchman'] or exists roster[viewer, role = 'supervisor']
  online only

query whoAmI():
  return viewer

query myRole():
  return roster[viewer]

query myClearances(c: cursor ?):
  me = roster[viewer] ! else NOT_ENROLLED
  if me.role = 'operator' or me.role = 'supervisor':
    return clearances last 50 by .id after c
  if me.role = 'contractor':
    return clearances where .area = me.area last 50 by .id after c
  return clearances where exists clearanceMembers[.id, viewer] last 50 by .id after c

query clearanceDetail(clearance: clearances):
  return clearances[clearance]

query clearanceSteps(clearance: clearances, c: cursor ?):
  return steps where .clearance = clearance first 200 by .seq after c

query clearanceMembersOf(clearance: clearances, c: cursor ?):
  return clearanceMembers where .clearance = clearance first 100 by .id after c

query equipmentBoard(c: cursor ?):
  me = roster[viewer] ! else NOT_ENROLLED
  if me.role = 'contractor':
    return equipment where .area = me.area last 100 by .id after c
  return equipment last 100 by .id after c

mutation enroll(who: principal, role: enum('switchman', 'crew', 'operator', 'contractor', 'supervisor'), area: text 1..40):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roster[who] { principal: who, role, area }

mutation createEquipment(name: text 1..80, area: text 1..40, kind: text 1..40 ?):
  require exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] else NOT_OPERATOR
  return insert equipment { name, area, kind }

mutation issueClearance(title: text 1..120, equipment: equipment):
  require exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] else NOT_OPERATOR
  e = equipment[equipment] ! else NOT_FOUND
  return insert clearances { title, equipment: e.id, area: e.area, createdBy: viewer, grantedAt: now, expiresAt: now + 12h, nextSeq: 1 }

mutation addCrewMember(clearance: clearances, who: principal):
  require exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] else NOT_OPERATOR
  c = clearances[clearance] ! else NOT_FOUND
  return insert clearanceMembers { clearance: c.id, principal: who }

mutation addStep(clearance: clearances, seq: int 1..1000, title: text 1..200):
  require exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] else NOT_OPERATOR
  c = clearances[clearance] ! else NOT_FOUND
  require c.expiresAt > now else EXPIRED
  return insert steps { clearance: c.id, seq, title }

mutation confirmStep(step: steps, photo: image <=10000000):
  require exists roster[viewer, role = 'switchman'] else NOT_SWITCHMAN
  s = steps[step] ! else NOT_FOUND
  require exists clearanceMembers[s.clearance, viewer] else NOT_ON_CREW
  c = clearances[s.clearance] ! else NOT_FOUND
  require c.expiresAt > now else EXPIRED
  require s.state = 'pending' else ALREADY_DONE
  require s.seq = c.nextSeq else OUT_OF_SEQUENCE
  update steps[s.id] { state: 'confirmed', photo, confirmedBy: viewer, confirmedAt: now }
  update clearances[c.id] { nextSeq: c.nextSeq + 1 }
  return null

mutation renewClearance(clearance: clearances):
  require exists roster[viewer, role = 'operator'] else NOT_OPERATOR
  c = clearances[clearance] ! else NOT_FOUND
  update clearances[c.id] { expiresAt: now + 12h }
  return null

mutation approveSkip(step: steps, reason: text 1..500):
  require exists roster[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  s = steps[step] ! else NOT_FOUND
  c = clearances[s.clearance] ! else NOT_FOUND
  require s.state = 'pending' else ALREADY_DONE
  require s.seq = c.nextSeq else OUT_OF_SEQUENCE
  update steps[s.id] { state: 'skipped', approvedBy: viewer, approvalReason: reason }
  update clearances[c.id] { nextSeq: c.nextSeq + 1 }
  return null

mutation reorderStep(step: steps, newSeq: int 1..1000, reason: text 1..500):
  require exists roster[viewer, role = 'supervisor'] else NOT_SUPERVISOR
  s = steps[step] ! else NOT_FOUND
  c = clearances[s.clearance] ! else NOT_FOUND
  require s.state = 'pending' else ALREADY_DONE
  require newSeq >= c.nextSeq else TOO_EARLY
  require not exists steps[s.clearance, newSeq] else SEQ_TAKEN
  update steps[s.id] { seq: newSeq, approvedBy: viewer, approvalReason: reason }
  return null

-- Independent privacy intent; guide security states unproved paths.
invariant roster.read only .principal = viewer or exists roster[viewer, role = 'supervisor'] or exists roster[viewer, role = 'operator']
invariant equipment.read only exists roster[viewer]
invariant clearances.read only exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] or exists clearanceMembers[.id, viewer]
invariant clearanceMembers.read only .principal = viewer or exists roster[viewer, role = 'operator'] or exists roster[viewer, role = 'supervisor'] or exists clearanceMembers[.clearance, viewer]
