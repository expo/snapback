-- Fire Watch Patrols.
-- Roles: guard, tenant, supervisor (security supervisor), manager
-- (property manager), marshal (fire marshal).
-- Real authentication: email + password accounts (no personas, no guests).
use identity password

-- Buildings hold watches. The directory is public to signed-in users so a
-- signing-up tenant can pick their building; watch contents stay private.
table buildings:
  name: text 1..80
  address: text 1..200 ?
  public 'building directory is visible to signed-in users'
  insert <- exists users[viewer, role = 'manager']
  cap 200

-- One profile row per account. Role is immutable: it is chosen once at
-- sign-up and can never be escalated afterwards. Tenants must name a
-- building; anyone may leave it null otherwise.
table users:
  principal: principal
  role: enum('guard', 'tenant', 'supervisor', 'manager', 'marshal')
  building: buildings ?
  unique principal
  immutable principal, role
  cap 1 by principal
  read <- .principal = viewer or exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal']
  insert <- .principal = viewer
  update <- .principal = viewer

-- A fire watch on one building while its sprinklers are impaired.
-- Tenants may read only active watches in their own building; everyone else
-- with a duty role reads every watch; guards read watches they staff.
table watches:
  building: buildings
  status: enum('active', 'ended') default 'active'
  startedAt: time default now
  startedBy: principal
  endedAt: time ?
  endReason: text 1..500 ?
  report: image <=10000000 ?
  immutable building, startedBy
  cap 500 by building
  read <- exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal'] or exists assignments[.id, viewer] or (exists users[principal = viewer, role = 'tenant', building = .building] and .status = 'active')
  insert <- exists users[viewer, role = 'manager']
  update <- exists users[viewer, role = 'manager']

-- Guard staffing per watch. Only the property manager assigns.
table assignments:
  watch: watches
  guard: principal
  assignedAt: time default now
  assignedBy: principal
  unique watch, guard
  immutable watch, guard
  cap 100 by watch
  read <- exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal'] or exists assignments[.watch, viewer]
  insert <- exists users[viewer, role = 'manager']
  delete <- exists users[viewer, role = 'manager']

-- Patrol checkpoints of a watch. lastScanAt is maintained by recordScan;
-- null means never scanned (overdue). Tenants cannot read floors.
table floors:
  watch: watches
  number: int 0..200
  label: text 1..40 ?
  lastScanAt: time ?
  unique watch, number
  immutable watch, number
  cap 200 by watch
  read <- exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal'] or exists assignments[.watch, viewer]
  insert <- exists users[viewer, role = 'manager']
  update <- exists assignments[.watch, viewer] or exists users[viewer, role = 'manager']

-- One tag scan per patrol visit. Guard must staff the watch; watch active.
table scans:
  floor: floors
  guard: principal
  at: time default now
  note: text 1..280 ?
  immutable floor, guard, at
  cap 5000 by floor
  read through .floor
  insert <- .guard = viewer and exists assignments[.floor.watch, viewer]

-- Hazards found on patrol, with a required photo. Append-only.
table hazards:
  floor: floors
  description: text 1..500
  photo: image <=10000000
  reportedBy: principal
  at: time default now
  immutable floor, description, photo, reportedBy, at
  cap 500 by floor
  read through .floor
  insert <- .reportedBy = viewer and exists assignments[.floor.watch, viewer]

-- Independent privacy intent (guide security). Declarations grant nothing.
invariant users.read only .principal = viewer or exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal']
invariant users.insert only .principal = viewer
invariant watches.read only exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal'] or exists assignments[.id, viewer] or (exists users[principal = viewer, role = 'tenant', building = .building] and .status = 'active')
invariant floors.read only exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal'] or exists assignments[.watch, viewer]
invariant watches.endWatch only exists users[viewer, role = 'manager']
invariant assignments.assignGuard only exists users[viewer, role = 'manager']
invariant scans.recordScan only exists assignments[.floor.watch, viewer]
invariant hazards.reportHazard only exists assignments[.floor.watch, viewer]

-- Profiles and directory.
query myProfile():
  return users[principal = viewer]

query buildingsList(c: cursor ?):
  return buildings first 50 by .id after c

query guardsList(c: cursor ?):
  require exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] else STAFF_ONLY
  return users where .role = 'guard' first 50 by .id after c

-- Guard's own staffing, with the watch rows embedded.
query assignedWatches(c: cursor ?):
  return assignments where .guard = viewer first 50 by .id after c { id, w: watches[.watch] }

-- Duty roles see every watch; the fire marshal's history access is this query.
query allWatches(c: cursor ?):
  require exists users[viewer, role = 'manager'] or exists users[viewer, role = 'supervisor'] or exists users[viewer, role = 'marshal'] else DUTY_ONLY
  return watches last 50 by .id after c

-- Tenants see only whether a watch is active in their building: ids and
-- start times, nothing about patrols, floors, scans or hazards.
query tenantStatus():
  me = users[principal = viewer] ! else NO_PROFILE
  require me.role = 'tenant' else TENANTS_ONLY
  require me.building != null else NO_BUILDING
  return watches where .building = me.building and .status = 'active' first 10 by .id { id, startedAt }

query watchDetail(watch: watches):
  return watches[watch] ! else NOT_FOUND

query watchFloors(watch: watches, c: cursor ?):
  return floors where .watch = watch first 100 by .number after c

query watchScans(watch: watches, c: cursor ?):
  return scans where .floor.watch = watch last 50 by .at after c

query watchHazards(watch: watches, c: cursor ?):
  return hazards where .floor.watch = watch last 50 by .at after c

-- Security-supervisor alert list: floors of a watch (or every watch) with no
-- scan in the last 30 minutes. Never-scanned floors are always overdue.
query overdueFloors(watch: watches ?, c: cursor ?):
  me = users[principal = viewer] ! else NO_PROFILE
  require me.role = 'supervisor' or me.role = 'manager' else SUPERVISORS_ONLY
  return floors where (watch = null or .watch = watch) and (.lastScanAt = null or .lastScanAt < now - 30m) first 100 by .watch after c

mutation setProfile(role: enum('guard', 'tenant', 'supervisor', 'manager', 'marshal'), building: buildings ?):
  require role != 'tenant' or building != null else TENANT_NEEDS_BUILDING
  return upsert users[viewer] { principal: viewer, role, building }

mutation createBuilding(name: text 1..80, address: text 1..200 ?):
  require exists users[viewer, role = 'manager'] else MANAGERS_ONLY
  return insert buildings { name, address }

mutation startWatch(building: buildings):
  require exists users[viewer, role = 'manager'] else MANAGERS_ONLY
  b = buildings[building] ! else NOT_FOUND
  return insert watches { building, status: 'active', startedAt: now, startedBy: viewer }

mutation addFloor(watch: watches, number: int 0..200, label: text 1..40 ?):
  require exists users[viewer, role = 'manager'] else MANAGERS_ONLY
  w = watches[watch] ! else NOT_FOUND
  require w.status = 'active' else WATCH_ENDED
  return insert floors { watch, number, label }

mutation assignGuard(watch: watches, guard: principal):
  require exists users[viewer, role = 'manager'] else MANAGERS_ONLY
  w = watches[watch] ! else NOT_FOUND
  require w.status = 'active' else WATCH_ENDED
  g = users[guard]
  require g != null else NO_SUCH_USER
  require g.role = 'guard' else NOT_A_GUARD
  return insert assignments { watch, guard, assignedAt: now, assignedBy: viewer }

mutation recordScan(floor: floors, at: time ?, note: text 1..280 ?):
  f = floors[floor] ! else NOT_FOUND
  require exists assignments[f.watch, viewer] else NOT_ASSIGNED
  w = watches[f.watch] ! else NOT_FOUND
  require w.status = 'active' else WATCH_ENDED
  scanAt = at ?? now
  require scanAt <= now + 5m else FUTURE_SCAN
  s = insert scans { floor, guard: viewer, at: scanAt, note }
  update floors[floor] { lastScanAt: scanAt }
  return s

mutation reportHazard(floor: floors, description: text 1..500, photo: image <=10000000):
  f = floors[floor] ! else NOT_FOUND
  require exists assignments[f.watch, viewer] else NOT_ASSIGNED
  w = watches[f.watch] ! else NOT_FOUND
  require w.status = 'active' else WATCH_ENDED
  return insert hazards { floor, description, photo, reportedBy: viewer, at: now }

mutation endWatch(watch: watches, reason: text 1..500, report: image <=10000000):
  require exists users[viewer, role = 'manager'] else MANAGERS_ONLY
  w = watches[watch] ! else NOT_FOUND
  require w.status = 'active' else WATCH_ALREADY_ENDED
  update watches[watch] { status: 'ended', endedAt: now, endReason: reason, report }
  return watches[watch]
