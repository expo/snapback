-- Wheelchair Repair Loaners.
-- A mobility clinic repairs clients' wheelchairs and lends a loaner chair
-- while the repair is done. Roles: client, technician, coordinator, manager.
use identity password

-- Roster: one row per user. Anyone may self-register as a client; staff
-- roles are granted by the clinic manager (or the service operator seat).
table roles:
  principal: principal
  role: enum('client', 'technician', 'coordinator', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  insert <- (.principal = viewer and .role = 'client') or viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  delete <- viewer = 'service:operator' or exists roles[viewer, role = 'manager']
  online only

-- Clients' own wheelchairs. Technicians read (they repair them); intake
-- and edits are the client or the front desk (coordinator/manager).
table chairs:
  owner: principal
  label: text 1..80
  notes: text <=500 ?
  createdAt: time default now
  immutable owner
  cap 20 by owner
  read <- .owner = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  insert <- .owner = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  update <- .owner = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  delete <- viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Clients' funding paperwork. Private to the client and the front desk:
-- technicians never see it.
table funding:
  client: principal
  funder: text 1..80
  limitCents: int
  paperwork: text <=2000 ?
  unique client
  immutable client
  read <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  insert <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  update <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Approval thresholds, one per client. The numeric limit is workflow state
-- (like a job ticket's auth max): staff can read it to enforce the approval
-- gate. The paperwork itself stays in funding, which technicians never see.
-- setFunding is the only writer of both rows, so they cannot drift apart.
table limits:
  client: principal
  limitCents: int
  unique client
  immutable client
  read <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  insert <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  update <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Repair jobs on clients' chairs. Clients read their own and watch status
-- live; technicians/coordinators/managers work them. Clients never write.
table repairs:
  chair: chairs
  client: principal
  problem: text 1..500
  status: enum('intake', 'in_progress', 'ready', 'closed') default 'intake'
  costCents: int default 0
  approved: bool default false
  approvalReason: text <=500 ?
  funderRef: text <=120 ?
  readyAt: time ?
  createdAt: time default now
  immutable chair, client
  cap 100 by client
  read <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  insert <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Parts logged against a repair. Readers inherit the repair's audience.
table parts:
  repair: repairs
  name: text 1..120
  costCents: int default 0
  at: time default now
  immutable repair
  cap 50 by repair
  read through .repair
  insert <- viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  delete <- viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Loaner chairs lent while a repair is done. Condition photos at handover
-- and return are required by the lending/return mutations. dueAt is stamped
-- when the client's own chair becomes ready (readyAt + 7 days).
table loans:
  repair: repairs
  client: principal
  loanerLabel: text 1..80
  handoverPhoto: image <=5000000 ?
  returnPhoto: image <=5000000 ?
  dueAt: time ?
  returnedAt: time ?
  createdAt: time default now
  unique repair else ALREADY_LENT
  immutable repair, client
  cap 50 by client
  read <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  insert <- viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Overdue-loaner follow-ups. Only the sweep job writes them.
table followups:
  loan: loans
  client: principal
  note: text 1..280
  resolved: bool default false
  createdAt: time default now
  unique loan else ALREADY_FLAGGED
  immutable loan, client
  cap 50 by client
  read <- .client = viewer or viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  insert <- deny
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  delete <- viewer = 'service:operator' or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
  online only

-- Daily sweep: flag loaners still out more than seven days after the
-- client's own chair became ready.
job flagOverdue(periodStart: time, periodEnd: time):
  for l in loans:
    r = repairs[l.repair]
    if r != null and r.status = 'ready' and r.readyAt != null and l.returnedAt = null and r.readyAt + 7d < periodEnd:
      if not exists followups[l.id]:
        insert followups { loan: l.id, client: l.client, note: 'Loaner is overdue. Please follow up with the client.' }

schedule overdueSweep every 1d at 08:00: flagOverdue

query myRole():
  return roles[viewer]

query roster(c: cursor ?):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return roles last 50 by .id after c

query myChairs(c: cursor ?):
  return chairs where .owner = viewer last 50 by .createdAt after c

query allChairs(c: cursor ?):
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_STAFF
  return chairs last 50 by .createdAt after c

query myRepairs(c: cursor ?):
  return repairs where .client = viewer last 50 by .createdAt after c

query allRepairs(c: cursor ?):
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_STAFF
  return repairs last 50 by .createdAt after c

query repairDetail(repair: repairs):
  return repairs[repair] ! else NOT_FOUND

query repairParts(repair: repairs, c: cursor ?):
  r = repairs[repair] ! else NOT_FOUND
  return parts where .repair = r.id last 50 by .at after c

query myLoans(c: cursor ?):
  return loans where .client = viewer last 50 by .createdAt after c

query allLoans(c: cursor ?):
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_STAFF
  return loans last 50 by .createdAt after c

query overdueLoans(c: cursor ?):
  require exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_COORDINATOR
  return loans where .returnedAt = null and .dueAt != null and .dueAt < now first 50 by .dueAt after c

query myFunding():
  return funding[client = viewer]

query clientFunding(client: principal):
  require exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_COORDINATOR
  return funding[client = client]

query followupsList(c: cursor ?):
  if exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']:
    return followups last 50 by .createdAt after c
  return followups where .client = viewer last 50 by .createdAt after c

mutation joinAsClient():
  return insert roles { principal: viewer, role: 'client' }

mutation provision(who: principal, role: enum('client', 'technician', 'coordinator', 'manager')):
  require viewer = 'service:operator' or exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return upsert roles[who] { principal: who, role }

mutation addChair(owner: principal ?, label: text 1..80, notes: text <=500 ?):
  o = owner ?? viewer
  require o = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_INTAKE
  return insert chairs { owner: o, label, notes }

mutation fileRepair(chair: chairs, problem: text 1..500):
  c = chairs[chair] ! else NOT_FOUND
  require c.owner = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_INTAKE
  return insert repairs { chair, client: c.owner, problem }

mutation setFunding(client: principal, funder: text 1..80, limitCents: int, paperwork: text <=2000 ?):
  require limitCents >= 0 else BAD_LIMIT
  require client = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_FUNDING
  upsert funding[client] { client, funder, limitCents, paperwork }
  return upsert limits[client] { client, limitCents }

mutation logPart(repair: repairs, name: text 1..120, costCents: int):
  require costCents >= 0 else BAD_COST
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_TECHNICIAN
  r = repairs[repair] ! else NOT_FOUND
  return insert parts { repair, name, costCents }

mutation removePart(part: parts):
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_TECHNICIAN
  delete parts[part]
  return null

mutation setEstimate(repair: repairs, costCents: int):
  require costCents >= 0 else BAD_COST
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_TECHNICIAN
  r = repairs[repair] ! else NOT_FOUND
  update repairs[repair] { costCents }
  return null

mutation setStatus(repair: repairs, status: enum('intake', 'in_progress', 'ready', 'closed')):
  require exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_TECHNICIAN
  r = repairs[repair] ! else NOT_FOUND
  l = loans[r.id]
  if status = 'ready':
    f = limits[r.client]
    limit = f.limitCents if f != null else 0
    require r.approved or r.costCents <= limit else NEEDS_APPROVAL
    update repairs[repair] { status, readyAt: now }
    if l != null and l.returnedAt = null:
      update loans[l.id] { dueAt: now + 7d }
  else:
    if status = 'closed':
      require l = null or l.returnedAt != null else LOAN_OUT
    update repairs[repair] { status }
    if r.status = 'ready':
      update repairs[repair] { readyAt: null }
      if l != null and l.returnedAt = null:
        update loans[l.id] { dueAt: null }
  return null

mutation approveRepair(repair: repairs, reason: text 1..500, funderRef: text 1..120):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  r = repairs[repair] ! else NOT_FOUND
  f = limits[r.client]
  limit = f.limitCents if f != null else 0
  require r.costCents > limit else NOT_ABOVE_LIMIT
  update repairs[repair] { approved: true, approvalReason: reason, funderRef }
  return null

mutation lendLoaner(repair: repairs, loanerLabel: text 1..80, handoverPhoto: image <=5000000):
  require exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_COORDINATOR
  r = repairs[repair] ! else NOT_FOUND
  require r.status != 'closed' else REPAIR_CLOSED
  due = r.readyAt + 7d if r.readyAt != null else null
  return insert loans { repair, client: r.client, loanerLabel, handoverPhoto, dueAt: due }

mutation recordReturn(loan: loans, returnPhoto: image <=5000000):
  require exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_COORDINATOR
  l = loans[loan] ! else NOT_FOUND
  require l.returnedAt = null else ALREADY_RETURNED
  update loans[loan] { returnPhoto, returnedAt: now }
  return { id: l.id, late: l.dueAt != null and l.dueAt < now }

mutation resolveFollowup(followup: followups):
  require exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager'] else NOT_COORDINATOR
  f = followups[followup] ! else NOT_FOUND
  update followups[followup] { resolved: true }
  return null

-- Independent privacy intent; guide security states unproved paths.
invariant chairs.read only .owner = viewer or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
invariant repairs.read only .client = viewer or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
invariant loans.read only .client = viewer or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
invariant funding.read only .client = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
invariant funding.insert only .client = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
invariant funding.update only .client = viewer or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
invariant limits.read only .client = viewer or exists roles[viewer, role = 'technician'] or exists roles[viewer, role = 'coordinator'] or exists roles[viewer, role = 'manager']
