-- Mass Spec Sample Queue.
-- Roles: researcher, technician, pi (principal investigator), director.
-- Researchers submit batches for their group; technicians run the instrument;
-- PIs see their group's charges; the director reorders the queue and waives
-- rerun charges. Memberships are provisioned by the service operator only.
use identity password

table memberships:
  principal: principal
  role: enum('researcher', 'technician', 'pi', 'director')
  group: text 1..40
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('researcher', 'technician', 'pi', 'director'), group: text 1..40):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert memberships[principal] { principal, role, group }

query myMembership():
  return memberships[viewer]

-- Instrument queue. Every registered user reads the queue, but sample names
-- and results live in child tables with group-scoped rules.
table batches:
  owner: principal
  group: text 1..40
  title: text 1..120
  detail: text <=2000 ?
  coc: image <=10000000
  status: enum('queued', 'running', 'completed', 'failed')
  queuePos: time default now
  createdAt: time default now
  immutable owner, group, coc, createdAt
  read <- exists memberships[principal = viewer]
  insert <- exists memberships[principal = viewer, role = 'researcher', group = .group]
  update (old, next) <- old.owner = viewer or exists memberships[principal = viewer, role = 'technician'] or exists memberships[principal = viewer, role = 'director']
  cap 500 by group
  online only

query queue(c: cursor ?):
  require exists memberships[principal = viewer] else NOT_REGISTERED
  return batches first 50 by .queuePos after c

query groupBatches(c: cursor ?):
  m = memberships[viewer] ! else NOT_REGISTERED
  return batches where .group = m.group first 50 by .queuePos after c

mutation submitBatch(title: text 1..120, detail: text <=2000 ?, coc: image <=10000000):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'researcher' else NOT_RESEARCHER
  return insert batches { owner: viewer, group: m.group, title, detail, coc, status: 'queued' }

mutation editBatch(batch: batches, title: text 1..120, detail: text <=2000 ?):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'researcher' else NOT_RESEARCHER
  b = batches[batch] ! else NOT_FOUND
  require b.owner = viewer else NOT_OWNER
  require b.status = 'queued' else NOT_QUEUED
  update batches[batch] { title, detail }
  return batches[batch]

-- Private sample names: same group, plus staff (technicians run every batch,
-- the director oversees the facility).
table samples:
  batch: batches
  group: text 1..40
  name: text 1..120
  note: text <=500 ?
  immutable batch, group
  read <- exists memberships[principal = viewer, group = .group] or exists memberships[principal = viewer, role = 'technician'] or exists memberships[principal = viewer, role = 'director']
  insert <- exists memberships[principal = viewer, role = 'researcher', group = .group]
  update (old, next) <- exists memberships[principal = viewer, group = old.group] or exists memberships[principal = viewer, role = 'technician'] or exists memberships[principal = viewer, role = 'director']
  cap 200 by batch
  online only

query batchSamples(batch: batches, c: cursor ?):
  b = batches[batch] ! else NOT_FOUND
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.group = b.group or m.role = 'technician' or m.role = 'director' else NOT_IN_GROUP
  return samples where .batch = batch first 50 by .id after c

mutation addSample(batch: batches, name: text 1..120, note: text <=500 ?):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'researcher' else NOT_RESEARCHER
  b = batches[batch] ! else NOT_FOUND
  require b.group = m.group else NOT_IN_GROUP
  require b.owner = viewer else NOT_OWNER
  require b.status = 'queued' else NOT_QUEUED
  return insert samples { batch, group: b.group, name, note }

-- Released results: downloadable for 90 days, then archived (expired).
table results:
  batch: batches
  group: text 1..40
  summary: text <=2000
  report: file <=10000000 ?
  releasedAt: time
  expiresAt: time ?
  unique batch
  immutable batch, group, releasedAt, expiresAt
  read <- exists memberships[principal = viewer, group = .group] or exists memberships[principal = viewer, role = 'technician'] or exists memberships[principal = viewer, role = 'director']
  insert <- exists memberships[principal = viewer, role = 'technician']
  expire at .expiresAt
  online only

query batchResults(batch: batches, c: cursor ?):
  b = batches[batch] ! else NOT_FOUND
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.group = b.group or m.role = 'technician' or m.role = 'director' else NOT_IN_GROUP
  return results where .batch = batch first 20 by .id after c

-- Charges: PIs read their own group's charges, the director reads everything.
table charges:
  batch: batches
  group: text 1..40
  amountCents: int 0..100000000
  kind: enum('run', 'rerun')
  waived: bool
  waiveReason: text <=280 ?
  immutable batch, group, amountCents, kind
  cap 500 by group
  read <- exists memberships[principal = viewer, group = .group, role = 'pi'] or exists memberships[principal = viewer, role = 'director']
  insert <- exists memberships[principal = viewer, role = 'technician']
  update (old, next) <- exists memberships[principal = viewer, role = 'director']
  online only

query groupCharges(c: cursor ?):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'pi' else NOT_PI
  return charges where .group = m.group first 50 by .id after c

query allCharges(c: cursor ?):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'director' else NOT_DIRECTOR
  return charges first 50 by .id after c

-- Audit log: every reorder and every waived charge, with a reason.
table events:
  kind: enum('reorder', 'waive', 'failed')
  actor: principal
  batch: batches ?
  group: text 1..40
  reason: text 1..280
  at: time default now
  immutable kind, actor, batch, group, reason, at
  read <- exists memberships[principal = viewer, role = 'technician'] or exists memberships[principal = viewer, role = 'director']
  insert <- exists memberships[principal = viewer, role = 'technician'] or exists memberships[principal = viewer, role = 'director']
  online only

query auditLog(c: cursor ?):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'technician' or m.role = 'director' else NOT_STAFF
  return events last 50 by .at after c

-- Technician operates the instrument.
mutation startRun(batch: batches):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'technician' else NOT_TECHNICIAN
  b = batches[batch] ! else NOT_FOUND
  require b.status = 'queued' else NOT_QUEUED
  update batches[batch] { status: 'running' }
  return batches[batch]

mutation failRun(batch: batches, reason: text 1..280):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'technician' else NOT_TECHNICIAN
  b = batches[batch] ! else NOT_FOUND
  require b.status = 'running' else NOT_RUNNING
  update batches[batch] { status: 'failed' }
  insert events { kind: 'failed', actor: viewer, batch, group: b.group, reason }
  return batches[batch]

mutation completeRun(batch: batches):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'technician' else NOT_TECHNICIAN
  b = batches[batch] ! else NOT_FOUND
  require b.status = 'running' else NOT_RUNNING
  update batches[batch] { status: 'completed' }
  return batches[batch]

mutation releaseResults(batch: batches, summary: text <=2000, report: file <=10000000 ?, amountCents: int 0..100000000):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'technician' else NOT_TECHNICIAN
  b = batches[batch] ! else NOT_FOUND
  require b.status = 'completed' else NOT_COMPLETED
  require results[batch] = null else ALREADY_RELEASED
  insert results { batch, group: b.group, summary, report, releasedAt: now, expiresAt: now + 90d }
  insert charges { batch, group: b.group, amountCents, kind: 'run', waived: false }
  return results[batch]

mutation rerunCharge(batch: batches, amountCents: int 0..100000000):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'technician' else NOT_TECHNICIAN
  b = batches[batch] ! else NOT_FOUND
  require b.status = 'completed' or b.status = 'failed' else NOT_DONE
  c = insert charges { batch, group: b.group, amountCents, kind: 'rerun', waived: false }
  update batches[batch] { status: 'queued' }
  return c

-- Only the facility director moves a batch ahead or waives a rerun charge.
mutation reorderBatch(batch: batches, aheadOf: batches, reason: text 1..280):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'director' else NOT_DIRECTOR
  b = batches[batch] ! else NOT_FOUND
  target = batches[aheadOf] ! else NOT_FOUND
  require b.status = 'queued' else NOT_QUEUED
  require target.status = 'queued' else NOT_QUEUED
  update batches[batch] { queuePos: target.queuePos - 1ms }
  insert events { kind: 'reorder', actor: viewer, batch, group: b.group, reason }
  return batches[batch]

mutation waiveCharge(charge: charges, reason: text 1..280):
  m = memberships[viewer] ! else NOT_REGISTERED
  require m.role = 'director' else NOT_DIRECTOR
  c = charges[charge] ! else NOT_FOUND
  update charges[charge] { waived: true, waiveReason: reason }
  insert events { kind: 'waive', actor: viewer, batch: c.batch, group: c.group, reason }
  return charges[charge]
