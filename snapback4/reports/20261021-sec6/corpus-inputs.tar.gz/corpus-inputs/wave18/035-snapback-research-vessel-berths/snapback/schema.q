use identity password

table roles:
  principal: principal
  role: enum('chief', 'scientist', 'crew', 'captain', 'superintendent')
  name: text 1..80
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'superintendent'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table cruises:
  title: text 1..120
  chief: principal
  departure: time
  endsAt: time
  immutable chief, departure, endsAt
  read <- .chief = viewer or exists berths[.id, viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
  insert <- exists roles[viewer, role = 'superintendent']
  online only

table berths:
  cruise: cruises
  person: principal
  name: text 1..80
  addedBy: principal
  lateReason: text <=500
  boarded: bool default false
  unique cruise, person
  immutable cruise, person, name, addedBy, lateReason
  read <- exists cruises[.cruise, chief = viewer] or exists berths[.cruise, viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
  insert <- .addedBy = viewer and (exists cruises[.cruise, chief = viewer] or exists roles[viewer, role = 'superintendent'])
  update <- exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
  cap 40 by cruise
  online only

table stations:
  cruise: cruises
  equipment: text 1..120
  startsAt: time
  minutes: int 1..720
  completed: bool default false
  immutable cruise, equipment, startsAt, minutes
  read <- exists cruises[.cruise, chief = viewer] or exists berths[.cruise, viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
  insert <- exists cruises[.cruise, chief = viewer]
  update <- exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain']
  cap 300 by cruise
  online only

table medical:
  owner: principal
  document: file <=2000000 ('application/pdf', 'image/png', 'image/jpeg')
  at: time
  unique owner
  immutable owner
  read <- exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
  insert <- .owner = viewer and exists roles[viewer]
  update <- .owner = viewer and exists roles[viewer]
  online only

table survival:
  owner: principal
  document: file <=2000000 ('application/pdf', 'image/png', 'image/jpeg')
  at: time
  unique owner
  immutable owner
  read <- .owner = viewer or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
  insert <- .owner = viewer and exists roles[viewer]
  update <- .owner = viewer and exists roles[viewer]
  online only

mutation provision(principal: principal, role: enum('chief', 'scientist', 'crew', 'captain', 'superintendent'), name: text 1..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role, name }

query me():
  return roles[viewer]

query people():
  require exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'superintendent'] else NOT_PLANNER
  return roles first 100 by .id

query myCruises():
  return cruises last 100 by .id

query plan(cruise: cruises):
  return cruises[cruise]

query crewList(cruise: cruises):
  require exists cruises[cruise] else NOT_FOUND
  return berths where .cruise = cruise first 40 by .id

query deck(cruise: cruises):
  require exists cruises[cruise] else NOT_FOUND
  return stations where .cruise = cruise first 300 by .startsAt

query medicalRecord(person: principal):
  require exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent'] else MEDICAL_PRIVATE
  return medical[person]

query survivalRecord(person: principal):
  require person = viewer or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent'] else SURVIVAL_PRIVATE
  return survival[person]

mutation createCruise(title: text 1..120, chief: principal, departure: time, endsAt: time):
  require exists roles[viewer, role = 'superintendent'] else NOT_SUPERINTENDENT
  require exists roles[chief, role = 'chief'] else NOT_CHIEF
  require departure > now else DEPARTURE_PAST
  require endsAt > departure and endsAt <= departure + 90d else BAD_END
  return insert cruises { title, chief, departure, endsAt }

mutation requestBerth(cruise: cruises, person: principal, reason: text <=500):
  c = cruises[cruise] ! else NOT_FOUND
  require c.chief = viewer or exists roles[viewer, role = 'superintendent'] else NOT_PLANNER
  require now < c.departure else DEPARTED
  if now >= c.departure - 14d:
    require exists roles[viewer, role = 'superintendent'] else LIST_LOCKED
    require len(trim(reason)) >= 5 else REASON_REQUIRED
  p = roles[person] ! else UNKNOWN_PERSON
  return insert berths { cruise, person, name: p.name, addedBy: viewer, lateReason: trim(reason) }

mutation requestDeck(cruise: cruises, equipment: text 1..120, startsAt: time, minutes: int 1..720):
  c = cruises[cruise] ! else NOT_FOUND
  require c.chief = viewer else NOT_CHIEF
  require now < c.departure else DEPARTED
  require startsAt >= c.departure and startsAt + minutes * 1m <= c.endsAt else OUTSIDE_CRUISE
  return insert stations { cruise, equipment, startsAt, minutes }

mutation completeStation(station: stations):
  require exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] else NOT_CREW
  s = stations[station] ! else NOT_FOUND
  require not s.completed else ALREADY_COMPLETE
  update stations[station] { completed: true }

mutation uploadMedical(document: file <=2000000 ('application/pdf', 'image/png', 'image/jpeg')):
  return upsert medical[viewer] { owner: viewer, document, at: now }

mutation uploadSurvival(document: file <=2000000 ('application/pdf', 'image/png', 'image/jpeg')):
  return upsert survival[viewer] { owner: viewer, document, at: now }

mutation board(berth: berths):
  require exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent'] else NOT_BOARDING_OFFICER
  b = berths[berth] ! else NOT_FOUND
  require exists medical[b.person] and exists survival[b.person] else DOCUMENTS_REQUIRED
  require not b.boarded else ALREADY_BOARDED
  update berths[berth] { boarded: true }

invariant medical.read only exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
invariant medical.insert only .owner = viewer
invariant medical.update only .owner = viewer
invariant survival.read only .owner = viewer or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
invariant roles.insert only viewer = 'service:operator'
invariant roles.update only viewer = 'service:operator'
invariant cruises.insert only exists roles[viewer, role = 'superintendent']
invariant cruises.read only .chief = viewer or exists berths[.id, viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
invariant berths.read only exists cruises[.cruise, chief = viewer] or exists berths[.cruise, viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
invariant stations.read only exists cruises[.cruise, chief = viewer] or exists berths[.cruise, viewer] or exists roles[viewer, role = 'crew'] or exists roles[viewer, role = 'captain'] or exists roles[viewer, role = 'superintendent']
