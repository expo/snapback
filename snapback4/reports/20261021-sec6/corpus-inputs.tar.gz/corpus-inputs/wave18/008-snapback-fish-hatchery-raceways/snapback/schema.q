-- Fish Hatchery Raceways.
-- Trout raceways in units; culturists log feed, mortalities and water
-- readings (with photos of anything abnormal). A treated raceway is held
-- for its withdrawal period counted from the last treatment; only the fish
-- health biologist prescribes treatments or clears a raceway early with a
-- recorded reason. Culturists see only their assigned units and never lab
-- reports; the manager sees every raceway; drivers see only their loads.
use identity password

-- Roster: one row per account. Managers read the roster (to assign loads to
-- drivers); everyone else reads only their own row. Only the local
-- operator seat writes it, through `provision`.
table staff:
  principal: principal
  role: enum('culturist', 'manager', 'driver', 'biologist')
  unit: text 1..40 ?
  unique principal
  immutable principal
  read <- .principal = viewer or exists staff[viewer, role = 'manager'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

mutation provision(who: principal, role: enum('culturist', 'manager', 'driver', 'biologist'), unit: text 1..40 ?):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert staff[who] { role, unit }

query myRole():
  return staff[viewer]

-- Raceways. name/unit never change, so the biologist's hold-field updates
-- below cannot rename or reassign a raceway. Only the manager creates them.
table raceways:
  name: text 1..80
  unit: text 1..40
  unique name else NAME_TAKEN 'A raceway already uses this name.'
  immutable name, unit
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .unit]
  insert <- exists staff[viewer, role = 'manager']
  online only

mutation addRaceway(name: text 1..80, unit: text 1..40):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  return insert raceways { name, unit }

-- Current withdrawal hold per raceway, written only by the biologist.
-- clearedAt >= lastTreatedAt means a clearance came after the last
-- treatment, releasing the raceway early.
table treatmentHolds:
  raceway: raceways
  lastTreatedAt: time
  withdrawalDays: int 0..90 default 0
  holdUntil: time
  clearedAt: time ?
  reason: text 1..500 ?
  unique raceway
  immutable raceway
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  insert <- exists staff[viewer, role = 'biologist']
  update <- exists staff[viewer, role = 'biologist']
  delete <- exists staff[viewer, role = 'biologist']
  online only

-- Daily logs. Writers: the culturist assigned to the raceway's unit, or
-- the manager. Readers: same audience plus the biologist.
table feedLogs:
  raceway: raceways
  grams: int 1..500000
  note: text 1..500 ?
  photo: image <=5000000 ?
  at: time default now
  immutable raceway, at
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  insert <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  online only

table mortalityLogs:
  raceway: raceways
  count: int 1..100000
  note: text 1..500 ?
  photo: image <=5000000 ?
  at: time default now
  immutable raceway, at
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  insert <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  online only

table waterReadings:
  raceway: raceways
  tempC: int -10..40
  ph10: int 0..140
  oxygenMgL: int 0..30
  note: text 1..500 ?
  photo: image <=5000000 ?
  at: time default now
  immutable raceway, at
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  insert <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  online only

mutation logFeed(raceway: raceways, grams: int 1..500000, note: text 1..500 ?, photo: image <=5000000 ?):
  r = raceways[raceway] ! else NOT_FOUND
  require exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'culturist', unit = r.unit] else NOT_ASSIGNED
  return insert feedLogs { raceway, grams, note, photo }

mutation logMortality(raceway: raceways, count: int 1..100000, note: text 1..500 ?, photo: image <=5000000 ?):
  r = raceways[raceway] ! else NOT_FOUND
  require exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'culturist', unit = r.unit] else NOT_ASSIGNED
  return insert mortalityLogs { raceway, count, note, photo }

mutation logWater(raceway: raceways, tempC: int -10..40, ph10: int 0..140, oxygenMgL: int 0..30, note: text 1..500 ?, photo: image <=5000000 ?):
  r = raceways[raceway] ! else NOT_FOUND
  require exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'culturist', unit = r.unit] else NOT_ASSIGNED
  return insert waterReadings { raceway, tempC, ph10, oxygenMgL, note, photo }

-- Treatments and early clearances: biologist only, reason recorded.
table treatments:
  raceway: raceways
  medication: text 1..120
  withdrawalDays: int 0..90
  treatedAt: time default now
  prescribedBy: principal default viewer
  immutable raceway, medication, withdrawalDays, treatedAt, prescribedBy
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  insert <- exists staff[viewer, role = 'biologist']
  online only

table clearances:
  raceway: raceways
  reason: text 1..500
  clearedAt: time default now
  clearedBy: principal default viewer
  immutable raceway, reason, clearedAt, clearedBy
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
  insert <- exists staff[viewer, role = 'biologist']
  online only

mutation prescribeTreatment(raceway: raceways, medication: text 1..120, withdrawalDays: int 0..90):
  require exists staff[viewer, role = 'biologist'] else NOT_BIOLOGIST
  r = raceways[raceway] ! else NOT_FOUND
  t = insert treatments { raceway, medication, withdrawalDays, prescribedBy: viewer }
  if exists treatmentHolds[raceway]:
    delete treatmentHolds[raceway = raceway]
  insert treatmentHolds { raceway, lastTreatedAt: now, withdrawalDays, holdUntil: now + withdrawalDays * 1d }
  return t

mutation clearRaceway(raceway: raceways, reason: text 1..500):
  require exists staff[viewer, role = 'biologist'] else NOT_BIOLOGIST
  r = raceways[raceway] ! else NOT_FOUND
  h = treatmentHolds[raceway = raceway] ! else NO_HOLD 'This raceway has no treatment hold to clear.'
  update treatmentHolds[raceway = raceway] { clearedAt: now, reason }
  return insert clearances { raceway, reason, clearedBy: viewer }

-- Lab reports: manager and biologist only. Culturists never see them.
table labReports:
  raceway: raceways
  title: text 1..120
  findings: text 1..2000
  sampledAt: time default now
  attachment: image <=5000000 ?
  immutable raceway, title, findings, sampledAt
  read <- exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist']
  insert <- exists staff[viewer, role = 'biologist']
  online only

mutation addLabReport(raceway: raceways, title: text 1..120, findings: text 1..2000, attachment: image <=5000000 ?):
  require exists staff[viewer, role = 'biologist'] else NOT_BIOLOGIST
  r = raceways[raceway] ! else NOT_FOUND
  return insert labReports { raceway, title, findings, attachment }

-- Stocking loads. Drivers read only their own loads; the raceway label is
-- snapshotted so drivers never need raceway reads. Only the manager assigns.
table loads:
  raceway: raceways
  racewayLabel: text 1..80
  driver: principal
  destination: text 1..120
  scheduledAt: time
  status: enum('assigned', 'loaded', 'delivered', 'cancelled') default 'assigned'
  createdAt: time default now
  immutable raceway, racewayLabel, driver, destination, scheduledAt, createdAt
  read <- .driver = viewer or exists staff[viewer, role = 'manager']
  insert <- exists staff[viewer, role = 'manager']
  update <- .driver = viewer or exists staff[viewer, role = 'manager']
  online only

mutation assignLoad(raceway: raceways, driver: principal, destination: text 1..120, scheduledAt: time):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  require exists staff[driver, role = 'driver'] else NOT_DRIVER 'Loads may only be assigned to a stocking truck driver.'
  r = raceways[raceway] ! else NOT_FOUND
  require scheduledAt >= now else LOAD_IN_PAST 'Loads are scheduled now or in the future.'
  h = treatmentHolds[raceway = raceway]
  if h != null:
    if now < h.holdUntil:
      require (h.clearedAt ?? 0) >= h.lastTreatedAt else WITHDRAWAL_HOLD 'The withdrawal period has not passed.'
  return insert loads { raceway, racewayLabel: r.name, driver, destination, scheduledAt }

mutation updateLoadStatus(load: loads, status: enum('loaded', 'delivered')):
  l = loads[load] ! else NOT_FOUND
  require l.driver = viewer or exists staff[viewer, role = 'manager'] else NOT_DRIVER
  require l.status = 'assigned' and status = 'loaded' or l.status = 'loaded' and status = 'delivered' else BAD_TRANSITION 'Loads move assigned to loaded to delivered.'
  update loads[load] { status }

mutation cancelLoad(load: loads):
  l = loads[load] ! else NOT_FOUND
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  require l.status = 'assigned' or l.status = 'loaded' else BAD_TRANSITION 'Only an open load can be cancelled.'
  update loads[load] { status: 'cancelled' }

-- Boards and detail reads. Table rules still hide every unreadable row.
query board(c: cursor ?):
  require exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] else NOT_MANAGER
  return raceways last 100 by .id after c

query myRaceways(c: cursor ?):
  s = staff[viewer] ! else NOT_ENROLLED
  require s.role = 'culturist' else NOT_CULTURIST
  return raceways where .unit = s.unit first 100 by .id after c

query racewayById(raceway: raceways):
  return raceways[raceway]

query releaseStatus(raceway: raceways):
  r = raceways[raceway] ! else NOT_FOUND
  return treatmentHolds[raceway = raceway]

query feedLogsFor(raceway: raceways, c: cursor ?):
  return feedLogs where .raceway = raceway last 50 by .at after c

query mortalityLogsFor(raceway: raceways, c: cursor ?):
  return mortalityLogs where .raceway = raceway last 50 by .at after c

query waterReadingsFor(raceway: raceways, c: cursor ?):
  return waterReadings where .raceway = raceway last 50 by .at after c

query treatmentsFor(raceway: raceways, c: cursor ?):
  return treatments where .raceway = raceway last 50 by .treatedAt after c

query clearancesFor(raceway: raceways, c: cursor ?):
  return clearances where .raceway = raceway last 50 by .clearedAt after c

query labReportsFor(raceway: raceways, c: cursor ?):
  return labReports where .raceway = raceway last 50 by .sampledAt after c

query myLoads(c: cursor ?):
  return loads where .driver = viewer last 50 by .scheduledAt after c

query roster(c: cursor ?):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  return staff last 100 by .id after c

query allLoads(c: cursor ?):
  require exists staff[viewer, role = 'manager'] else NOT_MANAGER
  return loads last 100 by .scheduledAt after c

-- Privacy and authority intent, stated apart from enforcement.
invariant raceways.read only exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .unit]
invariant labReports.read only exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist']
invariant loads.read only .driver = viewer or exists staff[viewer, role = 'manager']
invariant treatments.insert only exists staff[viewer, role = 'biologist']
invariant clearances.insert only exists staff[viewer, role = 'biologist']
invariant loads.insert only exists staff[viewer, role = 'manager']
invariant feedLogs.read only exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .unit]
invariant mortalityLogs.read only exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .unit]
invariant waterReadings.read only exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .unit]
invariant treatmentHolds.read only exists staff[viewer, role = 'manager'] or exists staff[viewer, role = 'biologist'] or exists staff[viewer, role = 'culturist', unit = .raceway.unit]
invariant staff.read only .principal = viewer or exists staff[viewer, role = 'manager']
