use identity password

table roles:
  principal: principal
  role: enum('exhibitor', 'judge', 'clerk', 'manager')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator' or exists roles[principal = viewer, role = 'manager']
  insert <- viewer = 'service:operator'
  update <- viewer = 'service:operator'
  online only

table shows:
  manager: principal
  title: text 1..100
  opensAt: time
  immutable manager, opensAt
  read <- allow
  insert <- .manager = viewer and exists roles[principal = viewer, role = 'manager'] or viewer = 'service:operator'
  online only

table rings:
  show: shows
  label: text 1..60
  judge: principal
  clerk: principal
  finished: bool default false
  immutable show, judge, clerk
  read <- allow
  insert <- exists shows[id = .show, manager = viewer] or viewer = 'service:operator'
  update <- .clerk = viewer
  online only

table showStaff:
  show: shows
  principal: principal
  unique show, principal
  immutable show, principal
  read <- .principal = viewer or exists shows[id = .show, manager = viewer] or viewer = 'service:operator'
  insert <- exists shows[id = .show, manager = viewer] or viewer = 'service:operator'
  update <- exists shows[id = .show, manager = viewer] or viewer = 'service:operator'
  online only

table catalog:
  cap 50 by show
  show: shows
  number: int 1..99999
  class: enum('Kitten', 'Championship', 'Premiership', 'Household')
  disqualified: bool default false
  reason: text <=500 default ''
  unique show, number
  immutable show, number
  read <- exists shows[id = .show, manager = viewer] or exists showStaff[.show, viewer]
  insert <- exists roles[principal = viewer, role = 'exhibitor'] or viewer = 'service:operator'
  update <- exists shows[id = .show, manager = viewer]
  online only

table entries:
  owner: principal
  show: shows
  cat: catalog
  name: text 1..100
  class: enum('Kitten', 'Championship', 'Premiership', 'Household')
  disqualified: bool default false
  reason: text <=500 default ''
  registration: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')
  vaccination: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')
  unique cat
  immutable owner, show, cat, name
  read <- .owner = viewer or exists shows[id = .show, manager = viewer]
  insert <- .owner = viewer and exists roles[principal = viewer, role = 'exhibitor'] or viewer = 'service:operator'
  update <- .owner = viewer or exists shows[id = .show, manager = viewer]
  online only

table scores:
  show: shows
  ring: rings
  cat: catalog
  judge: principal
  placement: int 1..50
  comments: text 1..1000
  unique ring, cat
  unique ring, placement
  immutable ring, cat, judge, show
  read <- .judge = viewer or exists rings[id = .ring, clerk = viewer] or exists rings[id = .ring, finished = true] and exists entries[cat = .cat, owner = viewer] or exists shows[id = .show, manager = viewer]
  insert <- .judge = viewer and exists rings[id = .ring, judge = viewer, finished = false] or viewer = 'service:operator'
  update <- .judge = viewer and exists rings[id = .ring, judge = viewer, finished = false]
  online only

table board:
  ring: rings
  number: int 1..99999
  class: enum('Kitten', 'Championship', 'Premiership', 'Household')
  placement: int 1..50
  unique ring, number
  immutable ring, number, class, placement
  read <- allow
  insert <- exists rings[id = .ring, clerk = viewer] or viewer = 'service:operator'
  online only

table decisions:
  show: shows
  cat: catalog
  manager: principal
  action: enum('transfer', 'disqualify')
  reason: text 1..500
  class: enum('Kitten', 'Championship', 'Premiership', 'Household')
  at: time default now
  immutable cat, show, manager, action, reason, class, at
  read <- exists shows[id = .show, manager = viewer] or exists showStaff[.show, viewer] or exists entries[cat = .cat, owner = viewer]
  insert <- .manager = viewer and exists shows[id = .cat.show, manager = viewer] or viewer = 'service:operator'
  online only

mutation provision(principal: principal, role: enum('exhibitor', 'judge', 'clerk', 'manager')):
  require viewer = 'service:operator' else NOT_OPERATOR
  return upsert roles[principal] { principal, role }
query myRole():
  return roles[viewer]
query staff():
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  return roles where .role != 'exhibitor' first 100 by .id
query listShows():
  return shows first 100 by .id
query listRings(show: shows):
  return rings where .show = show first 100 by .id
query myEntries():
  require exists roles[principal = viewer, role = 'exhibitor'] else NOT_EXHIBITOR
  return entries where .owner = viewer first 100 by .id { id, name, show, cat, class, disqualified, reason, registration, vaccination }
query entry(entry: entries):
  return entries[entry]
query ringCats(ring: rings):
  r = rings[ring] ! else NOT_FOUND
  require r.judge = viewer or r.clerk = viewer or exists shows[id = r.show, manager = viewer] else NOT_ASSIGNED
  return catalog where .show = r.show first 100 by .number
query ringScores(ring: rings):
  return scores where .ring = ring first 100 by .placement
query myResults(cat: catalog):
  require exists entries[cat = cat, owner = viewer] else PRIVATE_ENTRY
  return scores where .cat = cat first 100 by .id
query liveBoard(ring: rings):
  return board where .ring = ring first 100 by .placement
query history(cat: catalog):
  return decisions where .cat = cat first 100 by .at

mutation createShow(title: text 1..100, opensAt: time):
  require exists roles[principal = viewer, role = 'manager'] else NOT_MANAGER
  return insert shows { manager: viewer, title, opensAt }
mutation createRing(show: shows, label: text 1..60, judge: principal, clerk: principal):
  s = shows[show] ! else NOT_FOUND
  require s.manager = viewer else NOT_SHOW_MANAGER
  require exists roles[principal = judge, role = 'judge'] else NOT_JUDGE
  require exists roles[principal = clerk, role = 'clerk'] else NOT_CLERK
  upsert showStaff[show, judge] { show, principal: judge }
  upsert showStaff[show, clerk] { show, principal: clerk }
  return insert rings { show, label, judge, clerk }
mutation createEntry(show: shows, number: int 1..99999, name: text 1..100, class: enum('Kitten', 'Championship', 'Premiership', 'Household'), registration: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png'), vaccination: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  require exists roles[principal = viewer, role = 'exhibitor'] else NOT_EXHIBITOR
  s = shows[show] ! else NOT_FOUND
  require now < s.opensAt - 21d else ENTRIES_CLOSED 'Entries and papers close 21 days before opening.'
  c = insert catalog { show, number, class }
  return insert entries { owner: viewer, show, cat: c.id, name, class, registration, vaccination }
mutation replacePapers(entry: entries, registration: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png'), vaccination: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  e = entries[entry] ! else NOT_FOUND
  require e.owner = viewer else PRIVATE_ENTRY
  s = shows[e.show] ! else NOT_FOUND
  require now < s.opensAt - 21d else ENTRIES_CLOSED
  update entries[entry] { registration, vaccination }
mutation judgeCat(ring: rings, cat: catalog, placement: int 1..50, comments: text 1..1000):
  r = rings[ring] ! else NOT_FOUND
  require r.judge = viewer else NOT_RING_JUDGE
  s = shows[r.show] ! else NOT_FOUND
  require now >= s.opensAt else SHOW_NOT_OPEN
  require not r.finished else RING_FINISHED
  c = catalog[cat] ! else NOT_FOUND
  require c.show = r.show else WRONG_SHOW
  require not c.disqualified else DISQUALIFIED
  return upsert scores[ring, cat] { ring, cat, show: r.show, judge: viewer, placement, comments }
mutation finishRing(ring: rings):
  r = rings[ring] ! else NOT_FOUND
  require r.clerk = viewer else NOT_RING_CLERK
  require not r.finished else RING_FINISHED
  s = shows[r.show] ! else NOT_FOUND
  require now >= s.opensAt else SHOW_NOT_OPEN
  for c in catalog where .show = r.show by .number:
    if not c.disqualified:
      score = scores[ring, c.id] ! else MISSING_PLACEMENT
      insert board { ring, number: c.number, class: c.class, placement: score.placement }
  update rings[ring] { finished: true }
mutation transferCat(cat: catalog, class: enum('Kitten', 'Championship', 'Premiership', 'Household'), reason: text 1..500):
  c = catalog[cat] ! else NOT_FOUND
  s = shows[c.show] ! else NOT_FOUND
  require s.manager = viewer else NOT_SHOW_MANAGER
  require not c.disqualified else DISQUALIFIED
  require not exists rings[show = c.show, finished = true] else RESULTS_FINAL
  update catalog[cat] { class, reason }
  update entries[cat = cat] { class, reason }
  return insert decisions { cat, show: c.show, manager: viewer, action: 'transfer', reason, class }
mutation disqualifyCat(cat: catalog, reason: text 1..500):
  c = catalog[cat] ! else NOT_FOUND
  s = shows[c.show] ! else NOT_FOUND
  require s.manager = viewer else NOT_SHOW_MANAGER
  require not exists rings[show = c.show, finished = true] else RESULTS_FINAL
  update catalog[cat] { disqualified: true, reason }
  update entries[cat = cat] { disqualified: true, reason }
  return insert decisions { cat, show: c.show, manager: viewer, action: 'disqualify', reason, class: c.class }

-- Operator-only historical fixture import; never exposed in the ordinary UI.
mutation importLive(manager: principal, judge: principal, clerk: principal, owner: principal, registration: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png'), vaccination: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  require viewer = 'service:operator' else NOT_OPERATOR
  s = insert shows { manager, title: 'Autumn championship · live ring', opensAt: now - 1d }
  upsert showStaff[s.id, judge] { show: s.id, principal: judge }
  upsert showStaff[s.id, clerk] { show: s.id, principal: clerk }
  r = insert rings { show: s.id, label: 'Live judging', judge, clerk }
  c = insert catalog { show: s.id, number: 101, class: 'Championship' }
  e = insert entries { owner, show: s.id, cat: c.id, name: 'Silver Mistral', class: 'Championship', registration, vaccination }
  return { show: s.id, ring: r.id, cat: c.id, entry: e.id }
