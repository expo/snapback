use identity password

table people:
  principal: principal
  name: text 1..80
  role: enum('technician', 'siteLead', 'siteManager', 'landowner')
  unique principal
  immutable principal, role
  read <- .principal = viewer or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager'] or exists people[principal = viewer, role = 'technician'] and .role = 'technician' or viewer = 'service:provisioner'
  insert <- viewer = 'service:provisioner'
  online only

table training:
  technician: principal
  validUntil: time
  unique technician
  immutable technician
  read <- .technician = viewer or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager']
  insert <- exists people[principal = viewer, role = 'siteManager']
  update <- exists people[principal = viewer, role = 'siteManager']
  online only

table turbines:
  label: text 1..80
  land: text 1..80
  landowner: principal
  immutable label, land, landowner
  read <- exists people[principal = viewer, role = 'technician'] or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager']
  insert <- exists people[principal = viewer, role = 'siteManager']
  online only

table permits:
  turbine: turbines
  first: principal
  second: principal
  requestedAt: time
  state: enum('requested', 'active', 'lapsed') default 'requested'
  issuedAt: time ?
  expiresAt: time ?
  lastCheckIn: time ?
  photoFirst: image <=5000000 ?
  photoSecond: image <=5000000 ?
  reasonFirst: text 8..500 ?
  reasonSecond: text 8..500 ?
  overrideByFirst: principal ?
  overrideBySecond: principal ?
  issuedBy: principal ?
  signal: signals ?
  immutable turbine, first, second, requestedAt
  read <- .first = viewer or .second = viewer or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager']
  insert <- .first = viewer and exists people[principal = viewer, role = 'technician']
  update <- .first = viewer or .second = viewer or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager']
  online only

table signals:
  turbineLabel: text 1..80
  lastAt: time
  endsAt: time
  silent: bool default false
  immutable turbineLabel, endsAt
  expire at .endsAt
  read <- exists people[principal = viewer, role = 'technician'] or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager']
  insert <- exists people[principal = viewer, role = 'siteLead']
  update <- exists people[principal = viewer, role = 'technician']
  online only

table accessDates:
  landowner: principal
  land: text 1..80
  accessAt: time
  immutable landowner, land, accessAt
  read <- .landowner = viewer or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager']
  insert <- exists people[principal = viewer, role = 'siteLead']
  online only

mutation provision(principal: principal, name: text 1..80, role: enum('technician', 'siteLead', 'siteManager', 'landowner')):
  require viewer = 'service:provisioner' else FORBIDDEN
  return insert people { principal, name, role }

query me():
  return people[principal = viewer]
query directory(c: cursor ?):
  require exists people[principal = viewer, role = 'technician'] or exists people[principal = viewer, role = 'siteLead'] or exists people[principal = viewer, role = 'siteManager'] else FORBIDDEN
  return people first 100 by .id after c
query turbineList(c: cursor ?):
  return turbines first 100 by .id after c
query trainingList(c: cursor ?):
  return training first 100 by .id after c
query trainingRecord(technician: principal):
  return training[technician]
query permitList(c: cursor ?):
  return permits last 100 by .requestedAt after c { id, turbine, first, second, state, issuedAt, expiresAt, lastCheckIn, requestedAt, photoFirst, photoSecond, reasonFirst, reasonSecond, overrideByFirst, overrideBySecond, issuedBy, active: .expiresAt != null and .expiresAt > now }
query permitRecord(permit: permits):
  return permits[permit]
query radioAlerts(c: cursor ?):
  return signals where .lastAt <= now - 1h and .endsAt > now first 100 by .id after c { id, turbineLabel, lastAt, endsAt }
query landAccess(c: cursor ?):
  return accessDates last 100 by .accessAt after c

mutation setTraining(technician: principal, validUntil: time):
  require exists people[principal = viewer, role = 'siteManager'] else FORBIDDEN
  require exists people[principal = technician, role = 'technician'] else NOT_TECHNICIAN
  require validUntil >= now - 365d and validUntil <= now + 730d else BAD_DATE
  upsert training[technician] { validUntil }

mutation addTurbine(label: text 1..80, land: text 1..80, landowner: principal):
  require exists people[principal = viewer, role = 'siteManager'] else FORBIDDEN
  require exists people[principal = landowner, role = 'landowner'] else NOT_LANDOWNER
  return insert turbines { label, land, landowner }

mutation requestPermit(turbine: turbines, partner: principal):
  require exists people[principal = viewer, role = 'technician'] else FORBIDDEN
  require partner != viewer else NEED_PAIR
  require exists people[principal = partner, role = 'technician'] else NOT_TECHNICIAN
  t = turbines[turbine] ! else NOT_FOUND
  return insert permits { turbine: t.id, first: viewer, second: partner, requestedAt: now }

mutation placeInspection(permit: permits, photo: image <=5000000):
  require exists people[principal = viewer, role = 'technician'] else FORBIDDEN
  p = permits[permit] ! else NOT_FOUND
  require p.state = 'requested' else ALREADY_ISSUED
  require p.first = viewer or p.second = viewer else FORBIDDEN
  if p.first = viewer:
    require p.photoFirst = null else PHOTO_ALREADY_PLACED
    update permits[permit] { photoFirst: photo }
  else:
    require p.photoSecond = null else PHOTO_ALREADY_PLACED
    update permits[permit] { photoSecond: photo }

mutation overrideTraining(permit: permits, technician: principal, reason: text 8..500):
  require exists people[principal = viewer, role = 'siteManager'] else FORBIDDEN
  p = permits[permit] ! else NOT_FOUND
  require p.state = 'requested' else ALREADY_ISSUED
  require p.first = technician or p.second = technician else NOT_IN_PAIR
  tr = training[technician] ! else TRAINING_MISSING
  require tr.validUntil <= now else TRAINING_CURRENT
  if p.first = technician:
    update permits[permit] { reasonFirst: reason, overrideByFirst: viewer }
  else:
    update permits[permit] { reasonSecond: reason, overrideBySecond: viewer }

mutation issuePermit(permit: permits):
  require exists people[principal = viewer, role = 'siteLead'] else FORBIDDEN
  p = permits[permit] ! else NOT_FOUND
  require p.state = 'requested' else ALREADY_ISSUED
  require p.photoFirst != null and p.photoSecond != null else PHOTOS_REQUIRED
  a = training[p.first] ! else TRAINING_MISSING
  b = training[p.second] ! else TRAINING_MISSING
  require a.validUntil > now or p.reasonFirst != null else LAPSED_TRAINING
  require b.validUntil > now or p.reasonSecond != null else LAPSED_TRAINING
  t = turbines[p.turbine] ! else NOT_FOUND
  s = insert signals { turbineLabel: t.label, lastAt: now, endsAt: now + 8h }
  update permits[permit] { state: 'active', issuedAt: now, expiresAt: now + 8h, lastCheckIn: now, issuedBy: viewer, signal: s.id }
  insert accessDates { landowner: t.landowner, land: t.land, accessAt: now }

mutation checkIn(permit: permits):
  require exists people[principal = viewer, role = 'technician'] else FORBIDDEN
  p = permits[permit] ! else NOT_FOUND
  require p.first = viewer or p.second = viewer else FORBIDDEN
  require p.state = 'active' and p.expiresAt != null and p.expiresAt > now else PERMIT_LAPSED
  update permits[permit] { lastCheckIn: now }
  if p.signal != null:
    update signals[p.signal] { lastAt: now, silent: false }

job safetySweep():
  for p in permits:
    if p.state = 'active' and p.expiresAt != null and p.expiresAt <= now:
      update permits[p.id] { state: 'lapsed' }
  for s in signals:
    if s.silent = false and s.lastAt <= now - 1h:
      update signals[s.id] { silent: true }
schedule safety every 1m: safetySweep
