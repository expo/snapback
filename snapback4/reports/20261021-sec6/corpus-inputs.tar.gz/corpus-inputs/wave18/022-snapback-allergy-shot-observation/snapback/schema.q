use identity password

table roles:
  principal: principal
  role: enum('patient', 'nurse', 'frontdesk', 'allergist')
  unique principal
  immutable principal
  read <- .principal = viewer or viewer = 'service:operator'
  insert <- viewer = 'service:operator' or (.principal = viewer and .role = 'patient')
  update <- viewer = 'service:operator'
  online only

table patients:
  owner: principal
  name: text 2..80
  unique owner
  immutable owner, name
  read <- .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator' or .owner = viewer
  online only

table courses:
  patient: patients
  owner: principal
  lastDoseAt: time ?
  lastDoseUnits: int 0..1000
  unique patient
  immutable patient, owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist'] or viewer = 'service:operator'
  insert <- viewer = 'service:operator' or .owner = viewer
  update <- exists roles[principal = viewer, role = 'nurse']
  online only

table schedules:
  patient: patients
  owner: principal
  doseUnits: int 1..1000
  intervalDays: int 1..28
  reason: text 5..500
  changedBy: principal
  changedAt: time
  basedOnLastDoseAt: time ?
  unique patient
  immutable patient, owner
  read <- .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist']
  insert <- exists roles[principal = viewer, role = 'allergist']
  update <- exists roles[principal = viewer, role = 'allergist']
  online only

table scheduleAudit:
  patient: patients
  owner: principal
  doseUnits: int 1..1000
  intervalDays: int 1..28
  reason: text 5..500
  changedBy: principal
  changedAt: time
  read <- .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist']
  insert <- exists roles[principal = viewer, role = 'allergist']
  online only

table doses:
  patient: patients
  owner: principal
  doseUnits: int 1..1000
  givenAt: time
  givenBy: principal
  reaction: enum('none', 'local', 'large', 'systemic')
  reactionNote: text <=500
  photo: image <=5000000 ?
  immutable patient, owner, doseUnits, givenAt, givenBy
  read <- .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist']
  insert <- exists roles[principal = viewer, role = 'nurse']
  update <- exists roles[principal = viewer, role = 'nurse']
  online only

table observations:
  patient: patients
  owner: principal
  patientName: text 2..80
  dose: doses
  startedAt: time
  mayLeaveAt: time
  immutable patient, owner, patientName, dose, startedAt, mayLeaveAt
  read <- .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'frontdesk'] or exists roles[principal = viewer, role = 'allergist']
  insert <- exists roles[principal = viewer, role = 'nurse']
  online only

mutation provision(principal: principal, role: enum('patient', 'nurse', 'frontdesk', 'allergist'), name: text 2..80):
  require viewer = 'service:operator' else NOT_OPERATOR
  require not exists roles[principal] else ALREADY_PROVISIONED
  insert roles { principal, role }
  if role = 'patient':
    p = insert patients { owner: principal, name }
    insert courses { patient: p.id, owner: principal, lastDoseAt: null, lastDoseUnits: 0 }

query myRole():
  return roles[principal = viewer]

query patientList(c: cursor ?):
  require exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist'] else CLINICAL_ONLY
  return patients first 100 by .id after c

query myPatient():
  require exists roles[principal = viewer, role = 'patient'] else PATIENT_ONLY
  return patients[owner = viewer]

query clinical(patient: patients):
  p = patients[patient] ! else PRIVATE_PATIENT
  return { patient: p, course: courses[patient], schedule: schedules[patient], now: now }

query history(patient: patients, c: cursor ?):
  require exists patients[patient] else PRIVATE_PATIENT
  return doses where .patient = patient last 100 by .givenAt after c

query audit(patient: patients, c: cursor ?):
  require exists patients[patient] else PRIVATE_PATIENT
  return scheduleAudit where .patient = patient last 100 by .changedAt after c

query observationBoard(c: cursor ?):
  require exists roles[principal = viewer, role = 'frontdesk'] or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist'] else STAFF_ONLY
  return observations where .mayLeaveAt > now first 100 by .mayLeaveAt after c { id, patientName, startedAt, mayLeaveAt }

mutation changeSchedule(patient: patients, doseUnits: int 1..1000, intervalDays: int 1..28, reason: text 5..500):
  require exists roles[principal = viewer, role = 'allergist'] else ALLERGIST_ONLY
  p = patients[patient] ! else PRIVATE_PATIENT
  c = courses[patient] ! else NOT_FOUND
  if c.lastDoseAt != null and now > c.lastDoseAt + 14d:
    require doseUnits < c.lastDoseUnits else REDUCED_DOSE_REQUIRED
  upsert schedules[patient] { patient, owner: p.owner, doseUnits, intervalDays, reason, changedBy: viewer, changedAt: now, basedOnLastDoseAt: c.lastDoseAt }
  return insert scheduleAudit { patient, owner: p.owner, doseUnits, intervalDays, reason, changedBy: viewer, changedAt: now }

mutation recordDose(patient: patients):
  require exists roles[principal = viewer, role = 'nurse'] else NURSE_ONLY
  p = patients[patient] ! else PRIVATE_PATIENT
  c = courses[patient] ! else NOT_FOUND
  s = schedules[patient] ! else SCHEDULE_REQUIRED
  require c.lastDoseAt = null or now >= c.lastDoseAt + 30m else STILL_OBSERVING
  if c.lastDoseAt != null and now > c.lastDoseAt + 14d:
    require s.basedOnLastDoseAt = c.lastDoseAt and s.doseUnits < c.lastDoseUnits and s.changedAt > c.lastDoseAt + 14d else ALLERGIST_HOLD 'More than 14 days: allergist must set a reduced dose.'
  d = insert doses { patient, owner: p.owner, doseUnits: s.doseUnits, givenAt: now, givenBy: viewer, reaction: 'none', reactionNote: '', photo: null }
  insert observations { patient, owner: p.owner, patientName: p.name, dose: d.id, startedAt: now, mayLeaveAt: now + 30m }
  update courses[patient] { lastDoseAt: now, lastDoseUnits: s.doseUnits }
  return d

mutation recordReaction(dose: doses, reaction: enum('none', 'local', 'large', 'systemic'), reactionNote: text <=500, photo: image <=5000000 ?):
  require exists roles[principal = viewer, role = 'nurse'] else NURSE_ONLY
  d = doses[dose] ! else PRIVATE_DOSE
  require reaction != 'large' or photo != null else PHOTO_REQUIRED 'Attach a photo for a large reaction.'
  require reaction = 'none' or reactionNote != '' else NOTE_REQUIRED
  update doses[dose] { reaction, reactionNote, photo }

mutation registerPatient(name: text 2..80):
  require not exists roles[principal = viewer] else ALREADY_PROVISIONED
  insert roles { principal: viewer, role: 'patient' }
  p = insert patients { owner: viewer, name }
  insert courses { patient: p.id, owner: viewer, lastDoseAt: null, lastDoseUnits: 0 }
  return p

invariant patients.read only .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist'] or viewer = 'service:operator'

invariant courses.read only .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist'] or viewer = 'service:operator'

invariant schedules.read only .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist']

invariant scheduleAudit.read only .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist']

invariant doses.read only .owner = viewer or exists roles[principal = viewer, role = 'nurse'] or exists roles[principal = viewer, role = 'allergist']

invariant schedules.update only exists roles[principal = viewer, role = 'allergist']
invariant scheduleAudit.insert only exists roles[principal = viewer, role = 'allergist']
