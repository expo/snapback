-- Fencing Bout Pools.
-- Roles: fencer, armorer, referee, medic, committee, chair (bout committee chair).
-- Real password auth; role roster provisioned by the service:operator operator seat
-- (minted with `snapback4 token --service ops`) or by the chair.
use identity
use personas alice, bob, carol, dave, erin, frank, grace, heidi

table roles:
  principal: principal
  role: enum('fencer', 'armorer', 'referee', 'medic', 'committee', 'chair')
  unique principal
  immutable principal
  read <- .principal = viewer or exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  insert <- viewer = 'service:operator' or exists roles[viewer, role = 'chair']
  update <- viewer = 'service:operator' or exists roles[viewer, role = 'chair']
  delete <- viewer = 'service:operator' or exists roles[viewer, role = 'chair']
  cap 100
  online only

-- A pool (poule): fencers registered, bouts fenced, sheet public on the hall screen.
table pools:
  name: text 3..80
  startsAt: time
  status: enum('scheduled', 'running', 'finished') default 'scheduled'
  immutable startsAt
  public 'pool sheets are public on the hall screen'
  insert <- exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  update <- exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  delete <- exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  cap 500
  online only

-- One fencer's registration in a pool. Status flips to withdrawn only by the job.
table entries:
  pool: pools on delete cascade
  fencer: principal
  status: enum('entered', 'withdrawn') default 'entered'
  unique pool, fencer else ALREADY_ENTERED
  immutable pool, fencer
  public 'pool sheets are public on the hall screen'
  insert <- exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  update <- deny
  delete <- exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  cap 64 by pool
  online only

-- Armorer equipment check for one entry. Failures carry a photo.
table checks:
  entry: entries on delete cascade
  armorer: principal
  passed: bool
  detail: text <=500 ?
  photo: image <=5000000 ?
  at: time default now
  unique entry else ALREADY_CHECKED
  immutable entry
  public 'equipment checks are part of the public pool sheet'
  insert <- exists roles[viewer, role = 'armorer']
  update <- exists roles[viewer, role = 'armorer']
  delete <- deny
  cap 1 by entry
  online only

-- One bout between two entries of a pool. Fencer principals are copied onto
-- the row (checked against the entries) so each fencer's page stays complete.
table bouts:
  pool: pools on delete cascade
  entryA: entries
  entryB: entries
  fencerA: principal
  fencerB: principal
  referee: principal
  scoreA: int 0..15
  scoreB: int 0..15
  status: enum('recorded', 'overturned') default 'recorded'
  at: time default now
  unique pool, entryA, entryB else ALREADY_FENCED
  immutable pool, entryA, entryB, fencerA, fencerB
  public 'bout scores are part of the public pool sheet'
  insert <- exists roles[viewer, role = 'referee'] and .fencerA = .entryA.fencer and .fencerB = .entryB.fencer
  update <- exists roles[viewer, role = 'referee'] or exists roles[viewer, role = 'chair']
  delete <- deny
  cap 144 by pool
  online only

-- Appeal of a referee's call by one of the bout's fencers; decided by the chair.
table appeals:
  bout: bouts on delete cascade
  pool: pools on delete cascade
  appellant: principal
  reason: text 5..500
  decision: enum('pending', 'upheld', 'overturned') default 'pending'
  decisionReason: text <=500 ?
  decidedBy: principal ?
  unique bout else ALREADY_APPEALED
  immutable bout, pool, appellant, reason
  public 'appeals and their reasons are recorded on the public sheet'
  insert <- .appellant = viewer
  update <- exists roles[viewer, role = 'chair']
  delete <- deny
  cap 1 by bout
  cap 144 by pool
  online only

-- Medical notes: visible only to the medic and the bout committee (incl. chair).
table medicalNotes:
  fencer: principal
  author: principal
  note: text 1..2000
  at: time default now
  immutable fencer, author
  read <- exists roles[viewer, role = 'medic'] or exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
  insert <- .author = viewer and exists roles[viewer, role = 'medic']
  update <- .author = viewer and exists roles[viewer, role = 'medic']
  delete <- deny
  cap 200 by fencer
  online only

invariant medicalNotes.read only exists roles[viewer, role = 'medic'] or exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
invariant medicalNotes.insert only exists roles[viewer, role = 'medic']
invariant medicalNotes.update only exists roles[viewer, role = 'medic']
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair']
invariant roles.insert only viewer = 'service:operator' or exists roles[viewer, role = 'chair']
invariant roles.update only viewer = 'service:operator' or exists roles[viewer, role = 'chair']
invariant bouts.insert only exists roles[viewer, role = 'referee']
invariant appeals.update only exists roles[viewer, role = 'chair']
invariant entries.update only false

query whoAmI():
  return viewer

query myRole():
  return roles[viewer]

query listRoles(c: cursor ?):
  require exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair'] else NOT_COMMITTEE
  return roles first 100 by .id after c

query listPools(c: cursor ?):
  return pools last 50 by .startsAt after c

query poolDetail(pool: pools):
  return pools[pool]

query entriesOf(pool: pools, c: cursor ?):
  return entries where .pool = pool first 100 by .id after c

query boutsOf(pool: pools, c: cursor ?):
  return bouts where .pool = pool first 100 by .id after c

query checksOf(entry: entries, c: cursor ?):
  return checks where .entry = entry first 20 by .id after c

query appealsOfPool(pool: pools, c: cursor ?):
  return appeals where .pool = pool first 50 by .id after c

query pendingAppeals(c: cursor ?):
  require exists roles[viewer, role = 'chair'] else NOT_CHAIR
  return appeals where .decision = 'pending' first 50 by .id after c

query myEntries(c: cursor ?):
  return entries where .fencer = viewer first 50 by .id after c

query myBouts(c: cursor ?):
  return bouts where .fencerA = viewer or .fencerB = viewer first 50 by .id after c

query medicalNotesFor(fencer: principal, c: cursor ?):
  require exists roles[viewer, role = 'medic'] or exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair'] else NOT_MEDIC
  return medicalNotes where .fencer = fencer first 50 by .at after c

mutation provision(who: principal, role: enum('fencer', 'armorer', 'referee', 'medic', 'committee', 'chair')):
  require viewer = 'service:operator' or exists roles[viewer, role = 'chair'] else NOT_CHAIR
  return upsert roles[who] { principal: who, role }

mutation createPool(name: text 3..80, startsAt: time):
  require exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair'] else NOT_COMMITTEE
  require startsAt > now else BAD_START 'Pools start in the future.'
  return insert pools { name, startsAt }

mutation setPoolStatus(pool: pools, status: enum('scheduled', 'running', 'finished')):
  require exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair'] else NOT_COMMITTEE
  p = pools[pool] ! else NOT_FOUND
  update pools[pool] { status }
  return null

mutation registerEntry(pool: pools, fencer: principal):
  require exists roles[viewer, role = 'committee'] or exists roles[viewer, role = 'chair'] else NOT_COMMITTEE
  p = pools[pool] ! else NOT_FOUND
  require p.startsAt > now and p.status = 'scheduled' else STARTED 'This pool is already running.'
  require exists roles[fencer, role = 'fencer'] else NOT_FENCER 'Only rostered fencers may be registered.'
  return insert entries { pool, fencer }

mutation recordCheck(entry: entries, passed: bool, detail: text <=500 ?, photo: image <=5000000 ?):
  require exists roles[viewer, role = 'armorer'] else NOT_ARMORER
  e = entries[entry] ! else NOT_FOUND
  p = pools[e.pool] ! else NOT_FOUND
  require now <= p.startsAt - 30m else CHECKIN_CLOSED 'Check-in closes 30 minutes before the pool starts.'
  require passed or photo != null else PHOTO_REQUIRED 'A failed check needs a photo.'
  return upsert checks[entry] { entry, armorer: viewer, passed, detail, at: now, photo }

mutation recordBout(pool: pools, entryA: entries, entryB: entries, scoreA: int 0..15, scoreB: int 0..15):
  require exists roles[viewer, role = 'referee'] else NOT_REFEREE
  p = pools[pool] ! else NOT_FOUND
  ea = entries[entryA] ! else NOT_FOUND
  eb = entries[entryB] ! else NOT_FOUND
  require entryA != entryB else SAME_FENCER
  require ea.pool = pool and eb.pool = pool else WRONG_POOL
  require ea.status = 'entered' and eb.status = 'entered' else WITHDRAWN 'A withdrawn fencer cannot fence.'
  return insert bouts { pool, entryA, entryB, fencerA: ea.fencer, fencerB: eb.fencer, referee: viewer, scoreA, scoreB }

mutation correctBout(bout: bouts, scoreA: int 0..15, scoreB: int 0..15):
  require exists roles[viewer, role = 'referee'] else NOT_REFEREE
  b = bouts[bout] ! else NOT_FOUND
  require b.status = 'recorded' else ALREADY_DECIDED 'Overturned bouts change only by appeal.'
  update bouts[bout] { scoreA, scoreB }
  return null

mutation fileAppeal(bout: bouts, reason: text 5..500):
  b = bouts[bout] ! else NOT_FOUND
  require b.fencerA = viewer or b.fencerB = viewer else NOT_FENCER 'Only the fencers of this bout may appeal.'
  return insert appeals { bout, pool: b.pool, appellant: viewer, reason }

mutation decideAppeal(appeal: appeals, overturn: bool, decisionReason: text 5..500, scoreA: int 0..15 ?, scoreB: int 0..15 ?):
  require exists roles[viewer, role = 'chair'] else NOT_CHAIR
  a = appeals[appeal] ! else NOT_FOUND
  require a.decision = 'pending' else ALREADY_DECIDED
  require not overturn or (scoreA != null and scoreB != null) else SCORES_REQUIRED 'Overturning needs the corrected score.'
  if overturn:
    update bouts[a.bout] { status: 'overturned', scoreA: scoreA ?? 0, scoreB: scoreB ?? 0 }
    update appeals[appeal] { decision: 'overturned', decisionReason, decidedBy: viewer }
  else:
    update appeals[appeal] { decision: 'upheld', decisionReason, decidedBy: viewer }
  return null

mutation writeMedicalNote(fencer: principal, note: text 1..2000):
  require exists roles[viewer, role = 'medic'] else NOT_MEDIC
  return insert medicalNotes { fencer, author: viewer, note, at: now }

-- A fencer with no passed equipment check 30 minutes before their pool starts
-- is withdrawn automatically. The mutation-level CHECKIN_CLOSED guard closes
-- the same deadline exactly; this sweep flips the status.
job withdrawUnchecked(periodStart: time, periodEnd: time):
  for e in entries by .id:
    p = pools[e.pool]
    if p != null and e.status = 'entered' and p.startsAt - 30m <= now:
      c = checks[e.id]
      if c = null or not c.passed:
        update entries[e.id] { status: 'withdrawn' }

schedule withdrawSweep every 1m: withdrawUnchecked
