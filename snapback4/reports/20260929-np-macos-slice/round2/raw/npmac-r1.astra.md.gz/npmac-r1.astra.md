Reviewed the requested diff read-only. Four findings should be fixed before landing.

1. **High — Embedded bytes are reported as executed bytes.**  
   [WitnessContainer.swift:25](/home/ccheever/sb4-intent/review-npmac-r1-astra/snapback4/packages/snapback4-expo/ios/WitnessContainer.swift:25)

   The observation hashes `Bundle.main/main.jsbundle`, without checking React Native’s selected bundle. An accepted native customization can load another local bundle while repack replaces `main.jsbundle`. The old JS can complete smoke, and startup binding still attributes execution to the new bundle. Excluding `expo-updates` does not exclude custom bundle selection.

   The calibration app records `SourceCode.scriptURL` and `__DEV__`, but the product validator does not enforce them.

   **Smallest fix:** observe the actual selected bundle URL, require it to resolve to the verified installed bundle, and hash that file. Reject unknown/remote selection and `__DEV__ === true`.

2. **Medium — Stale residency facts can excuse device-query loading.**  
   [smoke.ts:129](/home/ccheever/sb4-intent/review-npmac-r1-astra/snapback4/packages/snapback4-expo/src/smoke.ts:129)

   Facts originate from the CLI compiler, which is sound, but the helper compares only query names against the kept backend. It never compares `backend.schema.operations[name].runs` or `held`. The driver computes facts separately from the subsequent backend compilation, permitting source changes between those reads.

   I reproduced a false pass in a disposable copy: the kept `page` query says `device`, launch facts say `server`, and its loading result becomes expected offline unavailability.

   **Smallest fix:** require every supplied residency/held fact to match the kept backend before querying. Bind the driver’s facts to the backend generation or compiled digest actually served.

3. **High — Native inputs outside the inventoried directories can bypass repack refusal.**  
   [prepare.mjs:30](/home/ccheever/sb4-intent/review-npmac-r1-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:30)

   Consider an existing Xcode project referencing `../SharedNative/Foo.swift`. Changing that file leaves `ios/`, dependencies, config and lock unchanged. The general source inventory records the edit, but is not compared with the base for native compatibility. Expo’s directory-based fingerprint does not follow that Xcode reference; I reproduced an unchanged fingerprint with pinned `0.20.13`.

   Repack therefore accepts a native-source change while retaining the old executable.

   **Smallest fix:** for this bounded adapter, refuse native source/resource/build-input references outside the covered roots. Alternatively, resolve and include those inputs in the compatibility key.

4. **Medium — Interrupted preparation can leave compiler descendants running.**  
   [preparation.rs:28](/home/ccheever/sb4-intent/review-npmac-r1-astra/snapback4/crates/snapback4/src/verbs/witness/preparation.rs:28)

   Cleanup sends one SIGTERM to the process group, then waits only for the Node parent. If Node exits while a descendant ignores SIGTERM, cleanup returns and releases the project lease. That descendant can continue writing the snapshot or DerivedData while another run starts.

   I reproduced this using the copied Rust cleanup functions and a test-owned SIGTERM-resistant child.

   **Smallest fix:** retain ownership and the lease through bounded group cleanup; escalate surviving owned descendants to SIGKILL, rather than escalating only the parent.

What is sound: proof kinds and artifact prefixes distinguish repack from fresh builds; failed builds cannot advance to installation; base tampering, native-byte changes, metadata changes and asset mismatches are checked. Simulator operations use resolved UDIDs, busy ports are refused, and replacement app PIDs are preserved. The recorded death control correctly fails the segment.

All **23 copied JavaScript tests pass**. However, deleting both preparation HBC-version comparison guards still passes those tests—a concrete surviving mutation. Add a preparation-level wrong-version control. I also verified all **497 round-1 evidence entries** and reproduced the reported **46.109 s median / 56.639 s p95**. No iOS execution was performed here; the checkout is unchanged.

**Verdict: NOT READY.**