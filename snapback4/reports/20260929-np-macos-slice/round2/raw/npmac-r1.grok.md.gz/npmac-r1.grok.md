I'll review the `sb4-np/np-macos` diff read-only against the design and the recorded macOS evidence, starting with the review criteria and the exact range you named.The range is the native-proof slice plus its evidence. I'll read the design and the witness, smoke, and repack code next, and treat the reports as recorded evidence rather than as the implementation.Auto-compacting conversation (84% full)...
Conversation compacted.
The review still needs exact line citations before the verdict. I'll re-read the proof, classification, fingerprint, and process-safety paths, then write the review.**NOT READY.** Two holes let a passing receipt describe an embedded device answer that did not happen. The build, repack, and process machinery around them is sound and should be kept.

## 1. Honesty of the proof

**High.** The startup binding hashes the embedded file, not the script that ran. `snapback4/packages/snapback4-expo/ios/WitnessContainer.swift:16-26`, `snapback4/packages/snapback4-expo/src/witness-core.ts:27-28`, checked at `snapback4/crates/snapback4/src/verbs/witness/preparation.rs:94-97`.

`observation()` SHA-256s `Bundle.main`'s `main.jsbundle` and the Mach-O executable. `release` is `#if DEBUG` in the native binary. The JS side only adds `hermes: !!HermesInternal` from whatever runtime is executing. Nothing reads `SourceCode.scriptURL`, `__DEV__`, `EXDevLauncher.manifestString`, `Constants.manifest2`, or `ExpoUpdates`. `prepare.mjs:68` refuses linked `expo-updates` and keeps `expo-dev-client`. `preparation.rs:71` records that install preserves the existing data container and keychain. `index.ts:42` attaches smoke as soon as the client exists.

Accepted LLP 3000.030 §5 requires those checks on every cold launch, because this same lane already saw a Release dev-client open the wrong URL. They exist only in the calibration app: `snapback4/reports/20260929-np-macos-slice/subject/src/NPProbe.tsx:35-36`, and `subject/src/np-gate.ts:8-15` delays `onClient` until `releaseSmoke()`. Drop that probe and the product path still prints "Own Release smoke passed."

Failing scenario: the simulator already ran this bundle id under `expo start`, so the launcher URL is still in the preserved container. `simctl launch <udid> <bundle>` starts Release with no URL argument. The dev client executes the restored bundle. If that bundle is this project (it still calls the witness helper), startup hashes the embedded file, `release` and `HermesInternal` are both true, and smoke can pass. `javascriptSha256` in the proof is a bundle that was not executed. Round 1's file-URL observation is the subject probe on a fresh simulator, not this helper.

Smallest fix: in `witness-core.ts`, next to the Hermes field, fail `E_WITNESS_PROOF` unless `__DEV__` is false, `scriptURL` is `file:` and contains `.app/main.jsbundle`, and the launcher and updates manifests are empty. Keep the native file hashes.

**High.** A device-answerable query passes offline when the client reports `E_OFFLINE`. `snapback4/crates/snapback4/src/verbs/witness/smoke.rs:36-41` and `snapback4/packages/snapback4-expo/src/smoke.ts:155-156`. Locked in by `snapback4/packages/snapback4/test/native-smoke.test.mjs:57-59`.

For `runs: device`, any non-empty denial code and message is success. `E_OFFLINE` is not treated like `loading`. The real client produces that denial: when the local engine does not publish data, offline recovery returns `{ denied: env.offline() }` for a one-shot read (`snapback4/packages/snapback4/src/local-query.ts:141-142`). Prime and restart never sample device queries (`smoke.ts:136`), so this is the only device check.

`held:` makes it worse. After residency is computed, `snapback4/crates/snapback4-lang/src/bind/mod.rs:146-149` forces `runs: "device"` even if a server site remains. A `held` query that also reads `connected()` is classified device-answerable, the local engine does not complete it, recovery returns `E_OFFLINE` ("requires the server"), and the offline segment passes with no count.

Failing scenario: every optional-argument query is `runs: device`. Offline, each returns `{ denied: { code: "E_OFFLINE", message: "requires the server" } }`. The receipt says `device-answerable` and `pass: true`. The unit test expects that.

Smallest fix: for `runs: device`, accept `ready`, or a refusal whose code is not `E_OFFLINE` or `E_OFFLINE_*`. Treat those codes like `loading`. Change the test that currently requires the pass.

**High.** Compiler facts mark native reads server-only, so a device that did not answer is "expected." `snapback4/crates/snapback4-lang/src/bind/residency.rs:78-80` and `:120-122`.

Any `program.native` query gets a synthetic `SiteClass::Server` site ("held on a device with the module"), and any server site sets `runs: "server"`. The client does the opposite: `runsOnServer` is `!nativeReady` for a native program (`snapback4/packages/snapback4/src/local-reads.ts:8-9`). The language guide says a cold offline start answers native reads with the module the device kept (`snapback4/crates/snapback4-lang/src/guide/native.rs:56-57`). Smoke classifies from the compiler bit (`smoke.ts:135`) and, offline, accepts `loading` or `E_OFFLINE` as `online-only: unavailable offline (expected)` (`smoke.ts:149-152`). Returning data for that query fails the segment.

Failing scenario: an optional-argument `query … : native` whose wasm module is absent. Offline the client returns `loading` or `E_OFFLINE`. The receipt records expected unavailability and the segment passes. The same query with the module resident and a real local answer fails smoke. The same one-bit rule excuses a mixed query: one server site, including `connected()`, and the held reads in that query are never required offline.

Smallest fix: do not push that synthetic server site for queries, or set `runs: "device"` for a native query and require a ready local answer when the device reports the module. A missing module is then a failure, which matches the guide.

What is sound on this axis. `proofKind` comes from preparation mode (`prepare.mjs:159`), and the success line cannot call a repack an own build (`witness.rs:460-462`). Legacy `--bundle-id` stays `installed-application`. The driver recomputes classification from host compiler facts (`smoke.rs:23-35`); the app echoing a different `queryFacts` or swapping `online-only` with `device-answerable` fails. `loading` on a device query fails. A server query that returns data offline fails. Server queries must be `ready` in prime and restart. `save_smoke` (`smoke.rs:120-138`) flips a segment that is still marked passed when revalidation fails, and any `:failed` step fails `receipts()` (`protocol.rs:63`). The success line is printed only after `execute()` returns `Ok`. Facts are not taken from the app. A replaced helper can still invent `state: "ready"`; LLP 3000.030 §10 says this is not adversarial attestation. That is not a hole beyond the two above.

## 2. Build and repack

**Medium.** A native change under `ios/Pods/**` misses the compatibility gate. `snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:29` and `:84-85`.

`nativeOmit` skips `Pods/`. `sourceSkips: 0` does not turn off `@expo/fingerprint` path ignores; that package is not in this worktree, and 0.20.13's default ignores still include `**/ios/Pods/**`. `node_modules` is hashed in full, and `Podfile.lock` lives under `ios/` outside `Pods/`, so a lockfile or dependency edit is caught. A hand-edit inside `Pods/` changes neither inventory nor fingerprint hash. `--repack` proceeds. It does not run the edited sources: Mach-O JSON must still equal the sealed base (`prepare.mjs:139`). The false claim is "native inputs unchanged," not "this binary contains the new object code."

Failing scenario: patch a file under `ios/Pods/` that the next `--build` would compile, leave `Podfile.lock` and `package-lock.json` alone, run `--repack`. The command passes, records the old fingerprint, and installs the old Mach-O.

Smallest fix: hash `ios/Pods` (or at least `Pods` manifest plus `hermesc` and a content digest of pod sources) in the input compared at line 84, and refuse on any difference. Do not rely on the fingerprint default ignore.

The rest of this path holds. A base whose bytes no longer match `build.json` is refused before install (`prepare.mjs:83`). HBC magic `c61fbc03c103191f` and the version at offset 8 must match the compiler's `HBC bytecode version` (`payload.mjs:35-38`, `prepare.mjs:136-137`). Repack compiler JSON must match the base. CocoaPods `hermesc` and the JS-export `hermesc` must be the same bytes. Changes outside `main.jsbundle` and `assets/` fail (`prepare.mjs:142-144`). Assets must equal the fresh `repack-work/bundles/assets` graph exactly (`payload.mjs:63-67`), not merely share a directory prefix. Info.plist, Expo.plist, EXConstants, and public config are compared. Installed inventory allows only the measured `0755` to `0644` mode change on `Frameworks/*.framework/*`, and only when the bytes match (`payload.mjs:50-57`). `proof.json` is sealed `0444` with `create_new`, and its `sha256` is of the file before that field is added. `verify` rechecks the app inventory before install, on each launch, and at collection. Round 1's five repacks are consistent with that: same Mach-O list, different JS and probe PNGs, HBC 98. I did not recompute those hashes here. Differing `hermesc` flags (export versus Xcode `-O`) are recorded; cold execution is the actual check, and these runs did execute.

## 3. Process safety

No High or Medium here.

**Low.** Simulator signing can still consult the login keychain. `prepare.mjs:111` passes `CODE_SIGN_IDENTITY=-` and does not pass `CODE_SIGNING_ALLOWED=NO` or `CODE_SIGNING_REQUIRED=NO`. Round 1 reports no keychain change. Smallest fix: pass both `NO` settings on the simulator `xcodebuild` invocation.

**Low.** With no `--udid`, the sole booted simulator is taken. `snapback4/crates/snapback4/src/verbs/witness/protocol.rs:26-27`. That may be another person's session. Install, launch, terminate, and video then run there. Two booted simulators are refused, and the literal target `booted` is not a UDID (`protocol.rs:23-24`). The guide's example always passes `$UDID`. Smallest fix: require `--udid` for `--build` and `--repack`.

What is sound. Every `simctl` call uses the resolved UDID. The lease is `simctl getenv <udid> HOME` plus `.snapback4-witness-owner.lock` (`witness.rs:384-386`), which on current CoreSimulator is that device's data directory, plus a separate project lock (`preparation.rs:39`). A held lease is left untouched. The port bind is `127.0.0.1` only and does not kill a foreign listener (`protocol.rs:41-42`). The preparation child is a process-group leader; on failure the parent signals the group (`preparation.rs:14`, `:28-31`). Terminate runs only when `launchctl` still shows the owned PID; a replacement is left running (`witness.rs:135-147`). The `UIKitApplication:{bundle}[` prefix does not match a longer bundle id. There is no `xcode-select` write and no global DerivedData: private `CP_HOME_DIR`, `CP_CACHE_DIR`, npm cache, `TMPDIR`, and `-derivedDataPath` / `-resultBundlePath` under the project. The env passed to tools is the small allow-list plus `EXPO_NO_DOTENV=1`. Launch env is only `SIMCTL_CHILD_SNAPBACK4_WITNESS`. The driver does not erase simulators or keychains. `Drop` stops capture, the owned app, and the backend.

## 4. What should stop landing, and what a test would miss

Do not land while findings 1 and 2 are as they are. Finding 3 is the same class of overclaim and should be fixed in the same change. Finding 4 should be fixed before `--repack` is described as "native inputs unchanged." The Low items need not block.

Mutations that survive the current tests:

- A device query that returns `{ denied: { code: "E_OFFLINE", message: "requires the server" } }` is a passing offline receipt. `native-smoke.test.mjs:57-59` requires that pass.
- An optional-argument native query that returns `loading` offline is recorded as expected server-only unavailability. No test uses a native program fact.
- A byte change under `ios/Pods/**` still repacks. `witness-preparation.test.mjs` covers inventory, the framework mode bit, HBC headers, and the asset graph. It does not mutate `Pods`.
- A Release process whose executed `scriptURL` is not `file:…/main.jsbundle` still binds. No product test asserts the script URL. The calibration probe would fail that app only, and it is not in `snapback4-expo`.

## Verdict

**NOT READY.** Fix the executed-script check, reject `E_OFFLINE` for device-answerable queries, and stop classifying native reads as server-only. Then the Pods input hash. The receipt rules, HBC and Mach-O checks, asset graph, leases, and UDID-scoped `simctl` use are fit to land with those fixes.
