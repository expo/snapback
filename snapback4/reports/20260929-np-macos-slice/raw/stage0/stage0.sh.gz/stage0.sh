#!/bin/zsh
# NP stage 0: cold and warm Release simulator build timings for a real builder app (cal25 Clique).
# Everything lives under ~/np-stage0; nothing global is changed.
set -u
R=~/np-stage0; cd $R
export DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer
export CP_HOME_DIR=$R/cp-home CP_CACHE_DIR=$R/cp-cache
export CI=1 EXPO_NO_TELEMETRY=1
log() { echo "$(date -u +%FT%TZ) $*" | tee -a $R/stage0.log; }
if [ ! -x $R/node/bin/node ]; then
  log "download node 24.18.0"
  curl -fsSL https://nodejs.org/dist/v24.18.0/node-v24.18.0-darwin-arm64.tar.gz -o $R/node.tgz && mkdir -p $R/node && tar -xzf $R/node.tgz -C $R/node --strip-components 1 || { log "node download failed"; exit 1; }
fi
export PATH=$R/node/bin:/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin
log "node $(node --version) npm $(npm --version) pod $(pod --version) xcode $(xcodebuild -version | head -1)"
UDID=$(xcrun simctl create np-stage0-iphone "iPhone 18 Pro" 2>/dev/null)
log "simulator $UDID"; xcrun simctl boot $UDID; xcrun simctl bootstatus $UDID -b > /dev/null
cd $R/clique
t0=$(date +%s); log "npm ci start"
npm ci --no-audit --no-fund > $R/npm-ci.log 2>&1; rc=$?; log "npm ci exit=$rc $(( $(date +%s) - t0 ))s"
[ $rc -eq 0 ] || exit 1
t0=$(date +%s); log "cold release build start"
npx expo run:ios --configuration Release --device $UDID --no-bundler > $R/build-cold.log 2>&1; rc=$?
log "cold release build exit=$rc $(( $(date +%s) - t0 ))s"
echo "// stage0 warm marker $(date +%s)" >> app/_layout.tsx
t0=$(date +%s); log "warm release build start"
npx expo run:ios --configuration Release --device $UDID --no-bundler > $R/build-warm.log 2>&1; rc=$?
log "warm release build exit=$rc $(( $(date +%s) - t0 ))s"
APP=$(ls -d ~/Library/Developer/Xcode/DerivedData/*/Build/Products/Release-iphonesimulator/*.app 2>/dev/null | grep -i clique | head -1)
log "app=$APP size=$(du -sh "$APP" 2>/dev/null | cut -f1)"
echo "// stage0 repack marker $(date +%s)" >> app/_layout.tsx
t0=$(date +%s); log "repack start"
npx --yes @expo/repack-app --platform ios --source-app "$APP" --output $R/repacked.app > $R/repack.log 2>&1; rc=$?
log "repack exit=$rc $(( $(date +%s) - t0 ))s"
xcrun simctl shutdown $UDID; xcrun simctl delete $UDID
log "done"
