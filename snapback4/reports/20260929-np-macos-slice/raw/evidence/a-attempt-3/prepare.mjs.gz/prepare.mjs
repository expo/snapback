// @ref LLP 3000.030#3 — private own-project preparation; never launch through Expo CLI.
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import { hash, fail, readJSON, seal, inventory, hbc, nativeFiles, differences } from './payload.mjs';

const [mode, projectArg, artifactsArg, udid, origin, receiptArg] = process.argv.slice(2);
const out = path.resolve(artifactsArg), project = fs.realpathSync(projectArg);
const started = Date.now(), deadline = started + 900_000, phases = [];
const cache = path.join(project, '.snapback4-witness'), snapshot = path.join(cache, 'snapshot');
const env = Object.fromEntries(['PATH', 'HOME', 'USER', 'LOGNAME', 'DEVELOPER_DIR', 'LANG'].filter(k => process.env[k]).map(k => [k, process.env[k]]));
Object.assign(env, { CI: '1', EXPO_NO_TELEMETRY: '1', EXPO_NO_DOTENV: '1', NODE_ENV: 'production',
  EXPO_PUBLIC_SNAPBACK_URL: origin, CP_HOME_DIR: path.join(cache, 'pods-home'), CP_CACHE_DIR: path.join(cache, 'pods-cache'),
  npm_config_cache: path.join(cache, 'npm-cache'), TMPDIR: path.join(cache, 'tmp') });
fs.mkdirSync(env.TMPDIR, { recursive: true });
function command(label, executable, args, cwd = snapshot) {
  const time = Date.now(), log = path.join(out, `${label}.log`), fd = fs.openSync(log, 'wx');
  const r = spawnSync(executable, args, { cwd, env, timeout: Math.max(1, deadline - time), maxBuffer: 64 * 1024 * 1024, encoding: 'utf8' });
  fs.writeSync(fd, (r.stdout ?? '') + (r.stderr ?? '')); fs.closeSync(fd);
  phases.push({ label, executable, args, cwd, startedAt: time, durationMs: Date.now() - time, status: r.status, signal: r.signal, log: path.basename(log), sha256: hash(fs.readFileSync(log)) });
  fs.writeFileSync(path.join(out, 'preparation-phases.json'), JSON.stringify(phases, null, 2));
  if (r.error || r.status !== 0) fail('E_WITNESS_BUILD', `${label} failed (${r.error?.message ?? r.status}); see ${log}; use --build in a fresh artifacts directory`);
  return r.stdout.trim();
}
const excluded = new Set(['.git', '.expo', '.snapback4', '.snapback4-witness', 'artifacts', 'evidence', 'dist', 'choreography', 'node_modules', 'ios']);
function sourceOmit(p) { return excluded.has(p.split('/')[0]) || p.split('/').some(n => n === 'provider-secrets.env' || n.startsWith('.env')); }
function nativeOmit(p) { return p === 'build' || p.startsWith('build/') || p === 'Pods' || p.startsWith('Pods/') || p.includes('/xcuserdata') || p === '.xcode.env.local'; }
function nativeInput(root) {
  const deps = inventory(path.join(root, 'node_modules'));
  const ios = fs.existsSync(path.join(root, 'ios')) ? inventory(path.join(root, 'ios'), nativeOmit) : null;
  const config = readJSON(path.join(root, 'app.json'));
  const manifest = readJSON(path.join(root, 'package.json'));
  const lock = hash(fs.readFileSync(path.join(root, 'package-lock.json')));
  return { config, manifest, lock, dependencies: deps, ios };
}
function sameInputs(a, b, code = 'E_WITNESS_NATIVE_COMPAT') {
  const changes = [];
  for (const key of ['config', 'manifest', 'lock', 'dependencies', 'ios']) if (JSON.stringify(a[key]) !== JSON.stringify(b[key])) {
    changes.push({ field: key, ...(a[key]?.files && b[key]?.files ? { changes: differences(a[key].files, b[key].files) } : { expected: a[key], actual: b[key] }) });
  }
  if (changes.length) { seal(path.join(out, 'input-differences.json'), changes); fail(code, `input differences in ${changes.map(x => x.field).join(', ')}; see input-differences.json; use witness ios --build ${project}`); }
}
function plist(file) { return JSON.parse(command(`plist-${phases.length}`, '/usr/bin/plutil', ['-convert', 'json', '-o', '-', file])); }
function appInfo(app) {
  const inv = inventory(app), info = plist(path.join(app, 'Info.plist')), js = hbc(path.join(app, 'main.jsbundle'));
  const native = nativeFiles(app, inv);
  if (!native.some(f => f.path === info.CFBundleExecutable)) fail('E_WITNESS_HERMES', 'application has no Mach-O executable');
  return { inventory: inv, native, javascript: js, info, path: app };
}
try {
  if (process.platform !== 'darwin' || process.arch !== 'arm64') fail('E_WITNESS_PLATFORM', 'preparation requires an Apple-silicon Mac');
  for (const file of ['app.config.js', 'app.config.ts', 'app.config.json', '.fingerprintignore', 'fingerprint.config.js', 'fingerprint.config.cjs']) {
    if (fs.existsSync(path.join(project, file))) fail('E_WITNESS_NATIVE_COMPAT', `${file} is outside the first static-config preparation adapter; use manual installed-app mode`);
  }
  const req = createRequire(path.join(project, 'package.json'));
  const version = name => req(`${name}/package.json`).version;
  if (version('expo') !== '57.0.22' || version('react-native') !== '0.86.3' || version('@expo/fingerprint') !== '0.20.13') fail('E_WITNESS_BUILD', 'this preparation adapter requires Expo 57.0.22, RN 0.86.3 and @expo/fingerprint 0.20.13; use installed-app mode');
  const source = inventory(project, sourceOmit), inputs = nativeInput(project);
  const fingerprintOptions = { platforms: ['ios'], silent: true, sourceSkips: 0 };
  // Use a clean child environment for config/plugin evaluation, not ambient secrets.
  const fpScript = `const f=require('@expo/fingerprint'); f.createFingerprintAsync(process.cwd(),${JSON.stringify(fingerprintOptions)}).then(x=>console.log(JSON.stringify(x)))`;
  const fingerprint = JSON.parse(command('fingerprint-before', process.execPath, ['-e', fpScript], project));
  const toolchain = { node: process.version, xcode: command('xcode-version', 'xcodebuild', ['-version'], project), sdk: command('sdk-version', 'xcrun', ['--sdk', 'iphonesimulator', '--show-sdk-version'], project),
    sdkBuild: command('sdk-build', 'xcrun', ['--sdk', 'iphonesimulator', '--show-sdk-build-version'], project), pod: command('pod-version', 'pod', ['--version'], project),
    runtime: JSON.parse(command('runtime', 'xcrun', ['simctl', 'list', 'runtimes', '--json'], project)).runtimes.map(({ identifier, version, buildversion }) => ({ identifier, version, buildversion })), architecture: 'arm64' };
  const nativeFingerprint = { version: '0.20.13', options: fingerprintOptions, fingerprint };
  let base = null;
  if (mode === 'repack') {
    base = readJSON(receiptArg);
    if (base.format !== 1 || base.project !== project || base.proofKind !== 'application-release') fail('E_WITNESS_NATIVE_COMPAT', 'receipt is not an own-build base for this project; use --build');
    const baseApp = path.join(path.dirname(path.resolve(receiptArg)), 'base.app');
    if (inventory(baseApp).sha256 !== base.executedApp.inventory.sha256) fail('E_WITNESS_PROOF', 'immutable base bytes changed; use --build');
    sameInputs(base.inputs, inputs);
    if (JSON.stringify(base.toolchain) !== JSON.stringify(toolchain) || base.nativeFingerprint.fingerprint.hash !== fingerprint.hash) fail('E_WITNESS_NATIVE_COMPAT', 'toolchain or Expo fingerprint changed; use --build');
    if (fs.existsSync(path.join(project, 'node_modules/expo-updates'))) fail('E_WITNESS_REPACK', 'linked expo-updates is outside repack support; use --build');
    if (version('@expo/repack-app') !== '0.10.3') fail('E_WITNESS_REPACK', 'repack requires installed @expo/repack-app 0.10.3; use --build');
    base.sourceApp = baseApp;
  }
  // Stable private path permits warm Xcode intermediates. A project lease in
  // the Rust parent excludes competing writers; each run retains its inputs.
  fs.mkdirSync(snapshot, { recursive: true });
  command('snapshot', '/usr/bin/rsync', ['-a', '--delete', '--exclude=/.git', '--exclude=/.expo', '--exclude=/.snapback4', '--exclude=/.snapback4-witness', '--exclude=/artifacts', '--exclude=/evidence', '--exclude=/dist', '--exclude=/choreography', '--exclude=provider-secrets.env', '--exclude=.env*', project + '/', snapshot + '/'], project);
  const sourceSnapshot = inventory(snapshot, sourceOmit);
  if (sourceSnapshot.sha256 !== source.sha256) fail('E_WITNESS_PROOF', 'source changed while snapshotting');
  sameInputs(inputs, nativeInput(snapshot), 'E_WITNESS_PROOF');
  seal(path.join(out, 'source-inputs.json'), source);
  const expoCLI = path.join(snapshot, 'node_modules/expo/bin/cli');
  const publicConfig = JSON.parse(command('public-config', process.execPath, [expoCLI, 'config', '--type', 'public', '--json']));
  let app, transformation = null, settings = null;
  if (mode === 'build') {
    if (!fs.existsSync(path.join(snapshot, 'ios'))) command('prebuild', process.execPath, [expoCLI, 'prebuild', '--platform', 'ios', '--no-install']);
    fs.writeFileSync(path.join(snapshot, 'ios/.xcode.env.local'), `export NODE_BINARY=${JSON.stringify(process.execPath)}\n`);
    command('pods', 'pod', ['install'], path.join(snapshot, 'ios'));
    const workspaces = fs.readdirSync(path.join(snapshot, 'ios')).filter(n => n.endsWith('.xcworkspace'));
    if (workspaces.length !== 1) fail('E_WITNESS_BUILD', 'no unique iOS workspace; use installed-app mode');
    const workspace = path.join(snapshot, 'ios', workspaces[0]);
    const list = JSON.parse(command('schemes', 'xcodebuild', ['-list', '-json', '-workspace', workspace]));
    const scheme = workspaces[0].slice(0, -12);
    if (!list.workspace.schemes.includes(scheme)) fail('E_WITNESS_BUILD', 'no matching application scheme; use installed-app mode');
    const derived = path.join(cache, 'DerivedData');
    const args = ['-workspace', workspace, '-scheme', scheme, '-configuration', 'Release', '-sdk', 'iphonesimulator', '-destination', `id=${udid}`, '-derivedDataPath', derived, 'ARCHS=arm64', 'ONLY_ACTIVE_ARCH=YES', 'CODE_SIGN_IDENTITY=-', 'RCT_NEW_ARCH_ENABLED=1'];
    const all = JSON.parse(command('build-settings', 'xcodebuild', [...args, '-showBuildSettings', '-json']));
    const targets = all.filter(x => x.buildSettings.PRODUCT_TYPE === 'com.apple.product-type.application' && x.target === scheme);
    if (targets.length !== 1) fail('E_WITNESS_BUILD', 'no unique application product in build settings');
    settings = targets[0].buildSettings;
    app = path.join(settings.TARGET_BUILD_DIR, settings.FULL_PRODUCT_NAME);
    // A failed build may leave a stale product; only exit success advances.
    command('xcode-build', 'xcodebuild', [...args, '-resultBundlePath', path.join(out, 'build.xcresult'), 'build']);
    app = fs.realpathSync(app);
    command('preserve-app', '/bin/cp', ['-cR', app, path.join(out, 'base.app')]);
    app = path.join(out, 'base.app');
  } else {
    const repackCLI = path.join(snapshot, 'node_modules/@expo/repack-app/build/index.js');
    const pkg = readJSON(path.join(snapshot, 'node_modules/@expo/repack-app/package.json'));
    const cli = path.join(snapshot, 'node_modules/@expo/repack-app', typeof pkg.bin === 'string' ? pkg.bin : Object.values(pkg.bin)[0]);
    app = path.join(out, 'repacked.app');
    command('repack', process.execPath, [cli, '--platform', 'ios', '--source-app', base.sourceApp, '--output', app, '--working-directory', path.join(out, 'repack-work'), '--skip-working-dir-cleanup']);
    transformation = { tool: '@expo/repack-app', version: '0.10.3', source: base.executedApp.inventory.sha256, changes: differences(base.executedApp.inventory.files, inventory(app).files) };
  }
  const executedApp = appInfo(app);
  const compilerPath = path.join(snapshot, 'node_modules/hermes-compiler/hermesc/osx-bin/hermesc');
  const compiler = { package: version('hermes-compiler'), sha256: hash(fs.readFileSync(compilerPath)), version: command('hermes-version', compilerPath, ['-version']) };
  const hbcVersion = Number(compiler.version.match(/HBC bytecode version:\s*(\d+)/)?.[1]);
  if (executedApp.javascript.version !== hbcVersion) fail('E_WITNESS_HERMES', 'bundle and installed compiler HBC versions differ');
  if (base) {
    if (JSON.stringify(executedApp.native) !== JSON.stringify(base.executedApp.native)) fail('E_WITNESS_REPACK', 'native Mach-O bytes changed; use --build');
    if (executedApp.javascript.version !== base.executedApp.javascript.version || JSON.stringify(compiler) !== JSON.stringify(base.compiler)) fail('E_WITNESS_HERMES', 'base/repack Hermes compiler or bytecode changed');
    if (JSON.stringify(executedApp.info) !== JSON.stringify(base.executedApp.info)) fail('E_WITNESS_REPACK', 'Info.plist semantics changed; use --build');
    for (const row of transformation.changes) {
      if (!(row.path === 'main.jsbundle' || row.path.startsWith('assets/') || row.path === 'app.config' || row.path === 'Info.plist' || row.path.startsWith('_CodeSignature/'))) fail('E_WITNESS_REPACK', `unclassified changed resource ${row.path}; use --build`);
    }
    if (JSON.stringify(publicConfig) !== JSON.stringify(base.publicConfig)) fail('E_WITNESS_REPACK', 'public config changed');
    if (executedApp.javascript.sha256 === base.executedApp.javascript.sha256) fail('E_WITNESS_REPACK', 'repack did not produce changed JavaScript');
  }
  const after = nativeInput(project);
  sameInputs(inputs, after, 'E_WITNESS_PROOF');
  if (inventory(project, sourceOmit).sha256 !== source.sha256) fail('E_WITNESS_PROOF', 'live source changed during preparation');
  const fpAfter = JSON.parse(command('fingerprint-after', process.execPath, ['-e', fpScript], project));
  if (fpAfter.hash !== fingerprint.hash) fail('E_WITNESS_PROOF', 'native fingerprint changed during preparation');
  const resolved = { ios: inventory(snapshot, p => !['ios', 'node_modules'].includes(p.split('/')[0]) || p === 'ios/build'), podLock: hash(fs.readFileSync(path.join(snapshot, 'ios/Podfile.lock'))), properties: readJSON(path.join(snapshot, 'ios/Podfile.properties.json')) };
  seal(path.join(out, 'resolved-native.json'), resolved);
  const result = { format: 1, proofKind: base ? 'application-release-repack' : 'application-release', project, startedAt: started, durationMs: Date.now() - started,
    inputs, nativeFingerprint, source, publicConfig, toolchain, compiler, settings, executedApp, transformation, phases, origin,
    nativeBase: base ? { app: base.executedApp.inventory.sha256, build: hash(fs.readFileSync(receiptArg)), fingerprint: base.nativeFingerprint.fingerprint.hash } : null,
    resolvedNative: hash(fs.readFileSync(path.join(out, 'resolved-native.json'))) };
  seal(path.join(out, base ? 'repack.json' : 'build.json'), result);
} catch (error) {
  seal(path.join(out, 'preparation-failure.json'), { startedAt: started, durationMs: Date.now() - started, error: String(error), phases });
  console.error(String(error)); process.exitCode = 1;
}
