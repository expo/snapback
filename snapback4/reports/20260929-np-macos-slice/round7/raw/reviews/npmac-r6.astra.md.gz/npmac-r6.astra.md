Reviewed `6234118df866b67b47eb4724e61771d4ba511391..cbb44e37fa` read-only. **Repack withdrawal is complete. One remaining output-path escape should stop landing.**

Earlier findings resolve as follows:

| Earlier finding | Verification |
|---|---|
| Embedded bytes mistaken for executed bytes | Fixed. Selected-file binding, Release/Hermes flags and launcher/Updates checks have detecting tests and recorded alternate-bundle controls. |
| Stale residency facts; native queries excused as server-only | Fixed. Facts bind to the served generation and match the kept backend before querying. Source-race/mismatch tests detect regressions; generic smoke refuses eligible native queries. |
| Preparation descendants survive interruption | Fixed for the owned process group. Resistant-child tests and recorded interruption controls cover cleanup before lease release. |
| HBC-version mismatch | Fixed. Preparation tests require refusal without a build receipt. |
| Incomplete native compatibility key | Withdrawn with repack. CLI and direct-helper refusal tests cover removal. These compatibility gaps are deferred, not claimed fixed. |
| Pods provenance captured before resolution; misattributed link control | Build records distinguish source, post-Pods and post-Xcode stages. Tests cover those stages; the inconclusive control is disclosed and replaced. |
| Directory/linker outputs, Swift forwarding, source maps, sibling Xcode destinations | Reported cases have detecting tests and controls. Build-session output is pinned during settings queries. A combined symlink/parent-traversal escape remains below. |
| Stale warm bundle; failed Xcode retaining valid products | Fixed. Warm A→B, skipped-production, required-pin and exit-65 tests detect these cases. |
| `.xcode.env.local` symlink overwrite | Fixed. Snapshot entry is removed and recreated exclusively; the test preserves the outside sentinel and source link. |
| Rejected generation leaves segment passed | Fixed. Shared validation precedes status assignment and runs again during collection; driver tests cover both paths. |
| Writable build receipts undetected | Fixed. Successful preparation now asserts mode `0444`, alongside create-once behavior. |

Explained device-query refusals, sole-booted-simulator selection and ad-hoc signing remain explicit decisions or deferrals. Requiring an explicit `--udid` was **not** implemented.

1. **Medium — Parent traversal defeats output symlink confinement.**  
   [native-closure.mjs:11](/home/ccheever/sb4-intent/review-npmac-r6-astra/snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:11)

   `canonical()` calls `path.resolve()` before resolving symlinks. That collapses `link/..` lexically, although filesystem traversal follows the link first. [POSIX pathname-resolution rules](https://pubs.opengroup.org/onlinepubs/9699919799/basedefs/V1_chap04.html).

   **Failing scenario:** the retained cache contains `link -> /Users/Shared/another-session/subdir`, and a Pod supplies:

   ```text
   OTHER_CFLAGS = -MJ <cache>/link/../compile.json
   ```

   The audit checks `<cache>/compile.json` and accepts it. Clang writes `/Users/Shared/another-session/compile.json`.

   I reproduced audit acceptance and an outside-sentinel overwrite using real Linux Clang. The equivalent Swift output path also passes the audit; a copied preparation fixture overwrote its outside sentinel and still issued `build.json`. `LD_MAP_FILE_PATH` accepts the same shape.

   **Smallest fix:** reject parent-traversal components before normalizing output paths, including followed symlink targets, or resolve components in filesystem order. Add combined symlink-plus-`..` sentinel tests at both audit and preparation boundaries.

2. **Low — Snapshot-source custody has no detecting regression.**  
   [prepare.mjs:183](/home/ccheever/sb4-intent/review-npmac-r6-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:183)

   **Surviving mutation:** deleting the snapshot-source consistency check leaves all **33 JavaScript tests passing**.

   The current guard is correct. Without it, a snapshot JavaScript edit during preparation can leave the sealed source inventory inconsistent with the bundled input.

   **Smallest fix:** have the command-boundary fixture modify snapshot JavaScript during the build, leaving live source unchanged; require `E_WITNESS_PROOF` and no `build.json`.

What is sound: no reachable repack implementation or active CLI/README claim remains. Selected-bundle verification and served-backend residency binding are substantive. Device loading fails; server-only queries must answer online. Simulator operations use resolved UDIDs, ownership checks preserve replacement processes and occupied listeners, and I found no global Xcode-selection or keychain changes.

All **33 copied JavaScript tests passed**. **31,024 archived evidence entries** matched their hashes. Final helper bytes, preparation/proof bindings and startup observations agree; the command record confirms **149.491 seconds**. No iOS execution was performed here. The checkout is unchanged, and no `provider-secrets.env` file was opened.

**Verdict: NOT READY.**