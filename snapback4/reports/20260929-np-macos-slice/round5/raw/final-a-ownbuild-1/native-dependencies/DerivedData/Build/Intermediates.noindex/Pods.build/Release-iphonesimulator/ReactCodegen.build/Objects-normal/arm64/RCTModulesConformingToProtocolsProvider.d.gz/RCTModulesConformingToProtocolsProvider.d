dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/build/generated/ios/ReactCodegen/RCTModulesConformingToProtocolsProvider.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/ReactCodegen/ReactCodegen-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/build/generated/ios/ReactCodegen/RCTModulesConformingToProtocolsProvider.h
