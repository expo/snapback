Reviewed `398552255dab53ad9aa2e347f47bded11d65aad0..77b6b88965` read-only. **Repack withdrawal is complete, but three build-route issues remain.**

1. **High — A successful warm build can seal stale JavaScript.**  
   [prepare.mjs:154](/home/ccheever/sb4-intent/review-npmac-r4-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:154)

   Both native audits accept an app build setting `SKIP_BUNDLING=1`. After building A, change JavaScript to B, enable that setting, and run `--build` again. The private product remains available, while RN’s bundling script exits successfully without replacing its HBC. Preparation then inventories and seals A’s bundle alongside B’s source inventory. Selected-bundle verification correctly identifies A, so it cannot detect this freshness failure.

   I confirmed audit acceptance and ran the pinned [RN 0.86.3 bundling script](https://github.com/facebook/react-native/blob/v0.86.3/packages/react-native/scripts/react-native-xcode.sh) in a temporary Linux copy: it exited zero and preserved the existing bundle.

   **Smallest fix:** refuse nonempty resolved `SKIP_BUNDLING`, pin it empty on the build invocation, and remove the previous product’s bundle before building so skipped production cannot pass. Add a warm A→B regression.

2. **Medium — Swift output flags bypass the private-output audit.**  
   [native-closure.mjs:169](/home/ccheever/sb4-intent/review-npmac-r4-astra/snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:169)

   The regex matches `OTHER_SWIFTFLAGS`, not Xcode’s `OTHER_SWIFT_FLAGS`. The raw app audit does not cover resolved Pods settings.

   **Failing scenario:** a Pod supplies `OTHER_SWIFT_FLAGS = -emit-module-interface-path /Users/Shared/another-session/Module.swiftinterface`. I confirmed that `auditNativeProject` accepts this. Swift treats that argument as an explicit output destination; private `SYMROOT`/`OBJROOT` cannot contain it. A later preparation refusal would occur after the write. [Swift option definitions](https://github.com/swiftlang/swift/blob/main/include/swift/Option/Options.td).

   **Smallest fix:** match the real underscore-bearing flag keys, correctly unwrap `-Xcc`/`-Xfrontend` arguments, and refuse output flags whose destinations are not canonically inside the cache. Add a resolved Pod-target sentinel test. This part of Grok’s earlier finding remains relevant to `--build`; withdrawing reuse does not resolve it.

3. **Medium — The accepted bundling phase can write a source map outside the workspace.**  
   [native-closure.mjs:40](/home/ccheever/sb4-intent/review-npmac-r4-astra/snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:40)

   **Failing scenario:** set `SOURCEMAP_FILE=/Users/Shared/another-session/app.map` in the app’s Release settings. Both raw and resolved audits accept it. The unchanged, hash-approved RN script composes the final Hermes source map directly into that path. [Pinned script](https://github.com/facebook/react-native/blob/v0.86.3/packages/react-native/scripts/react-native-xcode.sh).

   **Smallest fix:** reject this override or pin its destination inside the private cache, validating symlink parents before compilation. Test preservation of an outside sentinel.

What is sound: the CLI and direct helper reject repack before preparation, its implementation is removed, and the guide/READMEs make no active repack claim. Earlier selected-bundle, served-generation residency, native-query classification, HBC-version and owned-process-group fixes remain intact. Device-query loading cannot be excused by changing receipt facts; server-only queries must answer online. The documented data-or-explained-refusal rule remains explicit. Simulator operations use resolved UDIDs, and I found no global Xcode-selection or keychain changes. The reported linker-output escapes are now guarded.

**Low — Test gap at [prepare.mjs:29](/home/ccheever/sb4-intent/review-npmac-r4-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:29):** all 31 copied JavaScript tests pass even after deleting the subprocess-failure guard. Add a failed-`xcodebuild` case with a retained valid product and assert that no build receipt is issued.

All **7,650 round-4 archive entries** matched their hashes. Command records reproduce **172.045 s median / 199.870 s p95**. No macOS execution was rerun; the worktree is unchanged.

**Verdict: NOT READY.**