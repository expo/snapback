dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/common/cpp/react/renderer/components/rnscreens/RNSFormSheetHostState.cpp \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNScreens/RNScreens-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/common/cpp/react/renderer/components/rnscreens/RNSFormSheetHostState.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-jsi/jsi/jsi.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-jsi/jsi/jsi-inl.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-graphics/react/renderer/graphics/Float.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-graphics/react/renderer/graphics/Point.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-utils/react/utils/hash_combine.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-graphics/react/renderer/graphics/Size.h
