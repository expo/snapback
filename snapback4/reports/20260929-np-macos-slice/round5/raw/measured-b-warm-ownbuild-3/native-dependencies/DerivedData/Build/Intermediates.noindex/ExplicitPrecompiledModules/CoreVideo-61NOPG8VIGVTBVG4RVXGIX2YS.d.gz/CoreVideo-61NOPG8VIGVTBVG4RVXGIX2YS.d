moduledependenciestarget: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_DarwinFoundation1-BE00RCTLNJSPP11Z69QHTBK61.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation1.modulemap \
  /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_stdint-89GFYNQTRN3O6PBHMSF9CGVJ9.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/CoreFoundation-9KVA10SGCFQYGSWTNUQ5DOKBL.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/CoreFoundation.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/CoreGraphics-81AO72CXNU8G3VY2OA1T9OWT8.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/CoreGraphics.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/IOSurface-CB5V1DISYZ1O3KN28GNV6ZINO.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/IOSurface.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/OpenGLES-ETHQTQR9X66FE9J4NDAEZOWUN.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/OpenGLES.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/Metal-CEJYIDCA8SPI71G7BD25SOX8N.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/Metal.framework/Modules/module.modulemap
