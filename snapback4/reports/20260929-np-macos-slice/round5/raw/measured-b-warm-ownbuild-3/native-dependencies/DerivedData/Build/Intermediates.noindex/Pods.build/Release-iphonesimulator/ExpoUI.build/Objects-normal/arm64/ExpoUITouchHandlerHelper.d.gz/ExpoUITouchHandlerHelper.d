dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/@expo/ui/ios/ExpoUITouchHandlerHelper.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/ExpoUI/ExpoUI-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/@expo/ui/ios/ExpoUITouchHandlerHelper.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/XCFrameworkIntermediates/ExpoModulesCore/ExpoModulesCore.framework/Headers/Platform.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-RCTFabric/React/RCTSurfaceTouchHandler.h
