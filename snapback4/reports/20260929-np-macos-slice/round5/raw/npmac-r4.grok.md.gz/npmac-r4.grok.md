I'll review the `--build` witness read-only: first the diff, the design, and the round reports, then the code paths that could still claim a proof they didn't run.The diff is large because of recorded evidence. I'll read the design, the round-4 report, and the witness source, and I'll keep earlier review findings in view.Round 3 stopped on an unaudited Swift flag. Round 4 claims that path is gone with `--repack`. I'll read the witness implementation and check that claim against the code.Auto-compacting conversation (81% full)...
Conversation compacted.
The withdrawal and residency binding look settled. I’m checking the one open build-safety hole: whether Pod `OTHER_SWIFT_FLAGS` can still point linker or Swift outputs outside the private cache, and whether a sealed receipt would still be issued.**READY WITH CHANGES.** Withdrawal of `--repack` is complete, and a `--build` smoke receipt does not invent a passed segment, a stale selected bundle, or a server-only excuse for a device query. Output confinement is not complete: three outside destinations still reach `xcodebuild build` and still seal `application-release`. This host cannot run `simctl` or `xcodebuild`. The audit result is from calling the checkers here, and the flag text is from the sealed round-4 settings log.

## 1. Withdrawal

No reachable repack path remains. `witness.rs:25-26` rejects `--repack` and `--app-project` (including `=` forms) before flag parsing. `prepare.mjs:12` rejects any mode other than `build` before it resolves a project, creates a cache, or runs a tool. The guide (`witness.md:120`) and the package README (`README.md:96`) say the route is withdrawn. Nothing in the CLI or those docs offers repack as available. `@expo/repack-app` is still a dependency of the qualified subject app. The witness never invokes it.

## 2. Honesty of the proof

A `--build` receipt cannot claim the three things this review was asked about.

The selected bundle is the file React Native actually opened. `binding` (`preparation.rs:147-160`) requires startup format 2, helper `native-proof-v2`, `dev` false, `release` and `hermes` true, and both `selectedBundlePath` and the file URL equal to the installed `…/main.jsbundle`, with the JavaScript and executable hashes equal to the sealed proof. `prepare.mjs:154` always runs `xcodebuild build`. There is no reuse of a previous Mach-O. Warm DerivedData is incremental compilation, not a stale JS bundle presented as the one that ran.

A failed segment stays failed. `protocol.rs:63` rejects a `:failed` step before it can satisfy the milestone. `smoke.rs:120` marks the segment failed unless launch, the milestone, the screenshot, and terminate all succeed. `save_smoke` (`smoke.rs:153-156`) forces `failed` when a receipt line has `pass != true`, and it never promotes a failed segment back to passed.

Residency is the backend that was served. `bind_served_queries` (`smoke.rs:24-49`), called from `start_backend` (`witness.rs:209`), reads one SQLite generation row and requires it to match `GET /dev/status` on generation, store id, and null adoption. `served_query_facts` (`smoke.rs:6-20`) classifies from that schema. A native query is refused before smoke (`smoke.rs:14`). `validate_queries` (`smoke.rs:52-72`) compares the receipt to those driver facts, not to the app’s echoed classification. Offline, a server operation must be `loading` or `E_OFFLINE` / `E_OFFLINE_*` with the expected-unavailability string, and online it must be `ready`. A device operation must be `ready` or an explained refusal. `loading` is not accepted for it. Offline keeps the facts from the backend started for prime. Restart binds again and refuses a generation or fact change (`smoke.rs:43-46`).

The recorded closure is still not every file the compiler opened. That is the withdrawn compatibility-key issue, and LLP 3000.030 §12 says so. It is not a smoke pass for a bundle that did not run.

## 3. Build safety

**Medium.** A Pod `OTHER_SWIFT_FLAGS` or `OTHER_MODULE_VERIFIER_FLAGS` output option is not audited, the build runs, and `build.json` still seals. `native-closure.mjs:169`.

```169:169:snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs
if (/^(OTHER_(?:C|CPLUSPLUS|SWIFT|LD|LIBTOOL|MODULE_VERIFIER)FLAGS|WARNING_CFLAGS)$/.test(key) && value) flags(value, s);
```

That matches `OTHER_SWIFTFLAGS` and `OTHER_CFLAGS`. It does not match Xcode’s `OTHER_SWIFT_FLAGS` or `OTHER_MODULE_VERIFIER_FLAGS`. `validateOutputs` only sees setting keys, so a path inside the flag string is invisible. `flags()` is also the wrong hammer for the stock spelling: `-Xcc` and `-Xfrontend` do not consume their argument (`native-closure.mjs:127`).

On a copy of the preparation fixture, a Pod row with `OTHER_SWIFT_FLAGS=-index-store-path <outside> -emit-module-path <outside>/M.swiftmodule` exited 0, wrote `xcode-build.log`, overwrote the outside sentinel, and sealed `proofKind: application-release`. The same copy’s `LD_MAP_FILE_PATH` control refused at `validateOutputs`, created no build log, left the sentinel untouched, and wrote no `build.json`. `auditNativeProject` likewise accepts `OTHER_MODULE_VERIFIER_FLAGS=-index-store-path <outside>` and the stock-shaped `-Xcc -ivfsoverlay -Xcc <yaml> -Xfrontend -load-plugin-executable -Xfrontend <tool#module>`. The same `-index-store-path` on `OTHER_CFLAGS` is refused.

`native-inputs.mjs:73` returns immediately for files under `ios/Pods`, so the app-project allow-list never sees these resolved strings. The gate that runs before compile is `prepare.mjs:149-154`: `auditNativeProject`, then `xcodebuild … build`.

The qualified run did not take the escape. In `round4/raw/a-ownbuild-1/target-settings-1.log.gz` (120 Pod targets), `OTHER_SWIFT_FLAGS` is only `-D`, `-Xcc -fmodule-map-file`, `-Xcc -ivfsoverlay -Xcc`, `-Xfrontend -load-plugin-executable -Xfrontend`, `-import-underlying-module`, and warning flags. There are zero `-index-store-path`, `-emit-module-path`, `-module-cache-path`, or `-o` tokens. `INDEX_DATA_STORE_DIR` and `SWIFT_MODULE_CACHE_PATH` resolve under `.snapback4-witness/DerivedData`. Those input overlays are the deferred compatibility-key finding (LLP §12, the disposition table). They are not what this finding is. An output option in the same unparsed string is a write, and withdrawing repack does not close it.

The README states the stronger claim at `packages/snapback4/README.md:99-100`: custom output paths refuse before compilation, and all target outputs stay in the private cache. LLP §3 (`3000.030-native-proof-in-minutes.rfc.md:173-176`) requires the same pre-compile check for every app and Pods target. Both are false for this string.

**Failing scenario.** A locked pod sets `OTHER_SWIFT_FLAGS` to `-index-store-path /tmp/idx` (or `-emit-module-path`, `-module-cache-path`, `-serialize-diagnostics-path`, `-emit-dependencies-path`, `-emit-objc-header-path`, `-o`). Swift appends `OTHER_SWIFT_FLAGS` after Xcode’s own `-index-store-path`, so the last path wins. Preparation does not refuse. The index store is written outside the project. `compilerClosure` does not read index stores. `build.json` is still `application-release`.

**Smallest fix.** Before compile, scan every resolved `OTHER_*FLAGS` value for output-destination options and refuse unless the path canonicalizes inside the private cache. Do not merely correct the regex. That would reject the sealed cal25 flags, because `-Xcc -ivfsoverlay -Xcc <yaml>` would be parsed with `-Xcc` as the overlay path. Add the Pod-target case next to the existing `LD_*` sentinel test (`witness-preparation.test.mjs:175-184`). Today’s fixture (`witness-preparation-fixture.mjs:20-29`) never emits `OTHER_SWIFT_FLAGS`.

**Medium.** `PER_ARCH_OBJECT_FILE_DIR` and `COMPILATION_CACHE_CAS_PATH` are not output keys. `native-closure.mjs:40-41`.

`outputKey` matches `OBJECT_FILE_DIR`, `SYMROOT`, `OBJROOT`, `LD_MAP_FILE_PATH`, and the module-cache paths. It does not match `PER_ARCH_OBJECT_FILE_DIR` or `COMPILATION_CACHE_CAS_PATH`. The app-project scanner has the same gap (`native-inputs.mjs:90-92`). `validateOutputs` accepts both set to a directory outside the cache. On the same preparation copy, a Pod `COMPILATION_CACHE_CAS_PATH` and a Pod `PER_ARCH_OBJECT_FILE_DIR` each reached the build action, overwrote their outside sentinel, and sealed `application-release`.

In the sealed log both values are inside DerivedData (`…/DerivedData/Cache/CompilationCache.noindex` and `…/Objects-normal/…`), because `CACHE_ROOT` and `OBJROOT` are pinned (`native-closure.mjs:28-34`) and this project does not override them. An xcconfig override of either key is not refused. Xcode 27 emits both settings, so the resolved value is the one the build uses.

**Smallest fix.** Add both keys to `outputKey` and cover them with the existing outside-path `validateOutputs` test (`witness-preparation.test.mjs:252-256`).

What that check did hold: command-line `SYMROOT`, `OBJROOT`, `DSTROOT`, module caches, and `INDEX_DATA_STORE_DIR`; resolved `CONFIGURATION_BUILD_DIR` and the four linker keys, including symlink parents; private `HOME`, CocoaPods home, npm cache, and `TMPDIR` (`prepare.mjs:17-20`); `-derivedDataPath` under the project cache (`prepare.mjs:135-136`). No `xcode-select`, `security`, or `defaults write`. `CODE_SIGN_IDENTITY=-` is an ad-hoc override for this invocation, not a keychain or signing-policy change. Simulator operations use the resolved UDID (`protocol.rs:13-29`). The literal `booted` is only the `simctl list` filter. `terminate` (`witness.rs:138-144`) signals the recorded PID and leaves a replacement PID running. Preparation cleanup signals the process group and waits until `ps` shows no live member (`preparation.rs:35-49`).

## 4. Earlier findings

| Earlier finding | On `--build` now |
| --- | --- |
| Embedded bytes reported as the bundle that ran | Fixed. `preparation.rs:154-157`. |
| Residency facts not tied to the served backend | Fixed. `smoke.rs:24-49`. |
| Device `E_OFFLINE` must fail the segment | Not a defect. Data or an explained refusal is the accepted rule. Loading still fails (`smoke.rs:70`). |
| Native query classified as server-only | Fixed for this smoke. `smoke.rs:14` refuses it before launch. |
| Preparation descendants left running | Fixed for the owned group. `preparation.rs:35-49`. |
| HBC version mismatch still seals | Fixed. `prepare.mjs:166-168`. The preparation test rejects it with no `build.json`. |
| Linker map and dependency files escape | Fixed for those four keys, and the sentinel control holds. |
| `OTHER_SWIFT_FLAGS` missed by the regex | The input half (VFS `external-contents`, plugins) is an unresolved compatibility key, correctly deferred with repack. The output-option half is finding 1 and is not deferred by that sentence. |
| Project settings redirect `SYMROOT` / `OBJROOT` / `CONFIGURATION_BUILD_DIR` | Fixed for the keys that are listed. `PER_ARCH_OBJECT_FILE_DIR` and `COMPILATION_CACHE_CAS_PATH` are finding 2. |

## 5. What should change before landing

The two Medium findings should land with this route. The smoke proof does not depend on them. The private-cache claim does.

**Mutation that survives the suite.** Do not delete a check. Point a Pod target’s resolved `OTHER_SWIFT_FLAGS` at `-index-store-path` outside the cache, or set `COMPILATION_CACHE_CAS_PATH` or `PER_ARCH_OBJECT_FILE_DIR` outside it. Every current preparation test stays green. On a copy of today’s fixture, each of the three sealed `application-release` after the build action wrote the outside path. The linker-key test does not cover them.

## Verdict

**READY WITH CHANGES.** Land the withdrawal and the smoke proof. Do not land the current tree as confining every target output until a Pod `OTHER_SWIFT_FLAGS` output path, `COMPILATION_CACHE_CAS_PATH`, and `PER_ARCH_OBJECT_FILE_DIR` outside the private cache refuse before `xcodebuild build` and do not seal `build.json`.
