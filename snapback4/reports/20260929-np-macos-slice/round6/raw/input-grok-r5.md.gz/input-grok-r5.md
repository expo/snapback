I'll review the `--build` witness change read-only: first the diff range, the design, and the round 4–5 reports, then the code paths those findings named.The range is large and mostly evidence. I’ll read the prior findings and the witness source, then check whether `--repack` is actually gone.Round 4 left output confinement and bundle freshness open. I’ll read the current witness implementation and the tests that are supposed to close those holes.Auto-compacting conversation (82% full)...
Conversation compacted.
The review is ready to write once the cited lines are confirmed. I am checking only those locations, then the verdict.## Verdict: READY WITH CHANGES

`--build` is the only preparation route, and the round-4 proof bugs are fixed with tests that catch the original mutations. The private-output audit is still a denylist. Sibling Xcode 27 write destinations are not on it, so a Pod or project override can write outside `.snapback4-witness` and still seal `application-release`. That is the same class of hole as round 4. It is not a stale-bundle or misclassified-query bug. The five recorded warm runs resolved these keys inside the private cache; this review did not re-run them (Linux, no `simctl` or `xcodebuild`).

## 1. Withdrawal

Complete. `witness.rs:25-26` refuses `--repack`, `--repack=`, `--app-project`, and `--app-project=` before any tool runs. `prepare.mjs:12` accepts only `mode === 'build'`. `witness.rs` tests cover those refusals. The guide (`witness.md:126`), package README (`README.md:96`), and LLP §1 (`3000.030` lines 13–19) say repack is withdrawn and point at `--build`. LLP §4 is kept as a deferred design, and the later sections are marked historical. No witness path invokes `@expo/repack-app`.

## 2. Honesty of the proof

A `--build` receipt cannot seal the round-4 stale bundle, and a device-answerable query is not excused as server-only.

- Bundling: resolved nonempty `SKIP_BUNDLING` and `SOURCEMAP_FILE` refuse (`native-closure.mjs:47-50`). The build pins both empty, deletes `main.jsbundle` after checking it is inside the cache, and refuses to seal if Xcode did not recreate it (`prepare.mjs:153-160`). A nonzero `xcodebuild` status throws before `seal` (`prepare.mjs:29`). The fixture’s `skipped-phase`, `requires-pin`, and `failed-build` faults detect deleting those controls.
- The served backend is the one that was classified. `bind_served_queries` reads the SQLite `_generations` row and requires it to match `GET /dev/status` (generation, store id, null adoption), then parses residency from that schema (`smoke.rs:29-48`). Restart rebinds and refuses a fact or generation change (`smoke.rs:43-45`). Native optional-argument queries are refused before launch (`smoke.rs:14`).
- Classification matches that contract. Offline, a server operation must be `loading` or `E_OFFLINE` / `E_OFFLINE_*` with the expected-unavailability string (`smoke.rs:67-69`). Online, it must be `ready` (`smoke.rs:70`). A device operation must be `ready` or an explained refusal; `loading` fails. `E_OFFLINE` on a device query is the accepted explained refusal, not a new defect.

One segment-status hole remains (Low, below). It does not turn the run into a pass.

## 3. Build safety

Owned processes, UDID-scoped `simctl` operations after resolution, and the keys named in round 4 are in good shape. There is no global Xcode-defaults write and no keychain write. `CODE_SIGN_IDENTITY=-` at `prepare.mjs:136` leaves `CODE_SIGNING_ALLOWED` / `CODE_SIGNING_REQUIRED` at their project values; ad-hoc `-` consults signing, it does not add an identity. Resolved `HOME` in the qualified settings is still the account home, because Xcode fills that from the user record. User-script sandboxing is off. Phase scripts are hash-pinned. Nothing here shows a pinned script writing outside the cache.

The output check is not closed. See the Medium finding.

## 4. Earlier findings that still apply to `--build`

| Earlier finding | Now |
| --- | --- |
| High: `SKIP_BUNDLING=1` seals stale JS | Fixed. Pin, `rmSync`, exists-check, `skipped-phase` / `requires-pin`. |
| Medium: `OTHER_SWIFT_FLAGS` regex typo, Pod settings skipped, `-Xcc` / `-Xfrontend` did not consume their argument | Fixed. Regex at `native-closure.mjs:204`. Pods go through resolved settings (`prepare.mjs:146-151`). Forwarded flags are split into separate streams and unknown flags refuse (`native-closure.mjs:138-157`). |
| Medium: `SOURCEMAP_FILE` outside the workspace | Fixed. Nonempty refuses; the build pins it empty. |
| Low: failed `xcodebuild` still sealed | Fixed. `prepare.mjs:29`, fixture status 65. |
| Medium: `PER_ARCH_OBJECT_FILE_DIR`, `COMPILATION_CACHE_CAS_PATH` | Fixed. Both are output keys (`native-closure.mjs:40`) and raw rejects (`native-inputs.mjs:91`). Tests set them outside the cache. |
| Linker `LD_MAP_FILE_PATH`, `LD_DEPENDENCY_INFO_FILE`, `LD_LTO_OBJECT_FILE`, `LD_SDK_IMPORTS_FILE` | Fixed, subject to the dangling-symlink bypass below. |
| `FOLDER_PATH` / `EXECUTABLE_PATH` with `..` | Fixed (`native-closure.mjs:63-67`). |
| Repack compatibility key (Pods hash, DerivedData recheck, missing-header lookups, Swift input flags) | Withdrawn with repack. Not a `--build` defect. |
| Device `E_OFFLINE` | Accepted contract. Not re-opened. |
| Omitted `--udid` uses the sole booted simulator | Still true. Low, below. |

## 5. Findings

### Medium — sibling write destinations never enter the output audit

`snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:40-41` and `:8-11`. The same names are missing from the raw reject list at `snapback4/crates/snapback4/src/verbs/witness/native-inputs.mjs:91-93`.

`outputKey` matches the round-4 names, `OBJECT_FILE_DIR*`, a suffix list (`BUILD_DIR`, `TEMP_DIR`, `CACHE_DIR`, …), and a fixed set. It does not match these Xcode 27 destinations, which the compiler or a build task writes on their own, not as a path nested under a checked parent:

- `PER_ARCH_MODULE_FILE_DIR` — Swift/Clang `-emit-module-path`. Sibling of the key round 4 just closed. The qualified value sits under `Objects-normal`, not under `OBJECT_FILE_DIR`.
- `PRECOMP_DESTINATION_DIR` — prefix-header `-o`. Distinct from the pinned `SHARED_PRECOMPS_DIR`.
- `GENERATED_MODULEMAP_DIR` — generated module maps.
- `CLANG_MODULES_BUILD_SESSION_FILE` — clang `-fbuild-session-file`.
- `LINK_FILE_LIST_normal_arm64`, `SWIFT_RESPONSE_FILE_PATH_normal_arm64`, `LM_AUX_CONST_METADATA_LIST_PATH_normal_arm64` — file lists the compile/link tasks write, then pass to `ld` or `swiftc`.
- `PRELINK_DEPENDENCY_INFO_FILE` — sibling of the checked `LD_DEPENDENCY_INFO_FILE`.
- `INFOPLIST_PATH` and `DWARF_DSYM_FILE_NAME` when the value contains `..`. The folder-path check is only `FOLDER_PATH` / `EXECUTABLE_PATH` (`native-closure.mjs:63`). `infoPlistUtility` writes `$(TARGET_BUILD_DIR)/$(INFOPLIST_PATH)`. The qualified app uses `dwarf-with-dsym`, so a `..` dSYM name is live too.

`canonical` (`native-closure.mjs:8-11`) walks to the nearest existing parent and `realpath`s that parent only. A dangling final symlink is returned as itself. `existsSync` follows links, so a link whose target does not exist yet never resolves. An existing symlink to an outside file is refused. A link planted inside the cache, not yet pointing at a real file, is allowed, and `ld -map` then creates the outside file.

The per-project settings pass does not use `-derivedDataPath` (`prepare.mjs:149-150`). On that invocation the qualified log already resolves `CLANG_MODULES_BUILD_SESSION_FILE` to `/var/folders/.../org.llvm.clang/ModuleCache.noindex/Session.modulevalidation`, and `validateOutputs` allows it. The workspace build, which does pass `-derivedDataPath`, resolved that file inside `DerivedData`. Do not read the five warm runs as having written `/var/folders`. An override on the build that does run would be accepted and used.

Weaker cousins, same hole, less clearly independent of a checked parent: `TEMP_FILES_DIR` / `TEMP_FILE_DIR` (often aliases of the checked `TARGET_TEMP_DIR`), `PER_VARIANT_OBJECT_FILE_DIR` (often expanded into the checked `OBJECT_FILE_DIR` / `PER_ARCH_OBJECT_FILE_DIR`), `METAL_LIBRARY_OUTPUT_DIR` (only if a `.metal` source is compiled).

**Scenario.** A Pod xcconfig sets `PER_ARCH_MODULE_FILE_DIR` or `PRECOMP_DESTINATION_DIR` to `/tmp/sb4-escape`. Resolved settings stay absolute and outside the cache. `validateOutputs` never looks at the key. `xcodebuild build` writes there and `prepare.mjs` still seals `application-release`. The guide (`witness.md:82-83`), README (`README.md:100`), and LLP §1 (lines 35 and 43) say every target output stays in the private cache. That claim is broader than the check.

**Smallest fix.** Add those destination keys to `outputKey` and to the `native-inputs.mjs` reject list. Apply the `TARGET_BUILD_DIR` + `..` check to `INFOPLIST_PATH` and `DWARF_DSYM_FILE_NAME`. In `canonical`, `lstat` the final component and refuse, or resolve, a symlink even when the target is missing. Extend the existing outside-path cases in `witness-preparation.test.mjs`.

**Mutation that survives today.** Set `PER_ARCH_MODULE_FILE_DIR=/tmp/sb4-escape` on a Pod target. Current tests still pass because `outputKey` does not name it. Second mutation: point `LD_MAP_FILE_PATH` at a dangling symlink inside the cache whose target is outside. Parent-symlink tests do not catch a missing final component.

### Low — a generation mismatch leaves the segment `passed`

`snapback4/crates/snapback4/src/verbs/witness/smoke.rs:120` and `:134-135`. `save_smoke` does not repair it (`smoke.rs:167-168`).

On success the segment is stored as `passed` with `error: null`. An origin mismatch then flips both (`smoke.rs:127-131`). A `queryGeneration` / `generation` mismatch returns `E_WITNESS_RECEIPT` without flipping either. `save_smoke` rechecks query facts and the receipt, not the generation.

**Scenario.** The app’s smoke receipt says `pass: true` for `prime` but carries a different generation than the bound backend. The process exits 1 and the run error names the generation. `run.json` still has `segments.prime.status = "passed"` and `error: null`. A reader of the run sees failure. A reader of the segment status sees a pass. A test that only asserts the function returns `Err` stays green.

**Smallest fix.** Set `status` to `failed` and store the error before returning, as the origin branch does, and repeat that generation check in `save_smoke`.

### Low — omitted `--udid` attaches to whoever booted the only simulator

`snapback4/crates/snapback4/src/verbs/witness/protocol.rs:26-27`.

With no `--udid`, exactly one booted, available simulator is selected. Later `simctl` calls use that UDID, not the literal `booted` (`booted` is only the `simctl list` filter). Zero or many booted simulators already fail.

**Scenario.** On a shared Mac the only booted simulator is another user’s. `witness ios --build` installs and launches there.

**Smallest fix.** Require `--udid` always. The error text already tells the caller to pass it.

## What is sound

- Repack cannot run. Docs that a builder reads first do not offer it.
- The sealed bundle is one this build produced, or the build refuses. HBC must match the installed `hermesc`. Startup binds the selected file to the installed `main.jsbundle` and checks those hashes against the sealed proof.
- Residency facts come from the backend that was actually served, native optional-argument queries are refused, server-only operations must answer online, and device `loading` fails.
- Round-4 output keys, Swift and module-verifier flags, and `SOURCEMAP_FILE` are refused outside the cache, including on Pod targets, with tests that delete the guard and fail.
- A failed `xcodebuild` does not seal. Owned process groups are signalled and reaped before the lease drops. Qualified workspace settings for the keys this audit does cover were inside the private cache.

Nothing here is a High against the smoke proof. Do not call the private-output audit finished, and do not keep the “all target outputs stay in the private cache” sentence, until the sibling keys and the dangling final symlink are refused.
