Reviewed `398552255dab53ad9aa2e347f47bded11d65aad0..df3dd91ce0` read-only. **Repack withdrawal is complete. One remaining write outside the private workspace should stop landing.**

The rounds 1–4 findings resolve as follows:

| Earlier finding | Verification |
|---|---|
| Embedded bytes mistaken for executed bytes | Fixed. Selected-file binding, runtime flags and manifest checks have detecting helper/Rust tests and recorded alternate-bundle controls. |
| Stale residency facts; native queries excused as server-only | Fixed. Facts bind to the served generation and kept `runs`/`held`; source-race and mismatch tests detect regressions. Generic smoke refuses eligible native queries. |
| Preparation descendants survive interruption | Fixed for the owned process group. The resistant-descendant test and recorded interruption control cover cleanup before lease release. |
| HBC-version mismatch | Fixed. Preparation-level wrong-version tests require refusal without `build.json`. |
| External inputs, generated inputs, negative lookups and incomplete reuse validation | Repack is removed, so these are deferred compatibility findings, not claimed fixes. CLI and direct-helper refusal tests cover withdrawal. |
| Pods provenance captured before resolution | Build records distinguish source, post-Pods and post-Xcode inventories; preparation tests verify those stages. The misattributed Pods-link control is corrected and replaced. |
| Directory/linker outputs, Swift flags, source maps, per-architecture output and CAS paths | The reported cases are fixed, with raw/resolved checks, forwarded-argument tests and outside-sentinel controls. |
| Warm `SKIP_BUNDLING`; failed Xcode retaining valid products | Fixed. Warm A→B, skipped-production and exit-65 tests detect these regressions; the recorded RN skip control corroborates the original failure. |

The documented decisions to accept explained device-query refusals, retain sole-booted-simulator selection and use ad-hoc simulator signing remain explicit; they were not silently represented as fixes.

1. **Medium — Preparation overwrites an external file through `.xcode.env.local`.**  
   [snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:122](/home/ccheever/sb4-intent/review-npmac-r5-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:122)

   **Scenario:** `ios/.xcode.env.local` is a symlink to a shared environment file outside the project. `nativeOmit` excludes it from inspection, while `rsync -a` preserves the link. Preparation then follows it when writing `export NODE_BINARY=…`, truncating the shared file before the output audits.

   In the copied preparation fixture, this overwrote an outside sentinel, exited successfully and issued `build.json`. Actual Linux `rsync -a` also preserved the escaping link.

   **Smallest fix:** unlink the snapshot’s `.xcode.env.local` and recreate it exclusively as a regular file, or reject the symlink before writing. Add a preparation regression asserting that the external sentinel remains unchanged.

2. **Low — A rejected generation receipt leaves its segment marked passed.**  
   [snapback4/crates/snapback4/src/verbs/witness/smoke.rs:134](/home/ccheever/sb4-intent/review-npmac-r5-astra/snapback4/crates/snapback4/src/verbs/witness/smoke.rs:134)

   **Scenario:** an otherwise valid prime receipt carries the wrong `queryGeneration`. The driver rejects it here, after assigning `status: "passed"`. Collection revalidates queries and ordinary receipt fields but omits this generation check, leaving prime marked passed in the failed run.

   A harness using the copied Rust methods reproduces this. **The overall run still fails**; the inconsistency is in its segment record.

   **Smallest fix:** include generation validation before assigning final segment status, or mark the segment failed on this error. Add a driver fixture asserting both the failed exit and failed segment.

3. **Low — The tests do not enforce read-only build receipts.**  
   [snapback4/crates/snapback4/src/verbs/witness/payload.mjs:9](/home/ccheever/sb4-intent/review-npmac-r5-astra/snapback4/crates/snapback4/src/verbs/witness/payload.mjs:9)

   **Surviving mutation:** removing `mode: 0o444` from `seal()` leaves all **31 JavaScript tests passing**, while receipts become owner-writable under an ordinary umask.

   **Smallest fix:** assert the resulting `build.json` permission bits in the successful preparation test. Keep the existing create-once assertion.

What is sound: there is no reachable repack implementation or active repack claim in the CLI, guide or READMEs. Selected-bundle verification and served-backend residency binding are substantive. Device loading fails, and server-only queries must answer online. Simulator operations use resolved UDIDs; ownership checks preserve other listeners and replacement app processes. I found no global Xcode-selection or keychain changes.

All **31 copied JavaScript tests passed**. All **28,123 archived entries** from rounds 1–5 matched their hashes. The six final runs’ receipt bindings and helper bytes checked out, and command records reproduce **159.841 s median / 197.562 s p95**. No iOS execution was performed here; the worktree remains unchanged.

**Verdict: NOT READY.**