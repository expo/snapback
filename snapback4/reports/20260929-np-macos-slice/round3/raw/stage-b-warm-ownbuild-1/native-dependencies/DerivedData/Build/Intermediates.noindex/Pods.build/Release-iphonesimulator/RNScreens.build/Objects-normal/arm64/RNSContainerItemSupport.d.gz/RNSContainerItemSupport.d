dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSContainerItemSupport.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNScreens/RNScreens-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSContainerItemSupport.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSContainer.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/scroll-view/RNSScrollViewFinder.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/scroll-view/RNSContentScrollViewProviding.h
