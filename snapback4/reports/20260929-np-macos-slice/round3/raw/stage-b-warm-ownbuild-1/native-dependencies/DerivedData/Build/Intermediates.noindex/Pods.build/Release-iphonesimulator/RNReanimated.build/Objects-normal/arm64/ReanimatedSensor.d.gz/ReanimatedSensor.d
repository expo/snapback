dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-reanimated/apple/reanimated/apple/sensor/ReanimatedSensor.m \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNReanimated/RNReanimated-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/UIKit-4H1E1SO9P2ISHO6RUFT2P9CTD.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/System/Library/Frameworks/Foundation.framework/Modules/module.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/System/Library/Frameworks/CoreMotion.framework/Modules/module.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/System/Library/Frameworks/UIKit.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNReanimated/reanimated/apple/sensor/ReanimatedSensor.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNReanimated/reanimated/apple/sensor/ReanimatedSensorType.h
