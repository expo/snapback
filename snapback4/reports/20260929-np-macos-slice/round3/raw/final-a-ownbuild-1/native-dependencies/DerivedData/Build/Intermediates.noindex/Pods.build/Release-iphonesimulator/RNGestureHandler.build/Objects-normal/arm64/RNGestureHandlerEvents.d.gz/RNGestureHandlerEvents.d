dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGestureHandlerEvents.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNGestureHandler/RNGestureHandler-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGestureHandlerEvents.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTEventDispatcher.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBridge.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBridgeDelegate.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTJavaScriptLoader.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTDefines.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBridgeModule.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTJSThread.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RCTDeprecation/RCTDeprecation.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBundleManager.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBridgeModuleDecorator.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTFrameUpdate.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTInvalidating.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBridgeConstants.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTConstants.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTEventDispatcherProtocol.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTBridgeProxy.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Core/React/RCTInitializing.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGHStylusData.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGHTouchEventType.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGHUIKit.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGestureHandlerActionType.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGestureHandlerEventHandlerType.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-gesture-handler/apple/RNGestureHandlerState.h
