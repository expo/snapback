#include "Input.hxx"
int native_value(void) { return NATIVE; }
