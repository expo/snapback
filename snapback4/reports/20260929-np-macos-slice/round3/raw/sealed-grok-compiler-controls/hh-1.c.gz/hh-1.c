#include "Input.hh"
int native_value(void) { return NATIVE; }
