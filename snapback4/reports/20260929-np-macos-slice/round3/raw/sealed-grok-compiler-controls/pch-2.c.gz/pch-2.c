#include "Input.pch"
int native_value(void) { return NATIVE; }
