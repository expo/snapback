#include "safe.h"
int native_value(void) { return NATIVE; }
