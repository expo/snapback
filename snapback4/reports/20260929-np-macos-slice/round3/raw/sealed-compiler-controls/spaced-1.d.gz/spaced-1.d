/Users/ccheever/sb4-np/evidence/round3/sealed-compiler-controls/project/.cache/DerivedData/Build/Intermediates.noindex/App.o: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/evidence/round3/sealed-compiler-controls/project/ios/App.c \
  /Users/ccheever/sb4-np/evidence/round3/sealed-compiler-controls/SharedNative/SnapbackConfig.h
