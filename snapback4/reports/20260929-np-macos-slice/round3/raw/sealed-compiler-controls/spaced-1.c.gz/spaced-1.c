# include "/Users/ccheever/sb4-np/evidence/round3/sealed-compiler-controls/SharedNative/SnapbackConfig.h"
int native_value(void) { return NATIVE; }
