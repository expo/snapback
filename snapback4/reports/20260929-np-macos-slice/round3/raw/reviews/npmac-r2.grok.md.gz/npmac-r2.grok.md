I'll review the `sb4-np/np-macos` diff read-only: first the change itself, then the design, prior findings, and the recorded macOS evidence.The branch is at `72db6edc6`. Next I’ll read the implementation diff, the design, and the round-1 findings the report says it fixed.Round 1 left eight findings. I’ll check the current witness, smoke, and preparation code against each one before trusting the round-2 report.Auto-compacting conversation (81% full)...
Conversation compacted.
The review is ready to write once the cited lines are confirmed. I’ll check the native-input audit, repack gates, and the round-1 fixes, then give the verdict.The audit’s allow-list is narrower than the design. I’ll run those mutations against a copy of the checker so the review cites what it actually accepts.**NOT READY.** One round-1 High is only partly closed: a native source outside `ios/` and `node_modules` can still be compiled into the binary and then edited without `--repack` refusing. I ran that audit on a copy. The other round-1 findings are fixed in code, with the tests named below. This host is Linux, so nothing here executed `simctl`, `xcodebuild`, or the Mac driver tests.

## Round-1 findings

| Finding | Status | Detecting test or control |
| --- | --- | --- |
| Embedded bytes reported as executed bytes | Fixed for the honest helper | `WitnessContainer.observation` (`WitnessContainer.swift:16-35`) requires a file URL, resolves it, and hashes it only when it equals `Bundle.main`'s `main.jsbundle`. `startup_binds_each_independent_identity` rejects a different URL, remote URL, query, or NUL. Round 2's Documents-copy and runtime `__DEV__` controls match this code. A forged JS caller can still pass the embedded URL; LLP 3000.030 §10 says this is not an adversarial attestation. |
| Residency facts not bound to the served backend | Fixed | `bind_served_queries` (`smoke.rs:24-49`) reads the committed generation, schema, and programs in one statement and matches `/dev/status` generation, store, and null adoption. `smoke.ts:125-145` rechecks both generations and every `runs`/`held` fact against the device's kept backend before the first query. `smoke_facts_come_from_the_generation_served_after_a_source_edit` edits the schema after witness start and before the served compile. Not executed here. |
| Native inputs outside inventoried directories | **Not fixed.** The file-reference, `HEADER_SEARCH_PATHS`, xcfilelist, and custom-script cases are fixed and tested (`witness-preparation.test.mjs:75-123`). The surviving forms are the High below. | |
| Interrupted preparation leaves compiler descendants | Fixed for the owned process group | `PreparationProcess` (`preparation.rs:12-73`) keeps the leader unreaped, signals the group with SIGTERM then SIGKILL, and returns only after `ps` shows no live member. `preparation_cleans_term_resistant_descendants_before_releasing_lease` covers that. A descendant that calls `setsid`, or a SIGKILL that does not die, still escapes; the lease then drops. |
| HBC-version mutation | Fixed | `prepare.mjs:163-167` requires the bundle version to match `hermesc -version` and, on repack, the base compiler and version. `preparation rejects wrong HBC versions on own-build and repack before issuing a receipt` drives `prepare.mjs` and expects `E_WITNESS_HERMES` with no receipt. |
| `E_OFFLINE` on a device-answerable query | Not a defect | `smoke.ts:170` and `smoke.rs:70` still accept any nonempty refusal, including `E_OFFLINE`. LLP 3000.030 §5 and the round-2 RFC disposition keep "data or an explained refusal." Loading on a device query still fails. Receipts store the code and message, not invented data. |
| Native reads classified server-only | Fixed for generic smoke | `residency.rs:78-80` still adds a synthetic server site. Smoke never uses it: `smoke.rs:14` and `smoke.ts:136-137` refuse an all-optional native query before classification. `conditional native queries refuse generic smoke` covers that. Required-argument queries stay out of generic smoke. |
| `Pods` byte changes still repack | Fixed | `nativeInput` (`prepare.mjs:45-63`) inventories `ios/Pods` and `ios/build/generated/ios`, and `sameInputs` compares both. The preparation test appends to `hermesc` and expects a `pods` refusal before repack. |

## Findings

### 1. High — an outside native source still survives repack

`native-inputs.mjs:100`, `native-inputs.mjs:146`, `native-inputs.mjs:71-72`.

`settings()` only follows keys matching `SEARCH_PATHS|BRIDGING_HEADER|PREFIX_HEADER|MODULEMAP_FILE|INFOPLIST_FILE|ENTITLEMENTS`. `SWIFT_INCLUDE_PATHS` does not match, including the `[sdk=iphonesimulator*]` form. The include walk is only under `ios/`, skips `Pods` and `build`, and only reads `.h`, `.hpp`, `.c`, `.cc`, `.cpp`, `.m`, and `.mm`. A `.pch`, `.hh`, `.hxx`, `.metal`, or `module.modulemap` `header` line is never resolved. `textInputs` returns immediately for every file inside `Pods`, so an app `baseConfigurationReference` to `Pods-App.release.xcconfig` never has its `HEADER_SEARCH_PATHS` checked. That xcconfig's own bytes are hashed; the outside directory it points at is not.

A copy of `nativeReferences` today:

- ALLOW `SWIFT_INCLUDE_PATHS = $(SRCROOT)/../SharedNative`
- ALLOW the same setting with `[sdk=iphonesimulator*]`
- ALLOW `GCC_PREFIX_HEADER` pointing at `ios/App/Prefix.pch` whose body is `#include "../../SharedNative/Foo.h"`
- ALLOW the same include from `Secret.hh` and `Shader.metal`
- ALLOW `MODULEMAP_FILE` whose module map says `header "../../SharedNative/Foo.h"`
- ALLOW `Pods-App.release.xcconfig` containing `HEADER_SEARCH_PATHS = $(SRCROOT)/../SharedNative`
- REFUSE the same include from `Secret.h`
- REFUSE `HEADER_SEARCH_PATHS` (the round-1 case)

**Scenario.** The base that `--build` accepts sets `SWIFT_INCLUDE_PATHS` to `../SharedNative`, or includes that tree from `Prefix.pch`. Xcode compiles `SharedNative/Foo.swift` or `Foo.h` into the Mach-O. Edit only that outside file. `@expo/fingerprint` is rooted at the project, and `ios`, `Pods`, `node_modules`, and the reference list are unchanged, so `sameInputs` (`prepare.mjs:111`) and the fingerprint check pass. `--repack` is `--js-bundle-only` and the old Mach-O still matches (`prepare.mjs:166`). The receipt is `application-release-repack` with "native inputs unchanged" while a compiled native input changed. The same edit through a Pods xcconfig search path works, because CocoaPods writes those paths into the file the audit skips.

**Smallest fix.** In `settings()`, treat every `*_PATH`, `*_PATHS`, `*_FILE`, and `*_HEADER` value as a path, or reject an unknown path-like setting. Scan `.pch`, `.hh`, `.hxx`, `.metal`, and module-map `header` / `umbrella` lines, and scan `node_modules` and `Pods` sources the same way; resolve the include and refuse anything that canonicalizes outside `ios/` and `node_modules`. Do not return early for a Pods xcconfig that is a `baseConfigurationReference`; parse it and refuse an outside path. Add tests that the six ALLOW cases above must refuse. The existing test file does not plant any of them, so this mutation survives the suite.

### 2. Medium — the compatibility key is taken before pod resolution

`prepare.mjs:87`, `prepare.mjs:130`, `prepare.mjs:111`, `prepare.mjs:184-190`.

LLP 3000.030 §4 says to take the baseline after native generation and pod resolution have stabilized, then compare that same stage later. `inputs` is captured from the live tree before rsync and before `pod install`. `pod install` runs only in the snapshot, and only for `--build`. Repack compares `base.inputs` to the current live pre-pod tree. It never compares `resolvedNative`. That field is a single hash, and the inventory it hashes skips `ios/build` entirely (`p === 'ios/build'`), so `ios/build/generated` is not in it either.

**Scenario.** The live `ios/Pods` (and generated-header tree) is stale or incomplete. `pod install` in the snapshot rewrites Pods, and `xcodebuild` compiles that tree. `build.json`'s `inputs.pods` is still the stale live inventory. A later repack with the same stale tree passes the compatibility check and reuses the Mach-O. The Mach-O check itself is honest — repack did not relink — but "these inputs produced this binary" is not. A live edit to an inventoried Pod file still refuses, so this is not a second slip-through of a hashed source. It is the wrong stage in the key.

**Smallest fix.** After `pod install` (and after codegen has written the generated headers), set `inputs` from the snapshot and store that as the baseline. On repack, reproduce that stage and `sameInputs` it. Drop the unused `resolvedNative` hash, or compare its inventories field by field.

### 3. Medium — a project `SYMROOT` writes outside the private DerivedData

`prepare.mjs:138` and `native-inputs.mjs:100`.

The `xcodebuild` invocation sets `-derivedDataPath` under `.snapback4-witness/DerivedData` and does not set `SYMROOT`, `OBJROOT`, or `CONFIGURATION_BUILD_DIR`. An explicit project `SYMROOT` overrides the DerivedData default. `settings()` ignores `SYMROOT`, so the audit accepts it. The same probe ALLOWs `SYMROOT = /tmp/other-session-derived`.

**Scenario.** Two witnesses on one Mac use different simulators. The project, or a stale generated pbxproj, sets `SYMROOT` to the other session's DerivedData or a shared `/tmp` path. `--build` writes products there and can clobber the other session. The simulator lease, UDID-only `simctl` calls, and project `owner.lock` do not cover this directory. `xcode-select` is not changed, and other simulators are not shut down.

**Smallest fix.** Pass `SYMROOT`, `OBJROOT`, and `CONFIGURATION_BUILD_DIR` on the `xcodebuild` command line, inside the private cache. Command-line settings override the project. Refuse a build setting that still resolves elsewhere.

## Honesty of the proof

A prepared receipt cannot be upgraded. `prepare.mjs:186` sets `application-release` or `application-release-repack`, repack rejects a base that is not `application-release` (`prepare.mjs:108`), and the success line follows that field (`witness.rs:461-464`). Legacy `--bundle-id` stays `installed-application`.

A failed segment is not stored as a pass. `:failed` steps fail the receipt protocol (`protocol.rs:63`). `smoke_segment` requires `pass: true` and then `validate_queries` (`smoke.rs:122-138`). `save_smoke` forces `failed` when a later line has `pass != true` (`smoke.rs:153-156`). Device-query `loading` fails both the helper (`smoke.ts:170`) and the driver (`smoke.rs:70`). Server-only offline must be `loading` or `E_OFFLINE` / `E_OFFLINE_*`, and the same query must be `ready` online.

Facts are not taken from the app. The driver reads SQLite and `/dev/status`; the helper rechecks the kept backend; the driver recomputes classification from its own facts. An app-echoed fact that differs fails. A `held:` query is forced to `runs: "device"` even if a server site remains (`bind/mod.rs:146-149`). Offline, `E_OFFLINE` then passes under the accepted rule. The receipt shows the refusal. Native queries do not take this path.

The High above is the honesty hole: the repack receipt's native-input claim is wider than the files that were hashed.

## What is sound

- Repack still requires Mach-O equality, HBC magic `c61fbc03c103191f` and version agreement, compiler-binary agreement between `hermes-compiler` and the Pods `hermesc`, Info.plist and Expo plist equality, and changes only under `main.jsbundle` and `assets/`. `repackAssets` (`payload.mjs:64-68`) requires the asset inventory to equal the `export:embed` graph, modes included.
- Tampered base bytes fail before repack (`prepare.mjs:110`). Custom fingerprint config, `expo-updates`, workspaces, and local plugins refuse. Release is the compile-time `#if DEBUG` flag, not a JS string. `expo-dev-client` is not specially refused; a nonempty `EXDevLauncher` manifest fails the honest helper (`witness-runtime.ts:12`, `witness-core.ts:34`). The witness does not open a dev-client URL.
- Simulator selection is the resolved UDID after `device()` (`protocol.rs:13-29`). The sole-booted fallback is the accepted design. The simulator lease is `simctl getenv HOME` plus `.snapback4-witness-owner.lock`, held for the run (`witness.rs:386-387`). Install happens before that project lease drops. Termination uses `simctl terminate` only when the recorded PID is still the bundle's PID (`witness.rs:135-147`). The port bind is `127.0.0.1` only (`protocol.rs:41-42`); a stolen port fails the bind. The env allow-list and private CocoaPods, npm, and temp directories are in place. `CODE_SIGN_IDENTITY=-` remains the round-1 nonblocking note; it is not a new defect.

## Verdict

**NOT READY.** Do not land until the six outside-input cases refuse, with tests that fail on today's `native-inputs.mjs`. The pod-resolution baseline and `SYMROOT` override should land in the same fix. The measured repack median of 41.4 s does not cover this mutation.
