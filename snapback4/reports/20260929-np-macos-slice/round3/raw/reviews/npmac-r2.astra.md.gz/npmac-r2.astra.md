Reviewed `7f540f09467fcbdd73d4faa05db14fce696e9e85..72db6edc64` read-only. Two issues should stop landing.

The prior findings resolve as follows:

| Prior finding | Round 2 verification |
|---|---|
| Embedded bytes reported as executed | Fixed. RN-selected URL is checked against the installed bundle. Recorded alternate-bundle and runtime-dev controls fail. |
| Stale residency facts | Fixed. Facts come from the served generation; the helper checks generation, `runs` and `held` before querying. Copied tests and recorded injections detect mismatches. |
| External native inputs | Partially fixed; an escape remains below. |
| Surviving preparation descendants | Fixed for the owned process group. Cleanup retains the leader and lease through escalation; the recorded resistant-child control confirms stopped writes before lease release. |
| HBC-version mutation | Fixed. I repeated deletion of both guards in a copy; the preparation test now fails. |
| Device-query `E_OFFLINE` | Deliberately unchanged. Tests still accept it as an explained refusal under the documented ruling. Smoke therefore does not require every device query to return data. |
| Native queries classified server-only | Fixed by refusing eligible native queries in generic smoke. Copied tests detect this. |
| Changed Pods bytes | Fixed. The preparation test and recorded `pod-input` control detect changes. One related evidence claim needs correction below. |

1. **High — Native includes still escape the compatibility check.**  
   [native-inputs.mjs:147](/home/ccheever/sb4-intent/review-npmac-r2-astra/snapback4/crates/snapback4/src/verbs/witness/native-inputs.mjs:147)

   An unchanged `ios/App.c` can contain:

   ```c
   # include "/Users/Shared/SnapbackConfig.h"
   ```

   The space after `#` bypasses the regex. A macro-expanded include also bypasses it; computed includes are valid preprocessing syntax. [Compiler documentation](https://gcc.gnu.org/onlinedocs/cpp/Computed-Includes.html).

   Changing only that external header changes the next native compilation, while repack retains the old executable. I reproduced changed Clang output with unchanged inventories and audit results, and unchanged fingerprints using pinned `@expo/fingerprint` **0.20.13**. The command-boundary preparation fixture also issued `repack.json` after this edit.

   **Smallest reliable fix:** inspect compiler dependency records before sealing a reusable base and refuse non-SDK dependencies outside covered roots. Fail closed when dependency coverage is unavailable. Add spaced and computed-include controls.

   **Surviving mutation:** deleting the quoted C-include audit entirely still passes all **28 JavaScript tests**.

2. **Medium — Project settings can redirect builds outside the private cache.**  
   [prepare.mjs:143](/home/ccheever/sb4-intent/review-npmac-r2-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:143)

   A project with `CONFIGURATION_BUILD_DIR=/Users/Shared/another-session/Products` passes the native audit. The driver accepts the resulting `TARGET_BUILD_DIR` and starts the build without checking ownership or containment. `-derivedDataPath` alone does not constrain an explicit product-directory setting. Apple defines `CONFIGURATION_BUILD_DIR` as the destination for configuration build products. [Build settings reference](https://developer.apple.com/documentation/xcode/build-settings-reference).

   Two project copies targeting that shared directory hold different project leases and can overwrite each other’s products. I confirmed that these output overrides pass `nativeReferences`.

   **Smallest fix:** refuse custom output-directory overrides in this adapter and validate resolved product/intermediate directories for every target against the owned cache before building.

3. **Low — The Pods-link native control failed for an unrelated reason.**  
   [round2/REPORT.md:207](/home/ccheever/sb4-intent/review-npmac-r2-astra/snapback4/reports/20260929-np-macos-slice/round2/REPORT.md:207)

   The report credits rejection of the injected `SharedNative` link. Its retained failure instead names the ordinary generated `RCTAppDependencyProvider.h` target. The control checks only the diagnostic prefix, so it succeeds without reaching the injected link.

   **Smallest fix:** mark this attempt inconclusive, rerun against the final implementation with a passing unmodified baseline, and assert that the refusal names the injected link and target. The existing unit test provides separate coverage.

What is sound: build and repack provenance remain distinct; selected-bundle observations bind every prepared launch; server-only classification comes from host compiler facts; device loading fails; server-only reads must answer online. Tampered-base, Mach-O, HBC and exported-asset checks are substantive. Simulator commands use resolved UDIDs, busy listeners are preserved, and replacement app PIDs are left running.

All **28 copied JavaScript tests passed**. All **1,959 round 2 evidence entries** matched their recorded hashes. The five recorded repacks reproduce **41.385 s median / 53.816 s p95**. No iOS execution was performed here, and the worktree remains unchanged.

**Verdict: NOT READY.**