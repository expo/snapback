#pragma clang module import External
int native_value(void) { return NATIVE; }
