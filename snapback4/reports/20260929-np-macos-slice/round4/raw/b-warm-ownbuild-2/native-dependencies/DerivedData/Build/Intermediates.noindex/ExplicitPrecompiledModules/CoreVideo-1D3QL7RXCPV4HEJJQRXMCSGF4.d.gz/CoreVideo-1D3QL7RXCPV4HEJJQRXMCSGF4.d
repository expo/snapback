moduledependenciestarget: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_DarwinFoundation1-A9E9UDHCZKMZO78MAM16CS116.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation1.modulemap \
  /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_stdint-9KO3GXUXITGOPC2K5JCDBJEW4.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/CoreFoundation-AO4JYY7EYKDQTUY9MD5ZU2ASW.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/CoreFoundation.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/CoreGraphics-2S4CE75LU6BP01KAU5Y1KAVCQ.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/CoreGraphics.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/IOSurface-2PK80OK2UT1BU0NE5FX9J7DC0.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/IOSurface.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/OpenGLES-61Q4QBJ09G8QR0AMRWKLP9TZ.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/OpenGLES.framework/Modules/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/Metal-5RNHX0IACLABIU23XK8P8I12O.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/Metal.framework/Modules/module.modulemap
