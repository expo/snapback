dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/EXManifests/EXManifests.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/expo-dev-menu-interface/EXDevMenuInterface.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/expo-dev-menu/expo-dev-menu-dummy.m \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/expo-dev-menu/expo-dev-menu-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/UIKit-AQM5LFW6YACR0TD8ZE2JP83OH.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/System/Library/Frameworks/Foundation.framework/Modules/module.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/System/Library/Frameworks/UIKit.framework/Modules/module.modulemap
