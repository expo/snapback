dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSParentContainerItemRegistry.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNScreens/RNScreens-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSParentContainerItemRegistry.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSContainer.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/container/RNSContainerItem.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-screens/ios/helpers/scroll-view/RNSContentScrollViewProviding.h
