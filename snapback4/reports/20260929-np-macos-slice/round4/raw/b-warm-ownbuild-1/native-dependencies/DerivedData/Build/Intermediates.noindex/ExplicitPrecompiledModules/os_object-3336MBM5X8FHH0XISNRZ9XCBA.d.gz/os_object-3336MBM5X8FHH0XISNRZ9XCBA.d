moduledependenciestarget: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/Darwin.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_DarwinFoundation1-31ALB32USNJJTYHU1JY5GR8EZ.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation1.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/Darwin-AHWII3LIUC3LF9DS8VD4JU3R4.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/ObjectiveC-3AMZC0N09CJK83VTBNVMIP9WO.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/ObjectiveC.modulemap
