I'll review the iOS witness change read-only: first the diff, the accepted design, and the round 1–3 findings, then the code paths those findings touch.The source change is about thirty files. I'll read the prior findings and the witness implementation next, then check each claimed fix against the code.Auto-compacting conversation (80% full)...
Conversation compacted.
The remaining question is whether a native input can change without the repack check noticing. I'll verify that against the closure code and the round-1 and round-2 findings, then write the review.**NOT READY.** One native-input channel is still open, and it is the channel the sealed build actually uses. The other round-1 and round-2 findings are fixed. This host cannot run `simctl` or `xcodebuild`; the audit result below is from calling `auditNativeProject` here, and the flag text is from the sealed settings log.

## Prior findings

| Finding | Status | Detecting test or control |
| --- | --- | --- |
| Embedded bytes reported as executed | Fixed | `WitnessContainer.swift:16-24` hashes the selected file only when the resolved file URL equals `Bundle.main`'s `main.jsbundle`. `preparation.rs:149-163` checks that path, both hashes, Release, and Hermes. `startup_binds_each_independent_identity` rejects another URL, a remote URL, a query, and a NUL. |
| Residency facts not bound to the served backend | Fixed | `smoke.rs:24-49` reads one SQLite row and requires it to match `/dev/status` generation, store, and null adoption. `smoke.ts:125-145` rechecks generation, `runs`, and `held` before any query. A receipt whose `queryFacts` differ fails `smoke.rs:55`. |
| Outside native inputs (round 1), then the six round-2 cases | Fixed for those cases; one channel remains below | `witness-preparation.test.mjs:96-132` refuses `SWIFT_INCLUDE_PATHS` (including the `[sdk=iphonesimulator*]` form), `HEADER_SEARCH_PATHS`, prefix/`.pch`/`.hh`/`.hxx`/`.metal` includes, and module-map `header` lines. `witness-preparation.test.mjs:297-314` refuses the same search paths on a Pods target. `compilerClosure` refuses a spaced or macro include once it is in a `.d` (`witness-preparation.test.mjs:257-262`). Linker probes, including missing ones, refuse outside roots (`witness-preparation.test.mjs:334-336`). |
| Interrupted preparation leaves compilers running | Fixed for the owned group | `preparation.rs:35-49` signals the process group and returns only after `ps` shows no live member. `preparation_cleans_term_resistant_descendants_before_releasing_lease` covers a SIGTERM-ignoring child. |
| HBC-version mutation | Fixed | `prepare.mjs:191-195` requires the bundle version to match `hermesc -version` and, on repack, the base compiler. `witness-preparation.test.mjs:190-208` and `:235-241`. |
| Device-query `E_OFFLINE` | Not a defect | LLP 3000.030 §5 requires data or an explained refusal. Loading still fails (`smoke.ts:170`, `smoke.rs:70`). The receipt stores the code. |
| Native reads classified server-only | Fixed for generic smoke | `residency.rs:78-80` still adds a synthetic server site. Smoke never uses it: `smoke.rs:14` and `smoke.ts:136-137` refuse a native query before classification. |
| `Pods` byte changes still repack | Fixed | `prepare.mjs:49-63` inventories `ios/Pods` and `ios/build/generated`. The preparation test expects a `pods` refusal. `native-input-controls.json` records `ios/Pods/np-external.h -> SharedNative/NP.h` with `bothNamesAsserted: true` and no proof. |
| Includes and search paths escape (round 2) | Not fully fixed | The cases above are closed. `OTHER_SWIFT_FLAGS` is not. |
| Project settings redirect outputs | Fixed | `native-closure.mjs:28-34` pins the output roots on the `xcodebuild` argv. `validateOutputs` (`native-closure.mjs:38-51`) checks every target, including symlink parents. `witness-preparation.test.mjs:272-284`. The recorded `CONFIGURATION_BUILD_DIR`, `SYMROOT`, and `OBJROOT` controls refuse before compile. |
| Pods-link control failed for the wrong reason | Fixed | The round-2 attempt is marked inconclusive. The replacement diagnostic names the injected link and `SharedNative/NP.h`. |
| Compatibility key taken before `pod install` | Fixed | `prepare.mjs:141-142` and `:177` compare post-pod `inputs`, including `ios/build/generated`, before repack. `witness-preparation.test.mjs:198-203` requires the three stage hashes to differ and refuses a resolved-only Pod change before `repack.log` exists. |

## Finding

**High.** Resolved `OTHER_SWIFT_FLAGS` never enters the native audit. `snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:165`.

The scanner is:

```165:165:snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs
if (/^(OTHER_(?:C|CPLUSPLUS|SWIFT|LD|LIBTOOL|MODULE_VERIFIER)FLAGS|WARNING_CFLAGS)$/.test(key) && value) flags(value, s);
```

That matches `OTHER_SWIFTFLAGS` and `OTHER_CFLAGS`. It does not match Xcode's `OTHER_SWIFT_FLAGS` or `OTHER_MODULE_VERIFIER_FLAGS`. I called `auditNativeProject` on a Pod target: `OTHER_SWIFT_FLAGS` with `-I/<outside>` is allowed, and so is `-load-plugin-executable /<outside>/tool#Evil`. The same `-I` on `OTHER_CFLAGS` is refused.

`native-inputs.mjs:71-72` returns immediately for every file under `ios/Pods`, and `nativeInput` only parses top-level `ios/*.xcodeproj`. Pods flags are visible only in the resolved settings passed to `auditNativeProject` at `prepare.mjs:164-166`. The older allow-list never sees them. Repack then rehashes only `kind === 'toolchain'` closure inputs (`prepare.mjs:120`). A path that never entered `compiler.inputs` is not checked.

This is not a hypothetical key. In `round3/raw/sealed-a-ownbuild-1/target-settings-1.log.gz` (120 Pod targets):

- 55 targets pass `-Xcc -ivfsoverlay -Xcc …/ios/Pods/React-Core-prebuilt/React-VFS.yaml` only inside `OTHER_SWIFT_FLAGS`.
- Several, including `EXConstants`, also pass `-Xfrontend -load-plugin-executable -Xfrontend …/ExpoModulesMacros-tool#…` there.

`flags()` was written to walk `-ivfsoverlay` `external-contents` (`native-closure.mjs:126-133`) and to pin `-load-plugin-executable` (`native-closure.mjs:138-141`). Neither runs for this key. The sealed spelling would also defeat `flags()` if the key were added alone: `-Xcc` and `-Xfrontend` do not consume their argument (`native-closure.mjs:123`), so `-ivfsoverlay`'s next token is the second `-Xcc`, and the plugin's next token is the second `-Xfrontend`, not the path.

The sealed closure shows the gap is real for the overlay file. All 1,123 copied `.d` files name `ExpoModulesMacros-tool` in 11 of them, and that path is a hashed `input`. None name `React-VFS.yaml`. There are 0 `.yaml` inputs among 13,906 closure inputs. The overlay's own bytes still sit in the Pods inventory, so editing the yaml refuses. A file named only by `external-contents`, which Clang does not print into a `.d`, does not.

**Failing scenario.** A Pods target's resolved `OTHER_SWIFT_FLAGS` contains `-Xcc -ivfsoverlay -Xcc /tmp/extra.yaml`, and that overlay maps an included virtual header to `external-contents: /tmp/evil.h`. `auditNativeProject` does not open the yaml. If the `.d` names only the virtual header, `compilerClosure` hashes the unchanged in-tree file and `--build` seals. Edit `/tmp/evil.h`. `--repack` sees equal inventories, fingerprint, and toolchain hashes, reuses the old Mach-O (`prepare.mjs:194`), and records `application-release-repack`. The same shape works for a header added later on an unscanned `-I`: the directory is not a closure input, so the new file is invisible until a rebuild.

The stock macro tool does not slip today: Swift named it, it lives under `node_modules`, and that tree is inventoried. The sealed VFS file does not get that treatment.

**Smallest fix.** At `native-closure.mjs:165`, match `/^OTHER_.*FLAGS$/` and `WARNING_CFLAGS`. In `flags()`, when `-Xcc` or `-Xfrontend` is repeated before the real argument of `-ivfsoverlay`, `-include`, `-I`, or `-load-plugin-executable`, check that argument. Keep the existing rule that the only plugin path is `node_modules/@expo/expo-modules-macros-plugin/apple/ExpoModulesMacros-tool`. Add an `auditNativeProject` test for the sealed `-Xcc -ivfsoverlay -Xcc <yaml>` spelling with an outside `external-contents`, and for `OTHER_SWIFT_FLAGS=-I/<outside>`. `witness-preparation.test.mjs:100` does not cover this: it calls `nativeReferences` on the app project, which rejects the token for a different reason, and `:297-301` never passes `OTHER_SWIFT_FLAGS`.

**Mutation that survives the suite.** Delete nothing. A Pods `OTHER_SWIFT_FLAGS` of `-I/<outside>` still passes `auditNativeProject`, and every current preparation test stays green.

## Honesty of the proof

A repack cannot be labeled an own build. `prepare.mjs:214` sets `application-release-repack` only when a base exists, `prepare.mjs:112` requires that base to be `application-release`, and `witness.rs:461-464` prints from `proofKind`.

A failed segment is not stored as a pass. `protocol.rs:63` rejects a `:failed` step. `smoke.rs:122-125` copies a smoke receipt only when `pass == true`. `save_smoke` (`smoke.rs:153-156`) forces `failed` when a later line has `pass != true`, then revalidates any segment still marked passed (`smoke.rs:167-171`).

A device-answerable query cannot pass while loading. The helper throws (`smoke.ts:170`); the driver rejects anything that is not `ready` or a nonempty refusal (`smoke.rs:70`). Server-only offline must be `loading` or `E_OFFLINE` / `E_OFFLINE_*` with the expectation string, and the same query must be `ready` online (`smoke.ts:163-168`, `smoke.rs:67-70`). Server data returned offline fails. Classification does not excuse a device query: `held:` forces `runs: "device"`, and a native query is refused before that choice.

Facts are not taken from the app. The driver reads its SQLite generation and `/dev/status`. The helper rechecks the kept backend. The driver recomputes classification and rejects an echoed fact that differs. The app can still lie about `ready` versus `loading` inside a well-formed receipt; LLP 3000.030 §10 bounds this to the honest helper, not an adversarial attestation. The result code is stored, not invented.

The High above is the remaining overclaim: a repack receipt can say the native inputs are unchanged when a file reached the compiler only through `OTHER_SWIFT_FLAGS`.

## Build and repack, otherwise

Consumed files that do show up in a `.d` or `*_dependency_info.dat` are fail-closed. `compilerClosure` (`native-closure.mjs:249-300`) refuses an uncovered source, an unlinked product, an empty record set, or any path outside `ios/`, `node_modules`, the private DerivedData, the SDK, `DEVELOPER_DIR`, `/System/Library`, and `/usr/lib`. The sealed closure has 1,155 records, 782 sources, and no non-toolchain input outside the snapshot or DerivedData. Missing toolchain probes are rechecked on repack (`prepare.mjs:120`): a path that was missing and now exists refuses.

Tampered `base.app` bytes fail before repack (`prepare.mjs:114`). Mach-O JSON must match (`prepare.mjs:194`). HBC magic `c61fbc03c103191f` and the version at offset 8 must match `hermesc` and the base (`payload.mjs:36-39`, `prepare.mjs:191-195`). Both `hermesc` binaries must be the same bytes. Changes outside `main.jsbundle` and `assets/` fail. `repackAssets` (`payload.mjs:64-68`) requires the installed `assets/` inventory to equal the `export:embed` graph. Info.plist, Expo.plist, `EXConstants` `app.config`, and public config are deep-equal. The only installed mode change allowed is `0755` to `0644` on `Frameworks/*.framework/*` with identical bytes (`payload.mjs:51-58`).

`expo-updates` is refused (`prepare.mjs:99`). A nonempty dev-launcher or updates manifest fails (`witness-core.ts:34-36`). `{}` counts as absent (`witness-core.ts:16-22`), which does not by itself select another bundle: the selected URL still has to be the installed `main.jsbundle`. Release is `#if DEBUG` (`WitnessContainer.swift:25-29`), not a JavaScript string.

Custom fingerprint configs, workspaces, local plugins, and `codegenConfig` refuse (`prepare.mjs:85-96`). The recorded §11 sample is five repacks, median 53,430 ms, nearest-rank p95 54,618 ms. I did not re-time it.

## Process safety

Simulator commands use the resolved UDID after `protocol.rs:13-29`. The literal target `booted` is not used. Zero or several booted simulators refuse; the single-booted fallback is the accepted rule in LLP 3000.030 §5. The simulator lease is `simctl getenv <udid> HOME` plus `.snapback4-witness-owner.lock`, held for the run. The project lease is separate (`preparation.rs:79`) and is held across group cleanup. The port bind is `127.0.0.1` only (`protocol.rs:42`); a busy port is reported and not killed. `terminate` (`witness.rs:135-154`) calls `simctl terminate` only when the current bundle PID is still the recorded PID, and leaves a replacement PID running. There is no `xcode-select` write and no global DerivedData: `privateBuildFlags` and the private `HOME` / CocoaPods / npm / `TMPDIR` are per project. `CODE_SIGN_IDENTITY=-` is still set without `CODE_SIGNING_ALLOWED=NO` (`prepare.mjs:151`). That is the old non-blocking note, not a new defect.

## Verdict

**NOT READY.** Do not land until `OTHER_SWIFT_FLAGS` is audited, including the sealed `-Xcc -ivfsoverlay -Xcc <file>` and `-Xfrontend -load-plugin-executable -Xfrontend <tool#module>` spellings, with a test that fails on today's `auditNativeProject`. Repack stays valid only when every path that flag can open is inside an inventoried root or a rehashed toolchain input. The receipt rules, HBC and Mach-O checks, asset graph, pod-resolution key, output pinning, and UDID-scoped process ownership are otherwise fit to land.
