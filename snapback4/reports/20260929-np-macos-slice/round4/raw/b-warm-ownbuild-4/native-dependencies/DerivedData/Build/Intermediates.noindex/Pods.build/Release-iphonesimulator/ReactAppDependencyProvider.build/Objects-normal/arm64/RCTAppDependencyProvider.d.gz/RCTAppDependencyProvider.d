dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/build/generated/ios/ReactAppDependencyProvider/RCTAppDependencyProvider.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/ReactAppDependencyProvider/ReactAppDependencyProvider-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/build/generated/ios/ReactAppDependencyProvider/RCTAppDependencyProvider.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/React-RCTAppDelegate/RCTDependencyProvider.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/ReactCodegen/RCTModulesConformingToProtocolsProvider.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/ReactCodegen/RCTThirdPartyComponentsProvider.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/ReactCodegen/RCTUnstableModulesRequiringMainQueueSetupProvider.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/ReactCodegen/RCTModuleProviders.h
