Reviewed `b7d05baff661db08bb99250d80b1090a8ed99346..a26e33abc8` read-only. **Three issues remain: two native-compatibility gaps and one shared-Mac output escape.**

The earlier findings resolve as follows:

| Earlier finding | Verification |
|---|---|
| Embedded bytes reported as executed | Fixed for the honest helper. Selected-file binding, runtime flags and manifest checks have detecting tests; recorded alternate-bundle and runtime-dev controls fail. |
| Stale residency facts | Fixed. Facts bind to the served generation and are checked against the kept backend before querying. Tests and recorded stale-`runs`/`held` injections detect mismatches. |
| Preparation descendants survive interruption | Fixed for the owned process group. The resistant-child test and native interruption control verify stopped writes before lease release. |
| Surviving HBC-version mutation | Fixed. I removed both guards in a copy; the preparation test fails. |
| Device-query `E_OFFLINE` passes | **Deliberately unchanged**, under the documented data-or-explained-refusal ruling. Loading still fails; receipts distinguish refusal from data. |
| Native reads classified server-only | Fixed by refusing eligible native queries in generic smoke. Detecting helper/driver tests exist. |
| Pods bytes and pre-resolution compatibility key | Fixed. Tests detect changed source Pods, generated headers and post-resolution Pods bytes before repack. |
| External includes/search paths, including Grok’s six cases | The reported cases now have detecting tests or compiler controls. The broader compatibility claim remains incomplete: findings 1–2 below. |
| Output-directory overrides | The reported `CONFIGURATION_BUILD_DIR`, `SYMROOT` and `OBJROOT` cases now refuse, with native controls. Another output escape remains: finding 3. |
| Misattributed Pods-link control | Corrected to inconclusive. Its replacement follows a passing baseline and names both the injected link and its external target. |

1. **High — Consumed files under DerivedData are recorded but never checked on reuse.**  
   [native-closure.mjs:63](/home/ccheever/sb4-intent/review-npmac-r3-astra/snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:63), [prepare.mjs:120](/home/ccheever/sb4-intent/review-npmac-r3-astra/snapback4/crates/snapback4/src/verbs/witness/prepare.mjs:120)

   Every path under the private DerivedData directory is accepted as `generated`, without proving which build step produces it. Repack rechecks only `toolchain` entries from the compiler closure; the ordinary inventories exclude this cache.

   **Failing scenario:** an unchanged app source uses a macro-expanded include of `.snapback4-witness/DerivedData/LocalConfig.h`. The base’s dependency record includes that header and captures its hash. Change the header, then repack. Neither the input inventories nor the closure revalidation detects it, so the old native executable remains eligible.

   I reproduced this in the copied command-boundary fixture: the base recorded the header as `generated`, and changing its contents still produced `repack.json`.

   **Smallest fix:** do not exempt arbitrary DerivedData inputs. Require provenance from a qualified producer; bind and revalidate any remaining consumed files, or refuse repack eligibility for them.

2. **High — Missing compiler-header lookups are absent from the compatibility key.**  
   [native-closure.mjs:274](/home/ccheever/sb4-intent/review-npmac-r3-astra/snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:274), [native-inputs.mjs:150](/home/ccheever/sb4-intent/review-npmac-r3-astra/snapback4/crates/snapback4/src/verbs/witness/native-inputs.mjs:150)

   The compiler audit trusts successful dependencies in `.d` files. Unlike its linker handling, it captures no missing-header probes. The source audit also misses macro-expanded includes.

   **Failing scenario:**

   ```c
   #define CONFIG_HEADER "/Users/Shared/OptionalConfig.h"
   #if __has_include(CONFIG_HEADER)
   #include CONFIG_HEADER
   #else
   #define ANSWER 1
   #endif
   int answer(void) { return ANSWER; }
   ```

   Build while the external header is absent, then create it with `ANSWER 2`. Header existence changes compilation semantics. [Clang documents this behavior](https://clang.llvm.org/docs/LanguageExtensions.html#has-include).

   With real Linux Clang, the first dependency file contained only the unchanged source; creating the header changed the object bytes. Both native audits accepted the original base. The copied preparation fixture also issued `repack.json` after the external header appeared.

   **Smallest fix:** keep sources with unqualified include-availability probes ineligible for repack. Supporting them requires capturing and checking negative compiler lookups, including macro-expanded names; positive `.d` dependencies alone are insufficient.

3. **Medium — Linker output settings can still write outside the private cache.**  
   [native-closure.mjs:36](/home/ccheever/sb4-intent/review-npmac-r3-astra/snapback4/crates/snapback4/src/verbs/witness/native-closure.mjs:36), [native-inputs.mjs:89](/home/ccheever/sb4-intent/review-npmac-r3-astra/snapback4/crates/snapback4/src/verbs/witness/native-inputs.mjs:89)

   Both output checks ignore `LD_MAP_FILE_PATH`.

   **Failing scenario:** a project sets:

   ```text
   LD_GENERATE_MAP_FILE = YES
   LD_MAP_FILE_PATH = /Users/Shared/another-session/LinkMap.txt
   ```

   The raw-project audit and both resolved-settings audits accept this configuration. Xcode directs the linker to write that file; private `SYMROOT` and `OBJROOT` do not constrain the explicit map path. Another session’s file can therefore be overwritten before any later dependency-record refusal. [Apple’s build-setting reference](https://developer.apple.com/documentation/xcode/build-settings-reference) defines this destination.

   **Smallest fix:** reject custom linker-output paths or pin them inside the cache, and validate their resolved destinations for every target. Cover `LD_MAP_FILE_PATH` and `LD_DEPENDENCY_INFO_FILE`, with a control asserting that an outside sentinel remains untouched.

What is sound: build and repack provenance remain distinct; selected-bundle observations bind prepared launches; server-only classification comes from the owned backend rather than loading results. Tampered-base, native Mach-O, HBC and exported-asset checks are substantive. Simulator commands use resolved UDIDs, occupied listeners survive refusal, replacement app PIDs are preserved, and no global Xcode selection is changed.

All **32 copied JavaScript tests passed**. A remaining concrete surviving mutation is deleting the entire toolchain-input revalidation loop at `prepare.mjs:120`: all 32 still pass. Add a preparation test that changes a recorded toolchain dependency without changing its reported version.

All **11,218 archived evidence entries** across rounds 1–3 matched their hashes; the sealed helper hashes match this implementation. The five final command records reproduce **53.430 s median / 54.618 s p95**. No iOS execution was performed here, and the checkout remains unchanged.

**Verdict: NOT READY.**