dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/build/generated/ios/ReactCodegen/react/renderer/components/rngesturehandler_codegen/States.cpp \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/ReactCodegen/ReactCodegen-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/ReactCodegen/react/renderer/components/rngesturehandler_codegen/States.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-Fabric/react/renderer/core/StateData.h
