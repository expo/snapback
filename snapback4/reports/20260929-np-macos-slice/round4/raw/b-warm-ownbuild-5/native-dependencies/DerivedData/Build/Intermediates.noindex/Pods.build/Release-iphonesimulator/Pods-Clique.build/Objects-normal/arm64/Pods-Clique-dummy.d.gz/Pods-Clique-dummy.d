dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/EXConstants/EXConstants.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/EXManifests/EXManifests.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/EXUpdatesInterface/EXUpdatesInterface.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/Expo/Expo.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoAsset/ExpoAsset.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoDomWebView/ExpoDomWebView.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoGlassEffect/ExpoGlassEffect.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoImagePicker/ExpoImagePicker.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoKeepAwake/ExpoKeepAwake.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoLinking/ExpoLinking.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoLogBox/ExpoLogBox.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoRouter/ExpoRouter.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoSQLite/ExpoSQLite.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoSecureStore/ExpoSecureStore.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoSymbols/ExpoSymbols.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/ExpoUI/ExpoUI.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/RNScreens/RNScreens.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/Snapback4Expo/Snapback4Expo.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Products/Release-iphonesimulator/expo-dev-menu-interface/EXDevMenuInterface.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/Pods-Clique/Pods-Clique-dummy.m \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/Foundation-4OISIQYTAPJDKZK9SAXRBIUUN.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator.sdk/System/Library/Frameworks/Foundation.framework/Modules/module.modulemap
