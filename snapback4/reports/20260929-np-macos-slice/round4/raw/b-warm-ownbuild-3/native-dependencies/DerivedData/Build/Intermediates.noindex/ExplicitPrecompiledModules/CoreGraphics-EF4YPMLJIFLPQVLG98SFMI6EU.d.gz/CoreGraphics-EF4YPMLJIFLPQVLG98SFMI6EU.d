moduledependenciestarget: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_stdbool-4Y0X69LWYGMD1FYXX4MESLUWL.pcm \
  /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_stddef-1W4I8YL3OYMP9V0NH2DMIMK37.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_float-36VENOMK1H3YANBNAU8ZQ2TXY.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_DarwinFoundation1-31ALB32USNJJTYHU1JY5GR8EZ.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation1.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/CoreFoundation-6CMUP2FIZUYDN4QBMSD4JWQMD.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation2.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/System/Library/Frameworks/CoreFoundation.framework/Modules/module.modulemap
