dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-worklets/apple/worklets/apple/Networking/AppleNetworkingBackend.mm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNWorklets/RNWorklets-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNWorklets/worklets/apple/Networking/AppleNetworkingBackend.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNWorklets/worklets/Networking/NetworkingBackend.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNWorklets/worklets/Networking/NetworkingTypes.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNWorklets/worklets/apple/Networking/WorkletsURLSessionDelegate.h
