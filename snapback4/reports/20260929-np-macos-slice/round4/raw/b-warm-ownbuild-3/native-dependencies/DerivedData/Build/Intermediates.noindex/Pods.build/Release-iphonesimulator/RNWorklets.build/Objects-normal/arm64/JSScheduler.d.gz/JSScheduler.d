dependencies: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/node_modules/react-native-worklets/Common/cpp/worklets/Tools/JSScheduler.cpp \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Target\ Support\ Files/RNWorklets/RNWorklets-prefix.pch \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-debug/react/debug/react_native_assert.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-debug/react/debug/flags.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Private/RNWorklets/worklets/Tools/JSScheduler.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-callinvoker/ReactCommon/CallInvoker.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-callinvoker/ReactCommon/SchedulerPriority.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-jsi/jsi/jsi.h \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/snapshot/ios/Pods/Headers/Public/React-jsi/jsi/jsi-inl.h
