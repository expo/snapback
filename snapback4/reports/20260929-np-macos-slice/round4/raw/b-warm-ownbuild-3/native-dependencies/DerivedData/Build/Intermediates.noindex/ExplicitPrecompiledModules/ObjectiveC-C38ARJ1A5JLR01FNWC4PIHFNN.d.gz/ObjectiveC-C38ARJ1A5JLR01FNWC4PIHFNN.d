moduledependenciestarget: \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/SDKSettings.json \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/Darwin.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_DarwinFoundation1-6VWOEUH9T2CG08U33SZCX0YRZ.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation1.modulemap \
  /Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/clang/21/include/module.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_limits-ENK8VCCGQRXNHEH3QIB1LXVIZ.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_DarwinFoundation3-8H2R7MJ8P1CHES697U93CGOMI.pcm \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation2.modulemap \
  /Applications/Xcode.app/Contents/Developer/Platforms/iPhoneSimulator.platform/Developer/SDKs/iPhoneSimulator27.0.sdk/usr/include/DarwinFoundation3.modulemap \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/_Builtin_stdbool-AGV2ZSBPCTMCLWY3MFFZQU2PQ.pcm \
  /Users/ccheever/sb4-np/subject/.snapback4-witness/DerivedData/Build/Intermediates.noindex/ExplicitPrecompiledModules/Darwin-8UTCQEOMRTJZ3NOQ3YP2SF10Q.pcm
