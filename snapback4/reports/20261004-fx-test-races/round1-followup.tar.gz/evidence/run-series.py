import datetime, hashlib, json, os, pathlib, signal, subprocess, sys, time
base = pathlib.Path('/tmp/fx-r1-followup')
label, binary, count = sys.argv[1], sys.argv[2], int(sys.argv[3])
scratch = base / (label + '-scratch'); scratch.mkdir(exist_ok=True)
evidence = base / 'evidence'
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
record = {'label': label, 'binary': binary, 'binary_sha256': digest(binary), 'cpu': 0, 'started_at': stamp(), 'runs': []}
hog = subprocess.Popen(['taskset','-c','0','python3','-c','while True: pass'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, preexec_fn=lambda: os.sched_setaffinity(0, {0}))
record['hog_pid'] = hog.pid
record['hog_affinity'] = sorted(os.sched_getaffinity(hog.pid))
try:
 for n in range(1,count+1):
  command = ['taskset','-c','0',binary,'--nocapture']
  row = {'iteration':n, 'started_at':stamp(), 'command': command, 'hog_alive':hog.poll() is None}
  assert row['hog_alive']
  row['hog_affinity'] = sorted(os.sched_getaffinity(hog.pid))
  assert row['hog_affinity'] == [0]
  log = evidence / f'{label}-{n:02d}.log'
  start = time.monotonic()
  with log.open('wb') as out:
   child = subprocess.Popen(command, env={**os.environ,'TMPDIR':str(scratch)}, stdout=out,stderr=subprocess.STDOUT,start_new_session=True, preexec_fn=lambda: os.sched_setaffinity(0, {0}))
   row['affinity'] = sorted(os.sched_getaffinity(child.pid))
   row['pid'] = child.pid
   try:
    row['exit_code'] = child.wait(timeout=180)
   except subprocess.TimeoutExpired:
    os.killpg(child.pid, signal.SIGKILL); child.wait()
    row['exit_code'] = child.returncode; row['timeout'] = True
  row.update(finished_at=stamp(), seconds=time.monotonic()-start, log=log.name, log_sha256=digest(log), hog_alive_at_finish=hog.poll() is None)
  record['runs'].append(row)
  (evidence / f'{label}.json').write_text(json.dumps(record,indent=2)+'\n')
  print(f'{label} {n}/{count}: exit={row["exit_code"]} seconds={row["seconds"]:.2f}',flush=True)
  if row['exit_code']: break
finally:
 hog.terminate(); record['hog_exit_code'] = hog.wait(); record['hog_reaped_at'] = stamp()
 record['finished_at'] = stamp()
 record['scratch_remaining'] = [str(p.relative_to(scratch)) for p in scratch.iterdir()]
 (evidence / f'{label}.json').write_text(json.dumps(record,indent=2)+'\n')
if len(record['runs']) != count or any(r['exit_code'] for r in record['runs']): sys.exit(1)
