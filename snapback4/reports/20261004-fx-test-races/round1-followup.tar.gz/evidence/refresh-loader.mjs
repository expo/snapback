// FY's inherited-loader.mjs refresh control, with injection/arrival telemetry.
import { registerHooks } from 'node:module';
import assert from 'node:assert/strict';
registerHooks({ load(url, context, next) {
  const loaded = next(url, context);
  if (!url.endsWith('/test/worker-regressions.test.mjs')) return loaded;
  let source = String(loaded.source);
  const listener = "child.stderr.on('data', b => { s.log += b; s.events.push({ at: performance.now(), text: String(b) }); });";
  assert.equal(source.split(listener).length, 2, 'exactly one host log observer');
  source = source.replace(listener, `child.stderr.on('data', b => {
    const text = String(b), delayed = text.match(/[^\\n]*refresh-whole:[^\\n]*\\n/g)?.join('') ?? '';
    s.log += text.replace(/[^\\n]*refresh-whole:[^\\n]*\\n/g, '');
    if (delayed) {
      const started = performance.now();
      console.error('FX_REFRESH_HELD', JSON.stringify({pid: child.pid, milliseconds: 500}));
      setTimeout(() => {
        const sawLogged = s.log.includes('refresh-logged');
        const sawSplit = s.log.split('\\n').slice(0, -1).some(line => line.includes('refresh-split:'));
        s.log += delayed;
        console.error('FX_REFRESH_RELEASED', JSON.stringify({pid: child.pid, elapsed: performance.now() - started, sawLogged, sawSplit}));
      }, 500);
    }
    s.events.push({at: performance.now(), text});
  });`);
  const barrier = "  await until(() => ['refresh-whole:', 'refresh-split:'].every(prefix =>\n    s.log.split('\\n').slice(0, -1).some(line => line.includes(prefix))));";
  assert.equal(source.split(barrier).length, 2, 'exactly one independent-stream barrier');
  if (process.env.FX_REFRESH_CONTROL === 'no-barrier') source = source.replace(barrier, '');
  else assert.equal(process.env.FX_REFRESH_CONTROL, 'final');
  return {...loaded, source};
}});
