import datetime, hashlib, json, os, pathlib, re, shutil, subprocess, tarfile
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx'); base=pathlib.Path('/tmp/fx-r1-followup');e=base/'evidence'
report=root/'snapback4/reports/20261004-fx-test-races'
def stamp():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def size(p):return int(subprocess.check_output(['du','-sb',str(p)],text=True).split()[0])
metadata=json.loads((e/'metadata.json').read_text())
for p,digest in metadata['source_sha256'].items():assert sha(root/p)==digest,p
series=[]
for name,count,cases in [('witness',30,31),('http_emfile',30,9),('acquisition_crash',1,2)]:
 d=json.loads((e/f'{name}.json').read_text());assert len(d['runs'])==count
 assert d['hog_exit_code']==-15 and d['scratch_remaining']==[]
 assert sha(pathlib.Path(d['binary']))==d['binary_sha256']
 for run in d['runs']:
  assert run['exit_code']==0 and run['affinity']==[0] and run['hog_affinity']==[0]
  assert run['hog_alive'] and run['hog_alive_at_finish']
  log=e/run['log'];assert sha(log)==run['log_sha256']
  summaries=re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;',log.read_text())
  assert summaries and int(summaries[-1])==cases,log
 series.append({'name':name,'runs':count,'passes':count,'tests_per_run':cases,'cpu':0,'hog_reaped':True,'binary_sha256':d['binary_sha256'],'started_at':d['started_at'],'finished_at':d['finished_at'],'details':f'evidence/{name}.json'})
refresh=json.loads((e/'refresh.json').read_text())
for d in refresh:assert sha(e/d['log'])==d['log_sha256']
assert [d['exit_code'] for d in refresh]==[1,0]
metadata['cli_sha256']=sha(root/'snapback4/target/debug/snapback4')
(e/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
cleanup={'measured_at':stamp(),'pre_cleanup_bytes':{'target':size(root/'snapback4/target'),'scratch':size(base),'existing_dependencies':size(root/'snapback4/node_modules')}}
assert sum(cleanup['pre_cleanup_bytes'].values())<40_000_000_000
for p in base.glob('*-scratch'):assert not list(p.iterdir()),p
shutil.rmtree(root/'snapback4/target');cleanup['target_deleted_at']=stamp()
assert not (root/'snapback4/target').exists()
(e/'target-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n')
for p in base.glob('*.py'):shutil.copy2(p,e/p.name)
shutil.copy2(base/'refresh-loader.mjs',e/'refresh-loader.mjs')
archive=report/'round1-followup.tar.gz'
with tarfile.open(archive,'w:gz') as tar:tar.add(e,arcname='evidence')
verified=0
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  if member.isfile():
   assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(base/member.name),member.name
   verified+=1
cleanup['archive_verified_files']=verified
cleanup['scratch_paths_removed']=[str(base),'/tmp/fx-r1-followup-rust-search.txt']
shutil.rmtree(base)
pathlib.Path('/tmp/fx-r1-followup-rust-search.txt').unlink(missing_ok=True)
cleanup['scratch_deleted_at']=stamp()
for p in cleanup['scratch_paths_removed']:assert not pathlib.Path(p).exists()
manifest={'parent':metadata['parent'],'host':metadata['host'],'rustc':metadata['rustc'],'node':metadata['node'],'source_sha256':metadata['source_sha256'],'build_environment':metadata['build_environment'],'series':series,'refresh_control':{'milliseconds':500,'cases_per_mode':2,'without_barrier':{'exit_code':1,'passed':0,'failed':2},'final_tree':{'exit_code':0,'passed':2,'failed':0},'whole_observed_after_stderr_records':True,'details':'evidence/refresh.json','control':'evidence/refresh-loader.mjs'},'audit':'evidence/audit.json','unchanged_assertions':'evidence/assertions.json','initial_witness_series':metadata['initial_witness_series'],'full_suite':metadata['full_suite'],'remote_hosts':metadata['remote_hosts'],'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size},'cleanup':cleanup}
(report/'round1-followup.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'series':series,'cleanup':cleanup,'archive':manifest['archive']},indent=2))
