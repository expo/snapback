import datetime, hashlib, json, os, pathlib, selectors, signal, subprocess, time
base=pathlib.Path('/tmp/fx-r1-followup'); evidence=base/'evidence'
rows=[json.loads(l) for l in (evidence/'audit-build.jsonl').read_text().splitlines()]
http=next(r['executable'] for r in rows if r.get('target',{}).get('name')=='http_emfile' and r.get('executable'))
witness=(base/'witness-binary').read_text()
scratch=base/'marker-scratch';scratch.mkdir()
hog=subprocess.Popen(['taskset','-c','0','python3','-c','while True: pass'],preexec_fn=lambda:os.sched_setaffinity(0,{0}))
record={'hog_pid':hog.pid,'hog_affinity':sorted(os.sched_getaffinity(hog.pid)),'cases':[]}
try:
 command=['taskset','-c','0',witness,'--exact','many_large_scene_reports_keep_constant_peak_memory','--nocapture']
 out=subprocess.run(command,env={**os.environ,'SB4_SCENE_MEMORY_DIR':str(scratch)},capture_output=True,timeout=15)
 (evidence/'marker-witness.stdout').write_bytes(out.stdout)
 (evidence/'marker-witness.stderr').write_bytes(out.stderr)
 assert out.returncode==0
 text=out.stdout.decode(); old=any(line.startswith('scene-peak-bytes=') for line in text.splitlines())
 marker=next(line for line in text.splitlines() if 'scene-peak-bytes=' in line)
 assert not old,marker
 peak=int(text.rsplit('scene-peak-bytes=',1)[1].split()[0]); assert peak>0
 record['cases'].append({'name':'witness','command':command,'environment':{'SB4_SCENE_MEMORY_DIR':str(scratch)},'exit_code':out.returncode,'marker_line':marker,'old_line_prefix_found':old,'new_peak':peak})
 command=['taskset','-c','0',http,'--exact','descriptor_exhaustion_backlog_backs_off_and_recovers','--nocapture']
 child=subprocess.Popen(command,env={**os.environ,'SNAPBACK4_HTTP_BACKLOG_CHILD':'0'},stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,preexec_fn=lambda:os.sched_setaffinity(0,{0}))
 captured=b''
 try:
  selector=selectors.DefaultSelector();selector.register(child.stdout,selectors.EVENT_READ);end=time.monotonic()+15
  while b'FDL_ADDRESS=' not in captured or not captured.endswith(b'\n'):
   assert time.monotonic()<end,'marker not emitted'
   if selector.select(0.1):
    data=os.read(child.stdout.fileno(),8192);assert data,'child exited';captured+=data
  marker=next(line for line in captured.decode().splitlines() if 'FDL_ADDRESS=' in line)
  old=marker.strip().startswith('FDL_ADDRESS=');assert not old,marker
  address=marker.strip().rsplit('FDL_ADDRESS=',1)[1]
  assert address.startswith('127.0.0.1:') and int(address.split(':')[1])>0
 finally:
  os.killpg(child.pid,signal.SIGKILL); tail,err=child.communicate();selector.close()
 (evidence/'marker-http.stdout').write_bytes(captured+tail)
 (evidence/'marker-http.stderr').write_bytes(err)
 record['cases'].append({'name':'http_emfile','command':command,'environment':{'SNAPBACK4_HTTP_BACKLOG_CHILD':'0'},'exit_code':child.returncode,'scope':'listener-marker observation only; deliberately SIGKILLed and reaped before backlog exercise; not a test pass','marker_line':marker,'old_line_prefix_found':old,'new_address':address})
finally:
 hog.terminate();record['hog_exit_code']=hog.wait();record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (evidence/'marker-controls.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
