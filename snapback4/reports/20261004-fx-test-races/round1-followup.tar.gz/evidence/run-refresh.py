import datetime, hashlib, json, os, pathlib, subprocess, time
base=pathlib.Path('/tmp/fx-r1-followup'); evidence=base/'evidence'
source=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4/packages/snapback4/test/worker-regressions.test.mjs')
scratch=base/'refresh-scratch';scratch.mkdir()
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
results=[]
for mode in ['no-barrier','final']:
 command=['taskset','-c','0,1','node','--import',str(base/'refresh-loader.mjs'),'--test','--test-reporter=tap','--test-name-pattern=refuses refresh without logging',str(source)]
 log=evidence/f'refresh-{mode}.log'; start=time.monotonic();started=stamp()
 with log.open('wb') as out:
  p=subprocess.run(command,env={**os.environ,'FX_REFRESH_CONTROL':mode,'TMPDIR':str(scratch)},stdout=out,stderr=subprocess.STDOUT,timeout=150)
 results.append({'mode':mode,'command':command,'started_at':started,'finished_at':stamp(),'seconds':time.monotonic()-start,'exit_code':p.returncode,'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'test_sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
 print(f'refresh {mode}: exit={p.returncode}',flush=True)
(evidence/'refresh.json').write_text(json.dumps(results,indent=2)+'\n')
assert results[0]['exit_code']==1
assert results[1]['exit_code']==0
for result in results:
 log=(evidence/result['log']).read_text()
 assert log.count('FX_REFRESH_HELD {')==2
 assert log.count('FX_REFRESH_RELEASED {')==2
 for line in log.splitlines():
  if 'FX_REFRESH_RELEASED {' in line:
   r=json.loads(line.split('FX_REFRESH_RELEASED ',1)[1]);assert r['elapsed']>=499 and r['sawLogged'] and r['sawSplit'],r
