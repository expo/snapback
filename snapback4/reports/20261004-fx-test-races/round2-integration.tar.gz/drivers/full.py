import datetime,hashlib,json,os,pathlib,subprocess,time
b=pathlib.Path('/tmp/fx-integration');e=b/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx')
while not (b/'run-full').exists():time.sleep(3)
assert json.loads((e/'repetition-summary.json').read_text())['runs']==30
meta=json.loads((e/'metadata.json').read_text())
for p,d in meta['source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==d
for i in range(10):assert json.loads((e/f'lane-{i}-cleanup.json').read_text())['reaped']
for key in ['SNAPBACK4_SESSION_SEQUENCES','SNAPBACK4_ONLINE_SEQUENCES','RL_SEEDS','SB4_SEARCH_SEEDS','SNAPBACK4_TEST_SERIAL_CLIENT_FILES']:assert key not in os.environ,key
scratch=b/'full-scratch';scratch.mkdir();env={**os.environ,**meta['build_environment'],'TMPDIR':str(scratch)}
r={'command':['bash','snapback4/scripts/test.sh'],'cwd':str(root),'environment':{**meta['build_environment'],'TMPDIR':str(scratch)},'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cli_sha256_before':hashlib.sha256((root/'snapback4/target/debug/snapback4').read_bytes()).hexdigest()};start=time.monotonic()
with (e/'full-suite.log').open('wb') as log:
 child=subprocess.Popen(r['command'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT);r['pid']=child.pid;(e/'full-suite.json').write_text(json.dumps(r,indent=2)+'\n');r['exit_code']=child.wait()
r.update(finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,log_sha256=hashlib.sha256((e/'full-suite.log').read_bytes()).hexdigest(),cli_sha256_after=hashlib.sha256((root/'snapback4/target/debug/snapback4').read_bytes()).hexdigest());(e/'full-suite.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
