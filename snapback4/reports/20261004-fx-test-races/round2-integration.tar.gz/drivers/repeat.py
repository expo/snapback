import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess,time
b=pathlib.Path('/tmp/fx-integration');e=b/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
while not (e/'build-complete.json').exists():
 if (e/'build.json').exists():assert all(r['exit_code']==0 for r in json.loads((e/'build.json').read_text()))
 time.sleep(5)
meta=json.loads((e/'metadata.json').read_text())
for p,d in meta['source_sha256'].items():assert hashlib.sha256((root.parent/p).read_bytes()).hexdigest()==d
files=['cleanup.test.mjs','release-activation.test.mjs','worker-regressions.test.mjs']
plan={'files':files,'iterations':10,'lanes':10,'cpus_per_lane':4,'hogs_per_lane':1,'started':now()};(e/'repetition-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def lane(i):
 cpus=f'{4+4*i}-{7+4*i}';expected=set(range(4+4*i,8+4*i));scratch=b/f'lane-{i}-scratch';scratch.mkdir()
 hog=subprocess.Popen(['taskset','-c',cpus,'python3','-c','while True: pass']);deadline=time.monotonic()+10
 while os.sched_getaffinity(hog.pid)!=expected:
  assert time.monotonic()<deadline and hog.poll() is None;time.sleep(.01)
 try:
  with (e/f'lane-{i}.jsonl').open('w') as records:
   for name in files:
    file='packages/snapback4/test/'+name;stem=f'{pathlib.Path(name).stem}-{i+1:02}';log=e/(stem+'.log');receipt=e/(stem+'.native.json')
    cmd=['taskset','-c',cpus,'node',str(b/'run-one.mjs'),file,str(receipt)]
    r={'file':file,'iteration':i+1,'command':cmd,'cpus':cpus,'hog_pid':hog.pid,'hog_affinity':sorted(os.sched_getaffinity(hog.pid)),'started':now()};assert hog.poll() is None and set(r['hog_affinity'])==expected
    with log.open('wb') as stream:
     child=subprocess.Popen(cmd,cwd=root,env={**os.environ,'TMPDIR':str(scratch)},stdout=stream,stderr=subprocess.STDOUT);r['pid']=child.pid;r['exit_code']=child.wait()
    r.update(finished=now(),hog_alive=hog.poll() is None,native=json.loads(receipt.read_text()),log=stem+'.log.gz',log_sha256=hashlib.sha256(log.read_bytes()).hexdigest());receipt.unlink()
    with log.open('rb') as src,gzip.open(e/r['log'],'wb') as dest:shutil.copyfileobj(src,dest)
    log.unlink();records.write(json.dumps(r)+'\n');records.flush();print(json.dumps({k:r[k] for k in ['file','iteration','exit_code','finished']}),flush=True)
 finally:
  hog.terminate();hog.wait();remaining=[p.name for p in scratch.iterdir()];shutil.rmtree(scratch)
  (e/f'lane-{i}-cleanup.json').write_text(json.dumps({'hog_pid':hog.pid,'exit_code':hog.returncode,'reaped':True,'scratch_remaining_before_removal':remaining,'scratch_removed':not scratch.exists(),'finished':now()},indent=2)+'\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:list(pool.map(lane,range(10)))
rows=[json.loads(l) for p in e.glob('lane-*.jsonl') for l in p.read_text().splitlines()]
assert len(rows)==30
summary={'runs':len(rows),'passed':sum(r['exit_code']==0 for r in rows),'failed':sum(r['exit_code']!=0 for r in rows),'finished':now()};(e/'repetition-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
