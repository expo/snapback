import datetime,json,os,pathlib,subprocess,time
base=pathlib.Path('/tmp/fx-integration');root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4')
with (base/'evidence/disk.jsonl').open('w') as out:
 while not (base/'stop-monitor').exists():
  r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sizes':{},'errors':[]}
  for p in [root/'target',root/'node_modules',base]:
   result=subprocess.run(['du','-sb',str(p)],capture_output=True,text=True)
   if result.returncode:r['errors'].append({'path':str(p),'code':result.returncode,'stderr':result.stderr})
   if result.stdout:
    try:r['sizes'][str(p)]=int(result.stdout.split()[0])
    except ValueError:r['errors'].append({'path':str(p),'output':result.stdout})
  usage=os.statvfs(base);r['filesystem_free_bytes']=usage.f_bavail*usage.f_frsize
  r['owned_total_bytes']=sum(r['sizes'].values())
  r['budget_ok']=len(r['sizes'])==3 and r['owned_total_bytes']<40_000_000_000
  out.write(json.dumps(r)+'\n');out.flush();time.sleep(15)
