import datetime,hashlib,json,pathlib,re,shutil,subprocess,tarfile
b=pathlib.Path('/tmp/fx-integration');e=b/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx');report=root/'snapback4/reports/20261004-fx-test-races'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(name):return json.loads((e/name).read_text())
subprocess.run(['python3',str(b/'verify.py')],check=True)
s=read('full-suite.json');assert 'exit_code' in s;assert (b/'stop-monitor').exists()
log=(e/'full-suite.log').read_text();assert sha(log.encode())==s['log_sha256']
end=re.search(r'^== (\d+) failure\(s\) in (\d+) s$',log,re.M);assert end
s.update(reported_failed_stages=int(end[1]),reported_seconds=int(end[2]))
s['stages']=[{'result':v,'name':n,'seconds':int(t)} for v,n,t in re.findall(r'^-- (ok|FAIL): (.+) \((\d+) s\)$',log,re.M)]
counts=re.findall(r'^-- rust target: .+?: test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)
s['rust_executions']=len(counts);s['rust_counts']={k:sum(int(v[i]) for v in counts) for i,k in enumerate(['passed','failed','ignored'])}
s['client_summaries']=[dict(completed=int(a),total=int(t),failed_files=int(f),counts=json.loads(c)) for a,t,f,c in re.findall(r'^-- client files: (\d+)/(\d+); failed (\d+); tests (\{[^\n]+\})$',log,re.M)]
s['cli_matches_repetitions']=s['cli_sha256_before']==s['cli_sha256_after']==read('build-complete.json')['cli_sha256']
s['model_sequence_counts']=sorted(set(re.findall(r'sequences=(\d+)',log)))
(e/'full-suite-summary.json').write_text(json.dumps(s,indent=2)+'\n')
meta=read('metadata.json');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==meta['fx_parent'];assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()==meta['main_parent']
assert subprocess.check_output(['git','write-tree'],cwd=root,text=True).strip()==meta['qualified_tree_before_report']
for name in ['release-activation.test.mjs','worker-regressions.test.mjs','cleanup.test.mjs']:
 d=e/'resolved';d.mkdir(exist_ok=True);shutil.copy2(root/'snapback4/packages/snapback4/test'/name,d/name)
for p in b.iterdir():
 if p.is_file() and p.suffix in ('.py','.mjs'):
  dest=b/'drivers';dest.mkdir(exist_ok=True);shutil.copy2(p,dest/p.name)
files={str(p.relative_to(b)):p for d in [e,b/'drivers'] for p in d.rglob('*') if p.is_file() and p.name!='integrity.json'}
index={n:sha(p.read_bytes()) for n,p in files.items()};(e/'integrity.json').write_text(json.dumps(index,indent=2)+'\n');files['evidence/integrity.json']=e/'integrity.json'
archive=report/'round2-integration.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as t:
 assert set(t.getnames())==set(files)
 for member in t:assert sha(t.extractfile(member).read())==sha(files[member.name].read_bytes()),member.name
samples=[json.loads(l) for l in (e/'disk.jsonl').read_text().splitlines()]
disk={'samples':len(samples),'peak_sampled_owned_bytes':max(r['owned_total_bytes'] for r in samples),'samples_with_errors':sum(bool(r['errors']) for r in samples),'all_samples_under_40GB':all(r['owned_total_bytes']<40_000_000_000 for r in samples),'minimum_free_bytes':min(r['filesystem_free_bytes'] for r in samples)};assert disk['all_samples_under_40GB']
m={**meta,'repetitions':read('verification.json'),'assertion_audit':read('assertion-audit.json'),'build':read('build.json'),'full_suite':s,'disk':disk,'archive':{'path':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'all_archived_bytes_verified':True},'cleanup':{'stress_scratch_removed':True,'hogs_reaped':True,'remaining_scratch_and_target':'pending'}}
(report/'round2-integration.json').write_text(json.dumps(m,indent=2)+'\n');shutil.copy2(e/'repetitions.csv',report/'round2-integration.csv')
print(json.dumps({'repetitions':{k:m['repetitions'][k] for k in ['runs','passed','failed']},'suite':{k:s[k] for k in ['exit_code','reported_failed_stages','reported_seconds','rust_counts','client_summaries','cli_matches_repetitions']},'disk':disk,'archive':m['archive']},indent=2))
