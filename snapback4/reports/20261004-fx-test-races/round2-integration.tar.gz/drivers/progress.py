import datetime,json,pathlib,re
b=pathlib.Path('/tmp/fx-integration');e=b/'evidence';r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
if (e/'repetition-plan.json').exists():
 rows=[json.loads(l) for p in e.glob('lane-*.jsonl') for l in p.read_text().splitlines()];r['repetitions']={'completed':len(rows),'failed':[{'file':x['file'],'iteration':x['iteration'],'exit_code':x['exit_code']} for x in rows if x['exit_code']]}
else:
 r['building']=json.loads((e/'build-current.json').read_text());log=e/'build-1.log'
 if log.exists():
  targets=[]
  for l in log.read_text().splitlines():
   try:x=json.loads(l)
   except ValueError:continue
   if x.get('reason')=='compiler-artifact' and 'test' in x['target']['kind']:targets.append(x['target']['name'])
  r['integration_test_artifacts']=len(targets);r['last_artifacts']=targets[-3:]
if (e/'full-suite.json').exists():
 r['full_suite']=json.loads((e/'full-suite.json').read_text());r['suite_last_line']=(e/'full-suite.log').read_text().splitlines()[-1]
 for p in (b/'full-scratch').glob('snapback4-test.*/*.log'):
  if p.with_suffix('.status').exists():continue
  s=p.read_text(errors='replace');r[p.stem]={'last_line':s.splitlines()[-1] if s else '', 'rust_executions':len(re.findall(r'^-- rust target:',s,re.M)), 'failed_rust_targets':re.findall(r'^-- FAIL rust target: (.+)$',s,re.M),'client_files_completed':len(re.findall(r'^-- client file (?:ok|FAIL):',s,re.M)),'failed_client_files':re.findall(r'^-- client file FAIL: (.+)$',s,re.M)}
x=json.loads((e/'disk.jsonl').read_text().splitlines()[-1]);r['owned_GB']=round(x['owned_total_bytes']/1e9,2);print(json.dumps(r,indent=2))
