import collections,csv,datetime,gzip,hashlib,json,pathlib
b=pathlib.Path('/tmp/fx-integration');e=b/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx')
rows=[json.loads(l) for p in e.glob('lane-*.jsonl') for l in p.read_text().splitlines()]
assert len(rows)==30 and len({(r['file'],r['iteration']) for r in rows})==30
meta=json.loads((e/'metadata.json').read_text())
for p,d in meta['source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==d,p
by=collections.defaultdict(list)
for r in rows:
 assert hashlib.sha256(gzip.decompress((e/r['log']).read_bytes())).hexdigest()==r['log_sha256']
 n=r['native'];assert n['code']==r['exit_code'] and n['passed']==(r['exit_code']==0) and n['signal'] is None
 assert n['keeperExit']['cleanupAcknowledged'] and n['keeperExit']['signal']=='SIGKILL'
 lo,hi=map(int,r['cpus'].split('-'));assert hi-lo==3
 assert n['affinity']==r['cpus'] and r['hog_affinity']==list(range(lo,hi+1)) and r['hog_alive']
 by[r['file']].append(r)
assert len(by)==3
for runs in by.values():assert sorted(r['iteration'] for r in runs)==list(range(1,11))
for i in range(10):
 r=json.loads((e/f'lane-{i}-cleanup.json').read_text());assert r['reaped'] and r['scratch_removed']
summary={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':len(rows),'passed':sum(r['exit_code']==0 for r in rows),'failed':sum(r['exit_code']!=0 for r in rows),'files':[{'file':f,'runs':len(rs),'passed':sum(r['exit_code']==0 for r in rs),'failed':sum(r['exit_code']!=0 for r in rs),'native_counts':[r['native']['counts'] for r in rs]} for f,rs in sorted(by.items())],'log_hashes_match':True,'source_hashes_unchanged':True,'native_exits_and_affinity_checked':True,'keeper_cleanup_acknowledged':True,'all_hogs_reaped_and_stress_scratch_removed':True}
(e/'verification.json').write_text(json.dumps(summary,indent=2)+'\n')
with (e/'repetitions.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['file','iteration','started','finished','cpus','exit_code','tests','pass','fail','log','log_sha256'],lineterminator='\n');w.writeheader()
 for r in sorted(rows,key=lambda r:(r['file'],r['iteration'])):w.writerow({**{k:r[k] for k in ['file','iteration','started','finished','cpus','exit_code','log','log_sha256']},**{k:r['native']['counts'][k] for k in ['tests','pass','fail']}})
print(json.dumps({k:summary[k] for k in ['runs','passed','failed','files']}))
