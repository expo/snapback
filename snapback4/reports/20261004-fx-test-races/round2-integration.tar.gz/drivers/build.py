import datetime,hashlib,json,os,pathlib,subprocess,time
b=pathlib.Path('/tmp/fx-integration');e=b/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');meta=json.loads((e/'metadata.json').read_text());env={**os.environ,**meta['build_environment']}
commands=[['cargo','build','--workspace','--quiet'],['cargo','test','--workspace','--no-run','--message-format=json-render-diagnostics']]
results=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();r={'command':cmd,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()};(e/'build-current.json').write_text(json.dumps(r,indent=2)+'\n')
 with (e/f'build-{i}.log').open('wb') as out:
  r['exit_code']=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
 r.update(seconds=time.monotonic()-start,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256((e/f'build-{i}.log').read_bytes()).hexdigest());results.append(r)
 (e/'build.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(r),flush=True)
 if r['exit_code']:raise SystemExit(r['exit_code'])
(e/'build-complete.json').write_text(json.dumps({'cli_sha256':hashlib.sha256((root/'target/debug/snapback4').read_bytes()).hexdigest(),'finished':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
