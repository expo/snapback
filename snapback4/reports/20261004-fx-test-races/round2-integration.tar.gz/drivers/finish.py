import datetime,hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx');b=pathlib.Path('/tmp/fx-integration');report=root/'snapback4/reports/20261004-fx-test-races';mp=report/'round2-integration.json';m=json.loads(mp.read_text());s=m['full_suite']
assert m['repetitions']['runs']==m['repetitions']['passed']==30 and m['repetitions']['failed']==0
assert s['exit_code']==s['reported_failed_stages']==0 and s['cli_matches_repetitions']
assert '3000' in s['model_sequence_counts'] and '5000' in s['model_sequence_counts']
assert all(r['failed_files']==0 and r['counts']['fail']==0 for r in s['client_summaries'])
archive=report/m['archive']['path'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['archive']['sha256'] and m['archive']['all_archived_bytes_verified']
assert (b/'stop-monitor').exists()
for p,d in m['source_sha256'].items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==d
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==m['fx_parent']
assert subprocess.check_output(['git','rev-parse','MERGE_HEAD'],cwd=root,text=True).strip()==m['main_parent']
owned={str(p):int(subprocess.check_output(['du','-sb',str(p)],text=True).split()[0]) for p in [root/'snapback4/target',b]}
shutil.rmtree(root/'snapback4/target');shutil.rmtree(b)
assert not (root/'snapback4/target').exists() and not b.exists()
m['cleanup']['remaining_scratch_and_target']={'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed_bytes_before_deletion':owned,'removed_paths_absent':True,'existing_node_modules_retained':True};mp.write_text(json.dumps(m,indent=2)+'\n')
peak=m['disk']['peak_sampled_owned_bytes']/1e9
text=f"\nFY integration: merged `origin/main` at `{m['main_parent'][:10]}` (including\n`c738607178`) into `665df05f6e`. Kept FY's pre-maintenance scheduled-job crash\ngate and cleanup that preserves body failures, alongside FX's stdout-only,\ncomplete-line readiness. The worker auto-merge retains FY's identity-based\nwatchdog checks and all FX atomic-file, log-observation and lock-setup fixes.\nNo new HTTP readiness reader was added by FY. Both JOURNAL histories are\npreserved; the merge preserves all 318 FY assertion calls and every test name\nand timeout expression in the three files.\n\nThe requested release-activation, worker-regressions and cleanup files each\npassed **10/10** complete runs under a four-CPU `taskset` with a live hog\n(18, 77 and six tests/run respectively). The merged full suite\n(`bash snapback4/scripts/test.sh`) **passed, exit 0, zero failed stages in\n{s['reported_seconds']:,} seconds**, retaining the full 5,000/3,000 model histories. The\n[merge manifest](./round2-integration.json), [30-run CSV](./round2-integration.csv)\nand [raw archive](./round2-integration.tar.gz) retain both parent hashes, the\nresolution audit, native exits, affinity, source/log hashes and suite output.\nObserved build/dependency/scratch use peaked at {peak:.2f} GB; the archive retains\nthe {m['disk']['samples_with_errors']} transient disk-sampling errors as live files disappeared. Every hog was reaped; owned target\nand scratch were deleted after archive verification. Earlier Round 2 stress\nfailures remain recorded separately. No push.\n"
assert '\nFY integration: merged' not in (report/'REPORT.md').read_text()
with (report/'REPORT.md').open('a') as f:f.write(text)
print(json.dumps({'cleanup':m['cleanup'],'report_appended':True},indent=2))
