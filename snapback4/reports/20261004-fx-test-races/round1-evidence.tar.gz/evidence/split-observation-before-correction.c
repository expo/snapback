#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <fcntl.h>
static void delay(void) { struct timespec t={0,500000000}; nanosleep(&t,0); }
ssize_t read(int fd, void *buf, size_t n) {
 ssize_t (*real)(int,void*,size_t)=dlsym(RTLD_NEXT,"read");
 ssize_t r=real(fd,buf,n);
 if(getenv("FX_DELAY_STDERR") && r>0 && memmem(buf,r,"stderr-token:",13)) delay();
 return r;
}
ssize_t write(int fd, const void *buf, size_t n) {
 ssize_t (*real)(int,const void*,size_t)=dlsym(RTLD_NEXT,"write");
 if(getenv("FX_DELAY_CUT") && fd==2 && n>30 && memmem(buf,n,"snapback4 dev: read filtered",28)) {
  size_t prefix=28; ssize_t r=real(fd,buf,prefix); if(r!=prefix)return r;
  delay(); ssize_t rest=real(fd,(const char*)buf+prefix,n-prefix);return rest<0?r:r+rest;
 }
 if(getenv("FX_DELAY_CASCADE") && fd==2 && n>30 && ((memmem(buf,n,"redundant cascade diagnostic(s) hidden",37)) || memmem(buf,n,"serving the previous generation",31)) && ((const char*)buf)[n-1]=='\n') {
  ssize_t r=real(fd,buf,n-1); if(r!=n-1)return r;
  delay(); ssize_t rest=real(fd,(const char*)buf+n-1,1);return rest<0?r:r+rest;
 }
 if(getenv("FX_DELAY_URL") && fd==1 && n>20 && memmem(buf,n,"http://127.0.0.1:",16)==buf) {
  size_t prefix=17; ssize_t r=real(fd,buf,prefix); if(r!=prefix)return r;
  delay(); ssize_t rest=real(fd,(const char*)buf+prefix,n-prefix); return rest<0?r:r+rest;
 }
 if(getenv("FX_DELAY_LOCKED") && fd==1 && n==7 && memcmp(buf,"locked\n",7)==0) {
  ssize_t r=real(fd,buf,3); if(r!=3)return r;
  delay(); ssize_t rest=real(fd,(const char*)buf+3,n-3); return rest<0?r:r+rest;
 }
 if(getenv("FX_DELAY_PACKAGE") && n>20 && memmem(buf,n,"host dependency",15)) delay();
 return real(fd,buf,n);
}
