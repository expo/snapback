# FX Round 1 evidence

`lane-*.jsonl` records the main round-robin Linux pool. `extra-*.jsonl`
records the three additional Rust targets. `server-final.jsonl` and
`upload-final.jsonl` replace all main-pool invocations of those files for final
qualification. Worker-regression invocations begun at or before each host's
`worker-cutover*.json` timestamp remain intermediate; later invocations plus
`*-worker-regressions-final-*.json` establish 30 final-source runs per host.
The checked-in `round1-repetitions.csv` identifies exactly the counted logs.

A driver exit of zero means collection completed, not that every test passed.
Each record preserves the native test exit, timestamps, command, and raw-log
SHA-256. Linux records preserve CPU sets and live hog PIDs; cleanup records
confirm owned hog reaping. `affinity-snapshot.json` records descendant masks.
The file runner's native result retains its process-group cleanup verdict.

`controlled-probes.json`, `split-probes.json`, `url-partial-port-probe.json`,
`writer-lock-probes.json`, and `continue-probes.json` retain both negative and
fixed controls. Initial package and URL attempts did not reproduce the race;
see the report rather than interpreting their passes as reproduction evidence.
`retained-baseline.json` is the unchanged merged-baseline R5 control, which
reproduces the independently tracked product defect.

`drivers/` retains orchestration and probe sources, including their commands.
Scratch paths in these scripts identify the measured environment; they are
not portable installation paths. Source and binary hashes bind this evidence
to the merged tree and final test revisions. `full-suite.json` and its raw
compressed log retain the complete suite outcome, including any red stages.
No measurements here overlap the excluded 13:45–13:55Z disk-full interval.
