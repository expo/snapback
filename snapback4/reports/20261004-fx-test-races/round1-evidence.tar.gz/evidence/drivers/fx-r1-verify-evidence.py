import datetime,gzip,hashlib,json,pathlib
p=pathlib.Path('/tmp/fx-r1-evidence');rows=[]
for pattern in ['lane-*.jsonl','extra-*.jsonl','server-final.jsonl','upload-final.jsonl']:
 for f in p.glob(pattern):rows.extend(json.loads(line) for line in f.read_text().splitlines())
rows.extend(json.loads(f.read_text()) for f in p.glob('linux-worker-regressions-final-*.json'))
verified=[]
for r in rows:
 log=p/(r['name']+'.log.gz');assert hashlib.sha256(gzip.open(log,'rb').read()).hexdigest()==r['log_sha256'],r['name']
 if 'native' in r:
  n=r['native'];assert (r['exit_code']==0)==n['passed'],r['name'];assert n['keeperExit']['cleanupAcknowledged'],r['name']
 assert r['hog_alive'],r['name'];verified.append(r['name'])
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verified_runs':verified,'count':len(verified),'checks':['raw log SHA-256','native pass/exit consistency','keeper cleanup acknowledgment','live per-run CPU hog']}
(p/'evidence-integrity.json').write_text(json.dumps(record,indent=2)+'\n');print('Verified',len(rows),'completed Linux invocations')
