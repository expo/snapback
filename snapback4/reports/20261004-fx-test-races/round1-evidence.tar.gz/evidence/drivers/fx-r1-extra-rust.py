import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess
root='/home/ccheever/sb4-intent/lane-fx/snapback4';out=pathlib.Path('/tmp/fx-r1-evidence')
env=dict(os.environ,LIBSQLITE3_FLAGS='-USQLITE_ENABLE_MEMORY_MANAGEMENT',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='8')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def lane(pair):
 name,cpus=pair;hog=subprocess.Popen(['taskset','-c',cpus,'python3','-c','while True: pass']);rows=[]
 try:
  with (out/f'extra-{name}.jsonl').open('w') as records:
   for i in range(1,31):
    label=f'linux-{name}-{i:02d}';log=out/(label+'.log');cmd=['taskset','-c',cpus,'cargo','test','-p','snapback4','--test',name,'--','--nocapture'];r={'file':'rust:'+name,'name':label,'iteration':i,'cpus':cpus,'hog_pid':hog.pid,'started':now(),'command':cmd}
    r['hog_affinity']=pathlib.Path(f'/proc/{hog.pid}/status').read_text().split('Cpus_allowed_list:\t')[1].splitlines()[0]
    with log.open('wb') as stream:r['exit_code']=subprocess.run(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
    r['finished']=now();r['hog_alive']=hog.poll() is None;r['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
    with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
    log.unlink();rows.append(r);records.write(json.dumps(r)+'\n');records.flush();print(json.dumps({k:r[k] for k in ['name','exit_code','finished']}),flush=True)
 finally:
  hog.terminate();hog.wait();(out/f'extra-{name}-cleanup.json').write_text(json.dumps({'hog_pid':hog.pid,'reaped':True,'exit_code':hog.returncode,'finished':now()}))
 return rows
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:rows=[r for group in p.map(lane,[('check','84-87'),('run_admission','88-91'),('witness','92-95')]) for r in group]
(out/'extra-rust-summary.json').write_text(json.dumps({'runs':len(rows),'failed':sum(r['exit_code']!=0 for r in rows),'finished':now()},indent=2))
