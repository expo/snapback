import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');out=pathlib.Path('/tmp/fx-r1-evidence')
probes=[('package','FX_DELAY_PACKAGE',['node','--test','--test-name-pattern=uses symlinked dependencies','packages/snapback4/test/worker-regressions.test.mjs']),('redaction','FX_DELAY_STDERR',['node','--test','--test-name-pattern=redacts both child log streams','packages/snapback4/test/worker.test.mjs']),('cut','FX_DELAY_CUT',['node','--test','--test-name-pattern=dev logs a measured cut','packages/snapback4/test/client-seams.test.mjs']),('cascade','FX_DELAY_CASCADE',['cargo','test','-p','snapback4','--test','lifecycle','w10r1b_dev_reports_the_same_cascades_as_check','--','--nocapture'])]
def run(probe):
 name,var,cmd=probe;env=os.environ.copy();env.update(LD_PRELOAD='/tmp/fx-r1-delay.so',LIBSQLITE3_FLAGS='-USQLITE_ENABLE_MEMORY_MANAGEMENT',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='8');env[var]='1'
 log=out/f'probe-{name}.log';r={'probe':name,'command':cmd,'delay_env':var,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with log.open('wb') as f:r['exit_code']=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
 r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
 with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
 log.unlink();return r
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p:rows=list(p.map(run,probes))
(out/'probes.json').write_text(json.dumps(rows,indent=2));print(json.dumps(rows,indent=2))
