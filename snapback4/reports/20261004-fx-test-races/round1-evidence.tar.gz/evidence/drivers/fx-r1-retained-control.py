import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');out=pathlib.Path('/tmp/fx-r1-evidence');file=root/'packages/snapback4/test/.fx-r1-retained-control.mjs'
file.write_bytes(subprocess.check_output(['git','show','cee23d5619:snapback4/packages/snapback4/test/retained-history.test.mjs'],cwd=root));sha=hashlib.sha256(file.read_bytes()).hexdigest()
hog=subprocess.Popen(['taskset','-c','92-95','python3','-c','while True: pass'])
def run(i):
 log=out/f'retained-baseline-{i:02d}.log';cmd=['taskset','-c','92-95','node','--test','--test-name-pattern=^R5 history ',str(file)];r={'iteration':i,'command':cmd,'source_sha256':sha,'hog_pid':hog.pid,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with log.open('wb') as f:r['exit_code']=subprocess.run(cmd,cwd=root,stdout=f,stderr=subprocess.STDOUT).returncode
 r['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();r['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
 with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
 log.unlink();print(json.dumps(r),flush=True);return r
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(run,range(1,31)))
 (out/'retained-baseline.json').write_text(json.dumps(rows,indent=2))
finally:hog.terminate();hog.wait();file.unlink()
