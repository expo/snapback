import { Socket } from 'node:net';
const original = Socket.prototype.emit;
Socket.prototype.emit = function (event, ...args) {
  const value = args[0];
  if (event === 'data' && Buffer.isBuffer(value) && value.toString().startsWith('HTTP/1.1 100 Continue')) {
    process.stderr.write('FX_CONTINUE_SPLIT\n');
    original.call(this, event, value.subarray(0, 5));
    setTimeout(() => { if (!this.destroyed) original.call(this, event, value.subarray(5)); }, 500);
    return true;
  }
  return original.call(this, event, ...args);
};
