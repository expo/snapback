import datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');out=pathlib.Path('/tmp/fx-r1-evidence');cpus='80-83';file='packages/snapback4/test/server-e2e.test.mjs'
hog=subprocess.Popen(['taskset','-c',cpus,'python3','-c','while True: pass']);rows=[]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
 with (out/'server-final.jsonl').open('w') as records:
  for i in range(1,31):
   name=f'linux-server-e2e-final-{i:02d}';log=out/(name+'.log');receipt=out/(name+'.native.json');cmd=['taskset','-c',cpus,'node','/tmp/fx-r1-run-one.mjs',file,str(receipt)]
   r={'file':file,'name':name,'iteration':i,'command':cmd,'cpus':cpus,'hog_pid':hog.pid,'started':now(),'source_sha256':hashlib.sha256((root/file).read_bytes()).hexdigest()}
   with log.open('wb') as stream:r['exit_code']=subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT).returncode
   r['finished']=now();r['hog_alive']=hog.poll() is None
   if receipt.exists():r['native']=json.loads(receipt.read_text());receipt.unlink()
   r['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
   with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
   log.unlink();rows.append(r);records.write(json.dumps(r)+'\n');records.flush();print(json.dumps({k:r[k] for k in ['name','exit_code','finished']}),flush=True)
finally:
 hog.terminate();hog.wait();(out/'server-final-cleanup.json').write_text(json.dumps({'hog_pid':hog.pid,'reaped':True,'finished':now()}))
(out/'server-final-summary.json').write_text(json.dumps({'runs':len(rows),'failed':sum(r['exit_code']!=0 for r in rows),'finished':now()},indent=2))
