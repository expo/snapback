import datetime,json,os,pathlib,subprocess
root='/home/ccheever/sb4-intent/lane-fx/snapback4';out=pathlib.Path('/tmp/fx-r1-evidence')
env=dict(os.environ,LM_TEST='packages/snapback4/test/native-opening.test.mjs')
rows=[]
for i in range(1,31):
 prefix=out/f'load-helper-{i:02d}';cmd=['taskset','-c','80-83','node','packages/snapback4/test/helpers/live-margin-load.mjs',str(prefix),'1','80-83']
 rec={'iteration':i,'command':cmd,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/'load-helper-driver.log').open('ab') as log:rec['exit_code']=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
 rec['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();rows.append(rec)
 (out/'load-helper-runs.json').write_text(json.dumps(rows,indent=2))
print('Finished',len(rows),'failures',sum(r['exit_code']!=0 for r in rows))
