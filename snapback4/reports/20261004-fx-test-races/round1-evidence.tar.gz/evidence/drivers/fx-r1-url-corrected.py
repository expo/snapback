exec(open('/tmp/fx-r1-controls.py').read().split('cases=')[0])
cases=[('url-partial-port','client-seams','dev logs a measured cut',{'LD_PRELOAD':'/tmp/fx-r1-split-corrected.so','FX_DELAY_URL':'1'})]
source=open('/tmp/fx-r1-controls.py').read();exec(source[source.index('def run(case):'):].replace("controlled-probes.json","url-partial-port-probe.json"))
