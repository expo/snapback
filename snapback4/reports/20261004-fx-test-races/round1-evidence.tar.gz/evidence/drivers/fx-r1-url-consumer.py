exec(open('/tmp/fx-r1-controls.py').read().split('cases=')[0])
cases=[('url-consumer','client-seams','dev logs a measured cut',{'LD_PRELOAD':'/tmp/fx-r1-split.so','FX_DELAY_URL':'1'})]
source=open('/tmp/fx-r1-controls.py').read();exec(source[source.index('def run(case):'):].replace("controlled-probes.json","url-consumer-probe.json"))
