import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,queue,shutil,subprocess
base=pathlib.Path('/tmp/sb4-fx-r1.9lqr3D');root=base/'snapback4';out=base/'evidence';out.mkdir(exist_ok=True)
scratch=base/'test-scratch';scratch.mkdir(exist_ok=True)
env=os.environ.copy();env['TMPDIR']=str(scratch)
files=['packages/snapback4/test/worker-regressions.test.mjs','packages/snapback4/test/worker.test.mjs']
(out/'plan.json').write_text(json.dumps({'files':files,'iterations':30,'concurrency':3,'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files}},indent=2))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def run(job):
 f,i=job;name='mini-'+pathlib.Path(f).stem.replace('.test','')+f'-{i:02d}'
 log=out/(name+'.log');receipt=out/(name+'.native.json')
 cmd=['node',str(base/'run-one.mjs'),f,str(receipt)]
 rec={'name':name,'file':f,'iteration':i,'command':cmd,'started':now()}
 with log.open('wb') as stream:rec['exit_code']=subprocess.run(cmd,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
 rec['finished']=now()
 if receipt.exists():rec['native']=json.loads(receipt.read_text());receipt.unlink()
 rec['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
 with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
 log.unlink()
 (out/(name+'.json')).write_text(json.dumps(rec))
 print(json.dumps({k:rec[k] for k in ['name','exit_code','finished']}),flush=True)
 return rec
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(run,[(f,i) for i in range(1,31) for f in files]))
(out/'summary.json').write_text(json.dumps({'runs':len(rows),'failed':sum(r['exit_code']!=0 for r in rows),'finished':now()},indent=2))
