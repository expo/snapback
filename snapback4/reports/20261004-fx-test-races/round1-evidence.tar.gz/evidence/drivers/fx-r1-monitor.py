import datetime,json,pathlib,subprocess,time
out=pathlib.Path('/tmp/fx-r1-evidence'); paths=['/home/ccheever/sb4-intent/lane-fx/snapback4/target','/tmp/fx-r1-evidence','/tmp/fx-r1-full-scratch']
with (out/'disk-samples.jsonl').open('w') as records:
 while True:
  sizes={}
  for p in paths:
   if pathlib.Path(p).exists():sizes[p]=int(subprocess.check_output(['du','-sb',p],stderr=subprocess.DEVNULL).split()[0])
  records.write(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':sizes})+'\n');records.flush()
  if (out/'full-suite.json').exists():break
  time.sleep(30)
