const fs=require('node:fs'), cp=require('node:child_process');
const ts=require('/home/ccheever/sb4-intent/lane-fx/snapback4/node_modules/typescript');
const files=cp.execFileSync('git',['diff','--name-only'],{encoding:'utf8'}).trim().split('\n').filter(x=>x.endsWith('.mjs'));
function collect(text,path) {
 const sf=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS), assertions=[],names=[];
 function walk(n){ if(ts.isCallExpression(n)){const expr=n.expression.getText(sf);if(/^assert(?:\.|$)/.test(expr))assertions.push(n.getText(sf).replace(/\s+/g,' '));if(expr==='test')names.push(n.arguments[0]?.getText(sf));}ts.forEachChild(n,walk);}
 walk(sf);return {assertions,names};
}
const records=files.map(path=>{const old=collect(cp.execFileSync('git',['show','cee23d5619:'+path],{encoding:'utf8'}),path),next=collect(fs.readFileSync(path,'utf8'),path);return {path,assertionsBefore:old.assertions.length,assertionsAfter:next.assertions.length,assertionsUnchanged:JSON.stringify(old.assertions)===JSON.stringify(next.assertions),testNamesUnchanged:JSON.stringify(old.names)===JSON.stringify(next.names)};});
fs.writeFileSync('/tmp/fx-r1-evidence/assertion-census.json',JSON.stringify(records,null,2));
const failures=records.filter(r=>!r.assertionsUnchanged||!r.testNamesUnchanged);console.log(JSON.stringify({files:records.length,failures},null,2));process.exitCode=failures.length?1:0;
