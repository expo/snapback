import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,queue,shutil,subprocess,time
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');out=pathlib.Path('/tmp/fx-r1-evidence');file='packages/snapback4/test/worker-regressions.test.mjs'
cut=json.loads((out/'worker-cutover-local.json').read_text())
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def main_rows():return [json.loads(x) for p in out.glob('lane-*.jsonl') for x in p.read_text().splitlines() if x]
# Round-robin jobs start in iteration order. The first final-source completion
# establishes how many original iterations began before the source cutover.
while True:
 selected=[r for r in main_rows() if r['file']==file and r['started']>cut['completed']]
 if selected: missing=min(r['iteration'] for r in selected)-1;break
 time.sleep(5)
jobs=queue.Queue()
for i in range(1,missing+1):jobs.put(i)
def lane(n):
 cpus=f'{84+4*n}-{87+4*n}';hog=subprocess.Popen(['taskset','-c',cpus,'python3','-c','while True: pass']);rows=[]
 try:
  while True:
   try:i=jobs.get_nowait()
   except queue.Empty:return rows
   name=f'linux-worker-regressions-final-{i:02d}';log=out/(name+'.log');receipt=out/(name+'.native.json');cmd=['taskset','-c',cpus,'node','/tmp/fx-r1-run-one.mjs',file,str(receipt)]
   r={'file':file,'name':name,'iteration':i,'command':cmd,'cpus':cpus,'hog_pid':hog.pid,'started':now(),'source_sha256':hashlib.sha256((root/file).read_bytes()).hexdigest()}
   assert r['source_sha256']==cut['sha256']
   with log.open('wb') as stream:r['exit_code']=subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT).returncode
   r['finished']=now();r['hog_alive']=hog.poll() is None
   if receipt.exists():r['native']=json.loads(receipt.read_text());receipt.unlink()
   r['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
   with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
   log.unlink();rows.append(r);(out/(name+'.json')).write_text(json.dumps(r));print(json.dumps({k:r[k] for k in ['name','exit_code','finished']}),flush=True)
 finally:
  hog.terminate();hog.wait();(out/f'worker-final-lane-{n}-cleanup.json').write_text(json.dumps({'hog_pid':hog.pid,'reaped':True,'finished':now()}))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:extra=[r for group in pool.map(lane,range(3)) for r in group]
while not (out/'stress-summary.json').exists():time.sleep(5)
final=[r for r in main_rows() if r['file']==file and r['started']>cut['completed']]+extra
assert len(final)==30,(len(final),missing)
(out/'worker-final-summary.json').write_text(json.dumps({'runs':len(final),'topups':len(extra),'failed':sum(r['exit_code']!=0 for r in final),'names':[r['name'] for r in final],'finished':now()},indent=2))
