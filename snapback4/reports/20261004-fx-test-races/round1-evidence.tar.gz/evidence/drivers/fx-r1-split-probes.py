exec(open('/tmp/fx-r1-controls.py').read().split('cases=')[0])
cases=[('url','worker','redacts both child log streams',{'LD_PRELOAD':'/tmp/fx-r1-split.so','FX_DELAY_URL':'1'}),('locked','native-opening','exclusively held ownership sidecar',{'LD_PRELOAD':'/tmp/fx-r1-split.so','FX_DELAY_LOCKED':'1'})]
source=open('/tmp/fx-r1-controls.py').read();exec(source[source.index('def run(case):'):].replace("controlled-probes.json","split-probes.json"))
