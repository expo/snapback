import datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');out=pathlib.Path('/tmp/fx-r1-evidence');source='packages/snapback4/test/worker-regressions.test.mjs';baseline=root/'packages/snapback4/test/.fx-r1-writer-lock.mjs';rows=[]
# Keep all prior Round 1 fixes, changing only acquisition back to direct BEGIN.
text=(root/source).read_text().replace('await lockWriter(db);',"db.exec('BEGIN IMMEDIATE');")
baseline.write_text(text)
try:
 for variant,file in [('negative',str(baseline)),('fixed',source)]:
  log=out/f'writer-lock-{variant}.log';cmd=['node','--import','/tmp/fx-r1-writer-lock-probe.mjs','--test','--test-name-pattern=removed worker retains|failed revocation blocks restart',file];rec={'variant':variant,'command':cmd,'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
  with log.open('wb') as stream:rec['exit_code']=subprocess.run(cmd,cwd=root,stdout=stream,stderr=subprocess.STDOUT).returncode
  rec['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec['injections']=log.read_text().count('FX_WRITER_LOCK_INJECTED');rec['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
  with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
  log.unlink();rows.append(rec);print(json.dumps(rec),flush=True)
finally:baseline.unlink()
(out/'writer-lock-probes.json').write_text(json.dumps(rows,indent=2))
