import concurrent.futures,datetime,gzip,hashlib,json,os,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');out=pathlib.Path('/tmp/fx-r1-evidence')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
cases=[('package','worker-regressions','uses symlinked dependencies',{'SNAPBACK_NODE':'/tmp/fx-r1-node-delay'}),('redaction','worker','redacts both child log streams',{'LD_PRELOAD':'/tmp/fx-r1-delay.so','FX_DELAY_STDERR':'1'}),('cut','client-seams','dev logs a measured cut',{'LD_PRELOAD':'/tmp/fx-r1-delay.so','FX_DELAY_CUT':'1'})]
def run(case):
 name,stem,pattern,extra=case;rows=[]
 source='packages/snapback4/test/'+stem+'.test.mjs';baseline=root/'packages/snapback4/test'/('.fx-r1-'+stem+'.mjs')
 baseline.write_bytes(subprocess.check_output(['git','show','cee23d5619:snapback4/'+source],cwd=root))
 try:
  for variant,file in [('negative',str(baseline)),('fixed',source)]:
   log=out/f'controlled-{name}-{variant}.log';env=dict(os.environ,**extra);rec={'probe':name,'variant':variant,'command':['node','--test','--test-name-pattern='+pattern,file],'env':extra,'started':now(),'source_sha256':hashlib.sha256(pathlib.Path(file if file.startswith('/') else root/file).read_bytes()).hexdigest()}
   with log.open('wb') as stream:rec['exit_code']=subprocess.run(rec['command'],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
   rec['finished']=now();rec['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
   with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
   log.unlink();rows.append(rec);print(json.dumps(rec),flush=True)
 finally:baseline.unlink()
 return rows
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as p:rows=[r for group in p.map(run,cases) for r in group]
(out/'controlled-probes.json').write_text(json.dumps(rows,indent=2))
