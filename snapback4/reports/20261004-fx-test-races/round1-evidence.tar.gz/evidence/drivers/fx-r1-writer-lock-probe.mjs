import { DatabaseSync } from 'node:sqlite';
const original = DatabaseSync.prototype.exec;
const injected = new Set();
DatabaseSync.prototype.exec = function (sql) {
  if (sql === 'BEGIN IMMEDIATE') {
    const file = this.prepare('PRAGMA database_list').all().find(row => row.name === 'main')?.file;
    if (file?.includes('sb4-worker-regression-') && file.endsWith('/.snapback4/store.sqlite') && !injected.has(file)) {
      injected.add(file);
      const holder = new DatabaseSync(file);
      original.call(holder, 'BEGIN IMMEDIATE');
      process.stderr.write('FX_WRITER_LOCK_INJECTED\n');
      setTimeout(() => { original.call(holder, 'ROLLBACK'); holder.close(); }, 150);
    }
  }
  return original.call(this, sql);
};
