import collections,csv,gzip,hashlib,json,pathlib,re,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx');out=pathlib.Path('/tmp/fx-r1-evidence');report=root/'snapback4/reports/20261004-fx-test-races'
def lines(pattern):return [json.loads(s) for p in out.glob(pattern) for s in p.read_text().splitlines()]
main=lines('lane-*.jsonl')
worker='packages/snapback4/test/worker-regressions.test.mjs'
cut=json.loads((out/'worker-cutover-local.json').read_text())
intermediate_server=[r for r in main if r['file']=='packages/snapback4/test/server-e2e.test.mjs']
intermediate_worker=[r for r in main if r['file']==worker and r['started']<=cut['completed']]
intermediate_upload=[r for r in main if r['file']=='packages/snapback4/test/upload-retry.test.mjs']
intermediate=intermediate_server+intermediate_worker+intermediate_upload
linux=[r for r in main if r not in intermediate]+lines('extra-*.jsonl')+lines('server-final.jsonl')+lines('upload-final.jsonl')+[json.loads(p.read_text()) for p in out.glob('linux-worker-regressions-final-*.json')]
all_mini=[json.loads(p.read_text()) for p in (out/'mini').glob('mini-*.json') if not p.name.endswith('.native.json')]
mini_cut=json.loads((out/'mini/worker-cutover.json').read_text())
intermediate_mini=[r for r in all_mini if r['file']==worker and r['started']<=mini_cut['completed']]
mini=[r for r in all_mini if r not in intermediate_mini]
assert len(linux)==2130,len(linux)
assert len(mini)==60,len(mini)
assert all(n==30 for n in collections.Counter(r['file'] for r in linux).values())
assert all(n==30 for n in collections.Counter(r['file'] for r in mini).values())
for rows in [linux,mini]:
 assert len({(r['file'],r['iteration']) for r in rows})==len(rows)
 assert all({r['iteration'] for r in rows if r['file']==f}==set(range(1,31)) for f in {r['file'] for r in rows})
records=[];series=[]
for host,rows in [('eb1000',linux),('Apartment mini',mini)]:
 for r in rows:
  native=r.get('native',{});counts=native.get('counts',{})
  if r['file'].startswith('rust:'):
   text=gzip.open(out/(r['name']+'.log.gz'),'rt').read();match=re.search(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
   assert match,r['name'];counts={'pass':int(match[1]),'fail':int(match[2]),'ignored':int(match[3])}
  records.append({'host':host,'file':r['file'],'iteration':r['iteration'],'command_exit':r['exit_code'],'native_test_exit':native.get('code',r['exit_code']),'reason':native.get('reason',''),'passed':counts.get('pass'),'failed':counts.get('fail'),'skipped_or_ignored':counts.get('skipped',counts.get('ignored',0)),'started':r['started'],'finished':r['finished'],'cpus':r.get('cpus',''),'hog_pid':r.get('hog_pid',''),'log_sha256':r['log_sha256'],'log':('mini/' if host=='Apartment mini' else '')+r['name']+'.log.gz'})
 for file in sorted({r['file'] for r in rows}):
  chosen=[r for r in rows if r['file']==file];series.append({'host':host,'file':file,'iterations':len(chosen),'passed':sum(r['exit_code']==0 for r in chosen),'failed':sum(r['exit_code']!=0 for r in chosen),'failed_iterations':sorted(r['iteration'] for r in chosen if r['exit_code'])})
with (report/'round1-repetitions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]),lineterminator='\n');w.writeheader();w.writerows(sorted(records,key=lambda r:(r['host'],r['file'],r['iteration'])))
full=json.loads((out/'full-suite.json').read_text());text=gzip.open(out/'full-suite.log.gz','rt').read()
assert hashlib.sha256(text.encode()).hexdigest()==full['log_sha256']
rust=[tuple(map(int,m)) for m in re.findall(r'(?m)^-- rust target: .*?test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
clients=[json.loads(m) for m in re.findall(r'(?m)^-- client files: .*?tests (\{.*\})$',text)]
footer=re.search(r'== (\d+) failure\(s\) in (\d+) s',text)
full.update(failed_stages=int(footer[1]),seconds_reported_by_suite=int(footer[2]),rust_passed=sum(r[0] for r in rust),rust_failed=sum(r[1] for r in rust),rust_ignored=sum(r[2] for r in rust),client_summaries=clients,passed_stages=re.findall(r'(?m)^-- ok: (.*)$',text),failed_stage_names=re.findall(r'(?m)^-- FAIL: (.*)$',text))
source={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in json.loads((out/'plan.json').read_text())['source_sha256']}
manifest={'merge_base':'cee23d5619','merged_main':'cb7833c8813b616bbec5a411069b19f33de10a6d','environment':{'node':'24.13.1','rust':'1.97.0','bun_eb1000':'1.3.14','bun_mini':'1.4.2',**json.loads((out/'plan.json').read_text())['environment']},'source_sha256':source,'repetitions':series,'full_suite':full,'intermediate_server_runs':{'count':len(intermediate_server),'failed':[r['name'] for r in intermediate_server if r['exit_code']],'reason':'Replaced for final qualification by server-final.jsonl after moving PID observation before crash invocation.'},'load_helper':{'iterations':len(json.loads((out/'load-helper-runs.json').read_text())),'failed':sum(r['exit_code']!=0 for r in json.loads((out/'load-helper-runs.json').read_text()))},'retained_history_baseline':{'iterations':30,'failed_iterations':[r['iteration'] for r in json.loads((out/'retained-baseline.json').read_text()) if r['exit_code']],'ticket':'issues/20260929-snapback4-retained-history-transient-empty.md'},'assertion_census':json.loads((out/'assertion-census.json').read_text())}
assert all(r['assertionsUnchanged'] and r['testNamesUnchanged'] for r in manifest['assertion_census'])
manifest['intermediate_upload_runs']={'count':len(intermediate_upload),'failed':[r['name'] for r in intermediate_upload if r['exit_code']],'reason':'The full file was repeated 30 times after the complete HTTP 100-continue status-line barrier; main-pool invocations are retained as intermediate.'}
manifest['intermediate_worker_runs']={'eb1000':{'count':len(intermediate_worker),'failed':[r['name'] for r in intermediate_worker if r['exit_code']],'cutover':cut},'Apartment mini':{'count':len(intermediate_mini),'failed':[r['name'] for r in intermediate_mini if r['exit_code']],'cutover':mini_cut},'reason':'Only invocations started after the bounded writer-lock setup change count toward the final 30; earlier and in-flight invocations remain intermediate evidence.'}
for f,h in json.loads((out/'mini/plan.json').read_text())['source_sha256'].items():
 if f==worker:h=mini_cut['sha256']
 assert source['snapback4/'+f]==h
for rows in [linux,mini]:
 for r in rows:
  if r['file']==worker:assert r['started']>(cut if rows is linux else mini_cut)['completed']
manifest['controlled_probes']={name:json.loads((out/name).read_text()) for name in ['controlled-probes.json','split-probes.json','url-partial-port-probe.json','writer-lock-probes.json','continue-probes.json']}

manifest['cleanup']={'eb1000':json.loads((out/'linux-cleanup.json').read_text()),'Apartment mini':json.loads((out/'mini-cleanup.json').read_text())}
manifest['artifact_hashes']=json.loads((out/'full-build-artifacts.json').read_text())
manifest['hosts']={'eb1000':json.loads((out/'eb1000-host.json').read_text()),'Apartment mini':json.loads((out/'mini/host.json').read_text())}
(report/'round1-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'counted_linux_runs':len(linux),'counted_mini_runs':len(mini),'failures':[r for r in series if r['failed']],'full_suite':full},indent=2))
