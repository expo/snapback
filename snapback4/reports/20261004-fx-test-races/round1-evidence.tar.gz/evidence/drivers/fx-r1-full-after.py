import datetime,json,os,pathlib,subprocess,time,gzip,shutil,hashlib
out=pathlib.Path('/tmp/fx-r1-evidence');root='/home/ccheever/sb4-intent/lane-fx/snapback4'
while not all((out/name).exists() for name in ['stress-summary.json','worker-final-summary.json','upload-final-summary.json','server-final-summary.json','extra-rust-summary.json']):time.sleep(5)
scratch=pathlib.Path('/tmp/fx-r1-full-scratch');scratch.mkdir(exist_ok=True)
env=os.environ.copy();env.update(TMPDIR=str(scratch),LIBSQLITE3_FLAGS='-USQLITE_ENABLE_MEMORY_MANAGEMENT',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='8')
rec={'command':['bash','scripts/test.sh'],'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
log=out/'full-suite.log'
with log.open('wb') as stream:rec['exit_code']=subprocess.run(rec['command'],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT).returncode
rec['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();rec['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
(out/'full-suite.json').write_text(json.dumps(rec,indent=2));print(json.dumps(rec),flush=True)
with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
log.unlink()
