import datetime,gzip,hashlib,json,pathlib,subprocess
base=pathlib.Path('/tmp/sb4-fx-r1.9lqr3D');p=base/'evidence'
assert (p/'summary.json').exists() and (p/'worker-final-summary.json').exists()
rows=[json.loads(f.read_text()) for f in p.glob('mini-*.json') if not f.name.endswith('.native.json')]
for r in rows:
 assert hashlib.sha256(gzip.open(p/(r['name']+'.log.gz'),'rb').read()).hexdigest()==r['log_sha256'],r['name']
 assert r['native']['passed'] and r['exit_code']==0,r['name']
 assert r['native']['keeperExit']['cleanupAcknowledged'],r['name']
cut=json.loads((p/'worker-cutover.json').read_text());hashes=json.loads((p/'plan.json').read_text())['source_sha256'];hashes['packages/snapback4/test/worker-regressions.test.mjs']=cut['sha256']
for f,h in hashes.items():assert hashlib.sha256((base/'snapback4'/f).read_bytes()).hexdigest()==h,f
r={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_logs_verified':len(rows),'all_native_exits_zero':True,'all_keeper_cleanup_acknowledged':True,'final_source_sha256':hashes,'scratch_bytes':int(subprocess.check_output(['du','-sk',str(base)],text=True).split()[0])*1024}
(p/'integrity.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
