fn scene_peak_bytes(stdout: &str) -> Option<u64> {
    let peak = stdout.rsplit_once("scene-peak-bytes=")?.1;
    peak.chars().take_while(|c| c.is_ascii_digit()).collect::<String>().parse::<u64>().ok()
}

#[test]
fn scene_peak_parser_requires_the_whole_first_measurement() {
    for prefix in ["", "test many_large_scene_reports ... "] {
        for ending in ["\n", "\r\n"] {
            assert_eq!(scene_peak_bytes(&format!("{prefix}scene-peak-bytes=12345{ending}ok\n")), Some(12345));
        }
        for value in ["12x345", "1e9", "12 345", "+12", "", "18446744073709551616", "\n12345", "12 scene-peak-bytes=1"] {
            assert_eq!(scene_peak_bytes(&format!("{prefix}scene-peak-bytes={value}\n")), None, "{value:?}");
        }
    }
    assert_eq!(scene_peak_bytes("scene-peak-bytes=100000000\nscene-peak-bytes=1\n"), Some(100000000));
    assert_eq!(scene_peak_bytes("scene-peak-bytes=12x345\nscene-peak-bytes=1\n"), None);
}

fn descriptor_address(line: &str) -> Option<&str> {
    line.trim().rsplit_once("FDL_ADDRESS=").map(|(_, address)| address)
}

#[test]
fn descriptor_address_parser_rejects_partial_ports() {
    for prefix in ["", "test descriptor_exhaustion ... "] {
        let parse = |value: &str| descriptor_address(&format!("{prefix}FDL_ADDRESS={value}\n"))
            .and_then(|address| address.parse::<std::net::SocketAddr>().ok());
        assert_eq!(parse("127.0.0.1:12345"), Some("127.0.0.1:12345".parse().unwrap()));
        for port in ["12x345", "1e9", "12 345", "+12", "", "18446744073709551616", "\n12345", "12 FDL_ADDRESS=127.0.0.1:1"] {
            assert_eq!(parse(&format!("127.0.0.1:{port}")), None, "{port:?}");
        }
    }
}

fn crash_record(line: &str) -> Option<&str> {
    line.rfind("NA_").map(|marker| &line[marker..])
}

fn crash_count(record: &str) -> Option<u64> {
    record.split_whitespace().nth(1)?.parse().ok()
}

#[test]
fn acquisition_marker_parser_rejects_partial_counts() {
    for prefix in ["", "test acquisition_crash_worker ... "] {
        for marker in ["NA_DONE", "NA_KILL"] {
            let parse = |value| crash_record(&format!("{prefix}{marker} {value}")).and_then(crash_count);
            assert_eq!(parse("12345"), Some(12345));
            for value in ["12x345", "1e9", "12 345", "+12", "", "18446744073709551616", "\n12345", "12 NA_DONE 1"] {
                assert_eq!(parse(value), None, "{marker}: {value:?}");
            }
        }
    }
}
