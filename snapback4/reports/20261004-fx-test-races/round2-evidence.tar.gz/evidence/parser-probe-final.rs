fn scene_peak_bytes(stdout: &str) -> Option<u64> {
    // Libtest can prepend its banner. Keep the first record, as before: a
    // malformed measurement must not be replaced by a later, smaller value.
    let value = stdout.lines().find_map(|line| line.split_once("scene-peak-bytes=").map(|(_, value)| value))?;
    if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_digit()) { return None; }
    value.parse().ok()
}

#[test]
fn scene_peak_parser_requires_the_whole_first_measurement() {
    for prefix in ["", "test many_large_scene_reports ... "] {
        for ending in ["\n", "\r\n"] {
            assert_eq!(scene_peak_bytes(&format!("{prefix}scene-peak-bytes=12345{ending}ok\n")), Some(12345));
        }
        for value in ["12x345", "1e9", "12 345", "+12", "", "18446744073709551616", "\n12345", "12 scene-peak-bytes=1"] {
            assert_eq!(scene_peak_bytes(&format!("{prefix}scene-peak-bytes={value}\n")), None, "{value:?}");
        }
    }
    assert_eq!(scene_peak_bytes("scene-peak-bytes=100000000\nscene-peak-bytes=1\n"), Some(100000000));
    assert_eq!(scene_peak_bytes("scene-peak-bytes=12x345\nscene-peak-bytes=1\n"), None);
}

fn descriptor_address(line: &str) -> Option<&str> {
    // Accept a libtest banner before the first marker, then parse its whole value.
    line.trim().split_once("FDL_ADDRESS=").map(|(_, address)| address)
}

#[test]
fn descriptor_address_parser_rejects_partial_ports() {
    for prefix in ["", "test descriptor_exhaustion ... "] {
        let parse = |value: &str| descriptor_address(&format!("{prefix}FDL_ADDRESS={value}\n"))
            .and_then(|address| address.parse::<std::net::SocketAddr>().ok());
        assert_eq!(parse("127.0.0.1:12345"), Some("127.0.0.1:12345".parse().unwrap()));
        for port in ["12x345", "1e9", "12 345", "+12", "", "18446744073709551616", "\n12345", "12 FDL_ADDRESS=127.0.0.1:1"] {
            assert_eq!(parse(&format!("127.0.0.1:{port}")), None, "{port:?}");
        }
    }
}

fn crash_record(line: &str) -> Option<&str> {
    // Libtest can prepend its unterminated banner to the first record.
    line.find("NA_").map(|marker| &line[marker..])
}

fn crash_count(record: &str) -> Option<u64> {
    let (_, value) = record.split_once(' ')?;
    if value.is_empty() || !value.bytes().all(|byte| byte.is_ascii_digit()) { return None; }
    value.parse().ok()
}

#[test]
fn acquisition_marker_parser_rejects_partial_counts() {
    for prefix in ["", "test acquisition_crash_worker ... "] {
        for marker in ["NA_DONE", "NA_KILL"] {
            let parse = |value| crash_record(&format!("{prefix}{marker} {value}")).and_then(crash_count);
            assert_eq!(parse("12345"), Some(12345));
            for value in ["12x345", "1e9", "12 345", "+12", "", "18446744073709551616", "\n12345", "12 NA_DONE 1"] {
                assert_eq!(parse(value), None, "{marker}: {value:?}");
            }
        }
    }
}
