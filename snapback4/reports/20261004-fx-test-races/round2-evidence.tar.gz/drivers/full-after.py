import datetime, hashlib, json, os, pathlib, subprocess, time
base=pathlib.Path('/tmp/fx-r2');e=base/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4')
while not (e/'js-summary.json').exists():time.sleep(5)
summary=json.loads((e/'js-summary.json').read_text());assert summary['runs']==1890
plan=json.loads((e/'js-plan.json').read_text())
for path,digest in plan['source_sha256'].items():assert hashlib.sha256((root.parent/path).read_bytes()).hexdigest()==digest,path
for n in range(20):
 receipt=json.loads((e/f'js-lane-{n}-cleanup.json').read_text());assert receipt['reaped']
for key in ['SNAPBACK4_SESSION_SEQUENCES','SNAPBACK4_ONLINE_SEQUENCES','RL_SEEDS','SB4_SEARCH_SEEDS','SNAPBACK4_TEST_SERIAL_CLIENT_FILES']:assert key not in os.environ,key
scratch=base/'full-scratch';scratch.mkdir()
build={'LIBSQLITE3_FLAGS':'-USQLITE_ENABLE_MEMORY_MANAGEMENT','CARGO_PROFILE_DEV_DEBUG':'0','CARGO_PROFILE_TEST_DEBUG':'0','CARGO_INCREMENTAL':'0','CARGO_BUILD_JOBS':'8'}
record={'command':['bash','scripts/test.sh'],'cwd':str(root),'environment':{**build,'TMPDIR':str(scratch)},'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'cli_sha256_before':hashlib.sha256((root/'target/debug/snapback4').read_bytes()).hexdigest()}
(e/'full-suite.json').write_text(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with (e/'full-suite.log').open('wb') as log:
 child=subprocess.Popen(record['command'],cwd=root,env={**os.environ,**record['environment']},stdout=log,stderr=subprocess.STDOUT)
 record['pid']=child.pid;(e/'full-suite.json').write_text(json.dumps(record,indent=2)+'\n')
 record['exit_code']=child.wait()
record.update(finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=time.monotonic()-start,log_sha256=hashlib.sha256((e/'full-suite.log').read_bytes()).hexdigest(),cli_sha256_after=hashlib.sha256((root/'target/debug/snapback4').read_bytes()).hexdigest())
(e/'full-suite.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
