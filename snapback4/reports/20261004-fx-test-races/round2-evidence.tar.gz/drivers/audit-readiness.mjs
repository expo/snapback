import ts from '/home/ccheever/sb4-intent/lane-fx/snapback4/node_modules/typescript/lib/typescript.js';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
const root='snapback4/packages/snapback4/test';
function* files(dir) { for(const e of readdirSync(dir,{withFileTypes:true})) { const p=join(dir,e.name); if(e.isDirectory())yield* files(p); else if(e.name.endsWith('.mjs'))yield p; } }
const rows=[];
for(const path of files(root)) {
 const text=readFileSync(path,'utf8'),file=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
 function visit(n) {
  if(n.kind===ts.SyntaxKind.RegularExpressionLiteral && n.getText(file).includes('http:') && n.getText(file).includes('\\d+')) {
   rows.push({path,line:file.getLineAndCharacterOfPosition(n.getStart(file)).line+1,expression:(ts.isPropertyAccessExpression(n.parent) ? n.parent.parent : n.parent).getText(file)});
  }
  ts.forEachChild(n,visit);
 }
 visit(file);
}
writeFileSync('/tmp/fx-r2/evidence/all-readiness.json',JSON.stringify(rows,null,2)+'\n');
for(const r of rows.filter(r=>!r.expression.includes('readStdout')))console.log(r.path+':'+r.line+' '+r.expression);
