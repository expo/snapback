import ts from '/home/ccheever/sb4-intent/lane-fx/snapback4/node_modules/typescript/lib/typescript.js';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { resolve, dirname, join } from 'node:path';
const root='/home/ccheever/sb4-intent/lane-fx';
const changed=execFileSync('git',['diff','--name-only'],{cwd:root,encoding:'utf8'}).trim().split('\n').filter(p=>p.endsWith('.mjs'));
function inspect(path,text){
 const f=ts.createSourceFile(path,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS),r={assertions:[],names:[],timeouts:[]};
 function visit(n){
  if(ts.isCallExpression(n)){
   const callee=n.expression.getText(f);
   if(callee==='assert'||callee.startsWith('assert.'))r.assertions.push(n.getText(f));
   if(callee==='test'||callee.startsWith('test.'))r.names.push(n.arguments[0]?.getText(f));
  }
  if(ts.isPropertyAssignment(n)&&n.name.getText(f)==='timeout')r.timeouts.push(n.initializer.getText(f));
  ts.forEachChild(n,visit);
 }visit(f);return r;
}
let total=0;const results=[];
for(const p of changed){
 const before=inspect(p,execFileSync('git',['show','0edf7c4690:'+p],{cwd:root,encoding:'utf8'}));
 const after=inspect(p,readFileSync(resolve(root,p),'utf8'));
 if(JSON.stringify(before)!==JSON.stringify(after))throw Error('changed assertions/names/timeouts '+p);
 execFileSync('node',['--check',resolve(root,p)]);
 total+=after.assertions.length;results.push({path:p,assertions:after.assertions.length,test_names:after.names.length,timeouts:after.timeouts.length});
}
const testdir=resolve(root,'snapback4/packages/snapback4/test');
const helpers=new Set(changed.filter(p=>!p.endsWith('.test.mjs')).map(p=>resolve(root,p)));
const dependencies=new Map();
function visits(path,seen=new Set()){
 if(helpers.has(path))return true;if(seen.has(path))return false;seen.add(path);
 let text;try{text=readFileSync(path,'utf8')}catch{return false}
 const imports=[...text.matchAll(/(?:from\s+|import\s*\(\s*)['"](\.[^'"]+)['"]/g)].map(m=>resolve(dirname(path),m[1]));
 return imports.some(p=>visits(p,seen));
}
const affected=readdirSync(testdir).filter(p=>p.endsWith('.test.mjs')).map(p=>join(testdir,p)).filter(p=>changed.includes(p.slice(root.length+1))||visits(p)||p.endsWith('/server-output.test.mjs')).sort();
writeFileSync('/tmp/fx-r2/evidence/js-preservation.json',JSON.stringify({assertions:total,files:results},null,2)+'\n');
writeFileSync('/tmp/fx-r2/evidence/affected-js.json',JSON.stringify(affected.map(p=>p.slice((root+'/snapback4/').length)),null,2)+'\n');
console.log(JSON.stringify({changed_files:changed.length,assertions:total,affected_test_files:affected.length,indirect:affected.filter(p=>!changed.includes(p.slice(root.length+1))).map(p=>p.split('/').pop())},null,2));
