import ts from '/home/ccheever/sb4-intent/lane-fx/snapback4/node_modules/typescript/lib/typescript.js';
import { readFileSync, writeFileSync } from 'node:fs';
import { dirname, relative, resolve } from 'node:path';
const root = '/home/ccheever/sb4-intent/lane-fx/snapback4';
const rows = JSON.parse(readFileSync('/tmp/fx-r2/evidence/readiness-before.json'));
const audit = [];
for (const path of new Set(rows.map(r => r.path))) {
  const absolute = resolve(root, path), source = readFileSync(absolute, 'utf8');
  const file = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const nodes = [];
  const visit = node => { nodes.push(node); ts.forEachChild(node, visit); }; visit(file);
  const edits = [], captures = new Map();
  for (const row of rows.filter(r => r.path === path)) {
    const re = nodes.find(n => n.kind === ts.SyntaxKind.RegularExpressionLiteral && file.getLineAndCharacterOfPosition(n.getStart(file)).line + 1 === row.line && n.getText(file).includes('127'));
    if (!re) throw Error('missing regex '+JSON.stringify(row));
    const call = ts.isCallExpression(re.parent) ? re.parent : re.parent.parent;
    const buffer = call.expression.name.text === 'match' ? call.expression.expression : call.arguments[0];
    if ((path.endsWith('/upload-retry.test.mjs') && row.line === 179) || (path.endsWith('/worker.test.mjs') && row.line === 198)) {
      audit.push({...row, status: 'already stdout only', buffer:buffer.getText(file)}); continue;
    }
    const spawn = nodes.filter(n => ts.isCallExpression(n) && n.expression.getText(file) === 'spawn' && n.getStart(file) < re.getStart(file)).at(-1);
    if (!spawn) throw Error('missing spawn '+path+':'+row.line);
    let child;
    if (ts.isVariableDeclaration(spawn.parent)) child = spawn.parent.name.getText(file);
    else if (ts.isBinaryExpression(spawn.parent)) child = spawn.parent.left.getText(file);
    else throw Error('unhandled spawn '+path+':'+row.line+' '+spawn.parent.getText(file));
    let statement = spawn;
    while (!ts.isVariableStatement(statement) && !ts.isExpressionStatement(statement)) statement = statement.parent;
    if (statement.end > re.getStart(file)) throw Error('readiness inside spawn statement '+path);
    captures.set(statement.end, {child, statement});
    edits.push({start:buffer.getStart(file), end:buffer.end, text:'readStdout()'});
    audit.push({...row, status:'stdout capture', child, spawn_line:file.getLineAndCharacterOfPosition(spawn.getStart(file)).line+1, buffer:buffer.getText(file)});
  }
  if (!edits.length) continue;
  for (const [position,{child,statement}] of captures) {
    const indent = source.slice(source.lastIndexOf('\n',statement.getStart(file))+1, statement.getStart(file)).match(/^\s*/)[0];
    edits.push({start:position,end:position,text:`\n${indent}const readStdout = captureStdout(${child});`});
  }
  let helper = relative(dirname(absolute), resolve(root,'packages/snapback4/test/helpers/server-output.mjs'));
  if (!helper.startsWith('.')) helper='./'+helper;
  edits.push({start:0,end:0,text:`import { captureStdout } from '${helper}';\n`});
  edits.sort((a,b) => b.start-a.start);
  let updated=source;
  for (const edit of edits) updated=updated.slice(0,edit.start)+edit.text+updated.slice(edit.end);
  const parsed=ts.createSourceFile(path,updated,ts.ScriptTarget.Latest,true,ts.ScriptKind.JS);
  if (parsed.parseDiagnostics.length) throw Error('invalid syntax '+path);
  writeFileSync(absolute,updated);
}
writeFileSync('/tmp/fx-r2/evidence/readiness-audit.json',JSON.stringify(audit,null,2)+'\n');
console.log(JSON.stringify({sites:audit.length, changed:audit.filter(a=>a.status==='stdout capture').length, files:new Set(audit.filter(a=>a.status==='stdout capture').map(a=>a.path)).size}));
