import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
registerHooks({load(url,context,next) {
  const loaded=next(url,context);
  if(url.endsWith('/test/client-seams.test.mjs') && process.env.FX_PROBE_REV==='parent')return {...loaded,source:readFileSync('/tmp/fx-r2/evidence/client-seams-parent.mjs','utf8')};
  return loaded;
}});
