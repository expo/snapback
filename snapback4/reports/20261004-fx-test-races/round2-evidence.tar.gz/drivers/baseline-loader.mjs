import { registerHooks } from 'node:module';
import { readFileSync } from 'node:fs';
const sources=JSON.parse(readFileSync('/tmp/fx-r2/evidence/baseline-sources.json','utf8'));
registerHooks({load(url,context,next) {
 const loaded=next(url,context);
 return Object.hasOwn(sources,url)?{...loaded,source:sources[url]}:loaded;
}});
