import { writeFileSync } from 'node:fs';
import { runFile } from '/home/ccheever/sb4-intent/lane-fx/snapback4/scripts/run-client-tests.mjs';
const [label]=process.argv.slice(2);
const result=await runFile('packages/snapback4/test/client-seams.test.mjs', {
  nodeArgs:['--import','/tmp/fx-r2/parent-loader.mjs','--import','/tmp/fx-r2/interleave.mjs','--test-name-pattern=dev logs a measured cut'],
  env:{FX_PROBE_REV:label}
});
writeFileSync('/tmp/fx-r2/evidence/interleave-'+label+'.json',JSON.stringify(result,null,2)+'\n');
process.exitCode=result.passed?0:1;
