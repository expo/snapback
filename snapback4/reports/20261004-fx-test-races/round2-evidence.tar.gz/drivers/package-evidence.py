import collections, datetime, gzip, hashlib, json, pathlib, re, shutil, subprocess, tarfile
b=pathlib.Path('/tmp/fx-r2');e=b/'evidence';root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx');report=root/'snapback4/reports/20261004-fx-test-races'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(name):return json.loads((e/name).read_text())
suite=read('full-suite.json'); assert 'exit_code' in suite
assert (b/'stop-monitor').exists()
subprocess.run(['python3',str(b/'verify-records.py')],check=True)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==read('metadata.json')['parent']
log=(e/'full-suite.log').read_text()
assert sha(log.encode())==suite['log_sha256']
stages=[dict(result=r,name=n,seconds=int(t)) for r,n,t in re.findall(r'^-- (ok|FAIL): (.+) \((\d+) s\)$',log,re.M)]
final=re.search(r'^== (\d+) failure\(s\) in (\d+) s$',log,re.M);assert final
suite['reported_failed_stages']=int(final[1]);suite['reported_seconds']=int(final[2]);suite['stages']=stages
suite['rust_target_summaries']=[dict(target=n,passed=int(p),failed=int(f),ignored=int(i)) for n,p,f,i in re.findall(r'^-- rust target: (.+?) \([^\n]+?\): test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)]
suite['rust_counts']={k:sum(x[k] for x in suite['rust_target_summaries']) for k in ['passed','failed','ignored']}
suite['client_summaries']=[dict(completed=int(a),total=int(t),failed_files=int(f),counts=json.loads(c)) for a,t,f,c in re.findall(r'^-- client files: (\d+)/(\d+); failed (\d+); tests (\{[^\n]+\})$',log,re.M)]
suite['cli_unchanged']=suite['cli_sha256_before']==suite['cli_sha256_after']==read('metadata.json')['cli_sha256']
(e/'full-suite-summary.json').write_text(json.dumps(suite,indent=2)+'\n')
# Preserve exact tested changes, including the two new JavaScript files, alongside hashes.
(e/'tested-tracked.patch').write_bytes(subprocess.check_output(['git','diff','--','snapback4/crates','snapback4/packages/snapback4/test'],cwd=root))
for path in ['snapback4/packages/snapback4/test/helpers/server-output.mjs','snapback4/packages/snapback4/test/server-output.test.mjs']:
 dest=e/'new-sources'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/path,dest)
# No live databases, caches, node_modules or build targets belong in the archive.
drivers=b/'drivers';drivers.mkdir(exist_ok=True)
for p in b.iterdir():
 if p.is_file() and p.suffix in ('.py','.mjs'):shutil.copy2(p,drivers/p.name)
files={str(p.relative_to(b)):p for d in [e,drivers] for p in d.rglob('*') if p.is_file() and p.name!='integrity.json'}
assert not any(p.suffix in ('.sqlite','.wasm') for p in files.values())
index={name:sha(p.read_bytes()) for name,p in files.items()}
(e/'integrity.json').write_text(json.dumps(index,indent=2)+'\n')
files['evidence/integrity.json']=e/'integrity.json'
archive=report/'round2-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=9) as tar:
 for name,p in sorted(files.items()):tar.add(p,arcname=name,recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 assert set(tar.getnames())==set(files)
 for member in tar:
  assert sha(tar.extractfile(member).read())==sha(files[member.name].read_bytes()),member.name
samples=[json.loads(l) for l in (e/'disk.jsonl').read_text().splitlines()]
disk={'samples':len(samples),'peak_sampled_owned_bytes':max(r['owned_total_bytes'] for r in samples),'samples_with_errors':sum(bool(r['errors']) for r in samples),'all_samples_under_40GB':all(r['owned_total_bytes']<40_000_000_000 for r in samples),'all_samples_complete':all(len(r['sizes'])==3 for r in samples),'minimum_free_bytes':min(r['filesystem_free_bytes'] for r in samples)}
assert disk['all_samples_under_40GB']
manifest={**read('metadata.json'),'verification':read('verification-final.json'),'repetitions':read('repetition-summary.json'),'interleaving':read('interleave.json'),'parser_controls':read('parser-controls.json'),'full_suite':suite,'disk':disk,'assertions':read('js-preservation.json'),'rust_assertions':read('rust-preservation.json'),'archive':{'path':archive.name,'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,'files':len(files),'all_archived_bytes_verified':True},'cleanup':{'completed_stress_scratch':'stress-scratch-cleanup.json','completed_control_scratch':'control-scratch-cleanup.json','target_and_final_scratch':'pending'}}
for source,dest in [('repetitions.csv','round2-repetitions.csv'),('readiness.csv','round2-readiness.csv'),('failures.json','round2-failures.json')]:shutil.copy2(e/source,report/dest)
(report/'round2-validation.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'archive':manifest['archive'],'disk':disk,'full_suite':{k:suite[k] for k in ['exit_code','reported_failed_stages','reported_seconds','rust_counts','client_summaries','cli_unchanged']}},indent=2))
