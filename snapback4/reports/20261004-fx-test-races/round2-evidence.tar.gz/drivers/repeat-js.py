import concurrent.futures, datetime, gzip, hashlib, json, os, pathlib, queue, shutil, subprocess, time
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');base=pathlib.Path('/tmp/fx-r2');out=base/'evidence';env=os.environ.copy()
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
files=sorted({p.removeprefix('snapback4/') for p in changed if p.endswith('.test.mjs')})
files+=['packages/snapback4/test/'+p for p in ['read-through.test.mjs','timeline-delivery.test.mjs','asset-avatars.test.mjs','app.test.mjs','routes.test.mjs','server-output.test.mjs']]
files=list(dict.fromkeys(files));jobs=queue.Queue()
for i in range(1,31):
 for f in files:jobs.put((f,i))
plan={'files':files,'iterations':30,'lanes':20,'cpus_per_lane':4,'hogs_per_lane':1,'helper_consumers':files[-6:],'transitive_inventory':'affected-js.json','transitive_validation':'full suite','source_sha256':{p:hashlib.sha256((root/p.removeprefix('snapback4/')).read_bytes()).hexdigest() for p in changed if p.endswith(('.mjs','.rs'))}}
for p in ['packages/snapback4/test/helpers/server-output.mjs','packages/snapback4/test/server-output.test.mjs']:plan['source_sha256']['snapback4/'+p]=hashlib.sha256((root/p).read_bytes()).hexdigest()
(out/'js-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def lane(n):
 lo=4+n*4;cpus=f'{lo}-{lo+3}';scratch=base/f'js-lane-{n}-scratch';scratch.mkdir()
 hog=subprocess.Popen(['taskset','-c',cpus,'python3','-c','while True: pass'])
 expected=set(range(lo,lo+4));end=time.monotonic()+10
 while os.sched_getaffinity(hog.pid)!=expected:
  assert time.monotonic()<end and hog.poll() is None
  time.sleep(.01)
 try:
  with (out/f'js-lane-{n}.jsonl').open('w') as records:
   while True:
    try:f,i=jobs.get_nowait()
    except queue.Empty:break
    name=f'js-{pathlib.Path(f).stem}-{i:02d}';log=out/(name+'.log');receipt=out/(name+'.native.json')
    cmd=['taskset','-c',cpus,'node',str(base/'run-one.mjs'),f,str(receipt)]
    rec={'file':f,'iteration':i,'name':name,'started':now(),'cpus':cpus,'hog_pid':hog.pid,'command':cmd,'hog_affinity':sorted(os.sched_getaffinity(hog.pid))}
    assert hog.poll() is None and set(rec['hog_affinity'])==expected
    with log.open('wb') as stream:
     child=subprocess.Popen(cmd,cwd=root,env={**env,'TMPDIR':str(scratch)},stdout=stream,stderr=subprocess.STDOUT)
     rec['pid']=child.pid;rec['exit_code']=child.wait()
    rec['finished']=now();rec['hog_alive']=hog.poll() is None
    if receipt.exists():rec['native']=json.loads(receipt.read_text());receipt.unlink()
    rec['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
    with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dest:shutil.copyfileobj(src,dest)
    log.unlink();records.write(json.dumps(rec)+'\n');records.flush()
    print(json.dumps({k:rec[k] for k in ['name','exit_code','finished']}),flush=True)
    jobs.task_done()
 finally:
  hog.terminate();hog.wait()
  (out/f'js-lane-{n}-cleanup.json').write_text(json.dumps({'hog_pid':hog.pid,'reaped':True,'exit_code':hog.returncode,'finished':now(),'scratch_remaining':[p.name for p in scratch.iterdir()]}))
with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:list(pool.map(lane,range(20)))
rows=[json.loads(line) for p in out.glob('js-lane-*.jsonl') for line in p.read_text().splitlines()]
(out/'js-summary.json').write_text(json.dumps({'runs':len(rows),'failed':sum(r['exit_code']!=0 for r in rows),'finished':now()},indent=2))
