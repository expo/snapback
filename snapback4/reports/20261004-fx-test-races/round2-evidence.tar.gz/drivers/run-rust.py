import pathlib,json,subprocess
base=pathlib.Path('/tmp/fx-r2');bins=json.loads((base/'evidence/rust-binaries.json').read_text())
for name in ['witness','http_emfile','acquisition_crash']:
 r=subprocess.run(['python3',str(base/'rust-series.py'),name,bins[name],'30'])
 if r.returncode:raise SystemExit(r.returncode)
