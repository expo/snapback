import { writeFileSync } from 'node:fs';
import { runFile } from '/home/ccheever/sb4-intent/lane-fx/snapback4/scripts/run-client-tests.mjs';
const [file,path]=process.argv.slice(2);
const result=await runFile(file,{nodeArgs:['--import','/tmp/fx-r2/baseline-loader.mjs']});
writeFileSync(path,JSON.stringify(result,null,2)+'\n');process.exitCode=result.passed?0:1;
