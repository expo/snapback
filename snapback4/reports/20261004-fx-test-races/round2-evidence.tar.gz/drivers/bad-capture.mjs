import { registerHooks } from 'node:module';
import assert from 'node:assert/strict';
registerHooks({load(url,context,next) {
 const loaded=next(url,context);
 if(!url.endsWith('/helpers/server-output.mjs'))return loaded;
 const source=String(loaded.source), original="child.stdout.on('data', bytes => { stdout += bytes; });";
 assert.equal(source.split(original).length,2);
 return {...loaded,source:source.replace(original,"for (const stream of [child.stdout, child.stderr]) stream.on('data', bytes => { stdout += bytes; });")};
}});
