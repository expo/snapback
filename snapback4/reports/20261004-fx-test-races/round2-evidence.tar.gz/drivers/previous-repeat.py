import concurrent.futures, datetime, gzip, hashlib, json, os, pathlib, queue, shutil, subprocess, sys, time
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4')
out=pathlib.Path('/tmp/fx-r1-evidence'); out.mkdir(exist_ok=True)
env=os.environ.copy();env.update(LIBSQLITE3_FLAGS='-USQLITE_ENABLE_MEMORY_MANAGEMENT',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_INCREMENTAL='0',CARGO_BUILD_JOBS='8')
changed=subprocess.check_output(['git','diff','--name-only'],cwd=root).decode().splitlines()
files=sorted({p.removeprefix('snapback4/') for p in changed if p.endswith('.test.mjs')})
# Exercise each changed shared readiness helper through a complete consumer file.
files+=['packages/snapback4/test/read-through.test.mjs','packages/snapback4/test/timeline-delivery.test.mjs','packages/snapback4/test/asset-avatars.test.mjs','packages/snapback4/test/app.test.mjs']
files=list(dict.fromkeys(files))
jobs=queue.Queue()
# Round robin: all files from one iteration before starting the next.
for i in range(1,31):
 for f in files:jobs.put((f,i))
 jobs.put(('rust:lifecycle',i))
(out/'plan.json').write_text(json.dumps({'files':files+['rust:lifecycle'],'iterations':30,'lanes':20,'cpus_per_lane':4,'hogs_per_lane':1,'environment':{k:env[k] for k in ['LIBSQLITE3_FLAGS','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','CARGO_INCREMENTAL','CARGO_BUILD_JOBS']},'source_sha256':{p:hashlib.sha256((root/p.removeprefix('snapback4/')).read_bytes()).hexdigest() for p in changed}},indent=2))
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def lane(n):
 cpus=f'{n*4}-{n*4+3}';hog=subprocess.Popen(['taskset','-c',cpus,'python3','-c','while True: pass'])
 try:
  with (out/f'lane-{n}.jsonl').open('w') as records:
   while True:
    try:f,i=jobs.get_nowait()
    except queue.Empty:return
    label=f.replace('rust:','').rsplit('/',1)[-1].replace('.test.mjs','')
    name=f'linux-{label}-{i:02d}';log=out/(name+'.log');receipt=out/(name+'.native.json')
    cmd=['cargo','test','-p','snapback4','--test','lifecycle','--','--nocapture'] if f.startswith('rust:') else ['node','/tmp/fx-r1-run-one.mjs',f,str(receipt)]
    rec={'file':f,'iteration':i,'name':name,'started':now(),'cpus':cpus,'hog_pid':hog.pid,'command':['taskset','-c',cpus]+cmd}
    rec['hog_affinity']=pathlib.Path(f'/proc/{hog.pid}/status').read_text().split('Cpus_allowed_list:\t')[1].splitlines()[0]
    with log.open('wb') as stream:
     child=subprocess.Popen(rec['command'],cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
     rec['pid']=child.pid;rec['exit_code']=child.wait()
    rec['finished']=now();rec['hog_alive']=hog.poll() is None
    if receipt.exists():rec['native']=json.loads(receipt.read_text());receipt.unlink()
    rec['log_sha256']=hashlib.sha256(log.read_bytes()).hexdigest()
    with log.open('rb') as source,gzip.open(str(log)+'.gz','wb') as dest:shutil.copyfileobj(source,dest)
    log.unlink();records.write(json.dumps(rec)+'\n');records.flush()
    print(json.dumps({k:rec[k] for k in ['name','exit_code','finished']}),flush=True)
    jobs.task_done()
 finally:
  hog.terminate();hog.wait()
  (out/f'lane-{n}-cleanup.json').write_text(json.dumps({'hog_pid':hog.pid,'reaped':True,'exit_code':hog.returncode,'finished':now()}))
with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:list(pool.map(lane,range(20)))
rows=[json.loads(line) for p in out.glob('lane-*.jsonl') for line in p.read_text().splitlines()]
(out/'stress-summary.json').write_text(json.dumps({'runs':len(rows),'failed':sum(r['exit_code']!=0 for r in rows),'finished':now()},indent=2))
