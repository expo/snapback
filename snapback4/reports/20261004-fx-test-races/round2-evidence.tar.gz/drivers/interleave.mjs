import cp from 'node:child_process';
import { syncBuiltinESMExports } from 'node:module';
const original=cp.spawn;
cp.spawn=function(file,args,...rest){
 const child=original.call(this,file,args,...rest);
 if(!String(file).endsWith('/snapback4') || !['dev','serve'].includes(args?.[0]) || !child.stdout || !child.stderr)return child;
 const outEmit=child.stdout.emit,errEmit=child.stderr.emit;let queue=[],phase='before',injected=false;
 child.stderr.emit=function(event,...args){
  if(event==='data' && phase==='before'){queue.push(args[0]);return true;}
  return errEmit.call(this,event,...args);
 };
 child.stdout.emit=function(event,...args){
  const b=args[0];
  if(event==='data' && !injected && Buffer.isBuffer(b) && /^http:\/\/127\.0\.0\.1:\d+\r?\n$/.test(b.toString())){
   injected=true;phase='gap';const cut=b.indexOf(10),prefix=b.subarray(0,cut),suffix=b.subarray(cut);
   process.stderr.write('REVIEW_INTERLEAVE '+JSON.stringify({prefix:prefix.toString(),queuedStderr:queue.map(b=>b.toString()),delayMs:500})+'\n');
   outEmit.call(this,event,prefix);
   for(const b of queue)errEmit.call(child.stderr,'data',b);queue=[];
   setTimeout(()=>{phase='after';outEmit.call(child.stdout,event,suffix);process.stderr.write('REVIEW_INTERLEAVE_NEWLINE_DELIVERED\n');},500);
   return true;
  }
  return outEmit.call(this,event,...args);
 };
 return child;
};
syncBuiltinESMExports();
