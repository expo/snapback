import collections, csv, datetime, gzip, hashlib, json, pathlib
b=pathlib.Path('/tmp/fx-r2/evidence'); root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx')
def digest(x):return hashlib.sha256(x).hexdigest()
rows=[json.loads(line) for p in sorted(b.glob('js-lane-*.jsonl')) for line in p.read_text().splitlines()]
plan=json.loads((b/'js-plan.json').read_text())
assert len(rows)==1890
assert len({(r['file'],r['iteration']) for r in rows})==1890
assert set(r['file'] for r in rows)==set(plan['files'])
for f in plan['files']:assert sorted(r['iteration'] for r in rows if r['file']==f)==list(range(1,31))
for r in rows:
 assert digest(gzip.decompress((b/(r['name']+'.log.gz')).read_bytes()))==r['log_sha256'],r['name']
 n=r['native']; assert r['exit_code']==n['code'] and n['signal'] is None
 assert n['passed']==(r['exit_code']==0)
 assert n['keeperExit']['cleanupAcknowledged'] and n['keeperExit']['signal']=='SIGKILL'
 start,end=map(int,r['cpus'].split('-')); assert end-start==3
 assert n['affinity']==r['cpus'] and r['hog_affinity']==list(range(start,end+1)) and r['hog_alive']
for i in range(20):assert json.loads((b/f'js-lane-{i}-cleanup.json').read_text())['reaped']
for p,d in plan['source_sha256'].items():assert digest((root/p).read_bytes())==d,p
rust=[]
for name,count in [('witness',32),('http_emfile',10),('acquisition_crash',3)]:
 d=json.loads((b/(name+'.json')).read_text()); assert d['hog_reaped_at'] and d['hog_exit_code']==-15
 assert digest(pathlib.Path(d['binary']).read_bytes())==d['binary_sha256']
 assert [r['iteration'] for r in d['runs']]==list(range(1,31))
 for r in d['runs']:
  raw=(b/r['log']).read_bytes();assert digest(raw)==r['log_sha256']
  assert f'test result: ok. {count} passed; 0 failed;'.encode() in raw
  assert r['exit_code']==0 and r['affinity']==r['hog_affinity']==[0] and r['hog_alive'] and r['hog_alive_at_finish']
  if name=='acquisition_crash': assert raw.count(b'12 process kills')==4
  if name=='witness': assert b'scene scan peak: one=' in raw
  rust.append(dict(target=name,**r))
watch=json.loads((b/'watch-baseline.json').read_text());assert len(watch['runs'])==30
assert sum(r['exit_code']!=0 for r in watch['runs'])==1
for r in watch['runs']:
 assert digest(gzip.decompress((b/f"baseline-read-existence-{r['iteration']:02}.log.gz").read_bytes()))==r['log_sha256']
 assert r['exit_code']==r['native']['code'] and r['native']['keeperExit']['cleanupAcknowledged']
 assert r['hog_alive'] and r['hog_affinity']==[88,89,90,91]
for path,d in json.loads((b/'parser-controls.json').read_text())['source_sha256'].items():assert digest((root/'snapback4'/path).read_bytes())==d
summary={'verified_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'js_invocations':len(rows),'js_pass':sum(r['exit_code']==0 for r in rows),'js_fail':sum(r['exit_code']!=0 for r in rows),'rust_invocations':len(rust),'rust_pass':len(rust),'baseline_read_existence_pass':29,'baseline_read_existence_fail':1,'all_log_hashes_match':True,'native_exits_and_affinity_match':True,'keeper_cleanup_acknowledged':True,'hog_cleanup_recorded':True,'source_hashes_unchanged':True,'rust_binary_hashes_unchanged':True}
(b/'verification-final.json').write_text(json.dumps(summary,indent=2)+'\n')
with (b/'repetitions.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['kind','file','iteration','started','finished','cpus','exit_code','tests','pass','fail','log','log_sha256']);w.writeheader()
 for r in sorted(rows,key=lambda r:(r['file'],r['iteration'])):
  w.writerow({**{k:r[k] for k in ['file','iteration','started','finished','cpus','exit_code','log_sha256']},'kind':'javascript','log':r['name']+'.log.gz',**{k:r['native']['counts'][k] for k in ['tests','pass','fail']}})
 for r in rust:w.writerow({'kind':'rust','file':r['target'],'iteration':r['iteration'],'started':r['started_at'],'finished':r['finished_at'],'cpus':'0','exit_code':r['exit_code'],'tests':{'witness':32,'http_emfile':10,'acquisition_crash':3}[r['target']],'pass':{'witness':32,'http_emfile':10,'acquisition_crash':3}[r['target']],'fail':0,'log':r['log'],'log_sha256':r['log_sha256']})
print(json.dumps(summary))
