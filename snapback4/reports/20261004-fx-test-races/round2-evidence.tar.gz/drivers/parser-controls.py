import pathlib,re,subprocess,json,hashlib,datetime
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx/snapback4');base=pathlib.Path('/tmp/fx-r2');e=base/'evidence'
groups=[('crates/snapback4/tests/witness.rs',['scene_peak_bytes','scene_peak_parser_requires_the_whole_first_measurement']),('crates/snapback4/tests/http_emfile.rs',['descriptor_address','descriptor_address_parser_rejects_partial_ports']),('crates/snapback4-device/tests/acquisition_crash.rs',['crash_record','crash_count','acquisition_marker_parser_rejects_partial_counts'])]
parts=[];hashes={}
for path,names in groups:
 source=(root/path).read_text();hashes[path]=hashlib.sha256(source.encode()).hexdigest()
 for name in names:
  block=re.search(r'(?m)^fn '+name+r'\([^\n]*\{\n.*?^\}',source,re.S).group()
  if 'parser_' in name:block='#[test]\n'+block
  parts.append(block)
fixed='\n\n'.join(parts)+'\n'
old=fixed
replacements={
'scene_peak_bytes':'''fn scene_peak_bytes(stdout: &str) -> Option<u64> {
    let peak = stdout.rsplit_once("scene-peak-bytes=")?.1;
    peak.chars().take_while(|c| c.is_ascii_digit()).collect::<String>().parse::<u64>().ok()
}''',
'descriptor_address':'''fn descriptor_address(line: &str) -> Option<&str> {
    line.trim().rsplit_once("FDL_ADDRESS=").map(|(_, address)| address)
}''',
'crash_record':'''fn crash_record(line: &str) -> Option<&str> {
    line.rfind("NA_").map(|marker| &line[marker..])
}''',
'crash_count':'''fn crash_count(record: &str) -> Option<u64> {
    record.split_whitespace().nth(1)?.parse().ok()
}'''}
for name,replacement in replacements.items():old=re.sub(r'(?m)^fn '+name+r'\([^\n]*\{\n.*?^\}',lambda _:replacement,old,count=1,flags=re.S)
rows=[]
for mode,source in [('parent',old),('final',fixed)]:
 path=e/f'parser-probe-{mode}.rs';path.write_text(source);binary=base/f'parser-probe-{mode}'
 build=['rustc','--edition=2024','--test',str(path),'-o',str(binary)];subprocess.run(build,check=True,cwd=root)
 command=[str(binary),'--nocapture']
 with (e/f'parser-control-{mode}.log').open('wb') as out:r=subprocess.run(command,stdout=out,stderr=subprocess.STDOUT)
 rows.append({'mode':mode,'build':build,'command':command,'exit_code':r.returncode,'source_sha256':hashlib.sha256(source.encode()).hexdigest()})
 binary.unlink()
(e/'parser-controls.json').write_text(json.dumps({'source_sha256':hashes,'parent_adaptation':'Original parsing expressions adapted to Option-returning helper signatures; panicking parse failure becomes None for malformed-value probes. Final helper and test functions are extracted verbatim.','runs':rows},indent=2)+'\n')
assert [r['exit_code'] for r in rows]==[101,0];print(json.dumps(rows,indent=2))
