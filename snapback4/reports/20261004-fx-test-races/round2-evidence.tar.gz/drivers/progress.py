import datetime,json,pathlib,re
b=pathlib.Path('/tmp/fx-r2/evidence');s=(b/'full-suite.log').read_text();active={}
for p in pathlib.Path('/tmp/fx-r2/full-scratch').glob('snapback4-test.*/*.log'):
 t=p.read_text(errors='replace')
 if not p.with_suffix('.status').exists():
  active[p.stem]={'last_line':t.splitlines()[-1] if t.splitlines() else '', 'rust_targets_completed':len(re.findall(r'^-- rust target:',t,re.M)), 'failed_rust_targets':re.findall(r'^-- FAIL rust target: (.+)$',t,re.M),'client_files_completed':len(re.findall(r'^-- client file (?:ok|FAIL):',t,re.M)),'client_files_failed':re.findall(r'^-- client file FAIL: (.+)$',t,re.M)}
r=json.loads((b/'disk.jsonl').read_text().splitlines()[-1]);print(json.dumps({'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'full_suite':json.loads((b/'full-suite.json').read_text()),'last_suite_line':s.splitlines()[-1], 'active':active,'owned_GB':round(r['owned_total_bytes']/1e9,2)},indent=2))
