import datetime,hashlib,json,pathlib,shutil,subprocess
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx');b=pathlib.Path('/tmp/fx-r2');report=root/'snapback4/reports/20261004-fx-test-races';mp=report/'round2-validation.json';m=json.loads(mp.read_text());s=m['full_suite']
assert s['exit_code']==0 and s['reported_failed_stages']==0
assert s['rust_counts']=={'passed':4975,'failed':0,'ignored':33}
clients=next(r for r in s['client_summaries'] if r['total']==312);models=next(r for r in s['client_summaries'] if r['total']==2)
assert clients['counts']['pass']==6206 and clients['counts']['fail']==0 and clients['counts']['skipped']==11
assert models['counts']['pass']==79 and models['counts']['fail']==0
assert s['cli_unchanged']
archive=report/m['archive']['path'];assert hashlib.sha256(archive.read_bytes()).hexdigest()==m['archive']['sha256']
assert m['archive']['all_archived_bytes_verified']
text=(b/'round2-report.md').read_text()
full=f"The full eb1000 suite (`bash scripts/test.sh`) **passed, exit 0, zero failed\nstages in {s['reported_seconds']:,} seconds**: 4,975 Rust passes, 33 existing ignores,\nworkspace doctests, all 312 client files (6,206 passes, 11 existing skips),\nall 79 serial model tests at full 5,000/3,000 histories, nine fixture tests,\nand every build/budget/typecheck stage. Its CLI hash matches the repetition\nbinary. This pass does not erase or classify the stress failures."
text=text.replace('FULL_SUITE_RESULT',full)
peak=m['disk']['peak_sampled_owned_bytes']/1e9;errors=m['disk']['samples_with_errors']
disk=f"Observed build, dependency and\nscratch allocations peaked at {peak:.2f} GB, below 40 GB. The sampler continued\nthrough {errors} transient `du` errors as live files disappeared; their stderr is\nretained. Completed stress/control scratch was removed promptly. The final\nlocal target and remaining owned scratch were deleted after archive verification."
text=text.replace('DISK_AND_CLEANUP_RESULT',disk)
assert 'RESULT' not in text
journal=f"\n## 2026-10-04 — FX round 2: independent readiness and whole marker values\n\nFixed Astra's two P2s on `0edf7c4690`: all 79 combined-stream readiness reads\nnow parse stdout alone while retaining complete-line guards; witness, HTTP\ndescriptor and acquisition markers consume whole values and select the first\nrecord. Existing assertions, names and bounds remain unchanged. Interleaving\nand malformed-value controls fail the parent and pass the repairs. All three\nRust binaries pass 30/30 under a CPU-0 hog. The 63 JavaScript file series\nran 30 times each under four-CPU contention: 1,874 passes and 16 retained\nfailures (four known R5, two parent-reproduced condition timeouts, ten\nunclassified). The full suite passes in {s['reported_seconds']:,} s at full counts. Astra's\nseparate MQ count failure remains unclassified and was not pursued. The\n[Round 2 report](./reports/20261004-fx-test-races/REPORT.md#round-2--keep-readiness-streams-separate-and-parse-whole-measurements)\nrecords every result, source/receipt checks, controls and cleanup. Observed\nallocations peaked at {peak:.2f} GB; owned target/scratch removed after verified\narchival. One local commit, with no push or remote-host work.\n"
assert '\n## Round 2 —' not in (report/'REPORT.md').read_text()
assert '\n## 2026-10-04 — FX round 2:' not in (root/'snapback4/JOURNAL.md').read_text()
# The suite and monitor are finished, and all retained evidence is verified.
assert (b/'stop-monitor').exists()
assert 'exit_code' in json.loads((b/'evidence/full-suite.json').read_text())
target=root/'snapback4/target'
owned={str(p):int(subprocess.check_output(['du','-sb',str(p)],text=True).split()[0]) for p in [target,b]}
shutil.rmtree(target);shutil.rmtree(b)
assert not target.exists() and not b.exists()
m['cleanup']['target_and_final_scratch']={'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'removed_bytes_before_deletion':owned,'removed_paths_absent':True,'existing_node_modules_retained':True}
mp.write_text(json.dumps(m,indent=2)+'\n')
with (report/'REPORT.md').open('a') as f:f.write(text)
with (root/'snapback4/JOURNAL.md').open('a') as f:f.write(journal)
print(json.dumps({'cleanup':m['cleanup']['target_and_final_scratch'],'report_appended':True,'journal_appended':True},indent=2))
