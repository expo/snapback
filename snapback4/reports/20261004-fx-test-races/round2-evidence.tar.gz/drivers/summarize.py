import pathlib,json,gzip,collections,re,hashlib,datetime
b=pathlib.Path('/tmp/fx-r2/evidence');rows=[json.loads(l) for p in b.glob('js-lane-*.jsonl') for l in p.read_text().splitlines()]
by=collections.defaultdict(list)
for r in rows:by[r['file']].append(r)
failures=[]
for r in rows:
 if not r['exit_code']:continue
 s=gzip.open(b/(r['name']+'.log.gz'),'rt').read();lines=s.splitlines();blocks=[]
 for i,line in enumerate(lines):
  if re.match(r'^\s*not ok \d+',line):
   end=i+1
   while end<len(lines) and lines[end].strip()!='...':end+=1
   blocks.append('\n'.join(lines[max(0,i-1):end+1]))
 failures.append({'name':r['name'],'file':r['file'],'iteration':r['iteration'],'native':r.get('native'),'log':r['name']+'.log.gz','log_sha256':r['log_sha256'],'failure_blocks':blocks,'classification':('known R5 empty-delivery defect: issues/20260929-snapback4-retained-history-transient-empty.md' if 'assert.ok(!deliveries.includes(0))' in s else 'same condition-timeout signature reproduced on parent (1/30 whole-file controls); root cause open' if r['file'].endswith('read-existence-integration.test.mjs') and 'wasm: same-key row arrival and delete replace absent/present existence' in s and 'TEST_HANG: condition' in s else 'unclassified stress failure; no exclusions')})
summary={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'invocations':len(rows),'passes':sum(r['exit_code']==0 for r in rows),'failures':len(failures),'files':[{'file':f,'invocations':len(rs),'passes':sum(r['exit_code']==0 for r in rs),'failures':sum(r['exit_code']!=0 for r in rs),'iterations':sorted(r['iteration'] for r in rs)} for f,rs in sorted(by.items())]}
(b/'repetition-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(b/'failures.json').write_text(json.dumps(failures,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ['at','invocations','passes','failures']}))
