import pathlib,json,subprocess,os,time,datetime,gzip,shutil,hashlib
base=pathlib.Path('/tmp/fx-r2');e=base/'evidence';root='/home/ccheever/sb4-intent/lane-fx/snapback4';scratch=base/'watch-baseline-scratch';scratch.mkdir()
hog=subprocess.Popen(['taskset','-c','88-91','python3','-c','while True: pass'])
while os.sched_getaffinity(hog.pid)!=set(range(88,92)):time.sleep(.01)
rows=[]
try:
 for i in range(1,31):
  label=f'baseline-read-existence-{i:02d}';file='packages/snapback4/test/read-existence-integration.test.mjs'
  command=['taskset','-c','88-91','node',str(base/'baseline-one.mjs'),file,str(e/(label+'.json'))]
  row={'iteration':i,'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'hog_pid':hog.pid,'hog_affinity':sorted(os.sched_getaffinity(hog.pid))};log=e/(label+'.log')
  with log.open('wb') as stream:r=subprocess.run(command,cwd=root,env={**os.environ,'TMPDIR':str(scratch)},stdout=stream,stderr=subprocess.STDOUT)
  row.update(exit_code=r.returncode,finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),native=json.loads((e/(label+'.json')).read_text()),log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),hog_alive=hog.poll() is None)
  (e/(label+'.json')).unlink()
  with log.open('rb') as src,gzip.open(str(log)+'.gz','wb') as dst:shutil.copyfileobj(src,dst)
  log.unlink();rows.append(row)
  (e/'watch-baseline.json').write_text(json.dumps({'parent':'0edf7c4690','runs':rows},indent=2)+'\n');print(label,r.returncode,flush=True)
finally:
 hog.terminate();hog.wait()
 (e/'watch-baseline.json').write_text(json.dumps({'parent':'0edf7c4690','runs':rows,'hog_pid':hog.pid,'hog_reaped':True,'hog_exit_code':hog.returncode},indent=2)+'\n')
