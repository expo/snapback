import { writeFileSync, readFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const {runFile} = await import(pathToFileURL(resolve('scripts/run-client-tests.mjs')));
const [file, receipt] = process.argv.slice(2);
const affinity = readFileSync('/proc/self/status','utf8').match(/^Cpus_allowed_list:\s*(.*)$/m)?.[1];
const result = await runFile(file);
writeFileSync(receipt, JSON.stringify({...result, affinity}));
process.exitCode = result.passed ? 0 : 1;
