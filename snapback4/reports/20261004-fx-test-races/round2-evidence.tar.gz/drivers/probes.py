import concurrent.futures, pathlib, os, subprocess, json, datetime
base=pathlib.Path('/tmp/fx-r2');scratch=base/'probe-scratch';scratch.mkdir();root='/home/ccheever/sb4-intent/lane-fx/snapback4'
def run(label):
 cmd=['taskset','-c','88-91','node',str(base/'run-interleave.mjs'),label]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (base/f'evidence/interleave-{label}.log').open('wb') as log:r=subprocess.run(cmd,cwd=root,env={**os.environ,'TMPDIR':str(scratch)},stdout=log,stderr=subprocess.STDOUT)
 return {'label':label,'started':start,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':cmd,'exit_code':r.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(run,['parent','final']))
(base/'evidence/interleave.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2))
assert [r['exit_code'] for r in rows]==[1,0]
