import subprocess,pathlib,json,os,time,datetime,hashlib
root=pathlib.Path('/home/ccheever/sb4-intent/lane-fx');base=pathlib.Path('/tmp/fx-r2');e=base/'evidence'
paths=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
sources={}
for p in paths:
 if '/test/' in p and p.endswith('.mjs'):sources[(root/p).as_uri()]=subprocess.check_output(['git','show','0edf7c4690:'+p],cwd=root,text=True)
(e/'baseline-sources.json').write_text(json.dumps(sources)+'\n')
scratch=base/'baseline-scratch';scratch.mkdir();rows=[]
hog=subprocess.Popen(['taskset','-c','88-91','python3','-c','while True: pass'])
while os.sched_getaffinity(hog.pid)!=set(range(88,92)):time.sleep(.01)
try:
 for name in ['server-e2e','sync-overflow','admit-before-identity']:
  file='packages/snapback4/test/'+name+'.test.mjs';label='baseline-'+name
  command=['taskset','-c','88-91','node',str(base/'baseline-one.mjs'),file,str(e/(label+'.json'))]
  started=datetime.datetime.now(datetime.timezone.utc).isoformat()
  with (e/(label+'.log')).open('wb') as log:r=subprocess.run(command,cwd=root/'snapback4',env={**os.environ,'TMPDIR':str(scratch)},stdout=log,stderr=subprocess.STDOUT)
  rows.append({'file':file,'command':command,'started':started,'finished':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':r.returncode,'hog_alive':hog.poll() is None,'hog_affinity':sorted(os.sched_getaffinity(hog.pid))})
  print(label,r.returncode,flush=True)
finally:
 hog.terminate();hog.wait()
 (e/'baseline-summary.json').write_text(json.dumps({'parent':'0edf7c4690','runs':rows,'hog_pid':hog.pid,'hog_exit_code':hog.returncode,'hog_reaped':True},indent=2)+'\n')
