import { writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
const {runFile} = await import(pathToFileURL(resolve('scripts/run-client-tests.mjs')));
const [file, receipt] = process.argv.slice(2);
const result = await runFile(file);
writeFileSync(receipt, JSON.stringify(result));
process.exitCode = result.passed ? 0 : 1;
