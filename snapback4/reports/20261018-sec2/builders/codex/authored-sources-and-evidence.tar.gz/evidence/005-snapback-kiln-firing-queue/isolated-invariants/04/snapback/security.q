invariant pieces always .photo != null
