invariant firings.update only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
