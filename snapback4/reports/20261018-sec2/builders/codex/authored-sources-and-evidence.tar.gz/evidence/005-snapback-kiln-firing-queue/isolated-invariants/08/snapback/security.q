invariant memberships.update only exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'
