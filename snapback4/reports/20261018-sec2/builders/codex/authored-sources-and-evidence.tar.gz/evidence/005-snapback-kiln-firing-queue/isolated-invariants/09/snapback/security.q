invariant pieces.status write only .status != 'cancelled' or .owner = viewer or exists memberships[viewer, role = 'manager']
