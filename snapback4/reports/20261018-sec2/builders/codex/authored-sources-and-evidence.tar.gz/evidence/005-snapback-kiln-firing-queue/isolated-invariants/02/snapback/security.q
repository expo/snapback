invariant pieces.insert only .owner = viewer and exists memberships[viewer]
