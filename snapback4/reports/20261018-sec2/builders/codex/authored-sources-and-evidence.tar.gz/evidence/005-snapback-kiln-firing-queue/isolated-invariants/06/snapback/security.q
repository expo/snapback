invariant firings.insert only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
