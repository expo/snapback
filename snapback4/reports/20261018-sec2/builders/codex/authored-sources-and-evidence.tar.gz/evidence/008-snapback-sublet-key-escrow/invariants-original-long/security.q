-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant listings.read only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant listings.insert only .leaseholder = viewer and exists people[viewer, role = 'leaseholder']
invariant bookings.read only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant bookings.insert only .subtenant = viewer and exists people[viewer, role = 'subtenant', vetted = true]
invariant idDocuments.read only .owner = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant idDocuments.insert only .owner = viewer and .booking.subtenant = viewer
invariant idDocuments always .document != null
invariant bookings always .releasedAt = null or (.leaseSignedAt != null and .subSignedAt != null and .proofUploaded = true)
invariant bookings.cancelled write only .cancelled = false or (.leaseSignedAt = null and .subSignedAt = null) or exists people[viewer, role = 'manager']
