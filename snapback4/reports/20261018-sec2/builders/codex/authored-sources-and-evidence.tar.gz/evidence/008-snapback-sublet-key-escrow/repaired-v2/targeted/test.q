use personas alice, bob, staff, boss, other, outsider
use identity password

-- Office-managed roster. Password signup alone grants no application role.
table people:
  principal: principal
  name: text 2..80
  role: enum('leaseholder', 'subtenant', 'staff', 'manager')
  vetted: bool default false
  unique principal
  immutable principal, name, role
  read <- .principal = viewer or viewer = 'service:provision' or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
  insert <- viewer = 'service:provision'
  update <- exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
  online only

-- A matched room is visible only to its leaseholder, assigned subtenant and office.
table listings:
  leaseholder: principal
  subtenant: principal ?
  room: text 2..120
  startsAt: time
  endsAt: time
  createdAt: time default now
  immutable leaseholder, room, startsAt, endsAt, createdAt
  read <- .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
  insert <- .leaseholder = viewer and exists people[viewer, role = 'leaseholder']
  update <- exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
  cap 100 by leaseholder
  online only

table bookings:
  listing: listings
  leaseholder: principal
  subtenant: principal
  room: text 2..120
  startsAt: time
  endsAt: time
  leaseSignedAt: time ?
  subSignedAt: time ?
  proofUploaded: bool default false
  releasedAt: time ?
  returnedAt: time ?
  overdue: bool default false
  cancelled: bool default false
  createdAt: time default now
  unique listing else ALREADY_BOOKED
  immutable listing, leaseholder, subtenant, room, startsAt, endsAt, createdAt
  read <- .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
  insert <- .subtenant = viewer and exists people[viewer, role = 'subtenant', vetted = true] and .leaseholder = .listing.leaseholder and .listing.subtenant = viewer and .releasedAt = null
  update <- (.leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']) and (.releasedAt = null or (.leaseSignedAt != null and .subSignedAt != null and .proofUploaded = true))
  online only

-- ID handles and bytes never enter a listing or ordinary booking response.
table idDocuments:
  booking: bookings
  owner: principal
  document: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')
  uploadedAt: time default now
  unique booking
  immutable booking, owner, document, uploadedAt
  read <- .owner = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
  insert <- .owner = viewer and .booking.subtenant = viewer
  online only

shape bookingCard = { *, flagged: .overdue or (.releasedAt != null and .returnedAt = null and day(now) > day(.endsAt)) }

query me():
  return people[viewer]

query roster(c: cursor ?):
  require exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager'] else OFFICE_ONLY
  return people first 100 by .id after c

query myListings(c: cursor ?):
  return listings last 100 by .createdAt after c

query listingDetail(listing: listings):
  return listings[listing]

query myBookings(c: cursor ?):
  return bookings last 100 by .createdAt after c bookingCard

query bookingDetail(booking: bookings):
  return bookings[booking] bookingCard

query idDocument(booking: bookings):
  return idDocuments[booking = booking]

-- Provisioning is a private operator capability, never an end-user role selector.
mutation provision(who: principal, name: text 2..80, role: enum('leaseholder', 'subtenant', 'staff', 'manager')):
  require viewer = 'service:provision' else PROVISION_ONLY
  require not exists people[who] else ALREADY_ENROLLED
  return insert people { principal: who, name, role }

mutation vetSubtenant(who: principal):
  require exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager'] else OFFICE_ONLY
  p = people[who] ! else NOT_FOUND
  require p.role = 'subtenant' else NOT_SUBTENANT
  require not p.vetted else ALREADY_VETTED
  update people[p.id] { vetted: true }

mutation createListing(room: text 2..120, startsAt: time, endsAt: time):
  require exists people[viewer, role = 'leaseholder'] else LEASEHOLDER_ONLY
  require startsAt % 1d = 0 and endsAt % 1d = 0 else UTC_DATES_ONLY
  require startsAt >= day(now) * 1d else START_IN_PAST
  require endsAt >= startsAt and endsAt <= startsAt + 180d else BAD_DATE_RANGE
  return insert listings { leaseholder: viewer, room, startsAt, endsAt }

mutation assignSubtenant(listing: listings, who: principal):
  require exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager'] else OFFICE_ONLY
  l = listings[listing] ! else NOT_FOUND
  p = people[who] ! else NOT_FOUND
  require p.role = 'subtenant' else NOT_SUBTENANT
  require p.vetted else NOT_VETTED
  require not exists bookings[listing = listing] else ALREADY_BOOKED
  require day(now) <= day(l.startsAt) else WINDOW_CLOSED
  update listings[listing] { subtenant: who }

mutation book(listing: listings):
  require exists people[viewer, role = 'subtenant', vetted = true] else VETTED_SUBTENANT_ONLY
  l = listings[listing] ! else NOT_FOUND
  require l.subtenant = viewer else NOT_ASSIGNED
  require day(now) <= day(l.startsAt) else WINDOW_CLOSED
  require not exists bookings[listing = listing] else ALREADY_BOOKED
  return insert bookings { listing, leaseholder: l.leaseholder, subtenant: viewer, room: l.room, startsAt: l.startsAt, endsAt: l.endsAt }

mutation signBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.leaseholder = viewer or b.subtenant = viewer else PARTY_ONLY
  require not b.cancelled else CANCELLED
  require day(now) <= day(b.startsAt) else WINDOW_CLOSED
  if b.leaseholder = viewer:
    require b.leaseSignedAt = null else ALREADY_SIGNED
    update bookings[booking] { leaseSignedAt: now }
  else:
    require b.subSignedAt = null else ALREADY_SIGNED
    update bookings[booking] { subSignedAt: now }

mutation uploadId(booking: bookings, document: file <=5000000 ('application/pdf', 'image/jpeg', 'image/png')):
  b = bookings[booking] ! else NOT_FOUND
  require b.subtenant = viewer else SUBTENANT_ONLY
  require not b.cancelled else CANCELLED
  require day(now) <= day(b.startsAt) else WINDOW_CLOSED
  require not b.proofUploaded else ID_ALREADY_UPLOADED
  insert idDocuments { booking, owner: viewer, document }
  update bookings[booking] { proofUploaded: true }
  return null

mutation releaseKey(booking: bookings):
  require exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager'] else OFFICE_ONLY
  b = bookings[booking] ! else NOT_FOUND
  require not b.cancelled else CANCELLED
  require day(now) = day(b.startsAt) else START_DATE_ONLY
  require b.leaseSignedAt != null and b.subSignedAt != null else SIGNATURES_REQUIRED
  require b.proofUploaded else ID_REQUIRED
  require b.releasedAt = null else ALREADY_RELEASED
  update bookings[booking] { releasedAt: now }

mutation returnKey(booking: bookings):
  require exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager'] else OFFICE_ONLY
  b = bookings[booking] ! else NOT_FOUND
  require b.releasedAt != null else NOT_RELEASED
  require b.returnedAt = null else ALREADY_RETURNED
  update bookings[booking] { returnedAt: now, overdue: b.overdue or day(now) > day(b.endsAt) }

mutation cancelBooking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.leaseholder = viewer or b.subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager'] else NOT_ALLOWED
  require not b.cancelled else CANCELLED
  require (b.leaseSignedAt = null and b.subSignedAt = null) or exists people[viewer, role = 'manager'] else MANAGER_ONLY
  update bookings[booking] { cancelled: true }

job flagOverdue():
  for b in bookings:
    if b.releasedAt != null and b.returnedAt = null and day(now) > day(b.endsAt) and not b.overdue:
      update bookings[b.id] { overdue: true }
schedule checkReturns every 1m: flagOverdue
