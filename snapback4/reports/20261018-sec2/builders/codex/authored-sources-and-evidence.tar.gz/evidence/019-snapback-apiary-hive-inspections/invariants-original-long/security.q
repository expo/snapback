-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant hives.read only .landOwner = viewer or (exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .route]) or exists roles[viewer, role = 'lead']
invariant inspections.read only exists hives[.hive, landOwner = viewer] or (exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .hive.route]) or exists roles[viewer, role = 'lead']
invariant inspections.insert only .inspector = viewer and exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .hive.route]
invariant inspections always .photo != null
invariant alerts.read only .owner = viewer or exists roles[viewer, role = 'lead']
invariant alerts.insert only .inspector = viewer and exists roles[viewer, role = 'inspector']
invariant hives.status write only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
invariant listings always exists hives[.hive, status = 'healthy']
invariant listings.insert only .owner = viewer and exists hives[.hive, landOwner = viewer, status = 'healthy']
