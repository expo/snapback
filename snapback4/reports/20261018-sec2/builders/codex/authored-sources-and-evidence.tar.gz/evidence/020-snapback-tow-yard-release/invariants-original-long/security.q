-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant vehicles.read only .owner = viewer or exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager'] or (.onHold = true and exists roster[principal = viewer, role = 'liaison'])
invariant vehicles.insert only exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']
invariant vehicles always .photos != null
invariant vehicles always .status != 'released' or .onHold = false
invariant claims.read only .claimant = viewer or exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']
invariant claims.insert only .claimant = viewer
invariant claims.update only exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']
invariant claims always .proof != null
invariant waivers.insert only exists roster[principal = viewer, role = 'manager']
invariant vehicles.waived write only .waived = 0 or exists roster[principal = viewer, role = 'manager']
