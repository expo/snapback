"""Independent installed-document-only SPEC review; never edits application inputs."""
from pathlib import Path
import json

R = Path('/tmp/sec2-builders/codex')
# One entry per authored declaration, in source order. These are semantic review
# notes, not proof verdicts; the candidate's complete verdicts are kept separately.
NOTES = {
'005': [
 'Own-piece privacy with tech/manager queue access; staff access to historical pieces is an explicit interpretation.',
 'Submission belongs to the current member; firing-count limits are a separate workflow obligation.',
 'Row authority allows owners and staff; it does not state the started-firing edit lock.',
 'Required submission photo matches the SPEC; non-null does not establish actual asset bytes.',
 'Load rows preserve piece-owner/staff privacy.',
 'Creating a firing is kiln staff authority, with manager administrative access assumed.',
 'Firing stage changes belong to kiln staff; valid stage ordering is separate.',
 'Manager membership-limit authority is covered; service:ops is an explicit trusted provisioning assumption, not an engine exemption.',
 'Cancellation predicate covers both old and next status images. It is stronger than only authorizing entry into cancelled; retained without weakening.'
],
'007': [
 'Own horse records plus the assigned farrier and manager match the SPEC; assignment lifetime is not specified.',
 'Visit privacy follows the horse audience; inherited parent authority requires a separate proof reduction.',
 'Photo privacy follows visit then horse; this multi-hop expression remains explicitly unsupported.',
 'Billing audience is only the horse manager, as required.',
 'Billing writer is only that horse manager; this is a compatible administrative policy.',
 'Billing updates constrain both images and remain manager-only.',
 'Visit author must be the booked farrier; this does not prove every visit eventually has a photo.',
 'Photo writer is the visit farrier; uploads are a separate step.',
 'Every photo row requires a photo; it does not require every visit to have a photo row.',
 'Quote privacy follows horse records.',
 'Only the horse owner answers a quote; quote expiry and answer-once are separate guards.',
 'Reminder content is private to its recipient; two-day timing and delivery are separate.'
],
'008': [
 'Listings are private to matched parties and office staff, matching the existing assigned-subtenant interpretation.',
 'Listings must be created by their leaseholder.',
 'Bookings are private to their two parties and office.',
 'Booking requires a current vetted subtenant; dates and assignment consistency are separate.',
 'ID documents are restricted to the uploader and office, excluding the other party.',
 'Only the booking subtenant supplies their own ID.',
 'An ID row requires a document; proofUploaded-to-document correspondence is separate.',
 'Release timestamp writes require signatures and proof in both old and next images. Exact start-date and actual ID-ledger evidence remain separate.',
 'Signed cancellation is manager-only. Both-image semantics additionally constrain edits away from a signed cancelled state; no such public operation is modeled.'
],
'009': [
 'Own-part tracks need a live release unless director. Concert-to-release date correspondence is not stated by this predicate alone.',
 'Only the director uploads tracks.',
 'Track rows require audio; media bytes require separate evidence.',
 'Progress audience is self, matching section leader, or director.',
 'Self-progress insert must agree with the current member and part.',
 'Self/director progress updates; section realignment and reference consistency are separate.',
 'Only director changes roster part; table-wide authority is broader than just moving a singer but compatible.',
 'Attendance audience is section leader or director; historical audience after part moves is unspecified.',
 'Only the matching section leader marks attendance.',
 'Attendance updates belong to matching leader or director in both images.',
 'Concert creation is director-only.',
 'Release creation is director-only; this does not prove release dates equal the parent concert dates.'
],
'010': [
 'Owner/committee/chair booking payload audience. Committee access to other holders identities is an administrative assumption beyond the explicit calendar privacy sentence.',
 'Only a member creates their own booking; weekly count and two-hour duration are separate.',
 'Shared calendar is member-visible; absence of identity depends on the stored/projected fields, not this predicate.',
 'Only committee/chair changes drought policy.',
 'Override audit is chair-only, including photo handles.',
 'Override audit author must be the current committee/chair caller.',
 'Override records require a meter photo.',
 'Over-strong for SPEC transition intent: both-image semantics ban a holder changing an already-override row away from override. Current changed replay legitimately refutes this literal declaration; it is not proof of an unauthorized override operation.'
],
'019': [
 'Owner, current assigned inspector, or lead can read a hive; current role is checked alongside the durable route.',
 'Inspection privacy follows owner/current assigned inspector/lead. The live parent hop is unsupported, not a false runtime refusal.',
 'Inspection author is the current inspector on the hive route.',
 'Inspection row requires a frame photo.',
 'Mite alert audience is owner or lead.',
 'Alert author must be a current inspector; chosen owner/hive correspondence and threshold completeness are separate.',
 'Only lead or explicit service:ops can write hive status. The service exception is a trust assumption beyond the literal only-lead SPEC; service seats are ordinary viewers in the checker.',
 'Honey listing visibility requires a healthy hive. This faithfully states hiding, without demanding physical row deletion in every imported snapshot.',
 'Listing creation requires its actual healthy-hive landowner.'
],
'020': [
 'Owner/staff see vehicles; current liaison sees only held vehicles. Manager broad access is an existing administrative interpretation.',
 'Only clerk/manager creates intake rows.',
 'Non-null intake photo list is weaker than nonempty; the separate 1..4 type bound enforces the SPEC cardinality.',
 'Over-strong for SPEC transition intent: both-image semantics prohibit a status edit away from released on a held historical row. Current released-to-impounded replay is real, but it does not enter released while held.',
 'Claims are visible to their claimant and yard staff.',
 'Claim writer must be its claimant; ownership and impounded status are separate operation checks.',
 'Only yard staff decides claims.',
 'Claim proof is required.',
 'Only manager creates fee waivers.',
 'Waived amount writes require manager whenever either image is nonzero; this is stronger than authorizing only newly waived fees but preserves the intended restriction.'
],
'021': [
 'Judge sees own scores; other judges and own-team students/coaches need round closure; director sees all. Coach pre-close timing and judge panel scope remain unspecified/model gaps.',
 'Score writer must be its judge and currently a judge; panel/round-open checks are separate.',
 'Only that current judge updates a score; closed-round lock is not expressed here.',
 'Team creation belongs to director.',
 'Bracket/disqualification changes belong to director.',
 'Team deletion is director-only; this is an additional compatible policy.',
 'Round changes belong to director; valid timing/stages are separate.',
 'Brief audience is own team, coach, judges, or director.',
 'Brief creation requires own-team membership; the deadline is not encoded.',
 'Brief edits require own-team membership; caller-chosen tournament deadline association is not encoded.',
 'Director enrollment requires existing director or explicit trusted service:ops; group creation alone is insufficient.',
 'Tournament creation requires existing director or explicit trusted service:ops; global authority is not granted to arbitrary signup.'
],
'045': [
 'Borrower/librarian/manager loan audience. This does not model a parent-to-student family relationship required for shared family access.',
 'Checkout is librarian/manager authority.',
 'Loan updates are librarian/manager authority; return/season transitions need separate assertions.',
 'Checkout photo is required.',
 'Correct conditional return-photo intent is preserved. The trusted seed refutation is a real failure of the all-snapshot integrity assertion, not a demonstrated ordinary checkin path.',
 'Only manager reads deposit records, including family borrowers.',
 'Only manager records deposits.',
 'Only manager edits deposits.',
 'Repair notes are readable only by librarian/manager; luthier blind writing remains allowed.',
 'Luthier writes their own repair note.',
 'Only manager writes either an old or next written-off status. This also restricts undoing write-off, beyond only entering it.'
],
'048': [
 'Current engineers see own shift rounds; manager sees completed rounds only; chief sees all.',
 'Current engineers see gauge history; contractors need current role and specific equipment assignment.',
 'Reading privacy matches live history for engineers and assigned contractors, excluding manager.',
 'Reading writer must be current engineer on the recorded shift; round-to-shift correspondence is separate.',
 'Every reading requires a gauge photo.',
 'Gauge creation belongs to chief.',
 'Gauge changes including limits belong to chief; table-wide intent is broader than only limits but compatible.',
 'Gauge deletion is chief-only; this is an additional compatible policy.',
 'Only chief reads alerts.',
 'Only chief acknowledges/updates alerts; completeness and immediate timing are separate.'
]
}
HOLES = {
'005': ['No invariant expresses the started-firing edit lock or valid firing stage sequence.', 'Member firing-count limits and 21-day donation flag timing need operation/clock qualification.', 'Public queue length is explicitly allowed by SPEC, but the payload read invariant has no explicit aggregate declassification; keep the unproved observer visible.'],
'007': ['Multi-hop photo privacy is unsupported; parent authority/read-through remains unproved.', 'Visit-to-photo completeness and automatic two-day reminders are not established by row non-null and recipient assertions.', 'Recurring cycle timing, media bytes, and ongoing farrier assignment lifetime remain unqualified.'],
'008': ['Exact start-date release, both signatures, and verified ID/document correspondence need a transition/sequence reduction; the timestamp declaration alone is incomplete.', 'Overdue end-date flagging and actual ID upload/download bytes remain unqualified.', 'Both-image cancellation/release predicates also restrict historical recovery edits beyond the transition wording; no public recovery operation is modeled.'],
'009': ['Tracks release existence does not itself prove parent-concert release date and concert+7d correspondence; temporal directives and workflow need separate qualification.', 'Attendance live delivery and media bytes are not proven by row intent.', 'After a singer changes part, historical attendance audience is a product assumption; retained tests check the implemented realignment.'],
'010': ['Old-and-next status intent is stronger than only authorizing override; the legitimate literal refutation has no public mutation reachability proof.', 'Two-hour turns, weekly limit, drought integer rounding, oldest-booked retention, every-override audit completeness, and week races are workflow obligations.', 'Committee access to private booking payloads is an administrative interpretation; opaque booking references in the calendar are assumed not to identify holders.'],
'019': ['Parent-hop inspection privacy is unsupported; raw public-listing hive probes need observer reduction.', 'Lead-only status intent explicitly includes service:ops, a trust assumption that must not be described as an implicit checker exemption.', 'Inspection threshold/alert recipient correspondence, seasonal 14-day crossing, and real media bytes are not fully qualified.'],
'020': ['Both-image held-release predicate is stronger than blocking entry to released; current synthetic replay changes away from released.', 'Actual 30-day auction, fee accrual boundaries, verified ownership/claim correspondence, and photo bytes remain unqualified.', 'Manager lifting holds is an existing exception; the SPEC explicitly names liaison authority and does not define manager delegation.'],
'021': ['Brief deadline is selected by a caller-supplied tournament; teams/briefs lack a tournament link. The security declarations do not prove the intended brief-to-deadline association.', 'Judge panel membership is not modeled, so assigned-panel live scoring cannot be qualified.', 'Closed-round score lock, brief time crossing, coach pre-close timing, and live delivery remain separate workflow scope.'],
'045': ['Returned-loan photo integrity is refuted at trusted seed ingress; ordinary checkin now requires a return photo. Preserve both facts.', 'Parent/student/family linkage is absent; the retained parent-with-no-link case cannot qualify legitimate parent access or establish a false refusal.', 'Season-end and 14-day follow-up are query-derived without a fully qualified clock/delivery history; media bytes remain unqualified.'],
'048': ['Completing every gauge uses an operation count guard outside row proof; the retained additional workflow pair tests one missing gauge.', 'Immediate missed-round/out-of-range alerts are not fully qualified by the hourly sweep/two-hour window; no exact numeric deadline was invented.', 'Round/gauge/shift consistency, real media bytes, and live compliance delivery need separate qualification.']
}

def main():
    review = {}
    for app in sorted(R.glob('0*-snapback-*')):
        notes = NOTES[app.name[:3]]
        declarations = [(i, l) for i,l in enumerate((app/'snapback/security.q').read_text().splitlines(),1) if l.startswith('invariant ')]
        assert len(notes) == len(declarations), app.name
        review[app.name] = dict(spec=(app/'SPEC.md').read_text().strip(), holes=HOLES[app.name[:3]], declarations=[dict(line=i, declaration=l, independent_spec_review=n) for (i,l),n in zip(declarations,notes)])
    (R/'final-evidence/spec-review.json').write_text(json.dumps(review,indent=2)+'\n')
    print('Independent SPEC review entries:',sum(len(x['declarations']) for x in review.values()))

if __name__ == '__main__': main()
