import subprocess, pathlib, json, hashlib, sys, time, concurrent.futures, os
ROOT = pathlib.Path('/tmp/sec2-builders/codex')
CLI = str(ROOT / 'node_modules/.bin/snapback4')
APP_ROOT=pathlib.Path(os.environ.get('SNAPBACK_APP_ROOT',str(ROOT)))
phase = sys.argv[1]
def measure(app):
    records=[]
    out = ROOT / 'evidence' / app.name / phase
    out.mkdir(parents=True, exist_ok=True)
    for src in (app/'snapback').glob('*.q'):
        (out/src.name).write_bytes(src.read_bytes())
    (out/'SPEC.md').write_bytes((app/'SPEC.md').read_bytes())
    for args in [['check', '--json'], ['test']]:
        command = ['timeout', '600s', CLI, *args]
        started = time.monotonic()
        p = subprocess.run(command, cwd=app, capture_output=True)
        name = args[0]
        (out/f'{name}.stdout').write_bytes(p.stdout)
        (out/f'{name}.stderr').write_bytes(p.stderr)
        rec = dict(app=app.name, phase=phase, cwd=str(app), command=command,
                   exit_code=p.returncode, seconds=round(time.monotonic()-started,3),
                   stdout=str((out/f'{name}.stdout').relative_to(ROOT)),
                   stderr=str((out/f'{name}.stderr').relative_to(ROOT)))
        records.append(rec)
        print(json.dumps(rec), flush=True)
    (out/'commands.json').write_text(json.dumps(records, indent=2)+'\n')
    return records
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    apps=[a for a in sorted(APP_ROOT.glob('[0-9][0-9][0-9]-snapback-*')) if len(sys.argv)<3 or a.name[:3] in sys.argv[2:]]
    records=[r for group in pool.map(measure, apps) for r in group]
(ROOT/'evidence'/f'{phase}-commands.json').write_text(json.dumps(records, indent=2)+'\n')
