from pathlib import Path
import subprocess, time, json, sys, os, signal, hashlib
R=Path('/tmp/sec2-builders/codex'); app=next(R.glob(sys.argv[1]+'-snapback-*')); phase=sys.argv[2]; verb=sys.argv[3]
out=R/'final-evidence'/app.name/phase; out.mkdir(parents=True,exist_ok=True)
if verb in ('check','test','audit'):
 args=[verb]+(['--json'] if verb in ('check','audit') else [])
else:
 args=json.loads(sys.argv[4])
for p in (app/'snapback').glob('*.q'): (out/p.name).write_bytes(p.read_bytes())
(out/'SPEC.md').write_bytes((app/'SPEC.md').read_bytes())
command=['timeout','--signal=TERM','--kill-after=3s','175s',str(R/'node_modules/.bin/snapback4'),*args]
start=time.monotonic()
with (out/(verb+'.stdout')).open('wb') as so, (out/(verb+'.stderr')).open('wb') as se:
 p=subprocess.run(command,cwd=app,stdout=so,stderr=se)
rec=dict(app=app.name,phase=phase,command=command,cwd=str(app),exit_code=p.returncode,seconds=round(time.monotonic()-start,3),stdout=str((out/(verb+'.stdout')).relative_to(R)),stderr=str((out/(verb+'.stderr')).relative_to(R)),source_hashes={str(s.relative_to(R)):hashlib.sha256(s.read_bytes()).hexdigest() for s in (app/'snapback').glob('*.q')})
(out/(verb+'.command.json')).write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True)
