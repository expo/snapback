"""Documented fixture format only. No server, credentials, SDK internals or imports."""
from pathlib import Path
import json, subprocess, sys, time, re
ROOT=Path('/tmp/sec2-builders/codex')
phase=sys.argv[1]
cast=['alice','bob','staff','boss','other','outsider']
def row(id,**kw): return dict(id=id,**kw)
def case(as_,op,args=None,**kw): return dict(as_=as_,op=op,args=args or {},**kw)
def role(id,role,**kw): return row(id,principal='dev:'+id,role=role,**kw)
def img(id): return dict(id=id,type='image/png',bytes=68,width=1,height=1,duration=None)
def file(id): return dict(id=id,type='audio/wav',bytes=100,name='track.wav')
datasets={}
datasets['005']=({'memberships':[role('alice','member',name='Alice'),role('bob','member',name='Bobby'),role('staff','tech',name='Tech'),role('boss','manager',name='Boss')]},[
 case('alice','changeLimit',{'who':'dev:bob','firingLimit':10},expect='MANAGER_ONLY'),
 case('staff','createFiring',{'kiln':'Amber','cone':'6'},save='firing'),
 case('alice','firingBoard',expect='STAFF_ONLY'),
 case('boss','changeLimit',{'who':'dev:alice','firingLimit':8}),
 case('alice','me',match={'firingLimit':8}),
 case('bob','membership',{'who':'dev:alice'},data=None),
 case('alice','queueLength',data=0),
])
datasets['007']=({'roles':[role('alice','owner',name='Alice'),role('bob','owner',name='Bobby'),role('staff','farrier',name='Farrier'),role('boss','manager',name='Boss')],
 'horses':[row('h1',name='Ash',manager='dev:boss',owner='dev:alice',farrier='dev:staff',nextAt='now+2d'),row('h2',name='Birch',manager='dev:boss',owner='dev:bob',farrier='dev:staff',nextAt='now+3d')],
 'billing':[row('bill1',horse='h1',details='private account')],
 'quotes':[row('q1',horse='h1',description='Corrective shoeing',cents=5000,validUntil='now+1d')]},[
 case('alice','myHorses',count=1),case('bob','horse',{'horse':'h1'},data=None),case('staff','myHorses',count=2),
 case('staff','billingFor',{'horse':'h1'},expect='NOT_MANAGER'),case('boss','billingFor',{'horse':'h1'},match={'details':'private account'}),
 case('bob','answerQuote',{'quote':'q1','approve':True},expect='NOT_FOUND'),case('alice','answerQuote',{'quote':'q1','approve':True}),
 case('alice','horseQuotes',{'horse':'h1'},match=[{'status':'approved'}]),case('boss','dueSoon',count=2),
])
datasets['008']=({'people':[role('alice','leaseholder',name='Alice'),role('bob','subtenant',name='Bobby',vetted=True),role('staff','staff',name='Office'),role('boss','manager',name='Manager')],
 'listings':[row('l1',leaseholder='dev:alice',subtenant='dev:bob',room='Room 1',startsAt='now+1d',endsAt='now+7d')],
 'bookings':[row('b1',listing='l1',leaseholder='dev:alice',subtenant='dev:bob',room='Room 1',startsAt='now+1d',endsAt='now+7d',leaseSignedAt='now-1h')]},[
 case('alice','myBookings',count=1),case('outsider','bookingDetail',{'booking':'b1'},data=None),
 case('alice','cancelBooking',{'booking':'b1'},expect='MANAGER_ONLY'),case('staff','cancelBooking',{'booking':'b1'},expect='MANAGER_ONLY'),
 case('bob','signBooking',{'booking':'b1'}),case('staff','releaseKey',{'booking':'b1'},expect='START_DATE_ONLY'),
 case('alice','idDocument',{'booking':'b1'},data=None),case('boss','cancelBooking',{'booking':'b1'}),
 case('alice','bookingDetail',{'booking':'b1'},match={'cancelled':True}),
])
datasets['009']=({'roster':[role('alice','singer',name='Alice',part='Alto'),role('bob','singer',name='Bobby',part='Tenor'),role('staff','leader',name='Leader',part='Alto'),role('boss','director',name='Director',part='Bass')],
 'concerts':[row('concert',title='Spring',releaseAt='now-1d',concertAt='now+1d')],
 'pieces':[row('piece',concert='concert',title='Song')],
 'progress':[row('p1',member='alice',singer='dev:alice',part='Alto',piece='piece',title='Song',learned=True),row('p2',member='bob',singer='dev:bob',part='Tenor',piece='piece',title='Song',learned=False)],
 'rehearsals':[row('rehearsal',title='Practice',startsAt='now-1h',endsAt='now+1h')]},[
 case('alice','progress',count=1),case('staff','progress',count=1),case('boss','progress',count=2),
 case('staff','markAttendance',{'rehearsal':'rehearsal','member':'alice','present':True}),
 case('staff','markAttendance',{'rehearsal':'rehearsal','member':'bob','present':True},expect='NOT_FOUND'),
 case('boss','attendance',{'rehearsal':'rehearsal'},count=1),case('alice','moveSinger',{'member':'bob','part':'Alto'},expect='FORBIDDEN'),
 case('boss','moveSinger',{'member':'bob','part':'Alto'}),case('staff','progress',count=2),
])
slot=((int(time.time()*1000)//7200000)+2)*7200000
datasets['010']=({'members':[role('alice','holder',plot='A1'),role('bob','holder',plot='B2'),role('staff','committee',plot='C3'),role('boss','chair',plot='D4')], 'policy':[row('policy',key='water',drought=False)]},[
 case('alice','book',{'startsAt':slot},save='first'),case('alice','book',{'startsAt':slot+7200000},save='second'),case('alice','book',{'startsAt':slot+14400000},save='third'),
 case('alice','book',{'startsAt':slot+21600000},expect='WEEKLY_LIMIT'),case('bob','booking',{'booking':'$first'},expect='NOT_FOUND'),
 case('alice','declareDrought',{'drought':True},expect='NOT_COMMITTEE'),case('staff','declareDrought',{'drought':True}),
 case('alice','mine',count=3,matchSet=[{'status':'booked','startsAt':slot},{'status':'drought','startsAt':slot+7200000},{'status':'drought','startsAt':slot+14400000}]),
 case('alice','calendar',{'from':slot,'until':slot+28800000},count=1),case('alice','audit',expect='NOT_CHAIR'),
])
datasets['019']=({'roles':[role('alice','landowner'),role('staff','inspector'),role('boss','lead')],
 'routes':[row('route',inspector='dev:staff',route='North')],
 'hives':[row('h1',name='Hive',landOwner='dev:alice',route='North',seasonStart='now-30d',seasonEnd='now+30d')]},[
 case('staff','hives',count=1),case('alice','hives',count=1),case('bob','hive',{'hive':'h1'},data=None),
 case('staff','recordInspection',{'hive':'h1','queenStatus':'laying','miteCount':4},expect='E_INPUT',label='photo must be supplied'),
 case('boss','grantRole',{'who':'dev:staff','role':'landowner'}),
 case('staff','hive',{'hive':'h1'},data=None,label='demoted inspector loses route access'),
 case('staff','setHiveStatus',{'hive':'h1','status':'quarantined'},expect='NOT_LEAD'),
 case('boss','setHiveStatus',{'hive':'h1','status':'quarantined'}),
 case('alice','addListing',{'hive':'h1','title':'Honey','priceCents':500},expect='HIVE_HIDDEN'),case('bob','listings',count=0),
])
datasets['020']=({'roster':[role('alice','owner',handle='alice'),role('bob','owner',handle='bobby'),role('staff','clerk',handle='clerk'),role('boss','manager',handle='manager'),role('other','liaison',handle='liaison')],
 'vehicles':[row('v1',plate='ABC',make='Ford',model='Car',color='Blue',towedFrom='Main street',towedAt='now-2d',owner='dev:alice',photos=[img('intake1')],onHold=True),row('v2',plate='DEF',make='Ford',model='Van',color='Red',towedFrom='Side street',towedAt='now-2d',owner='dev:bob',photos=[img('intake2')])]},[
 case('alice','myVehicles',count=1),case('bob','vehicleDetail',{'vehicle':'v1'},expect='NOT_FOUND'),case('other','holdVehicles',count=1),
 case('other','vehicleDetail',{'vehicle':'v2'},expect='NOT_FOUND'),case('staff','waiveFees',{'vehicle':'v1','amount':1,'reason':'Test'},expect='NOT_MANAGER'),
 case('staff','releaseVehicle',{'vehicle':'v1'},expect='ON_HOLD'),
 case('staff','intake',{'plate':'NEW','make':'Ford','model':'Car','color':'Blue','towedFrom':'Main street','ownerHandle':'alice'},expect='E_INPUT',label='intake requires photos'),
 case('other','liftHold',{'vehicle':'v1'}),case('other','holdVehicles',count=0),
])
datasets['021']=({'tournaments':[row('t1',code='main',name='Tournament',briefDeadline='now+1d',director='dev:boss')],
 'directors':[row('director',tournament='t1',principal='dev:boss')],
 'judges':[row('judge1',principal='dev:staff'),row('judge2',principal='dev:other')],
 'coaches':[row('coach',principal='dev:bob')],
 'teams':[row('team1',name='Team A',coach='dev:bob',bracket='A'),row('team2',name='Team B',bracket='B')],
 'members':[row('member',team='team1',student='dev:alice')],
 'rounds':[row('r1',name='Final',status='open',bracket='A')],
 'roundTeams':[row('entry',round='r1',team='team1')],
 'scores':[row('s1',round='r1',team='team1',judge='dev:staff',argument=7,presence=8,comment='Private until close')]},[
 case('alice','studentScores',{'team':'team1'},count=0),case('other','judgeScores',{'team':'team1'},count=0),case('staff','judgeScores',{'team':'team1'},count=1),
 case('boss','closeRound',{'round':'r1'}),case('alice','studentScores',{'team':'team1'},count=1),
 case('staff','updateScore',{'score':'s1','argument':9,'presence':9,'comment':'Late'},expect='ROUND_CLOSED'),
 case('outsider','createTournament',{'code':'evil','name':'Rogue','briefDeadline':'now+1d'},expect='NOT_DIRECTOR',label='creation must not grant global authority'),
 case('outsider','setBracket',{'team':'team1','bracket':'Hijacked'},expect='NOT_DIRECTOR',label='outsider cannot rewrite existing bracket'),
])
datasets['045']=({'roles':[role('alice','student'),role('bob','parent'),role('staff','librarian'),role('boss','manager'),role('other','luthier')],
 'instruments':[row('i1',kind='Violin',serial='V1'),row('i2',kind='Cello',serial='C1',status='loaned')],
 'seasons':[row('season',name='Spring',endsAt='now+30d')],
 'loans':[row('loan',instrument='i2',borrower='dev:alice',season='season',seasonEndsAt='now+30d',checkoutPhoto=img('checkout'))],
 'repairNotes':[row('note',instrument='i1',author='dev:other',note='Bridge repaired')],
 'deposits':[row('deposit',family='dev:alice',season='season',amount=5000)]},[
 case('alice','myLoans',count=1),case('bob','myLoans',count=0),case('staff','notesFor',{'instrument':'i1'},count=1),
 case('other','notesFor',{'instrument':'i1'},count=0,label='luthier cannot read repair notes'),
 case('alice','myDeposits',count=0),case('boss','depositRecords',count=1),
 case('staff','checkout',{'instrument':'i1','borrower':'dev:alice','season':'season'},expect='E_INPUT',label='checkout photo required'),
 case('staff','checkin',{'loan':'loan'},expect='E_INPUT',label='return photo required'),
 case('staff','writeOff',{'instrument':'i1'},expect='NOT_MANAGER'),
])
datasets['048']=({'roles':[role('alice','engineer'),role('staff','contractor'),role('boss','chief'),role('other','manager')],
 'shifts':[row('shift',label='Morning',startsAt='now-2h',endsAt='now+2h')],
 'shiftMembers':[row('member',shift='shift',engineer='dev:alice')],
 'gauges':[row('g1',name='Pressure',location='Boiler',minPressure=10,maxPressure=100,minTemp=0,maxTemp=80)],
 'assignments':[row('assignment',gauge='g1',contractor='dev:staff')],
 'rounds':[row('r1',shift='shift',scheduledAt='now-1h',status='completed',completedAt='now-30m'),row('r2',shift='shift',scheduledAt='now',status='scheduled')],
 'readings':[row('reading',round='r1',gauge='g1',shift='shift',engineer='dev:alice',pressure=50,temp=50,photo=img('gauge'))]},[
 case('other','compliance',{'from':'now-2h','to':'now+2h'},count=1,label='manager gets completed rounds'),
 case('other','gaugeHistory',{'gaugeId':'g1'},expect='NOT_FOUND'),case('staff','gaugeHistory',{'gaugeId':'g1'},count=1),
 case('alice','setLimits',{'gaugeId':'g1','minPressure':5,'maxPressure':100,'minTemp':0,'maxTemp':90},expect='NOT_CHIEF'),
 case('boss','assignRole',{'who':'dev:staff','role':'manager'}),case('staff','gaugeHistory',{'gaugeId':'g1'},expect='NOT_FOUND',label='demoted contractor loses assignment'),
 case('boss','assignRole',{'who':'dev:alice','role':'manager'}),case('alice','myShifts',count=0,label='demoted engineer loses shift'),
])
# Extend the cases with media metadata fixtures as documented by guide assets.
# No bytes are available behind these handles; asset download remains unqualified.
tables,cases=datasets['005']
tables['firings']=[row('hot',kiln='Birch',cone='6',stage='firing',startedAt='now-1h')]
tables['pieces']=[row('p1',owner='dev:alice',title='Cup',photo=img('cup'),clay='stoneware',cone='6'),row('p2',owner='dev:bob',title='Bowl',photo=img('bowl'),clay='stoneware',cone='6'),row('p3',owner='dev:alice',title='Hot cup',photo=img('hotcup'),clay='stoneware',cone='6',status='firing',firing='hot',kiln='Birch')]
cases[-1]['data']=2
cases.extend([case('alice','myPieces',count=2),case('bob','piece',{'piece':'p1'},data=None),case('alice','editPiece',{'piece':'p3','title':'Changed','clay':'stoneware','cone':'6'},expect='PIECE_LOCKED'),case('staff','cancelPiece',{'piece':'p2'},expect='MANAGER_ONLY'),case('boss','cancelPiece',{'piece':'p2'}),case('boss','studioQueue',count=3)])
tables,cases=datasets['008']
tables['idDocuments']=[row('doc',booking='b1',owner='dev:bob',document=dict(id='proof',type='application/pdf',bytes=100,name='id.pdf'))]
tables['bookings'][0]['proofUploaded']=True
cases.extend([case('bob','idDocument',{'booking':'b1'},match={'owner':'dev:bob'}),case('staff','idDocument',{'booking':'b1'},match={'owner':'dev:bob'})])
tables,cases=datasets['009']
tables['roster'].append(role('other','singer',name='Other singer',part='Tenor'))
tables['pieces'].extend([row('futurePiece',concert='concert',title='Future song'),row('oldPiece',concert='concert',title='Old song')])
tables['tracks']=[row('trackNow',piece='piece',title='Song',part='Alto',audio=file('audioNow')),row('trackFuture',piece='futurePiece',title='Future',part='Alto',audio=file('audioFuture')),row('trackOld',piece='oldPiece',title='Old',part='Alto',audio=file('audioOld'))]
tables['releases']=[row('relNow',track='trackNow',part='Alto',opensAt='now-1d',endsAt='now+2d'),row('relFuture',track='trackFuture',part='Alto',opensAt='now+1d',endsAt='now+2d'),row('relOld',track='trackOld',part='Alto',opensAt='now-2d',endsAt='now-1d')]
cases.extend([case('alice','tracks',count=1),case('alice','track',{'track':'trackFuture'},data=None),case('alice','track',{'track':'trackOld'},data=None),case('other','track',{'track':'trackNow'},data=None),case('boss','tracks',count=3)])
# A property manager may read compliance shift metadata, so the earlier myShifts
# expectation was broader than SPEC. Exercise the explicitly shift-only reader.
datasets['048'][1][-1]=case('alice','shiftRounds',{'shift':'shift'},expect='NOT_SHIFT_MEMBER',label='demoted engineer loses shift round access')
all_records=[]
for prefix,(tables,cases) in datasets.items():
 if len(sys.argv)>2 and prefix not in sys.argv[2:]: continue
 app=next(ROOT.glob(prefix+'-snapback-*')); out=ROOT/'evidence'/app.name/phase/'targeted';out.mkdir(parents=True,exist_ok=True)
 source=out.parent/'schema.q'
 if not source.exists():
  source=ROOT/'evidence'/app.name/('original' if phase.startswith('original') else 'repaired')/'schema.q'
 src=source.read_text()
 # Fixtures alone name development personas; production copies keep their auth.
 src=re.sub(r'^use personas .*$','',src,flags=re.M)
 (out/'test.q').write_text('use personas '+', '.join(cast)+'\n'+src)
 fix=out/'fixtures';fix.mkdir(exist_ok=True)
 for table,rows in tables.items(): (fix/(table+'.jsonl')).write_text(''.join(json.dumps(r)+'\n' for r in rows))
 for c in cases:c['as']=c.pop('as_')
 (fix/'test.cases.jsonl').write_text(''.join(json.dumps(c)+'\n' for c in cases))
 cmd=['timeout','120s',str(ROOT/'node_modules/.bin/snapback4'),'test','--source',str(out/'test.q'),'--fixture',str(fix)]
 start=time.monotonic();p=subprocess.run(cmd,cwd=app,capture_output=True)
 (out/'test.stdout').write_bytes(p.stdout);(out/'test.stderr').write_bytes(p.stderr)
 rec=dict(app=app.name,phase=phase,cwd=str(app),command=cmd,exit_code=p.returncode,seconds=round(time.monotonic()-start,3),cases=len(cases),stdout=str((out/'test.stdout').relative_to(ROOT)),stderr=str((out/'test.stderr').relative_to(ROOT)))
 (out/'command.json').write_text(json.dumps(rec,indent=2)+'\n');all_records.append(rec);print(json.dumps(rec),flush=True)
(ROOT/'evidence'/(phase+'-targeted-commands.json')).write_text(json.dumps(all_records,indent=2)+'\n')
