from pathlib import Path
import os
ROOT=Path(os.environ.get('SNAPBACK_REPAIR_ROOT','/tmp/sec2-builders/codex'))
def path(prefix,name='schema.q'): return next(ROOT.glob(prefix+'-snapback-*'))/'snapback'/name
def replace(prefix,old,new,name='schema.q'):
 p=path(prefix,name);s=p.read_text();assert old in s,(prefix,old);p.write_text(s.replace(old,new))

# The sublet specification constrains the key-release transition, not arbitrary
# operator imports of historical data. Preserve that intent at the written field.
replace('008','invariant bookings always .releasedAt = null or (.leaseSignedAt != null and .subSignedAt != null and .proofUploaded = true)',
 'invariant bookings.releasedAt write only .releasedAt = null or (.leaseSignedAt != null and .subSignedAt != null and .proofUploaded = true)','security.q')
p=path('008');s=p.read_text();a=s.index('table bookings:');b=s.index('table idDocuments:');block=s[a:b]
block=block.replace("and .listing.subtenant = viewer", "and .listing.subtenant = viewer and .releasedAt = null")
block=block.replace("update <- .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']", "update <- (.leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']) and (.releasedAt = null or (.leaseSignedAt != null and .subSignedAt != null and .proofUploaded = true))")
s=s[:a]+block+s[b:];p.write_text(s)

# Synthetic table replay found an override state insert bypass; public book()
# already inserts 'booked'. Retain the invariant and strengthen the row boundary.
replace('010','insert <- .owner = viewer and exists members[viewer]',"insert <- .owner = viewer and exists members[viewer] and .status = 'booked'")
replace('010',"update <- .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']", "update (old, next) <- exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'] or (old.owner = viewer and next.owner = viewer and next.status != 'override')")

# Current inspector authority is required in addition to a stored route.
replace('019',".landOwner = viewer or exists routes[inspector = viewer, route = .route] or exists roles[viewer, role = 'lead']", ".landOwner = viewer or (exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .route]) or exists roles[viewer, role = 'lead']")
replace('019',"update <- exists routes[inspector = viewer, route = .route] or exists roles[viewer, role = 'lead']", "update (old, next) <- exists roles[viewer, role = 'lead'] or (exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = old.route] and next.status = old.status)")
replace('019','photo: image <=10000000 ?', 'photo: image <=10000000')
replace('019','insert <- .inspector = viewer',"insert <- .inspector = viewer and exists roles[viewer, role = 'inspector']")
replace('019',"require exists routes[inspector = viewer, route = h.route] else NOT_ROUTE", "require exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = h.route] else NOT_ROUTE")
replace('019','lastAt = h.lastInspectedAt ?? 0','lastAt = h.lastInspectedAt ?? h.seasonStart')
replace('019',"  if exists listings[hive]:", "  if status != 'healthy' and exists listings[hive]:")
replace('019',"insert <- .owner = viewer\n  update <- .owner = viewer", "insert <- .owner = viewer and exists hives[.hive, landOwner = viewer, status = 'healthy']\n  update <- .owner = viewer and exists hives[.hive, landOwner = viewer, status = 'healthy']")
replace('019',"public 'honey listings are public; flagged hives hold no listing row'", "read <- exists hives[.hive, status = 'healthy']")
replace('019',"invariant listings always exists hives[.hive, status = 'healthy']", "invariant listings.read only exists hives[.hive, status = 'healthy']",'security.q')

# Intake photos must contain at least one image, not a nullable/empty list.
replace('020','[image <=10000000] <=4 ?', '[image <=10000000] 1..4')
# The waiver authority invariant applies to insert as well as update. Initial
# fees have no waiver; later changes require the manager even at the row layer.
p=path('020');s=p.read_text();a=s.index('table vehicles:');b=s.index('table claims:');block=s[a:b]
block=block.replace("insert <- exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']", "insert <- (exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']) and .waived = 0 and .status = 'impounded'")
block=block.replace("update <- exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager'] or exists roster[principal = viewer, role = 'liaison']", "update (old, next) <- (exists roster[principal = viewer, role = 'manager'] or ((exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'liaison']) and next.waived = old.waived)) and (next.status != 'released' or next.onHold = false or next.status = old.status)")
s=s[:a]+block+s[b:];p.write_text(s)
# A later investigative hold is not forbidden by the spec. Constrain the actual
# status write to released, rather than all later snapshots of released vehicles.
replace('020',"invariant vehicles always .status != 'released' or .onHold = false", "invariant vehicles.status write only .status != 'released' or .onHold = false",'security.q')

# A newly created tournament must not mint global director power for an outsider.
replace('021','insert <- .director = viewer',"insert <- .director = viewer and (exists directors[viewer] or viewer = 'service:ops')")
replace('021','insert <- exists directors[viewer] or created tournaments[.tournament]',"insert <- exists directors[viewer] or (viewer = 'service:ops' and created tournaments[.tournament] and .principal = viewer)")
replace('021',"mutation createTournament(code: text 1..40, name: text 1..120, briefDeadline: time):\n", "mutation createTournament(code: text 1..40, name: text 1..120, briefDeadline: time):\n  require exists directors[viewer] or viewer = 'service:ops' else NOT_DIRECTOR\n")
replace('021','-- first director (see createTournament + the directors insert rule).','-- first director only through trusted service:ops bootstrap.')
replace('021','-- inserts its creator here (created-probe arm). Afterwards only directors','-- inserts its trusted creator here. Afterwards only directors')

# Condition evidence is mandatory at each handoff; a pending return remains null.
replace('045','checkoutPhoto: image <=5000000 ?', 'checkoutPhoto: image <=5000000')
replace('045','mutation checkin(loan: loans, returnPhoto: image <=5000000 ?):','mutation checkin(loan: loans, returnPhoto: image <=5000000):')
replace('045',"read <- exists roles[viewer, role = 'luthier'] or exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']", "read <- exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']")
replace('045',"  unique serial\n", "  unique serial\n")
# Table authority also protects write-off, independent of the mutation guard.
p=path('045');s=p.read_text();old="  update <- exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']";idx=s.index(old,s.index('table instruments:'));s=s[:idx]+s[idx:].replace(old,"  update (old, next) <- exists roles[viewer, role = 'manager'] or (exists roles[viewer, role = 'librarian'] and old.status != 'written_off' and next.status != 'written_off')",1);p.write_text(s)
p=path('045');s=p.read_text();a=s.index('table instruments:');b=s.index('table seasons:');block=s[a:b].replace("insert <- exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']", "insert <- (exists roles[viewer, role = 'librarian'] and .status = 'available') or exists roles[viewer, role = 'manager']");p.write_text(s[:a]+block+s[b:])

# Shift grants and equipment assignments require the reader's current role.
replace('048',"or exists shiftMembers[.id, viewer]", "or (exists roles[viewer, role = 'engineer'] and exists shiftMembers[.id, viewer])")
replace('048',"or exists assignments[.id, viewer]", "or (exists roles[viewer, role = 'contractor'] and exists assignments[.id, viewer])")
replace('048',"or exists assignments[.gauge, viewer]", "or (exists roles[viewer, role = 'contractor'] and exists assignments[.gauge, viewer])")
replace('048',"read <- exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'manager'] or exists shiftMembers[shift = .shift, engineer = viewer]", "read <- exists roles[viewer, role = 'chief'] or (.status = 'completed' and exists roles[viewer, role = 'manager']) or (exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer])")
replace('048',"update <- exists shiftMembers[shift = .shift, engineer = viewer] or exists roles[viewer, role = 'chief']", "update <- (exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer]) or exists roles[viewer, role = 'chief']")
replace('048',"insert <- .engineer = viewer and exists shiftMembers[shift = .shift, engineer = viewer]", "insert <- .engineer = viewer and exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer]")
replace('048',"where exists shiftMembers[.id, viewer]", "where exists roles[viewer, role = 'engineer'] and exists shiftMembers[.id, viewer]")
replace('048',"require exists shiftMembers[shift = s.id, engineer = viewer] or exists roles[viewer, role = 'chief']", "require (exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = s.id, engineer = viewer]) or exists roles[viewer, role = 'chief']")
replace('048',"require exists shiftMembers[shift = r.shift, engineer = viewer] or exists roles[viewer, role = 'chief']", "require (exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = r.shift, engineer = viewer]) or exists roles[viewer, role = 'chief']")
replace('048',"require exists shiftMembers[shift = r.shift, engineer = viewer] else NOT_SHIFT_MEMBER", "require exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = r.shift, engineer = viewer] else NOT_SHIFT_MEMBER")
replace('048',"return rounds where .scheduledAt >= from and .scheduledAt < to", "return rounds where .status = 'completed' and .scheduledAt >= from and .scheduledAt < to")
replace('048',"require (readingsCount[roundId] ?? 0) > 0 else NO_READINGS 'Log at least one gauge reading first.'", "require (readingsCount[roundId] ?? 0) > 0 else NO_READINGS 'Log every gauge reading first.'\n  require (readingsCount[roundId] ?? 0) = count(gauges) else MISSING_READINGS 'Log a reading and photo for every gauge.'")
