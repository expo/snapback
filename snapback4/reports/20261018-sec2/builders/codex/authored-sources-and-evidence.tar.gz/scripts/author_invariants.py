from pathlib import Path
ROOT=Path('/tmp/sec2-builders/codex')
# Authored from SPEC.md. These are upper bounds on authority, not grants.
policies={
'005': '''
invariant pieces.read only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant pieces.insert only .owner = viewer and exists memberships[viewer]
invariant pieces.update only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant pieces always .photo != null
invariant firingLoads.read only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firings.insert only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firings.update only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant memberships.update only exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'
invariant pieces.status write only .status != 'cancelled' or .owner = viewer or exists memberships[viewer, role = 'manager']
''',
'007': '''
invariant horses.read only .owner = viewer or .manager = viewer or .farrier = viewer
invariant visits.read only exists horses[.horse, owner = viewer] or exists horses[.horse, manager = viewer] or exists horses[.horse, farrier = viewer]
invariant photos.read only exists horses[.visit.horse, owner = viewer] or exists horses[.visit.horse, manager = viewer] or exists horses[.visit.horse, farrier = viewer]
invariant billing.read only exists horses[.horse, manager = viewer]
invariant billing.insert only exists horses[.horse, manager = viewer]
invariant billing.update only exists horses[.horse, manager = viewer]
invariant visits.insert only .farrier = viewer and .horse.farrier = viewer
invariant photos.insert only .visit.farrier = viewer
invariant photos always .photo != null
invariant quotes.read only exists horses[.horse, owner = viewer] or exists horses[.horse, manager = viewer] or exists horses[.horse, farrier = viewer]
invariant quotes.update only .horse.owner = viewer
invariant reminders.read only .to = viewer
''',
'008': '''
invariant listings.read only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant listings.insert only .leaseholder = viewer and exists people[viewer, role = 'leaseholder']
invariant bookings.read only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant bookings.insert only .subtenant = viewer and exists people[viewer, role = 'subtenant', vetted = true]
invariant idDocuments.read only .owner = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant idDocuments.insert only .owner = viewer and .booking.subtenant = viewer
invariant idDocuments always .document != null
invariant bookings always .releasedAt = null or (.leaseSignedAt != null and .subSignedAt != null and .proofUploaded = true)
invariant bookings.cancelled write only .cancelled = false or (.leaseSignedAt = null and .subSignedAt = null) or exists people[viewer, role = 'manager']
''',
'009': '''
invariant tracks.read only exists roster[principal = viewer, role = 'director'] or (exists roster[principal = viewer, part = .part] and exists releases[track = .id])
invariant tracks.insert only exists roster[principal = viewer, role = 'director']
invariant tracks always .audio != null
invariant progress.read only .singer = viewer or exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
invariant progress.insert only .singer = viewer and .singer = .member.principal and .part = .member.part
invariant progress.update only .singer = viewer or exists roster[principal = viewer, role = 'director']
invariant roster.update only exists roster[principal = viewer, role = 'director']
invariant attendance.read only exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
invariant attendance.insert only exists roster[principal = viewer, role = 'leader', part = .part]
invariant attendance.update only exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
invariant concerts.insert only exists roster[principal = viewer, role = 'director']
invariant releases.insert only exists roster[principal = viewer, role = 'director']
''',
'010': '''
invariant bookings.read only .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
invariant bookings.insert only .owner = viewer and exists members[viewer]
invariant slots.read only exists members[viewer]
invariant policy.update only exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
invariant overrides.read only exists members[viewer, role = 'chair']
invariant overrides.insert only .actor = viewer and (exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'])
invariant overrides always .photo != null
invariant bookings.status write only .status != 'override' or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
''',
'019': '''
invariant hives.read only .landOwner = viewer or (exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .route]) or exists roles[viewer, role = 'lead']
invariant inspections.read only exists hives[.hive, landOwner = viewer] or (exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .hive.route]) or exists roles[viewer, role = 'lead']
invariant inspections.insert only .inspector = viewer and exists roles[viewer, role = 'inspector'] and exists routes[inspector = viewer, route = .hive.route]
invariant inspections always .photo != null
invariant alerts.read only .owner = viewer or exists roles[viewer, role = 'lead']
invariant alerts.insert only .inspector = viewer and exists roles[viewer, role = 'inspector']
invariant hives.status write only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
invariant listings always exists hives[.hive, status = 'healthy']
invariant listings.insert only .owner = viewer and exists hives[.hive, landOwner = viewer, status = 'healthy']
''',
'020': '''
invariant vehicles.read only .owner = viewer or exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager'] or (.onHold = true and exists roster[principal = viewer, role = 'liaison'])
invariant vehicles.insert only exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']
invariant vehicles always .photos != null
invariant vehicles always .status != 'released' or .onHold = false
invariant claims.read only .claimant = viewer or exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']
invariant claims.insert only .claimant = viewer
invariant claims.update only exists roster[principal = viewer, role = 'clerk'] or exists roster[principal = viewer, role = 'manager']
invariant claims always .proof != null
invariant waivers.insert only exists roster[principal = viewer, role = 'manager']
invariant vehicles.waived write only .waived = 0 or exists roster[principal = viewer, role = 'manager']
''',
'021': '''
invariant scores.read only .judge = viewer or exists directors[viewer] or (exists rounds[.round, status = 'closed'] and (exists judges[viewer] or exists members[.team, viewer] or exists teams[.team, coach = viewer]))
invariant scores.insert only .judge = viewer and exists judges[viewer]
invariant scores.update only .judge = viewer and exists judges[viewer]
invariant teams.insert only exists directors[viewer]
invariant teams.update only exists directors[viewer]
invariant teams.delete only exists directors[viewer]
invariant rounds.update only exists directors[viewer]
invariant briefs.read only exists directors[viewer] or exists judges[viewer] or exists members[.team, viewer] or exists teams[.team, coach = viewer]
invariant briefs.insert only exists members[.team, viewer]
invariant briefs.update only exists members[.team, viewer]
invariant directors.insert only exists directors[viewer] or viewer = 'service:ops'
invariant tournaments.insert only exists directors[viewer] or viewer = 'service:ops'
''',
'045': '''
invariant loans.read only .borrower = viewer or exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans.insert only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans.update only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans always .checkoutPhoto != null
invariant loans always .status != 'returned' or .returnPhoto != null
invariant deposits.read only exists roles[viewer, role = 'manager']
invariant deposits.insert only exists roles[viewer, role = 'manager']
invariant deposits.update only exists roles[viewer, role = 'manager']
invariant repairNotes.read only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant repairNotes.insert only .author = viewer and exists roles[viewer, role = 'luthier']
invariant instruments.status write only .status != 'written_off' or exists roles[viewer, role = 'manager']
''',
'048': '''
invariant rounds.read only exists roles[viewer, role = 'chief'] or (.status = 'completed' and exists roles[viewer, role = 'manager']) or (exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer])
invariant gauges.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'engineer'] or (exists roles[viewer, role = 'contractor'] and exists assignments[.id, viewer])
invariant readings.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'engineer'] or (exists roles[viewer, role = 'contractor'] and exists assignments[.gauge, viewer])
invariant readings.insert only .engineer = viewer and exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer]
invariant readings always .photo != null
invariant gauges.insert only exists roles[viewer, role = 'chief']
invariant gauges.update only exists roles[viewer, role = 'chief']
invariant gauges.delete only exists roles[viewer, role = 'chief']
invariant alerts.read only exists roles[viewer, role = 'chief']
invariant alerts.update only exists roles[viewer, role = 'chief']
'''
}
for prefix, declarations in policies.items():
    app=next(ROOT.glob(prefix+'-snapback-*'))
    (app/'snapback/security.q').write_text('-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.\n'+declarations.lstrip())
