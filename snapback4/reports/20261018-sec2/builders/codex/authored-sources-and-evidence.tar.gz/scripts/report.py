from pathlib import Path
import json, re, hashlib, collections, shlex, difflib
ROOT=Path('/tmp/sec2-builders/codex')
assessment=json.loads((ROOT/'scripts/assessment.json').read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def parsed(p):
 try:return json.loads(p.read_text())
 except (ValueError,FileNotFoundError):return None
def invariants(p):return [l for l in p.read_text().splitlines() if l.startswith('invariant ')] if p.exists() else []
def check_summary(p):
 d=parsed(p)
 if d is None:return dict(available=False,counts=None,invariants=[],notes=[])
 entries=d.get('security',{}).get('invariants',[])
 result=dict(available=True,ok=d.get('ok'),milliseconds=d.get('ms'),counts={s:sum(i['status']==s for i in entries) for s in ['proved','refuted','unproved']},
             unsupported_count=sum(bool(i['invariant'].get('unsupported')) for i in entries),
             supported_but_unproved_count=sum(i['status']=='unproved' and not i['invariant'].get('unsupported') for i in entries),
             direct_rule_counts=dict(collections.Counter(i['direct_rule'] for i in entries)),invariants=[],notes=d.get('notes',[]),security_note_counts=dict(collections.Counter(n['code'] for n in d.get('security',{}).get('notes',[]))))
 for i in entries:
  v=i['invariant'];c=i.get('counterexample');brief=None
  if c:
   brief={k:c.get(k) for k in ['operation','effect','scope','viewer','rule_path','invariant_site','row','old','observations','history']}
   brief['unchanged_row_image']=c.get('old') is not None and c.get('old')==c.get('row')
  result['invariants'].append(dict(table=v['table'],column=v['column'],target=v['target'],predicate=v['predicate'],status=i['status'],direct_rule=i['direct_rule'],unsupported=v.get('unsupported'),reasons=i['reasons'],obligations=i.get('obligations',[]),counterexample=brief))
 return result
def test_summary(p):
 s=p.read_text() if p.exists() else '';m=re.search(r'security tests: (\d+) attempted, (\d+) refused, (\d+) violations',s)
 c=re.search(r'cases: (\d+) passed, (\d+) failed',s)
 return dict(security_counts=dict(zip(['attempted','refused','violations'],map(int,m.groups()))) if m else None,
             case_counts=dict(zip(['passed','failed'],map(int,c.groups()))) if c else None,
             failed_cases=[l.strip() for l in s.splitlines() if 'FAIL test.cases' in l],
             not_covered=[l[len('security not covered: '):] for l in s.splitlines() if l.startswith('security not covered: ')],
             sweep_summary=next((l for l in reversed(s.splitlines()) if l.startswith('test: ') and ('complete,' in l)),None))
def command_records(out):
 d=parsed(out/'commands.json')
 if d is not None:return d
 return []
apps=[]
for app in sorted(ROOT.glob('[0-9][0-9][0-9]-snapback-*')):
 aid=app.name[:3]; ev=ROOT/'evidence'/app.name;meta=assessment[aid]
 final_phase=next(p for p in ['repaired-v3','repaired-v2','repaired'] if (ev/p/'schema.q').exists())
 phases={}
 for phase in ['original','invariants-original','invariants-original-long','repaired-stage','repaired','repaired-v2','repaired-v3']:
  out=ev/phase
  if not out.exists():continue
  records=command_records(out)
  phases[phase]=dict(commands=records,check=check_summary(out/'check.stdout'),test=test_summary(out/'test.stdout'),evidence=str(out.relative_to(ROOT)))
  for rec in records:rec['stderr_text']=(ROOT/rec['stderr']).read_text() if (ROOT/rec['stderr']).exists() else ''
 target_original='original-corrected' if aid=='009' else 'original-expanded'
 targets={}
 for phase in ['original','original-expanded','original-corrected','repaired-stage','repaired','repaired-v2','repaired-v3']:
  out=ev/phase/'targeted';rec=parsed(out/'command.json')
  if rec:targets[phase]=dict(command=rec,**test_summary(out/'test.stdout'))
 before=ev/'original/schema.q';after=app/'snapback/schema.q'
 final_source=ev/final_phase/'schema.q';final_security=ev/final_phase/'security.q'
 installed=after.exists() and final_source.exists() and digest(after)==digest(final_source) and digest(app/'snapback/security.q')==digest(final_security)
 diff=''.join(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='original/schema.q',tofile='repaired/schema.q'))
 (ev/'repair.diff').write_text(diff)
 refutations=phases.get(final_phase,{}).get('check',{}).get('invariants',[])
 false_refusals=[]
 if aid=='010' and any(i['status']=='refuted' for i in refutations):
  false_refusals.append(dict(classification='confirmed replay mismatch',count=1,description='The checker refutes the named update rule with an unchanged override image. A test-only authored update of that same override value is refused E_RULE. The invariant remains present.',evidence=str((ev/'no-op-verification').relative_to(ROOT))))
 if aid=='020' and any(i['status']=='refuted' for i in refutations):
  false_refusals.append(dict(classification='intent expressiveness / no transition',count=1,description='The remaining status-write counterexample starts and ends released/onHold with identical images. This does not demonstrate release while held. The spec permits a later hold, while the field-write invariant cannot express only a transition. Retained rather than deleted.'))
 extras={}
 for phase in ['original','repaired']:
  out=ev/'additional-workflow'/phase;rec=parsed(out/'command.json')
  if rec:extras[phase]=dict(command=rec,**test_summary(out/'test.stdout'))
 isolated=[]
 for p in sorted((ev/'isolated-invariants').glob('*/command.json')):
  isolated.append(dict(command=parsed(p),check=check_summary(p.parent/'check.stdout')))
 apps.append(dict(app=app.name,spec=(app/'SPEC.md').read_text().strip(),assessment=meta,declared_invariants=invariants(app/'snapback/security.q'),declared_count=len(invariants(app/'snapback/security.q')),
                  original_declared_invariants=invariants(ev/'invariants-original-long/security.q'),source_repaired=bool(diff),source_hashes=dict(original=digest(before),installed=digest(after),measured_final=digest(final_source) if final_source.exists() else None),
                  measured_final_installed=installed,primary_original_phase='invariants-original-long',primary_final_phase=final_phase,primary_original_targeted_phase=target_original,
                  primary_final_targeted_phase=next(p for p in ['repaired-v3','repaired-v2','repaired'] if p in targets),phases=phases,targeted=targets,additional_workflow=extras,isolated_invariants=isolated,false_refusals=false_refusals,
                  unsupported_is_not_a_refusal=True))
totals=dict(apps=len(apps),declared_invariants=sum(a['declared_count'] for a in apps),apps_with_reproduced_original_findings=sum(bool(a['assessment']['findings']) for a in apps),
            distinct_reproduced_original_findings=sum(len(a['assessment']['findings']) for a in apps),apps_without_reproduced_original_findings=sum(not a['assessment']['findings'] for a in apps),
            schema_copies_repaired=sum(a['source_repaired'] for a in apps),confirmed_false_refutation_invariants=sum(r['count'] for a in apps for r in a['false_refusals'] if r['classification']=='confirmed replay mismatch'),
            intent_expressiveness_false_refusal_candidates=sum(r['count'] for a in apps for r in a['false_refusals'] if r['classification']!='confirmed replay mismatch'),
            all_final_measured_sources_installed=all(a['measured_final_installed'] for a in apps))
totals['observed_false_runtime_refusals_in_final_targeted_cases']=0
totals['authored_invariant_scope_corrections']=sum(len(a['assessment'].get('intent_revisions',[])) for a in apps)
totals['invariants_removed_to_pass']=0
for phase_key,name in [('primary_original_phase','original_invariant'),('primary_final_phase','final_invariant')]:
 counts=collections.Counter();missing=[];exits=collections.Counter();security=collections.Counter()
 for a in apps:
  p=a['phases'].get(a[phase_key],{});c=p.get('check',{}).get('counts')
  if c:counts.update(c)
  else:missing.append(a['app'])
  for r in p.get('commands',[]):exits[str(r['exit_code'])]+=1
  if p.get('test',{}).get('security_counts'):security.update(p['test']['security_counts'])
 totals[name]=dict(counts=dict(counts),apps_without_json=missing,command_exit_counts=dict(exits),security_counts_from_completed_outputs=dict(security))
for key,name in [('primary_original_targeted_phase','original_targeted'),('primary_final_targeted_phase','final_targeted')]:
 counts=collections.Counter();fail_apps=[]
 for a in apps:
  t=a['targeted'].get(a[key],{});c=t.get('case_counts')
  if c:counts.update(c)
  if t.get('command',{}).get('exit_code')!=0:fail_apps.append(a['app'])
 totals[name]=dict(case_counts=dict(counts),nonzero_apps=fail_apps)
totals['additional_workflow']={phase:{k:sum_counts.get(k,0) for k in ['passed','failed']} for phase in ['original','repaired'] for sum_counts in [sum((collections.Counter(a['additional_workflow'].get(phase,{}).get('case_counts') or {}) for a in apps),collections.Counter())]}
result=dict(format=1,tool_version=(ROOT/'evidence/documentation/version.stdout').read_text().strip(),workspace=str(ROOT),
            learning_sources=['node_modules/snapback4/README.md','installed CLI --help and guide security/testing/rules/types/assets'],
            methodology='Independent SPEC.md policies; original no-invariant baseline; original schemas plus authored invariants; repaired schemas with invariants retained; isolated documented-fixture operation cases. Refutations are scoped as authored operation, synthetic table replay, or trusted seed. Unproved/unsupported, capped and timeout are not security refusals.',
            phases_explanation=dict(original='Untouched copied schema; no invariants.',invariants_original='120-second first attempt, retained including timeouts and overlapping-run store contention.',invariants_original_long='Primary original plus independent invariants, 600-second commands.',repaired='Measured repaired stage copies; hashes must match the final installed copies.',repaired_v2='Further row-boundary repairs for sublet and tow, with separate preserved evidence.',targeted='Self-contained source with development personas and documented fixtures; no invariants so that case outcomes independently measure workflow behavior. Metadata-only media fixtures have no downloadable bytes.'),
            totals=totals,apps=apps,
            limitations=['No ground-truth labels were consulted. Absence of a reproduced finding is not proof of a clean app.','Unproved assertions stay in the source and are not counted as refusals.','Trusted seed and synthetic table counterexamples do not establish application reachability.','No real media downloads, device revocation, external notifications, or full clock/schedule qualification.','A passing finite test campaign is not a proof.','The two initial fixture expectation mistakes are preserved and corrected, not reported as application findings.'])
(ROOT/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
def counts(c):return '/'.join(str(c.get(k,0)) for k in ['proved','refuted','unproved']) if c else 'no JSON'
lines=['# Snapback invariant adoption assessment','',f"{totals['apps']} apps; {totals['declared_invariants']} independently authored invariants. Targeted operation tests reproduce {totals['distinct_reproduced_original_findings']} distinct specification violations in {totals['apps_with_reproduced_original_findings']} apps. The other five have no reproduced application finding in this campaign; that is not a clean-app proof.",'',
       'Only installed package README/docs and CLI guide/help were used to learn Snapback. Only the ten copied SPEC.md/schema.q pairs were inspected as application inputs. No original wave directories, repository source, reviews, journals, other worktrees, credentials, remote systems, cargo, publication or push were used. All shell commands had timeouts. No generated invariant draft was accepted or used as intent.','',
       'Evidence is verbatim stdout and stderr with exit code, elapsed time, source snapshots and exact command arrays. `original` is the untouched baseline; `invariants-original-long` is the primary bad-original-plus-intent measurement; `repaired` and the two `repaired-v2` directories are final schema measurements. Repairs were staged while original checks ran, then installed only after original measurements finished. Final source hashes in RESULTS.json bind the installed copies to the measured snapshots.','',
       'P/R/U below means whole-declaration proved/refuted/unproved, not just the direct row-rule implication. Unsupported expressions, unreduced paths, partial (`capped`) answers and timeouts are not security refusals. Refutations from a trusted seed or a synthetic table operation do not establish a reachable public workflow. The independent targeted cases provide that distinction.','',
       '| App | Declared | Original P/R/U | Final P/R/U | Original targeted passed/failed | Final targeted passed/failed | Distinct reproduced findings |','|---|---:|---|---|---|---|---:|']
for a in apps:
 old=a['phases'].get(a['primary_original_phase'],{}).get('check',{}).get('counts');new=a['phases'].get(a['primary_final_phase'],{}).get('check',{}).get('counts')
 t=a['targeted'].get(a['primary_original_targeted_phase'],{}).get('case_counts') or {};u=a['targeted'].get(a['primary_final_targeted_phase'],{}).get('case_counts') or {}
 lines.append(f"| {a['app']} | {a['declared_count']} | {counts(old)} | {counts(new)} | {t.get('passed','?')}/{t.get('failed','?')} | {u.get('passed','?')}/{u.get('failed','?')} | {len(a['assessment']['findings'])} |")
def campaign(p):
 c=p.get('test',{}).get('security_counts')
 return '/'.join(str(c[k]) for k in ['attempted','refused','violations']) if c else 'not completed'
lines+=['','Schema-derived security campaign counts are attempted/refused/violations. Refused attacks are expected denials, not false refusals. These counts are separate from authored fixture cases.','',
        '| App | Untouched baseline A/R/V | Original with invariants A/R/V | Final A/R/V | Final unsupported assertions | Confirmed false refutations |','|---|---|---|---|---:|---:|']
for a in apps:
 p=a['phases'].get(a['primary_final_phase'],{})
 lines.append(f"| {a['app']} | {campaign(a['phases'].get('original',{}))} | {campaign(a['phases'].get(a['primary_original_phase'],{}))} | {campaign(p)} | {p.get('check',{}).get('unsupported_count','?')} | {sum(r['count'] for r in a['false_refusals'] if r['classification']=='confirmed replay mismatch')} |")
lines+=['','The unchanged kiln schema has especially expensive full-set invariant checks; bounded runs and isolated declaration checks are retained under its evidence directory. A missing JSON result is reported as missing, never as zero findings or a pass.','',
        'The confirmed allotment replay mismatch has an additional [authored boundary test](evidence/010-snapback-allotment-water-turns/no-op-verification/test.stdout): the same forbidden override write is refused E_RULE. The remaining tow status counterexample starts and ends in the identical released/held state; it does not show a release transition. These refusal cases remain visible. The initial sublet and tow all-snapshot assertions, and the initial honey-listing physical-absence assertion, were narrowed to actual release/write/read intent with explanations below. No invariant was removed to obtain a pass.','',
        'Usability friction: whole-declaration proofs are frequently unproved despite proved direct row predicates, because jobs, raw probes, parent captures, refusal observations and wire paths need separate reductions. Multi-hop read assertions can be retained but unsupported. Required non-null scalar evidence has a type theorem, while conditional evidence and trusted seeds need careful interpretation. Checks can take minutes; both 120- and 600-second bounded attempts are preserved. One overlapping exploratory choir test returned E_STORE_BUSY; this is harness-induced contention, not a security refusal. Query sweeps can be incomplete with exit zero, and expected authorization refusals are advisory. Counts retain those limits rather than treating every refused attack or incomplete sweep as a false refusal.','',
        'The first choir expanded case incorrectly tested bob as a wrong-part singer after moving bob to Alto. It was corrected to a separate Tenor singer and rerun. The first boiler demotion case used myShifts metadata, whose audience is unspecified; it was corrected to the explicitly shift-authorized shiftRounds operation. Both initial outputs are preserved.','']
lines+=[f"The main corrected fixture suite has {totals['final_targeted']['case_counts'].get('passed',0)} final passes. Additional original/final pairs catch a premature apiary overdue flag and completing a boiler round without reading every gauge, and preserve the luthier's ability to write private notes; {totals['additional_workflow']['repaired']['passed']} additional final cases pass. These workflow findings are counted separately from invariant refutations and their exact commands are under `evidence/additional-workflow-commands.json`.",'']
lines+=['No false runtime refusal was observed in the final authored cases. This is finite case coverage, not a claim about every legitimate workflow. The invariant checker still returns nonzero for three declarations: the confirmed allotment replay mismatch, the tow unchanged-image transition-scope issue, and a returned-loan-without-photo trusted-seed counterexample. The loan snapshot does not show that the repaired required-photo checkin operation can create that state. Unsupported and unreduced declarations remain unproved rather than being labeled refusals.','',
        'Final source reproduction and integrity: [original snapshots stayed unchanged](evidence/original-integrity.json); [all 20 final source files reproduce exactly](evidence/repair-reproducibility.json) from those snapshots with `scripts/repair.py`.','']
for a in apps:
 meta=a['assessment'];ev='evidence/'+a['app'];lines += [f"## {a['app']}",'',meta['policy'],'','Declared intent in `snapback/security.q`:','','```quarry',*a['declared_invariants'],'```','']
 if meta['findings']:
  lines+=['Reproduced original findings:','']+[f"- {f['id']}: {f['description']} {f['invariant_detection']}" for f in meta['findings']]+['']
 else:lines+=['No application finding reproduced by the targeted cases.','']
 if meta.get('repairs'):lines+=['Source repairs:','']+['- '+r for r in meta['repairs']]+['']
 else:lines+=['The application schema was retained; security intent was added independently.','']
 if meta.get('intent_revisions'):lines+=['Assertion scope corrections:','']+['- '+r for r in meta['intent_revisions']]+['']
 if a['false_refusals']:lines+=['False-refusal assessment:','']+['- '+r['classification']+': '+r['description'] for r in a['false_refusals']]+['']
 if a['additional_workflow']:
  lines+=['Additional workflow evidence:','']
  for phase,ex in a['additional_workflow'].items():
   r=ex['command'];c=ex['case_counts'] or {};lines.append(f"- `{phase}`: {c.get('passed',0)} passed / {c.get('failed',0)} failed; `{shlex.join(r['command'])}` → exit {r['exit_code']}")
  lines+=['']
 lines+=['Ambiguities and preserved conventions:','']+['- '+r for r in meta['ambiguities']]+['',meta['workflow_coverage'],'',f"[Source diff]({ev}/repair.diff), [original invariant evidence]({ev}/invariants-original-long/commands.json), [final evidence]({ev}/{a['primary_final_phase']}/commands.json), [original targeted cases]({ev}/{a['primary_original_targeted_phase']}/targeted/fixtures/test.cases.jsonl), [final targeted output]({ev}/{a['primary_final_targeted_phase']}/targeted/test.stdout).",'','Exact primary measurement commands (run each from the stated cwd):','']
 for phase in ['original',a['primary_original_phase'],a['primary_final_phase']]:
  for r in a['phases'].get(phase,{}).get('commands',[]):lines.append(f"- `{phase}`, cwd `{r['cwd']}`: `{shlex.join(r['command'])}` → exit {r['exit_code']} ({r['seconds']}s)")
 for phase in [a['primary_original_targeted_phase'],a['primary_final_targeted_phase']]:
  r=a['targeted'].get(phase,{}).get('command')
  if r:lines.append(f"- `{phase}` targeted, cwd `{r['cwd']}`: `{shlex.join(r['command'])}` → exit {r['exit_code']}")
 lines+=['']
lines+=['## Evidence and practical limits','',
        'RESULTS.json contains per-invariant predicates, whole and direct-rule verdicts, unsupported reasons, counterexample scopes, attempted/refused/violation campaign counts, case counts, raw-path links, exact commands, exit codes and source hashes. Each app retains its original and repaired evidence even when a checker refutes a declaration or times out. `snapback/*.q` in the ten top-level app copies is the final source for the later independent live probe.','',
        'Media fixture cells follow the installed asset guide and contain metadata only. They establish row visibility and required argument behavior, not byte delivery. No live-server, device, notification provider, upload/download or exhaustive temporal claim is made. Several deadlines/jobs were reviewed in source but not driven through a clock boundary. Ambiguous product details are listed per app.']
(ROOT/'REPORT.md').write_text('\n'.join(lines)+'\n')
print(json.dumps(totals,indent=2))
