from pathlib import Path
import json, hashlib, collections, re

R=Path('/tmp/sec2-builders/codex')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p): return json.loads(p.read_text())
initial=read(R/'archive-initial/RESULTS.json')
review=read(R/'final-evidence/spec-review.json')
retained={x['app']:x for x in read(R/'final-evidence/retained-workflow-index.json')}
apps=[]
for old in initial['apps']:
    name=old['app']; app=R/name
    phase='pre-review' if name[:3] in ['005','010','020','045'] else 'final'
    d=R/'final-evidence'/name/phase
    commands={v:read(d/(v+'.command.json')) if (d/(v+'.command.json')).exists() else {'status':'pending'} for v in ['check','test']}
    c=read(d/'check.stdout') if (d/'check.stdout').stat().st_size else None
    s=(d/'test.stdout').read_text() if (d/'test.stdout').exists() else ''
    security=c['security'] if c else {}
    inv=security.get('invariants',[])
    counts={k:sum(x['status']==k for x in inv) for k in ['proved','refuted','unproved']}
    unsupported=[x for x in inv if x['invariant'].get('unsupported')]
    match=re.search(r'security tests: (\d+) attempted, (\d+) refused, (\d+) violations',s)
    campaign=dict(zip(['attempted','refused','violations'],map(int,match.groups()))) if match else None
    violations=[json.loads(x.removeprefix('security violation: ')) for x in s.splitlines() if x.startswith('security violation: ')]
    not_covered=sorted(set(x.removeprefix('security not covered: ') for x in s.splitlines() if x.startswith('security not covered: ')))
    tp=old['targeted'][old['primary_final_targeted_phase']]
    hashes={str(p.relative_to(R)):sha(p) for p in (app/'snapback').glob('*.q')}
    initial_hashes=old['source_hashes']
    invariant_review=review[name]['declarations']
    for note,result in zip(invariant_review,inv): note['candidate_status']=result['status']
    boundary_dir=R/'final-evidence'/name/'boundary-verification'
    boundary=None
    if (boundary_dir/'boundary.command.json').exists():
        bs=(boundary_dir/'boundary.stdout').read_text()
        bm=re.search(r'cases: (\d+) passed, (\d+) failed',bs)
        boundary=dict(command=read(boundary_dir/'boundary.command.json'),cases=dict(zip(['passed','failed'],map(int,bm.groups()))) if bm else None,
                      purpose=read(boundary_dir/'purpose.json'),summary=[x for x in bs.splitlines() if x.startswith('test: ')][-1:])
    apps.append(dict(app=name,spec=review[name]['spec'],declared_count=len(invariant_review),source_hashes=hashes,
                     schema_unchanged_since_initial_report=sha(app/'snapback/schema.q')==initial_hashes.get('installed'),
                     authored_invariants_unchanged_since_initial_report=[x['declaration'] for x in invariant_review]==old['declared_invariants'],
                     commands=commands,check_ok=c.get('ok') if c else None,counts=counts,
                     invariants=inv,independent_spec_review=invariant_review,
                     declaration_hole_count=len(security.get('uncovered',[])),declaration_holes=security.get('uncovered',[]),
                     spec_scope_holes=review[name]['holes'],unsupported_count=len(unsupported),unsupported=unsupported,
                     test_campaign=campaign,test_violation_replays=violations,test_not_covered=not_covered,test_not_covered_count=len(not_covered),
                     test_sweep_summary=[x for x in s.splitlines() if x.startswith('test: ')][-1:] or None,
                     retained_workflows=dict(**retained[name],source_mode='Production schema plus test personas; security.q intentionally absent to test application enforcement independently of checker assertions.',
                                             original_not_covered=tp.get('not_covered',[]),additional_workflow=old.get('additional_workflow',{})),
                     boundary_verification=boundary,
                     false_runtime_refusals=dict(observed=0,scope='Retained final ordinary cases and new boundary cases only. Expected permission denials and attack refusals are not false refusals; untested legitimate workflows remain unqualified.'),
                     prior_report_false_refutation_claims=old['false_refusals'],prior_original_findings=old['assessment'].get('findings',[])))

reassessments=[
 dict(app='010-snapback-allotment-water-turns',prior_claim='confirmed replay mismatch',
      prior_evidence='evidence/010-snapback-allotment-water-turns/no-op-verification',
      prior_evidence_disposition='Preserved. The earlier displayed unchanged override write is refused E_RULE; that observation has not been erased or silently recategorized.',
      final_classification='valid refutation of an over-strong both-image author policy; no current confirmed false refutation',
      changed_evidence='Current replay has actual old status override, committed next status booked, and $syntheticPatch {status: booked}. The old predicate is false for an ordinary holder, so the declaration is refuted under documented semantics.',
      spec_explanation='SPEC reserves overriding to committee. It does not require that every status edit away from an already overridden snapshot be committee-only. The public cancel requires booked and the public override requires committee. Neither counterexample nor new test-only diagnosticStatus is an unauthorized public override.',
      action='Retained the declaration and nonzero verdict. No scope weakening or deletion. A role-only bookings.override declaration would state operation authority but would not prove next-image/cross-operation transition intent.'),
 dict(app='020-snapback-tow-yard-release',prior_claim='intent expressiveness / no transition',
      prior_evidence='evidence/020-snapback-tow-yard-release/repaired-v2',
      prior_evidence_disposition='Preserved. The earlier unchanged released/held image did not establish a release transition.',
      final_classification='valid refutation of an over-strong both-image author policy; general transition assertion is a scope limitation',
      changed_evidence='Current replay has released/onHold=true as old and impounded/onHold=true as committed next, with $syntheticPatch {status: impounded}. It violates the old-image predicate even though the next image satisfies it.',
      spec_explanation='SPEC blocks releasing while held. Moving away from released in a synthetic snapshot is not entering released while held. The public releaseVehicle requires impounded, no hold, and verified claim. The corrected replay is valid against the literal declaration but does not establish an app release violation.',
      action='Retained the declaration, original evidence and nonzero verdict; did not reinterpret write only as next-image-only.'),
 dict(app='045-snapback-instrument-loan-bank',prior_claim='all-snapshot return evidence refutation, no false-refutation claim',
      prior_evidence='evidence/045-snapback-instrument-loan-bank/repaired-v3',
      prior_evidence_disposition='Preserved as a real trusted seed_at commit/read-back of returned with returnPhoto=null.',
      final_classification='genuine all-snapshot integrity / trusted-ingress scope limitation; ordinary app reachability not established',
      changed_evidence='The current candidate still returns a trusted seed_at counterexample with returned status and no return photo; it is not a failed input decode or a no-op mismatch.',
      spec_explanation='The SPEC requires condition photos at return. That is correct intent and remains authored. Public checkin now has a required returnPhoto argument. A typed snapshot import can still introduce an invalid historical returned row, and the checker does not prove only histories reachable through checkin.',
      action='Retained correct intent rather than deleting or weakening it to make check/test pass.')
]

preserved_manifest=read(R/'final-evidence/initial-evidence-sha256.json')
preservation_errors=[n for n,h in preserved_manifest.items() if not (R/n).is_file() or sha(R/n)!=h]
archive_hashes=read(R/'archive-initial/SHA256.json')
archive_ok=all(sha(R/'archive-initial'/n)==h and sha(R/n)==h for n,h in archive_hashes.items())
totals=dict(apps=len(apps),declared_invariants=sum(a['declared_count'] for a in apps),
            invariant_counts={k:sum(a['counts'][k] for a in apps) for k in ['proved','refuted','unproved']},
            unsupported_declarations=sum(a['unsupported_count'] for a in apps),
            declaration_holes=sum(a['declaration_hole_count'] for a in apps),
            commands_completed=sum('exit_code' in c for a in apps for c in a['commands'].values()),
            commands_exit_0=sum(c.get('exit_code')==0 for a in apps for c in a['commands'].values()),
            commands_exit_1=sum(c.get('exit_code')==1 for a in apps for c in a['commands'].values()),
            timeouts=sum(c.get('exit_code') in [124,137] for a in apps for c in a['commands'].values()),
            confirmed_current_false_refutations=0,historical_confirmed_replay_mismatch_claims_preserved=1,
            over_strong_author_policies_with_current_refutation=2,trusted_seed_integrity_refutations=1,
            observed_false_runtime_refusals=0,
            retained_ordinary_case_passes=sum(a['retained_workflows']['cases']['passed'] for a in apps),
            retained_additional_case_passes=sum(a['retained_workflows']['additional_workflow'].get('repaired',{}).get('case_counts',{}).get('passed',0) for a in apps),
            new_boundary_case_passes=sum((a['boundary_verification']['cases'] or {}).get('passed',0) for a in apps if a['boundary_verification']),
            source_declarations_removed=0,scope_corrections_applied_this_continuation=0)
campaigns=[a['test_campaign'] for a in apps if a['test_campaign']]
totals['final_test_campaign']={k:sum(c[k] for c in campaigns) for k in ['attempted','refused','violations']}
result=dict(format=2,status='complete' if totals['commands_completed']==20 else 'partial',workspace=str(R),
            learning_sources=['node_modules/snapback4/README.md','final-evidence/guide-security.txt','final-evidence/guide-testing.txt'],
            methodology='Independent per-declaration SPEC review; all 102 authored declarations retained; fresh installed-candidate check --json and test on all ten actual app directories; retained equivalent ordinary workflows plus new disputed-boundary probes. No inference of app reachability from synthetic or trusted seed snapshots.',
            execution_limits=dict(outer_seconds=180,cli_seconds=175,kill_after_seconds=3,max_concurrent_apps=4,no_publication=True,no_cargo=True),
            totals=totals,preservation=dict(archive_verified=archive_ok,original_evidence_files=len(preserved_manifest),evidence_errors=preservation_errors),
            report_label_explanation='pre-review command records are final applicable measurements: no application schema or invariant changed after these commands. Other apps use the final label. Labels are preserved rather than rewriting command evidence.',
            prior_report_reassessments=reassessments,apps=apps,
            limitations=['An exit-zero schema-only test can still say incomplete; no business-case pass is inferred from it.',
                         'Proved/refuted/unproved count whole declarations, not just direct row-rule implications. Unsupported is a subset of unproved.',
                         'Declaration holes are uncovered effect entries from the check security audit, not confirmed vulnerabilities. SPEC scope holes are separately enumerated.',
                         'Refused security attacks are expected denials, not false runtime refusals. The zero false-runtime-refusal count is limited to the finite reviewed workflows.',
                         'Retained workflow suites are reused with explicit provenance, not represented as newly executed with the current candidate. No ordinary application bodies changed.',
                         'Test personas and metadata-only fixture media do not establish production identity, real asset bytes, device revocation, UI delivery, or complete app histories.',
                         'Trusted operator service seats are explicit policy assumptions and ordinary checker viewers; the guide does not grant an implicit seat exemption.'])
(R/'FINAL-RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')

lines=['# Final installed-document-only continuation','',
       f"{totals['commands_completed']}/20 final check/test commands completed; {totals['declared_invariants']} declarations: {totals['invariant_counts']['proved']} proved, {totals['invariant_counts']['refuted']} refuted, {totals['invariant_counts']['unproved']} unproved. {totals['unsupported_declarations']} unproved declarations contain unsupported expressions. {totals['commands_exit_0']} commands exited 0, {totals['commands_exit_1']} exited 1, {totals['timeouts']} timed out.",'',
       'All application schema.q and security.q files were retained. No correct intent was removed or narrowed to obtain a pass. Current refutations comprise two over-strong both-image policies and one trusted-ingress integrity counterexample; none establishes a newly reproduced unauthorized public app operation. Zero current false refutations were confirmed. The historical false-replay claim and its refusal evidence remain preserved and explicitly reassessed below.','',
       f"The first action affecting files archived REPORT.md and RESULTS.json under [archive-initial](archive-initial/). Their originals and archived SHA-256 hashes match. All {len(preserved_manifest)} pre-existing evidence files remain byte-identical. Independent review of each declaration against its SPEC is in [spec-review.json](final-evidence/spec-review.json); full command arrays, exit status, timings, source hashes, raw counterexamples and unsupported paths are in [FINAL-RESULTS.json](FINAL-RESULTS.json).",'',
       'Only this workspace was used. Learning used the installed README and current CLI security/testing guides. No repository source, other-model reports/reviews, journals, original-wave directories, keys, cargo or publication were accessed. CLI commands had 175-second timeouts with 3-second kill grace and a 180-second outer deadline; at most four apps ran concurrently.','',
       '| App | Declared | P/R/U | Holes | Unsupported | check/test exit | Test A/R/V | Retained ordinary pass/fail | False runtime refusals |',
       '|---|---:|---|---:|---:|---|---|---|---:|']
for a in apps:
    cs=a['counts'];cmd=a['commands'];camp=a['test_campaign'];cases=a['retained_workflows']['cases']
    lines.append(f"| {a['app']} | {a['declared_count']} | {cs['proved']}/{cs['refuted']}/{cs['unproved']} | {a['declaration_hole_count']} | {a['unsupported_count']} | {cmd['check'].get('exit_code','pending')}/{cmd['test'].get('exit_code','pending')} | {'/'.join(str(camp[k]) for k in ['attempted','refused','violations']) if camp else 'pending'} | {cases['passed']}/{cases['failed']} | 0 |")
lines += ['', 'P/R/U are whole-declaration verdicts. Holes are conditional read/write effects with no matching declaration, not confirmed leaks. Unsupported is included in unproved. A/R/V are finite security attempts, expected refusals, and policy violations. Exit zero does not turn an incomplete query sweep into complete business coverage. Seven apps exited zero for both commands; this concerns command exits only.','',
          '## Reassessment without rewriting history','']
for x in reassessments:
    lines += [f"**{x['app']}: {x['final_classification']}.**",'',x['prior_evidence_disposition']+' '+x['changed_evidence'],'',x['spec_explanation']+' '+x['action'],'']
lines += ['## Ordinary workflow provenance and boundary verification','',
          f"Reused {totals['retained_ordinary_case_passes']} earlier final ordinary-case passes plus {totals['retained_additional_case_passes']} additional passes; these were not rerun wholesale and are not presented as fresh current-candidate results. The retained sources match the final production schemas after only test-persona and blank-line normalization (apiary has one extra blank line). Each source hash and original command is retained in FINAL-RESULTS.json. The ordinary sources intentionally omit security.q so they test application enforcement independently of checker refutations.",'',
          f"New boundary probes: {totals['new_boundary_case_passes']} passes. These use the current application bodies with a clearly labeled added diagnosticStatus mutation absent from the app. Allotment verifies public cancel refuses an already overridden row, the old unchanged override write is E_RULE, the synthetic override-to-booked change commits, and entering override as a holder is E_RULE. Tow verifies public release checks, synthetic released-to-impounded commit, held release refusal at both operation and row boundary, and verified-claim enforcement after hold removal. These fixture-only snapshots and test-only mutations do not prove production operation-sequence reachability.",'',
          'No false runtime refusal was observed in the retained final ordinary cases or new boundary cases. This says nothing about untested legitimate workflows, including unmodeled parent/family access. Historical incorrect fixture expectations and original failing outputs remain in the archived evidence.','',
          '## Per-app SPEC and proof scope','']
for a in apps:
    lines += [f"**{a['app']}** — {a['declaration_hole_count']} uncovered effects; {a['test_not_covered_count']} distinct named test coverage limitations.",'']
    lines += ['- '+x for x in a['spec_scope_holes']]
    lines += ['']
lines += ['The unsupported expressions are farrier photos.read and apiary inspections.read: live parent/read-through hops lack a reduction. They remain declared. Full unproved reasons include observer/raw-probe, reference/existence, job, aggregate, temporal, paired-world and protocol paths; the JSON preserves all of them.','',
          'All ten fresh check and test outputs, source snapshots and command records are under [final-evidence](final-evidence/). The kiln now completes its whole-set check and test within this continuation\'s limits; its old timeouts remain historical evidence. No old timeout or incomplete result was converted to a pass.','']
(R/'FINAL-REPORT.md').write_text('\n'.join(lines))
print(json.dumps(dict(status=result['status'],totals=totals,preservation=result['preservation']),indent=2))
