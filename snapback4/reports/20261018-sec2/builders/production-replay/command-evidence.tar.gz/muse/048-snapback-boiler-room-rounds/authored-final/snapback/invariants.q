-- Invariants for 048 Boiler Room Rounds, from SPEC.
-- SPEC: engineers see rounds for own shift + live gauge history; contractors
-- see only serviced equipment; only chief changes gauge limits; manager sees
-- compliance reports but not individual readings; missed/out-of-range rounds
-- alert the chief.
-- Draft reviewed. One deliberate tightening: readings stay shift-scoped for
-- engineers (see below).

-- Roles: self + chief + operator. Chief by invite/upsert only.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'chief'] or viewer = 'service:ops'
invariant roles.insert only .principal = viewer and .role != 'chief' or exists roles[viewer, role = 'chief'] or viewer = 'service:ops'
invariant roles.update only exists roles[viewer, role = 'chief'] or viewer = 'service:ops'

-- Shifts: chief, manager, own members.
invariant shifts.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'manager'] or exists shiftMembers[.id, viewer]
invariant shifts.insert only exists roles[viewer, role = 'chief'] or viewer = 'service:ops'
invariant shifts.update only exists roles[viewer, role = 'chief']
invariant shiftMembers.read only .engineer = viewer or exists roles[viewer, role = 'chief']
invariant shiftMembers.insert only exists roles[viewer, role = 'chief'] or viewer = 'service:ops'
invariant shiftMembers.delete only exists roles[viewer, role = 'chief']

-- Gauges: chief, engineers, assigned contractors. Limits are chief-only.
invariant gauges.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'engineer'] or exists assignments[.id, viewer]
invariant gauges.insert only exists roles[viewer, role = 'chief']
invariant gauges.update only exists roles[viewer, role = 'chief']
invariant gauges.delete only exists roles[viewer, role = 'chief']
invariant assignments.read only .contractor = viewer or exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'engineer']
invariant assignments.insert only exists roles[viewer, role = 'chief']
invariant assignments.delete only exists roles[viewer, role = 'chief']

-- Rounds: chief, manager, own-shift engineers. Updates by shift member/chief.
invariant rounds.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'manager'] or exists shiftMembers[.shift, viewer]
invariant rounds.insert only exists roles[viewer, role = 'chief'] or viewer = 'service:ops'
invariant rounds.update only exists shiftMembers[.shift, viewer] or exists roles[viewer, role = 'chief']

-- Readings: SPEC scopes engineers to their own shift, so the engineer arm is
-- shift-scoped here (unlike the schema's all-engineers rule) to test that
-- over-broad grant. Contractors read only assigned gauges; chief reads all.
-- Managers read no readings (compliance query carries rounds only).
invariant readings.read only exists roles[viewer, role = 'chief'] or exists shiftMembers[.shift, viewer] or exists assignments[.gauge, viewer]
invariant readings.insert only .engineer = viewer and exists shiftMembers[.shift, viewer]

-- Alerts: chief reads/acks; engineers + chief raise.
invariant alerts.read only exists roles[viewer, role = 'chief']
invariant alerts.insert only exists roles[viewer, role = 'engineer'] or exists roles[viewer, role = 'chief']
invariant alerts.update only exists roles[viewer, role = 'chief']

-- Maintained count audience mirrors readers.
invariant readingsCount.read only exists roles[viewer, role = 'engineer'] or exists roles[viewer, role = 'chief']
