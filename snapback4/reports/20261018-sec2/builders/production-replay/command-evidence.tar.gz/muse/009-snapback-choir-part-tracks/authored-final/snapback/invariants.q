-- Invariants for 009 Choir Part Tracks, from SPEC.
-- SPEC: director uploads tracks; tracks visible to singers only on release
-- date, hidden a week after concert; singer sees only own part tracks + own
-- progress; leaders see section progress; director sees everything and moves
-- singers; attendance taken live by leaders, shown to director live.
-- Draft reviewed and confirmed; temporal window is carried by releases
-- lifetime bounds (not before / expire at) plus the releases-exists gate.

-- Roster: self + director + section leader of same part + bootstrap.
invariant roster.read only .principal = viewer or exists roster[viewer, role = 'director'] or exists roster[viewer, role = 'leader', part = .part] or viewer = 'service:bootstrap'
invariant roster.insert only viewer = 'service:bootstrap'
invariant roster.update only exists roster[viewer, role = 'director']

-- Concerts/pieces: director only (singers reach tracks via releases gate,
-- not via concert/piece rows).
invariant concerts.read only exists roster[viewer, role = 'director']
invariant concerts.insert only exists roster[viewer, role = 'director']
invariant pieces.read only exists roster[viewer, role = 'director']
invariant pieces.insert only exists roster[viewer, role = 'director']

-- Releases gate the temporal window; read is director or same-part singer.
invariant releases.read only exists roster[viewer, role = 'director'] or exists roster[viewer, part = .part]
invariant releases.insert only exists roster[viewer, role = 'director']

-- Tracks: director, or same-part singer while a release row exists (lifetime
-- bounds hide it outside [opensAt, endsAt)).
invariant tracks.read only exists roster[viewer, role = 'director'] or exists roster[viewer, part = .part] and exists releases[.id]
invariant tracks.insert only exists roster[viewer, role = 'director']

-- Progress: own, section leader, director. Insert/update by the singer.
invariant progress.read only .singer = viewer or exists roster[viewer, role = 'director'] or exists roster[viewer, role = 'leader', part = .part]
invariant progress.insert only .singer = viewer and .singer = roster[.member].principal and .part = roster[.member].part
invariant progress.update only .singer = viewer and .part = roster[.member].part or exists roster[viewer, role = 'director']

-- Rehearsals: any roster member reads; director creates.
invariant rehearsals.read only exists roster[viewer]
invariant rehearsals.insert only exists roster[viewer, role = 'director']

-- Attendance: director or section leader of that part. Writes by the
-- section leader of the member's part (live, window-checked in mutation).
invariant attendance.read only exists roster[viewer, role = 'director'] or exists roster[viewer, role = 'leader', part = .part]
invariant attendance.insert only exists roster[viewer, role = 'leader', part = .part] and .part = roster[.member].part and .singer = roster[.member].principal
invariant attendance.update only exists roster[viewer, role = 'director'] or exists roster[viewer, role = 'leader', part = .part] and .part = roster[.member].part
