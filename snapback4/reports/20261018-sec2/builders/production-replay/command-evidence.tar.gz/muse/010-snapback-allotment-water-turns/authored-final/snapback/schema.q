use identity password

-- Roster membership is provisioned by a trusted operator, never by signup.
table members:
  principal: principal
  role: enum('holder', 'committee', 'chair')
  plot: text 1..24
  unique principal
  unique plot
  read <- .principal = viewer or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  cap 200
  online only

table policy:
  key: text 1..12
  drought: bool
  unique key
  read <- exists members[viewer]
  insert <- viewer = 'service:ops'
  update <- exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
  cap 1
  online only

table bookings:
  owner: principal
  plot: text 1..24
  startsAt: time
  week: int
  bookedAt: time
  ordinal: int 1..10000
  unique owner, week, ordinal
  status: enum('booked', 'cancelled', 'drought', 'override')
  immutable owner, plot, startsAt, week, bookedAt, ordinal
  read <- .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
  insert <- .owner = viewer and exists members[viewer]
  update <- .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
  cap 10000
  online only

-- No owner, plot, booking timestamp, or creator is stored in the shared calendar.
table slots:
  booking: bookings
  startsAt: time
  unique startsAt else SLOT_TAKEN
  unique booking
  immutable booking, startsAt
  read <- exists members[viewer]
  insert <- exists members[viewer]
  delete <- exists members[viewer]
  cap 1000
  online only

table overrides:
  actor: principal
  booking: bookings
  owner: principal
  startsAt: time
  reason: text 5..300
  photo: image <=5000000
  at: time
  read <- exists members[viewer, role = 'chair']
  insert <- .actor = viewer and (exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'])
  cap 10000
  online only

mutation provision(principal: principal, role: enum('holder', 'committee', 'chair'), plot: text 1..24):
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert members { principal, role, plot }

mutation initialize():
  require viewer = 'service:ops' else NOT_OPERATOR
  return insert policy { key: 'water', drought: false }

query me():
  return members[principal = viewer]

query settings():
  require exists members[viewer] else NOT_MEMBER
  return { drought: policy[key = 'water'].drought, limit: 1 if policy[key = 'water'].drought = true else 3, now: now }

query calendar(from: time, until: time):
  require exists members[viewer] else NOT_MEMBER
  require until > from and until - from <= 35d else BAD_RANGE
  return slots where .startsAt >= from and .startsAt < until first 500 by .startsAt { id, booking, startsAt, endsAt: .startsAt + 2h }

query mine(c: cursor ?):
  require exists members[viewer] else NOT_MEMBER
  return bookings where .owner = viewer last 100 by .bookedAt after c

query booking(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.owner = viewer else PRIVATE_BOOKING
  return b

mutation book(startsAt: time):
  m = members[viewer] ! else NOT_MEMBER
  p = policy[key = 'water'] ! else NOT_READY
  require startsAt > now else TOO_LATE
  require startsAt <= now + 28d else TOO_FAR
  require startsAt % 2h = 0 else BAD_SLOT
  w = (day(startsAt) + 3) / 7
  n = count(bookings where .owner = viewer and .week = w and .status = 'booked')
  require n < (1 if p.drought else 3) else WEEKLY_LIMIT
  ordinal = count(bookings where .owner = viewer and .week = w) + 1
  b = insert bookings { owner: viewer, plot: m.plot, startsAt, week: w, bookedAt: now, ordinal, status: 'booked' }
  insert slots { booking: b.id, startsAt }
  return b

mutation cancel(booking: bookings):
  b = bookings[booking] ! else NOT_FOUND
  require b.owner = viewer else PRIVATE_BOOKING
  require b.startsAt > now else TOO_LATE
  require b.status = 'booked' else NOT_ACTIVE
  s = slots[booking = booking] ! else NOT_FOUND
  delete slots[s.id]
  update bookings[booking] { status: 'cancelled' }

mutation declareDrought(drought: bool):
  require exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'] else NOT_COMMITTEE
  update policy[key = 'water'] { drought }
  if drought:
    for b in bookings where .status = 'booked' first 10000 by .bookedAt:
      older = count(bookings where .owner = b.owner and .week = b.week and .status = 'booked' and .ordinal < b.ordinal)
      if older >= 1 and b.startsAt > now:
        s = slots[booking = b.id] ! else NOT_FOUND
        delete slots[s.id]
        update bookings[b.id] { status: 'drought' }

mutation override(booking: bookings, reason: text 5..300, photo: image <=5000000):
  require exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'] else NOT_COMMITTEE
  b = bookings[booking] ! else NOT_FOUND
  require b.startsAt > now else TOO_LATE
  require b.status = 'booked' else NOT_ACTIVE
  insert overrides { actor: viewer, booking, owner: b.owner, startsAt: b.startsAt, reason, photo, at: now }
  s = slots[booking = booking] ! else NOT_FOUND
  delete slots[s.id]
  update bookings[booking] { status: 'override' }
  return null

query audit(c: cursor ?):
  require exists members[viewer, role = 'chair'] else NOT_CHAIR
  return overrides last 100 by .at after c
