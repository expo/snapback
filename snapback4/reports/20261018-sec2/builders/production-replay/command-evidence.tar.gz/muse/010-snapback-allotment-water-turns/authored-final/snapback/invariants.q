-- Invariants for 010 Allotment Water Turns, from SPEC.
-- SPEC: shared calendar shows booked slots but not who booked; holders see own
-- bookings in full; only committee declares drought or overrides; chair sees
-- audit log of overrides with meter photos; 3/week halves to 1 in drought.
-- Draft reviewed and confirmed. Ambiguity recorded: slots carry no owner
-- identity by design; direct slots insert/delete authority is left as the
-- rule states (any member) since SPEC defines slots only via the booking
-- workflow and names no direct-write audience.

-- Roster: self + operator. Committee/chair are roles on this table.
invariant members.read only .principal = viewer or viewer = 'service:ops'
invariant members.insert only viewer = 'service:ops'

-- Policy: members read; committee/chair update.
invariant policy.read only exists members[viewer]
invariant policy.insert only viewer = 'service:ops'
invariant policy.update only exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']

-- Bookings: owner + committee/chair. Insert by the member holder.
invariant bookings.read only .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
invariant bookings.insert only .owner = viewer and exists members[viewer]
invariant bookings.update only .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']

-- Shared calendar: any member reads the anonymized slot rows.
invariant slots.read only exists members[viewer]
invariant slots.insert only exists members[viewer]
invariant slots.delete only exists members[viewer]

-- Overrides audit: chair reads; committee/chair write with photo evidence.
invariant overrides.read only exists members[viewer, role = 'chair']
-- Parenthesised to match the schema rule: the actor binding applies to both
-- committee and chair arms (without parens the chair arm would read ungated).
invariant overrides.insert only .actor = viewer and (exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'])
