-- Invariants for 045 Instrument Loan Bank, from SPEC.
-- SPEC: students/parents see only own loans; librarian sees every instrument
-- and checks out/in; only manager writes off or sees deposit records; repair
-- notes visible to librarian and manager only; season-end auto-close with
-- 14-day follow-up flag.
-- Draft reviewed. One deliberate tightening: repairNotes.read excludes the
-- luthier author (SPEC says "librarian and manager only").

-- Roles: self + manager + operator.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'manager']
invariant roles.insert only exists roles[viewer, role = 'manager'] or viewer = 'service:ops'
invariant roles.update only exists roles[viewer, role = 'manager']
invariant roles.delete only exists roles[viewer, role = 'manager']

-- Public catalog + season dates.
invariant instruments.read only allow
invariant instruments.insert only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant instruments.update only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant seasons.read only allow
invariant seasons.insert only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant seasons.update only exists roles[viewer, role = 'manager']

-- Loans: borrower + staff. Writes by librarian/manager.
-- Ambiguity recorded: SPEC says "students and parents see only their own
-- loans" but the schema links a loan to one borrower principal with no
-- parent-child delegation, so a parent cannot read a child's loan under this
-- invariant; no family-delegation audience is invented.
invariant loans.read only .borrower = viewer or exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans.insert only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans.update only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']

-- Deposits: manager only.
invariant deposits.read only exists roles[viewer, role = 'manager']
invariant deposits.insert only exists roles[viewer, role = 'manager']
invariant deposits.update only exists roles[viewer, role = 'manager']

-- Repair notes: SPEC-literal librarian + manager only (no luthier read arm).
invariant repairNotes.read only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant repairNotes.insert only .author = viewer and exists roles[viewer, role = 'luthier']
