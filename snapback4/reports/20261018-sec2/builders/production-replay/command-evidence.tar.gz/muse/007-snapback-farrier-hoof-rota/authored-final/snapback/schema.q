use identity password

table roles:
  principal: principal
  name: text 1..80
  role: enum('manager', 'farrier', 'owner')
  unique principal
  read <- .principal = viewer or exists roles[viewer, role = 'manager'] or viewer = 'service:ops'
  insert <- viewer = 'service:ops'
  update <- viewer = 'service:ops'
  online only

table horses:
  name: text 1..80
  manager: principal
  owner: principal
  farrier: principal
  cycleWeeks: int 3..12 default 6
  nextAt: time
  immutable manager, owner, farrier
  read <- .manager = viewer or .owner = viewer or .farrier = viewer
  insert <- .manager = viewer and exists roles[viewer, role = 'manager'] and exists roles[.owner, role = 'owner'] and exists roles[.farrier, role = 'farrier']
  update <- .manager = viewer or .farrier = viewer
  online only

table visits:
  horse: horses
  farrier: principal
  notes: text 1..4000
  at: time default now
  immutable horse, farrier, notes, at
  read through .horse
  insert <- .farrier = viewer and .horse.farrier = viewer
  online only

table photos:
  visit: visits
  photo: image <=5000000
  caption: text 1..160
  immutable visit, photo, caption
  read through .visit
  insert <- .visit.farrier = viewer
  online only

table quotes:
  horse: horses
  description: text 1..2000
  cents: int 1..1000000
  validUntil: time
  status: enum('open', 'approved', 'declined') default 'open'
  immutable horse, description, cents, validUntil
  read through .horse
  insert <- .horse.farrier = viewer and .status = 'open'
  update <- .horse.owner = viewer
  online only

table billing:
  horse: horses
  details: text 1..2000
  unique horse
  read <- .horse.manager = viewer
  insert <- .horse.manager = viewer
  update <- .horse.manager = viewer
  online only

table reminders:
  horse: horses
  to: principal
  dueAt: time
  at: time
  unique horse, dueAt
  read <- .to = viewer
  online only

query me():
  return roles[principal = viewer]
query directory(c: cursor ?):
  return roles first 100 by .id after c
query myHorses(c: cursor ?):
  return horses first 100 by .id after c
query horse(horse: horses):
  return horses[horse]
query dueSoon(c: cursor ?):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  return horses where .manager = viewer and .nextAt <= now + 7d first 100 by .id after c
query visitHistory(horse: horses, c: cursor ?):
  h = horses[horse] ! else NOT_FOUND
  return visits where .horse = horse last 100 by .at after c
query visitPhotos(visit: visits, c: cursor ?):
  v = visits[visit] ! else NOT_FOUND
  return photos where .visit = visit first 100 by .id after c
query horseQuotes(horse: horses, c: cursor ?):
  h = horses[horse] ! else NOT_FOUND
  return quotes where .horse = horse first 100 by .id after c
query billingFor(horse: horses):
  require exists horses[horse, manager = viewer] else NOT_MANAGER
  return billing[horse = horse]
query myReminders(c: cursor ?):
  return reminders where .to = viewer last 100 by .at after c

mutation grant(who: principal, name: text 1..80, role: enum('manager', 'farrier', 'owner')):
  require viewer = 'service:ops' else NOT_OPS
  return upsert roles[principal = who] { principal: who, name, role }
mutation addHorse(name: text 1..80, owner: principal, farrier: principal, cycleWeeks: int 3..12, nextAt: time):
  require exists roles[viewer, role = 'manager'] else NOT_MANAGER
  require nextAt > now else IN_THE_PAST
  return insert horses { name, manager: viewer, owner, farrier, cycleWeeks, nextAt }
mutation bookCycle(horse: horses, cycleWeeks: int 3..12, nextAt: time):
  h = horses[horse] ! else NOT_FOUND
  require h.manager = viewer else NOT_MANAGER
  require nextAt > now else IN_THE_PAST
  update horses[horse] { cycleWeeks, nextAt }
mutation recordVisit(horse: horses, notes: text 1..4000):
  h = horses[horse] ! else NOT_FOUND
  require h.farrier = viewer else NOT_FARRIER
  require now >= h.nextAt else TOO_EARLY
  v = insert visits { horse, farrier: viewer, notes }
  update horses[horse] { nextAt: now + h.cycleWeeks * 7d }
  return v
mutation addPhoto(visit: visits, photo: image <=5000000, caption: text 1..160):
  v = visits[visit] ! else NOT_FOUND
  require v.farrier = viewer else NOT_FARRIER
  return insert photos { visit, photo, caption }
mutation proposeQuote(horse: horses, description: text 1..2000, cents: int 1..1000000, validUntil: time):
  h = horses[horse] ! else NOT_FOUND
  require h.farrier = viewer else NOT_FARRIER
  require validUntil > now else EXPIRED
  require validUntil <= h.nextAt else AFTER_APPOINTMENT
  return insert quotes { horse, description, cents, validUntil }
mutation answerQuote(quote: quotes, approve: bool):
  q = quotes[quote] ! else NOT_FOUND
  require exists horses[q.horse, owner = viewer] else NOT_OWNER
  require q.status = 'open' else ALREADY_ANSWERED
  require now < q.validUntil else EXPIRED
  update quotes[quote] { status: 'approved' if approve else 'declined' }
mutation saveBilling(horse: horses, details: text 1..2000):
  require exists horses[horse, manager = viewer] else NOT_MANAGER
  return upsert billing[horse = horse] { horse, details }

job remindOwners(periodStart: time, periodEnd: time):
  for h in horses by .id:
    if h.nextAt > periodEnd and h.nextAt <= periodEnd + 2d:
      if not exists reminders[horse = h.id, dueAt = h.nextAt]:
        insert reminders { horse: h.id, to: h.owner, dueAt: h.nextAt, at: periodEnd }
schedule hourly every 1h: remindOwners
