-- Invariants for 007 Farrier Hoof Rota, from SPEC.
-- SPEC: owners see only own horses' records, approve/decline corrective quotes;
-- farrier sees every horse booked with them but not billing; only manager sees
-- billing; due-within-week on manager list; 2-day reminder automatic.
-- Draft reviewed; roles.read allow is NOT accepted (see below).

-- Roster: SPEC implies a private roster (owners see only own records).
-- The schema's universal read + open directory query over-expose it, so the
-- invariant is restrictive to catch that. Operator seat retained for grants.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'manager'] or viewer = 'service:ops'
invariant roles.insert only viewer = 'service:ops'
invariant roles.update only viewer = 'service:ops'

-- Horses: manager (own book), owner (own), farrier (booked with them).
invariant horses.read only .manager = viewer or .owner = viewer or .farrier = viewer
invariant horses.insert only .manager = viewer and exists roles[viewer, role = 'manager'] and exists roles[.owner, role = 'owner'] and exists roles[.farrier, role = 'farrier']
-- Update stays as rule (manager or farrier); farrier needs it for recordVisit
-- nextAt rotation. Field-level ownership changes are a mutation concern.
invariant horses.update only .manager = viewer or .farrier = viewer

-- Child audiences delegate to the readable parent (caller-filtered exists):
-- a visit/photo/quote is readable iff its horse/visit is readable, and the
-- horse read rule carries the SPEC audience above.
invariant visits.read only exists horses[.horse]
invariant visits.insert only .farrier = viewer and horses[.horse].farrier = viewer
invariant photos.read only exists visits[.visit]
invariant photos.insert only visits[.visit].farrier = viewer
invariant quotes.read only exists horses[.horse]
invariant quotes.insert only horses[.horse].farrier = viewer and .status = 'open'
invariant quotes.update only horses[.horse].owner = viewer

-- Billing: manager only (farrier explicitly excluded by SPEC).
invariant billing.read only exists horses[.horse, manager = viewer]
invariant billing.insert only horses[.horse].manager = viewer
invariant billing.update only horses[.horse].manager = viewer

-- Reminders: recipient only.
invariant reminders.read only .to = viewer
