-- Invariants for 021 Moot Court Scoring, from SPEC + schema header.
-- SPEC: briefs uploaded before deadline then locked; judges score live, hidden
-- from each other until close; students see only own team's scores after close
-- (numbers only via student query); coaches see team scores + comments; only
-- director changes brackets / disqualifies.
-- Draft reviewed. Two deliberate tightenings: profiles directory and the
-- student scores read (see below).

-- Tournament setup: creator is first director; directors manage the rest.
invariant tournaments.read only exists directors[viewer] or exists judges[viewer] or exists coaches[viewer] or exists members[viewer]
invariant tournaments.insert only .director = viewer
invariant tournaments.update only exists directors[viewer]

-- Role rosters: self-read; directors manage.
invariant directors.read only .principal = viewer
invariant directors.insert only exists directors[viewer] or created tournaments[.tournament]
invariant directors.delete only exists directors[viewer]
invariant judges.read only .principal = viewer
invariant judges.insert only exists directors[viewer]
invariant judges.delete only exists directors[viewer]
invariant coaches.read only .principal = viewer
invariant coaches.insert only exists directors[viewer]
invariant coaches.delete only exists directors[viewer]

-- Teams/membership: students are members; coach + directors manage.
invariant members.read only .student = viewer or exists teams[.team, coach = viewer] or exists directors[viewer]
invariant members.insert only exists directors[viewer]
invariant members.delete only exists directors[viewer]
invariant teams.read only exists directors[viewer] or exists judges[viewer] or exists coaches[viewer] or exists members[viewer]
invariant teams.insert only exists directors[viewer]
invariant teams.update only exists directors[viewer]
invariant teams.delete only exists directors[viewer]

-- Rounds: same audience; directors manage.
invariant rounds.read only exists directors[viewer] or exists judges[viewer] or exists coaches[viewer] or exists members[viewer]
invariant rounds.insert only exists directors[viewer]
invariant rounds.update only exists directors[viewer]
invariant rounds.delete only exists directors[viewer]
invariant roundTeams.read only exists directors[viewer] or exists judges[viewer] or exists coaches[viewer] or exists members[viewer]
invariant roundTeams.insert only exists directors[viewer]
invariant roundTeams.delete only exists directors[viewer]

-- Briefs: own-team students, team coach, judges, directors.
invariant briefs.read only exists directors[viewer] or exists judges[viewer] or exists members[.team, viewer] or exists teams[.team, coach = viewer]
invariant briefs.insert only exists members[.team, viewer]
invariant briefs.update only exists members[.team, viewer]

-- Scores: a judge reads own rows; everyone else (other judges, team
-- students, team coach) only after the round closes; directors always.
-- Student comment hiding is enforced by the student query shape + scoreDetail
-- projection, not by this row invariant.
invariant scores.read only .judge = viewer or exists directors[viewer] or exists rounds[.round, status = 'closed'] and exists judges[viewer] or exists members[.team, viewer] or exists teams[.team, coach = viewer]
invariant scores.insert only .judge = viewer and exists judges[viewer]
invariant scores.update only .judge = viewer and exists judges[viewer]
invariant scores.delete only exists directors[viewer]

-- Profiles directory: SPEC's stated purpose is director discovery for grants,
-- so the invariant is director-only. The schema's all-roles read is
-- deliberately tighter here to test that over-exposure.
invariant profiles.read only exists directors[viewer]
invariant profiles.insert only .owner = viewer
invariant profiles.update only .owner = viewer
