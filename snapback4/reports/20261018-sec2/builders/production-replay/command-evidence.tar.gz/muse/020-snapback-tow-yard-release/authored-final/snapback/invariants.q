-- Invariants for 020 Tow Yard Release, from SPEC + schema header.
-- SPEC: owners see only own vehicle/fees; clerks + manager see every vehicle;
-- liaison sees only held vehicles (hold blocks release); only manager waives.
-- Intake photos required (optional list form permits omission only when no
-- photos supplied); 30-day auction sweep; verified claim gates release.
-- Draft reviewed and confirmed.

-- Roster: self + clerks/manager + operator. Self-registration is owner-only.
invariant roster.read only .principal = viewer or exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager'] or viewer = 'service:ops'
invariant roster.insert only .principal = viewer and .role = 'owner' or exists roster[viewer, role = 'manager'] or viewer = 'service:ops'
invariant roster.update only exists roster[viewer, role = 'manager'] or viewer = 'service:ops'

-- Vehicles: owner, clerks/manager, liaison on held rows only.
invariant vehicles.read only .owner = viewer or exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager'] or .onHold = true and exists roster[viewer, role = 'liaison']
invariant vehicles.insert only exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager']
invariant vehicles.update only exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager'] or exists roster[viewer, role = 'liaison']

-- Claims: claimant + staff. Insert by the claimant; staff decide.
invariant claims.read only .claimant = viewer or exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager']
invariant claims.insert only .claimant = viewer
invariant claims.update only exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager']

-- Waivers: manager writes; reads are the author, the vehicle owner, staff.
invariant waivers.read only .waivedBy = viewer or exists vehicles[.vehicle, owner = viewer] or exists roster[viewer, role = 'clerk'] or exists roster[viewer, role = 'manager']
invariant waivers.insert only exists roster[viewer, role = 'manager']
