invariant firingLoads.delete only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
