-- Invariants for 005 Kiln Firing Queue, from SPEC.
-- SPEC: members see only their own pieces + the public queue length; kiln
-- techs see every piece; only the studio manager can cancel another member's
-- piece or change membership firing limits; pieces lock once firing starts;
-- uncollected 21d flagged for donation.
-- Draft reviewed; the single generated delete draft is kept, the missing
-- SPEC audiences below are added (N_SECURITY_INTENT named firings,
-- memberships, pieces, publicQueue).

-- Roster: self + manager + trusted operator. Ordinary signup joins as member.
invariant memberships.read only .principal = viewer or exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'
-- Only the manager changes firing limits (changeLimit requires manager).
invariant memberships.firingLimit write only exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'

-- Firings: techs + manager only (members follow their own pieces' status).
invariant firings.read only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firings.insert only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firings.update only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']

-- Pieces: owner + techs + manager. Insert by the owning member.
invariant pieces.read only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant pieces.insert only .owner = viewer and exists memberships[viewer]
invariant pieces.update only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']

-- Loads: owner + techs + manager; techs/manager staff the kiln.
invariant firingLoads.read only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firingLoads.insert only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
-- Delete stays owner-or-staff: cancelPiece lets an owner cancel their own
-- piece (manager-only applies to ANOTHER member's piece, enforced in that
-- mutation's require, not at this table effect).
invariant firingLoads.delete only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']

-- The shared queue length is public by design; never member rows.
invariant publicQueue.read only allow
