-- Invariants for 019 Apiary Hive Inspections, from SPEC + schema header.
-- SPEC: landowners see only hives on their land; inspectors see hives on
-- their assigned route; only lead marks requeen/quarantine (hides listing);
-- mite > 3 alerts owner + lead; 14-day in-season flag; frame photos + queen
-- status + mite counts per inspection.
-- Draft reviewed and confirmed; honey listings are public by design.

-- Roles: self + lead + operator.
invariant roles.read only .principal = viewer or exists roles[viewer, role = 'lead']
invariant roles.insert only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
invariant roles.update only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
invariant roles.delete only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'

-- Routes: inspector + lead + operator.
invariant routes.read only .inspector = viewer or exists roles[viewer, role = 'lead']
invariant routes.insert only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
invariant routes.delete only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'

-- Hives: landowner, route inspector, lead.
invariant hives.read only .landOwner = viewer or exists routes[viewer, .route] or exists roles[viewer, role = 'lead']
invariant hives.insert only exists roles[viewer, role = 'lead'] or viewer = 'service:ops'
invariant hives.update only exists routes[viewer, .route] or exists roles[viewer, role = 'lead']
invariant hives.delete only exists roles[viewer, role = 'lead']

-- Inspections/alerts delegate to the readable hive; writes by the inspector.
invariant inspections.read only exists hives[.hive]
invariant inspections.insert only .inspector = viewer
invariant alerts.read only .owner = viewer or exists roles[viewer, role = 'lead']
invariant alerts.insert only .inspector = viewer

-- Public honey listings; flagged hives hold no row (enforced in mutations).
invariant listings.read only allow
invariant listings.insert only .owner = viewer
invariant listings.update only .owner = viewer
invariant listings.delete only .owner = viewer or exists roles[viewer, role = 'lead']
