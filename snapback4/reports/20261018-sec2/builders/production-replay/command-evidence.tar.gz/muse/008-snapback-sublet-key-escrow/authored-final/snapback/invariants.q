-- Invariants for 008 Sublet Key Escrow, from SPEC.
-- SPEC: leaseholders/subtenants see only own listings/bookings, never each
-- other's ID docs; office staff see every sublet; only manager cancels signed;
-- key releases only on start date after both signatures + ID proof; return by
-- end date or flagged overdue.
-- Draft reviewed and confirmed except where noted.

-- Roster: self + office + trusted provisioner. No end-user self-enrollment.
invariant people.read only .principal = viewer or viewer = 'service:provision' or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant people.insert only viewer = 'service:provision'
invariant people.update only exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']

-- Listings: matched room visible only to its leaseholder, assigned subtenant,
-- and office. Insert by leaseholder self.
invariant listings.read only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant listings.insert only .leaseholder = viewer and exists people[viewer, role = 'leaseholder']
invariant listings.update only exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']

-- Bookings: parties + office. Insert by vetted assigned subtenant.
-- Update stays broad at table level; "only manager cancels a signed sublet"
-- is a mutation-level workflow property (cancelBooking) covered by tests.
invariant bookings.read only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant bookings.insert only .subtenant = viewer and exists people[viewer, role = 'subtenant', vetted = true] and .leaseholder = listings[.listing].leaseholder and listings[.listing].subtenant = viewer
invariant bookings.update only .leaseholder = viewer or .subtenant = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']

-- ID documents: uploader (subtenant) + office only. Leaseholders and other
-- subtenants never read each other's docs. Insert by the subtenant party.
invariant idDocuments.read only .owner = viewer or exists people[viewer, role = 'staff'] or exists people[viewer, role = 'manager']
invariant idDocuments.insert only .owner = viewer and bookings[.booking].subtenant = viewer
