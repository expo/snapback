-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant bookings.read only .owner = viewer or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
invariant bookings.insert only .owner = viewer and exists members[viewer]
invariant slots.read only exists members[viewer]
invariant policy.update only exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
invariant overrides.read only exists members[viewer, role = 'chair']
invariant overrides.insert only .actor = viewer and (exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair'])
invariant overrides always .photo != null
invariant bookings.status write only .status != 'override' or exists members[viewer, role = 'committee'] or exists members[viewer, role = 'chair']
