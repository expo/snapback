-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant scores.read only .judge = viewer or exists directors[viewer] or (exists rounds[.round, status = 'closed'] and (exists judges[viewer] or exists members[.team, viewer] or exists teams[.team, coach = viewer]))
invariant scores.insert only .judge = viewer and exists judges[viewer]
invariant scores.update only .judge = viewer and exists judges[viewer]
invariant teams.insert only exists directors[viewer]
invariant teams.update only exists directors[viewer]
invariant teams.delete only exists directors[viewer]
invariant rounds.update only exists directors[viewer]
invariant briefs.read only exists directors[viewer] or exists judges[viewer] or exists members[.team, viewer] or exists teams[.team, coach = viewer]
invariant briefs.insert only exists members[.team, viewer]
invariant briefs.update only exists members[.team, viewer]
invariant directors.insert only exists directors[viewer] or viewer = 'service:ops'
invariant tournaments.insert only exists directors[viewer] or viewer = 'service:ops'
