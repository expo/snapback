-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant horses.read only .owner = viewer or .manager = viewer or .farrier = viewer
invariant visits.read only exists horses[.horse, owner = viewer] or exists horses[.horse, manager = viewer] or exists horses[.horse, farrier = viewer]
invariant photos.read only exists horses[.visit.horse, owner = viewer] or exists horses[.visit.horse, manager = viewer] or exists horses[.visit.horse, farrier = viewer]
invariant billing.read only exists horses[.horse, manager = viewer]
invariant billing.insert only exists horses[.horse, manager = viewer]
invariant billing.update only exists horses[.horse, manager = viewer]
invariant visits.insert only .farrier = viewer and .horse.farrier = viewer
invariant photos.insert only .visit.farrier = viewer
invariant photos always .photo != null
invariant quotes.read only exists horses[.horse, owner = viewer] or exists horses[.horse, manager = viewer] or exists horses[.horse, farrier = viewer]
invariant quotes.update only .horse.owner = viewer
invariant reminders.read only .to = viewer
