-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant tracks.read only exists roster[principal = viewer, role = 'director'] or (exists roster[principal = viewer, part = .part] and exists releases[track = .id])
invariant tracks.insert only exists roster[principal = viewer, role = 'director']
invariant tracks always .audio != null
invariant progress.read only .singer = viewer or exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
invariant progress.insert only .singer = viewer and .singer = .member.principal and .part = .member.part
invariant progress.update only .singer = viewer or exists roster[principal = viewer, role = 'director']
invariant roster.update only exists roster[principal = viewer, role = 'director']
invariant attendance.read only exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
invariant attendance.insert only exists roster[principal = viewer, role = 'leader', part = .part]
invariant attendance.update only exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
invariant concerts.insert only exists roster[principal = viewer, role = 'director']
invariant releases.insert only exists roster[principal = viewer, role = 'director']
