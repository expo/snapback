use identity password

table roster:
  principal: principal
  name: text 1..80
  role: enum('director', 'leader', 'singer')
  part: enum('Soprano', 'Alto', 'Tenor', 'Bass')
  unique principal
  immutable principal, role, name
  read <- .principal = viewer or exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part] or viewer = 'service:bootstrap'
  insert <- viewer = 'service:bootstrap'
  update <- exists roster[principal = viewer, role = 'director']
  online only

table concerts:
  title: text 1..100
  releaseAt: time
  concertAt: time
  immutable title, releaseAt, concertAt
  read <- exists roster[principal = viewer, role = 'director']
  insert <- exists roster[principal = viewer, role = 'director']
  online only

table pieces:
  concert: concerts
  title: text 1..100
  immutable concert, title
  read <- exists roster[principal = viewer, role = 'director']
  insert <- exists roster[principal = viewer, role = 'director']
  online only

table releases:
  track: tracks
  part: enum('Soprano', 'Alto', 'Tenor', 'Bass')
  opensAt: time
  endsAt: time
  unique track
  immutable track, part, opensAt, endsAt
  not before .opensAt
  expire at .endsAt
  read <- exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, part = .part]
  insert <- exists roster[principal = viewer, role = 'director']
  online only

table tracks:
  piece: pieces
  title: text 1..100
  part: enum('Soprano', 'Alto', 'Tenor', 'Bass')
  audio: file <=50000000 ('audio/wav', 'audio/mpeg', 'audio/flac')
  unique piece, part
  immutable piece, title, part, audio
  read <- exists roster[principal = viewer, role = 'director'] or (exists roster[principal = viewer, part = .part] and exists releases[track = .id])
  insert <- exists roster[principal = viewer, role = 'director']
  online only

table progress:
  member: roster
  singer: principal
  part: enum('Soprano', 'Alto', 'Tenor', 'Bass')
  piece: pieces
  title: text 1..100
  learned: bool
  unique singer, piece
  immutable member, singer, piece, title
  cap 2000 by member
  read <- .singer = viewer or exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
  insert <- .singer = viewer and .singer = .member.principal and .part = .member.part
  update <- (.singer = viewer and .part = .member.part) or exists roster[principal = viewer, role = 'director']
  online only

table rehearsals:
  title: text 1..100
  startsAt: time
  endsAt: time
  immutable title, startsAt, endsAt
  read <- exists roster[principal = viewer]
  insert <- exists roster[principal = viewer, role = 'director']
  online only

table attendance:
  rehearsal: rehearsals
  member: roster
  singer: principal
  name: text 1..80
  part: enum('Soprano', 'Alto', 'Tenor', 'Bass')
  present: bool
  markedBy: principal
  unique rehearsal, member
  immutable rehearsal, member, singer, name
  cap 2000 by member
  read <- exists roster[principal = viewer, role = 'director'] or exists roster[principal = viewer, role = 'leader', part = .part]
  insert <- exists roster[principal = viewer, role = 'leader', part = .part] and .part = .member.part and .singer = .member.principal
  update <- exists roster[principal = viewer, role = 'director'] or (exists roster[principal = viewer, role = 'leader', part = .part] and .part = .member.part)
  online only

mutation provision(principal: principal, name: text 1..80, role: enum('director', 'leader', 'singer'), part: enum('Soprano', 'Alto', 'Tenor', 'Bass')):
  require viewer = 'service:bootstrap' else FORBIDDEN
  return insert roster { principal, name, role, part }

query me():
  return roster[principal = viewer]
query members(c: cursor ?):
  m = roster[principal = viewer] ! else FORBIDDEN
  if m.role = 'director':
    return roster first 100 by .id after c
  if m.role = 'leader':
    return roster where .part = m.part first 100 by .id after c
  return roster where .principal = viewer first 100 by .id after c
query member(member: roster):
  return roster[member]
query concerts(c: cursor ?):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  return concerts first 100 by .id after c
query pieces(concert: concerts, c: cursor ?):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  return pieces where .concert = concert first 100 by .id after c
query tracks(c: cursor ?):
  m = roster[principal = viewer] ! else FORBIDDEN
  if m.role = 'director':
    return tracks first 100 by .id after c
  return tracks where .part = m.part first 100 by .id after c
query track(track: tracks):
  return tracks[track]
query progress(c: cursor ?):
  m = roster[principal = viewer] ! else FORBIDDEN
  if m.role = 'director':
    return progress first 100 by .id after c
  if m.role = 'leader':
    return progress where .part = m.part first 100 by .id after c
  return progress where .singer = viewer first 100 by .id after c
query progressRecord(singer: principal, piece: pieces):
  return progress[singer, piece]
query rehearsals(c: cursor ?):
  return rehearsals first 100 by .id after c
query attendance(rehearsal: rehearsals, c: cursor ?):
  m = roster[principal = viewer] ! else FORBIDDEN
  if m.role = 'director':
    return attendance where .rehearsal = rehearsal first 100 by .id after c
  require m.role = 'leader' else FORBIDDEN
  return attendance where .rehearsal = rehearsal and .part = m.part first 100 by .id after c
query attendanceRecord(rehearsal: rehearsals, member: roster):
  return attendance[rehearsal, member]

mutation createConcert(title: text 1..100, releaseAt: time, concertAt: time):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  require releaseAt <= concertAt else BAD_DATES
  return insert concerts { title, releaseAt, concertAt }
mutation createPiece(concert: concerts, title: text 1..100):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  require exists concerts[concert] else NOT_FOUND
  return insert pieces { concert, title }
mutation uploadTrack(piece: pieces, part: enum('Soprano', 'Alto', 'Tenor', 'Bass'), audio: file <=50000000 ('audio/wav', 'audio/mpeg', 'audio/flac')):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  p = pieces[piece] ! else NOT_FOUND
  c = concerts[p.concert] ! else NOT_FOUND
  require now < c.concertAt + 7d else EXPIRED
  t = insert tracks { piece, title: p.title, part, audio }
  insert releases { track: t.id, part, opensAt: c.releaseAt, endsAt: c.concertAt + 7d }
  return t
mutation setLearned(track: tracks, learned: bool):
  m = roster[principal = viewer] ! else FORBIDDEN
  require m.role != 'director' else FORBIDDEN
  t = tracks[track] ! else NOT_FOUND
  require t.part = m.part else WRONG_PART
  require exists releases[track = track] else NOT_RELEASED
  return upsert progress[singer = viewer, piece = t.piece] { member: m.id, singer: viewer, part: m.part, piece: t.piece, title: t.title, learned }
mutation moveSinger(member: roster, part: enum('Soprano', 'Alto', 'Tenor', 'Bass')):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  m = roster[member] ! else NOT_FOUND
  require m.role != 'director' else NOT_SINGER
  update roster[member] { part }
  for p in progress where .member = member and .part = m.part and .singer = m.principal:
    update progress[p.id] { part }
  for a in attendance where .member = member and .part = m.part:
    update attendance[a.id] { part }
  return roster[member]
mutation createRehearsal(title: text 1..100, startsAt: time, endsAt: time):
  require exists roster[principal = viewer, role = 'director'] else FORBIDDEN
  require startsAt < endsAt and endsAt - startsAt <= 12h else BAD_DATES
  return insert rehearsals { title, startsAt, endsAt }
mutation markAttendance(rehearsal: rehearsals, member: roster, present: bool):
  r = rehearsals[rehearsal] ! else NOT_FOUND
  require now >= r.startsAt and now < r.endsAt else REHEARSAL_CLOSED
  m = roster[member] ! else NOT_FOUND
  require exists roster[principal = viewer, role = 'leader', part = m.part] else FORBIDDEN
  require m.role != 'director' else NOT_SINGER
  return upsert attendance[rehearsal, member] { rehearsal, member, singer: m.principal, name: m.name, part: m.part, present, markedBy: viewer }
