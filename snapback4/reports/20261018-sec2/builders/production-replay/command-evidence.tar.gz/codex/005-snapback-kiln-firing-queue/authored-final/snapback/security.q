-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant pieces.read only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant pieces.insert only .owner = viewer and exists memberships[viewer]
invariant pieces.update only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant pieces always .photo != null
invariant firingLoads.read only .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firings.insert only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant firings.update only exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
invariant memberships.update only exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'
invariant pieces.status write only .status != 'cancelled' or .owner = viewer or exists memberships[viewer, role = 'manager']
