use identity password

-- Trusted operator provisions staff; ordinary signup can only join as member.
table memberships:
  principal: principal
  name: text 1..60
  role: enum('member', 'tech', 'manager')
  firingLimit: int 1..30 default 5
  unique principal
  immutable principal
  read <- .principal = viewer or exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'
  insert <- (.principal = viewer and .role = 'member' and .firingLimit = 5) or viewer = 'service:ops'
  update <- exists memberships[viewer, role = 'manager'] or viewer = 'service:ops'
  online only

table firings:
  kiln: enum('Amber', 'Birch', 'Cinder')
  cone: enum('06', '04', '5', '6', '10')
  stage: enum('loading', 'firing', 'cooling', 'unloaded') default 'loading'
  startedAt: time ?
  unloadedAt: time ?
  createdAt: time default now
  immutable kiln, cone, createdAt
  read <- exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  insert <- exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  update <- exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  online only

table pieces:
  owner: principal
  title: text 1..80
  photo: image <=5000000
  clay: enum('earthenware', 'stoneware', 'porcelain')
  cone: enum('06', '04', '5', '6', '10')
  status: enum('queued', 'loaded', 'firing', 'cooling', 'ready', 'collected', 'cancelled', 'donation') default 'queued'
  firing: firings ?
  kiln: enum('Amber', 'Birch', 'Cinder') ?
  submittedAt: time default now
  unloadedAt: time ?
  immutable owner, submittedAt
  read <- .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  insert <- .owner = viewer and exists memberships[viewer]
  update <- .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  online only

table firingLoads:
  firing: firings
  piece: pieces
  owner: principal
  unique piece
  cap 30 by firing
  immutable firing, piece, owner
  read <- .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  insert <- exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  delete <- .owner = viewer or exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager']
  online only

-- Only this aggregate is shared with other members, never their rows.
view publicQueue: count pieces where .status = 'queued'
  public 'Only the total queue length is shared.'
  online only

query me():
  return memberships[viewer]
query membership(who: principal):
  return memberships[who]
query queueLength():
  return publicQueue
query myPieces(c: cursor ?):
  return pieces where .owner = viewer last 50 by .submittedAt after c
query piece(piece: pieces):
  return pieces[piece]
query studioQueue(c: cursor ?):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  return pieces last 100 by .submittedAt after c
query firingBoard(c: cursor ?):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  return firings last 50 by .createdAt after c
query studioMembers(c: cursor ?):
  require exists memberships[viewer, role = 'manager'] else MANAGER_ONLY
  return memberships first 100 by .id after c

mutation joinStudio(name: text 1..60):
  require not exists memberships[viewer] else ALREADY_MEMBER
  return insert memberships { principal: viewer, name, role: 'member', firingLimit: 5 }
mutation provision(who: principal, name: text 1..60, role: enum('member', 'tech', 'manager')):
  require viewer = 'service:ops' else OPERATOR_ONLY
  return upsert memberships[who] { principal: who, name, role }
mutation changeLimit(who: principal, firingLimit: int 1..30):
  require exists memberships[viewer, role = 'manager'] else MANAGER_ONLY
  update memberships[who] { firingLimit }
mutation submitPiece(title: text 1..80, photo: image <=5000000, clay: enum('earthenware', 'stoneware', 'porcelain'), cone: enum('06', '04', '5', '6', '10')):
  member = memberships[viewer] ! else JOIN_FIRST
  active = count(pieces where .owner = viewer and .status != 'cancelled' and .status != 'collected' and .status != 'donation')
  require active < member.firingLimit else FIRING_LIMIT 'Collect an existing piece or ask a manager about your limit.'
  return insert pieces { owner: viewer, title, photo, clay, cone }
mutation editPiece(piece: pieces, title: text 1..80, clay: enum('earthenware', 'stoneware', 'porcelain'), cone: enum('06', '04', '5', '6', '10')):
  p = pieces[piece] ! else NOT_FOUND
  require p.owner = viewer else OWNER_ONLY
  require p.status = 'queued' or p.status = 'loaded' else PIECE_LOCKED
  if p.firing != null:
    require cone = p.cone else CONE_LOCKED 'Unload this piece before changing its cone.'
  update pieces[piece] { title, clay, cone }
mutation cancelPiece(piece: pieces):
  p = pieces[piece] ! else NOT_FOUND
  require p.owner = viewer or exists memberships[viewer, role = 'manager'] else MANAGER_ONLY
  require p.status = 'queued' or p.status = 'loaded' else PIECE_LOCKED
  if exists firingLoads[piece = piece]:
    delete firingLoads[piece = piece]
  update pieces[piece] { status: 'cancelled', firing: null, kiln: null }
mutation createFiring(kiln: enum('Amber', 'Birch', 'Cinder'), cone: enum('06', '04', '5', '6', '10')):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  require count(firings where .kiln = kiln and .stage != 'unloaded') = 0 else KILN_BUSY
  return insert firings { kiln, cone }
mutation loadPiece(piece: pieces, firing: firings):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  p = pieces[piece] ! else NOT_FOUND
  f = firings[firing] ! else NOT_FOUND
  require f.stage = 'loading' else FIRING_LOCKED
  require p.status = 'queued' else PIECE_NOT_QUEUED
  require p.cone = f.cone else CONE_MISMATCH
  require count(firingLoads where .firing = firing) < 30 else KILN_FULL
  insert firingLoads { firing, piece, owner: p.owner }
  update pieces[piece] { firing, kiln: f.kiln, status: 'loaded' }
mutation removeFromLoad(piece: pieces):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  p = pieces[piece] ! else NOT_FOUND
  require p.status = 'loaded' else PIECE_LOCKED
  delete firingLoads[piece = piece]
  update pieces[piece] { firing: null, kiln: null, status: 'queued' }
mutation startFiring(firing: firings):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  f = firings[firing] ! else NOT_FOUND
  require f.stage = 'loading' else FIRING_LOCKED
  require count(firingLoads where .firing = firing) > 0 else EMPTY_FIRING
  update firings[firing] { stage: 'firing', startedAt: now }
  for load in firingLoads where .firing = firing:
    update pieces[load.piece] { status: 'firing' }
mutation beginCooling(firing: firings):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  f = firings[firing] ! else NOT_FOUND
  require f.stage = 'firing' else WRONG_STAGE
  update firings[firing] { stage: 'cooling' }
  for load in firingLoads where .firing = firing:
    update pieces[load.piece] { status: 'cooling' }
mutation unloadFiring(firing: firings):
  require exists memberships[viewer, role = 'tech'] or exists memberships[viewer, role = 'manager'] else STAFF_ONLY
  f = firings[firing] ! else NOT_FOUND
  require f.stage = 'cooling' else WRONG_STAGE
  update firings[firing] { stage: 'unloaded', unloadedAt: now }
  for load in firingLoads where .firing = firing:
    update pieces[load.piece] { status: 'ready', unloadedAt: now }
mutation collectPiece(piece: pieces):
  p = pieces[piece] ! else NOT_FOUND
  require p.owner = viewer else OWNER_ONLY
  require p.status = 'ready' else NOT_READY
  require p.unloadedAt != null and now < p.unloadedAt + 21d else DONATION_DUE
  update pieces[piece] { status: 'collected' }

job flagDonations():
  for p in pieces:
    if p.status = 'ready' and p.unloadedAt != null and now >= p.unloadedAt + 21d:
      update pieces[p.id] { status: 'donation' }
schedule donationShelf every 1m: flagDonations
