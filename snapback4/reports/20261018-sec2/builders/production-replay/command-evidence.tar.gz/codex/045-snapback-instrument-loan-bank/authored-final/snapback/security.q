-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant loans.read only .borrower = viewer or exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans.insert only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans.update only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant loans always .checkoutPhoto != null
invariant loans always .status != 'returned' or .returnPhoto != null
invariant deposits.read only exists roles[viewer, role = 'manager']
invariant deposits.insert only exists roles[viewer, role = 'manager']
invariant deposits.update only exists roles[viewer, role = 'manager']
invariant repairNotes.read only exists roles[viewer, role = 'librarian'] or exists roles[viewer, role = 'manager']
invariant repairNotes.insert only .author = viewer and exists roles[viewer, role = 'luthier']
invariant instruments.status write only .status != 'written_off' or exists roles[viewer, role = 'manager']
