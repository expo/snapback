-- Independently authored SPEC.md security intent. See root REPORT.md for workflow limits.
invariant rounds.read only exists roles[viewer, role = 'chief'] or (.status = 'completed' and exists roles[viewer, role = 'manager']) or (exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer])
invariant gauges.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'engineer'] or (exists roles[viewer, role = 'contractor'] and exists assignments[.id, viewer])
invariant readings.read only exists roles[viewer, role = 'chief'] or exists roles[viewer, role = 'engineer'] or (exists roles[viewer, role = 'contractor'] and exists assignments[.gauge, viewer])
invariant readings.insert only .engineer = viewer and exists roles[viewer, role = 'engineer'] and exists shiftMembers[shift = .shift, engineer = viewer]
invariant readings always .photo != null
invariant gauges.insert only exists roles[viewer, role = 'chief']
invariant gauges.update only exists roles[viewer, role = 'chief']
invariant gauges.delete only exists roles[viewer, role = 'chief']
invariant alerts.read only exists roles[viewer, role = 'chief']
invariant alerts.update only exists roles[viewer, role = 'chief']
