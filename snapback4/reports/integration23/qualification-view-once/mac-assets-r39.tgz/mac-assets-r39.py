from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/Users/ccheever/projects/snapback-integ23');sb=root/'snapback4';logs=root/'integration23-logs'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/Users/ccheever/.elan/bin:/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',SNAPBACK4_BIN=str(sb/'target/debug/snapback4'),CI='1',EXPO_NO_TELEMETRY='1')
for key in ['CARGO_TARGET_DIR','SNAPBACK4_EVAL_POSTGRES','SNAPBACK4_STORE_URL','SNAPBACK4_WORKER_STATE_DIR']:
 env.pop(key,None)
env['SNAPBACK4_REQUIRE_LEAN']='1'
env['SNAPBACK4_LEAN_ORACLE']=str(sb/'lean/.lake/build/bin/quarry-oracle')
assert Path(env['SNAPBACK4_LEAN_ORACLE']).is_file()
manifest=json.loads((root/'mac-r39-source-manifest.json').read_text())
def parity():
 bad=[p for p,h in manifest.items() if not(root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
# Preserve source bytes but invalidate Cargo's mtime freshness after tar extraction.
refresh=[]
for p in manifest:
 q=root/p;refresh.append({'path':p,'beforeMtime':q.stat().st_mtime});os.utime(q,None)
(logs/'r39-source-timestamp-refresh.json').write_text(json.dumps({'reason':'Refresh preview source timestamps before qualifying the late-main merge.','inputs':refresh},indent=2)+'\n')
parity();commands=[]
def run(key,args,budget=3600):
 with(logs/('r39-'+key+'.log')).open('w')as out:r=subprocess.run(['timeout',str(budget)+'s',*args],cwd=sb,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=budget+30)
 commands.append({'key':key,'argv':args,'exit':r.returncode});(logs/('r39-'+key+'.status')).write_text(str(r.returncode)+'\n');(logs/'r39-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0,(key,r.returncode)
run('assets',['cargo','test','-p','snapback4','--bin','snapback4','asset','--','--include-ignored'],3600)
run('once',['cargo','test','-p','snapback4','--bin','snapback4','view_once','--','--include-ignored'],1800)
run('tiny-http',['cargo','test','-p','tiny_http','--lib'],1800)
run('guide',['cargo','test','-p','snapback4-lang','--test','guide'],1800)
run('build',['cargo','build','-p','snapback4'])
files=['http-bounds','asset-avatars','asset-blob-lifecycle','asset-buffered','asset-files','asset-lists','asset-pressure','asset-retry','asset-scan-recipe','expo-save-asset']
run('clients',['node','scripts/run-client-tests.mjs','4','files',*['packages/snapback4/test/'+n+'.test.mjs'for n in files]],7200)
parity();(logs/'r39-final-summary.json').write_text(json.dumps({'sourceFiles':len(manifest),'sourceMismatches':[],'commands':commands,'clientFiles':files,'nativeSha256':hashlib.sha256((sb/'target/debug/snapback4').read_bytes()).hexdigest(),'distSha256':{str(p.relative_to(sb/'packages/snapback4/dist')):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted((sb/'packages/snapback4/dist').rglob('*'))if p.is_file()}},indent=2)+'\n');(logs/'r39-wrapper.status').write_text('0\n')
