# Exact integration 23 final commands

Exact2 clean origin/main base: `14c091f205f62c32ed9d585ae75148cffc12dfa2` (includes EX10 contract migrate).
Snapback source: `3cd7b7636f0f496b1e45e59d4efb97f5f13dc2e2`.
Native SHA-256: `8aa998f61e2a0402e276dc10e17830b2dbd0fe5dd754af367af3579b1420673c`.
Client SHA-256: `1a082e7ba810831999c2401f63ec1d780fbe8fb9999cdd7cfb22b1b9fd77a103`.

Private setup changes only the three Snapback crate paths, packed client dependency and locks; `exact-postfix-local-setup-r12.patch` records the complete diff. The original clean clone was fetched before those bindings were applied. Fresh synced and online apps use separate directories and ports 27418/27419. The online app uses an authored minimal contract and online-only backend.

Environment supplied to every command: `CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=8`, with Bun 1.4.2 on PATH. App qualification additionally supplies `SNAPBACK4_BIN=/tmp/integ23/frozen-production39-r18/snapback4-bin`, and the recorded Chromium executable for web tests.

Before scaffolding, in `/home/ccheever/sb4-loop/prewave23/exact2-postfix`:

```sh
timeout 900s bun install
timeout 600s cargo update --manifest-path snapback4/Cargo.toml --workspace
timeout 2400s bun snapback4/web/build.mjs
```

The client pack is bound through the private manifest before install. Each backend was launched with `timeout 7200s /tmp/integ23/frozen-production39-r18/snapback4-bin dev --port PORT --no-watch` from its parent project directory, using 27418 for synced and 27419 for online. Cleanup sends TERM only to those owned groups and waits/reaps them; `exact-cleanup.json` records the result.

## synced

Working directory: `/home/ccheever/sb4-loop/prewave23/synced-r12`; exit 0.

```sh
timeout 600s bun install
```

Working directory: `/home/ccheever/sb4-loop/prewave23/synced-r12`; exit 0.

```sh
timeout 1800s bun /home/ccheever/sb4-loop/prewave23/exact2-postfix/scripts/exact.mjs new app --snapback --port 27418
```

Working directory: `/home/ccheever/sb4-loop/prewave23/synced-r12/app`; exit 0.

```sh
timeout 1800s bun exact.mjs snapback
```

Working directory: `/home/ccheever/sb4-loop/prewave23/synced-r12/app`; exit 0.

```sh
timeout 2400s bun exact.mjs test web
```

Web tests: 2 passed, zero failed.

## online

Working directory: `/home/ccheever/sb4-loop/prewave23/online-r12`; exit 0.

```sh
timeout 600s bun install
```

Working directory: `/home/ccheever/sb4-loop/prewave23/online-r12`; exit 0.

```sh
timeout 1800s bun /home/ccheever/sb4-loop/prewave23/exact2-postfix/scripts/exact.mjs new app --snapback --port 27419 --online
```

Working directory: `/home/ccheever/sb4-loop/prewave23/online-r12/app`; exit 0.

```sh
timeout 1800s bun exact.mjs snapback
```

Working directory: `/home/ccheever/sb4-loop/prewave23/online-r12/app`; exit 0.

```sh
timeout 2400s bun exact.mjs test web
```

Web tests: 1 passed, zero failed.

Both apps run the literal commands `bun exact.mjs snapback` and `bun exact.mjs test web` with external timeouts. Owned servers were stopped and reaped; raw logs, cleanup and manifest records are retained.
