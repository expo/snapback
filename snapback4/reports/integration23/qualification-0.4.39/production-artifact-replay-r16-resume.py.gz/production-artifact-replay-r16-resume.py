from pathlib import Path
import time,subprocess,shutil,hashlib,json,os
b=Path('/tmp/integ23');root=Path('/home/ccheever/projects/snapback-sb4loop');sb=root/'snapback4';f=b/'frozen-production39-r16'
for _ in range(2880):
 if (b/'qualified39-r19/day2-proof.json').exists():break
 time.sleep(5)
else:raise SystemExit('production qualification binary did not appear')
assert (f/'source.json').is_file()
env=dict(os.environ,SNAPBACK4_BIN=str(f/'snapback4-bin'),REPLAY_TAG='fixed-production-r16',ROLL_REPLAY_OUT=str(b/'roll-replay-production-r24'))
commands=[('w25-production-r16.log',['python3',str(b/'w25-replay.py')]),('roll-replay-production-r24.log',['python3',str(b/'roll-replay-compat-r16.py'),*[str(n).zfill(3) for n in range(1,51)]]),('survey-production-r13.log',['python3',str(b/'survey-both-outputs.py'),'--binary',str(f/'snapback4-bin'),'--out',str(b/'survey-production-r13'),'--waves','15,16,18,19,20,21,22,23']),('survey-gates-production-r13.log',['python3',str(b/'survey-gates.py'),'--binary',str(f/'snapback4-bin'),'--survey',str(b/'survey-production-r13/results.json'),'--out',str(b/'survey-gates-production-r13.json')])]
for name,args in commands[1:]:
 with (b/name).open('w') as log:r=subprocess.run(['timeout','5400s',*args],cwd=sb,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=5430)
 assert r.returncode==0,(name,r.returncode)
(b/'production-artifact-replay-r16.status').write_text('0\n')
