from pathlib import Path
import json,hashlib,copy
b=Path('/tmp/integ23');base=b/'base/lean-r15';candidate=b/'diff-lean-r23'
commands=json.loads((b/'final-r23-commands.json').read_text())
assert [x['key']for x in commands]==['five-crate','no-default','diff-build','diff-engine','diff-devices','diff-lean']
assert all(x['exit']==0 for x in commands[:-1])and commands[-1]['exit']==1
assert(b/'final-five-crate-r23.status').read_text().strip()=='0'
def thin(p):
 x=json.loads(p.read_text())
 for k in ['seconds','slowest_case_seconds','slowest_case_seed']:x.pop(k,None)
 return x
assert thin(base/'report.json')==thin(candidate/'report.json'),'Actual oracle, coverage or case-count delta must be investigated'
files=sorted(p.relative_to(base)for p in base.glob('worker-*/**/case.*')if p.is_file()and p.suffix in {'.json','.q'})
actual=sorted(p.relative_to(candidate)for p in candidate.glob('worker-*/**/case.*')if p.is_file()and p.suffix in {'.json','.q'})
assert files==actual and len(files)==76
checks=[];changes=[]
for name in files:
 old=(base/name).read_bytes();new=(candidate/name).read_bytes();same=old==new
 entry={'path':str(name),'baseSha256':hashlib.sha256(old).hexdigest(),'candidateSha256':hashlib.sha256(new).hexdigest(),'sameBytes':same}
 if name.suffix=='.q':assert same,str(name)
 elif not same:
  a=json.loads(old);c=json.loads(new)
  # S10e-2a adds this host-only observation to raw query records. Never
  # discard a nonnull dependency, any other new field, or changed data/meter.
  assert a['finding']['left']['kind']==c['finding']['left']['kind']=='query'
  prior=a['finding']['left']['value'];value=c['finding']['left']['value']
  assert 'pending_opening'not in prior and value.get('pending_opening','MISSING')is None
  value.pop('pending_opening')
  assert json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(c,sort_keys=True,separators=(',',':')),str(name)
  entry['onlyDiagnosticAddition']={'path':'finding.left.value.pending_opening','value':None,'baseline':'absent'}
  changes.append(entry)
 checks.append(entry)
assert len(changes)==24
result={'base':'7b051e5f3f','candidate':json.loads((b/'prepared-r19-ready.json').read_text())['source'],'ignoredTimingFields':['seconds','slowest_case_seconds','slowest_case_seed'],'sameAllOracleVerdicts':True,'sameCoverage':True,'newSignatures':[],'workerRepresentativeFiles':checks,'quarryFilesByteIdentical':38,'allRepresentativeFilesByteIdentical':False,'byteIdenticalRepresentativeFiles':52,'rawQueryDiagnosticAdditions':changes,'diagnosticChangeSource':'d20fbe09b2 / merged e1f424691a: execute::query_record now records the host-only pending_opening dependency; all added values here are null. Any nonnull value or other changed field would fail.','rawCommandExits':{x['key']:x['exit']for x in commands if x['key'].startswith('diff-')}}
(b/'difftest-baseline-comparison-r23.json').write_text(json.dumps(result,indent=2)+'\n')
(b/'difftest-evidence-format-r23.json').write_text(json.dumps({'originalStrictRawByteComparison':'requires update for the intentional new diagnostic field; not a product test failure','allExecutedChecks':commands,'verifiedDiagnosticOnlyFiles':24,'allOtherDataMetersCanonicalContinuationsUnchanged':True,'noNewSignatures':True},indent=2)+'\n')
(b/'final-r23-qualified.status').write_text('0\n');print(json.dumps({'newSignatures':[],'sameAllOracleVerdicts':True,'sameCoverage':True,'sameQuarryBytes':38,'sameAllBytes':52,'onlyNullDiagnosticAdded':24}))
