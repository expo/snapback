from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/Users/ccheever/projects/snapback-integ23');sb=root/'snapback4';logs=root/'integration23-logs'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/Users/ccheever/.elan/bin:/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',SNAPBACK4_BIN=str(sb/'target/debug/snapback4'),CI='1',EXPO_NO_TELEMETRY='1')
for key in ['CARGO_TARGET_DIR','SNAPBACK4_EVAL_POSTGRES','SNAPBACK4_STORE_URL','SNAPBACK4_WORKER_STATE_DIR']:
 env.pop(key,None)
env['SNAPBACK4_REQUIRE_LEAN']='1'
env['SNAPBACK4_LEAN_ORACLE']=str(sb/'lean/.lake/build/bin/quarry-oracle')
assert Path(env['SNAPBACK4_LEAN_ORACLE']).is_file()
manifest=json.loads((root/'mac-r37-source-manifest.json').read_text())
def parity():
 bad=[p for p,h in manifest.items() if not(root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
# Preserve source bytes but invalidate Cargo's mtime freshness after tar extraction.
refresh=[]
for p in manifest:
 q=root/p;refresh.append({'path':p,'beforeMtime':q.stat().st_mtime});os.utime(q,None)
(logs/'r37-source-timestamp-refresh.json').write_text(json.dumps({'reason':'Refresh preview source timestamps before qualifying the late-main merge.','inputs':refresh},indent=2)+'\n')
parity();commands=[]
def run(key,args,budget=3600):
 with(logs/('r37-'+key+'.log')).open('w')as out:r=subprocess.run(['timeout',str(budget)+'s',*args],cwd=sb,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=budget+30)
 commands.append({'key':key,'argv':args,'exit':r.returncode});(logs/('r37-'+key+'.status')).write_text(str(r.returncode)+'\n');(logs/'r37-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0,(key,r.returncode)
# Regenerate the test-only access census before using its compiled fixture.
env['SNAPBACK4_RATCHET_UPDATE']='1'
env['SNAPBACK4_RATCHET_ALLOW_RAISE']='1'
run('census',['cargo','test','-p','snapback4','--test','store_port_ratchet'])
env.pop('SNAPBACK4_RATCHET_UPDATE')
env.pop('SNAPBACK4_RATCHET_ALLOW_RAISE')
allow='snapback4/crates/snapback4/tests/store_port_ratchet.test-allow.txt'
newHash=hashlib.sha256((root/allow).read_bytes()).hexdigest();oldHash=manifest[allow];manifest[allow]=newHash
(root/'mac-r37-qualified-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(logs/'r37-generated-census.json').write_text(json.dumps({'path':allow,'before':oldHash,'after':newHash,'productionAllowance':'zero, enforced by generator'},indent=2)+'\n')
run('core',['cargo','test','-p','snapback4-core','--features','postgres','--no-fail-fast'],14400)
run('cli',['cargo','test','-p','snapback4','--bin','snapback4','--test','roll_views','--test','http','--test','clock','--test','replay','--test','check','--test','security_reviews','--no-fail-fast'],7200)
run('language-unit',['cargo','test','-p','snapback4-lang','--lib','--no-fail-fast'],7200)
run('guide',['cargo','test','-p','snapback4-lang','--test','guide','--test','read_through','--no-fail-fast'],7200)
run('difftest',['cargo','test','-p','snapback4-difftest','--no-fail-fast'],7200)
run('difftest-pg-check',['cargo','check','-p','snapback4-difftest','--features','postgres'])
run('build',['cargo','build','-p','snapback4'])
files=['answers-stay-bound', 'answers-stay-review', 'answers-stay-round2', 'answers-stay-round3', 'api-index', 'app-clock-prepare', 'app-local-session', 'app-receipts', 'app-storage', 'close-boundary', 'decorated-search', 'delivery-fault-matrix', 'device-version', 'dormant-visibility', 'dx5', 'dx5-react', 'dx6-clock', 'expo-media-storage', 'expo-scenes', 'expo-session-store', 'export-background', 'export-failure', 'export-native', 'export-native-round2', 'export-publication', 'first-account', 'front-data-react', 'generation-retry', 'http-bounds', 'identity-rate', 'keep-observation', 'lang4-guide', 'linux-package', 'live-contention', 'maintained-columns', 'maintenance-evidence', 'migrations', 'offline-run-warning', 'one-shot-commit-evidence', 'one-shot-generation', 'online-session', 'package-require', 'per-row-inflight', 'per-row-liveness', 'per-row-retention', 'per-row-retry', 'per-row-work', 'periphery', 'production-starters', 'proof', 'proof-contract', 'pubfix29b', 'publish-linux', 'publish-signing', 'qualify-linux', 'query-publication-session', 'react', 'read-only', 'read-types', 'readme-examples', 'recorded-compatibility', 'reg-upgrade', 'release-transitions', 'retention-episode', 'retention-online-boundaries', 'revocation-retention', 'rx-rule-hop-capability', 'schema-capabilities', 'schema-session', 'security-packed', 'server-clock', 'server-clock-wire', 'server-e2e', 'session-reasons', 'session-security', 'session-timing', 'social-starter', 'staging', 'subscription-pressure-round1', 'surf4', 'sync-generation', 'test-file-runner', 'test-platform-audit', 'test-processes', 'test-signals', 'transport-http', 'wasm-codec-census', 'wave10-starters', 'wave10-witness', 'wave11-narration', 'wave11-upgrade-history', 'wave12-kit', 'wave13-surface', 'wave14-rule-recipes', 'wave9-dx', 'web-session-authority', 'web-shell', 'wire-envelopes', 'wire-first', 'witness', 'witness-preparation', 'worker', 'worker-regressions']
run('sdk-build',['bun','run','--cwd','packages/snapback4','build'],1800)
run('clients',['node','scripts/run-client-tests.mjs','4','files',*['packages/snapback4/test/'+n+'.test.mjs'for n in files]],7200)
run('models',['node','scripts/run-client-tests.mjs','1','models','packages/snapback4/test/app-session-model.test.mjs','packages/snapback4/test/online-client-model.test.mjs'],7200)
parity();(logs/'r37-final-summary.json').write_text(json.dumps({'sourceFiles':len(manifest),'sourceMismatches':[],'commands':commands,'clientFiles':files,'nativeSha256':hashlib.sha256((sb/'target/debug/snapback4').read_bytes()).hexdigest(),'distSha256':{str(p.relative_to(sb/'packages/snapback4/dist')):hashlib.sha256(p.read_bytes()).hexdigest()for p in sorted((sb/'packages/snapback4/dist').rglob('*'))if p.is_file()}},indent=2)+'\n');(logs/'r37-wrapper.status').write_text('0\n')
