from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/Users/ccheever/projects/snapback-integ23');sb=root/'snapback4';logs=root/'integration23-logs'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',SNAPBACK4_BIN=str(sb/'target/debug/snapback4'),CI='1',EXPO_NO_TELEMETRY='1')
manifest=json.loads((root/'mac-r25-source-manifest.json').read_text())
def parity():
 bad=[p for p,h in manifest.items() if not(root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
parity();commands=[]
def run(key,args,budget=3600):
 with(logs/('r25-'+key+'.log')).open('w')as out:r=subprocess.run(['timeout',str(budget)+'s',*args],cwd=sb,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=budget+30)
 commands.append({'key':key,'argv':args,'exit':r.returncode});(logs/('r25-'+key+'.status')).write_text(str(r.returncode)+'\n');(logs/'r25-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0,(key,r.returncode)
run('core',['cargo','test','-p','snapback4-core','--lib','--no-fail-fast'])
run('cli',['cargo','test','-p','snapback4','--bin','snapback4','--test','roll_views','--test','clock','--test','http','--test','replay','--no-fail-fast'])
run('guide',['cargo','test','-p','snapback4-lang','--test','guide'])
run('build',['cargo','build','-p','snapback4'])
files=['http-bounds','live-contention','one-shot-commit-evidence','one-shot-generation','online-session','query-publication-session','receipt-upgrade','schema-session','server-clock-wire','session-reasons','session-security','session-timing','sync-generation','transport-http','web-receipt-upgrade','web-session-authority','wire-envelopes','wire-first']
run('clients',['node','scripts/run-client-tests.mjs','4','files',*['packages/snapback4/test/'+n+'.test.mjs'for n in files]])
parity();(logs/'r25-final-summary.json').write_text(json.dumps({'sourceFiles':len(manifest),'sourceMismatches':[],'commands':commands,'clientFiles':files},indent=2)+'\n');(logs/'r25-wrapper.status').write_text('0\n')
