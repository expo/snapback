from pathlib import Path
import time,os,subprocess,json
root=Path('/Users/ccheever/projects/snapback-integ23');logs=root/'integration23-logs'
for _ in range(4320):
 if (logs/'r21-wrapper.status').exists():break
 time.sleep(5)
else:raise SystemExit('Mac preceding pass incomplete')
assert (logs/'r21-wrapper.status').read_text().strip()=='0','finish/fix the full Mac pool first'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',SNAPBACK4_BIN=str(root/'snapback4/target/debug/snapback4'),CI='1',EXPO_NO_TELEMETRY='1')
files=['packages/snapback4/test/'+n+'.test.mjs' for n in ['http-bounds','migrations','release-transitions','dormant-visibility']]
(logs/'r22-files.json').write_text(json.dumps(files,indent=2)+'\n')
with (logs/'r22-affected-clients.log').open('w') as log:r=subprocess.run(['timeout','7200s','node','scripts/run-client-tests.mjs','1','files',*files],cwd=root/'snapback4',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=7230)
(logs/'r22-affected-clients.status').write_text(str(r.returncode)+'\n');assert r.returncode==0,r.returncode
