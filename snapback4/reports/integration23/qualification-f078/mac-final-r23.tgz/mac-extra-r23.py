from pathlib import Path
import time,os,subprocess,json
root=Path('/Users/ccheever/projects/snapback-integ23');logs=root/'integration23-logs'
for _ in range(4320):
 if (logs/'r22-affected-clients.status').exists():break
 time.sleep(5)
else:raise SystemExit('Mac affected client pass incomplete')
assert (logs/'r22-affected-clients.status').read_text().strip()=='0','finish/fix the full Mac pool first'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',SNAPBACK4_BIN=str(root/'snapback4/target/debug/snapback4'),CI='1',EXPO_NO_TELEMETRY='1')
commands=[('lang-lib',['cargo','test','-p','snapback4-lang','--lib']),('wave19-alone',['cargo','test','-p','snapback4','--test','security_wave19','check_refutes_excluded_contact_roles_before_any_full_test','--','--exact']),('wave19-full',['cargo','test','-p','snapback4','--test','security_wave19'])]
for key,args in commands:
 with (logs/('r23-'+key+'.log')).open('w') as log:r=subprocess.run(['timeout','1800s',*args],cwd=root/'snapback4',env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1830)
 (logs/('r23-'+key+'.status')).write_text(str(r.returncode)+'\n');assert r.returncode==0,(key,r.returncode)
(logs/'r23-wrapper.status').write_text('0\n')
