from pathlib import Path
import os,subprocess,json,hashlib,time
root=Path('/Users/ccheever/projects/snapback-integ23');sb=root/'snapback4';logs=root/'integration23-logs'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',SNAPBACK4_BIN=str(sb/'target/debug/snapback4'),CI='1',EXPO_NO_TELEMETRY='1')
manifest=json.loads((root/'mac-r27-source-manifest.json').read_text())
def parity():
 bad=[p for p,h in manifest.items() if not(root/p).is_file() or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
parity();commands=[]
def run(key,args,budget=3600):
 with(logs/('r27-'+key+'.log')).open('w')as out:r=subprocess.run(['timeout',str(budget)+'s',*args],cwd=sb,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=budget+30)
 commands.append({'key':key,'argv':args,'exit':r.returncode});(logs/('r27-'+key+'.status')).write_text(str(r.returncode)+'\n');(logs/'r27-commands.json').write_text(json.dumps(commands,indent=2)+'\n');assert r.returncode==0,(key,r.returncode)
run('init',['cargo','test','-p','snapback4','--test','init','--test','store_port_ratchet','--no-fail-fast'],7200)
parity();(logs/'r27-final-summary.json').write_text(json.dumps({'sourceFiles':len(manifest),'sourceMismatches':[],'commands':commands},indent=2)+'\n');(logs/'r27-wrapper.status').write_text('0\n')
