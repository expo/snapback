from pathlib import Path
import os,time,subprocess,json,hashlib,shutil
root=Path('/Users/ccheever/projects/snapback-integ23');sb=root/'snapback4';logs=root/'integration23-logs'
env=dict(os.environ,PATH=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin')+':/opt/homebrew/bin:/Users/ccheever/.bun/bin:/Users/ccheever/.cargo/bin:'+os.environ['PATH'],SNAPBACK_NODE=str(root/'integration23-tools/node-v24.13.1-darwin-arm64/bin/node'),CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0',CARGO_PROFILE_DEV_OPT_LEVEL='1',CARGO_BUILD_JOBS='4',RUST_TEST_THREADS='4',CI='1',EXPO_NO_TELEMETRY='1',npm_config_cache=str(root/'integration23-npm-r24'))
expected=json.loads((root/'mac-r24-source-manifest.json').read_text())
def parity():
 bad=[p for p,h in expected.items() if not(root/p).is_file()or hashlib.sha256((root/p).read_bytes()).hexdigest()!=h];assert not bad,bad
parity()
def run(key,args,cwd=sb,budget=3600):
 with(logs/('r24-'+key+'.log')).open('w') as out:r=subprocess.run(['timeout',str(budget)+'s',*args],cwd=cwd,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=budget+30)
 (logs/('r24-'+key+'.status')).write_text(str(r.returncode)+'\n');assert r.returncode==0,(key,r.returncode)
run('guide',['cargo','test','-p','snapback4-lang','--test','guide'])
run('build',['cargo','build','-p','snapback4'])
client=root/'integration23-client-r13.tgz'
for _ in range(1440):
 if client.exists():break
 time.sleep(5)
else:raise SystemExit('fresh client pack not copied')
pkg=root/'r24-platform-package';pkg.mkdir();packs=root/'r24-packs';packs.mkdir()
for name in ['package.json','THIRD-PARTY-NOTICES']:shutil.copy2(sb/'packages/snapback4-darwin-arm64'/name,pkg/name)
shutil.copy2(sb/'target/debug/snapback4',pkg/'snapback4')
run('native-pack',['npm','pack','--ignore-scripts','--json','--pack-destination',str(packs)],pkg)
platform=packs/'snapback4-darwin-arm64-0.4.39.tgz';assert platform.is_file()
run('proof-kit',['node','scripts/publication-proof-kit.mjs',str(client),str(platform),str(root/'integration23-proof-kit-r24')],budget=3600)
parity();summary={'sourceFiles':len(expected),'sourceMismatches':[],'clientSha256':hashlib.sha256(client.read_bytes()).hexdigest(),'nativeSha256':hashlib.sha256((pkg/'snapback4').read_bytes()).hexdigest(),'statuses':{k:int((logs/('r24-'+k+'.status')).read_text()) for k in ['guide','build','native-pack','proof-kit']}}
(logs/'r24-final-summary.json').write_text(json.dumps(summary,indent=2)+'\n');(logs/'r24-wrapper.status').write_text('0\n');print(json.dumps(summary))
