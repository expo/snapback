import {planAffected,CARGO_ENV} from '/home/ccheever/projects/sb4-b32-rel3/snapback4/scripts/affected.mjs';
import {spawn,execFileSync} from 'node:child_process';
import {mkdirSync,writeFileSync,openSync,closeSync,readFileSync} from 'node:fs';
import {resolve,join} from 'node:path';
import {createHash} from 'node:crypto';
const root='/home/ccheever/projects/sb4-b32-rel3',out='/tmp/rel3-evidence/merged-affected';mkdirSync(out,{recursive:true});
const plan=planAffected({base:'98177aa48b',root});
const prepNames=new Set(['install-client','build-cli','build-wasm','build-client']);
const receipt={...plan,started:new Date().toISOString(),executor:'Unmodified affected.mjs plan; sequential build prerequisites, independent Rust packages and non-Rust groups in parallel; original command arguments and per-step deadlines retained',results:[],complete:false};
const receiptPath=join(root,'target/affected',`${plan.head.slice(0,12)}-rel3-parallel.json`);
const save=()=>writeFileSync(receiptPath,JSON.stringify(receipt,null,2)+'\n');save();
async function run(step){
 const missing=(step.requires??[]).filter(id=>!receipt.results.some(r=>r.id===id&&r.status===0));
 const blockedFiles=Object.entries(step.fileRequires??{}).filter(([file,ids])=>ids.some(id=>!receipt.results.some(r=>r.id===id&&r.status===0)));
 if(missing.length||blockedFiles.length){receipt.results.push({id:step.id,status:null,blockedBy:missing,blockedFiles});save();console.log('BLOCKED',step.id);return;}
 const log=join(out,step.id.replaceAll(':','-')+'.log'),fd=openSync(log,'w'),start=Date.now();console.log('START',step.id);
 const result=await new Promise(done=>{const child=spawn('timeout',['--kill-after=10s',`${step.timeoutSeconds}s`,...step.argv],{cwd:resolve(root,step.cwd),env:{...process.env,...CARGO_ENV,RUST_MIN_STACK:'33554432'},stdio:['ignore',fd,fd]});child.on('error',e=>done({status:null,error:e.message}));child.on('close',(status,signal)=>done({status,signal}));});closeSync(fd);
 const logSha256=createHash('sha256').update(readFileSync(log)).digest('hex');receipt.results.push({id:step.id,...result,elapsedMs:Date.now()-start,log,logSha256});save();console.log('END',step.id,result.status);
}
for(const s of plan.steps.filter(s=>prepNames.has(s.id)))await run(s);
const rest=plan.steps.filter(s=>!prepNames.has(s.id)),rust=rest.filter(s=>s.id.startsWith('rust:')),client=rest.filter(s=>['fixture-tests','client-tests','client-models'].includes(s.id));
const reserved=new Set([...rust,...client].map(s=>s.id)),other=rest.filter(s=>!reserved.has(s.id));
await Promise.allSettled([...rust.map(s=>run(s)),(async()=>{for(const s of client)await run(s);})(),(async()=>{for(const s of other)await run(s);})()]);
const check=planAffected({base:'98177aa48b',root});receipt.complete=true;receipt.finished=new Date().toISOString();receipt.coverageComplete=receipt.results.length===plan.steps.length&&new Set(receipt.results.map(r=>r.id)).size===plan.steps.length;receipt.unchanged=plan.head===check.head&&plan.inputDigest===check.inputDigest&&JSON.stringify(plan.observedFiles)===JSON.stringify(check.observedFiles)&&execFileSync('git',['status','--porcelain'],{cwd:root,encoding:'utf8'}).trim()==='';receipt.ok=receipt.coverageComplete&&receipt.unchanged&&receipt.results.every(r=>r.status===0);save();console.log('FINAL',receiptPath,'complete',receipt.coverageComplete,'unchanged',receipt.unchanged,'ok',receipt.ok);process.exitCode=receipt.ok?0:1;
