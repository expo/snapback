import type { Client, Cursor } from "snapback4/contract";
import { api } from "../snapback/generated/api";

// Pass your app's client (for Expo, await openClient() from ./client).
// Register during profile creation, before following or creating posts.
// Existing app with media/reposts: `snapback4 guide feeds`, "Wire into an app".
// In the app's createPost, insert a recipe reference event (postId is
// the app post id) and call its deliver helper in the same mutation. Following
// joins the app's postCard and repost attribution; it copies no body or asset.
// Bridge the app's follow/unfollow with the recipe's addFollow/dropFollow
// helpers in ONE mutation. With --prefix, only the query wrapper is generated;
// all recipe mutations are fn helpers, called only by the app mutations.
// Backfill existing authors, events and edges before switching Following.
// Pull routes stay reader-private. Follow/unfollow queue without predicted
// rows because slot counts are online-only; profile saves and post creation
// can predict after their declared public metadata and app cards are acquired.
// With --prefix feed, helpers include feedRegister/feedDeliver/feedAddFollow/feedDropFollow/feedRepost;
// the module stays feed.q. With that prefix, the Quarry seams are:
//   a = feedAuthors[viewer] ! else AUTHOR_NOT_FOUND
//   event = insert feedPosts { id: postId, postId, actorId: viewer, authorId: p.authorId, repost: false, at: p.at, shared: a.shared }
//   feedDeliver(event)
// For repost, after checking the app card and creating its attribution row:
//   event = feedPosts[original.authorId, postId, false] ! else POST_NOT_FOUND
//   feedRepost(event.id)
// feedRepost(eventId: feedPosts) takes the source event id; resolve it from
// the app post as above. It delivers the new attributed event atomically.
// After the app's merge, join its card and attribution:
//   return entries { *, post: posts[.postId] postCard, attribution: reposts[.actorId, .postId] }
// The app edge insert/delete and feedAddFollow(authorId)/feedDropFollow(authorId)
// share one mutation. The card includes registration, guards and removal too.

// Render the returned Read's loading/denied/data states; keep complete and fresh visible.
// Pass page.next back as c to continue. A cut has no next: retry after cleanup.
// The local-first client answers from its partition; Expo Go uses the online tier.
export const followingPage = (client: Client, c: Cursor | null = null) => client.query(api.feed.feedFollowing, { c });
