table feedAuthors:
  principal: principal
  shared: bool default false
  unique byPrincipal: principal
  cap 1000
  public 'delivery mode is public'
  insert <- .principal = viewer
  update <- allow
  sync public

table feedFollows:
  followerId: principal
  followedId: principal
  at: time default 0
  unique byPair: followerId, followedId
  by byFollowed: followedId, followerId
  cap 1000 by followerId
  cap 1000 by followedId
  cap 100000
  public 'the follow graph is public'
  insert <- .followerId = viewer
  delete <- .followerId = viewer
  sync public

table feedPulls:
  readerId: principal
  authorId: principal
  unique byReaderAuthor: readerId, authorId
  cap 32 by readerId
  cap 32000
  read <- .readerId = viewer
  insert <- allow
  delete <- .readerId = viewer
  sync

table feedPullCounts:                 -- server-only slot accounting; never lists installed authors
  readerId: principal
  used: int
  unique byReader: readerId
  cap 32000
  public 'only the number of installed pulls is public; routes stay reader-private'
  insert <- exists feedPullTotals[readerId = .readerId, value = .used]
  update (old, next) <- exists feedPullTotals[readerId = next.readerId, value = next.used]
  delete <- .readerId = viewer
  online only

maintain feedPullTotals: count feedPulls by readerId
  read <- deny
  online only

table feedPosts:                       -- originals and attributed reposts, one source event each
  actorId: principal
  authorId: principal
  postId: id
  repost: bool
  at: time
  shared: bool
  unique byActorPost: actorId, postId, repost
  by byActorTime: actorId, at, id
  by byTime: at, id
  cap 1000 by actorId
  cap 60000
  immutable actorId, authorId, postId, repost, at, shared
  public 'original posts and attributed reposts are public'
  insert <- .actorId = viewer
  delete <- .actorId = viewer
  sync public

table feedRemovedEvents:               -- compact tombstones for deleted public source events
  eventId: id                       -- shared identity across source and tombstone tables; checked by the insert rule
  actorId: principal
  unique byEvent: eventId
  by byActor: actorId, id
  immutable eventId, actorId
  cap 1000 by actorId
  cap 32000
  public 'removal of a public source event is public; id is the eventId'
  insert <- .actorId = viewer and .id = .eventId and exists feedPosts[id = .eventId, actorId = viewer]
  sync public

table feedFeed:                        -- private inbox, with app post references
  readerId: principal
  eventId: feedPosts
  actorId: principal
  authorId: principal
  postId: id
  repost: bool
  at: time
  unique byReaderEvent: readerId, eventId
  unique byReaderTime: readerId, at, eventId
  by byReaderActor: readerId, actorId, id
  by byTime: at, eventId
  by byEvent: eventId, id
  immutable readerId, eventId, actorId, at
  cap 1000 by readerId, actorId
  cap 50000 by readerId
  cap 1001 by eventId
  read <- .readerId = viewer
  insert <- .actorId = viewer or .readerId = viewer
  delete <- .readerId = viewer
  sync

table feedBroadcast:                   -- public celebrity events, stored once
  readerId: principal
  eventId: feedPosts
  actorId: principal
  authorId: principal
  postId: id
  repost: bool
  at: time
  unique byReaderEvent: readerId, eventId
  unique byReaderTime: readerId, at, eventId
  by byReaderActor: readerId, actorId, id
  by byTime: at, eventId
  immutable readerId, eventId, actorId, at
  cap 32000
  public 'celebrity posts and reposts are public'
  insert <- .actorId = viewer
  delete <- .actorId = viewer
  sync public

fn feedCopy(p: feedPosts, readerId: principal, shared: bool):
  if shared:
    insert feedBroadcast { readerId, eventId: p.id, actorId: p.actorId, authorId: p.authorId, postId: p.postId, repost: p.repost, at: p.at }
  else:
    insert feedFeed { readerId, eventId: p.id, actorId: p.actorId, authorId: p.authorId, postId: p.postId, repost: p.repost, at: p.at }
  return null

fn feedRegister():
  insert feedAuthors { principal: viewer } if absent
  return null

fn feedTryPull(readerId: principal, authorId: principal):
  if readerId = viewer:
    if exists feedPulls[readerId, authorId]:
      return true
  slots = feedPullCounts[readerId]
  used = 0
  if slots != null:
    used = slots.used
  if used = 32:
    return false
  -- Foreign inserts happen only on an author's first promotion: no route
  -- for that author exists yet. Never probe another reader's private route.
  insert feedPulls { readerId, authorId }
  upsert feedPullCounts[readerId] { readerId, used: used + 1 }
  return true

fn feedAddFollow(authorId: principal):
  require authorId != viewer else FEED_CANNOT_FOLLOW_SELF
  a = feedAuthors[authorId] ! else FEED_AUTHOR_NOT_FOUND
  if exists feedFollows[followerId = viewer, followedId = authorId]:
    return null
  if a.shared:
    require feedTryPull(viewer, authorId) else FEED_PULL_CAP
  insert feedFollows { followerId: viewer, followedId: authorId, at: now }
  if not a.shared:
    near = feedFollows[authorId] first 51 by byFollowed
    if count(near) > 50:
      -- Check the caller first so their own full slots name their own repair.
      require feedTryPull(viewer, authorId) else FEED_PULL_CAP
      update feedAuthors[authorId] { shared: true }
      feedTryPull(authorId, authorId)
      for f in feedFollows[authorId] by byFollowed:
        require feedTryPull(f.followerId, authorId) else FEED_PROMOTION_PULL_CAP
  visited = 0
  for p in feedPosts[authorId] last 1000 by byActorTime:
    if visited = 865:
      break
    visited = visited + 1
    if not p.shared:
      feedCopy(p, viewer, false)

  return null

fn feedFollow(authorId: principal):
  return feedAddFollow(authorId)

fn feedDropFollow(authorId: principal):
  if not exists feedFollows[followerId = viewer, followedId = authorId]:
    return null
  for e in feedFeed[viewer, authorId] by byReaderActor:
    delete feedFeed[e.id]
  if exists feedPulls[viewer, authorId]:
    delete feedPulls[viewer, authorId]
    slots = feedPullCounts[viewer] ! else FEED_PULL_COUNT_MISSING
    if slots.used = 1:
      delete feedPullCounts[viewer]
    else:
      update feedPullCounts[viewer] { used: slots.used - 1 }
  delete feedFollows[followerId = viewer, followedId = authorId]

  return null

fn feedUnfollow(authorId: principal):
  return feedDropFollow(authorId)

fn feedDeliver(p: feedPosts):
  if p.shared:
    feedCopy(p, viewer, true)
    if not exists feedPulls[viewer, viewer]:
      feedCopy(p, viewer, false)
  else:
    feedCopy(p, viewer, false)
    for f in feedFollows[viewer] by byFollowed:
      feedCopy(p, f.followerId, false)
  return null

fn feedCreatePost(postId: id):
  require not exists feedRemovedEvents[eventId = postId] else FEED_EVENT_REMOVED
  a = feedAuthors[viewer] ! else FEED_AUTHOR_NOT_FOUND
  p = insert feedPosts { id: postId, postId, actorId: viewer, authorId: viewer, repost: false, at: now, shared: a.shared }
  feedDeliver(p)
  return { id: p.id }

fn feedRepost(eventId: feedPosts):
  original = feedPosts[eventId] ! else FEED_POST_NOT_FOUND
  require not original.repost else FEED_ORIGINAL_REQUIRED
  if exists feedPosts[viewer, original.postId, true]:
    return null
  a = feedAuthors[viewer] ! else FEED_AUTHOR_NOT_FOUND
  p = insert feedPosts { postId: original.postId, actorId: viewer, authorId: original.authorId, repost: true, at: now, shared: a.shared }
  feedDeliver(p)
  return { id: p.id }

fn feedRemoveEvent(p: feedPosts):
  require p.actorId = viewer else FEED_NOT_AUTHOR
  insert feedRemovedEvents { id: p.id, eventId: p.id, actorId: viewer }
  if p.shared:
    delete feedBroadcast[viewer, p.id]
  delete feedPosts[p.id]
  return null

fn feedDeletePost(postId: feedPosts):
  p = feedPosts[postId]
  if p != null:
    require not p.repost else FEED_ORIGINAL_REQUIRED
    feedRemoveEvent(p)
  return null

fn feedUnrepost(postId: id):
  p = feedPosts[viewer, postId, true]
  if p != null:
    feedRemoveEvent(p)
  return null

query feedFollowing(c: cursor ?):
  return merge feedFeed after c last 20 by byReaderTime where not exists feedRemovedEvents[eventId = .eventId]:
    [viewer]
    feedBroadcast[p.authorId] for p in feedPulls[viewer] by byReaderAuthor

job feedPurgeRemoved():
  chunk p in feedRemovedEvents first 1 by byId:
    for e in feedFeed[p.eventId] by byEvent:
      delete feedFeed[e.id]
    delete feedRemovedEvents[p.id]
schedule feedPurgeRemovedEvery every 1m: feed.feedPurgeRemoved
