#!/bin/bash
set -u
export PATH=/opt/homebrew/bin:$HOME/.volta/bin:$HOME/.cargo/bin:$HOME/.bun/bin:$PATH
export PATH=$HOME/.volta/tools/image/node/24.19.0/bin:$PATH
ulimit -n 65536
export SNAPBACK4_FENCE_PUBLISHED=/Users/ccheever/sb4-03-lanes/published-0.2.33
cd "$HOME/projects/snapback-integ6/snapback4"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0
export LIBSQLITE3_FLAGS=-USQLITE_ENABLE_MEMORY_MANAGEMENT
export CARGO_BUILD_JOBS=12
mkdir -p target/integ7-proof
failures=0
run() {
  local name="$1"; shift
  "$@" > "target/integ7-proof/$name.log" 2>&1
  local result=$?
  printf '%s %s\n' "$name" "$result" | tee -a target/integ7-proof/status.tsv
  if [ "$result" != 0 ]; then failures=$((failures+1)); fi
}
git rev-parse HEAD > target/integ7-proof/source.txt
node --version > target/integ7-proof/node.txt
printf 'TMPDIR=%s\nFD_LIMIT=%s\n' "$TMPDIR" "$(ulimit -n)" > target/integ7-proof/environment.txt
: > target/integ7-proof/status.tsv
run install bun install --frozen-lockfile
run build env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo build --workspace --quiet
run wasm env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 bash scripts/build-wasm.sh
run docs env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 node scripts/docs-budget.mjs
run release-guard env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 bash scripts/check-release-guard.sh
run typecheck bun run --cwd packages/snapback4 typecheck
run client-build bun run --cwd packages/snapback4 build
run chat-check bash -c 'cd apps/chat && ../../target/debug/snapback4 check'
run rust-warm env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 cargo test --workspace --no-run
run cargo-test env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 node scripts/run-rust-tests.mjs
run fixtures node scripts/run-client-tests.mjs 1 files fixtures/
run chat-typecheck bun run --cwd apps/chat typecheck
run expo-typecheck bun run --cwd apps/chat-expo typecheck
run xcframework env CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 bash scripts/build-xcframework.sh
run swift-compile env SKIP_BUNDLING=1 xcodebuild -workspace apps/chat-expo/ios/Snapback4chat.xcworkspace -scheme Snapback4chat -configuration Release -destination 'generic/platform=iOS Simulator' -arch arm64 -derivedDataPath target/integ6-expo CODE_SIGNING_ALLOWED=NO SKIP_BUNDLING=1 build
client_files=()
for path in packages/snapback4/test/*.test.mjs; do
  case "$(basename "$path")" in app-session-model.test.mjs|online-client-model.test.mjs) ;; *) client_files+=("$path");; esac
done
cpus=$(node -p 'require("node:os").availableParallelism()')
slots=$((cpus / 3)); if [ "$slots" -lt 1 ]; then slots=1; fi; if [ "$slots" -gt 24 ]; then slots=24; fi
printf 'CPUS=%s\nSLOTS=%s\nFILES=%s\n' "$cpus" "$slots" "${#client_files[@]}" >> target/integ7-proof/environment.txt
run client-tests node scripts/run-client-tests.mjs "$slots" files "${client_files[@]}"
run client-models node scripts/run-client-tests.mjs 1 models packages/snapback4/test/app-session-model.test.mjs packages/snapback4/test/online-client-model.test.mjs
printf 'FINAL_FAILURES=%s\n' "$failures" | tee target/integ7-proof/result.txt
[ "$failures" -eq 0 ]
