All named round-0 reproductions are fixed. I found **no High or Medium issue and no landing blocker**, but two Low follow-ups remain.

Using the retained binaries after confirming source equality across 1,073 source/build files, I ran **31 timing tests, 11 doctor/recipe tests and 89 guide tests successfully**. The regressions confirm:

- Wildcard listeners omit timing for both loopback and external peers.
- Delayed query, `/changes` and ephemeral acquisitions put approximately 150 ms in `wait`; reopening after a commit counts both acquisitions.
- Route/token refusals and pending responses retain timing when CORS is suppressed.
- Idle doctor output distinguishes no samples from an unavailable CPU clock. Missing clocks omit header CPU and produce `cpu: null`.
- A one-second held poll reported **151.072 ms engine**, **0.112 ms wait**, and **1000.219 ms total**.

The retained negative-control logs show the corresponding tests failing when these fixes are removed. I inspected those logs; I did not mutate source.

1. **Low — synchronous clock maintenance still bypasses acquisition attribution.**  
   [serve_maintenance.rs:15](/home/ccheever/sb4-intent/review-se-r12-astra/snapback4/crates/snapback4/src/serve_maintenance.rs:15), [serve_readers.rs:68](/home/ccheever/sb4-intent/review-se-r12-astra/snapback4/crates/snapback4/src/serve_readers.rs:68)

   `/dev/clock/advance` calls `work()` synchronously inside the request’s sample. Its `engine_work()` uses `background()`, whose admission skips `waited()`, and `retry_missing()` can call `engine.reader()` outside the acquisition helper. Consequently, maintenance writer contention disappears from `wait`, and reader-factory recovery counts as engine time.

   **Failing regression to add:** under an active request sample, delay maintenance writer admission by 150 ms; assert that `wait` includes it. Separately, force a missing reader factory and delay its retry open by 150 ms; assert that the delay enters `wait`, excluding `engine`. Neither property currently holds.

   **Smallest fix:** call `latency::waited(started)` for background admission too—it already does nothing without an active sample—and wrap the retry open in `latency::acquire`. Correct the report’s assertion that maintenance always occurs outside request sampling.

   **Nonblocking:** this concerns the dev clock endpoint, not the measured query paths.

2. **Low — the wildcard regression bypasses the production listener-to-dispatch wiring.**  
   [serve.rs:380](/home/ccheever/sb4-intent/review-se-r12-astra/snapback4/crates/snapback4/src/serve.rs:380), [serve_tests.rs:110](/home/ccheever/sb4-intent/review-se-r12-astra/snapback4/crates/snapback4/src/serve_tests.rs:110)

   **Surviving mutation:** replace the production dispatch call’s listener predicate with `true`. The wildcard unit test supplies its own correctly calculated predicate, so it still passes; the real-process latency tests use loopback listeners. Actual `dev --bind 0.0.0.0 --i-understand-cleartext` would again disclose timing to loopback peers.

   **Smallest fix:** add a real-process wildcard-bind regression covering both peers. **Nonblocking:** the current production predicate is correct.

The implemented fence is otherwise sound: recorder-generated timing requires dev, a loopback listener and the peer/Host/Origin checks. Refusals cannot enable timing after failing that fence. `serve` never enables it. Strictly, an application route can supply its own `Server-Timing` header through existing custom-header forwarding; that is application output, not recorder disclosure.

Outside the clock-maintenance exception, reader acquisitions use the helper, foreground writer admission is timed, and poll/action sleeps lie outside engine spans. I found no introduced panic or material request-path slowdown; the alternating overhead measurement showed **5.037 µs median overhead**.

The disclosure rationale now acknowledges the additional information and its development-only justification. The recipe passes; SS figures retain their measurement qualifications. The merge’s combined diff preserves both journal appends and LLP revision histories. The checkout remains unchanged.

**READY WITH CHANGES**