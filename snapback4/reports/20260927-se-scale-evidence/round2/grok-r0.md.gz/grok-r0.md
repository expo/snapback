I'll review the scale-evidence change read-only: the diff, the lane prompt, and the measured evidence, then check whether timings leak anything a wall-clock response does not.The branch is one commit on top of `51b318c63`. Next I’ll read the lane prompt, the report, and the source diff, leaving the evidence binaries alone.The header is gated in `Sample::with_headers`. I’ll trace every response path and the loopback check before judging what it can leak.The binary is built. Next I’ll probe loopback `dev`, `serve`, and a non-loopback bind for `Server-Timing`.**READY WITH CHANGES.** The dev timing fence holds, the 14,400 probes support the report, and the acquisition figures match lane SS. Two small product bugs should be fixed before this is the builder-facing latency tool.

## Disclosure

`Server-Timing` is not a second copy of wall-clock time. `wait`, `engine`, and `cpu` split one request into checkout, time holding a reader or writer, and that thread's CPU. Under load, CPU isolates work that wall-clock hides. On loopback `dev`, a query's logical meter already omits private authorization candidates, while `engine` and `cpu` include that walk, because it runs inside the reader span in `serve.rs`. That does not reveal rows, keys, principals, or meter counts. The lane's own report is right to refuse a claim of zero extra timing information.

It does not leave the dev fence.

- The only gate is `shared.personas && dev_request(...)` at `snapback4/crates/snapback4/src/serve.rs:413`. `serve` sets `personas` false. `header()` at `latency.rs:241` emits nothing unless that flag is set.
- I built this commit and probed it. Loopback `dev` sends `total`, `wait`, `engine`, and `cpu`. A bad `Origin` is 403 with no `Server-Timing`. On `dev --bind 0.0.0.0`, a connection from this host's public address is 403 with no header, including when `Host` and `Origin` are spoofed as loopback. The same bind's loopback peer does get the header.
- `serve` on loopback: anonymous `POST /q/fast` is 401 with no header; a service-token query is 200 with `data: 1` and no meter and no header. `GET /dev/latency` is 401 without the token and 200 with it, still with no `Server-Timing`. `serve --bind 0.0.0.0` from the public address is 401 with no header.
- Doctor's new `engine` and `cpu` fields are the same snapshot as before: loopback `dev`, or a live service token on `serve`. They are per-operation aggregates, not per principal. A service operator already sees totals. No meter counts were added.

## Timings

The spans match the stated definitions on the paths that matter.

- **Total** starts at HTTP acceptance and, on the header, ends at header construction. Doctor's total continues through the final write.
- **Wait** is reader checkout, including opening a connection and a failed open, plus foreground writer-lock acquisition. Later acquisitions add.
- **Engine** is time holding a reader or the writer, counted once when nested. Query, mutation, sync, action admission, and change-poll checks sit inside it. Condvar sleeps in `/changes` and action waits sit outside it.
- **CPU** is `CLOCK_THREAD_CPUTIME_ID` from worker start. If `clock_gettime` fails, or the delta goes backwards, `cpu_elapsed()` is `None` and the header omits `cpu` (`latency.rs:245`). It does not write zero. Other platforms hit the same `None` via the `cfg` in `thread_cpu()` (`latency.rs:139`).
- Histogram adds saturate. The header value is ASCII, so `Header::from_bytes` does not panic on it. A request adds a handful of `clock_gettime` calls. That is not visible next to the millisecond queries in this evidence.

### Low — idle operations are reported as "cpu unavailable"

`snapback4/crates/snapback4/src/verbs/latency.rs:24` (fed by `latency.rs:101`)

`cpu` is `None` whenever `cpu_n` is 0. The text then says `cpu unavailable` for every operation that has not run, on a machine whose thread clock works. I saw this on the binary just built: after two `/q/fast` samples, `doctor --latency` printed `cpu n=2` for `/q/fast` and `cpu unavailable` for `/q/idle`, `/sync`, and `/changes`, all with `n=0`. JSON is `cpu: null` in both the "no samples" and "clock missing" cases.

Failing case: `snapback4 doctor --latency` on a fresh dev server, before any traffic. Every line says the clock is missing.

Smallest fix: if `n == 0`, print `cpu n=0` and keep a null or empty `cpu` only as "no samples". Print `cpu unavailable` only when `n > 0 && cpu_n == 0`.

### Low — some dev refusals never get the header

`snapback4/crates/snapback4/src/serve.rs:664`

The header is attached only inside `cors()`, and `cors()` runs only when `allow_origin` is true. Query, mutation, action, sync, and change refusals use `respond_timed` and do get it. I confirmed `POST /q/missing` (404) and `OPTIONS /q/fast` (204). Route and token refusals call `respond_with_cors(..., false)` (`serve_routes.rs:37`, `serve_token.rs:128`), so a loopback dev client that already passed the fence gets no `Server-Timing`. Fence failures stay clean, because their sample flag is already false.

Failing case: a declared route whose auth check fails on loopback `dev`. The 401 has no `Server-Timing`; `POST /q/missing` does.

Smallest fix: add `latency::header()` in `respond_with_sync` whether or not CORS is allowed. Do not change the sample flag.

## Attribution

The report matches the samples. I recomputed `summary.json` from the three gzipped sample files.

- 6,990 HTTP samples per condition, 4,800 measured, 20,970 total. Wait never exceeds 0.047 ms. No sample lacks `cpu`.
- Quiet search p95: client 5.086 ms, server 4.000, wait 0.001, engine 3.775, CPU 3.839. Under the ten busy-loops: client 10.497, server 9.187, wait 0.001, engine 7.837, CPU 3.914. Paired server-minus-CPU p95 goes from 0.160 ms to 5.808 ms. The five cited samples match `builderClient` to 0.001 ms.
- The same-corpus midpoint control fails search 5/10 and trending 4/10 when quiet, and 8/10 and 6/10 under contention. Quiet per-round search p95 is 3.873–6.209 ms.
- The preserved calibration #23 50% samples do cluster: search 29.2 then 24.2/24.4, `following500` 25.8/25.3 and 21.4/21.8. The host log sits near load 8. The new runs do not identify that historical tail. The report says so, and it does not claim overlapping writers or an idle machine. Condition (a) is 28%/46% busy on the pinned CPUs. That limit is stated.

Nothing in the report outruns those measurements.

## Guide

The `bounds` recipe is the block the CLI test runs verbatim. `bounds_guide_growth_recipe_runs_verbatim_against_dev` passed in `verification/server-doctor-fixed.log.gz` (10/10). The header format it parses is what this binary sends. Its p95 index matches the server's nearest-rank rule (`ceil(0.95 * n) - 1`). `latency`, `performance`, `p95`, `benchmark`, and `load test` are new, point at `bounds`, and do not collide with a card or an existing alias. `load test` is one positional, same as the other multi-word aliases (`snapback4 guide 'load test'`).

The sync card's figures match `round2-measurements.json`, not a rounded wish. Final Node memory/fake-IndexedDB, no concurrent writer: 1.671 s / 16.324 s and 2.022 s / 21.036 s, 15,588 / 110,088 rows. Chromium 151.0.7922.34 with a live writer: 4.186 s / 27.327 s. During-acquisition p95 at 1,000 is 13.158 s (19 samples, 0 timeouts), still over 1 s; after acquisition, 0.754 s. The 100-conversation during p95 is 2.449 s (5 samples). Host and toolchain are SS's: `expo-build-1000`, shared Linux, 96 CPUs, Node 24.13.1. The card calls them observed runs and points at `ROUND2.md`. It does not promise a curve.

## Test strength

A mutation that survives: in `latency.rs:245`, emit `cpu;dur=0.000` when `cpu_elapsed()` is `None`. `headers.rs:30` requires the `cpu` key on Linux, where the clock works, and the burn tests only check that a present clock counts this thread. Nothing fails a platform that reports zero instead of omitting CPU.

Same class of hole: `duration.rs` checks that a held `/changes` poll's total includes the blocked write. It never checks that `engine` stays small across the sleep. Wrapping that sleep in `EngineSpan` would still pass.

## Verdict

**READY WITH CHANGES.** Fix the idle `cpu unavailable` line, and attach `Server-Timing` even when CORS is suppressed. The fence, the probe attribution, the recipe, and the SS citations can stand.
