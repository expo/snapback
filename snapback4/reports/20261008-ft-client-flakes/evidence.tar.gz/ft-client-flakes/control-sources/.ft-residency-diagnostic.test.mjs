import { captureStdout } from './helpers/server-output.mjs';
import { waitFor as awaitState, hangBudget } from './helpers/wait.mjs';
// Real process devices: server-run watches are live, and never read an empty
// device page as an offline server answer (LLP 3000.007 §6.5).
import test from "node:test";
import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { once } from "node:events";
import { mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { createLocalClient } from "../dist/local.js";
import { processDevice } from "../dist/native.js";
import { webDevice, memoryPersistence } from "../dist/web.js";

const root = join(dirname(fileURLToPath(import.meta.url)), "../../..");
const binary = process.env.SNAPBACK4_BIN ?? join(root, "target/debug/snapback4");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const query = (name) => ({ kind: "query", name });
const schema = `use personas alice, bob
table notes:
  owner: principal
  text: text <=100
  at: time
  by byTime: at, id
  by byOwner: owner, id
  public 'public notes'
  insert <- .owner = viewer
  sync last 2 by byTime
maintain counts: count notes by owner
  read <- allow
table audit:
  text: text <=100
  at: time
  by byTime: at, id
  public 'audit fixture'
  insert <- allow
  online only
query audits(c: cursor ?):
  return audit after c last 10 by byTime
query auditById(id: audit):
  return audit[id]
query localNotes(c: cursor ?):
  return notes after c last 1 by byTime
query presence(p: principal):
  return exists connected[p]
query wrappedPresence(p: principal):
  return [{ online: exists connected[p] }]
query identifiedPresence(p: principal):
  return { id: p, online: exists connected[p] }
query shapedNotes():
  return notes last 5 by byTime { text, at }
table permits:
  principal: principal
  expiresAt: time
  expire at .expiresAt
  by byExpiresAt: expiresAt
  unique byPrincipal: principal
  read <- .principal = viewer
  sync to .principal
table secrets:
  body: text <=100
  read <- exists permits[principal = viewer]
  online only
query secret(id: secrets):
  return secrets[id]
query connections(p: principal):
  return connected[p]
mutation add(text: text <=100):
  return insert audit { text, at: now }
`;
async function until(check, message, options) { return awaitState(check, message, options); }
function project(t) {
  const directory = mkdtempSync(join(tmpdir(), "sb4-residency-"));
  mkdirSync(join(directory, "snapback"));
  writeFileSync(join(directory, "snapback/schema.q"), schema);
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  return directory;
}
async function fixture(t, watchSources = false, tier = "native") {
  const directory = project(t);
  const child = spawn(binary, ["dev", "--port", "0", "--fresh", ...(watchSources ? [] : ["--no-watch"])], { cwd: directory, stdio: ["ignore", "pipe", "pipe"] });
  const readStdout = captureStdout(child);
  const exit = once(child, "exit");
  let log = "", url;
  child.stdout.on("data", (data) => { log += data; url ??= readStdout().match(/http:\/\/127\.0\.0\.1:\d+(?=\r?\n)/)?.[0]; });
  child.stderr.on("data", (data) => { log += data; });
  const clients = [];
  t.after(async () => {
    await Promise.allSettled(clients.map((client) => client.close()));
    if (child.exitCode == null && child.signalCode == null) child.kill("SIGTERM");
    await exit;
  });
  await until(() => { assert.equal(child.exitCode, null, log); return url; }, "server did not listen");
  const seed = async (rows) => {
    const reply = await fetch(`${url}/seed`, { method: "POST", body: JSON.stringify(rows) }).then((r) => r.json());
    assert.equal(reply.seeded, rows.length, JSON.stringify(reply));
  };
  await seed([
    { table: "audit", row: { id: "a1", text: "server answer", at: 1 } },
    { table: "notes", row: { id: "n1", text: "local one", at: 1, owner: "dev:alice" } },
    { table: "notes", row: { id: "n2", text: "local two", at: 2, owner: "dev:alice" } },
  ]);
  let offline = false, requests = 0;
  const trace = []; let transitionTrace = [];
  const record = (kind, detail) => { trace.push({ at: performance.now(), kind, ...detail }); if (trace.length > 200) trace.shift(); };
  const deviceReads = [], deviceAnswers = [];
  let queryGate = null;
  const persistence = memoryPersistence();
  const open = async () => {
    const data = join(directory, "device"); mkdirSync(data, { recursive: true });
    const opener = tier === "wasm" ? webDevice({ persist: persistence, wasm: readFileSync(join(root, "packages/snapback4/src/wasm/snapback4_device_bg.wasm")) }) : processDevice({ binary, dir: data, spawn: (cmd, args) => spawn(cmd, args, { stdio: ["pipe", "pipe", "inherit"] }), writeFile: async (path, text) => writeFileSync(path, text) });
    const client = await createLocalClient({ url, persona: "alice", waitSeconds: 1,
      fetch: async (input, init) => {
        const id = ++requests, path = new URL(input).pathname;
        record("request", { id, path, offline });
        if (offline) throw new TypeError("test link down");
        const response = await fetch(input, init);
        record("response", { id, path, offline });
        return response;
      },
      device: { open: async (...args) => { const core = await opener.open(...args); return { close: () => core.close(), call: async (request) => { if (request.op === "query") { deviceReads.push(request.name); if (queryGate) await queryGate; } const answer = await core.call(request); if (["apply", "observe_store", "query"].includes(request.op)) record(request.op, { name: request.name, page: request.page, answer }); if (request.op === "query") deviceAnswers.push({ name: request.name, ...answer.ok }); return answer; } }; } },
    });
    client.onLink(link => record("link", { link }));
    clients.push(client); return client;
  };
  return { trace: () => ({ transition: transitionTrace, latest: trace }), url, directory, log: () => log, seed, open, offline: (value) => { if (value) transitionTrace = trace.slice(); offline = value; }, requests: () => requests, deviceReads, deviceAnswers, gateQueries: gate => { queryGate = gate; } };
}

test("server-class watches run locally first and recover remembered server data offline", { timeout: hangBudget(12) }, async (t) => {
  const f = await fixture(t);
  const client = await f.open(); await client.sync();
  const backend = await fetch(`${f.url}/schema`, { headers: { "x-snapback-persona": "alice" } }).then((r) => r.json());
  assert.equal(backend.programs.find((p) => p.name === "audits").runs, "server");
  assert.equal(backend.schema.operations.audits.runs, "server");
  assert.equal(backend.programs.find((p) => p.name === "add").predicts, "never");
  let watch = client.observe(query("audits"), { c: null });
  const diagnostics = () => JSON.stringify({ snapshot: watch.getSnapshot(), link: client.link(), trace: f.trace() });
  await until(() => watch.getSnapshot().data?.[0]?.id === "a1", "initial server answer missing");
  await f.seed([{ table: "audit", row: { id: "a2", text: "commit touched only the server table", at: 2 } }]);
  await until(() => watch.getSnapshot().data?.[0]?.id === "a2", "online-only commit did not rerun watch");
  f.offline(true); await client.sync();
  await until(() => watch.getSnapshot().fresh === false, "offline watch downgrades the remembered answer", { diagnostics });
  assert.equal(watch.getSnapshot().data[0].id, "a2");
  assert.ok(watch.getSnapshot().since > 0);
  watch.close();
  watch = client.observe(query("audits"), { c: null });
  await awaitState(() => watch.getSnapshot().data?.[0]?.id === "a2" && watch.getSnapshot().fresh === false, "recreated watch recovers the server answer", { diagnostics });
  assert.equal(watch.getSnapshot().data[0].id, "a2", "recreated watch recovers the last server answer");
  assert.equal(watch.getSnapshot().fresh, false);
  assert.ok(f.deviceReads.includes("audits"), "static server classes must run locally first");
  f.offline(false); await client.sync();
  await until(() => watch.getSnapshot().fresh === true, "watch did not recover online");
  watch.close();
});

test("offline cold watches withhold placeholders, persisted local reads still work", { timeout: hangBudget(12) }, async (t) => {
  const f = await fixture(t);
  let client = await f.open(); await client.sync();
  assert.equal((await client.query(query("auditById"), { id: "a1" })).data.text, "server answer");
  f.offline(true); await client.sync();
  const remembered = await client.query(query("auditById"), { id: "a1" });
  assert.equal(remembered.data.text, "server answer"); assert.equal(remembered.fresh, false); assert.ok(remembered.since > 0);
  const watch = client.observe(query("auditById"), { id: "never-observed" });
  await sleep(20);
  assert.deepEqual(watch.getSnapshot(), { loading: true });
  const local = await client.query(query("localNotes"), { c: null });
  assert.equal(local.data[0].id, "n2");
  assert.equal(local.fresh, false);
  watch.close(); await client.close();
  client = await f.open();
  const cold = await client.query(query("auditById"), { id: "a1" });
  assert.equal(cold.denied.code, "E_OFFLINE", "server memory lasts only for this client lifetime");
  assert.equal((await client.query(query("localNotes"), { c: null })).data[0].id, "n2");
  assert.ok(f.deviceReads.includes("auditById"));
});

test("connected recovers a server false offline instead of the device presence assumption", { timeout: hangBudget(7) }, async (t) => {
  const f = await fixture(t), client = await f.open(); await client.sync();
  const online = await client.query(query("presence"), { p: "dev:bob" });
  assert.equal(online.data, false);
  f.offline(true); await client.sync();
  const offline = await client.query(query("presence"), { p: "dev:bob" });
  assert.equal(offline.data, false); assert.equal(offline.complete, true); assert.equal(offline.fresh, false); assert.ok(offline.since > 0);
  assert.equal((await client.query(query("presence"), { p: "dev:unseen" })).denied.code, "E_OFFLINE");
  assert.ok(f.deviceReads.includes("presence"));
});

test("clock advance expires presence on the server and a device", { timeout: hangBudget(12) }, async (t) => {
  const f = await fixture(t), client = await f.open(); await client.sync();
  const headers = { "x-snapback-persona": "bob", "content-type": "application/json" };
  await fetch(`${f.url}/changes?wait=0`, { headers }).then(r => r.json());
  const read = () => fetch(`${f.url}/q/connections`, { method: "POST", headers, body: JSON.stringify({ args: { p: "dev:bob" } }) }).then(r => r.json());
  assert.equal((await client.query(query("connections"), { p: "dev:bob" })).data, 1);
  assert.equal((await read()).data, 1);
  const start = performance.now();
  const advanced = await fetch(`${f.url}/dev/clock/advance`, { method: "POST", body: JSON.stringify({ duration: "36s" }) }).then(r => r.json());
  assert.equal(advanced.advancedMs, 36000);
  assert.equal((await read()).data, 0);
  assert.equal((await client.query(query("connections"), { p: "dev:bob" })).data, 0);
  assert.equal((await client.query(query("connections"), { p: "dev:bob" })).fresh, true);
  assert.ok(f.deviceReads.includes("connections"), "presence runs locally before unknown facts fall back");
  t.diagnostic(`presence device: advanced_ms=36000 before=1 after=0 wall_ms=${(performance.now() - start).toFixed(2)}`);
  await fetch(`${f.url}/changes?wait=0`, { headers }).then(r => r.json());
  assert.equal((await client.query(query("connections"), { p: "dev:bob" })).data, 1);
});

test("presence effects residency is additive in check, why and generated artifacts", (t) => {
  const directory = project(t);
  const path = join(directory, "snapback/schema.q");
  const effects = `${schema}\neffect notify\nmutation send():\n  insert notes { owner: viewer, text: 'hi', at: now }\n  if not exists connected[viewer]:\n    emit notify { target: viewer }\n`;
  writeFileSync(path, effects);
  const run = (...args) => { const result = spawnSync(binary, args, { cwd: directory, encoding: "utf8" }); assert.equal(result.status, 0, result.stdout + result.stderr); return result.stdout; };
  const explanation = "connected: decides effects only — the server decides who is notified at commit";
  const checked = run("check", "--residency");
  assert.match(checked, /send: predicts: eligible/);
  assert.ok(checked.includes(explanation));
  assert.ok(run("why", "send").includes(explanation));
  const facts = JSON.parse(readFileSync(join(directory, "snapback/generated/residency.json"), "utf8"));
  assert.equal(facts.send.connected_effects_only, true);
  assert.equal(facts.presence.runs, "server");
  for (const key of ["predicts", "sites", "requires"]) assert.ok(key in facts.send);
  const api = readFileSync(join(directory, "snapback/generated/api.ts"), "utf8");
  assert.ok(api.includes(explanation));
  assert.match(api, /name: "send", predicts: "eligible"/);
  writeFileSync(path, effects.replace("  if not exists connected[viewer]:\n    emit notify { target: viewer }", "  require exists connected[viewer] else X"));
  assert.match(run("check"), /N_NOT_PREDICTABLE[\s\S]*decides a require X/);
  writeFileSync(path, effects);
  assert.doesNotMatch(run("check"), /N_NOT_PREDICTABLE|N_NOW_SERVER/);
});

test("check sidecar, why and test residency print facts, changes and measured cold rows", { timeout: hangBudget(1) }, async (t) => {
  const directory = project(t);
  const run = (...args) => { const result = spawnSync(binary, args, { cwd: directory, encoding: "utf8" }); assert.equal(result.status, 0, result.stdout + result.stderr); return result.stdout; };
  const first = run("check", "--residency");
  assert.match(first, /residency \(facts\)/); assert.match(first, /operations \(facts\)/);
  assert.match(first, /from the read rule/); assert.match(first, /inherited from notes/);
  assert.match(first, /N_MAINTAIN_SYNCED/);
  assert.match(run("why", "audits"), /server[\s\S]*audit[\s\S]*rewrite:/);
  assert.match(run("why", "notes"), /inferred from read/);
  const path = join(directory, "snapback/schema.q");
  writeFileSync(path, schema.replace("  sync last 2 by byTime", "  online only"));
  assert.match(run("check"), /N_NOW_SERVER[\s\S]*localNotes/);
  assert.doesNotMatch(run("check"), /N_NOW_SERVER/);
  writeFileSync(path, schema);
  const fixture = join(directory, "fixture"); mkdirSync(fixture);
  writeFileSync(join(fixture, "notes.jsonl"), [1, 2, 3].map((n) => JSON.stringify({ id: `n${n}`, owner: "dev:alice", text: `note${n}`, at: n })).join("\n"));
  const measured = run("test", "--residency", "--verbose", "--fixture", fixture);
  assert.match(measured, /alice notes: 2 rows/); assert.match(measured, /bob notes: 2 rows/);
  assert.match(measured, /alice counts: 1 rows/); assert.match(measured, /maintain counts \(measurement\): 1 value rows/);
  assert.match(measured, /total across personas: 6 rows/);
  assert.ok(readFileSync(join(directory, "snapback/generated/residency.json"), "utf8").includes('"runs"'));
  console.log(measured.split("\n").filter((line) => /\d+ rows, \d+ bytes|maintain counts \(measurement\)/.test(line)).join("\n"));
});


test("dev compares residency with the served generation even when check advanced its sidecar", { timeout: hangBudget(3) }, async (t) => {
  const f = await fixture(t, true);
  writeFileSync(join(f.directory, "snapback/schema.q"), schema.replace("  sync last 2 by byTime", "  online only"));
  const checked = spawnSync(binary, ["check"], { cwd: f.directory, encoding: "utf8" });
  assert.equal(checked.status, 0, checked.stdout + checked.stderr);
  await until(() => f.log().includes("schema adopted as generation 2"), "dev did not adopt edited schema");
  assert.match(f.log(), /N_NOW_SERVER[\s\S]*localNotes/);
  const backend = await fetch(`${f.url}/schema`, { headers: { "x-snapback-persona": "alice" } }).then((r) => r.json());
  assert.equal(backend.schema.operations.localNotes.runs, "server");
});

for (const tier of ["wasm", "native"]) {
  test(`provenance ${tier}: wrapped presence recovers false, shaped rows without ids stay partial`, { timeout: hangBudget(8) }, async t => {
    const f = await fixture(t, false, tier);
    // Seed before acquisition: live delivery correctly retains older held rows.
    await f.seed([{ table: "notes", row: { id: "n3", text: "local three", at: 3, owner: "dev:alice" } }]);
    const client = await f.open(); await client.sync();
    for (const name of ["wrappedPresence", "identifiedPresence"]) {
      const online = await client.query(query(name), { p: "dev:bob" });
      assert.deepEqual(online.data, name === "wrappedPresence" ? [{ online: false }] : { id: "dev:bob", online: false });
      const raw = f.deviceAnswers.findLast(answer => answer.name === name);
      assert.equal(raw.speculative, true);
    }
    f.offline(true); await client.sync();
    for (const name of ["wrappedPresence", "identifiedPresence"]) {
      const offline = await client.query(query(name), { p: "dev:bob" });
      assert.deepEqual(offline.data, name === "wrappedPresence" ? [{ online: false }] : { id: "dev:bob", online: false });
      assert.equal(offline.fresh, false);
    }
    const shaped = await client.query(query("shapedNotes"), {});
    assert.deepEqual(shaped.data, [{ text: "local three", at: 3 }, { text: "local two", at: 2 }]);
    assert.equal(shaped.complete, false); assert.equal(shaped.fresh, false);
    const raw = f.deviceAnswers.findLast(answer => answer.name === "shapedNotes");
    assert.equal(Object.hasOwn(raw, "speculative"), false); assert.equal(raw.unknown, true);
  });
}
test("rule 5: a real process device never recovers private memory after its permit expiry", { timeout: hangBudget(14) }, async t => {
  const f = await fixture(t), client = await f.open(); await client.sync();
  const expiresAt = Date.now() + 2500;
  await f.seed([
    { table: "permits", row: { id: "permit", principal: "dev:alice", expiresAt } },
    { table: "secrets", row: { id: "secret", body: "private" } },
  ]);
  await client.sync();
  const op = query("secret"), args = { id: "secret" };
  const server = () => fetch(`${f.url}/q/secret`, { method: "POST", headers: { "x-snapback-persona": "alice" }, body: JSON.stringify({ args }) }).then(r => r.json());
  const first = await server();
  assert.equal(first.data.body, "private"); assert.equal(first.nextExpiry, expiresAt);
  assert.equal((await client.query(op, args)).data.body, "private");
  const watch = client.observe(op, args); t.after(() => watch.close());
  await until(() => watch.getSnapshot().data?.body === "private", "watch did not acquire the authorized answer");
  f.offline(true); await client.sync();
  await until(() => watch.getSnapshot().fresh === false, "watch did not recover stale memory before expiry");
  assert.equal(watch.getSnapshot().data.body, "private");
  const deliveries = [];
  const stop = watch.subscribe(() => deliveries.push({ at: Date.now(), read: watch.getSnapshot() })); t.after(stop);
  // A slow device must not extend the deadline of the currently visible memory.
  let release;
  f.gateQueries(new Promise(resolve => { release = resolve; }));
  try {
    await until(() => Date.now() >= expiresAt + 40, "permit did not expire");
    assert.deepEqual(watch.getSnapshot(), { loading: true }, "expiry ends retention before awaiting the device");
  } finally { f.gateQueries(null); release(); }
  assert.equal((await server()).data, null, "authoritative rule denies the expired permit");
  const after = await client.query(op, args);
  assert.equal(after.denied.code, "E_OFFLINE"); assert.equal("data" in after, false);
  await until(() => !("data" in watch.getSnapshot()), "watch kept private memory beyond its scheduled authorization expiry");
  assert.deepEqual(watch.getSnapshot(), { loading: true });
  assert.ok(deliveries.some(item => item.at >= expiresAt && item.read.loading), "the deadline itself must rerun the offline watch");
  assert.ok(deliveries.filter(item => item.at >= expiresAt).every(item => !("data" in item.read)), JSON.stringify(deliveries));
});
