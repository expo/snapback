import { mkdtempSync, writeFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { runFile } from '../../scripts/run-client-tests.mjs';
import { processTable, processExists } from '../../scripts/test-processes.mjs';

for (const mode of ['replay-all', 'enumeration-only']) {
  const dir = mkdtempSync(join(tmpdir(), 'sb4-pd-trace-'));
  const file = join(dir, 'leak.test.mjs');
  writeFileSync(file, `import test from 'node:test';import {execFileSync} from 'node:child_process';test('helper',()=>{execFileSync('/bin/sh',['-c','sleep 600 </dev/null >/dev/null 2>&1 &'])});`);
  let group, before, inspections = 0, emptyInspections = 0, output = '';
  const events = [];
  try {
    const result = await runFile(file, {onStart: child => { group = child.pid; }, onOutput: text => { output += text; }, inspect: async options => {
      const current = await processTable(options);
      const identity = options.pid !== undefined;
      if (mode === 'enumeration-only' && identity) {
        events.push({kind:'identity', pid:options.pid, present:processExists(options.pid), live:current.filter(row => row.alive && row.group === group).map(row => row.pid)});
        return current;
      }
      inspections++;
      if (inspections === 1) before = current;
      if (inspections >= 3) emptyInspections = current.some(row => row.group === group && row.alive) ? 0 : emptyInspections + 1;
      events.push({kind:identity ? 'identity' : 'enumeration', pid:options.pid, emptyInspections, replay:!!emptyInspections,
        live:current.filter(row => row.alive && row.group === group).map(row => row.pid),
        before:before.filter(row => row.group === group).map(row => ({pid:row.pid, alive:row.alive, present:processExists(row.pid)}))});
      return emptyInspections ? before : current;
    }});
    writeFileSync(new URL(`./trace-${mode}.json`, import.meta.url), JSON.stringify({mode,result,inspections,emptyInspections,events,output},null,2)+'\n');
    console.log(JSON.stringify({mode,inspections,emptyInspections,passed:result.passed,reason:result.reason,inspectionFailure:result.inspectionFailure,elapsed:result.elapsed,events:events.slice(0,8)}));
  } finally { rmSync(dir, {recursive:true,force:true}); }
}
